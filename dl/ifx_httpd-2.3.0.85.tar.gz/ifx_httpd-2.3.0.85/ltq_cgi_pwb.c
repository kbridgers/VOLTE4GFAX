#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#include "ifx_api_util.h"

extern char natvsAction[MAX_FILELINE_LEN];
int32 ltq_pwb_get_all_lanif(char8 iface_array[][MAX_IFACE_LEN]);
int32 ltq_pwb_get_conname_of_lanif(char_t *ifName, char_t *conname);

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
extern int ifx_httpd_parse_args(int argc, char_t **argv, char_t *fmt, ...);
void ltq_set_pwb_add(httpd_t wp, char_t *path, char_t *query);
void ltq_set_pwb(httpd_t wp, char_t *path, char_t *query);
int ltq_get_pwb(int eid, httpd_t wp, int argc, char_t **argv);
void ltq_get_pwb_rule(int eid, httpd_t wp, int argc, char_t **argv);

char gbl_ifaces[MAX_LAN_IFS][MAX_IFACE_LEN];
uint32 gbl_ifcount=0;
char glbl_pwbcpeid[4]={0},glbl_pwbpcpeid[4]={0};

/*********************************************************************************
* Function: ltq_set_pwb_add
* Description: This function sets the port binding entry 
*	1. If the Action is ADD: it reads all the parameters and saves to rc.conf and applies to system
*	3. If the action is MODIFY entry; it reads the entry from rc.conf updates the modified vaue
*	   and then saves it to rc.conf and configures the rule.
*
*********************************************************************************/
void ltq_set_pwb_add(httpd_t wp, char_t *path, char_t *query)
{
	pwb_cfg_t pwb, *pwb_list=NULL;
	uint32 count_lan_bound_int = 0, i, num=0;
	char8 command[MAX_FILELINE_LEN], buf[32];
	char_t *pPWBName = ifx_httpdGetVar(wp, T("PWBName"), T(""));
	char_t *pPWB_WAN_CONN = ifx_httpdGetVar(wp, T("PWB_WAN_CONN"), T(""));
	char_t *pSubAction = ifx_httpdGetVar(wp, T("subaction"), T(""));
	char_t *pwbEna= ifx_httpdGetVar(wp, T("PWBEnable"), T(""));
	char_t *pwbWanMode= ifx_httpdGetVar(wp, T("PWB_WANMODE"), T(""));

	char_t *lan_ifvals[MAX_LAN_IFS];

	memset(lan_ifvals,0,sizeof(char_t*)*MAX_LAN_IFS);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "gbl_ifcount=%d\n",gbl_ifcount);

	for(i=0; i<gbl_ifcount; i++) {
		memset(&buf,0,sizeof(buf));
		if(strlen(gbl_ifaces[i])) {
			gsprintf(buf, T("cb_lanport%d"), i);
			lan_ifvals[i]=ifx_httpdGetVar(wp, buf, T(""));
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add","i=%d >>%s<< : >>%s<<\n", i, gbl_ifaces[i],lan_ifvals[i]);
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "");

	memset(&pwb,0x00,sizeof(pwb));
	memset(command, 0, sizeof(command));
	if (!gstrcmp(pSubAction, T("MODIFY_ENTRY"))) {
	
		pwb.iid.cpeId.Id=atoi(ifx_httpdGetVar(wp, T("pwbcpeid"), T("")));
		pwb.iid.pcpeId.Id=atoi(ifx_httpdGetVar(wp, T("pwbpcpeid"), T("")));
		if(mapi_port_binding_cfg_get_all(&num, &pwb_list, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to get all port wan mapping info !!");
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "Fail to get all port wan mapping info !!");
			goto IFX_Handler;
		}
		for(i=0;i<num;i++) {
			if((pwb_list+i)->iid.cpeId.Id==pwb.iid.cpeId.Id && (pwb_list+i)->iid.pcpeId.Id==pwb.iid.pcpeId.Id){
				pwb.bitMask=(pwb_list+i)->bitMask;
				// If the WAN connection changes the parent will also change
				pwb.iid.pcpeId.Id=0;
				break;
			}
		}
	} 
	
	sprintf(pwb.pwbName, "%s", pPWBName);
	pwb.pwbEnable = atoi(pwbEna);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "status=%d", pwb.pwbEnable);

	for(i=0,count_lan_bound_int=0; i<gbl_ifcount; i++) {
		if(strlen(gbl_ifaces[i])){
			if(strlen(lan_ifvals[i])) {
				strncpy(pwb.lanifNames[count_lan_bound_int++], lan_ifvals[i], MAX_IFACE_LEN);
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "i=%d %s",i, pwb.lanifNames[count_lan_bound_int-1]);
			}
		}
	}


	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "pwb.numLANifs=%d",count_lan_bound_int);
	pwb.numLANIfs = count_lan_bound_int;
	sprintf(pwb.wanIf.conName, "%s", pPWB_WAN_CONN);
	pwb.wanIf.mode=atoi(pwbWanMode);
	pwb.iid.config_owner=IFX_WEB;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "mode=%d con_name=%s", pwb.wanIf.mode, pwb.wanIf.conName);
	
	if (!gstrcmp(pSubAction, T("MODIFY_ENTRY"))) {
		if(mapi_port_binding_cfg_set(IFX_OP_MOD, &pwb,
				IFX_F_MODIFY)!=IFX_SUCCESS){
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add",
				"mapi_port_binding_cfg_set failed");
		}
	} else {

		if(mapi_port_binding_cfg_set(IFX_OP_ADD, &pwb,
				IFX_F_INT_ADD)!=IFX_SUCCESS){
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add",
				"mapi_port_binding_cfg_set failed");
		}
	}
IFX_Handler:
	IFX_MEM_FREE(pwb_list);
	ifx_httpdRedirect(wp, T("pwb.asp"));
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb_add", "return");
}

/*********************************************************************************
* Function: ltq_get_pwb
* Description: This function gets the port binding status  and all portbinding entries
*	1. If if Action is Info: it reads all the Port binding entries and displays
*	2. If the Action is pwb_status: it reads the status of Port binding feature.
**********************************************************************************/
int ltq_get_pwb(int eid, httpd_t wp, int argc, char_t **argv)
{
	char_t  *name, conn_name[MAX_CONN_NAME_LEN];
	uint32	pwb_index_cnt=0, interface_index=0, num=0 ,ret = IFX_SUCCESS;
	pwb_cfg_t *pwb = NULL;
	pwb_status_t pwb_status;
	lan_port_sep_status_t lps;
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	dw_config_info_t dw_state;
	uint32 secwanmode;
#endif
	memset(&pwb_status,0x00,sizeof(pwb_status));
	memset(&lps,0x00,sizeof(lps));
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "Insufficient args\n");
		return -1;
	}
	if ( !gstrcmp(name, T("Info")) ) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "info\n");
		if(mapi_port_binding_cfg_get_all(&num, &pwb, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to get all port wan mapping info !!");
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "Fail to get all port wan mapping info !!");
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb","mapi_port_binding_cfg_get_all succeeded\n");
	
		if(num<8)  {
			ifx_httpdWrite(wp, T("<th><a href=\"#\" class=\"button\" value=\"Add\" onClick=\"return pwbaddEntry();\">Add</a></th></tr>"));
		}
	
		mapi_lan_port_sep_status_get(&lps,IFX_F_DEFAULT);
		ifx_httpdWrite(wp, T("<tr><td><input type='hidden' name='lan_port_sep' value=\"%d\">\n</td></tr>"), lps.enable);
		IFX_MAPI_DEBUG(fd,"/tmp/ltq_get_pwb","ltq_mapi_get_lan_port_sep succeeded %d\n", lps.enable);

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
		//if dual wan is enabled; get the dual wan configured parameters
		//check dualwan is enabled in hybrid mode by calling dw_mapi_cfg_get 
		if(dw_mapi_cfg_get(&dw_state, IFX_F_GET_ANY) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to get dual wan configurations!!");
			goto IFX_Handler;
		}	

		if(dw_state.fo_state==FO_WO_LOADBAL && dw_state.fo_type==FO_HSB) {
			ifx_httpdWrite(wp, T("<tr><td><input type='hidden' name='dw_status' value='1'></td></tr>\n"));
			secwanmode=compute_wan_mode(dw_state.sec_wan_cfg.phy_mode, dw_state.sec_wan_cfg.wan_tc);
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_secmode\" value=\"%d\">\n"), secwanmode);
		} else {
			ifx_httpdWrite(wp, T("<tr><td><input type='hidden' name='dw_status' value='0'></td></tr>\n"));
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_secmode\" value='-1'>\n"));
		}
#else
		ifx_httpdWrite(wp, T("<input type='hidden' name='dw_status' value='0'>\n"));
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_secmode\" value='-1'>\n"));
#endif
		ifx_httpdWrite(wp, T("<input type='hidden' name='pwb_count' value=\"%d\">\n"),num);
		for(pwb_index_cnt=0; pwb_index_cnt < num; pwb_index_cnt++) {
			ifx_httpdWrite(wp, T("\t\t\t<tr>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<td>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t</td>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<td id=\"pwb_pwbName%d\">"),pwb_index_cnt+1);
			ifx_httpdWrite(wp, T("%s</td>\n"),(pwb+pwb_index_cnt)->pwbName);
			ifx_httpdWrite(wp, T("\t\t\t\t<td id=\"pwb_ifName%d\">"),pwb_index_cnt+1);
			for(interface_index=0 ; interface_index < (pwb+pwb_index_cnt)->numLANIfs ; interface_index++) {
				memset(conn_name,'\0',MAX_CONN_NAME_LEN);
				ltq_pwb_get_conname_of_lanif((pwb+pwb_index_cnt)->lanifNames[interface_index], conn_name);
				ifx_httpdWrite(wp, T("%s "), conn_name);
			}
			ifx_httpdWrite(wp, T("</td>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<td id=\"pwb_wanIfName%d\">"),pwb_index_cnt+1);
			bzero(conn_name,MAX_CONN_NAME_LEN);
			memset(conn_name,'\0',MAX_CONN_NAME_LEN);
			if(strstr((pwb+pwb_index_cnt)->wanIf.conName,"IP")) 
				ifx_get_wan_confconnName_from_connName((pwb+pwb_index_cnt)->wanIf.conName,conn_name,0);	
			else 
				ifx_get_wan_confconnName_from_connName((pwb+pwb_index_cnt)->wanIf.conName,conn_name,1);	
			if(strlen(conn_name))
				ifx_httpdWrite(wp, T("%s</td>\n"),conn_name);
			else
				ifx_httpdWrite(wp, T("%s</td>\n"),(pwb+pwb_index_cnt)->wanIf.conName);
			ifx_httpdWrite(wp,T("\t\t\t\t<td id=\"pwb_pwben%d\">"),pwb_index_cnt+1);
			ifx_httpdWrite(wp, T("<input type=\"checkbox\" name=\"PWB_F%d\" value=\"1\"%s disabled></td>\n"),pwb_index_cnt + 1, (pwb+pwb_index_cnt)->pwbEnable ? " CHECKED" : " ");
			ifx_httpdWrite(wp, T("\t\t\t\t</td>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<td>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<a href=\"#\" class=\"button\" name=\"PWB_MOD%d\" value=\" Modify \" onClick=\"return pwbmodEntry(%d,%d);\">Modify</a>\n"),
					pwb_index_cnt,(pwb+pwb_index_cnt)->iid.cpeId.Id,
                                       (pwb+pwb_index_cnt)->iid.pcpeId.Id);
			ifx_httpdWrite(wp, T("\t\t\t\t<a href=\"#\" class=\"button\" name=\"PWD_DEL%d\" value=\" Delete \" onClick=\"return pwbdelEntry(%d,%d,%d);\">Delete</a>\n"),
			               pwb_index_cnt,(pwb+pwb_index_cnt)->iid.cpeId.Id,
			               (pwb+pwb_index_cnt)->iid.pcpeId.Id,
				       (pwb+pwb_index_cnt)->wanIf.mode);
			ifx_httpdWrite(wp, T("\t\t\t\t</td>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<input type=\"hidden\" name=\"pwb_wanmode%d\" value=\"%d\">\n"), pwb_index_cnt + 1, (pwb+pwb_index_cnt)->wanIf.mode);
			ifx_httpdWrite(wp, T("\t\t\t\t</tr>\n"));
		}
		 IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "Info returns");
	} else if( !gstrcmp(name, T("pwb_status")) ) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "pwb_status");
		mapi_port_binding_status_get(&pwb_status, IFX_F_DEFAULT);
		if (pwb_status.enable)
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "pwb_status success");

	} else	if ( !gstrcmp(name, T("pwb_details")) ) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "pwb_details");
		
		if(mapi_port_binding_status_get(&pwb_status, IFX_F_DEFAULT)  != IFX_SUCCESS) {
                	ifx_httpdError(wp, 500, "Fail to get port binding status!!");
                	return -1; 
        	}
	
		if(mapi_port_binding_cfg_get_all(&num, &pwb, IFX_F_DEFAULT) != IFX_SUCCESS) {
        		ifx_httpdError(wp, 500, "Fail to get all port binding info !!");
                	return -1; 
        	}
	
		ifx_httpdWrite(wp,T("<input type=\"hidden\" id=\"pwb_status\" name=\"pwb_status\" value=\"%d\">\n"),pwb_status.enable);
		ifx_httpdWrite(wp,T("<input type=\"hidden\" id=\"pwb_Count\" name=\"pwb_Count\" value=\"%d\">\n"),num);
	 	for(pwb_index_cnt=0; pwb_index_cnt < num; pwb_index_cnt++) {
			ifx_httpdWrite(wp,T("<input type=\"hidden\" id=\"pwb%d_lanifs_count\" name=\"pwb%d_lanifs_count\" value=\"%d\">\n"),
					pwb_index_cnt,pwb_index_cnt,(pwb+pwb_index_cnt)->numLANIfs);
			for(interface_index=0; interface_index < (pwb+pwb_index_cnt)->numLANIfs ; interface_index++) {
                                ifx_httpdWrite(wp, T("<input type=\"hidden\" id=\"pwb%d_port%d\" name=\"pwb%d_port%d\" value=\"%s\">\n"),
						pwb_index_cnt,interface_index,pwb_index_cnt,interface_index,(pwb+pwb_index_cnt)->lanifNames[interface_index]);
                        }
			ifx_httpdWrite(wp,T("<input type=\"hidden\" id=\"pwb%d_mode\" name=\"pwb%d_mode\" value=\"%d\">\n"),pwb_index_cnt,pwb_index_cnt,(pwb+pwb_index_cnt)->wanIf.mode);
			ifx_httpdWrite(wp,T("<input type=\"hidden\" id=\"pwb%d_conname\" name=\"pwb%d_conname\" value=\"%s\">\n"),pwb_index_cnt,pwb_index_cnt,(pwb+pwb_index_cnt)->wanIf.conName);
			ifx_httpdWrite(wp,T("<input type=\"hidden\" id=\"pwb%d_status\" name=\"pwb%d_status\" value=\"%d\">\n"),pwb_index_cnt,pwb_index_cnt,(pwb+pwb_index_cnt)->pwbEnable);
                }
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb", "pwb_details success");
        }

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		IFX_MEM_FREE(pwb);
	} else {
		IFX_MEM_FREE(pwb);
	}
	return ret;
}

/*********************************************************************************
* Function: ltq_set_pwb
* Description: This function sets the port binding status in the system.  
*	1. If the action is ADD entry; it displays the ADD page 
*	2. If the Action is Delete entry, it calls the delete function with the selected index
*	3. If the action is MODIFY entry; it displays the modify page with the values in the current.
*
*********************************************************************************/
void ltq_set_pwb(httpd_t wp, char_t *path, char_t *query)
{
	pwb_cfg_t pwb;
	pwb_status_t pwb_status;
	char_t  *pSubAction = ifx_httpdGetVar(wp, T("subaction"), T(""));
	char_t  *pEN_Status,*pwbcpeid,*pwbpcpeid;
	uint32 ret = IFX_SUCCESS;
	char command[MAX_FILELINE_LEN];
	memset(&pwb,0x00,sizeof(pwb));
	memset(&pwb_status,0x00,sizeof(pwb_status));
	
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb", "");

	if(!gstrcmp(pSubAction, T("SUBMIT"))) {

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb", "SUBMIT");

		pEN_Status = ifx_httpdGetVar(wp, T("pwbstatus"), T(""));
		if(mapi_port_binding_status_get(&pwb_status, IFX_F_DEFAULT)!=IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to get ipwb status !!");
			goto IFX_Handler;
		}
		pwb_status.enable = atoi(pEN_Status);
		mapi_port_binding_status_set(&pwb_status,IFX_F_MODIFY);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb", "SUBMIT return");

	} else if (!gstrcmp(pSubAction, T("DELETE_ENTRY"))) {

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb", "DELETE_ENTRY");
		
		memset (&pwb,0,sizeof(pwb_cfg_t));
		pwb.iid.pcpeId.Id=atoi(ifx_httpdGetVar (wp, T ("delindex_pcpid"), T ("")));
		pwb.iid.cpeId.Id=atoi(ifx_httpdGetVar (wp, T ("delindex_cpid"), T ("")));
		memset(command, 0, sizeof(command));
		if(mapi_port_binding_cfg_set(IFX_OP_DEL, &pwb, 0)!= IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to delete pwb entry");
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_pwb", "DELETE_ENTRY returns");
	} else if(!gstrcmp(pSubAction, T("MODIFY_ENTRY"))) {
		pwbcpeid = ifx_httpdGetVar(wp, T("delindex_cpid"), T(""));
		pwbpcpeid = ifx_httpdGetVar(wp, T("delindex_pcpid"), T(""));
		strcpy(glbl_pwbcpeid, pwbcpeid);  // cpeid of the entry to be modified
		strcpy(glbl_pwbpcpeid, pwbpcpeid); 
		strcpy(natvsAction, pSubAction);
                ifx_httpdRedirect(wp, "pwb_add.asp");
                return;
	} else if(!gstrcmp(pSubAction, T("ADD_ENTRY"))) {
		strcpy(natvsAction, pSubAction);
                ifx_httpdRedirect(wp, "pwb_add.asp");
                return;
	}
	ifx_httpdRedirect(wp, T("pwb.asp"));
IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	}
}
/*********************************************************************************
* Function: ltq_get_pwb_rule
* Description: It gets all the existing port binding rules, and does the following
*	1. If the action is ADD entry; it does all the validations and displays 
*	   all the available ports on the page.
*	2. If the action is MODIFY entry; it displays the corresponding entry
*
*********************************************************************************/
void ltq_get_pwb_rule(int eid, httpd_t wp, int argc, char_t **argv)
{
	uint32 pwb_index_cnt=0, ifName_index=0;
	uint32 num=0, i=0, j=0;
	uint32 pwb_wan_flag=0;
	int num_wan=0;
	pwb_cfg_t *pwb = NULL;
	WAN_CONN_CFG *p_wancfg;
	pwb_wanif_t wanIface;
	char_t conn_name[MAX_CONN_NAME_LEN];
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	dw_config_info_t dw_state;
	uint32  pri_wanmode=0, sec_wanmode=0;
#endif
	uint32 pwb_cpeid=0, pwb_pcpeid=0, pwb_offset=10; 
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	char_t wlan_tab=0;
#endif
#ifdef CONFIG_FEATURE_IFX_USB_DEVICE
	char_t usb_tab=0;
#endif
	
	LTQ_LOG_TIMESTAMP("Begin");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");

	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"PWB_WANMODE\" value=\"0\">"));
	//get all LAN interfaces
	memset(&gbl_ifaces,'\0',sizeof(gbl_ifaces));
	gbl_ifcount = ltq_pwb_get_all_lanif(gbl_ifaces);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	LTQ_LOG_TIMESTAMP("ltq_pwb_get_all_lanif done");
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"gbl_num_lanif\" value=\"%d\">\n"),gbl_ifcount); 
	
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	//get all WAN connections
	if(ifx_get_all_wan(&num_wan,&p_wancfg,IFX_F_GET_ANY)!=IFX_SUCCESS){
		ifx_httpdError(wp, 500, "Fail to get all wan connection info !!");
		goto IFX_Handler;
	}
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"gbl_num_wanif\" value=\"%d\">\n"),num_wan);
	for(i=0;i<num_wan;i++) {
		if((p_wancfg+i)->type==WAN_TYPE_IP) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"gbl_wanif%d_conname\" value=\"%s\">\n"),i, (p_wancfg+i)->wancfg.ip.wan_cfg.conn_name);
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"gbl_wanif%d_mode\" value=\"%d\">\n"),i, (p_wancfg+i)->wancfg.ip.wan_cfg.wan_mode.mode);
		} else {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"gbl_wanif%d_conname\" value=\"%s\">\n"),i,(p_wancfg+i)->wancfg.ppp.wan_cfg.conn_name);
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"gbl_wanif%d_mode\" value=\"%d\">\n"),i,(p_wancfg+i)->wancfg.ppp.wan_cfg.wan_mode.mode);
		}
	
	}

	
	LTQ_LOG_TIMESTAMP("ifx_get_all_wan");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	if(mapi_port_binding_cfg_get_all(&num, &pwb, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get all port wan mapping info !!");
		goto IFX_Handler;
	}
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwb_numentries\" value=\"%d\">\n"),num);
	for(i=0;i<num;i++) {
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwb%d_numlanifs\" value=\"%d\">\n"), i, (pwb+i)->numLANIfs);	
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwb%d_wanconname\" value=\"%s\">\n"), i, (pwb+i)->wanIf.conName);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwb%d_wanmode\" value=\"%d\">\n"), i, (pwb+i)->wanIf.mode);
		for(j=0;j<(pwb+i)->numLANIfs;j++) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwb%d_lanif%d\" value=\"%s\">\n"),i,j,(pwb+i)->lanifNames[j]);
		}
	}
	
	LTQ_LOG_TIMESTAMP("mapi_port_binding_cfg_get_all");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	//ifx_get_lan_connName_from_ifname

	if (!strcmp(natvsAction, "MODIFY_ENTRY")) {
		pwb_cpeid=atoi(glbl_pwbcpeid);
		pwb_pcpeid=atoi(glbl_pwbpcpeid);	
		
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwbcpeid\" value=\"%d\">\n"),pwb_cpeid);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwbpcpeid\" value=\"%d\">\n"),pwb_pcpeid);
		
		for(pwb_index_cnt=0; pwb_index_cnt< num; pwb_index_cnt++) {
			if((pwb+pwb_index_cnt)->iid.cpeId.Id==pwb_cpeid && (pwb+pwb_index_cnt)->iid.pcpeId.Id==pwb_pcpeid){
				pwb_offset=pwb_index_cnt;
				ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwb_offset\" value=\"%d\">\n"),pwb_offset);
				break;
			}	
		}
	} else {
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwbcpeid\" value=\"0\">\n"));
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"pwbpcpeid\" value=\"0\">\n"));
	}
	
	LTQ_LOG_TIMESTAMP("");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	//if dual wan is enabled; get the dual wan configured parameters
	//check dualwan is enabled in hybrid mode by calling dw_mapi_cfg_get 
	if(dw_mapi_cfg_get(&dw_state, IFX_F_GET_ANY) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get dual wan configurations!!");
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	if(dw_state.fo_state==FO_WO_LOADBAL && dw_state.fo_type==FO_HSB) {
	
		pri_wanmode=compute_wan_mode(dw_state.pri_wan_cfg.phy_mode, dw_state.pri_wan_cfg.wan_tc);
		sec_wanmode=compute_wan_mode(dw_state.sec_wan_cfg.phy_mode, dw_state.sec_wan_cfg.wan_tc);
				
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_fo_hsb\" value=\"1\">\n"));
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_primode\" value=\"%d\">\n"),pri_wanmode);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_secmode\" value=\"%d\">\n"),sec_wanmode);

	} else {
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_fo_hsb\" value=\"0\">\n"));
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_primode\" value=\"0\">\n"));
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_secmode\" value=\"0\">\n"));
	}
#else
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_fo_hsb\" value=\"0\">\n"));
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_primode\" value=\"0\">\n"));
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"dw_secmode\" value=\"0\">\n"));
#endif
	
	LTQ_LOG_TIMESTAMP("hidden done");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	ifx_httpdWrite(wp, T("<span class=\"textTitle\">ADD/MODIFY Port Binding Rule</span>"));
	ifx_httpdWrite(wp, T("<div align=\"center\">\n"));
	ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));
	ifx_httpdWrite(wp, T("\t<tr><td><br></td></tr>\n"));
	ifx_httpdWrite(wp, T("\t<tr>\n"));
	ifx_httpdWrite(wp, T("\t\t<td width=\"5%\"></td>\n"));
	ifx_httpdWrite(wp, T("\t\t<td width=\"15%\">Port Binding Name</td>\n"));
	ifx_httpdWrite(wp, T("\t\t<td colspan=\"12\">"));
	ifx_httpdWrite(wp, T("<input type=\"text\" name=\"PWBName\" size=\"12\" maxlength=\"60\""));	
	if (!strcmp(natvsAction, "MODIFY_ENTRY") && pwb_offset < 8) {
		ifx_httpdWrite(wp, T("value=\"%s\">\n"), (pwb+pwb_offset)->pwbName);
	} else {
		ifx_httpdWrite(wp, T("value=\"PWBName%d\">\n"),num+1);
	}
	ifx_httpdWrite(wp, T("\t\t</td>\n\t</tr>\n\t<tr><td><br></td></tr>\n"));
	
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
		
	LTQ_LOG_TIMESTAMP("name");
	ifx_httpdWrite(wp, T("\t<tr>\n"));
	ifx_httpdWrite(wp, T("\t<td></td>\n"));
	ifx_httpdWrite(wp, T("\t\t<td>WAN Connections</td>\n"));
	ifx_httpdWrite(wp, T("\t\t<td width=\"10%\">\n"));
	if (!strcmp(natvsAction, "MODIFY_ENTRY") && pwb_offset < 8) {
		ifx_httpdWrite(wp, T("\t\t\t<select name=\"PWB_WAN_CONN\" size=\"1\" onChange=\"updateLanPorts();\" disabled>\n"));
	} else {
		ifx_httpdWrite(wp, T("\t\t\t<select name=\"PWB_WAN_CONN\" size=\"1\" onChange=\"updateLanPorts();\">\n"));
	}
	//find whether the interface is already part of a pwb rule
	for(i=0;i<num_wan;i++) {
		pwb_wan_flag=0;
		bzero(&wanIface,sizeof(pwb_wanif_t));
		if((p_wancfg+i)->type==WAN_TYPE_IP) {
			strncpy(wanIface.conName,(p_wancfg+i)->wancfg.ip.wan_cfg.conn_name,MAX_CONN_NAME_LEN);
		} else {
			strncpy(wanIface.conName,(p_wancfg+i)->wancfg.ppp.wan_cfg.conn_name,MAX_CONN_NAME_LEN);
		}
		for(pwb_index_cnt=0; pwb_index_cnt< num; pwb_index_cnt++) {
			if(!strncmp((pwb+pwb_index_cnt)->wanIf.conName, wanIface.conName, MAX_IF_NAME)) {
				//check whether modify operation
				if(pwb_index_cnt == pwb_offset) pwb_wan_flag=2;
				else pwb_wan_flag=1; //this interface should be greyed out as there is one port binding rule already configured
				break;
			}
		}

		bzero(conn_name,MAX_CONN_NAME_LEN);
		ifx_get_wan_confconnName_from_connName(wanIface.conName,conn_name,(p_wancfg+i)->type);	
		
		if(pwb_wan_flag == 0) {
			ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"sroute_%s\" value=\"%s\">%s</option>\n"),
								wanIface.conName,wanIface.conName,conn_name);
		} else if (pwb_wan_flag == 2) {
			ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"sroute_%s\" value=\"%s\" selected>%s</option>\n"),
								wanIface.conName,wanIface.conName,conn_name);	
		} else {
			ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"sroute_%s\" value=\"%s\" disabled>%s</option>\n"),
								wanIface.conName,wanIface.conName,conn_name);
		}
	
	}	
	        	
	LTQ_LOG_TIMESTAMP("wan");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	ifx_httpdWrite(wp, T("\t\t\t</select>\n"));
	ifx_httpdWrite(wp, T("\t\t</td>\n\t</tr>\n<tr><td><br></td></tr>\n"));
		
	ifx_httpdWrite(wp, T("\t<tr>\n"));
	ifx_httpdWrite(wp, T("\t\t<td></td>"));
	ifx_httpdWrite(wp, T("\t\t<td>Ethernet LAN Ports</td>\n"));

	LTQ_LOG_TIMESTAMP("lan-begin");
	for(ifName_index=0 ; ifName_index< gbl_ifcount ; ifName_index++) {
	LTQ_LOG_TIMESTAMP("lan");
		if(strlen(gbl_ifaces[ifName_index])) {
#ifdef CONFIG_FEATURE_IFX_WIRELESS
			if((!wlan_tab) && 
			   (!strncmp(gbl_ifaces[ifName_index],"wlan",4) || !strncmp(gbl_ifaces[ifName_index],"ath",3))) {
				ifx_httpdWrite(wp, T("\t\t<td width=\"20%\"><br></td>\n</tr>\n"));
				ifx_httpdWrite(wp, T("\t<tr><td><br></td></tr>\n"));
				ifx_httpdWrite(wp, T("\t<tr>\n"));
				ifx_httpdWrite(wp, T("\t\t<td></td>"));
				ifx_httpdWrite(wp, T("\t\t<td colspan=\"1\">WLAN</td>\n"));
				wlan_tab=1;
			}
#endif
#ifdef CONFIG_FEATURE_IFX_USB_DEVICE
			if((!usb_tab) && (!strncmp(gbl_ifaces[ifName_index],"usb",3))){
				ifx_httpdWrite(wp, T("\t\t<td width=\"20%\"><br></td>\n</tr>\n"));
				ifx_httpdWrite(wp, T("\t<tr><td><br></td></tr>\n"));
				ifx_httpdWrite(wp, T("\t<tr>\n"));
				ifx_httpdWrite(wp, T("\t\t<td></td>"));
				ifx_httpdWrite(wp, T("\t\t<td colspan=\"1\">USB</td>\n"));
				usb_tab=1;
			}
#endif
			bzero(conn_name,MAX_CONN_NAME_LEN);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "ifname=%s", gbl_ifaces[ifName_index]);
			LTQ_LOG_TIMESTAMP("lan-calling ltq_pwb_get_conname_of_lanif");
			ltq_pwb_get_conname_of_lanif(gbl_ifaces[ifName_index], conn_name);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "conname=%s", conn_name);
			LTQ_LOG_TIMESTAMP("lan after calling ltq_pwb_get_conname_of_lanif");
			ifx_httpdWrite(wp, T("\t\t<td align=\"right\">%s</td><td width=\"2%\"><input type=CHECKBOX name=\"cb_lanport%d\" value=\"%s\" ></td>\n"),
									conn_name, ifName_index, gbl_ifaces[ifName_index]);
		}
	}
	ifx_httpdWrite(wp, T("\t\t<td width=\"20%\"><br></td>\n</tr>\n"));
	ifx_httpdWrite(wp, T("\t<tr><td><br></td></tr>\n"));

	LTQ_LOG_TIMESTAMP("lan-end");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	ifx_httpdWrite(wp, T("\t<tr>\n"));	
	ifx_httpdWrite(wp, T("\t\t<td></td>"));
	ifx_httpdWrite(wp, T("\t\t<td>Enabled</td>\n"));
	ifx_httpdWrite(wp, T("\t\t<td><input type=\"checkbox\" name=\"PWBEnable\" "));	
	if (!strcmp(natvsAction, "MODIFY_ENTRY") && pwb_offset < 8) {
		ifx_httpdWrite(wp, T("value=\"1\" %s>\n"), (pwb+pwb_offset)->pwbEnable ? " CHECKED" : " ");
	} else {
		ifx_httpdWrite(wp, T("value=\"1\" CHECKED>\n"));
	}
	ifx_httpdWrite(wp, T("\t\t</td></tr><tr><td><br></td></tr>\n"));
	
	ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
	ifx_httpdWrite(wp, T("\t updateLanPorts();\n"));
	ifx_httpdWrite(wp, T("</script>\n"));
	
	ifx_httpdWrite(wp, T("</table>\n"));

        ifx_httpdWrite(wp, T("</div>\n"));

	ifx_httpdWrite(wp, T("<div align=\"right\">\n"));      
   
  	ifx_httpdWrite(wp, T("<a class=\"button\" href=\"javascript:void(0);\" onClick=\"window.open('help.htm#filter','help','toolbar=0,status=0,menubar=0,scrollbars=1,resizable=1,width=530,height=400,left=150,top=150');\">Help</a>\n"));
	if (!strcmp(natvsAction, "MODIFY_ENTRY")) {
		ifx_httpdWrite(wp, T("<a class=\"button\" href=\"#\" name=\"PWB_APPLY\" value=\"Apply\" onClick=\"return modEntry();\">Apply</a>\n"));
	}else {
		ifx_httpdWrite(wp, T("<a class=\"button\" href=\"#\"name=\"PWB_APPLY\" value=\"Apply\" onClick=\"return addEntry();\">Apply</a>\n"));
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	LTQ_LOG_TIMESTAMP("end");
IFX_Handler:
	//free the buffer
	IFX_MEM_FREE(p_wancfg);
	IFX_MEM_FREE(pwb);
}
/*********************************************************************************
* Function: ltq_pwb_get_all_lanif
* Description: It gets all the lan side interfaces fron the system by reading the 
* ifconfig.
*********************************************************************************/
int32 ltq_pwb_get_all_lanif(char8 iface_array[][MAX_IFACE_LEN])
{
	uint32 iRet=IFX_SUCCESS;
	uint32 num_lan=0, i=0;
	int32  inflag=IFX_F_GET_ANY, outflag = 0;	
	LTQ_LOG_TIMESTAMP(" begin");
#if defined (CONFIG_FEATURE_IFX_USB_DEVICE)	|| defined (CONFIG_FEATURE_IFX_WIRELESS)
	char8 sVal[MAX_IF_NAME];
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
#endif
	FILE *fp=NULL;
	char buf[1024];
#ifdef CONFIG_FEATURE_IFX_USB_DEVICE
	uint32 num_usb=0;
	if ((iRet = ifx_GetObjData(FILE_RC_CONF, "usb0_mode", "usb0Mode",
	                           inflag, (IFX_OUT uint32 *)&outflag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;
	if(atoi(sVal)==2) num_usb++;
	if ((iRet = ifx_GetObjData(FILE_RC_CONF, "usb1_mode", "usb1Mode",
	                           inflag,(IFX_OUT uint32 *)&outflag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;
	if(atoi(sVal)==2) num_usb++;
#endif
	LTQ_LOG_TIMESTAMP(" ");
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	uint32 num_wlan=0;
	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, TAG_WLAN_MAIN "_Count",
	                           inflag, (IFX_OUT uint32 *)&outflag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;
	num_wlan = atoi(sVal);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "num_wlan=%d", num_wlan);
#endif
	LTQ_LOG_TIMESTAMP(" ");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	fp = popen("ifconfig | grep eth0. | awk '{print $1}'","r");
	while(fp){
                if(feof(fp) || ferror(fp)) break;
		memset(buf,0x00,sizeof(1024));
		if(fgets(buf,1024,fp)!= NULL) {
			strncpy(iface_array[num_lan+i],buf,strlen(buf)-1);
			i++;
		}
		if((i==2) && !(strncmp(iface_array[0],"eth0",7))){
			strcpy(iface_array[0],iface_array[1]);
			i=1;
		}
	}
	pclose(fp);
	num_lan=i;

	LTQ_LOG_TIMESTAMP(" ");
#ifdef CONFIG_FEATURE_IFX_USB_DEVICE
	fp = NULL; i=0;
	if(num_usb) {
		fp = popen("ifconfig | grep usb | awk '{print $1}'","r");
		while(fp) {
		    if( i< num_usb) {
			if(feof(fp) || ferror(fp)) break;
			memset(buf,0x00,sizeof(1024));
			if(fgets(buf,1024,fp)!= NULL) {
				strncpy(iface_array[num_lan+i],buf,strlen(buf)-1);
				i++;
			}
		    } else break;	
		}
		pclose(fp);
	}
	num_lan+=i;
#endif
	LTQ_LOG_TIMESTAMP(" ");
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "");
	fp = NULL;i=0;
	if(num_wlan) {
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATHEROS
		fp = popen("ifconfig | grep ath | awk '{print $1}'","r");
		while(fp) {
		    if( i< num_wlan) {
			if(feof(fp) || ferror(fp)) break;
			memset(buf,0x00,sizeof(1024));
			if(fgets(buf,1024,fp)!= NULL) {
				strncpy(iface_array[num_lan+i],buf,strlen(buf)-1);
				i++;
			}
		    } else break;	
		}
		pclose(fp);
		fp=NULL;
#endif
	LTQ_LOG_TIMESTAMP(" ");
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
		fp = popen("ifconfig | grep wlan | awk '{print $1}'","r");
		while(fp) {
		    if( i< num_wlan) {
			if(feof(fp) || ferror(fp)) break;
			memset(buf,0x00,sizeof(1024));
			if(fgets(buf,1024,fp)!= NULL) {
				strncpy(iface_array[num_lan+i],buf,strlen(buf)-1);
				i++;
			}
		    } else break;	
		}
		pclose(fp);
#endif 
	LTQ_LOG_TIMESTAMP(" ");
	}
	num_lan+=i;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_pwb_rule", "num_lan=%d",num_lan);
#endif
	iRet = num_lan;
	LTQ_LOG_TIMESTAMP("end");
IFX_Handler:
	return iRet;
}


/*********************************************************************************
* Function: ltq_pwb_get_conname_of_lanif
* Description: It gets SSID from wlan interface name
*********************************************************************************/
int  ltq_pwb_get_conname_of_lanif(char_t *ifName, char_t *conname) {
	char buf[1024]={};
	FILE *fp=NULL;
	//ethernet LAN
	if(!(strncmp(ifName,"eth0",4))) { 
		//call the api to get the connection name
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 	
	if(lan_port_sep_enable_get()==IFX_SUCCESS) {
		bzero(buf,1024);
		if(mapi_lan_get_ifname_from_conname(ifName, buf)==IFX_SUCCESS){
			strncpy(conname,buf,MAX_CONN_NAME_LEN);
		} else {
			strncpy(conname,ifName,MAX_CONN_NAME_LEN);
		}
	} else {
		strncpy(conname,ifName,MAX_CONN_NAME_LEN);
	}
#else		
	strncpy(conname,ifName,MAX_CONN_NAME_LEN);
#endif
	} else  {      // Wireless LAN
		sprintf(buf, "iwconfig %s | grep ESSID | awk '{ print $3 }' | cut -d'\"' -f2", ifName);
		fp = popen(buf,"r");
		if(fp!=NULL) {
			memset(buf,'\0',1024);
			if(fgets(buf,1024,fp)!=NULL) {
				strncpy(conname,buf,strlen(buf)-1);
			}
			pclose(fp);
		} else {
			strncpy(conname,ifName,MAX_CONN_NAME_LEN);
			return IFX_FAILURE;
		}
	}
	return IFX_SUCCESS;
}
#endif
