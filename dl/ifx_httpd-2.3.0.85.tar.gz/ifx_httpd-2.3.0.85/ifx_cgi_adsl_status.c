#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)

#include "ifx_httpd.h"
#include <ifx_emf.h>
#include <sys/ioctl.h>

//#include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#include <drv_dsl_cpe_api_g997.h>

#include "ifx_cgi_adsl_status.h"

DSL_G997_LineInventory_t lineInventoryGet;
DSL_uint8_t FarEndSystemVendorID[DSL_G997_LI_MAXLEN_VENDOR_ID];
DSL_uint8_t FarEndVersionNumber[DSL_G997_LI_MAXLEN_VERSION];
DSL_uint8_t FarEndSerialNumber[DSL_G997_LI_MAXLEN_SERIAL];
DSL_LineState_t lineState;
DSL_G997_XTUSystemEnabling_t xtuSystemEnabling;
#ifdef PLATFORM_VR9
DSL_BandPlanStatus_t xtuBandPlanStatus;
#endif
DSL_G997_PowerManagementStatus_t pwrMngStatus;
DSL_G997_PowerManagement_t PowerManagementStatus;
DSL_LineFeature_t lineFeatureConfig;
DSL_G997_FramingParameterStatus_t g997FramingParamStatusGet;
DSL_G997_ChannelStatus_t channelStatus;
DSL_uint32_t ActualInterleaveDelay;
DSL_uint32_t DownStreamActualDataRate;
DSL_uint32_t UpStreamActualDataRate;
DSL_G997_LineStatus_t lineStatus;
DSL_uint32_t DownStreamATTNDR;
DSL_uint32_t UpStreamATTNDR;
//DSL_uint32_t DownStreamINTLVDEPTH;
DSL_uint16_t DownStreamINTLVDEPTH;
//DSL_uint32_t UpStreamINTLVDEPTH;
DSL_uint16_t UpStreamINTLVDEPTH;
//DSL_uint32_t DownStreamLATN;
DSL_int16_t DownStreamLATN;
//DSL_uint32_t UpStreamLATN;
DSL_int16_t UpStreamLATN;
//DSL_uint32_t DownStreamSATN;
DSL_int16_t DownStreamSATN;
//DSL_uint32_t UpStreamSATN;
DSL_int16_t UpStreamSATN;
//DSL_uint32_t DownStreamSNR;
DSL_int16_t DownStreamSNR;
//DSL_uint32_t UpStreamSNR;
DSL_int16_t UpStreamSNR;
//DSL_uint32_t DownStreamACTATP;
DSL_int16_t DownStreamACTATP;
//DSL_uint32_t UpStreamACTATP;
DSL_int16_t UpStreamACTATP;
DSL_G997_LineFailures_t lineFailuresStatusGet;
DSL_G997_BF_LineFailures_t NearEndLOSFailure;
DSL_G997_BF_LineFailures_t FarEndLOSFailure;
DSL_G997_BF_LineFailures_t NearEndLOFFailure;
DSL_G997_BF_LineFailures_t FarEndLOFFailure;
DSL_G997_BF_LineFailures_t NearEndLPRFailure;
DSL_G997_BF_LineFailures_t FarEndLPRFailure;
DSL_G997_DataPathFailures_t dataPathFailuresStatusGet;
DSL_G997_BF_DataPathFailures_t NearEndNCDFailure;
DSL_G997_BF_DataPathFailures_t FarEndNCDFailure;
DSL_G997_BF_DataPathFailures_t NearEndLCDFailure;
DSL_G997_BF_DataPathFailures_t FarEndLCDFailure;
DSL_PM_ChannelCountersTotal_t pmChannelCountersTotal;
DSL_PM_ChannelCounters_t pmChannelCounters;	//Eros add for use SHOWTIME counter
DSL_PM_DataPathCounters_t pmDataPathCounters;	//Eros add for use SHOWTIME counter
DSL_uint32_t NearEndCRCFailure;
DSL_uint32_t FarEndCRCFailure;
DSL_uint32_t NearEndRSCorrectionFailure;
DSL_uint32_t FarEndRSCorrectionFailure;
DSL_uint32_t NearEndFECS;
DSL_uint32_t FarEndFECS;
DSL_PM_LineSecCountersTotal_t pmLineSecCountersTotal;
DSL_uint32_t NearEndES;
DSL_uint32_t FarEndES;
DSL_uint32_t NearEndSES;
DSL_uint32_t FarEndSES;
DSL_uint32_t NearEndLOSS;
DSL_uint32_t FarEndLOSS;
DSL_uint32_t NearEndUAS;
DSL_uint32_t FarEndUAS;
DSL_PM_DataPathCountersTotal_t pmDataPathCountersTotal;
DSL_uint32_t NearEndHEC;
DSL_uint32_t FarEndHEC;

DSL_IN DSL_DeltDataType_t gDeltDataType = DSL_DELT_DATA_SHOWTIME;

typedef enum {
	/*
	 * Format as hey values 
	 */
	DSL_ARRAY_FORMAT_HEX,
	/*
	 * Format as string 
	 */
	DSL_ARRAY_FORMAT_STRING
} DSL_CPE_ArrayPrintFormat_t;

extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);

DSL_void_t DSL_CPE_ArraySPrintF(DSL_char_t * pDst,
				DSL_void_t * pSrc,
				DSL_uint16_t nSrcSize,
				DSL_uint16_t nSrcElementSize,
				DSL_CPE_ArrayPrintFormat_t nFormat)
{
	DSL_uint16_t i = 0, j = 0, elements = 0;
	DSL_uint32_t nVal = 0;
	DSL_char_t c;
	DSL_int_t ret = 0;

	elements = nSrcSize / nSrcElementSize;

	if (nFormat == DSL_ARRAY_FORMAT_HEX) {
		ret = sprintf(pDst, "(");
		pDst++;
	}

	for (i = 0; i < elements; i++) {
		if ((i != 0) && (nFormat == DSL_ARRAY_FORMAT_HEX)) {
			ret = sprintf(pDst, ",");
			pDst++;
		}

		if (nFormat == DSL_ARRAY_FORMAT_HEX) {
			switch (nSrcElementSize) {
			case 1:
				ret =
				    sprintf(pDst, "%02X",
					    ((DSL_uint8_t *) pSrc)[i]);
				break;
			case 2:
				ret =
				    sprintf(pDst, "%04X",
					    ((DSL_uint16_t *) pSrc)[i]);
				break;
			case 4:
				ret =
				    sprintf(pDst, "%08X",
					    ((DSL_uint32_t *) pSrc)[i]);
				break;
			default:
				ret = sprintf(pDst, "xx");
				break;
			}

			if (ret > 0) {
				pDst += ret;
			}
		} else {
			switch (nSrcElementSize) {
			case 1:
				nVal =
				    (DSL_uint32_t) (((DSL_uint8_t *) pSrc)[i]);
				break;
			case 2:
				nVal =
				    (DSL_uint32_t) (((DSL_uint16_t *) pSrc)[i]);
				break;
			case 4:
				nVal =
				    (DSL_uint32_t) (((DSL_uint32_t *) pSrc)[i]);
				break;
			default:
				nVal = 0;
				break;
			}

			for (j = 0; j < nSrcElementSize; j++) {
				c = (DSL_uint8_t) (nVal >> j);
				if (isprint(c) != 0) {
					ret = sprintf(pDst, "%c", c);
					pDst += ret;
				}
			}
		}
	}

	if (nFormat == DSL_ARRAY_FORMAT_HEX) {
		ret = sprintf(pDst, ")");
	}
}
int ifx_cgi_dsl_status_get_data(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char buf[100];
	int fd = 0;
#ifdef PLATFORM_VR9
	int ret;
#endif
	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	char_t *dsl_line_str = NULL;
    if (ifx_httpd_parse_args(argc, argv, T("%s"), &dsl_line_str) < 1) { 
		IFX_DBG(" Error !! Insufficient args passed in [%s]!!\n", __FUNCTION__);
    }    
	else {
		dsl_line = atoi(dsl_line_str);
		if ((dsl_line != 0) && (dsl_line != 1)) {
			IFX_DBG(" Error !! Invalid DSL Line Number [%d] Passed in [%s]!!\n", dsl_line, __FUNCTION__);
			dsl_line = 0;
		}
	}	
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		ifx_httpdWrite(wp, T("cannot open device %s"),
			       dev_name);
	}
	// Modem Status
	memset(&lineState, 0x00, sizeof(DSL_LineState_t));
	ioctl(fd, DSL_FIO_LINE_STATE_GET, &lineState);

	// modem selected
	memset(&xtuSystemEnabling, 0x00, sizeof(DSL_G997_XTUSystemEnabling_t));
	ioctl(fd, DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET,
		    &xtuSystemEnabling);

#ifdef PLATFORM_VR9
	memset(&xtuBandPlanStatus, 0x00, sizeof(DSL_BandPlanStatus_t));
	ret = ioctl(fd, DSL_FIO_BAND_PLAN_STATUS_GET, &xtuBandPlanStatus);
	if (ret == 0) {
		if (xtuBandPlanStatus.accessCtl.nReturn != 0) {
			xtuBandPlanStatus.data.nProfile = -1;
		}
	} else {
		if (xtuBandPlanStatus.accessCtl.nReturn != 0) {
			xtuBandPlanStatus.data.nProfile = -1;
		}
	}
#endif
	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log%d",
		lineState.data.nLineState, dsl_line);
#else
	sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log",
		lineState.data.nLineState);
#endif
	system(buf);
	return DSL_SUCCESS;

}
int ifx_cgi_adsl_status_get_data(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char buf[100];
	int fd = 0;
	int i;
#ifdef PLATFORM_VR9
	int ret;
#endif
	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	char_t *dsl_line_str = NULL;
    if (ifx_httpd_parse_args(argc, argv, T("%s"), &dsl_line_str) < 1) { 
		IFX_DBG(" Error !! Insufficient args passed in [%s]!!\n", __FUNCTION__);
    }    
	else {
		dsl_line = atoi(dsl_line_str);
		if ((dsl_line != 0) && (dsl_line != 1)) {
			IFX_DBG(" Error !! Invalid DSL Line Number [%d] Passed in [%s]!!\n", dsl_line, __FUNCTION__);
			dsl_line = 0;
		}
	}	
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		ifx_httpdWrite(wp, T("cannot open device %s"),
			       dev_name);
	}
	// Vendor ID
	memset(&lineInventoryGet, 0x00, sizeof(DSL_G997_LineInventory_t));
	lineInventoryGet.nDirection = DSL_FAR_END;
	ioctl(fd, DSL_FIO_G997_LINE_INVENTORY_GET, &lineInventoryGet);
	for (i = 0; i < DSL_G997_LI_MAXLEN_VENDOR_ID; i++) {
		FarEndSystemVendorID[i] =
		    lineInventoryGet.data.SystemVendorID[i];
	}
	// Version Number
	for (i = 0; i < DSL_G997_LI_MAXLEN_VERSION; i++) {
		FarEndVersionNumber[i] = lineInventoryGet.data.VersionNumber[i];
	}
	// Serial Number
	for (i = 0; i < DSL_G997_LI_MAXLEN_SERIAL; i++) {
		FarEndSerialNumber[i] = lineInventoryGet.data.SerialNumber[i];
	}

	// Modem Status
	memset(&lineState, 0x00, sizeof(DSL_LineState_t));
	ioctl(fd, DSL_FIO_LINE_STATE_GET, &lineState);

	// modem selected
	memset(&xtuSystemEnabling, 0x00, sizeof(DSL_G997_XTUSystemEnabling_t));
	ioctl(fd, DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET,
		    &xtuSystemEnabling);

#ifdef PLATFORM_VR9
	memset(&xtuBandPlanStatus, 0x00, sizeof(DSL_BandPlanStatus_t));
	ret = ioctl(fd, DSL_FIO_BAND_PLAN_STATUS_GET, &xtuBandPlanStatus);
	if (ret == 0) {
		if (xtuBandPlanStatus.accessCtl.nReturn != 0) {
			xtuBandPlanStatus.data.nProfile = -1;
		}
	} else {
		if (xtuBandPlanStatus.accessCtl.nReturn != 0) {
			xtuBandPlanStatus.data.nProfile = -1;
		}
	}
#endif

	// power management mode
	memset(&pwrMngStatus, 0x00, sizeof(DSL_G997_PowerManagementStatus_t));
	
	    ioctl(fd, DSL_FIO_G997_POWER_MANAGEMENT_STATUS_GET, &pwrMngStatus);
	PowerManagementStatus = pwrMngStatus.data.nPowerManagementStatus;

	// trellis-coded modulation
	memset(&lineFeatureConfig, 0x00, sizeof(DSL_LineFeature_t));
	ioctl(fd, DSL_FIO_LINE_FEATURE_STATUS_GET, &lineFeatureConfig);

	// latency type 
	memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
	ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
	ActualInterleaveDelay = channelStatus.data.ActualInterleaveDelay;

	// Data Rate
	memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
	channelStatus.nDirection = DSL_DOWNSTREAM;
	ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
	DownStreamActualDataRate = channelStatus.data.ActualDataRate;

	memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
	channelStatus.nDirection = DSL_UPSTREAM;
	ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
	UpStreamActualDataRate = channelStatus.data.ActualDataRate;

	// Update G997LineStatus values for downstream
	memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
	lineStatus.nDirection = DSL_DOWNSTREAM;
	lineStatus.nDeltDataType = gDeltDataType;
	ioctl(fd, DSL_FIO_G997_LINE_STATUS_GET, &lineStatus);
	// SNRds
	DownStreamSNR = lineStatus.data.SNR;

	// LATNds
	DownStreamLATN = lineStatus.data.LATN;

	// SATNds
	DownStreamSATN = lineStatus.data.SATN;

	// ACTATPds
	DownStreamACTATP = lineStatus.data.ACTATP;

	// ATTNDRds
	DownStreamATTNDR = lineStatus.data.ATTNDR;

	// Update G997LineStatus values for upstream
	memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
	lineStatus.nDirection = DSL_UPSTREAM;
	lineStatus.nDeltDataType = gDeltDataType;
	ioctl(fd, DSL_FIO_G997_LINE_STATUS_GET, &lineStatus);
	// SNRus
	UpStreamSNR = lineStatus.data.SNR;

	// LATNus
	UpStreamLATN = lineStatus.data.LATN;

	// SATNus
	UpStreamSATN = lineStatus.data.SATN;

	// ACTATPus
	UpStreamACTATP = lineStatus.data.ACTATP;

	// ATTNDRus
	UpStreamATTNDR = lineStatus.data.ATTNDR;

	// DownStream (FarEnd) Interleaver Depth
	memset(&g997FramingParamStatusGet, 0x00,
	       sizeof(DSL_G997_FramingParameterStatus_t));
	g997FramingParamStatusGet.nDirection = DSL_DOWNSTREAM;
	ioctl(fd, DSL_FIO_G997_FRAMING_PARAMETER_STATUS_GET,
		    &g997FramingParamStatusGet);
	DownStreamINTLVDEPTH = g997FramingParamStatusGet.data.nINTLVDEPTH;

	// RS Correction 
	FarEndRSCorrectionFailure = g997FramingParamStatusGet.data.nNFEC;

	// UpStream (NearEnd) Interleaver Depth
	memset(&g997FramingParamStatusGet, 0x00,
	       sizeof(DSL_G997_FramingParameterStatus_t));
	g997FramingParamStatusGet.nDirection = DSL_UPSTREAM;
	ioctl(fd, DSL_FIO_G997_FRAMING_PARAMETER_STATUS_GET,
		    &g997FramingParamStatusGet);
	UpStreamINTLVDEPTH = g997FramingParamStatusGet.data.nINTLVDEPTH;

	// RS Correction 
	NearEndRSCorrectionFailure = g997FramingParamStatusGet.data.nNFEC;

	/* NearEnd G997LineFailures Status */
	// LOS
	memset(&lineFailuresStatusGet, 0x00, sizeof(DSL_G997_LineFailures_t));
	lineFailuresStatusGet.nDirection = DSL_NEAR_END;
	
	    ioctl(fd, DSL_FIO_G997_LINE_FAILURES_STATUS_GET,
		  &lineFailuresStatusGet);
	NearEndLOSFailure = lineFailuresStatusGet.data.nLineFailures;

	// LOF
	NearEndLOFFailure = lineFailuresStatusGet.data.nLineFailures;

	// LPR
	FarEndLPRFailure = lineFailuresStatusGet.data.nLineFailures;

	/* FarEnd G997LineFailures Status */
	// LOS
	memset(&lineFailuresStatusGet, 0x00, sizeof(DSL_G997_LineFailures_t));
	lineFailuresStatusGet.nDirection = DSL_FAR_END;
	
	    ioctl(fd, DSL_FIO_G997_LINE_FAILURES_STATUS_GET,
		  &lineFailuresStatusGet);
	FarEndLOSFailure = lineFailuresStatusGet.data.nLineFailures;

	// LOF
	FarEndLOFFailure = lineFailuresStatusGet.data.nLineFailures;

	// LPR
	FarEndLPRFailure = lineFailuresStatusGet.data.nLineFailures;

	/* NearEnd G997DathPathFailures Status */
	// NCD
	memset(&dataPathFailuresStatusGet, 0x00,
	       sizeof(DSL_G997_DataPathFailures_t));
	dataPathFailuresStatusGet.nDirection = DSL_NEAR_END;
	ioctl(fd, DSL_FIO_G997_DATA_PATH_FAILURES_STATUS_GET,
		    &dataPathFailuresStatusGet);
	NearEndNCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

	// LCD
	NearEndLCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

	/* FarEnd G997DathPathFailures Status */
	// NCD
	memset(&dataPathFailuresStatusGet, 0x00,
	       sizeof(DSL_G997_DataPathFailures_t));
	dataPathFailuresStatusGet.nDirection = DSL_FAR_END;
	ioctl(fd, DSL_FIO_G997_DATA_PATH_FAILURES_STATUS_GET,
		    &dataPathFailuresStatusGet);
	FarEndNCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

	// LCD
	FarEndLCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

	/* NearEnd PMChannelCounters */
	// CRC --Eros change to showtime counter only
	memset(&pmChannelCounters, 0x00, sizeof(DSL_PM_ChannelCounters_t));
	pmChannelCounters.nDirection = DSL_NEAR_END;
	ioctl(fd, DSL_FIO_PM_CHANNEL_COUNTERS_SHOWTIME_GET,
		  &pmChannelCounters);
	NearEndCRCFailure = pmChannelCounters.data.nCodeViolations;

	// FECS  ---- Eros change to showtime get only 
	NearEndFECS = pmChannelCounters.data.nFEC;

	/* FarEnd PMChannelCounters */
	//CRC
	memset(&pmChannelCounters, 0x00, sizeof(DSL_PM_ChannelCounters_t));
	pmChannelCounters.nDirection = DSL_FAR_END;

	    ioctl(fd, DSL_FIO_PM_CHANNEL_COUNTERS_SHOWTIME_GET,
		  &pmChannelCounters);
	FarEndCRCFailure = pmChannelCounters.data.nCodeViolations;

	// FECS
	FarEndFECS = pmChannelCounters.data.nFEC;

	/* NearEnd PMLineSecCounters */
	// Errored Second
	memset(&pmLineSecCountersTotal, 0x00,
	       sizeof(DSL_PM_LineSecCountersTotal_t));
	pmLineSecCountersTotal.nDirection = DSL_NEAR_END;
	ioctl(fd, DSL_FIO_PM_LINE_SEC_COUNTERS_TOTAL_GET,
		    &pmLineSecCountersTotal);
	NearEndES = pmLineSecCountersTotal.data.nES;;

	// Serverely Errored Second
	NearEndSES = pmLineSecCountersTotal.data.nSES;;

	// Loss of Signal Seconds 
	NearEndLOSS = pmLineSecCountersTotal.data.nLOSS;;

	// Unavailable Second
	NearEndUAS = pmLineSecCountersTotal.data.nUAS;;

	/* FarEnd PMLineSecCounters */
	// Errored Second
	memset(&pmLineSecCountersTotal, 0x00,
	       sizeof(DSL_PM_LineSecCountersTotal_t));
	pmLineSecCountersTotal.nDirection = DSL_FAR_END;
	ioctl(fd, DSL_FIO_PM_LINE_SEC_COUNTERS_TOTAL_GET,
		    &pmLineSecCountersTotal);
	FarEndES = pmLineSecCountersTotal.data.nES;;

	// Serverely Errored Second
	FarEndSES = pmLineSecCountersTotal.data.nSES;;

	// Loss of Signal Seconds 
	FarEndLOSS = pmLineSecCountersTotal.data.nLOSS;;

	// Unavailable Second
	FarEndUAS = pmLineSecCountersTotal.data.nUAS;;

	/* SHOWTIME PMDataPathCounters */
	// HEC Error  ---- Eros change to showtime get only 
	memset(&pmDataPathCounters, 0x00, sizeof(DSL_PM_DataPathCounters_t));
	pmDataPathCounters.nDirection = DSL_NEAR_END;
	ioctl(fd, DSL_FIO_PM_DATA_PATH_COUNTERS_SHOWTIME_GET,
		    &pmDataPathCounters);
	NearEndHEC = pmDataPathCounters.data.nHEC;;

	memset(&pmDataPathCounters, 0x00, sizeof(DSL_PM_DataPathCounters_t));
	pmDataPathCounters.nDirection = DSL_FAR_END;
	ioctl(fd, DSL_FIO_PM_DATA_PATH_COUNTERS_SHOWTIME_GET,
		    &pmDataPathCounters);
	FarEndHEC = pmDataPathCounters.data.nHEC;;

	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log%d",
		lineState.data.nLineState, dsl_line);
#else
	sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log",
		lineState.data.nLineState);
#endif
	system(buf);
	return DSL_SUCCESS;

}

// ATU-C System Vendor Information
int ifx_get_VendorID(int eid, httpd_t wp, int argc, char_t ** argv)
{
	DSL_char_t buf[256];
	DSL_CPE_ArraySPrintF(buf, FarEndSystemVendorID,
			     sizeof(FarEndSystemVendorID),
			     sizeof(FarEndSystemVendorID[0]),
			     DSL_ARRAY_FORMAT_HEX);
	ifx_httpdWrite(wp, T("%s"), buf);
	return 0;
}

int ifx_get_VendorVersionNumber(int eid, httpd_t wp, int argc, char_t ** argv)
{
	DSL_char_t buf[256];
	DSL_CPE_ArraySPrintF(buf, FarEndVersionNumber,
			     sizeof(FarEndVersionNumber),
			     sizeof(FarEndVersionNumber[0]),
			     DSL_ARRAY_FORMAT_HEX);
	ifx_httpdWrite(wp, T("%s"), buf);
	return 0;
}

int ifx_get_VendorSerialNumber(int eid, httpd_t wp, int argc, char_t ** argv)
{
	DSL_char_t buf[256];
	DSL_CPE_ArraySPrintF(buf, FarEndSerialNumber,
			     sizeof(FarEndSerialNumber),
			     sizeof(FarEndSerialNumber[0]),
			     DSL_ARRAY_FORMAT_HEX);
	ifx_httpdWrite(wp, T("%s"), buf);
	return 0;
}

// Status
int ifx_get_ModemStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char buf[100];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	char_t *dsl_line_str = NULL;
    if (ifx_httpd_parse_args(argc, argv, T("%s"), &dsl_line_str) < 1) { 
		IFX_DBG(" Error !! Insufficient args passed in [%s]!!\n", __FUNCTION__);
    } 
	else {    
		dsl_line = atoi(dsl_line_str);
		sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log%d",
			lineState.data.nLineState, dsl_line);
	}
#else
	sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log",
		lineState.data.nLineState);
#endif
	system(buf);

	switch (lineState.data.nLineState) {
	case DSL_LINESTATE_NOT_INITIALIZED:
		ifx_httpdWrite(wp, T("NOT INITIALIZED"));
		break;
	case DSL_LINESTATE_EXCEPTION:
		ifx_httpdWrite(wp, T("EXCEPTION"));
		break;
	case DSL_LINESTATE_DISABLED:
		ifx_httpdWrite(wp, T("DISABLED"));
		break; 
	case DSL_LINESTATE_IDLE_REQUEST:
		ifx_httpdWrite(wp, T("IDLE_REQUEST"));
		break;
	case DSL_LINESTATE_IDLE:
		ifx_httpdWrite(wp, T("IDLE"));
		break;
	case DSL_LINESTATE_SILENT_REQUEST:
		ifx_httpdWrite(wp, T("SILENT_REQUEST"));
		break;
	case DSL_LINESTATE_SILENT:
		ifx_httpdWrite(wp, T("SILENT"));
		break;
	case DSL_LINESTATE_HANDSHAKE:
		ifx_httpdWrite(wp, T("HANDSHAKE"));
		break;
	case DSL_LINESTATE_FULL_INIT:
		ifx_httpdWrite(wp, T("FULL_INIT"));
		break;
	case DSL_LINESTATE_DISCOVERY:
		ifx_httpdWrite(wp, T("DISCOVERY"));
		break;
	case DSL_LINESTATE_TRAINING:
		ifx_httpdWrite(wp, T("TRAINING"));
		break;
	case DSL_LINESTATE_ANALYSIS:
		ifx_httpdWrite(wp, T("ANALYSIS"));
		break;
	case DSL_LINESTATE_EXCHANGE:
		ifx_httpdWrite(wp, T("EXCHANGE"));
		break;
	case DSL_LINESTATE_SHOWTIME_NO_SYNC:
		ifx_httpdWrite(wp, T("SHOWTIME, NO SYNC"));
		break;
	case DSL_LINESTATE_SHOWTIME_TC_SYNC:
		ifx_httpdWrite(wp, T("SHOWTIME, SYNC"));
		break;
	case DSL_LINESTATE_FASTRETRAIN:
		ifx_httpdWrite(wp, T("FASTRETRAIN"));
		break;
	case DSL_LINESTATE_LOWPOWER_L2:
		ifx_httpdWrite(wp, T("LOWPOWER_L2"));
		break;
	case DSL_LINESTATE_LOOPDIAGNOSTIC_ACTIVE:
		ifx_httpdWrite(wp, T("DIAGNOSTIC ACTIVE"));
		break;
	case DSL_LINESTATE_LOOPDIAGNOSTIC_DATA_EXCHANGE:
		ifx_httpdWrite(wp, T("DIAGNOSTIC_DATA_EXCHANGE"));
		break;
	case DSL_LINESTATE_LOOPDIAGNOSTIC_DATA_REQUEST:
		ifx_httpdWrite(wp, T("DIAGNOSTIC_DATA_REQUEST"));
		break;
	case DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE:
		ifx_httpdWrite(wp, T("DIAGNOSTIC COMPLETE"));
		break;
	case DSL_LINESTATE_RESYNC:
		ifx_httpdWrite(wp, T("RESYNC"));
		break;
	case DSL_LINESTATE_TEST:
		ifx_httpdWrite(wp, T("TEST"));
		break;
	case DSL_LINESTATE_TEST_LOOP:
		ifx_httpdWrite(wp, T("TEST_LOOP"));
		break;
	case DSL_LINESTATE_TEST_REVERB:
		ifx_httpdWrite(wp, T("TEST_REVERB"));
		break;
	case DSL_LINESTATE_TEST_MEDLEY:
		ifx_httpdWrite(wp, T("TEST_MEDLEY"));
		break;
	case DSL_LINESTATE_TEST_SHOWTIME_LOCK:
		ifx_httpdWrite(wp, T("TEST_SHOWTIME_LOCK"));
		break;
	case DSL_LINESTATE_TEST_QUIET:
		ifx_httpdWrite(wp, T("TEST_QUIET"));
		break;
	case DSL_LINESTATE_LOWPOWER_L3:
		ifx_httpdWrite(wp, T("LOWPOWER_L3"));
		break;
	case DSL_LINESTATE_UNKNOWN:
		ifx_httpdWrite(wp, T("UNKNOWN"));
		break;
	case DSL_LINESTATE_NOT_UPDATED:
		ifx_httpdWrite(wp, T("NOT_UPDATED"));
		break;
	case DSL_LINESTATE_SHORT_INIT_ENTRY:
		ifx_httpdWrite(wp, T("NOT_UPDATED"));
		break;
	default:
		break;
	}			// switch     
	return 0;
}

int ifx_get_ModeSelected(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_PARAMETER_KEY_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	int32 dw_dsl_mode = -1;
	char_t sProfile_Value[MAX_PARAMETER_KEY_LEN];
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	int32 retVal = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT;
	dw_config_info_t dw_cfg_info = { 0 };

	flags = IFX_F_GET_ANY;
	retVal = dw_mapi_cfg_get(&dw_cfg_info, flags);
	if (retVal != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("Dual WAN Config Get in Function [%s]!!\n", __FUNCTION__);
#endif
		return IFX_FAILURE;
	}
	if ((dw_cfg_info.pri_wan_cfg.phy_mode == 0) || (dw_cfg_info.sec_wan_cfg.phy_mode == 0)) {
		dw_dsl_mode = 0;
	}
	else if ((dw_cfg_info.pri_wan_cfg.phy_mode == 3) || ( dw_cfg_info.sec_wan_cfg.phy_mode == 3)) {
		dw_dsl_mode = 3;
	}
#endif

	/*check for wanphy_phymode(ADSL=0/VDSL=3) */
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_phymode", IFX_F_DEFAULT,
	     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In function [%s] : Error--> Trying access to access [%s] !!",
		     __FUNCTION__, TAG_WAN_PHY_CFG);
#endif
		return IFX_FAILURE;
	}

	memset(sProfile_Value, 0x0, MAX_PARAMETER_KEY_LEN);
#ifdef PLATFORM_VR9
	if ((atoi(sValue) == 3) || (dw_dsl_mode == 3)) {
		if (xtuBandPlanStatus.data.nProfile != -1) {

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_8A)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 8A", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_8B)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 8B", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_8C)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 8C", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_8D)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 8D", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_12A)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 12A", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_12B)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 12B", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_17A)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 17A", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_30A)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 30A", MAX_PARAMETER_KEY_LEN);

			if (xtuBandPlanStatus.data.nProfile == DSL_PROFILE_17B)
				LTQ_STRNCPY(sProfile_Value, "VDSL, 17B", MAX_PARAMETER_KEY_LEN);

//			return IFX_SUCCESS;
		}
	}
	else
#endif
	if((atoi(sValue) == 0) || (dw_dsl_mode == 0))
	{
		// XTSE[1]
		if (xtuSystemEnabling.data.XTSE[0] & 0x01) {
			LTQ_STRNCPY(sProfile_Value, "ANSI T1.413", MAX_PARAMETER_KEY_LEN);
		}

		if (xtuSystemEnabling.data.XTSE[0] & 0x02) {
			LTQ_STRNCPY(sProfile_Value, "Annex C", MAX_PARAMETER_KEY_LEN);
		}

		if (xtuSystemEnabling.data.XTSE[0] & 0x04) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt , Annex A", MAX_PARAMETER_KEY_LEN);	//G992_1_A
		}

		if (xtuSystemEnabling.data.XTSE[0] & 0x10) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt , Annex B", MAX_PARAMETER_KEY_LEN);	//G992_1_B
		}
		// XTSE[2]
		if (xtuSystemEnabling.data.XTSE[1] & 0x01) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.lite , Annex A", MAX_PARAMETER_KEY_LEN);	// G992_2_A
		}
		// XTSE[3]
		if (xtuSystemEnabling.data.XTSE[2] & 0x04) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt.bis , Annex A", MAX_PARAMETER_KEY_LEN);	// G992_3_A
		}

		if (xtuSystemEnabling.data.XTSE[2] & 0x10) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt.bis , Annex B", MAX_PARAMETER_KEY_LEN);	//G992_3_B
		}
		// XTSE[4]
		if (xtuSystemEnabling.data.XTSE[3] & 0x01) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt.bis , Annex A ", MAX_PARAMETER_KEY_LEN);	//G992_4_A
		}

		if (xtuSystemEnabling.data.XTSE[3] & 0x10) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt.bis , Annex I", MAX_PARAMETER_KEY_LEN);	//G992_3_I
		}

		if (xtuSystemEnabling.data.XTSE[3] & 0x40) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_G.dmt.bis , Annex J", MAX_PARAMETER_KEY_LEN);	//G992_3_J
		}
		// XTSE[5]
		if (xtuSystemEnabling.data.XTSE[4] & 0x04) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_re-adsl , Annex L", MAX_PARAMETER_KEY_LEN);	//G992_3_L
		}

		if (xtuSystemEnabling.data.XTSE[4] & 0x08) {
			LTQ_STRNCPY(sProfile_Value, "ADSL_re-adsl , Annex L", MAX_PARAMETER_KEY_LEN);	//G992_3_L
		}

		if (xtuSystemEnabling.data.XTSE[4] & 0x40) {
			LTQ_STRNCPY(sProfile_Value, "ADSL2 , Annex M", MAX_PARAMETER_KEY_LEN);	//G992_3_M
		}
		// XTSE[6]
		if (xtuSystemEnabling.data.XTSE[5] & 0x01) {
			LTQ_STRNCPY(sProfile_Value, "ADSL2+, Annex A", MAX_PARAMETER_KEY_LEN);	//G992_5_A
		}

		if (xtuSystemEnabling.data.XTSE[5] & 0x04) {
			LTQ_STRNCPY(sProfile_Value, "ADSL2+ , Annex B", MAX_PARAMETER_KEY_LEN);	//G992_5_B
		}

		if (xtuSystemEnabling.data.XTSE[5] & 0x40) {
			LTQ_STRNCPY(sProfile_Value, "ADSL2+ , Annex I", MAX_PARAMETER_KEY_LEN);	//G992_5_I
		}
		// XTSE[7]
		if (xtuSystemEnabling.data.XTSE[6] & 0x01) {
			LTQ_STRNCPY(sProfile_Value, "ADSL2+ , Annex J", MAX_PARAMETER_KEY_LEN);	// G992_5_J
		}

		if (xtuSystemEnabling.data.XTSE[6] & 0x04) {
			LTQ_STRNCPY(sProfile_Value, "ADSL2+ , Annex M", MAX_PARAMETER_KEY_LEN);	//G992_5_M
		}
#if 0
		// XTSE[8]
		if (xtuSystemEnabling.data.XTSE[7] & 0x01) {
			ifx_httpdWrite(wp, T("VDSL , 8a"));	//G993_2_8A
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x02) {
			ifx_httpdWrite(wp, T("VDSL , 8b"));	//G993_2_8B
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x04) {
			ifx_httpdWrite(wp, T("VDSL , 8c"));	//G993_2_8C
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x08) {
			ifx_httpdWrite(wp, T("VDSL , 8d"));	//G993_2_8D
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x10) {
			ifx_httpdWrite(wp, T("VDSL , 12a"));	//G993_2_12A
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x20) {
			ifx_httpdWrite(wp, T("VDSL , 12b"));	//G993_2_12B
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x40) {
			ifx_httpdWrite(wp, T("VDSL , 17a"));	//G993_2_17A
		}

		if (xtuSystemEnabling.data.XTSE[7] & 0x80) {
			ifx_httpdWrite(wp, T("VDSL , 30a"));	//G993_2_30A
		}
#endif
	}
	else {
		LTQ_STRNCPY(sProfile_Value, "UNDEFINED", MAX_PARAMETER_KEY_LEN);
	}

	if (!gstrcmp(sProfile_Value, ""))
		LTQ_STRNCPY(sProfile_Value, "NOT AVAILABLE", MAX_PARAMETER_KEY_LEN);

	ifx_httpdWrite(wp, T("%s"), sProfile_Value);

	return IFX_SUCCESS;
}

 /* // XTSE[1]
    if (xtuSystemEnabling.data.XTSE[0] & 0x01)
    {
    ifx_httpdWrite(wp, T("ANSI T1.413"));
    }

    if (xtuSystemEnabling.data.XTSE[0] & 0x02)
    {
    ifx_httpdWrite(wp, T("Annex C"));
    }

    if (xtuSystemEnabling.data.XTSE[0] & 0x04)
    {
    ifx_httpdWrite(wp, T("G992_1_A"));
    }

    if (xtuSystemEnabling.data.XTSE[0] & 0x10)
    {
    ifx_httpdWrite(wp, T("G992_1_B"));
    }
    // XTSE[2]
    if (xtuSystemEnabling.data.XTSE[1] & 0x01)
    {
    ifx_httpdWrite(wp, T("G992_2_A"));
    }
    // XTSE[3]
    if (xtuSystemEnabling.data.XTSE[2] & 0x04)
    {
    ifx_httpdWrite(wp, T("G992_3_A"));
    }

    if (xtuSystemEnabling.data.XTSE[2] & 0x10)
    {
    ifx_httpdWrite(wp, T("G992_3_B"));
    }
    // XTSE[4]
    if (xtuSystemEnabling.data.XTSE[3] & 0x01)
    {
    ifx_httpdWrite(wp, T("G992_4_A"));
    }

    if (xtuSystemEnabling.data.XTSE[3] & 0x10)
    {
    ifx_httpdWrite(wp, T("G992_3_I"));
    }

    if (xtuSystemEnabling.data.XTSE[3] & 0x40)
    {
    ifx_httpdWrite(wp, T("G992_3_J"));
    }
    // XTSE[5]
    if (xtuSystemEnabling.data.XTSE[4] & 0x04)
    {
    ifx_httpdWrite(wp, T("G992_3_L"));
    }

    if (xtuSystemEnabling.data.XTSE[4] & 0x08)
    {
    ifx_httpdWrite(wp, T("G992_3_L"));
    }

    if (xtuSystemEnabling.data.XTSE[4] & 0x40)
    {
    ifx_httpdWrite(wp, T("G992_3_M"));
    }
    // XTSE[6]
    if (xtuSystemEnabling.data.XTSE[5] & 0x01)
    {
    ifx_httpdWrite(wp, T("G992_5_A"));
    }

    if (xtuSystemEnabling.data.XTSE[5] & 0x04)
    {
    ifx_httpdWrite(wp, T("G992_5_B"));
    }

    if (xtuSystemEnabling.data.XTSE[5] & 0x40)
    {
    ifx_httpdWrite(wp, T("G992_5_I"));
    }
    // XTSE[7]
    if (xtuSystemEnabling.data.XTSE[6] & 0x01)
    {
    ifx_httpdWrite(wp, T("G992_5_J"));
    }

    if (xtuSystemEnabling.data.XTSE[6] & 0x04)
    {
    ifx_httpdWrite(wp, T("G992_5_M"));
    }
    // XTSE[8]
    if (xtuSystemEnabling.data.XTSE[7] & 0x01)
    {
    ifx_httpdWrite(wp, T("G993_2_A"));
    }

    if (xtuSystemEnabling.data.XTSE[7] & 0x02)
    {
    ifx_httpdWrite(wp, T("G993_2_B"));
    }

    if (xtuSystemEnabling.data.XTSE[7] & 0x04)
    {
    ifx_httpdWrite(wp, T("G993_2_C"));
    }

    return 0;
    }
  */
int ifx_get_PowerMode(int eid, httpd_t wp, int argc, char_t ** argv)
{
	switch (PowerManagementStatus) {
	case DSL_G997_PMS_NA:
		ifx_httpdWrite(wp, T("DSL_G997_PMS_NA"));
		break;
	case DSL_G997_PMS_L0:
		ifx_httpdWrite(wp, T("DSL_G997_PMS_L0"));
		break;
	case DSL_G997_PMS_L1:
		ifx_httpdWrite(wp, T("DSL_G997_PMS_L1"));
		break;
	case DSL_G997_PMS_L2:
		ifx_httpdWrite(wp, T("DSL_G997_PMS_L2"));
		break;
	case DSL_G997_PMS_L3:
		ifx_httpdWrite(wp, T("DSL_G997_PMS_L3"));
		break;
	}
	return 0;
}

//int ifx_get_DMTFramingMode(int eid, httpd_t wp, int argc, char_t **argv)
//{
//}

int ifx_get_TrellisCodedMod(int eid, httpd_t wp, int argc, char_t ** argv)
{
	switch (lineFeatureConfig.data.bTrellisEnable) {
	case DSL_TRUE:
		ifx_httpdWrite(wp, T("Enable"));
		break;
	case DSL_FALSE:
		ifx_httpdWrite(wp, T("Disable"));
		break;
	}
	return 0;
}

int ifx_get_LatencyType(int eid, httpd_t wp, int argc, char_t ** argv)
{
	if (ActualInterleaveDelay > 100) {
		ifx_httpdWrite(wp, T("Interleave"));
	} else {
		ifx_httpdWrite(wp, T("Fast"));
	}
	return 0;
}

// Rate
int ifx_get_DownDataRate(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u kbps"), DownStreamActualDataRate / 1000);
	return 0;
}

int ifx_get_UpDataRate(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u kbps"), UpStreamActualDataRate / 1000);
	return 0;
}

int ifx_get_ATTNDRds(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u kbps"), DownStreamATTNDR / 1000);
	return 0;
}

int ifx_get_ATTNDRus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	/* Assuming Max ATTNDR as 48Mbps */
	if ((UpStreamATTNDR / 1000) <= 48)
		UpStreamATTNDR = UpStreamATTNDR * 1000;
	ifx_httpdWrite(wp, T("%u kbps"), UpStreamATTNDR / 1000);
	return 0;
}

// Information
int ifx_get_InterleaverDds(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), DownStreamINTLVDEPTH);
	return 0;
}

int ifx_get_InterleaverDus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), UpStreamINTLVDEPTH);
	return 0;
}

char tmpstr[6];
int ifx_get_LATNds(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)DownStreamLATN / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_LATNus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)UpStreamLATN / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_SATNds(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)DownStreamSATN / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_SATNus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)UpStreamSATN / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_SNRMds(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)DownStreamSNR / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_SNRMus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)UpStreamSNR / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_ACATPds(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)DownStreamACTATP / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

int ifx_get_ACATPus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	sprintf(tmpstr, "%.1f", (float)UpStreamACTATP / 10);
	ifx_httpdWrite(wp, T("%s dB"), tmpstr);
	return 0;
}

// Performance
int ifx_get_Superframe(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("Not available"));
	return 0;
}

int ifx_get_nLOSFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndLOSFailure);
	return 0;
}

int ifx_get_fLOSFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndLOSFailure);
	return 0;
}

int ifx_get_nLOFFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndLOFFailure);
	return 0;
}

int ifx_get_fLOFFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndLOFFailure);
	return 0;
}

int ifx_get_nLPRFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndLPRFailure);
	return 0;
}

int ifx_get_fLPRFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndLPRFailure);
	return 0;
}

//int ifx_get_nRFIFail(int eid, httpd_t wp, int argc, char_t **argv)
//{
//}

//int ifx_get_fRFIFail(int eid, httpd_t wp, int argc, char_t **argv)
//{
//}

int ifx_get_nNCDFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndNCDFailure);
	return 0;
}

int ifx_get_fNCDFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndNCDFailure);
	return 0;
}

int ifx_get_nLCDFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndLCDFailure);
	return 0;
}

int ifx_get_fLCDFail(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndLCDFailure);
	return 0;
}

int ifx_get_nCRC(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndCRCFailure);
	return 0;
}

int ifx_get_fCRC(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndCRCFailure);
	return 0;
}

int ifx_get_nRsCorrection(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndRSCorrectionFailure);
	//ifx_httpdWrite(wp, T("n/a"));
	return 0;
}

int ifx_get_fRsCorrection(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndRSCorrectionFailure);
	//ifx_httpdWrite(wp, T("n/a"));
	return 0;
}

int ifx_get_nFECS_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
//  ifx_httpdWrite(wp, T("%u"), FarEndFECS);  //Eros : this is bug which display nFEC=fFEC 2008.12.5
	ifx_httpdWrite(wp, T("%u"), NearEndFECS);
	return 0;
}

int ifx_get_fFECS_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndFECS);
	return 0;
}

int ifx_get_nES_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndES);
	return 0;
}

int ifx_get_fES_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndES);
	return 0;
}

int ifx_get_nSES_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndSES);
	return 0;
}

int ifx_get_fSES_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndSES);
	return 0;
}

int ifx_get_nLOSS_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndLOSS);
	return 0;
}

int ifx_get_fLOSS_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndLOSS);
	return 0;
}

int ifx_get_nUAS_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndUAS);
	return 0;
}

int ifx_get_fUAS_L(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndUAS);
	return 0;
}

int ifx_get_nHECError(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), NearEndHEC);
	return 0;
}

int ifx_get_fHECError(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%u"), FarEndHEC);
	return 0;
}

int ifx_get_isBondingSupported(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	ifx_httpdWrite(wp, T("%u"), 1);
#else
	ifx_httpdWrite(wp, T("%u"), 0);
#endif
	return 0;
}


#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT

int ifx_get_bonding_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[8] = {0}; 
	if (ifx_GetCfgData(FILE_SYSTEM_STATUS, "xDSL_Bonding", "Bonding_status", sValue) == 1) {
		ifx_httpdWrite(wp, T("%s"), sValue);
#if 0
		if (atoi(sValue) == 0) 
			ifx_httpdWrite(wp, T("%s"), "INACTIVE");
		else
			ifx_httpdWrite(wp, T("%s"), "ACTIVE");
	}
	else {
		ifx_httpdWrite(wp, T("%s"), "UNAVAILABLE");
		return -1;
#endif
	}
	return 0;
}

int ifx_get_bonded_ds_rate(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int fd = 0;
	int dsl_line = 0, max_lines = 2;
	char dev_name[64] = {0};
	int ret = 0;

	DSL_uint32_t DSActualDataRate[2];
	DSL_uint32_t BondedDSDataRate;

	BondedDSDataRate = 0;

	for (dsl_line = 0; dsl_line < max_lines; dsl_line++) {
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		ifx_httpdWrite(wp, T("cannot open device %s"),
			       dev_name);
	}

	// Data Rate
	memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
	channelStatus.nDirection = DSL_DOWNSTREAM;
	ret = ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
	DSActualDataRate[dsl_line] = channelStatus.data.ActualDataRate;

	BondedDSDataRate += DSActualDataRate[dsl_line];
	// close device
	close(fd);
	}
	ifx_httpdWrite(wp, T("%u kbps"), BondedDSDataRate / 1000);

	return 0;
}
int ifx_get_bonded_us_rate(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int fd = 0;
	int dsl_line = 0, max_lines = 2;
	char dev_name[64] = {0};
	int ret = 0;

	DSL_uint32_t USActualDataRate[2];
	DSL_uint32_t BondedUSDataRate;

	BondedUSDataRate = 0;
	for (dsl_line = 0; dsl_line < max_lines; dsl_line++) {
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		ifx_httpdWrite(wp, T("cannot open device %s"),
			       dev_name);
	}

	// Data Rate
	memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
	channelStatus.nDirection = DSL_UPSTREAM;
	ret = ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
	USActualDataRate[dsl_line] = channelStatus.data.ActualDataRate;

	BondedUSDataRate += USActualDataRate[dsl_line];
	// close device
	close(fd);
	}

	ifx_httpdWrite(wp, T("%u kbps"), BondedUSDataRate / 1000);
	return 0;
}
#endif

#endif
