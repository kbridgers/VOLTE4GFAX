#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#include "ifx_common.h"

extern int32 compute_wan_mode(WAN_PHY_MODE phy, WAN_TC tc);
extern int ifx_set_bridge_settings(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_static(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_dhcp(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_pppoa(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_pppoe(httpd_t wp, char_t * path, char_t * query);
extern int ifx_get_wanip(int eid, httpd_t wp, int argc, char_t ** argv);
extern int ifx_get_wan_ppp(int eid, httpd_t wp, int argc, char_t ** argv);
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);


int ifx_wan_common_cgi(httpd_t wp,char_t * path, char_t * query);
int ifx_set_wan(httpd_t wp, char_t * path, char_t * query);
extern int32 ltq_mapi_get_reserved_vlan_config(RESERVED_VLAN_CFG  *vlan_res);
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
extern int ltq_mapi_get_autodetect_config(auto_detect_cfg_t *config);
extern int ltq_mapi_set_autodetect_config(auto_detect_cfg_t *config, uint32 flags);
extern int ltq_mapi_update_autodetect_pool(char *field_name, char *value, uint32 operation);
int ltq_cgi_set_autodetect_config(httpd_t wp, char *layer);
#endif

#if 0
extern int mapi_set_vlan_ch_entry(int32 operation, vlan_ch_cfg_t * entry,
				  uint32 flags);
extern int32 mapi_get_all_vlan_ch_entries(int32 * num_entries,
					  vlan_ch_cfg_t ** vlan_chcfg,
					  uint32 flags);
extern int32 ifx_get_all_wan_eth_config(int32 * num_entries, uint32 mode,
					WAN_CONN_CFG ** pp_wancfg,
					uint32 flags);
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT) ||  defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
int32 ifx_delete_all_free_channel(char_t * Wan_Mode);
#endif
#ifdef CONFIG_FEATURE_NAPT
extern int32 ifx_get_wan_port(char_t * pWAN_VCC);
extern int32 ifx_mapi_set_all_virtual_server_delete();
#endif

#define IFX_HAVE_WAN_STATIC_IP

int ifx_get_wan_dns(int eid, httpd_t wp, int argc, char_t ** argv);	//wan_dns.asp; wizard_dns.asp
void ifx_set_wan_dns(httpd_t wp, char_t * path, char_t * query);	//wan_dns.asp; wizard_dns.asp
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
int32 ltq_mapi_get_cell_wan(LTQ_MAPI_Cell_WAN * cell_wan, uint32 index,
			    uint32 flags);
#endif
int32 ifx_set_wan_phy_cfg(WAN_PHY_CFG * pstWanPhy);
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
extern int32 ifx_set_xdsl_phy_cfg(XDSL_PHY_CFG * pstXdslPhy);
#endif
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);
int32 ifx_get_wanip_conn_type(IP_TYPE *, int32);
#ifdef CONFIG_FEATURE_DDNS
void ifx_set_ddns_config(httpd_t wp, char_t * path, char_t * query);	//ddns_config.asp
int ifx_get_ddns_cfg(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				//CONFIG_FEATURE_DDNS
extern int ifx_get_wan_mode_check(int eid, httpd_t wp, int argc,
				  char_t ** arg_v);
extern int32 ifx_read_dhcp_lease_file(const char *file, int *clients);
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
extern int32 dw_check_ip_url(char8 *IpUrlStr, char8 *retStr);
extern int32 default_wan_cfg_get_for_wan_phymode(def_wan_cfg_t * def_wan_cfg, WAN_PHY_CFG * wan_phy);
#endif
#endif

void get_atm_proto_name_by_id(char8 name[MAX_FILELINE_LEN], int32 proto);
extern int32 ifx_cgi_set_wan_config(int32 operation,
				    WAN_CONN_CFG * wan_conn_cfg, uint32 flags);
int ifx_create_wan_main_page(int eid, httpd_t wp, int argc, char_t ** argv);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern void websNextPage(httpd_t wp);
extern char *status_str;

extern int reboot_status;
char *atm_err =
    "<span class=\"textTitle\">Cannot modify ADSL WAN connection parameters.</span><br><p>Please change the operational WAN mode to ADSL <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *eth_err =
    "<span class=\"textTitle\">Cannot modify Ethernet WAN connection parameters.<br></span><p>Please change the operational WAN mode to Ethernet <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *eth0_err =
    "<span class=\"textTitle\">Cannot modify Ethernet WAN connection parameters.<br></span><p>Please change the operational WAN mode to Ethernet WAN on MII-0<a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *eth1_err =
    "<span class=\"textTitle\">Cannot modify Ethernet WAN connection parameters.<br></span><p>Please change the operational WAN mode to Ethernet WAN on MII-1<a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *atm_eth_err =
    "<span class=\"textTitle\">Cannot modify Ethernet to ADSL WAN connection parameters and vice versa.</span>";
char *atm_ptm_err =
    "<span class=\"textTitle\">Cannot modify ATM to PTM WAN connection parameters and vice versa.</span>";
char *eth_chan_err =
    "<span class=\"textTitle\">Duplicate Ethernet WAN channel.<br></span><p>Please chose another VLAN Id and try again.</p>";
#if 0 
manohar : This check is not needed now
char *del_wan_err =
    "<span class=\"textTitle\">Cannot delete WAN connection.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
#endif
char *modify_wan_err =
    "<span class=\"textTitle\">Cannot modify WAN connection.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *add_adsl_wan_err =
    "<span class=\"textTitle\">Cannot add other WAN connections in ADSL mode.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *add_eth_wan_err =
    "<span class=\"textTitle\">Cannot add other WAN connections in Ethernet mode.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";
char *add_vdsl_wan_err =
    "<span class=\"textTitle\">Cannot add ADSL ATM/PTM WAN connections in VDSL mode.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";

char *per_chwan_err =
	"<span class=\"textTitle\">Failed to create WAN connection .Exceeded limit of WAN connections or per channel wan connections limit.<br></span><p>Maximum number of WAN connections allowed is 16. Maximum number of PPPoE connections allowed per channel is 4.Maximum number of IP Routed connections allowed per channel is 1.Maximum number of IP Bridged connections allowed per channel is 1 .Create wan connections as per the specified limits above </p>";
char *del_vs_err = 
	"<span class=\"textTitle\">Cannot delete WAN connection.<br></span><p>Virtual server entries configured on this wan <a href=\"nat_virtualser.asp\">Here</a> Remove or change the wan connection and try again.</p>";

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
char *del_mcast_err = 
	"<span class=\"textTitle\">Cannot delete WAN connection.<br></span><p>Multicast entries configured on this wan <a href=\"igmp_proxy.asp\">Here</a> Remove or change the wan connection and try again.</p>";
#endif

char *del_pf_err = 
	"<span class=\"textTitle\">Cannot delete WAN connection.<br></span><p>Packet filter entries configured on this wan <a href=\"firewall_packetfilter.asp\">Here</a> Remove or change the wan connection and try again.</p>";

char *del_ipsec_err = 
	"<span class=\"textTitle\">Cannot delete WAN connection.<br></span><p>IPsec tunnel entries configured on this wan <a href=\"ipsec_tunnel_config.asp\">Here</a> Remove or change the wan connection and try again.</p>";

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
char *dw_config_err =
    "<span class=\"textTitle\">Dual WAN Configuration Failed.<br></span><p>Bridged WAN is not supported with Dual WAN. Please change the default Connection to Routed WAN and try again.</p>";
#endif
// wan_dns.asp; wizard_dns.asp
int ifx_get_wan_dns(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t sCFG_NAME[MAX_FILELINE_LEN];
	char_t *ip;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';

	if (!gstrncmp(name, "dns1_", 5))
		sprintf(sCFG_NAME, "WAN_DNS1");
	else if (!gstrncmp(name, "dns2_", 5))
		sprintf(sCFG_NAME, "WAN_DNS2");
	else {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	name += 5;
	if (GetObjData(FILE_RC_CONF, TAG_WAN_DNS, sCFG_NAME, sValue, IFX_F_DEFAULT) == IFX_SUCCESS) {
		if (sValue[0] != '0') {
			int idx = name[0] - '1';
			if (idx > 3) {
				ifx_httpdError(wp, 400,
					       T("Insufficient args\n"));
				return -1;
			}
			ip = strtok(sValue, ".");
			for (idx = 0; idx < name[0] - '1'; idx++)
				ip = strtok(NULL, ".");
			if (ip != NULL)
				ifx_httpdWrite(wp, T("%s"), ip);
		}
	}
	return 0;
}

int ifx_get_wan_vlan(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char sValue[MAX_DATA_LEN];
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_WAN_VLAN, "WAN_VLAN_STATUS", sValue) == 0) {
		return 0;
	}
	if (strcmp(sValue, "1") == 0)
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
	return IFX_SUCCESS;
}

void ifx_voip_enabled(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_VOIP
	ifx_httpdWrite(wp, T("1"));
#else
	ifx_httpdWrite(wp, T("0"));
#endif
}

void ifx_get_current_voip_interface(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_VOIP
	char_t sValue[10];
	uint32 outFlag = IFX_F_DEFAULT;
	sValue[0] = '\0';
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_SIP, "SIP_IF", IFX_F_DEFAULT, &outFlag,
	     sValue) != IFX_SUCCESS) {
		ifx_httpdWrite(wp, T("0"));
		return;
	}
	ifx_httpdWrite(wp, T("%s"), sValue);
#else
	ifx_httpdWrite(wp, T("0"));
#endif
}

void ifx_get_current_default_gateway(int eid, httpd_t wp, int argc,
				     char_t ** argv)
{
#if 1
	IFX_ID iid;
	char_t *name;
	char *mode_wan = NULL;
	int32 nWAN_IDX = 0;
	char wanConnName[MAX_CONN_NAME_LEN];
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	memset(&iid, 0x00, sizeof(iid));

	if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		ifx_httpdWrite(wp, T("WANIP0"));
		return;
	}

	if (!gstrcmp(name, T("mode_wan"))) {
		if (strstr(wanConnName, "WANIP") != NULL) {
			mode_wan = "IP";
			ifx_httpdWrite(wp, T("%s"), mode_wan);
		} else {
			mode_wan = "PPP";
			ifx_httpdWrite(wp, T("%s"), mode_wan);
		}
	}

	else {
		ifx_httpdWrite(wp, T("%s"), wanConnName);
	}

#endif				// 1
}

void ifx_get_WanStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[10], sCFG_NAME[MAX_NAME_SIZE];
	char8 wan_confconnName[MAX_NAME_SIZE];
	char_t *name = NULL;
	WAN_TYPE wan_type ;
	int i = 0, wipCnt = 0, wpppCnt = 0, vcc_count = 0 ;
	uint32 outFlag = IFX_F_DEFAULT;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdWrite(wp, T(""));
		return;
	}

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
    	pwb_cfg_t *pwb = NULL;
    	uint32  pwb_num = 0, cnt=0;
#endif
	sValue[0] = '\0';
	sCFG_NAME[0] = '\0';

	if (ifx_get_sec_count(TAG_WAN_IP, &wipCnt) != IFX_SUCCESS) {

	}

	if (ifx_get_sec_count(TAG_WAN_PPP, &wpppCnt) != IFX_SUCCESS) {

	}

	if (!gstrcmp(name, "all")) {
		for (i = 0; i < wipCnt; i++) {
			sprintf(sCFG_NAME, "%s_%d_fEnable", PREFIX_WAN_IP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
			     &outFlag, sValue) != IFX_SUCCESS) {
				//              ifx_httpdWrite(wp, T("WAN_STATUS[%d]=0;\n"), i-1);
				continue;
			}
			ifx_httpdWrite(wp, T("WANIP_STATUS[%d]=\"%s\";\n"), i,
				       sValue);
		}

		for (i = 0; i < wpppCnt; i++) {
			sprintf(sCFG_NAME, "%s_%d_fEnable", PREFIX_WAN_PPP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME,
			     IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				//              ifx_httpdWrite(wp, T("WAN_STATUS[%d]=0;\n"), i-1);
				continue;
			}
			ifx_httpdWrite(wp, T("WANPPP_STATUS[%d]=\"%s\";\n"), i,
				       sValue);
		}
	} else if (!gstrcmp(name, "names")) {
		for (i = 0; i < wipCnt; i++) {
			sprintf(sCFG_NAME, "%s_%d_connName", PREFIX_WAN_IP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
			     &outFlag, sValue) != IFX_SUCCESS) {
				//              ifx_httpdWrite(wp, T("WAN_STATUS[%d]=0;\n"), i-1);
				continue;
			}
			ifx_httpdWrite(wp, T("WANIP_NAME[%d]=\"%s\";\n"), i,
				       sValue);
		}

		for (i = 0; i < wpppCnt; i++) {
			sprintf(sCFG_NAME, "%s_%d_connName", PREFIX_WAN_PPP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME,
			     IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				//              ifx_httpdWrite(wp, T("WAN_STATUS[%d]=0;\n"), i-1);
				continue;
			}
			ifx_httpdWrite(wp, T("WANPPP_NAME[%d]=\"%s\";\n"), i,
				       sValue);
		}

	}else if (!gstrcmp(name, "confnames")) {
		for (i = 0; i < wipCnt; i++) {
			sprintf(sCFG_NAME, "%s_%d_confconnName", PREFIX_WAN_IP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
			     &outFlag, sValue) != IFX_SUCCESS) {
				//              ifx_httpdWrite(wp, T("WAN_STATUS[%d]=0;\n"), i-1);
				continue;
			}
			ifx_httpdWrite(wp, T("WANIP_CONFNAME[%d]=\"%s\";\n"), i,
				       sValue);
		}

		for (i = 0; i < wpppCnt; i++) {
			sprintf(sCFG_NAME, "%s_%d_confconnName", PREFIX_WAN_PPP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME,
			     IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				//              ifx_httpdWrite(wp, T("WAN_STATUS[%d]=0;\n"), i-1);
				continue;
			}
			ifx_httpdWrite(wp, T("WANPPP_CONFNAME[%d]=\"%s\";\n"), i,sValue);
		}

	}else if (!gstrcmp(name, "confname")) {
                if (ifx_GetCfgData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC",sValue) == 1)
		{
			if (strstr(sValue, "IP") != NULL) {
				wan_type = WAN_TYPE_IP;
			} else {
				wan_type = WAN_TYPE_PPP;
			}
		
			if (ifx_get_wan_confconnName_from_connName (sValue ,wan_confconnName ,wan_type) == IFX_SUCCESS)
			{
				ifx_httpdWrite(wp, T("%s"),wan_confconnName);
			}
		}
		
	}else if (!gstrcmp(name, "vcchannel")) {
	
		if (ifx_get_sec_count(TAG_ADSL_VCCHANNEL, &vcc_count) == IFX_SUCCESS){
                        	ifx_httpdWrite(wp, T("var vcc_count=%d;\n"),vcc_count);
			for (i = 0; i < vcc_count ; i++) {
				sprintf(sCFG_NAME, "%s_%d_vcc", PREFIX_ADSL_VCCHANNEL, i);
                        	if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sCFG_NAME,IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
                                	continue;
                        	}
                        	ifx_httpdWrite(wp, T("vcc_value[%d]=\"%s\";\n"), i,sValue);
				sprintf(sCFG_NAME, "%s_%d_l2ifName", PREFIX_ADSL_VCCHANNEL, i);
                        	if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sCFG_NAME,IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
                                	continue;
                        	}
                        	ifx_httpdWrite(wp, T("vcc_l2if[%d]=\"%s\";\n"), i,sValue);
			}
		}
	} else if (!gstrcmp(name, "pwb_status")) {
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)    
		mapi_port_binding_cfg_get_all(&pwb_num, &pwb, IFX_F_DEFAULT);
#endif
		for (i = 0; i < wipCnt; i++) {
 			sprintf(sCFG_NAME, "%s_%d_connName", PREFIX_WAN_IP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
			     &outFlag, sValue) != IFX_SUCCESS) {
				continue;
			}
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)    
			for( cnt=0; cnt<pwb_num; cnt++) {
				if(strncmp(sValue,pwb->wanIf.conName,MAX_CONN_NAME_LEN)==0) {
					ifx_httpdWrite(wp, T("var %s_PWB=\"1\"\n"),sValue);
					break;
				}
			}
			if(cnt==pwb_num)
#endif
				ifx_httpdWrite(wp, T("var %s_PWB=\"0\"\n"),sValue); 
			
		}
    			
		for (i = 0; i < wpppCnt; i++) {
 			sprintf(sCFG_NAME, "%s_%d_connName", PREFIX_WAN_PPP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME, IFX_F_DEFAULT,
			     &outFlag, sValue) != IFX_SUCCESS) {
				continue;
			}
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)    
			for( cnt=0; cnt<pwb_num; cnt++) {
				if(strncmp(sValue,pwb->wanIf.conName,MAX_CONN_NAME_LEN)==0) {
					ifx_httpdWrite(wp, T("var %s_PWB=\"1\"\n"),sValue);
					break;
				}
			}
			if(cnt==pwb_num) 
#endif
				ifx_httpdWrite(wp, T("var %s_PWB=\"0\"\n"),sValue); 
			
		}
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)   
		IFX_MEM_FREE(pwb);
#endif
	} 
}

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
int32 ltq_bridge_validation(int32 WanType)
{
	dw_config_info_t dw_attr;
	int32 ret;
	WAN_MODE PriWanType;
	WAN_MODE SecWanType; 
	memset(&dw_attr, 0, sizeof(dw_config_info_t));
	ret = dw_mapi_cfg_get(&dw_attr, 0);

	if (ret != IFX_SUCCESS) { 
 		IFX_DBG("[%s:%d] ERROR: Config File Read", __FUNCTION__,
				__LINE__);    	
		return IFX_FAILURE;
	}

	PriWanType = compute_wan_mode(dw_attr.pri_wan_cfg.set_phy_mode, dw_attr.pri_wan_cfg.set_wan_tc);
	SecWanType = compute_wan_mode(dw_attr.sec_wan_cfg.set_phy_mode, dw_attr.sec_wan_cfg.set_wan_tc);

	if(dw_attr.fo_state) {	
		if(WanType == PriWanType || WanType == SecWanType){
			return IFX_FAILURE;
		}
	}

	//Bridged WAN can be created
	return IFX_SUCCESS;
} 
#endif

/* wan_vcc_select.asp */
/* The name is though misnormous, this function fetches the WAN Settings along with Channel Information, 
 * Default Gateway and Default VoIP interface  */
int ifx_set_wan_vcc_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pWAN_select = ifx_httpdGetVar(wp, T("WAN"), T(""));
	char_t *pWAN_TYPE = ifx_httpdGetVar(wp, T("wan_type"), T(""));
	char_t *operation = ifx_httpdGetVar(wp, T("operation"), T(""));
	char8	sIface[MAX_IF_NAME_LEN], sVal[MAX_FILELINE_LEN];
	int32 count = 0, i = 0;
	IFX_MAPI_Firewall_PFRule *pfRules = NULL;
	IFX_IPSEC_TUNNEL *ipsec_rules = NULL;

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	Update_mcast_wan_flag(1,0);
#endif

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	if(operation != NULL)
		if (!strcmp(operation, "ads_update")) {
			if(ltq_cgi_set_autodetect_config(wp, "l3") != IFX_SUCCESS){
				return IFX_FAILURE;
			}
			ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
			return IFX_SUCCESS; 
		}
#endif

	char_t *wanmode = ifx_httpdGetVar(wp, T("wan_mode"), T(""));
//	IFX_MAPI_QoS_Interface_Type ifType;
	int32 ret = IFX_SUCCESS, nWAN_IDX = 0;
	//      uint32 outFlag = IFX_F_DEFAULT;
	//      WAN_TYPE sWAN_TYPE;
	char *error_msg =
	    "<font class=\"textTitle\">Error:Failed to make this WAN connection as the default gateway</font>",
	    sValue[MAX_FILELINE_LEN];
	WAN_CONN_CFG wan_cfg;
	IFX_ID iid;
	WAN_PHY_CFG pstWanPhy;
	WAN_COMMON_CFG pWan;
	uint32 flags = IFX_F_DEFAULT;
	//char_t *Wan_Mode = ifx_httpdGetVar(wp, T("wan_mode"), T(""));
	//char_t  *pWAN_VCC = ifx_httpdGetVar(wp, T("wan_mode1"), T(""));
	char_t sLine[256], *pDEF_WAN = NULL;
	IFX_MAPI_QoS_QM qm;
	char_t sWAN_VCC[10];
	char8 secName[MAX_FILELINE_LEN];
	WAN_TYPE wan_type = WAN_TYPE_IP;
	WAN_MODE_CFG cpe_wan_mode;

	sWAN_VCC[0] = '\0';
	ifx_mapi_get_active_qos_iface();
	memset(&iid, 0x00, sizeof(iid));
	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	memset(&cpe_wan_mode, 0x00, sizeof(cpe_wan_mode));
	ifx_get_wan_phy_cfg(&pstWanPhy);

/* Conversion from phy_mode to wan_mode */

	if ((pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)  && (pstWanPhy.wan_tc == WAN_TC_ATM))
	{
		cpe_wan_mode.mode = WAN_MODE_ATM; 
	}
	else if ((pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) && (pstWanPhy.wan_tc == WAN_TC_ATM))
	{
		cpe_wan_mode.mode = WAN_MODE_VDSL_ATM;
	}
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) 
	{	
		cpe_wan_mode.mode = WAN_MODE_ETH0;
	
	}
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
	{
		cpe_wan_mode.mode = WAN_MODE_ETH1;
	}
	else if ((pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) && (pstWanPhy.wan_tc == WAN_TC_PTM))
	{
		cpe_wan_mode.mode = WAN_MODE_VDSL_PTM;
	}
	else if ((pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) && (pstWanPhy.wan_tc == WAN_TC_PTM))
	{
		cpe_wan_mode.mode = WAN_MODE_PTM;
	}

	VIRTUAL_SERVER vs_entry;
        memset(&vs_entry, 0x00, sizeof(vs_entry));

/*
        WAN_TC wan_tc;
        WAN_PHY_MODE phy_mode;
        WAN_TC set_wan_tc;
        WAN_PHY_MODE set_phy_mode;
*/

	/* Fetch the default VoIP Interface */
	if (!strcmp(operation, "def_gw")) {
		/* Fetch the default Gateway */
		pDEF_WAN = ifx_httpdGetVar(wp, T("def_gw"), T(""));
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] def gw set [%s]", __FUNCTION__, __LINE__,
			pDEF_WAN);
#endif
		if (strstr(pDEF_WAN, "IP") != NULL) {
			sscanf(pDEF_WAN, "IP%d", &nWAN_IDX);
			wan_cfg.type = WAN_TYPE_IP;
			wan_type = WAN_TYPE_IP;
		} else {
			sscanf(pDEF_WAN, "PPP%d", &nWAN_IDX);
			wan_cfg.type = WAN_TYPE_PPP;
			wan_type = WAN_TYPE_PPP;
		}

		/* call the api to get the wan config for this wan index and then using iid of this wan call the api to
		   set the default wan interface */
		if (mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_DEFAULT)
		    != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Oops !! There is no wan configuration present for WAN[%d] !!",
				       nWAN_IDX);
			return -1;
		}

		if(wan_cfg.type == WAN_TYPE_IP && wan_cfg.WAN_IP_CONN.addr_type == IP_TYPE_AUTO) {
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
      		if(ltq_bridge_validation(wan_cfg.WAN_IP_CONN.wan_cfg.wan_mode.mode) != IFX_SUCCESS) {
				COPY_TO_STATUS("%s", dw_config_err)
				ifx_httpdRedirect(wp, T("err_page.html")); 
				return IFX_FAILURE;
			}
#endif
		}

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)
		    /* Set Default Gateway Only if the Global WAN Mode and the 
		     * Selected WAN Mode matches */
#ifdef IFX_LOG_DEBUG
		    IFX_DBG("[%s:%d] wan mode [%d]", __FUNCTION__, __LINE__,
			    pWan.wan_mode.mode);
#endif
		if (cpe_wan_mode.mode == pWan.wan_mode.mode
		    || (pstWanPhy.phy_mode== WAN_PHY_MODE_ADSL2
			&& pstWanPhy.wan_tc == WAN_TC_PTM
			&& pWan.wan_mode.mode == WAN_MODE_PTM)
		    || (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2
			&& pstWanPhy.wan_tc == WAN_TC_PTM
			&& pWan.wan_mode.mode == WAN_MODE_VDSL_PTM)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] iid [%d]", __FUNCTION__, __LINE__,
				pWan.iid.cpeId.Id);
#endif
			if (ifx_set_default_wan_if
			    (&pWan.iid, wan_type,
			     IFX_F_MODIFY) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to set WAN[%s] as the default gateway!!",
					       nWAN_IDX);
				return -1;
			}
			ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
		} else {
			COPY_TO_STATUS("%s", error_msg)
			    ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}
	}

	/* TBD: need to know how WANIP or WANPPP can be decided here for modify/delete operation */
	if (pWAN_select && strcmp(operation, "addition")) {

		sprintf(sValue, "WAN_VCC=\"%s\"\n", pWAN_TYPE);	/* TBD: earlier we used to store index. now it should be {wanip/wanppp}{index} */
		ifx_SetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select",
			       IFX_F_MODIFY, 1, sValue);
	}

	nWAN_IDX = atoi(pWAN_select);
	if (!strcmp(operation, "delete")) {
		GET_WAN_DETAILS_FROM_CONN_NAME(pWAN_TYPE, wan_cfg.type,
					       nWAN_IDX, secName)

		    /* NOTE : Validations to check for - existence of any virtual server, ipsec config or
		     * qos configuration on top of this WAN conneciton, disable status of WAN or L2 channel
		     * has been done in Web page and MAPI. TBD ?
		     */
		    if (mapi_get_wan_config
			(nWAN_IDX, &wan_cfg, IFX_F_GET_ENA) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Oops !! There is no wan configuration present for WAN !!");
			return -1;
		}
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		if (ifx_get_sec_count(TAG_NAT_VIRTUALSER, &count) == IFX_SUCCESS) 
		{
			for (i=0; i< count ; i++)
			{
				sprintf(sValue,"nat_virtualser_%d_wanConnIf",i);
                                if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER,sValue,IFX_F_GET_ANY, NULL, sVal) == IFX_SUCCESS)
				{
                	        	if ( !gstrcmp(sVal,pWAN_TYPE))
					{
						IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
						COPY_TO_STATUS("%s", del_vs_err)
        		        	        ifx_httpdRedirect(wp, "err_page.html");
						return -1;
					}
	                	}
			}
		}

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
		ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal);
		if ( strstr(sVal,pWAN_TYPE) != NULL ) {
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			COPY_TO_STATUS("%s", del_mcast_err)
                        ifx_httpdRedirect(wp, "err_page.html");
			return -1;	
		}
#endif

		/* dont allow delete if any packet filter rule configuration stores this WAN connection name */
		if ((ret = ifx_get_wan_ifname_from_connName(pWAN_TYPE, sIface,
			      wan_cfg.type)) != IFX_SUCCESS) {
		}

		count = 0;
		if(ifx_mapi_get_firewall_pfrules(&count, &pfRules, IFX_F_GET_ANY) != IFX_SUCCESS) {

		}
		else {
			for (i=0; i < count; i++) {
				if( (strcmp((pfRules + i)->oif, sIface) == 0) || (strcmp((pfRules + i)->iif, sIface) == 0) ) {
					IFX_MEM_FREE(pfRules)
					COPY_TO_STATUS("%s", del_pf_err)
	                	        ifx_httpdRedirect(wp, "err_page.html");
					return -1;	
				}
			}
			IFX_MEM_FREE(pfRules)
		}

		/* dont allow delete if any ipsec rule configuration stores this WAN connection name */
		count = 0;
		if(ifx_get_all_ipsec_tunnel_entries(&count, &ipsec_rules, IFX_F_GET_ANY) != IFX_SUCCESS) {

		}
		else {
			for (i=0; i < count; i++) {
				if( strcmp((ipsec_rules + i)->wan_conn_if, pWAN_TYPE) == 0) {
					IFX_MEM_FREE(ipsec_rules)
					COPY_TO_STATUS("%s", del_ipsec_err)
	        	                ifx_httpdRedirect(wp, "err_page.html");
					return -1;	
				}
			}
			IFX_MEM_FREE(ipsec_rules)
		}

		/* CANNOT Delete Disabled WAN Connections.
		 * These are configured from TR069 ACS and can't delete the same from Web */
		/* TBD : check this with latest code */
		if (pWan.f_enable == IFX_DISABLED) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] is currently disabled - Can't delete!!\n",
				       nWAN_IDX);
			return -1;
		}

		/* Reset the IPAddr, NetMask and Gateway fields in case of DHCP */
		if (pWan.link_type == WAN_LINK_TYPE_PPPOE
		    || pWan.link_type == WAN_LINK_TYPE_PPPOATM) {
			/* set the PPP status as dis-connecting */
			wan_cfg.WAN_PPP_CONN.conn_status =
			    WAN_PPP_CONN_STATUS_DISCONNECTING;
		} else {
			/* set the IP status as dis-connecting */
			wan_cfg.WAN_PPP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_DISCONNECTING;
		}

		/* Set the DELETE operation & Flags */
		flags = IFX_F_DELETE;

		/* Set the config owner to WEB */
		if(wan_cfg.type == WAN_TYPE_PPP)
			wan_cfg.wancfg.ppp.wan_cfg.iid.config_owner = IFX_WEB;
		else
			wan_cfg.wancfg.ip.wan_cfg.iid.config_owner = IFX_WEB;

		/* Invoke the MAPI function to delete this WAN Connection */
		if (strstr(wanmode, "PTM") != NULL || strstr(wanmode, "ETH") != NULL) {
			/* MAPI to delete this WAN Connection */
			ret = ifx_mapi_set_wan_config(IFX_OP_DEL, &wan_cfg, flags);
		}
		else {
			/* TBD: this validation will have an impact. We dont store VC info in WAN object anymore */
			ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM,
				       "qm_atmQmode", IFX_F_GET_ENA, 0, sLine);
			if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED) {
				/* check if WAN connection has active queues configured on it */
				if ((ret =
				     ifx_mapi_get_qos_qm(&qm,
							 IFX_F_DEFAULT)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s:%d] queue config read failed",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}
				//                                              IFX_DBG("[%s:%d] comparing [%s:%s]", __FUNCTION__, __LINE__, qm.qIf, sWAN_VCC);
				if (!strcmp(qm.qIf, sWAN_VCC)) {
					/* TODO : pramod */
					IFX_DBG
					    ("[%s:%d] Cannot delete. WAN connection has queues attached to it.",
					     __FUNCTION__, __LINE__);
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}

#if 0				// [ Debug start
			if (wan_cfg.type == WAN_TYPE_PPP) {
				IFX_DBG
				    ("[%s:%d] wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.Id = %d wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.sec [%s] config owner [%d]",
				     __FUNCTION__, __LINE__,
				     wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.Id,
				     wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.
				     secName,
				     wan_cfg.wancfg.ppp.wan_cfg.iid.
				     config_owner);
			} else {
				IFX_DBG
				    ("[%s:%d] wan_cfg.wancfg.ip.wan_cfg.iid.cpeId.Id = %d wan_cfg.wancfg.ip.wan_cfg.iid.cpeId.sec [%s] config owner [%d]",
				     __FUNCTION__, __LINE__,
				     wan_cfg.wancfg.ip.wan_cfg.iid.cpeId.Id,
				     wan_cfg.wancfg.ip.wan_cfg.iid.cpeId.
				     secName,
				     wan_cfg.wancfg.ip.wan_cfg.iid.
				     config_owner);
			}
#endif				// Debug end ]

			/* MAPI to delete this WAN Connection */
			ret = ifx_mapi_set_wan_config(IFX_OP_DEL, &wan_cfg, flags);
		}

		if(ret != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
	       			"Failed to Delete this wan connection !!");
			return -1;
		}

		/* Reset value in system_status file */
		sprintf(sValue, "%s", "WAN_VCC=\"\"\n");
		ifx_SetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select",
			       IFX_F_MODIFY, 1, sValue);
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	}

IFX_Handler:
	if (strcmp(operation, "delete")) {
		websNextPage(wp);
	}
	return 0;
}

/* wan_dns.asp */
void ifx_set_wan_dns(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pDIP11, *pDIP12, *pDIP13, *pDIP14;
	char_t *pDIP21, *pDIP22, *pDIP23, *pDIP24;
	char_t sCommand[MAX_FILELINE_LEN];
	a_assert(wp);
	// Get value from ASP file
	pDIP11 = ifx_httpdGetVar(wp, T("DIP11"), T(""));
	pDIP12 = ifx_httpdGetVar(wp, T("DIP12"), T(""));
	pDIP13 = ifx_httpdGetVar(wp, T("DIP13"), T(""));
	pDIP14 = ifx_httpdGetVar(wp, T("DIP14"), T(""));
	pDIP21 = ifx_httpdGetVar(wp, T("DIP21"), T(""));
	pDIP22 = ifx_httpdGetVar(wp, T("DIP22"), T(""));
	pDIP23 = ifx_httpdGetVar(wp, T("DIP23"), T(""));
	pDIP24 = ifx_httpdGetVar(wp, T("DIP24"), T(""));

	if (pDIP11[0] && pDIP12[0] && pDIP13[0] && pDIP14[0] &&
	    pDIP21[0] && pDIP22[0] && pDIP23[0] && pDIP24[0]) {
		gsprintf(sCommand,
			 "WAN_DNS1=\"%s.%s.%s.%s\"\nWAN_DNS2=\"%s.%s.%s.%s\"\n",
			 pDIP11, pDIP12, pDIP13, pDIP14, pDIP21, pDIP22, pDIP23,
			 pDIP24);
		ifx_SetObjData(FILE_RC_CONF, TAG_WAN_DNS, IFX_F_MODIFY, 1, sCommand);

		gsprintf(sCommand,
			 T
			 ("echo \"nameserver %s.%s.%s.%s\nnameserver %s.%s.%s.%s\" > %s"),
			 pDIP11, pDIP12, pDIP13, pDIP14, pDIP21, pDIP22, pDIP23,
			 pDIP24, FILE_RESOLV_CONF);
	} else if (pDIP11[0] && pDIP12[0] && pDIP13[0] && pDIP14[0]) {
		gsprintf(sCommand, "WAN_DNS1=\"%s.%s.%s.%s\"\nWAN_DNS2=\"0\"\n",
			 pDIP11, pDIP12, pDIP13, pDIP14);
		ifx_SetObjData(FILE_RC_CONF, TAG_WAN_DNS, IFX_F_MODIFY, 1, sCommand);

		gsprintf(sCommand, T("echo \"nameserver %s.%s.%s.%s\" > %s"),
			 pDIP11, pDIP12, pDIP13, pDIP14, FILE_RESOLV_CONF);

	} else {
		gsprintf(sCommand, "WAN_DNS1=\"0\"\nWAN_DNS2=\"0\"\n");
		ifx_SetObjData(FILE_RC_CONF, TAG_WAN_DNS, IFX_F_MODIFY, 1, sCommand);
		gsprintf(sCommand, T("echo " " > %s"), FILE_RESOLV_CONF);
	}

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	system(sCommand);

	// apply the new dns server ip to the dns relay server
	system(SERVICE_DNS_RELAY_RESTART);

	websNextPage(wp);
}

#if 0				// [ no explicit WAN VLAN config enable/disable for ATM
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
int ifx_set_wan_vlan(char_t * pCheck)
{
	char_t sCheck[MAX_WEB_DATA];
	char_t sCommand[MAX_DATA_LEN];

	//              a_assert(wp);
	memset(sCheck, 0x00, MAX_WEB_DATA);

	//pCheck = ifx_httpdGetVar(wp, T("wan_vlan_status"), T(""));
	if (!gstrcmp(pCheck, "1")) {
		gsprintf(sCheck, T("WAN_VLAN_STATUS=\"%s\"\n"), pCheck);
		sprintf(sCommand, "br2684ctl -v -g 1\n");
	} else {
		gsprintf(sCheck, T("WAN_VLAN_STATUS=\"0\"\n"));
		sprintf(sCommand, "br2684ctl -v -g 0\n");
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_WAN_VLAN, 1, sCheck);

	// save setting
	if (ifx_flash_write() <= 0) {
		IFX_DBG
		    ("\n\nIn Function [%s:%d] : Error--> Fial to save setting !!\n\n",
		     __FUNCTION__, __LINE__);
		//      ifx_httpdError(wp, 500, "Fail to save Setting");
		return -1;
	}
	//Runtime
	//Change
	system(sCommand);
//                              websNextPage(wp);
	return 0;
}
#endif
#endif				// no explicit enable/disable ]
int ifx_wan_common_cgi(httpd_t wp,char_t * path, char_t * query)
{
        int32   iRet = 0;
        char_t * pNewConnType = ifx_httpdGetVar(wp, T("WT"), T(""));

        iRet = ifx_set_wan(wp,path,query);
        if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        	IFX_DBG("In Function [%s]:[%d] :ifx_set_wan function failed !!\n",__FUNCTION__, __LINE__);
#endif
          goto ErrorHandler;
        }

        if (!gstrcmp(pNewConnType, "3"))
        {
                iRet = ifx_set_wan_pppoe(wp, path, query);
                if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("In Function [%s]:[%d] :PPPoE is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
                        goto ErrorHandler;
                }
       } else if (!gstrcmp(pNewConnType, "4")) { 
                iRet = ifx_set_wan_pppoa(wp, path, query);
                if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("In Function [%s]:[%d] :PPPoA is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
                        goto ErrorHandler;
                }
       } else if (!gstrcmp(pNewConnType, "1")) {
                iRet = ifx_set_wan_dhcp(wp, path, query);
                if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("In Function [%s]:[%d] :Dhcp is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
                        goto ErrorHandler;
                }
      } else if (!gstrcmp(pNewConnType, "2")) {
                iRet = ifx_set_wan_static(wp, path, query);
                if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("In Function [%s]:[%d] :Static is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
                        goto ErrorHandler;
                }
     } else if (!gstrcmp(pNewConnType, "5")) {
                iRet = ifx_set_bridge_settings(wp, path, query);
                if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("In Function [%s]:[%d] :Bridge is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
                        goto ErrorHandler;
                }
        }
      ErrorHandler:
        /* if WAN connection configuration has failed, (iRet == IFX_FAILURE), then restore old default VoIP */
        if (iRet != IFX_SUCCESS) {
                                return -1;
        }
        return 0;
}


/* This function configures WAN Connection Type on the
 * selected WAN index - Dynamic IP, Static IP, PPPoE, PPPoA, Bridge, Delete WAN */
int ifx_set_wan(httpd_t wp, char_t * path, char_t * query)
{
				char_t *pWAN_TYPE = ifx_httpdGetVar(wp, T("WT"), T(""));
				char_t *pWAN_VCC = ifx_httpdGetVar(wp, T("vcChannel"), T(""));
				char_t sWAN_TYPE[10];
				int32 nWAN_IDX = -1;
				uint32 outFlag = IFX_F_DEFAULT;
				char8 buf[MAX_FILELINE_LEN], *retVal = NULL;
				char8 sValue[MAX_NAME_SIZE], sValue_qs[MAX_NAME_SIZE];
				WAN_CONN_CFG wan_cfg;
				WAN_CONN_CFG mod_wan_cfg;
				WAN_PHY_CFG pstWanPhy;
				IFX_MAPI_QoS_QM qm;
				WAN_TYPE sTYPE;
				int32 ret = IFX_SUCCESS;
				/* QS Modifications */
				char_t *pNewVcc = NULL;
				char_t *pNewVlanId = NULL;

				/* QS Modifications END*/

				memset(&qm, 0x00, sizeof(qm));


				/* Get the current WAN Mode Configured */
				char_t *Wan_Mode = ifx_httpdGetVar(wp, T("wan_mode"), T(""));

				buf[0] = '\0';
				sWAN_TYPE[0] = '\0';
				memset(&wan_cfg, 0x00, sizeof(wan_cfg));
				memset(&mod_wan_cfg, 0x00, sizeof(mod_wan_cfg));
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]", __FUNCTION__, __LINE__,pWAN_TYPE, pWAN_VCC);
#endif

#ifdef CONFIG_FEATURE_IFX_MULTIPLE_VCCS
				if (!gstrcmp(Wan_Mode, "ATM")) {
					/* ATM WAN Mode: get the vcc selected from system file */
					/* QS Modifications */
					int status = 0;
					status = gatoi(ifx_httpdGetVar(wp, T("qs_status"), T("")));
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] ####status is ------->>>> %d ", __FUNCTION__,__LINE__, status);
#endif
					if (status != 1) {
						pNewVcc = ifx_httpdGetVar(wp, T("vcSetting"), T(""));
						pNewVlanId = ifx_httpdGetVar(wp, T("vlan_id"), T(""));
						if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF,TAG_ADSL_VCCHANNEL,"vcc", pNewVcc,&retVal)) != IFX_SUCCESS) {
							ifx_httpdError(wp, 400,"VC Channel [%s] doesn't exist!\n",pWAN_VCC);
						} else {
							sprintf(buf, "%s_l2ifName", retVal);
							if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf,IFX_F_GET_ANY, NULL,sValue_qs) == IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
							IFX_DBG("[%s:%d] ####pWAN_VCC =  %s.%s ------->>>> ",__FUNCTION__, __LINE__, sValue_qs,pNewVlanId);
#endif
							if (strlen(pNewVlanId)) {
								sprintf(pWAN_VCC, "%s.%s",sValue_qs, pNewVlanId);
							} else {
								sprintf(pWAN_VCC, "%s",sValue_qs);
							}
						}
#ifdef IFX_LOG_DEBUG
						IFX_DBG("[%s:%d] ####pWAN_VCC =  %s ------->>>> ",__FUNCTION__, __LINE__, pWAN_VCC);
#endif
					}
				}
				/* QS Modifications END*/
			}
#endif

			if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF,TAG_VLAN_CFG,"l2ifName", pWAN_VCC,&retVal)) != IFX_SUCCESS) {
				/* Cannot be - seriously something wrong here */
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]",__FUNCTION__, __LINE__, pWAN_TYPE, pWAN_VCC);
#endif
				ifx_httpdError(wp, 400,"L2 Channel [%s] doesn't exist!\n",pWAN_VCC);
				/* Free the returned VCC information */
				IFX_MEM_FREE(retVal)
				return -1;
			}

			/* Check if the VCC selected is in Disabled Mode */
			memset(sValue, 0x00, sizeof(sValue));
			sprintf(buf, "%s_fEnable", retVal);
			if (ifx_GetObjData(FILE_RC_CONF, TAG_VLAN_CFG, buf, IFX_F_GET_ANY,&outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("\n\nIn Function [%s] : Error--> f_enable not found for L2 channel [%s] !!\n\n",__FUNCTION__, pWAN_VCC);
#endif
				IFX_MEM_FREE(retVal)
				return -1;
			}
			if (atoi(sValue) == IFX_DISABLED) {
				ifx_httpdError(wp, 400,"L2 Channel[%s] is currently disabled - Can't select!!\n",pWAN_VCC);
				IFX_MEM_FREE(retVal)
				return -1;
			}

			buf[0] = '\0';

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]", __FUNCTION__, __LINE__,pWAN_TYPE, pWAN_VCC);
#endif

			IFX_GET_WAN_SELECTED_INDEX(IFX_F_DEFAULT, outFlag, buf , nWAN_IDX,sTYPE)

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] nWAN_IDX [%d] wan type [%d] ", __FUNCTION__, __LINE__,nWAN_IDX, sTYPE );
#endif

			if (sTYPE == WAN_TYPE_IP){
				mod_wan_cfg.type = WAN_TYPE_IP;
				wan_cfg.type = WAN_TYPE_IP;
				sprintf(wan_cfg.wancfg.ip.wan_cfg.l2iface_name,"%s",pWAN_VCC);
			}	
			else
			{
				mod_wan_cfg.type = WAN_TYPE_PPP;
				wan_cfg.type = WAN_TYPE_PPP;
				sprintf(wan_cfg.wancfg.ppp.wan_cfg.l2iface_name,"%s",pWAN_VCC);
			}

			if(nWAN_IDX != -1)
			{
				if (mapi_get_wan_config(nWAN_IDX, &mod_wan_cfg, IFX_F_GET_ENA) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]", __FUNCTION__, __LINE__,pWAN_TYPE, pWAN_VCC);
#endif
					return -1;
				}	
			}

			/* Identify the WAN Connection Type based on the Selection */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]", __FUNCTION__, __LINE__,pWAN_TYPE, pWAN_VCC);
#endif
			switch (atoi(pWAN_TYPE)) {
				case 1:
							wan_cfg.type = WAN_TYPE_IP;
							wan_cfg.wancfg.ip.conn_type=WAN_IP_CONN_TYPE_IP_ROUTED;
							gsprintf(sWAN_TYPE, "DHCPC");
							break;
				case 2:
							wan_cfg.type = WAN_TYPE_IP;
							wan_cfg.wancfg.ip.conn_type=WAN_IP_CONN_TYPE_IP_ROUTED;
							gsprintf(sWAN_TYPE, "FIXED");
							break;
				case 3:
							wan_cfg.type = WAN_TYPE_PPP;
							wan_cfg.wancfg.ppp.wan_cfg.link_type = WAN_LINK_TYPE_PPPOE; 
							gsprintf(sWAN_TYPE, "PPPOE");
							break;
				case 4:
							wan_cfg.type = WAN_TYPE_PPP;
							wan_cfg.wancfg.ppp.wan_cfg.link_type = WAN_LINK_TYPE_PPPOATM;
							gsprintf(sWAN_TYPE, "PPPOA");
							break;
				case 5:
							wan_cfg.type = WAN_TYPE_IP;
							wan_cfg.wancfg.ip.conn_type=WAN_IP_CONN_TYPE_IP_BRIDGED;
							gsprintf(sWAN_TYPE, "BRIDGE");
							break;
				case 0:
							default:
											gsprintf(sWAN_TYPE, "UNKNOWN");
											break;
			}

			if (mapi_validate_wanconfig( IFX_OP_MOD , &mod_wan_cfg, &wan_cfg) !=IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_validate wancount failed  pWAN_TYPE -> %s pWAN_VCC [%s]", __FUNCTION__, __LINE__,pWAN_TYPE, pWAN_VCC);
#endif
				COPY_TO_STATUS("%s", per_chwan_err);
				IFX_MEM_FREE(retVal)
				ifx_httpdRedirect(wp, "err_page.html");
				return -1;
			}

			ifx_get_wan_phy_cfg(&pstWanPhy);

			/* NOTE : Delete operation moved to another page and hence another CGI function */

			{
			if (!gstrcmp(Wan_Mode, "ATM")) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]",__FUNCTION__, __LINE__, sWAN_TYPE, pWAN_VCC);
#endif
				/* In case of ATM WAN, WAN_VCC is set with VPI/VCI values */
				sprintf(buf, "ipoption_wan=\"%s\"\nWAN_VCC=\"%s\"\n",sWAN_TYPE, pWAN_VCC);
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN,IFX_F_MODIFY, 1, buf);
			} else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] pWAN_TYPE -> %s pWAN_VCC [%s]",__FUNCTION__, __LINE__, sWAN_TYPE, pWAN_VCC);
#endif
				/* In all other cases WAN_VCC is set with: 
					* ETHx for ETH WAN Mode
					* PTMx for PTM WAN Mode */
				buf[0] = '\0';
				sprintf(buf, "ipoption_wan=\"%s\"\nWAN_VCC=\"%s\"\n",sWAN_TYPE, pWAN_VCC);
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN,IFX_F_MODIFY, 1, buf);
			}
			}

IFX_Handler:
			IFX_MEM_FREE(retVal)
			return 0;
}

int ifx_create_wan_main_page(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int nWanMode = 0;
	char_t sWAN_IDX[MAX_NAME_SIZE];
	int nWAN_IDX = -1;
	uint32 outFlag = IFX_F_DEFAULT;
	IP_TYPE nWanType;
	WAN_TYPE sWAN_TYPE;
	/* TBD: need to know how to find connection type based on which IFX_GET_WANIP_SELECTED_INDEX or IFX_GET_WANPPP_SELECTED_INDEX AND ifx_get_wanip_conn_type can be called */
	IFX_GET_WAN_SELECTED_INDEX(IFX_F_DEFAULT, outFlag, sWAN_IDX, nWAN_IDX,
				   sWAN_TYPE)

	    if (sWAN_TYPE == WAN_TYPE_IP) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] nWAN_IDX [%d]", __FUNCTION__, __LINE__,
			nWAN_IDX);
#endif
		nWanMode = getWanMode(nWAN_IDX, WAN_TYPE_IP);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] nWanMode [%d]", __FUNCTION__, __LINE__,
			nWanMode);
#endif

		if (nWanMode == IP_BOOT_ETH || nWanMode == IP_BOOT_PTM) {
			if (ifx_get_wanip_conn_type(&nWanType, nWAN_IDX) ==
			    IFX_SUCCESS) {
				switch (nWanType) {
				case IP_TYPE_DHCP:
					nWanMode = IP_BOOT_DHCPC;
					break;
				case IP_TYPE_STATIC:
					nWanMode = IP_BOOT_FIXED;
					break;
				case IP_TYPE_AUTO:
					nWanMode = IP_BOOT_BRIDGE;
					break;
				}
			}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] nWanType [%d]", __FUNCTION__, __LINE__,
				nWanType);
#endif

		}
	} else
		nWanMode = getWanMode(nWAN_IDX, WAN_TYPE_PPP);
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] nWanType [%d]", __FUNCTION__, __LINE__, nWanType);
#endif

#ifdef CONFIG_FEATURE_DHCP_CLIENT
	ifx_httpdWrite(wp,
		       T
		       ("CreateWANType('1','Dynamic IP Address','Obtain an IP address automatically from your service provider.',%d);\n"),
		       nWanMode == IP_BOOT_DHCPC ? 1 : 0);
#endif

	ifx_httpdWrite(wp,
		       T
		       ("CreateWANType('2','Static IP Address','Uses a static IP address. Your service provider gives a static IP address to access Internet services.',%d);\n"),
		       nWanMode == IP_BOOT_FIXED ? 1 : 0);

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOE
	ifx_httpdWrite(wp,
		       T
		       ("CreateWANType('3','PPPoE','PPP over Ethernet is a common connection method used to access Internet.',%d);\n"),
		       nWanMode == IP_BOOT_PPPOE ? 1 : 0);

#endif

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	ifx_httpdWrite(wp,
		       T
		       ("CreateWANType('4','PPPoA','PPP over ATM is a common connection method used for xDSL',%d);\n"),
		       nWanMode == IP_BOOT_PPPOA ? 1 : 0);
#endif

	ifx_httpdWrite(wp,
		       T
		       ("CreateWANType('5','Bridge','Transparent Bridging (802.1d) between WAN and LAN.',%d);\n"),
		       nWanMode == IP_BOOT_BRIDGE ? 1 : 0);
#ifdef IFX_CONFIG_TR037
	ifx_httpdWrite(wp,
		       T
		       ("CreateWANType('6','TR037/038','TR037/038 mode is a common connection method used for xDSL modem.',%d);\n"),
		       nWanMode == IP_BOOT_TR037 ? 1 : 0);
#endif

	//ifx_httpdWrite(wp, T("CreateWANType('0','Delete','Delete this WAN connection.',%d);\n"), nWanMode == 0);
	return 0;
}

int ifx_check_wan_conn_dependency(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t /*sWan_If_Name[MAX_FILELINE_LEN],*/ sWan_Conn_Name[MAX_CONN_NAME_LEN];
	char_t sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	int32 nWAN_IDX = -1, num_entries = 0, i = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	VIRTUAL_SERVER *virtual = NULL;
	WAN_TYPE sWAN_TYPE;

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
    pwb_cfg_t *pwb = NULL;
    uint32  num = 0;
#endif

	buf[0] = '\0';
	sValue[0] = '\0';
//	sWan_If_Name[0] = '\0';
	sWan_Conn_Name[0] = '\0';

	/* TBD: currently assuming as IP conn, bt need to handle both IP/PPP */
	IFX_GET_WAN_SELECTED_INDEX(IFX_F_DEFAULT, outFlag, sValue, nWAN_IDX,
				   sWAN_TYPE)

	    if (sWAN_TYPE == WAN_TYPE_IP) {
		sprintf(buf, "%s_%d_connName", PREFIX_WAN_IP, nWAN_IDX);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ENA, &outFlag,
		     sWan_Conn_Name) != IFX_SUCCESS) {
			/* check if entry is disabled */
			ifx_httpdWrite(wp, T("-2"));
			return -1;
		}
	} else {
		sprintf(buf, "%s_%d_connName", PREFIX_WAN_PPP, nWAN_IDX);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_GET_ENA, &outFlag,
		     sWan_Conn_Name) != IFX_SUCCESS) {
			/* check if entry is disabled */
			ifx_httpdWrite(wp, T("-2"));
			return -1;
		}
	}

	if (ifx_get_virtual_server_info(&num_entries, &virtual, IFX_F_GET_ANY)
	    != IFX_SUCCESS) {
		ifx_httpdWrite(wp, T("-2"));
		IFX_MEM_FREE(virtual)
		    return -1;
	}

	for (i = 0; i < num_entries; i++) {
		if (!gstrcmp((virtual + i)->wan_conn_if, sWan_Conn_Name)) {
			ifx_httpdWrite(wp, T("-1"));
			IFX_MEM_FREE(virtual)
			    return -1;
		}
	}

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
    if(mapi_port_binding_cfg_get_all(&num, &pwb, IFX_F_DEFAULT) != IFX_SUCCESS)
    {
    	ifx_httpdWrite(wp, T("-2"));
	IFX_MEM_FREE(pwb)
	return -1;
    }
    for (i=0; i<num; i++)
    {
	if(!strncmp((pwb + i)->wanIf.conName, sWan_Conn_Name, MAX_CONN_NAME_LEN)) {
		ifx_httpdWrite(wp, T("-3"));
		IFX_MEM_FREE(virtual)
		IFX_MEM_FREE(pwb)
		return	-1;
	}
    }
    IFX_MEM_FREE(pwb)
#endif

	ifx_httpdWrite(wp, T("0"));
	IFX_MEM_FREE(virtual)
	    return 0;
}

#ifdef CONFIG_FEATURE_DDNS
// ddns_config.asp
void ifx_set_ddns_config(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pStatus = ifx_httpdGetVar(wp, T("ddnsStatus"), T(""));
	char_t *pselradio;
	char_t *phost1 = ifx_httpdGetVar(wp, T("host1"), T(""));
	char_t *puser1 = ifx_httpdGetVar(wp, T("user1"), T(""));
	char_t *ppw1 = ifx_httpdGetVar(wp, T("pw1"), T(""));
	char_t *phost2 = ifx_httpdGetVar(wp, T("host2"), T(""));
	char_t *puser2 = ifx_httpdGetVar(wp, T("user2"), T(""));
	char_t *ppw2 = ifx_httpdGetVar(wp, T("pw2"), T(""));
	char_t *phost3 = ifx_httpdGetVar(wp, T("host3"), T(""));
	char_t *puser3 = ifx_httpdGetVar(wp, T("user3"), T(""));
	char_t *ppw3 = ifx_httpdGetVar(wp, T("pw3"), T(""));
	char_t sStatus[MAX_DATA_LEN], sSelIdx[MAX_DATA_LEN],
	    sHost[APPS_DDNS_NUM][MAX_DATA_LEN],
	    sUser[APPS_DDNS_NUM][MAX_DATA_LEN],
	    sPasswd[APPS_DDNS_NUM][MAX_DATA_LEN];
	char_t sDdnsIF[MAX_DATA_LEN];
	char_t *pDdnsIF;
	char_t sValue[MAX_DATA_LEN];
	char_t sWanStatusTag[MAX_DATA_LEN];
	int wanIdx = 0;
	char_t wanstr[10];

	a_assert(wp);
	sStatus[0] = '\0';
	sSelIdx[0] = '\0';

	/* Get the DDNS Status from System Status File
	   If DDNS already running, then stop the DDNS Service */
	if (ifx_GetCfgData(FILE_SYSTEM_STATUS, "ddns", "status", sValue) == 1) {
		if (!strcmp(sValue, "start")) {
			system(SERVICE_DDNS_STOP);
		}
	}

	if (pStatus && *pStatus) {
		pselradio = ifx_httpdGetVar(wp, T("selradio"), T(""));

		gsprintf(sStatus, T("ddns_enable=\"YES\"\n"));
		ifx_SetCfgData(FILE_RC_CONF, TAG_DDNSSTATUS, 1, sStatus);

		pDdnsIF = ifx_httpdGetVar(wp, T("ddns_if"), T(""));
		sprintf(sDdnsIF, "ddns_if=\"%s\"\n", pDdnsIF);
		sscanf(pDdnsIF, "%3s%d", wanstr, &wanIdx);

		/* Select the DDNS Service - dyndns, dhs, cx */
		if (pselradio && *pselradio)
			gsprintf(sSelIdx, T("serviceIndex=\"%s\"\n"),
				 pselradio);
		else
			gsprintf(sSelIdx, T("serviceIndex=\"1\"\n"));	//default

		/* Fetch the 1st Host, User Name & Password */
		if (phost1 && *phost1)
			gsprintf(sHost[0], T("host1=\"%s\"\n"), phost1);
		else
			gsprintf(sHost[0], T("host1=\"0\"\n"));
		if (puser1 && *puser1)
			gsprintf(sUser[0], T("user1=\"%s\"\n"), puser1);
		else
			gsprintf(sUser[0], T("user1=\"0\"\n"));
		if (ppw1 && *ppw1)
			gsprintf(sPasswd[0], T("passwd1=\"%s\"\n"), ppw1);
		else
			gsprintf(sPasswd[0], T("passwd1=\"0\"\n"));

		/* Fetch the 2nd Host, User Name & Password */
		if (phost2 && *phost2)
			gsprintf(sHost[1], T("host2=\"%s\"\n"), phost2);
		else
			gsprintf(sHost[1], T("host2=\"0\"\n"));
		if (puser2 && *puser2)
			gsprintf(sUser[1], T("user2=\"%s\"\n"), puser2);
		else
			gsprintf(sUser[1], T("user2=\"0\"\n"));
		if (ppw2 && *ppw2)
			gsprintf(sPasswd[1], T("passwd2=\"%s\"\n"), ppw2);
		else
			gsprintf(sPasswd[1], T("passwd2=\"0\"\n"));

		/* Fetch the 2nd Host, User Name & Password */
		if (phost3 && *phost3)
			gsprintf(sHost[2], T("host3=\"%s\"\n"), phost3);
		else
			gsprintf(sHost[2], T("host3=\"0\"\n"));
		if (puser3 && *puser3)
			gsprintf(sUser[2], T("user3=\"%s\"\n"), puser3);
		else
			gsprintf(sUser[2], T("user3=\"0\"\n"));
		if (ppw3 && *ppw3)
			gsprintf(sPasswd[2], T("passwd3=\"%s\"\n"), ppw3);
		else
			gsprintf(sPasswd[2], T("passwd3=\"0\"\n"));

		/* Store the DDNS Configuration to sysconfig file */
		ifx_SetCfgData(FILE_RC_CONF, TAG_DDNSCONFIG, 11, sSelIdx,
			       sDdnsIF, sHost[0], sUser[0], sPasswd[0],
			       sHost[1], sUser[1], sPasswd[1], sHost[2],
			       sUser[2], sPasswd[2]);

		//Runtime Change
		sprintf(sWanStatusTag, "bringup_wan%d_services", wanIdx);
		if (ifx_GetCfgData
		    (FILE_SYSTEM_STATUS, sWanStatusTag, "status",
		     sValue) == 1) {
			if (!strcmp(sValue, "start")) {
				if (GetWanMode(wanIdx) != IP_BOOT_BRIDGE) {
					snprintf(sValue, sizeof(sValue),
						 "%s %d", SERVICE_DDNS_START,
						 wanIdx);
					system(sValue);
				}
			}
		}
	} else {
		gsprintf(sStatus, T("ddns_enable=\"NO\"\n"));
		ifx_SetCfgData(FILE_RC_CONF, TAG_DDNSSTATUS, 1, sStatus);
	}
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 400, "Fail to save Setting");
		return;
	}

	websNextPage(wp);
}
#endif

#ifdef CONFIG_FEATURE_DDNS
// ddns_config.asp
int ifx_get_ddns_cfg(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';
	if (!gstrcmp(name, T("status"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSSTATUS, T("ddns_enable"),
		     sValue) == 0) {
			ifx_httpdError(wp, 500, "DDNS status not found");
			return -1;
		}

		if (!gstrcmp(sValue, "YES"))	// DDNS is enabled
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));
	} else if (!gstrcmp(name, T("ddns_if"))) {
		int nSelIdx = 1, i = 0;
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("ddns_if"), sValue) == 1) {
			nSelIdx = atoi(sValue);
		}
		for (i = 1; i <= MAX_VCCs; i++) {
			ifx_httpdWrite(wp,
				       T
				       ("<option value=%d %s>WAN%d</option>\n"),
				       i, i == nSelIdx ? "SELECTED" : " ", i);
		}
	} else if (!gstrcmp(name, T("selradio"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("serviceIndex"),
		     sValue) == 0) {
			ifx_httpdError(wp, 500,
				       "DDNS select server index found");
			return -1;
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	}
	/* Data of dyn.dhs.org */
	else if (!gstrcmp(name, T("host1"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("host1"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Hostname is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}

		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("user1"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("user1"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Username value is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("pw1"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("passwd1"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Password value is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	}
	/* Data of dyndns.org */
	else if (!gstrcmp(name, T("host2"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("host2"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Hostname is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("user2"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("user2"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Username value is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("pw2"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("passwd2"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Password value is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	}
	/* Data of dyns.cx */
	else if (!gstrcmp(name, T("host3"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("host3"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Hostname is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("user3"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("user3"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Username value is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("pw3"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("passwd3"), sValue) == 0) {
			ifx_httpdError(wp, 500, "Password value is not found");
			return -1;
		}
		if (!gstrcmp(sValue, "0")) {
			gstrcpy(sValue, "");
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	}

	return 0;
}
#endif				//CONFIG_FEATURE_DDNS

//cgi for supporting eth wan

int ifx_get_wan_channel_selected(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char8			sValue[16];
	WAN_TYPE	wan_type;
	int32			wanIdx = -1;
	uint32		outFlag = IFX_F_DEFAULT;

	sValue[0] = '\0';
	IFX_GET_WAN_SELECTED_INDEX(IFX_F_DEFAULT, outFlag, sValue, wanIdx, wan_type)

	ifx_httpdWrite(wp, "%d", WanModeGet(wanIdx, wan_type));

	return IFX_SUCCESS;
}

int ifx_get_wan_mode(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char_t phy_mode[8] = { 0 };
	char_t phy_tc[8] = { 0 };
	uint32 outFlag = IFX_F_DEFAULT;
	ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_phymode",
		       IFX_F_DEFAULT, &outFlag, phy_mode);
	if (!gstrcmp(phy_mode, "0")) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_tc",
			       IFX_F_DEFAULT, &outFlag, phy_tc);
		if (!gstrcmp(phy_tc, "1")) {
			ifx_httpdWrite(wp, T("%d"), 3);
			return IFX_SUCCESS;
		}
	} else if (!gstrcmp(phy_mode, "3")) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_tc",
			       IFX_F_DEFAULT, &outFlag, phy_tc);
		if (!gstrcmp(phy_tc, "1")) {
			ifx_httpdWrite(wp, T("%d"), 4);
			return IFX_SUCCESS;
		}
		if (!gstrcmp(phy_tc, "0")) {
			ifx_httpdWrite(wp, T("%d"), 5);
			return IFX_SUCCESS;
		}
	}
	ifx_httpdWrite(wp, T("%d"), atoi(phy_mode));
	return IFX_SUCCESS;
}

int ifx_get_wan_mode_configured(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char_t phy_mode[8] = { 0 };
	char_t phy_tc[8] = { 0 };
	uint32 outFlag = IFX_F_DEFAULT;
	ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_setphymode",
		       IFX_F_DEFAULT, &outFlag, phy_mode);
	if (!gstrcmp(phy_mode, "0")) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_settc",
			       IFX_F_DEFAULT, &outFlag, phy_tc);
		if (!gstrcmp(phy_tc, "1")) {
			ifx_httpdWrite(wp, T("%d"), 3);
			return IFX_SUCCESS;
		} else if (!gstrcmp(phy_tc, "2")) {
			ifx_httpdWrite(wp, T("%d"), 6);
			return IFX_SUCCESS;
		}
	} else if (!gstrcmp(phy_mode, "3")) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_settc",
			       IFX_F_DEFAULT, &outFlag, phy_tc);
		if (!gstrcmp(phy_tc, "1")) {
			ifx_httpdWrite(wp, T("%d"), 4);
			return IFX_SUCCESS;
		}else{
			ifx_httpdWrite(wp, T("%d"), 5);
			return IFX_SUCCESS;
		}
	} else if (!gstrcmp(phy_mode, "4")) {
		ifx_httpdWrite(wp, T("%d"), 8);
		return IFX_SUCCESS;
	} 
#ifdef CONFIG_FEATURE_CELL_WAN_SUPPORT
	else if (!gstrcmp(phy_mode, "5")) {
		ifx_httpdWrite(wp, T("%d"), 6);
		return IFX_SUCCESS;
	}
#endif 
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
	else if (!gstrcmp(phy_mode,"6")){
		ifx_httpdWrite(wp,T("%d"),7);
		return IFX_SUCCESS;
	}
#endif

	ifx_httpdWrite(wp, T("%d"), atoi(phy_mode));
	return IFX_SUCCESS;
}

int dw_cgi_cfg_get(int eid, httpd_t wp, int argc, char_t ** argv)
{

#ifndef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	ifx_httpdWrite(wp, T("\"-1\""));
	return 0;
#else
	dw_config_info_t dw_attr;
	char8 *name = NULL;
	int32 ret;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	memset(&dw_attr, 0, sizeof(dw_config_info_t));

	//Get Dual Wan Config Data From Mapi 
	ret = dw_mapi_cfg_get(&dw_attr, 0);

	if ((ret == IFX_SUCCESS)) {

		if (!gstrcmp(name, "all")) {
			if (dw_attr.fo_state)
				ifx_httpdWrite(wp, T("\"checked\","));	//0
			else
				ifx_httpdWrite(wp, T("\"0\","));

			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.fo_type);	//1 
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.probe_info.probe_int);	//2
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.probe_info.probe_retry);	//3
			ifx_httpdWrite(wp, T("\"%s\","), dw_attr.probe_info.probe_ip_url);	//4

			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.wan_tc);	//5
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.phy_mode);	//6
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.set_wan_tc);	//7
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.set_phy_mode);	//8
#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.ptm_vlan_mode);	//9
#else
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//9
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.eth_vlan_mode);	//10
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.pri_wan_cfg.eth_mii1_vlan_mode);	//11
#else
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//10
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//11
#endif
#endif				// no explicit enable/disable ]

			ifx_httpdWrite(wp, T("\"%d\","), 0);	//9
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//10
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//11
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.sec_wan_cfg.wan_tc);	//12
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.sec_wan_cfg.phy_mode);	//13
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.sec_wan_cfg.set_wan_tc);	//14
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.sec_wan_cfg.set_phy_mode);	//15
#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.sec_wan_cfg.ptm_vlan_mode);	//16
#else
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//16
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\","), dw_attr.sec_wan_cfg.eth_vlan_mode);	//17
			ifx_httpdWrite(wp, T("\"%d\""), dw_attr.sec_wan_cfg.eth_mii1_vlan_mode);	//18
#else
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//17
			ifx_httpdWrite(wp, T("\"%d\""), 0);	//18
#endif
#endif				// no explicit enable/disable ]
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//16
			ifx_httpdWrite(wp, T("\"%d\","), 0);	//17
			ifx_httpdWrite(wp, T("\"%d\""), 0);	//18

			return 0;
		} else if (!gstrcmp(name, DW_FAILOVER)) {
			if (dw_attr.fo_state)
				ifx_httpdWrite(wp, T("\"checked\""));
			else
				ifx_httpdWrite(wp, T("\"0\""));
		} else if (!gstrcmp(name, DW_STANDBY)) {
			ifx_httpdWrite(wp, T("\"%d\""), dw_attr.fo_type);
		} else if (!gstrcmp(name, DW_PROBE_INT)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.probe_info.probe_int);
		} else if (!gstrcmp(name, DW_PROBE_RET)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.probe_info.probe_retry);
		} else if (!gstrcmp(name, DW_IP)) {
			ifx_httpdWrite(wp, T("\"%s\""),
				       dw_attr.probe_info.probe_ip_url);
		}		//                             
		else if (!gstrcmp(name, DW_P_TC)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.pri_wan_cfg.wan_tc);
		} else if (!gstrcmp(name, DW_P_PHY)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.pri_wan_cfg.phy_mode);
		} else if (!gstrcmp(name, DW_P_SETTC)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.pri_wan_cfg.set_wan_tc);
		} else if (!gstrcmp(name, DW_P_SETPHY)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.pri_wan_cfg.set_phy_mode);
		}
#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
		else if (!gstrcmp(name, DW_P_PTM_VLAN)) {
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.pri_wan_cfg.ptm_vlan_mode);
#else
			ifx_httpdWrite(wp, T("\"%d\""), 0);
#endif
		} else if (!gstrcmp(name, DW_P_MII_VLAN)) {
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.pri_wan_cfg.eth_mii1_vlan_mode);
#else
			ifx_httpdWrite(wp, T("\"%d\""), 0);
#endif

		}
#endif				// no explicit enable/disable ]
		//else if (!gstrcmp(name, DW_P_TR69) ) {
		//        ifx_httpdWrite(wp, T("\"%s\""),dw_attr.pri_wan_cfg.tr69_encaprequested);
		//}     
		else if (!gstrcmp(name, DW_S_TC)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.sec_wan_cfg.wan_tc);
		} else if (!gstrcmp(name, DW_S_PHY)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.sec_wan_cfg.phy_mode);
		} else if (!gstrcmp(name, DW_S_SETTC)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.sec_wan_cfg.set_wan_tc);
		} else if (!gstrcmp(name, DW_S_SETPHY)) {
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.sec_wan_cfg.set_phy_mode);
		}
#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
		else if (!gstrcmp(name, DW_S_PTM_VLAN)) {
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.sec_wan_cfg.ptm_vlan_mode);
#else
			ifx_httpdWrite(wp, T("\"%d\""), 0);
#endif

		} else if (!gstrcmp(name, DW_S_MII_VLAN)) {
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
			ifx_httpdWrite(wp, T("\"%d\""),
				       dw_attr.sec_wan_cfg.eth_mii1_vlan_mode);
#else
			ifx_httpdWrite(wp, T("\"%d\""), 0);
#endif
		}
#endif				// no explicit enable/disable ]
		//else if (!gstrcmp(name, DW_S_TR69) ) {
		//        ifx_httpdWrite(wp, T("\"%s\""),dw_attr.sec_wan_cfg.tr69_encaprequested);
		//}     
	} else {
		ifx_httpdError(wp, 500, T("Failed to GET DW Configurations"));
	}
	return 0;
#endif
}

WAN_MODE ifx_get_wan_mode_selected()
{
	char_t sValue[MAX_FILENAME_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	WAN_MODE mode = WAN_MODE_ATM;
	ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
		       IFX_F_DEFAULT, &outFlag, sValue);
	if (*(sValue + 0) == 'e')
	{
		if (*(sValue + 3) == '1')
			mode = WAN_MODE_ETH1;
		else
			mode = WAN_MODE_ETH0;
	}

	else if (*(sValue + 0) == 'p') {
		if (strstr(sValue, "pppoa") != NULL)
			mode = WAN_MODE_ATM;
		else
			mode = WAN_MODE_VDSL_PTM;
	}
	else
		mode = WAN_MODE_ATM;
	return mode;
}

int ifx_get_wan_channel(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	WAN_MODE mode;
	mode = ifx_get_wan_mode_selected();
	ifx_httpdWrite(wp, T("%d"), mode);
	return IFX_SUCCESS;
}


/* Unused function */
#if 0
#ifdef CONFIG_FEATURE_NAPT
int32 ifx_set_virtual_server_delete_Without_TR69(char_t * pWAN_VCC)
{
	int32 ret = IFX_FAILURE, num_entries = 0, operation = 0;
	uint32 flags = IFX_F_DEFAULT;
	int32 i = 0/*, cpeId = 0*/;
	char_t buf[MAX_FILELINE_LEN];
	char_t *wan_conn_names = NULL, wan_conn_name[MAX_NAME_SIZE];
	VIRTUAL_SERVER *virtual = NULL;
	wan_conn_name[0] = '\0';

	if ((ret =
	     ifx_get_virtual_server_info(&num_entries, &virtual,
					 IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get the virtual server info !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	for (i = 0; i < num_entries; i++) {
		//cpeId = (virtual + i)->iid.cpeId.Id;
		gsprintf(buf, T("nat_virtualser_%d_wanConnIf"), i);
		if (strlen((virtual + i)->wan_conn_if) == 0)
			sprintf(wan_conn_name, "%s", "\0");
		else {
			memset(wan_conn_name, 0x00, sizeof(wan_conn_name));
			LTQ_STRNCPY(wan_conn_name, (virtual + i)->wan_conn_if,
				sizeof(wan_conn_name));
			//wan_conn_name[strlen((virtual + i)->wan_conn_if)] = '\0';
		}
		if (!gstrcmp(wan_conn_name, pWAN_VCC)) {	//delete vs entry
			operation = IFX_OP_DEL;
			flags = IFX_F_DELETE | IFX_F_DONT_ACTIVATE;
			ret =
			    ifx_set_virtual_server_info_Without_TR69(operation,
								     (virtual +
								      i),
								     flags);
			if (ret != IFX_SUCCESS) {
				IFX_DBG
				    ("\n\n In Function [%s] : Error--> Failed to delete the virtual server info !!\n\n",
				     __FUNCTION__);
				goto IFX_Handler;
			}

		}
	}
	IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return IFX_SUCCESS;
      IFX_Handler:
	IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return IFX_FAILURE;

}

int32 ifx_set_virtual_server_delete(char_t * pWAN_VCC)
{
	int32 ret = IFX_FAILURE, num_entries = 0, operation = 0;
	uint32 flags = IFX_F_DEFAULT;
	int32 i = 0;
//, cpeId = 0;
	char_t buf[MAX_FILELINE_LEN];
	char_t *wan_conn_names = NULL, wan_conn_name[MAX_NAME_SIZE];
	VIRTUAL_SERVER *virtual = NULL;
	wan_conn_name[0] = '\0';

	if ((ret =
	     ifx_get_virtual_server_info(&num_entries, &virtual,
					 IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get the virtual server info !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	for (i = 0; i < num_entries; i++) {
		//cpeId = (virtual + i)->iid.cpeId.Id;
		gsprintf(buf, T("nat_virtualser_%d_wanConnIf"), i);
		if (strlen((virtual + i)->wan_conn_if) == 0)
			sprintf(wan_conn_name, "%s", "\0");
		else {
			memset(wan_conn_name, 0x00, sizeof(wan_conn_name));
			strncpy(wan_conn_name, (virtual + i)->wan_conn_if,
				strlen((virtual + i)->wan_conn_if));
			wan_conn_name[strlen((virtual + i)->wan_conn_if)] =
			    '\0';
		}
		if (!gstrcmp(wan_conn_name, pWAN_VCC)) {	//delete vs entry
			operation = IFX_OP_DEL;
			flags = IFX_F_DELETE | IFX_F_DONT_ACTIVATE;
			ret =
			    ifx_set_virtual_server_info(operation,
							(virtual + i), flags);
			if (ret != IFX_SUCCESS) {
				IFX_DBG
				    ("\n\n In Function [%s] : Error--> Failed to delete the virtual server info !!\n\n",
				     __FUNCTION__);
				goto IFX_Handler;
			}

		}
	}
	IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return IFX_SUCCESS;
      IFX_Handler:
	IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return IFX_FAILURE;

}

#endif

int32 ifx_set_wan_delete(char_t * Wan_Mode, char_t * pWAN_VCC,
			 char_t * pNewWANIndex)
{
	char_t sWAN_TYPE[10];
//	char_t sWAN_VCC[10];
	int32 operation = IFX_OP_ADD;
	uint32 flags = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN];
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;
	buf[0] = '\0';
//	sWAN_VCC[0] = '\0';
	sWAN_TYPE[0] = '\0';
	memset(&wan_cfg, 0x00, sizeof(wan_cfg));

	//char_t *Wan_Mode = ifx_httpdGetVar(wp, T("wan_mode"), T(""));
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s]:[%d] : Wan Mode is %s, index is [%d]", __FUNCTION__,
		__LINE__, Wan_Mode, atoi(pNewWANIndex));
#endif
	if (!gstrcmp(Wan_Mode, "ATM")) {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		if (mapi_get_wan_config
		    (atoi(pNewWANIndex), &wan_cfg,
		     IFX_F_GET_ENA) != IFX_SUCCESS) {
			//ifx_httpdError(wp, 400, T("Wan index specified does not have a wan connection associated !!\n\n"));
			return -1;
		}
	} else if (!gstrcmp(Wan_Mode, "PTM")) {

		if (mapi_get_wan_config
		    (atoi(pNewWANIndex), &wan_cfg,
		     IFX_F_GET_ENA) != IFX_SUCCESS) {
			//ifx_httpdError(wp, 400, T("Wan index specified does not have a wan connection associated !!\n\n"));
			return -1;
		}
	} else {

		if (mapi_get_wan_config
		    (atoi(pNewWANIndex), &wan_cfg,
		     IFX_F_GET_ENA) != IFX_SUCCESS) {
			//ifx_httpdError(wp, 400, T("Wan index specified does not have a wan connection associated !!\n\n"));
			return -1;
		}
	}
	pWan.wan_index = atoi(pNewWANIndex);

	// set the dns override option to true
	wan_cfg.wandns.WAN_CONN_DNS_OVERRIDE = IFX_ENABLED;

	operation = IFX_OP_DEL;
	flags =
	    IFX_F_DELETE | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;

	sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_MAIN);
	sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	pWan.iid.config_owner = IFX_WEB;
	if (!gstrcmp(Wan_Mode, "ATM")) {

		if (ifx_mapi_set_wan_config(operation, &wan_cfg, flags) !=
		    IFX_SUCCESS) {

			return -1;
		}
		if (pWAN_VCC != NULL && strlen(pWAN_VCC)) {

			sprintf(buf, "ipoption_wan=\"%s\"\nWAN_VCC=\"%s\"\n",
				sWAN_TYPE, pWAN_VCC);
			ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN,
				       IFX_F_MODIFY, 1, buf);
		}
	} else if (!gstrcmp(Wan_Mode, "PTM")) {

		if (ifx_mapi_set_wan_config(operation, &wan_cfg, flags) !=
		    IFX_SUCCESS) {

			return -1;
		}
		sprintf(buf, "ipoption_wan=\"%s\"\nWAN_VCC=\"%d\"\n", sWAN_TYPE,
			pWan.iid.pcpeId.Id);
		ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY,
			       1, buf);
	} else {

		if (ifx_mapi_set_wan_config(operation, &wan_cfg, flags) !=
		    IFX_SUCCESS) {

			return -1;
		}
		sprintf(buf, "ipoption_wan=\"%s\"\nWAN_VCC=\"%d\"\n", sWAN_TYPE,
			pWan.iid.pcpeId.Id);
		ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY,
			       1, buf);
	}
	return 0;
}


int32 ifx_delete_all_ptm_channel()
{
	int num = 0, i = 0, operation = 0;
	uint32 flags = IFX_F_DEFAULT;
	PTM_CH_CFG *ptm_ch = NULL;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
	WAN_CONN_DEV wan_connDev;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	if (ifx_get_all_ptm_info(&num, &ptm_ch, flags) != IFX_SUCCESS) {
		IFX_DBG("[%s] ptm channel info fetch failed", __FUNCTION__);
		IFX_MEM_FREE(ptm_ch);
		return -1;
	}
	if (num != 0) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		for (i = 0; i < num; i++) {
			if (((ptm_ch + i)->vlanId) != 4096) {
				/* Populate the WAN Connection Device and PTM Channel Information */
				wan_connDev.iid.pcpeId.Id = 4;
				wan_connDev.iid.cpeId.Id =
				    (ptm_ch + i)->iid.pcpeId.Id;
				wan_connDev.iid.config_owner = IFX_WEB;
				/* Special Value of VPI/VCI */
				wan_connDev.vc.pvc.vpi = 0;
				wan_connDev.vc.pvc.vci = 0;
				snprintf(wan_connDev.iid.cpeId.secName,
					 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
					 TAG_WAN_CONN_DEVICE);
				snprintf((ptm_ch + i)->iid.cpeId.secName,
					 strlen(TAG_PTM_CHANNEL) + 1, "%s",
					 TAG_PTM_CHANNEL);
				strncpy((ptm_ch + i)->iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				(ptm_ch + i)->iid.config_owner = IFX_WEB;

				if (ifx_set_ptm_ch_cfg
				    (operation, (ptm_ch + i),
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channel delete failed",
					     __FUNCTION__);
					return -1;
				}
				//if((ifx_set_wan_conn_dev_Without_TR69(operation, &wan_connDev, flags)) != IFX_SUCCESS){
				if ((ifx_set_wan_conn_dev
				     (operation, &wan_connDev,
				      flags)) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] wan conn_dev delete failed",
					     __FUNCTION__);
					return -1;
				}
			}
		}
	}
	IFX_MEM_FREE(ptm_ch);
	return 0;
}

int32 ifx_add_ptm_channel()
{

	PTM_CH_CFG ptm_ch;
	WAN_CONN_DEV wan_connDev;
	int operation = 0;
	uint32 flags = IFX_F_DEFAULT;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	operation = IFX_OP_ADD;
	flags = IFX_F_INT_ADD | IFX_F_DONT_WRITE_TO_FLASH;
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
	int ret = -1;
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	ETH_CH_CFG eth_ch;
	memset(&eth_ch, 0x00, sizeof(eth_ch));
#endif

	ptm_ch.ptm_ch_name[0] = '\0';
	ptm_ch.mac_addr[0] = '\0';
	ptm_ch.macOverride = 0;
	ptm_ch.f_enable = 1;
	if (pstWanPhy.ptm_vlan_mode == 1)	//untagged mode
		ptm_ch.vlanId = 0;
	else {			//tagged mode
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
			ptm_ch.vlanId = 5;
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
			ptm_ch.vlanId = 6;
	}
	ptm_ch.preempt = 0;
	wan_connDev.iid.pcpeId.Id = 1;	// WANDEVICE 1 
	wan_connDev.iid.config_owner = IFX_WEB;
	wan_connDev.vc.pvc.vpi = 256;
	wan_connDev.vc.pvc.vci = 0;
	snprintf(wan_connDev.iid.cpeId.secName, strlen(TAG_WAN_CONN_DEVICE) + 1,
		 "%s", TAG_WAN_CONN_DEVICE);
	if ((ifx_set_wan_conn_dev(operation, &wan_connDev, flags)) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Trying to get the ptm connection device iid !!\n\n",
		     __FUNCTION__);
#endif
		return -1;
	}
	snprintf(ptm_ch.iid.cpeId.secName, strlen(TAG_PTM_CHANNEL) + 1, "%s",
		 TAG_PTM_CHANNEL);
	ptm_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	strncpy(ptm_ch.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
		strlen(wan_connDev.iid.pcpeId.secName));
	ptm_ch.iid.config_owner = IFX_WEB;
	if (ifx_set_ptm_ch_cfg(operation, &ptm_ch, flags) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Trying to get the ptm connection device iid !!\n\n",
		     __FUNCTION__);
		return -1;
	}
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	/* ATM F5 Object created along with channel addition */
	atmf5_diag.iid.config_owner = IFX_WEB;
	atmf5_diag.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	atmf5_diag.vpi = 256;
	sprintf(atmf5_diag.iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
	sprintf(atmf5_diag.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
	ret =
	    ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD, &atmf5_diag,
					   flags | IFX_F_DONT_ACTIVATE);
	if (ret != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Failed to add the atmf5 object !!\n\n",
		     __FUNCTION__);
		return -1;
	}
	vcc.vc.pvc.vpi = 256;
	snprintf(vcc.iid.cpeId.secName, strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
		 TAG_ADSL_VCCHANNEL);
	vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	strncpy(vcc.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
		strlen(wan_connDev.iid.pcpeId.secName));
	vcc.iid.config_owner = IFX_WEB;
	/* call the api to update the adsl vcchannel section for this vpi/vci */
	ret = ifx_set_vcc_cfg(IFX_OP_ADD, &vcc, flags | IFX_F_DONT_ACTIVATE);
	if (ret == IFX_FAILURE) {
		IFX_DBG
		    ("\n\n In Function [%s] : Failed to add the dummy atm channel object !!\n\n",
		     __FUNCTION__);
		return -1;
	}
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	eth_ch.vlanId = 4096;
	snprintf(eth_ch.iid.cpeId.secName, strlen(TAG_ETH_CHANNEL) + 1, "%s",
		 TAG_ETH_CHANNEL);
	eth_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	strncpy(eth_ch.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
		strlen(wan_connDev.iid.pcpeId.secName));
	eth_ch.iid.config_owner = IFX_WEB;
	/* call the api to update the adsl vcchannel section for this vpi/vci */
	ret =
	    ifx_set_eth_ch_cfg(IFX_OP_ADD, &eth_ch,
			       flags | IFX_F_DONT_ACTIVATE);
	if (ret == IFX_FAILURE) {
		IFX_DBG
		    ("\n\n In Function [%s] : Failed to add the eth channel object !!\n\n",
		     __FUNCTION__);
		return -1;
	}
#endif
	return 0;
}

int32 ifx_add_ptm_wan()
{
	int32 ret = -1;
	uint32 outFlag = IFX_F_DEFAULT;
	int32 dist_wan_index = -1;
	char8 sNewWAN[16] = { 0 };
	char_t *pNewWANIndex = NULL, buf[MAX_FILELINE_LEN];
	int num = 0, operation = 0;
	uint32 i = 0, flags = IFX_F_DEFAULT;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	PTM_CH_CFG *ptm_ch = NULL;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
	char8 sValue[MAX_FILELINE_LEN];
	buf[0] = '\0';
// wan connection does not exist
// search for empty wan to use
	if (ifx_get_available_distinct_index
	    (FILE_RC_CONF, TAG_WAN_MAIN, "index", MIN_WAN_INDEX, MAX_WAN_INDEX,
	     &dist_wan_index) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] dist_wan_index -> %d", __FUNCTION__, __LINE__,
		dist_wan_index);
#endif
	if (dist_wan_index > 14) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error : You cannot configure more than 14 WAN connections</span>");
		goto IFX_Handler;
	}
	snprintf(sNewWAN, sizeof(sNewWAN), "WAN%d", dist_wan_index);
	ret = ifx_get_wan_port(sNewWAN);
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] dist_wan_index -> %d sNewWAN -> %s", __FUNCTION__,
		__LINE__, dist_wan_index, sNewWAN);
#endif
	if (ret == -1) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d:%s]", __FUNCTION__, __LINE__,
			"ifx_get_wan_port");
#endif
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error : Please delete portmap entries for this WAN first.</span>");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	pNewWANIndex = sNewWAN + 3;
	if (pNewWANIndex) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] pNewWANIndex -> %s", __FUNCTION__, __LINE__,
			pNewWANIndex);
#endif
		sprintf(sValue, "WAN_VCC=\"%s\"\n", pNewWANIndex);
		ifx_SetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select",
			       IFX_F_MODIFY, 1, sValue);
	}

	if (ifx_get_all_ptm_info(&num, &ptm_ch, flags) != IFX_SUCCESS) {
		IFX_DBG("[%s] ptm channel info fetch failed", __FUNCTION__);
		IFX_MEM_FREE(ptm_ch);
		goto IFX_Handler;
	}
	for (i = 0; i < num; i++) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]  ((ptm_ch+i)->vlanId) -> %d ", __FUNCTION__,
			__LINE__, (ptm_ch + i)->iid.pcpeId.Id);
#endif
		if (((ptm_ch + i)->vlanId) != 4096) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] pcpeId -> %d vlanid -> %d",
				__FUNCTION__, __LINE__,
#endif
				(ptm_ch + i)->iid.pcpeId.Id,
				((ptm_ch + i)->vlanId));
			if ((((ptm_ch + i)->vlanId == 0) && (pstWanPhy.ptm_vlan_mode == 1)) || (((ptm_ch + i)->vlanId == 5 || (ptm_ch + i)->vlanId == 6) && (pstWanPhy.ptm_vlan_mode == 0))) {	//New Ptm channel instance on which WAN connection has to be formed
				memset(&buf, 0x00, sizeof(buf));
				memset(&sValue, 0x00, sizeof(sValue));

				sprintf(buf, "PtmChannel_%d_pcpeId", i);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_PTM_CHANNEL, buf, flags,
				     &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("In function [%s] : Error--> Trying to get the [%s] in [%s] !!",
					     __FUNCTION__, sBuf,
					     TAG_PTM_CHANNEL);
#endif
					goto IFX_Handler;
				}

				IFX_DBG
				    ("[%s:%d] (ptm_ch+i)->iid.pcpeId.Id -> %d",
				     __FUNCTION__, __LINE__,
				     (ptm_ch + i)->iid.pcpeId.Id);
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] sValue -> %d", __FUNCTION__,
					__LINE__, atoi(sValue));
#endif
				//sprintf(buf, "ipoption_wan=\"PPPOE\"\nWAN_VCC=\"PTM%u\"\n", (ptm_ch+i)->iid.pcpeId.Id);
				snprintf(buf, sizeof(buf),
					 "ipoption_wan=\"PPPOE\"\nWAN_VCC=\"PTM%u\"\n",
					 atoi(sValue));
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN,
					       IFX_F_MODIFY, 1, buf);
				WAN_COMMON_CFG wan_com;
				WAN_CONN_CFG wan_cfg;
				WAN_PPP_CONFIG wan_pppc;
				memset(&wan_cfg, 0x00, sizeof(wan_cfg));
				memset(&wan_com, 0x00, sizeof(wan_com));
				memset(&wan_pppc, 0x00, sizeof(wan_pppc));
				operation = IFX_OP_ADD;
				flags =
				    IFX_F_INT_ADD | IFX_F_INT_DONT_CONFIGURE |
				    IFX_F_DONT_WRITE_TO_FLASH;
				GET_GLOBAL_RIP_LISTEN_MODE(wan_cfg.wancfg.ppp.
							   wan_cfg.route_rx)
				    /* set the link type to pppoe */
				    wan_cfg.type = WAN_LINK_TYPE_PPPOE;
				/* Set the wan index */
				wan_com.wan_index = dist_wan_index;
				//if(ptm_vlan_mode==1)//untagged mode
				gstrcpy(wan_com.wan_mode.iface, "ptm0");
				//else
				//gstrcpy(wan_cfg.wan_mode.iface,"ptm0.200");
				gstrcpy(wan_cfg.WAN_PPP_CONN.WAN_CONN.
					WAN_CONN_NAME, sNewWAN);
#ifdef CONFIG_FEATURE_RIP
				/* Set RIP information based on the Global RIP State & Listen Mode */
				ifx_set_wanif_route_proto(dist_wan_index,
							  &wan_cfg.WAN_PPP_CONN.
							  WAN_CONN);
#endif
				wan_cfg.WAN_PPP_CONN.WAN_CONN.f_enable =
				    IFX_ENABLED;
				wan_pppc.WAN_CONN_TRIGGER =
				    CONN_TRIGGER_ALWAYS_ON;
//              wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_ALWAYS_ON; 
				wan_cfg.WAN_PPP_CONN.conn_type =
				    WAN_PPP_CONN_TYPE_IP_ROUTED;
				/* set the dns override option to true */
				wan_cfg.wandns.WAN_CONN_DNS_OVERRIDE =
				    IFX_ENABLED;
				wan_cfg.WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_CONNECTING;
#ifdef CONFIG_FEATURE_NAPT
				/* Currently we set the NAT on interface level as always ENABLED
				 * Once the interface level option is configurable, then it can be put here */
				wan_cfg.WAN_PPP_CONN.WAN_CONN.
				    WAN_CONN_NAT_ENABLED = IFX_ENABLED;
#endif
				wan_cfg.WAN_PPP_CONN.max_mru_size = 1492;
				sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_name,
					"subbi");
				sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_passwd,
					"subbi");
				wan_cfg.WAN_PPP_CONN.pppoe_service_name[0] =
				    '\0';
				wan_cfg.WAN_PPP_CONN.pppoe_ac_name[0] = '\0';
				wan_com.max_mtu = 1492;
				wan_cfg.WAN_PPP_CONN.bridge_enable = 0;
				wan_com.iid.config_owner = IFX_WEB;
				ret =
				    ifx_cgi_set_wan_config(operation, &wan_cfg,
							   flags);
				if (ret != IFX_SUCCESS) {
					IFX_DBG("[%s] ptm set wan failed",
						__FUNCTION__);
					return -1;
				}
				return 0;
			}
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]  ((ptm_ch+i)->vlanId) -> %d ", __FUNCTION__,
			__LINE__, (ptm_ch + i)->iid.pcpeId.Id);
#endif
	}
      IFX_Handler:
	IFX_MEM_FREE(ptm_ch);
	return -1;
}

int32 ifx_set_ptm_vlan_wan_display()
{
	char8 sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32 flags = IFX_F_GET_ANY, outFlag = IFX_F_DEFAULT;
	int operation1 = IFX_OP_DEL;
	int32 i = 0, *idx_array = NULL, idx_count = 0, ret = -2;
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG wan_com;
	char8 *retVal = NULL;
	char_t *pWAN_VCC = NULL, *pWan_Mode = NULL;
	char_t *pNewWANIndex = NULL;
	char8 conn_name[MAX_CONN_NAME_LEN];
	conn_name[0] = '\0';
	sValue[0] = '\0';
	sBuf[0] = '\0';
	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	memset(&wan_com, 0x00, sizeof(wan_com));
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
#endif

	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	PTM_CH_CFG ptm_ch1;
	memset(&ptm_ch1, 0x00, sizeof(ptm_ch1));
	WAN_CONN_DEV wan_connDev;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	sprintf(sBuf, "%s", "wan_main_index");
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_MAIN, sBuf, flags, &outFlag,
	     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In function [%s] : Error--> Trying to get the [%s] in [%s] !!",
		     __FUNCTION__, sBuf, TAG_WAN_MAIN);
#endif
		goto IFX_Handler;
	}
	get_wan_indices(sValue, &idx_count, &idx_array);
	for (i = 0; i < idx_count; i++) {	//loop through all WAN connections 
		if (mapi_get_wan_config
		    ((*(idx_array + i)), &wan_cfg,
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s] ptm config fetch failed", __FUNCTION__);
#endif
			//goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s] ptm config fetch suceeded", __FUNCTION__);
#endif
			if ((pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
			     && wan_com.wan_mode.mode == WAN_MODE_PTM)
			    || (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2
				&& wan_com.wan_mode.mode ==
				WAN_MODE_VDSL_PTM)) {
				if (wan_cfg.type == WAN_LINK_TYPE_PPPOE) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] ptm pppoe",
						__FUNCTION__, __LINE__);
#endif
					strcpy(conn_name,
					       wan_cfg.WAN_PPP_CONN.WAN_CONN.
					       WAN_CONN_NAME);
				} else {
					strcpy(conn_name,
					       wan_cfg.WAN_IP_CONN.WAN_CONN.
					       WAN_CONN_NAME);
				}
				pNewWANIndex = conn_name + 3;
#ifdef CONFIG_FEATURE_NAPT
				//ret=ifx_get_wan_port(conn_name);
				//if (ret == -1){//delete VS entries
				ret = -2;
				//ret=ifx_set_virtual_server_delete_Without_TR69(conn_name);
				ret = ifx_mapi_set_all_virtual_server_delete();
				if (ret != 0) {
					IFX_DBG
					    ("[%s] Virtual Server deletion on WAN deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				//}
#endif
				ret = -2;
				gstrcpy(sValue, "PTM");
				pWan_Mode = sValue;
				ret = ifx_set_wan_delete(pWan_Mode, pWAN_VCC, pNewWANIndex);	//delete WAN connection
				if (ret != 0) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s] WAN deletion failed",
						__FUNCTION__);
#endif
					goto IFX_Handler;
				}
				//Delete corresponding Ptm Channel
				operation1 = IFX_OP_DEL;
				flags =
				    IFX_F_DELETE | IFX_F_DONT_WRITE_TO_FLASH;
				ptm_ch1.vlanId = wan_cfg.vlanId;
				wan_connDev.iid.cpeId.Id =
				    wan_com.iid.pcpeId.Id;
				wan_connDev.iid.config_owner = IFX_WEB;
				wan_connDev.vc.pvc.vpi = 0;
				wan_connDev.vc.pvc.vci = 0;
				snprintf(wan_connDev.iid.cpeId.secName,
					 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
					 TAG_WAN_CONN_DEVICE);
				/* Populate the Ptm Channel information */
				ptm_ch1.iid.pcpeId.Id = wan_com.iid.pcpeId.Id;
				snprintf(ptm_ch1.iid.cpeId.secName,
					 strlen(TAG_PTM_CHANNEL) + 1, "%s",
					 TAG_PTM_CHANNEL);
				strncpy(ptm_ch1.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				ptm_ch1.iid.config_owner = IFX_WEB;
				//Delete corresponding Eth Channel
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
				ETH_CH_CFG eth_ch1;
				memset(&eth_ch1, 0x00, sizeof(eth_ch1));
				eth_ch1.vlanId = 4096;
				eth_ch1.iid.pcpeId.Id = wan_com.iid.pcpeId.Id;
				snprintf(ptm_ch1.iid.cpeId.secName,
					 strlen(TAG_ETH_CHANNEL) + 1, "%s",
					 TAG_ETH_CHANNEL);
				strncpy(eth_ch1.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				eth_ch1.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    wan_connDev.iid.cpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_ETH_CHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channel pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ETH_CHANNEL, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channel cpeId fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				eth_ch1.iid.cpeId.Id = atoi(sValue);
				if (ifx_set_eth_ch_cfg
				    (operation1, &eth_ch1,
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s:%d] Error deleting eth channel entry",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}
#endif
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT

				int outFlag = IFX_F_DEFAULT;
				ATM_VCC_INFO vcc;
				WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
				memset(&vcc, 0x00, sizeof(vcc));
				memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));

				/* deletion of corresponding dummy atm channel */

				memset(&vcc, 0x00, sizeof(vcc));

				snprintf(vcc.iid.cpeId.secName,
					 strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
					 TAG_ADSL_VCCHANNEL);

				vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;

				strncpy(vcc.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));

				vcc.iid.config_owner = IFX_WEB;

				IFX_MEM_FREE(retVal)

				    sprintf(sValue, "%d", vcc.iid.pcpeId.Id);

				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_ADSL_VCCHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {

					IFX_DBG
					    ("[%s:%d] Failed to find the pcpeid for corresponding vcc channel!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;

				}

				sprintf(sBuf, "%s_cpeId", retVal);

				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sBuf,
				     IFX_F_GET_ENA,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {

					IFX_DBG
					    ("[%s:%d] Failed to find the cpeid for corresponding vcc channel!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;

				}

				vcc.iid.cpeId.Id = atoi(sValue);

#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\n In Function [%s:%d]  vcc.iid.cpeId.Id -> %d\n\n",
				     __FUNCTION__, __LINE__, vcc.iid.cpeId.Id);
#endif
				ret = ifx_set_vcc_cfg(operation1, &vcc, flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s:%d] Error deleting corresponding vc channel entry !!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}

				/* deletion of corresponding dummy atm f5 object */

				memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));

				snprintf(vcc.iid.cpeId.secName,
					 strlen(TAG_WAN_ATMF5) + 1, "%s",
					 TAG_WAN_ATMF5);

				atmf5_diag.iid.pcpeId.Id =
				    wan_connDev.iid.cpeId.Id;

				strncpy(atmf5_diag.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));

				atmf5_diag.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    atmf5_diag.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_WAN_ATMF5,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {

					IFX_DBG
					    ("[%s:%d] Failed to find the pcpeid for corresponding atm f5 channel!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_ATMF5, sBuf,
				     IFX_F_GET_ENA,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {

					IFX_DBG
					    ("[%s:%d] Failed to find the cpeid for corresponding atm f5 channel!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}
				atmf5_diag.iid.cpeId.Id = atoi(sValue);
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\n In Function [%s:%d]  atmf5_diag.iid.cpeId.Id  -> %d\n\n",
				     __FUNCTION__, __LINE__,
				     atmf5_diag.iid.cpeId.Id);
#endif
				ret =
				    ifx_set_atmf5_loop_diagnostics(operation1,
								   &atmf5_diag,
								   flags);
				if (ret == IFX_FAILURE) {

					IFX_DBG
					    ("[%s:%d] Error deleting corresponding atm f5 entry !!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;

				}
#endif

				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    wan_connDev.iid.cpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_PTM_CHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channel pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}

				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_PTM_CHANNEL, sBuf,
				     IFX_F_GET_ENA,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channel cpeId fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				ptm_ch1.iid.cpeId.Id = atoi(sValue);
				if (ifx_set_ptm_ch_cfg
				    (operation1, &ptm_ch1,
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channels deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				if ((ret =
				     ifx_set_wan_conn_dev(operation1,
							  &wan_connDev,
							  flags)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm wan_conn_dev deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
			}
		}
	}
	//All free Ptm  Channel deletion and wan_conn_dev deletion
	ret = -2;
	gstrcpy(sValue, "PTM");
	pWan_Mode = sValue;
	ret = ifx_delete_all_free_channel(pWan_Mode);
	if (ret != 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] ptm channels deletion failed", __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	//Create a PTM channel
	ret = -2;
	ret = ifx_add_ptm_channel();
	if (ret != 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] Ptm channel addition failed", __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	//Create PTM WAN PPPoE connection
	ret = -2;
	ret = ifx_add_ptm_wan();
	if (ret != 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] Ptm WAN addition failed", __FUNCTION__);
#endif
		goto IFX_Handler;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s] Ptm WAN addition success ret -> %d", __FUNCTION__, ret);
#endif
      IFX_Handler:
	IFX_MEM_FREE(idx_array)
	    IFX_MEM_FREE(retVal)
	    return ret;
}

int32 ifx_delete_all_free_channel(char_t * Wan_Mode)
{
	int operation = IFX_OP_DEL;
	int32 ret = -2;
	uint32 i = 0, num = 0, flags = IFX_F_DELETE | IFX_F_DONT_WRITE_TO_FLASH;
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
	ETH_CH_CFG *eth_ch = NULL;
#endif
	char_t sBuf[MAX_FILELINE_LEN];
	char8 *retVal = NULL;
	WAN_CONN_DEV wan_connDev;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
	PTM_CH_CFG *ptm_ch = NULL;
	PTM_CH_CFG ptm_ch1;
	memset(&ptm_ch1, 0x00, sizeof(ptm_ch1));
#endif
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
	char_t sValue[MAX_FILELINE_LEN];
	sValue[0] = '\0';
	uint32 outFlag = IFX_F_DEFAULT;
#endif
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
	if (ifx_get_all_eth_info((int32 *) & num, &eth_ch, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		IFX_DBG("[%s] eth channel config fetch failed", __FUNCTION__);
		goto IFX_Handler;
	}
#endif
	if (!gstrcmp(Wan_Mode, "ETH")) {	//delete MII0/MII1 free Eth channels
#if 0
		if (ifx_get_all_eth_info
		    ((int32 *) & num, &eth_ch, IFX_F_DEFAULT) != IFX_SUCCESS) {
			IFX_DBG("[%s] eth channel config fetch failed",
				__FUNCTION__);
			goto IFX_Handler;
		}
#endif
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
		for (i = 0; i < num; i++) {
			if (((eth_ch + i)->vlanId) != 4096) {

				/* Check if the selected Ethernet Channel has any WAN Connections configured on it. If so check for other eth channel instance */
				sprintf(sBuf, "%u", (eth_ch + i)->vlanId);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_WAN_MAIN,
								   "vlanId",
								   sBuf,
								   &retVal)) ==
				    IFX_SUCCESS) {
					continue;
				}
				//delete free eth channels
				wan_connDev.iid.cpeId.Id =
				    (eth_ch + i)->iid.pcpeId.Id;
				wan_connDev.iid.config_owner = IFX_WEB;
				wan_connDev.vc.pvc.vpi = 0;
				wan_connDev.vc.pvc.vci = 0;
				snprintf(wan_connDev.iid.cpeId.secName,
					 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
					 TAG_WAN_CONN_DEVICE);
				/* Populate the Ethernet Channel information */
				snprintf((eth_ch + i)->iid.cpeId.secName,
					 strlen(TAG_ETH_CHANNEL) + 1, "%s",
					 TAG_ETH_CHANNEL);
				strncpy((eth_ch + i)->iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				(eth_ch + i)->iid.config_owner = IFX_WEB;
				/* delete dummy ptm wan channel section */
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
				memset(&ptm_ch1, 0x00, sizeof(ptm_ch1));
				ptm_ch1.iid.config_owner = IFX_WEB;
				ptm_ch1.iid.pcpeId.Id =
				    wan_connDev.iid.cpeId.Id;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    ptm_ch1.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_PTM_CHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s:%d] Failed to find the pcpeid for ptm channel!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}

				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_PTM_CHANNEL, sBuf,
				     IFX_F_GET_ENA,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s:%d] Failed to find the cpeid for ptm channel!!",
					     __FUNCTION__, __LINE__);
					IFX_MEM_FREE(retVal)
					    goto IFX_Handler;
				}
				ptm_ch1.iid.cpeId.Id = atoi(sValue);
				sprintf(ptm_ch1.iid.cpeId.secName, "%s",
					TAG_PTM_CHANNEL);
				sprintf(ptm_ch1.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				ret =
				    ifx_set_ptm_ch_cfg(IFX_OP_DEL, &ptm_ch1,
						       flags);
				if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("In Function [%s] : Failed to set wan ptm channel config !!",
					     __FUNCTION__);
#endif
					IFX_DBG
					    ("[%s:%d] Error deleting ptm channel entry!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}
#endif

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
				/* deletion of corresponding dummy atm channel */
				memset(&vcc, 0x00, sizeof(vcc));
				snprintf(vcc.iid.cpeId.secName,
					 strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
					 TAG_ADSL_VCCHANNEL);
				vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
				strncpy(vcc.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				vcc.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d", vcc.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_ADSL_VCCHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] vc channel pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] vc channel cpeId fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				vcc.iid.cpeId.Id = atoi(sValue);
				IFX_DBG
				    ("\n\n In Function [%s:%d]  vcc.iid.cpeId.Id -> %d\n\n",
				     __FUNCTION__, __LINE__, vcc.iid.cpeId.Id);
				ret = ifx_set_vcc_cfg(operation, &vcc, flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s] error deleting vc channel entry",
					     __FUNCTION__);
					goto IFX_Handler;
				}

				/* deletion of corresponding dummy atm f5 object */
				memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
				snprintf(atmf5_diag.iid.cpeId.secName,
					 strlen(TAG_WAN_ATMF5) + 1, "%s",
					 TAG_WAN_ATMF5);
				atmf5_diag.iid.pcpeId.Id =
				    wan_connDev.iid.cpeId.Id;
				strncpy(atmf5_diag.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				atmf5_diag.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    atmf5_diag.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_WAN_ATMF5,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] atmf5 pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_ATMF5, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG("[%s] atmf5 cpeId fetch failed",
						__FUNCTION__);
					goto IFX_Handler;
				}
				atmf5_diag.iid.cpeId.Id = atoi(sValue);
				IFX_DBG
				    ("\n\n In Function [%s:%d]  atmf5_diag.iid.cpeId.Id  -> %d\n\n",
				     __FUNCTION__, __LINE__,
				     atmf5_diag.iid.cpeId.Id);
				ret =
				    ifx_set_atmf5_loop_diagnostics(operation,
								   &atmf5_diag,
								   flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s] Error deleting corresponding atm f5 object",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#endif
				/* Delete the Ethernet Channel & WAN Connection Device entires */

				if (ifx_set_eth_ch_cfg
				    (operation, (eth_ch + i),
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth mii1 channels deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				if ((ret =
				     ifx_set_wan_conn_dev(operation,
							  &wan_connDev,
							  flags)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth mii1 wan_conn_dev deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}

			}
		}
		IFX_MEM_FREE(eth_ch);
#endif
		return IFX_SUCCESS;
	} else if (!gstrcmp(Wan_Mode, "PTM")) {	//delete ADSL/VDSL free ptm channels
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
		if (ifx_get_all_ptm_info
		    ((int32 *) & num, &ptm_ch, IFX_F_DEFAULT) != IFX_SUCCESS) {
			IFX_DBG("[%s] ptm channel config fetch failed",
				__FUNCTION__);
			goto IFX_Handler;
		}
		for (i = 0; i < num; i++) {
			if (((ptm_ch + i)->vlanId) != 4096) {
				/* Check if the selected PTM Channel has any WAN Connections configured on it. If any check for other ptm channel instance */
				sprintf(sBuf, "%u", (ptm_ch + i)->vlanId);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_WAN_MAIN,
								   "vlanId",
								   sBuf,
								   &retVal)) ==
				    IFX_SUCCESS) {
					continue;
				}
				//delete free ptm channels
				wan_connDev.iid.cpeId.Id =
				    (ptm_ch + i)->iid.pcpeId.Id;
				wan_connDev.iid.config_owner = IFX_WEB;
				wan_connDev.vc.pvc.vpi = 0;
				wan_connDev.vc.pvc.vci = 0;
				snprintf(wan_connDev.iid.cpeId.secName,
					 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
					 TAG_WAN_CONN_DEVICE);
				/* Populate the Ptm Channel information */
				snprintf((ptm_ch + i)->iid.cpeId.secName,
					 strlen(TAG_PTM_CHANNEL) + 1, "%s",
					 TAG_PTM_CHANNEL);
				strncpy((ptm_ch + i)->iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				(ptm_ch + i)->iid.config_owner = IFX_WEB;
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
				/* deletion of corresponding dummy atm channel */
				memset(&vcc, 0x00, sizeof(vcc));
				snprintf(vcc.iid.cpeId.secName,
					 strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
					 TAG_ADSL_VCCHANNEL);
				vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
				strncpy(vcc.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				vcc.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d", vcc.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_ADSL_VCCHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] vc channel pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] vc channel cpeId fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				vcc.iid.cpeId.Id = atoi(sValue);
				IFX_DBG
				    ("\n\n In Function [%s:%d]  vcc.iid.cpeId.Id -> %d\n\n",
				     __FUNCTION__, __LINE__, vcc.iid.cpeId.Id);
				ret = ifx_set_vcc_cfg(operation, &vcc, flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s] error deleting vc channel entry",
					     __FUNCTION__);
					goto IFX_Handler;
				}

				/* deletion of corresponding dummy atm f5 object */
				memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
				snprintf(atmf5_diag.iid.cpeId.secName,
					 strlen(TAG_WAN_ATMF5) + 1, "%s",
					 TAG_WAN_ATMF5);
				atmf5_diag.iid.pcpeId.Id =
				    wan_connDev.iid.cpeId.Id;
				strncpy(atmf5_diag.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				atmf5_diag.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    atmf5_diag.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_WAN_ATMF5,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] atmf5 pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_ATMF5, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG("[%s] atmf5 cpeId fetch failed",
						__FUNCTION__);
					goto IFX_Handler;
				}
				atmf5_diag.iid.cpeId.Id = atoi(sValue);
				IFX_DBG
				    ("\n\n In Function [%s:%d]  atmf5_diag.iid.cpeId.Id  -> %d\n\n",
				     __FUNCTION__, __LINE__,
				     atmf5_diag.iid.cpeId.Id);
				ret =
				    ifx_set_atmf5_loop_diagnostics(operation,
								   &atmf5_diag,
								   flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s] Error deleting corresponding atm f5 object",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#endif

				/* deletion of corresponding dummy ethernet channel */
				/* Populate the Ethernet Channel information */
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
				snprintf((eth_ch + i)->iid.cpeId.secName,
					 strlen(TAG_ETH_CHANNEL) + 1, "%s",
					 TAG_ETH_CHANNEL);
				strncpy((eth_ch + i)->iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				if (eth_ch != NULL)
					(eth_ch + i)->iid.config_owner =
					    IFX_WEB;

				if (ifx_set_eth_ch_cfg
				    (operation, (eth_ch + i),
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth channels deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#endif

				/* Delete the Ptm Channel & WAN Connection Device entires */

				if (ifx_set_ptm_ch_cfg
				    (operation, (ptm_ch + i),
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm channels deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				if ((ret =
				     ifx_set_wan_conn_dev(operation,
							  &wan_connDev,
							  flags)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] ptm wan_conn_dev deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}

			}
		}
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
		IFX_MEM_FREE(eth_ch);
#endif
		IFX_MEM_FREE(ptm_ch);
#endif
		return IFX_SUCCESS;

	}

      IFX_Handler:
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	IFX_MEM_FREE(eth_ch);
#endif
	IFX_MEM_FREE(retVal);
	return IFX_FAILURE;
}


/* Unused function */
int32 ifx_add_eth_channel()
{
	ETH_CH_CFG eth_ch;
	memset(&eth_ch, 0x00, sizeof(eth_ch));
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
	PTM_CH_CFG ptm_ch;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
#endif
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
	int ret = -1;
#endif
	WAN_CONN_DEV wan_connDev;
	char8 sValue[MAX_FILELINE_LEN];
	sValue[0] = '\0';
	uint32 outFlag = IFX_F_DEFAULT;
	int operation = 0;
	uint32 flags =
	    IFX_F_DEFAULT | IFX_F_DONT_WRITE_TO_FLASH | IFX_F_INT_ADD;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	operation = IFX_OP_ADD;
	if (ifx_GetObjData
	    (FILE_RC_CONF, "eth_channel", "eth_channel_Count", IFX_F_GET_ANY,
	     &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In function [%s] : Error--> Trying to get the eth_channel_Count in eth_channel section !!");
#endif
	}
	// sprintf(eth_ch.eth_ch_name,"eth_chan_%d",atoi(sValue));
	eth_ch.eth_ch_name[0] = '\0';
	eth_ch.mac_addr[0] = '\0';
	eth_ch.macOverride = 0;
	eth_ch.f_enable = 1;
	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {	//mii1 mode
		wan_connDev.iid.pcpeId.Id = 3;	//WAN DEVICE 3
		if (pstWanPhy.eth_mii1_vlan_mode == 1)	//untagged mode
			eth_ch.vlanId = 0;
		else
			eth_ch.vlanId = 3;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) {	//mii0 mode
		wan_connDev.iid.pcpeId.Id = 2;	//WAN DEVICE 2
		if (pstWanPhy.eth_vlan_mode == 1)	//untagged mode
			eth_ch.vlanId = 4;
		else
			eth_ch.vlanId = 4;
	}
	wan_connDev.iid.config_owner = IFX_WEB;
	wan_connDev.vc.pvc.vpi = 256;
	wan_connDev.vc.pvc.vci = 0;
	snprintf(wan_connDev.iid.cpeId.secName, strlen(TAG_WAN_CONN_DEVICE) + 1,
		 "%s", TAG_WAN_CONN_DEVICE);
	if ((ifx_set_wan_conn_dev(operation, &wan_connDev, flags)) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Trying to get the eth connection device iid !!\n\n",
		     __FUNCTION__);
#endif
		return -1;
	}
	snprintf(eth_ch.iid.cpeId.secName, strlen(TAG_ETH_CHANNEL) + 1, "%s",
		 TAG_ETH_CHANNEL);
	eth_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	strncpy(eth_ch.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
		strlen(wan_connDev.iid.pcpeId.secName));
	eth_ch.iid.config_owner = IFX_WEB;
	if (ifx_set_eth_ch_cfg(operation, &eth_ch, flags) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Trying to set eth channel !!\n\n",
		     __FUNCTION__);
		return -1;
	}
#ifdef  CONFIG_FEATURE_PTM_WAN_SUPPORT
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
	gstrcpy(ptm_ch.ptm_ch_name, "");
	gstrcpy(ptm_ch.mac_addr, "");
	ptm_ch.vlanId = 4096;
	ptm_ch.preempt = 0;
	snprintf(ptm_ch.iid.cpeId.secName, strlen(TAG_PTM_CHANNEL) + 1, "%s",
		 TAG_PTM_CHANNEL);
	ptm_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	strncpy(ptm_ch.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
		strlen(wan_connDev.iid.pcpeId.secName));

	ptm_ch.iid.config_owner = IFX_WEB;
	/* call the api to update the eth channel section  */

	ret =
	    ifx_set_ptm_ch_cfg(IFX_OP_ADD, &ptm_ch,
			       flags | IFX_F_DONT_ACTIVATE);
	if (ret != IFX_SUCCESS) {
		IFX_DBG
		    ("In Function [%s] : Failed to set wan ptm channel config !!",
		     __FUNCTION__);
	}
#endif

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	/* ATM F5 Object created along with channel addition */
	atmf5_diag.iid.config_owner = IFX_WEB;
	atmf5_diag.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	atmf5_diag.vpi = 256;
	sprintf(atmf5_diag.iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
	sprintf(atmf5_diag.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
	ret =
	    ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD, &atmf5_diag,
					   flags | IFX_F_DONT_ACTIVATE);
	if (ret != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Failed to add the atmf5 object !!\n\n",
		     __FUNCTION__);
		return -1;
	}
	vcc.vc.pvc.vpi = 256;
	snprintf(vcc.iid.cpeId.secName, strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
		 TAG_ADSL_VCCHANNEL);
	vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
	strncpy(vcc.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
		strlen(wan_connDev.iid.pcpeId.secName));
	vcc.iid.config_owner = IFX_WEB;
	/* call the api to update the adsl vcchannel section for this vpi/vci */
	ret = ifx_set_vcc_cfg(IFX_OP_ADD, &vcc, flags | IFX_F_DONT_ACTIVATE);
	if (ret == IFX_FAILURE) {
		IFX_DBG
		    ("\n\n In Function [%s] : Failed to add the dummy atm channel object !!\n\n",
		     __FUNCTION__);
		return -1;
	}
#endif
	return 0;
}

int32 ifx_add_eth_wan()
{
	int32 ret = -1;
	int32 dist_wan_index = -1;
	char8 sNewWAN[16] = { 0 };
	char_t *pNewWANIndex = NULL, buf[MAX_FILELINE_LEN];
	int num = 0, operation = 0;
	uint32 i = 0, flags = IFX_F_DEFAULT;
	ETH_CH_CFG *eth_ch = NULL;
	memset(&eth_ch, 0x00, sizeof(eth_ch));
	char8 sValue[MAX_FILELINE_LEN];
	buf[0] = '\0';
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
// wan connection does not exist
// search for empty wan to use
	if (ifx_get_available_distinct_index
	    (FILE_RC_CONF, TAG_WAN_MAIN, "index", MIN_WAN_INDEX, MAX_WAN_INDEX,
	     &dist_wan_index) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_DBG("[%s:%d] dist_wan_index -> %d", __FUNCTION__, __LINE__,
		dist_wan_index);
	if (dist_wan_index > 14) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error : You cannot configure more than 14 WAN connections</span>");
		goto IFX_Handler;
	}
	snprintf(sNewWAN, sizeof(sNewWAN), "WAN%d", dist_wan_index);
	ret = ifx_get_wan_port(sNewWAN);
	IFX_DBG("[%s:%d] dist_wan_index -> %d sNewWAN -> %s", __FUNCTION__,
		__LINE__, dist_wan_index, sNewWAN);
	if (ret == -1) {
		IFX_DBG("[%s:%d:%s]", __FUNCTION__, __LINE__,
			"ifx_get_wan_port");
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error : Please delete portmap entries for this WAN first.</span>");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	pNewWANIndex = sNewWAN + 3;
	if (pNewWANIndex) {
		IFX_DBG("[%s:%d] pNewWANIndex -> %s", __FUNCTION__, __LINE__,
			pNewWANIndex);
		sprintf(sValue, "WAN_VCC=\"%s\"\n", pNewWANIndex);
		ifx_SetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select",
			       IFX_F_MODIFY, 1, sValue);
	}

	if (ifx_get_all_eth_info(&num, &eth_ch, flags) != IFX_SUCCESS) {
		IFX_DBG("[%s] eth channel info fetch failed", __FUNCTION__);
		IFX_MEM_FREE(eth_ch);
		goto IFX_Handler;
	}
	for (i = 0; i < num; i++) {
		if (((eth_ch + i)->vlanId) != 4096) {
			if ((((eth_ch + i)->vlanId == 0 || (eth_ch + i)->vlanId == 3) && (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)) || (((eth_ch + i)->vlanId == 4) && (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0))) {	//New Ethernet channel instance on which WAN connection has to be formed
				// if(num==1){//one 
				IFX_DBG
				    ("[%s:%d] (eth_ch+i)->iid.pcpeId.Id -> %d",
				     __FUNCTION__, __LINE__,
				     (eth_ch + i)->iid.pcpeId.Id);
				sprintf(buf,
					"ipoption_wan=\"PPPOE\"\nWAN_VCC=\"ETH%u\"\n",
					(eth_ch + i)->iid.pcpeId.Id);
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN,
					       IFX_F_MODIFY, 1, buf);
				WAN_COMMON_CFG wan_com;
				WAN_CONN_CFG wan_cfg;
				WAN_PPP_CONFIG wan_pppc;
				memset(&wan_cfg, 0x00, sizeof(wan_cfg));
				operation = IFX_OP_ADD;
				flags =
				    IFX_F_INT_ADD | IFX_F_INT_DONT_CONFIGURE |
				    IFX_F_DONT_WRITE_TO_FLASH;
				GET_GLOBAL_RIP_LISTEN_MODE(wan_cfg.wancfg.ppp.
							   wan_cfg.route_rx)
				    /* set the link type to pppoe */
				    wan_cfg.type = WAN_LINK_TYPE_PPPOE;
				/* Set the wan index */
				wan_com.wan_index = dist_wan_index;
				if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)	//untagged mode
					gstrcpy(wan_com.wan_mode.iface, "eth1");

				else
					gstrcpy(wan_com.wan_mode.iface, "eth0");
				gstrcpy(wan_cfg.WAN_PPP_CONN.WAN_CONN.
					WAN_CONN_NAME, sNewWAN);
#ifdef CONFIG_FEATURE_RIP
				/* Set RIP information based on the Global RIP State & Listen Mode */
				ifx_set_wanif_route_proto(dist_wan_index,
							  &wan_cfg.WAN_PPP_CONN.
							  WAN_CONN);
#endif
				wan_cfg.WAN_PPP_CONN.WAN_CONN.f_enable =
				    IFX_ENABLED;
				wan_pppc.WAN_CONN_TRIGGER =
				    CONN_TRIGGER_ALWAYS_ON;
				wan_cfg.WAN_PPP_CONN.conn_type =
				    WAN_PPP_CONN_TYPE_IP_ROUTED;
				/* set the dns override option to true */
				wan_cfg.wandns.WAN_CONN_DNS_OVERRIDE =
				    IFX_ENABLED;
				wan_cfg.WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_CONNECTING;
#ifdef CONFIG_FEATURE_NAPT
				/* Currently we set the NAT on interface level as always ENABLED
				 * Once the interface level option is configurable, then it can be put here */
				wan_cfg.WAN_PPP_CONN.WAN_CONN.
				    WAN_CONN_NAT_ENABLED = IFX_ENABLED;
#endif
				wan_cfg.WAN_PPP_CONN.max_mru_size = 1492;
				sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_name,
					"subbi");
				sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_passwd,
					"subbi");
				wan_cfg.WAN_PPP_CONN.pppoe_service_name[0] =
				    '\0';
				wan_cfg.WAN_PPP_CONN.pppoe_ac_name[0] = '\0';
				wan_com.max_mtu = 1492;
				wan_cfg.WAN_PPP_CONN.bridge_enable = 0;
				wan_com.iid.config_owner = IFX_WEB;
				ret =
				    ifx_cgi_set_wan_config(operation, &wan_cfg,
							   flags);
				if (ret != IFX_SUCCESS) {
					IFX_DBG("[%s] eth set wan failed",
						__FUNCTION__);
					return -1;
				}
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
				return 0;
			}
		}
	}
      IFX_Handler:
	IFX_MEM_FREE(eth_ch);
	return -1;
}

int32 ifx_set_eth_vlan_wan_display(WAN_PHY_CFG * pstWanPhy_old)
{
	char8 sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32 flags = IFX_F_GET_ANY, outFlag = IFX_F_DEFAULT;
	int32 i = 0, *idx_array = NULL, idx_count = 0, ret = -2;
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG wan_com;
	char_t *pWAN_VCC = NULL, *pWan_Mode = NULL;
	char_t *pNewWANIndex = NULL;
	char8 conn_name[MAX_CONN_NAME_LEN];
	conn_name[0] = '\0';
	sValue[0] = '\0';
	sBuf[0] = '\0';
	int operation1 = 0;
	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	memset(&wan_com, 0x00, sizeof(wan_com));
	char8 *retVal = NULL;
	ETH_CH_CFG eth_ch1;
	memset(&eth_ch1, 0x00, sizeof(eth_ch1));
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
#endif
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
	PTM_CH_CFG ptm_ch;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
#endif
	WAN_CONN_DEV wan_connDev;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));

	sprintf(sBuf, "%s", "wan_main_index");
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_MAIN, sBuf, flags, &outFlag,
	     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In function [%s] : Error--> Trying to get the [%s] in [%s] !!",
		     __FUNCTION__, sBuf, TAG_WAN_MAIN);
#endif
		goto IFX_Handler;
	}
	get_wan_indices(sValue, &idx_count, &idx_array);
	for (i = 0; i < idx_count; i++) {	//loop through all WAN connections
		if (mapi_get_wan_config
		    ((*(idx_array + i)), &wan_cfg, WAN_MODE_ETH0 | WAN_MODE_ETH1,
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
			IFX_DBG("[%s] eth config fetch failed", __FUNCTION__);
			//        goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s] eth config fetch suceeded", __FUNCTION__);
#endif
			if (((wan_com.wan_mode.mode == WAN_MODE_ETH1) && (pstWanPhy_old->eth_mii1_vlan_mode != pstWanPhy.eth_mii1_vlan_mode)) || ((wan_com.wan_mode.mode == WAN_MODE_ETH0) && (pstWanPhy_old->eth_vlan_mode != pstWanPhy.eth_vlan_mode))) {	//if vlan mode change delete all respective eth wan WAN connections and create new WAN VLAN  WAN connection
				if (wan_cfg.type == WAN_LINK_TYPE_PPPOE) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] mii1 pppoe",
						__FUNCTION__, __LINE__);
#endif
					strcpy(conn_name,
					       wan_cfg.WAN_PPP_CONN.WAN_CONN.
					       WAN_CONN_NAME);
				} else {
					strcpy(conn_name,
					       wan_cfg.WAN_IP_CONN.WAN_CONN.
					       WAN_CONN_NAME);
				}
				pNewWANIndex = conn_name + 3;
#ifdef CONFIG_FEATURE_NAPT
				ret = ifx_get_wan_port(conn_name);
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
				if (ret == -1) {	//delete VS entries
					IFX_DBG("[%s:%d] ", __FUNCTION__,
						__LINE__);
					ret = -2;
					ret =
					    ifx_set_virtual_server_delete
					    (conn_name);
					if (ret != 0) {
						IFX_DBG
						    ("[%s] Virtual Server deletion on WAN deletion failed",
						     __FUNCTION__);
						goto IFX_Handler;
					}

				}
#endif
				ret = -2;
				gstrcpy(sValue, "ETH");
				pWan_Mode = sValue;
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
				ret = ifx_set_wan_delete(pWan_Mode, pWAN_VCC, pNewWANIndex);	//delete WAN connection
				if (ret != 0) {
					IFX_DBG("[%s] WAN deletion failed",
						__FUNCTION__);
					goto IFX_Handler;
				}
				//Delete corresponding Ethernet Channel
				operation1 = IFX_OP_DEL;
				flags =
				    IFX_F_DELETE | IFX_F_DONT_WRITE_TO_FLASH;
				eth_ch1.vlanId = wan_cfg.vlanId;
				wan_com.iid.cpeId.Id = wan_com.iid.pcpeId.Id;
				wan_connDev.iid.config_owner = IFX_WEB;
				wan_connDev.vc.pvc.vpi = 256;
				wan_connDev.vc.pvc.vci = 0;
				snprintf(wan_connDev.iid.cpeId.secName,
					 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
					 TAG_WAN_CONN_DEVICE);
				/* Populate the Ethernet Channel information */
				eth_ch1.iid.pcpeId.Id = wan_com.iid.pcpeId.Id;
				snprintf(eth_ch1.iid.cpeId.secName,
					 strlen(TAG_ETH_CHANNEL) + 1, "%s",
					 TAG_ETH_CHANNEL);
				strncpy(eth_ch1.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				eth_ch1.iid.config_owner = IFX_WEB;

				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    wan_connDev.iid.cpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_ETH_CHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth channel pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}

				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ETH_CHANNEL, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth channel cpeId fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				eth_ch1.iid.cpeId.Id = atoi(sValue);
				/* delete dummy ptm wan channel section */
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
				memset(&ptm_ch, 0x00, sizeof(ptm_ch));
				ptm_ch.iid.config_owner = IFX_WEB;
				ptm_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d", ptm_ch.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_PTM_CHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("In Function [%s:%d] : Failed to find the pcpeid for ptm channel!!",
					     __FUNCTION__, __LINE__);
					goto IFX_Handler;
				}

				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_PTM_CHANNEL, sBuf,
				     IFX_F_GET_ENA,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("In Function [%s:%d] : Failed to find the cpeid for ptm channel!!",
					     __FUNCTION__, __LINE__);
					IFX_MEM_FREE(retVal)
					    goto IFX_Handler;
				}
				ptm_ch.iid.cpeId.Id = atoi(sValue);
				sprintf(ptm_ch.iid.cpeId.secName, "%s",
					TAG_PTM_CHANNEL);
				sprintf(ptm_ch.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				ret =
				    ifx_set_ptm_ch_cfg(IFX_OP_DEL, &ptm_ch,
						       flags);
				if (ret != IFX_SUCCESS) {
					IFX_DBG
					    ("In Function [%s] : Failed to set wan ptm channel config !!",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#endif

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
				/* deletion of corresponding dummy atm channel */
				memset(&vcc, 0x00, sizeof(vcc));
				snprintf(vcc.iid.cpeId.secName,
					 strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
					 TAG_ADSL_VCCHANNEL);
				vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
				strncpy(vcc.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				vcc.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d", vcc.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_ADSL_VCCHANNEL,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] vc channel pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}

				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] vc channel cpeId fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				vcc.iid.cpeId.Id = atoi(sValue);
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\n In Function [%s:%d]  vcc.iid.cpeId.Id -> %d\n\n",
				     __FUNCTION__, __LINE__, vcc.iid.cpeId.Id);
#endif
				ret = ifx_set_vcc_cfg(operation1, &vcc, flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s] error deleting vc channel entry",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				/* deletion of corresponding dummy atm f5 object */
				memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
				snprintf(vcc.iid.cpeId.secName,
					 strlen(TAG_WAN_ATMF5) + 1, "%s",
					 TAG_WAN_ATMF5);
				atmf5_diag.iid.pcpeId.Id =
				    wan_connDev.iid.cpeId.Id;
				strncpy(atmf5_diag.iid.pcpeId.secName,
					wan_connDev.iid.pcpeId.secName,
					strlen(wan_connDev.iid.pcpeId.secName));
				atmf5_diag.iid.config_owner = IFX_WEB;
				IFX_MEM_FREE(retVal)
				    sprintf(sValue, "%d",
					    atmf5_diag.iid.pcpeId.Id);
				if ((ret =
				     ifx_ret_substr_from_distfield(FILE_RC_CONF,
								   TAG_WAN_ATMF5,
								   "pcpeId",
								   sValue,
								   &retVal)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] atmf5 pcpeId prefix fetch failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				sprintf(sBuf, "%s_cpeId", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_ATMF5, sBuf,
				     IFX_F_GET_ENA, &outFlag,
				     sValue) != IFX_SUCCESS) {
					IFX_DBG("[%s] atmf5 cpeId fetch failed",
						__FUNCTION__);
					goto IFX_Handler;
				}
				atmf5_diag.iid.cpeId.Id = atoi(sValue);
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\n In Function [%s:%d]  atmf5_diag.iid.cpeId.Id  -> %d\n\n",
				     __FUNCTION__, __LINE__,
				     atmf5_diag.iid.cpeId.Id);
#endif
				ret =
				    ifx_set_atmf5_loop_diagnostics(operation1,
								   &atmf5_diag,
								   flags);
				if (ret == IFX_FAILURE) {
					IFX_DBG
					    ("[%s] Error deleting corresponding atm f5 object",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#endif

				/* Delete the Ethernet Channel & WAN Connection Device entires */

				if (ifx_set_eth_ch_cfg
				    (operation1, &eth_ch1,
				     flags) != IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth mii1 channels deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
				if ((ret =
				     ifx_set_wan_conn_dev(operation1,
							  &wan_connDev,
							  flags)) !=
				    IFX_SUCCESS) {
					IFX_DBG
					    ("[%s] eth mii1 wan_conn_dev deletion failed",
					     __FUNCTION__);
					goto IFX_Handler;
				}
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
			}
		}
	}
	//All Eth mii1 Channel deletion and wan_conn_dev deletion
	ret = -2;
	gstrcpy(sValue, "ETH");
	pWan_Mode = sValue;
	ret = ifx_delete_all_free_channel(pWan_Mode);
	if (ret != 0) {
		IFX_DBG("[%s] mii1 channels deletion failed", __FUNCTION__);
		goto IFX_Handler;
	}
	//Create a Eth channel for VLAN untag mode
	ret = -2;
	ret = ifx_add_eth_channel();
	if (ret != 0) {
		IFX_DBG("[%s] eth channel addition failed", __FUNCTION__);
		goto IFX_Handler;
	}
	//Create Eth WAN PPPoE connection
	ret = -2;
	ret = ifx_add_eth_wan();
	if (ret != 0) {
		IFX_DBG("[%s] eth WAN addition failed", __FUNCTION__);
		goto IFX_Handler;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ret-> %d", __FUNCTION__, __LINE__, ret);
#endif
      IFX_Handler:
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ret-> %d", __FUNCTION__, __LINE__, ret);
#endif
	IFX_MEM_FREE(idx_array)
	    IFX_MEM_FREE(retVal)
	    return ret;
	return IFX_SUCCESS;
}
#endif				// 0

#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
void ifx_set_wan_mode_bbf(httpd_t wp, char_t * path, char_t * query)
{
	char_t *wan_type = NULL, *sTC = NULL;
	uint32 flags = 0;
	
	wan_type = ifx_httpdGetVar(wp, T("WT"), T(""));
	sTC = ifx_httpdGetVar(wp, T("TC"), T(""));

	WAN_PHY_CFG pstWanPhy;

	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	pstWanPhy.set_wan_tc = atoi(sTC);
	pstWanPhy.wan_tc = atoi(sTC);
	pstWanPhy.config_owner = IFX_WEB;
	printf("tc value :%d at line %d", atoi(sTC), __LINE__);
	printf("\ntc value :%d at line %d", atoi(sTC), __LINE__);
	pstWanPhy.set_phy_mode = atoi(wan_type);
	pstWanPhy.phy_mode = atoi(wan_type);
	
	printf("wt value :%d at line %d", atoi(wan_type), __LINE__);
	printf("\nwt value :%d at line %d", atoi(wan_type), __LINE__);
	ifx_set_wan_phy_cfg_new(&pstWanPhy, flags);
	ifx_httpdRedirect(wp, "anywan.asp");
	return;
}
#endif

void ifx_set_wan_mode(httpd_t wp, char_t * path, char_t * query)
{
	char_t *wan_type = NULL, *sTC = NULL;
	uint32 flags = 0;

#if 0
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	char_t *auto_detect_status = ifx_httpdGetVar(wp, T("ads_update"), T(""));

	if(auto_detect_status != NULL)
		if (!gstrcmp(auto_detect_status, T("1"))) {
			if(ltq_cgi_set_autodetect_config(wp, "dsl") == IFX_SUCCESS){
				ifx_httpdRedirect(wp, "wan_mode_setting.asp");
			}
			return;  
		}
#endif
#endif

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	int32 ret = IFX_SUCCESS, nFailover_status = 0;
	char_t *failover_status = NULL, *dual_wan_element = NULL;
	dw_config_info_t dw_attr;
	def_wan_cfg_t   def_wan_cfg;
	char8 sValue[MAX_NAME_LEN];
	WAN_TYPE	type;
	int32	wan_index;
	char8	secName[MAX_FILELINE_LEN];
	char8	buf[MAX_FILELINE_LEN];

	memset(&dw_attr, 0x00, sizeof(dw_attr));
	memset(&def_wan_cfg, 0x00, sizeof(def_wan_cfg));
	NULL_TERMINATE(sValue, 0x0, MAX_NAME_LEN);
	NULL_TERMINATE(secName, 0x0, MAX_FILELINE_LEN);
	NULL_TERMINATE(buf, 0x0, MAX_FILELINE_LEN);
#endif

	wan_type = ifx_httpdGetVar(wp, T("WT"), T(""));
	sTC = ifx_httpdGetVar(wp, T("TC"), T(""));
	ifx_httpdGetVar(wp, T("VLAN_EN"), T(""));

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	ifx_httpdGetVar(wp, T("PTM_VLAN_EN"), T(""));
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	ifx_httpdGetVar(wp, T("MII1_VLAN_EN"), T(""));
#endif

	WAN_PHY_CFG pstWanPhy;

	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	pstWanPhy.set_wan_tc = atoi(sTC);
	pstWanPhy.set_phy_mode = atoi(wan_type);

	/* For Auto Set the defaults as ADSL-ATM
	 */
	if (pstWanPhy.set_wan_tc == 2)	// 2 => Auto
		pstWanPhy.wan_tc = WAN_TC_ATM;
	else
		pstWanPhy.wan_tc = atoi(sTC);

	if (pstWanPhy.set_phy_mode == 4)	// 4 => Auto
	{
		pstWanPhy.set_wan_tc = 2;
		pstWanPhy.phy_mode = WAN_PHY_MODE_VDSL2;
		pstWanPhy.wan_tc = WAN_TC_PTM;
	} else
		pstWanPhy.phy_mode = atoi(wan_type);

#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	pstWanPhy.ptm_vlan_mode = atoi(sVLANPTM);
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	pstWanPhy.eth_vlan_mode = atoi(sVLAN);
	pstWanPhy.eth_mii1_vlan_mode = atoi(sVLANMII1);
#endif
#endif				// no explicit enable/disable ]

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
		/******************************DUAL WAN SUPPORT BLOCK**************************/
	failover_status = ifx_httpdGetVar(wp, T(DW_FAILOVER), T(""));

	if (failover_status) {
		nFailover_status = atoi(failover_status);
	}
	if (nFailover_status != 0) {

		dw_attr.fo_state = atoi(failover_status);

		dual_wan_element = ifx_httpdGetVar(wp, T(DW_STANDBY), T(""));
		dw_attr.fo_type = atoi(dual_wan_element);

		dual_wan_element = ifx_httpdGetVar(wp, T(DW_PROBE_INT), T(""));
		dw_attr.probe_info.probe_int = atoi(dual_wan_element);

		dual_wan_element = ifx_httpdGetVar(wp, T(DW_PROBE_RET), T(""));
		dw_attr.probe_info.probe_retry = atoi(dual_wan_element);

		dual_wan_element = ifx_httpdGetVar(wp, T(DW_IP), T(""));
		strcpy(dw_attr.probe_info.probe_ip_url, dual_wan_element);

		/*Primary Wan Configuration should be stored at both "bkup_wan" and "wan_phy_cfg" section of rc.conf */

		dw_attr.pri_wan_cfg.wan_tc = pstWanPhy.wan_tc;
		dw_attr.pri_wan_cfg.phy_mode = pstWanPhy.phy_mode;
		dw_attr.pri_wan_cfg.set_wan_tc = pstWanPhy.set_wan_tc;
		dw_attr.pri_wan_cfg.set_phy_mode = pstWanPhy.set_phy_mode;

#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		dw_attr.pri_wan_cfg.eth_mii1_vlan_mode =
		    pstWanPhy.eth_mii1_vlan_mode;
#endif

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		dw_attr.pri_wan_cfg.ptm_vlan_mode = pstWanPhy.ptm_vlan_mode;
#endif
#endif				// no explicit enable/disable ]

		/*strcpy( dw_attr.pri_wan_cfg.tr69_encaprequested, dual_wan_element );  */

		/*Secondary Wan Attributes */
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		ifx_httpdGetVar(wp, T("PTM_VLAN_EN_SEC"), T(""));
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		ifx_httpdGetVar(wp, T("VLAN_EN_SEC"), T(""));

		    ifx_httpdGetVar(wp, T("MII1_VLAN_EN_SEC"), T(""));
#endif

		dual_wan_element = ifx_httpdGetVar(wp, T(DW_S_TC), T(""));
		dw_attr.sec_wan_cfg.set_wan_tc = atoi(dual_wan_element);

		dual_wan_element = ifx_httpdGetVar(wp, T(DW_S_PHY), T(""));
		dw_attr.sec_wan_cfg.set_phy_mode = atoi(dual_wan_element);

		/* wan_tc amd phy_mode For Auto Set the defaults as ADSL-ATM
		 */
		if (dw_attr.sec_wan_cfg.set_wan_tc == 2)	// 2 => Auto
			dw_attr.sec_wan_cfg.wan_tc = WAN_TC_ATM;
		else
			dw_attr.sec_wan_cfg.wan_tc =
			    dw_attr.sec_wan_cfg.set_wan_tc;

		if (dw_attr.sec_wan_cfg.set_phy_mode == 4)	// 4 => Auto
		{
			//v dw_attr.sec_wan_cfg.set_wan_tc      = 2;
			dw_attr.sec_wan_cfg.phy_mode = WAN_PHY_MODE_VDSL2;
			dw_attr.sec_wan_cfg.wan_tc = WAN_TC_PTM;
		} else
			dw_attr.sec_wan_cfg.phy_mode =
			    dw_attr.sec_wan_cfg.set_phy_mode;

#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		dw_attr.sec_wan_cfg.ptm_vlan_mode = atoi(sVLANPTM_sec);
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		dw_attr.sec_wan_cfg.eth_vlan_mode = atoi(sVLAN_sec);
		dw_attr.sec_wan_cfg.eth_mii1_vlan_mode = atoi(sVLANMII1_sec);
#endif
#endif				// no explicit enable/disable ]

		/*Vicky_Note: The below section is for future Reference */

		//dual_wan_element                                              =   ifx_httpdGetVar(wp, T( DW_S_TC), T(""));
		//dw_attr.sec_wan_cfg.wan_tc                            =   atoi( dual_wan_element );  
		//dual_wan_element                                              =   ifx_httpdGetVar(wp, T( DW_S_PHY), T(""));
		//dw_attr.sec_wan_cfg.phy_mode                          =   atoi( dual_wan_element );  
		//dual_wan_element                                              =       ifx_httpdGetVar(wp, T( DW_S_MII_VLAN), T(""));
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		//dw_attr.sec_wan_cfg.eth_mii1_vlan_mode        =   atoi( dual_wan_element );  
#endif
		//dual_wan_element                                              =       ifx_httpdGetVar(wp, T( DW_S_PTM_VLAN), T(""));
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		//dw_attr.sec_wan_cfg.ptm_vlan_mode             =   atoi( dual_wan_element );  
#endif
		//dual_wan_element                                              =    ifx_httpdGetVar(wp, T( DW_S_TR69), T(""));
		//strcpy( dw_attr.sec_wan_cfg.tr69_encaprequested, dual_wan_element ); 
		if (dw_attr.pri_wan_cfg.phy_mode != WAN_PHY_MODE_CELL_WAN) {
			ret = default_wan_cfg_get_for_wan_phymode(&def_wan_cfg, &(dw_attr.pri_wan_cfg));
			if (ret == IFX_SUCCESS) {
				GET_WAN_DETAILS_FROM_CONN_NAME(def_wan_cfg.conn_name, type, wan_index, secName)
				if (type == WAN_TYPE_IP) {
				sprintf(buf, "%s_%d_addrType", (type == WAN_TYPE_IP)?PREFIX_WAN_IP:PREFIX_WAN_PPP, wan_index);
				if(ifx_GetObjData(FILE_RC_CONF, secName, buf, IFX_F_DEFAULT, NULL, sValue) != IFX_SUCCESS) {
					ifx_httpdError(wp, 500, T("Failed to determine default interface details"));
				}
				if(atoi(sValue) == IP_TYPE_AUTO) {
					/* default WAN is Bridged ! */
					COPY_TO_STATUS("%s", dw_config_err)
					    ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
				}
			}
		}
		if (dw_attr.sec_wan_cfg.phy_mode != WAN_PHY_MODE_CELL_WAN) {
			memset(&def_wan_cfg, 0x00, sizeof(def_wan_cfg));
			NULL_TERMINATE(sValue, 0x0, MAX_NAME_LEN);
			NULL_TERMINATE(secName, 0x0, MAX_FILELINE_LEN);
			NULL_TERMINATE(buf, 0x0, MAX_FILELINE_LEN);
			ret = default_wan_cfg_get_for_wan_phymode(&def_wan_cfg, &(dw_attr.sec_wan_cfg));
			if (ret == IFX_SUCCESS) {
				GET_WAN_DETAILS_FROM_CONN_NAME(def_wan_cfg.conn_name, type, wan_index, secName)
				if (type == WAN_TYPE_IP) {
				sprintf(buf, "%s_%d_addrType", (type == WAN_TYPE_IP)?PREFIX_WAN_IP:PREFIX_WAN_PPP, wan_index);
				if(ifx_GetObjData(FILE_RC_CONF, secName, buf, IFX_F_DEFAULT, NULL, sValue) != IFX_SUCCESS) {
					ifx_httpdError(wp, 500, T("Failed to determine default interface details"));
				}
				if(atoi(sValue) == IP_TYPE_AUTO) {
					/* default WAN is Bridged ! */
					COPY_TO_STATUS("%s", dw_config_err)
					    ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
				}
			}
		}
	} else {
		ret = dw_mapi_cfg_get(&dw_attr, 0);

		if (ret != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to save Retrive and Set dw_attr Default Configurations"));
			return;
		}

		dw_attr.fo_state = 0;
		dw_attr.pri_wan_cfg.wan_tc = pstWanPhy.wan_tc;
		dw_attr.pri_wan_cfg.phy_mode = pstWanPhy.phy_mode;
		dw_attr.pri_wan_cfg.set_wan_tc = pstWanPhy.set_wan_tc;
		dw_attr.pri_wan_cfg.set_phy_mode = pstWanPhy.set_phy_mode;
#if 0				// [ no explicit WAN VLAN config enable/disable for PTM/ETH
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		dw_attr.pri_wan_cfg.eth_mii1_vlan_mode =
		    pstWanPhy.eth_mii1_vlan_mode;
#endif

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		dw_attr.pri_wan_cfg.ptm_vlan_mode = pstWanPhy.ptm_vlan_mode;
#endif
#endif				// no explicit enable/disable ]
	}
	if (dw_mapi_cfg_set(flags, &dw_attr, IFX_F_MODIFY) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("Failed to save FAIL OVER Configurations"));
		return;
	}

		/******************************DUAL WAN SUPPORT BLOCK**************************/
#else
	ifx_set_wan_phy_cfg_new(&pstWanPhy, flags);
#endif
	ifx_httpdRedirect(wp, "wan_mode_setting.asp");
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
IFX_Handler:
#endif
	return;
}

void ifx_set_wan_eth_channel_config(httpd_t wp, char_t * path, char_t * query)
{
	char_t *Eth_channel_name = NULL;
	char_t sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	char_t *Vlan_id = NULL;
	char_t *Override_mac_add = NULL;
	char_t *Mac_addr = NULL;
	int32 ret = IFX_SUCCESS;
	char_t remove[15];
	char8 *retVal = NULL;
	char_t *remove_num = NULL;
	uint32 flags = IFX_F_DEFAULT;
	int status = 0;
	char_t *pSubmit_Action =
	    ifx_httpdGetVar(wp, T("submit_action_eth"), T(""));
	status = gatoi(ifx_httpdGetVar(wp, T("qs_status"), T("")));
	int operation = 0, num = 0, i = 0;
	int outFlag = IFX_F_DEFAULT;
#ifdef  CONFIG_FEATURE_PTM_WAN_SUPPORT
	PTM_CH_CFG ptm_ch;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
#endif
	sValue[0] = '\0';
	sBuf[0] = '\0';
	WAN_PHY_CFG pstWanPhy;
	ETH_CH_CFG eth_ch;
	WAN_CONN_DEV wan_connDev;
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	memset(&eth_ch, 0x00, sizeof(eth_ch));
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
	Eth_channel_name = ifx_httpdGetVar(wp, T("eth_channel_name"), T(""));
	Vlan_id = ifx_httpdGetVar(wp, T("vlan_id"), T(""));
	Override_mac_add = ifx_httpdGetVar(wp, T("override_mac_add"), T(""));
	Mac_addr = ifx_httpdGetVar(wp, T("mac_addr"), T(""));
	gstrcpy(eth_ch.eth_ch_name, Eth_channel_name);
	gstrcpy(eth_ch.mac_addr, Mac_addr);
	eth_ch.macOverride = Override_mac_add[0];
	eth_ch.f_enable = 1;
	if (Vlan_id != NULL && gstrcmp(Vlan_id, ""))
		eth_ch.vlanId = atoi(Vlan_id);
	ifx_get_wan_phy_cfg(&pstWanPhy);
	/* WAN Device1 - ATM/PTM
	 * WAN Device2 - MII0
	 * WAN Device3 - MII1 */
	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
		/* Case of PTM Mode, so pCPEId set to 2 */
		wan_connDev.iid.pcpeId.Id = 2;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
		wan_connDev.iid.pcpeId.Id = 3;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)	//for VRX eth channels are added under WAN Device 3
		wan_connDev.iid.pcpeId.Id = 3;
	else
		wan_connDev.iid.pcpeId.Id = 2;
	/* While adding Ethernet Channels, we create dummy channels for corresponding
	 * ATM devices with VPI=256 and VCI=0 (only for ATM WAN Connections)
	 * Work-around for now to modify the DS in DevM Stack */
	if (!gstrcmp(pSubmit_Action, T("addETH"))) {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;

		/* Dummy Channel: ATM devices with VPI=256 and VCI=0 
		 * Information is used only for ATM WAN Connections */
		wan_connDev.vc.pvc.vpi = 256;
		wan_connDev.vc.pvc.vci = 0;
		wan_connDev.iid.config_owner = IFX_WEB;

		/* Update the WAN Connection Device Information in sysconfig */
		snprintf(wan_connDev.iid.cpeId.secName,
			 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
			 TAG_WAN_CONN_DEVICE);
		if ((ret =
		     ifx_set_wan_conn_dev(operation, &wan_connDev,
					  flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error-->Trying to get the eth connection device iid !!\n\n",
			     __FUNCTION__);
#endif
			return;
		}

		/* Update the Ethernet Channel Information */
		snprintf(eth_ch.iid.cpeId.secName, strlen(TAG_ETH_CHANNEL) + 1,
			 "%s", TAG_ETH_CHANNEL);
		eth_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		strncpy(eth_ch.iid.pcpeId.secName,
			wan_connDev.iid.pcpeId.secName,
			strlen(wan_connDev.iid.pcpeId.secName));
		eth_ch.iid.config_owner = IFX_WEB;
		/* call the MAPI to update the eth channel section in sysconfig */
		ret = ifx_set_eth_ch_cfg(operation, &eth_ch, flags);
		if ((ret != IFX_SUCCESS) && (ret == IFX_DUPLICATE_ENTRY)) {
			/* In case Channel already configured - report to user */
			COPY_TO_STATUS("%s", eth_chan_err)
			    ifx_httpdRedirect(wp, "err_page.html");
			return;
		} else if (ret != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to set wan eth channel config !!"));
			return;
		}
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
		/* ATM F5 Object created along with channel addition */
		atmf5_diag.iid.config_owner = IFX_WEB;
		atmf5_diag.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		atmf5_diag.vpi = 256;
		sprintf(atmf5_diag.iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
		sprintf(atmf5_diag.iid.pcpeId.secName, "%s",
			TAG_WAN_CONN_DEVICE);
		ret =
		    ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD, &atmf5_diag,
						   IFX_F_INT_ADD |
						   IFX_F_DONT_ACTIVATE);
		if (ret != IFX_SUCCESS)
			ifx_httpdError(wp, 500,
				       "Error : Failed to add the atmf5 object [%d/%d] !!",
				       atmf5_diag.vpi, atmf5_diag.vci);
		/* addition of dummy ATM channel */
		vcc.vc.pvc.vpi = 256;
		snprintf(vcc.iid.cpeId.secName, strlen(TAG_ADSL_VCCHANNEL) + 1,
			 "%s", TAG_ADSL_VCCHANNEL);
		vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		strncpy(vcc.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
			strlen(wan_connDev.iid.pcpeId.secName));
		vcc.iid.config_owner = IFX_WEB;
		/* call the api to update the adsl vcchannel section for this vpi/vci */
		ret =
		    ifx_set_vcc_cfg(IFX_OP_ADD, &vcc,
				    IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE);
		if (ret == IFX_FAILURE)
			ifx_httpdError(wp, 400,
				       "Error : Failed to add the vc channel for [%d/%d] !!",
				       vcc.vc.pvc.vpi, vcc.vc.pvc.vci);
#endif
#ifdef  CONFIG_FEATURE_PTM_WAN_SUPPORT
		memset(&ptm_ch, 0x00, sizeof(ptm_ch));
		gstrcpy(ptm_ch.ptm_ch_name, "");
		gstrcpy(ptm_ch.mac_addr, "");
		ptm_ch.vlanId = 4096;
		ptm_ch.preempt = 0;
		snprintf(ptm_ch.iid.cpeId.secName, strlen(TAG_PTM_CHANNEL) + 1,
			 "%s", TAG_PTM_CHANNEL);
		ptm_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		strncpy(ptm_ch.iid.pcpeId.secName,
			wan_connDev.iid.pcpeId.secName,
			strlen(wan_connDev.iid.pcpeId.secName));
		ptm_ch.iid.config_owner = IFX_WEB;
		/* call the api to update the eth channel section  */
		ret =
		    ifx_set_ptm_ch_cfg(IFX_OP_ADD, &ptm_ch,
				       IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("In Function [%s] : Failed to set wan ptm channel config !!",
			     __FUNCTION__);
#endif
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to set wan ptm channel config !!"));
		}
#endif

	}
	/* While deleting Ethernet Channels, delete dummy channels for corresponding
	 * ATM devices with VPI=256 and VCI=0 (only for ATM WAN Connections)
	 * Work-around for now to modify the DS in DevM Stack */
	else if (!gstrcmp(pSubmit_Action, T("delETH"))) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
		ETH_CH_CFG *eth_ch1 = NULL;
		memset(&eth_ch, 0x00, sizeof(eth_ch));
		if (ifx_get_all_eth_info(&num, &eth_ch1, IFX_F_DEFAULT) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to get Ethernet Channel information!"));
			IFX_MEM_FREE(eth_ch1);
			return;
		}
		for (i = 0; i < num; i++) {
			if (((eth_ch1 + i)->vlanId) != 4096) {
				/* Option set to Delete a particular Ethernet Channel */
				snprintf(remove, sizeof(remove), "remove%d",
					 (eth_ch1 + i)->iid.cpeId.Id);
				remove_num = NULL;
				remove_num =
				    ifx_httpdGetVar(wp, T(remove), T(""));
				if (!gstrcmp(remove_num, "1")) {
					/* Check if the selected Ethernet Channel has any WAN Connections
					 * configured on it. If so, fail this operation */
					sprintf(sBuf, "%u",
						(eth_ch1 + i)->vlanId);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_ETH_CHANNEL,
					      "vlanId", sBuf,
					      &retVal)) == IFX_SUCCESS) {
						sprintf(sBuf, "%s_l2ifName",
							retVal);
						if (ifx_GetObjData
						    (FILE_RC_CONF,
						     TAG_ETH_CHANNEL, sBuf,
						     IFX_F_GET_ENA,
						     (IFX_OUT uint32 *) &
						     outFlag,
						     sValue) != IFX_SUCCESS) {
							ifx_httpdError(wp, 405,
								       T
								       ("Failed to find the cpeid for eth channel!!"));
							IFX_MEM_FREE(retVal)
							    return;
						}
						if ((ret =
						     ifx_ret_substr_from_distfield
						     (FILE_RC_CONF, TAG_WAN_IP,
						      "l2ifName", sValue,
						      &retVal)) ==
						    IFX_SUCCESS) {
							ifx_httpdError(wp, 400,
								       "Eth Channel is currently being used - Cannot Delete !!");
							IFX_MEM_FREE(eth_ch1);
							IFX_MEM_FREE(retVal);
							return;
						}
						if ((ret =
						     ifx_ret_substr_from_distfield
						     (FILE_RC_CONF, TAG_WAN_PPP,
						      "l2ifName", sValue,
						      &retVal)) ==
						    IFX_SUCCESS) {
							ifx_httpdError(wp, 400,
								       "Eth Channel is currently being used - Cannot Delete !!");
							IFX_MEM_FREE(eth_ch1);
							IFX_MEM_FREE(retVal);
							return;
						}

					}

					/* Channel not being used, so populate the WAN Connection Device
					 * and Ethernet Channel information */
					wan_connDev.iid.cpeId.Id =
					    (eth_ch1 + i)->iid.pcpeId.Id;
					wan_connDev.iid.config_owner = IFX_WEB;
					wan_connDev.vc.pvc.vpi = 0;
					wan_connDev.vc.pvc.vci = 0;

					/* Populate the Parent & Eternet Channel information */
					snprintf(wan_connDev.iid.cpeId.secName,
						 strlen(TAG_WAN_CONN_DEVICE) +
						 1, "%s", TAG_WAN_CONN_DEVICE);
					snprintf((eth_ch1 +
						  i)->iid.cpeId.secName,
						 strlen(TAG_ETH_CHANNEL) + 1,
						 "%s", TAG_ETH_CHANNEL);
					strncpy((eth_ch1 +
						 i)->iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					(eth_ch1 + i)->iid.config_owner =
					    IFX_WEB;
					/* delete dummy ptm wan channel section */
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
					memset(&ptm_ch, 0x00, sizeof(ptm_ch));
					ptm_ch.iid.config_owner = IFX_WEB;
					ptm_ch.iid.pcpeId.Id =
					    wan_connDev.iid.cpeId.Id;
					IFX_MEM_FREE(retVal)
					    sprintf(sValue, "%d",
						    ptm_ch.iid.pcpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_PTM_CHANNEL,
					      "pcpeId", sValue,
					      &retVal)) != IFX_SUCCESS) {
						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for ptm channel!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}

					sprintf(sBuf, "%s_cpeId", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_PTM_CHANNEL,
					     sBuf, IFX_F_GET_ENA,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {
						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for ptm channel!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					ptm_ch.iid.cpeId.Id = atoi(sValue);
					sprintf(ptm_ch.iid.cpeId.secName, "%s",
						TAG_PTM_CHANNEL);
					sprintf(ptm_ch.iid.pcpeId.secName, "%s",
						TAG_WAN_CONN_DEVICE);
					ret =
					    ifx_set_ptm_ch_cfg(IFX_OP_DEL,
							       &ptm_ch,
							       IFX_F_DELETE);
					if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("In Function [%s] : Failed to set wan ptm channel config !!",
						     __FUNCTION__);
#endif
						ifx_httpdError(wp, 500,
							       T
							       ("Error deleting ptm channel entry  !!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
#endif

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
					/* deletion of corresponding dummy atm channel */
					memset(&vcc, 0x00, sizeof(vcc));
					snprintf(vcc.iid.cpeId.secName,
						 strlen(TAG_ADSL_VCCHANNEL) + 1,
						 "%s", TAG_ADSL_VCCHANNEL);
					vcc.iid.pcpeId.Id =
					    wan_connDev.iid.cpeId.Id;
					strncpy(vcc.iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					vcc.iid.config_owner = IFX_WEB;
					IFX_MEM_FREE(retVal)
					    sprintf(sValue, "%d",
						    vcc.iid.pcpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					      "pcpeId", sValue,
					      &retVal)) != IFX_SUCCESS) {

						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the pcpeid for corresponding vcc channel!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					sprintf(sBuf, "%s_cpeId", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					     sBuf, IFX_F_GET_ENA,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {
						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for corresponding vcc channel!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					vcc.iid.cpeId.Id = atoi(sValue);
					IFX_DBG
					    ("\n\n In Function [%s:%d]  vcc.iid.cpeId.Id -> %d\n\n",
					     __FUNCTION__, __LINE__,
					     vcc.iid.cpeId.Id);
					ret =
					    ifx_set_vcc_cfg(operation, &vcc,
							    flags);
					if (ret == IFX_FAILURE) {
						ifx_httpdError(wp, 500,
							       "Error deleting corresponding vc channel entry !!");
						IFX_MEM_FREE(retVal)
						    return;
					}

					/* deletion of corresponding dummy atm f5 object */
					memset(&atmf5_diag, 0x00,
					       sizeof(atmf5_diag));
					snprintf(vcc.iid.cpeId.secName,
						 strlen(TAG_WAN_ATMF5) + 1,
						 "%s", TAG_WAN_ATMF5);
					atmf5_diag.iid.pcpeId.Id =
					    wan_connDev.iid.cpeId.Id;
					strncpy(atmf5_diag.iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					atmf5_diag.iid.config_owner = IFX_WEB;
					IFX_MEM_FREE(retVal)
					    sprintf(sValue, "%d",
						    atmf5_diag.iid.pcpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_WAN_ATMF5,
					      "pcpeId", sValue,
					      &retVal)) != IFX_SUCCESS) {

						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the pcpeid for corresponding atm f5 object!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					sprintf(sBuf, "%s_cpeId", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_WAN_ATMF5, sBuf,
					     IFX_F_GET_ENA,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {
						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for corresponding atm f5 object!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					atmf5_diag.iid.cpeId.Id = atoi(sValue);
					IFX_DBG
					    ("\n\n In Function [%s:%d]  atmf5_diag.iid.cpeId.Id  -> %d\n\n",
					     __FUNCTION__, __LINE__,
					     atmf5_diag.iid.cpeId.Id);
					ret =
					    ifx_set_atmf5_loop_diagnostics
					    (operation, &atmf5_diag, flags);
					if (ret == IFX_FAILURE) {
						ifx_httpdError(wp, 500,
							       "Error deleting corresponding atm f5 object !!");
						return;
					}
#endif
					/* Delete the Ethernet Channel & WAN Connection Device entires */
					if (ifx_set_eth_ch_cfg
					    (operation, (eth_ch1 + i),
					     flags) != IFX_SUCCESS) {
						ifx_httpdError(wp, 500,
							       T
							       ("Error deleting vc channel entry  !!"));
						return;
					}
					if ((ret =
					     ifx_set_wan_conn_dev(operation,
								  &wan_connDev,
								  flags)) !=
					    IFX_SUCCESS) {
						ifx_httpdError(wp, 500,
							       "Error deleting wan connection device entry !!");
						return;
					}
				}
			}
		}
		IFX_MEM_FREE(eth_ch1);
		websNextPage(wp);
	} else {
		operation = 0;
	}
	if (status == 1)
		ifx_httpdRedirect(wp, T("ethernet_channel_config.asp"));
	else
		websNextPage(wp);

      IFX_Handler:
	return;
}

int ifx_get_wan_eth_channel_config(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
	int num = 0, i = 0;
	//      char8   *name = NULL;
#if 0
	char8 sValue[20];
	uint32 outFlag = IFX_F_DEFAULT;
#endif
	uint32 flags = IFX_F_DEFAULT;
	ETH_CH_CFG *eth_ch = NULL;
	memset(&eth_ch, 0x00, sizeof(eth_ch));
	if (ifx_get_all_eth_info(&num, &eth_ch, flags) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get all ETH info !!");
		IFX_MEM_FREE(eth_ch);
		return -1;
	}
	if (num != 0) {
		for (i = 0; i < num; i++) {
			if (((eth_ch + i)->vlanId) != 4096) {
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"hidden\" name=\"cpeId\" value=\"%d\">"),
					       (eth_ch + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("<tr>"));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"eth_ch_name%d\">%s</td>"),
					       i, (eth_ch + i)->eth_ch_name);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"eth_mac_addr%d\">%s</td>"),
					       i, (eth_ch + i)->mac_addr);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"eth_if_name%d\">%s</td>"),
					       i, (eth_ch + i)->l2ifname);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"eth_vlanid%d\">%d</td>"),
					       i, (eth_ch + i)->vlanId);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='remove%d' value='1'></td>"),
					       (eth_ch + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</TR>\n"));
			}
		}
	} else {
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
			       T("<td colspan='5'>No Channel Configured</td>"));
		ifx_httpdWrite(wp, T("</TR>"));
	}
	IFX_MEM_FREE(eth_ch);
	return IFX_SUCCESS;
}

int ifx_get_wan_atm_channel_config(int eid, httpd_t wp, int argc,
				   char_t ** arg_v)
{
	int num = 0, i = 0;
	char8 link_name[MAX_NAME_LEN];
	ATM_VCC_INFO *vcc = NULL;
	memset(&vcc, 0x00, sizeof(vcc));
	if (ifx_get_all_vcc_info(&num, &vcc, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get all VCC info !!");
		IFX_MEM_FREE(vcc);
		return -1;
	}
	if (num != 0) {
		for (i = 0; i < num; i++) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
			if (((vcc + i)->vc.pvc.vpi) == 255){ 
						if (((vcc + i)->vc.pvc.vci) == 65535){
									continue;
						}
			}
#endif
			if (((vcc + i)->vc.pvc.vpi) != 256) {
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"hidden\" name=\"cpeId\" value=\"%d\">"),
					       (vcc + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("<tr>"));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"atm_ch_name%d\">%s</td>"),
					       (vcc + i)->iid.cpeId.Id, (vcc + i)->vcc_ch_name);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"atm_vpi_vci%d\">%d/%d</td>"),
					       (vcc + i)->iid.cpeId.Id, (vcc + i)->vc.pvc.vpi,
					       (vcc + i)->vc.pvc.vci);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"atm_en_mode%d\">%s</td>"),
					       (vcc + i)->iid.cpeId.Id,
					       ((vcc + i)->encap ==
						VC_ENCAP_LLC ? "LLC/SNAP" :
						"VCMux"));
				get_atm_proto_name_by_id(link_name,
							 (vcc + i)->type);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"atm_proto%d\">%s</td>"),
					       (vcc + i)->iid.cpeId.Id, link_name);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"atm_qos%d\">%s</td>"),
					       (vcc + i)->iid.cpeId.Id,
					       ifx_get_atm_qos_name_by_id((vcc +
									   i)->
									  txtp.
									  traffic_class));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"atm_if_name%d\">%s</td>"),
					       (vcc + i)->iid.cpeId.Id, (vcc + i)->l2ifname);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='remove%d' value='1'></td>"),
					       (vcc + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</TR>\n"));
			}
		}
	} else {
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
			       T("<td colspan='6'>No Channel Configured</td>"));
		ifx_httpdWrite(wp, T("</tr>"));
	}
	IFX_MEM_FREE(vcc);
	return IFX_SUCCESS;
}

int ifx_get_wan_ptm_channel_config(int eid, httpd_t wp, int argc,
				   char_t ** arg_v)
{
	int num = 0, i = 0;
	uint32 flags = IFX_F_DEFAULT;
	PTM_CH_CFG *ptm_ch = NULL;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
	if (ifx_get_all_ptm_info(&num, &ptm_ch, flags) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get all PTM info !!");
		IFX_MEM_FREE(ptm_ch);
		return -1;
	}
	if (num != 0) {
		for (i = 0; i < num; i++) {
			if (((ptm_ch + i)->vlanId) != 4096) {

				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"hidden\" name=\"cpeId\" value=\"%d\">"),
					       (ptm_ch + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("<tr>"));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptm_ch_name%d\">%s</td>"),
					       i, (ptm_ch + i)->ptm_ch_name);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptm_mac_addr%d\">%s</td>"),
					       i, (ptm_ch + i)->mac_addr);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptm_if_name%d\">%s</td>"),
					       i, (ptm_ch + i)->l2ifname);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptm_vlanid%d\">%d</td>"),
					       i, (ptm_ch + i)->vlanId);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type=\'checkbox\' name=\'remove%d\' value=\'1\'></td>"),
					       (ptm_ch + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</TR>\n"));
			}
		}
	} else {
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
			       T("<td colspan='5'>No Channel Configured</td>"));
		ifx_httpdWrite(wp, T("</TR>"));
	}
	IFX_MEM_FREE(ptm_ch);
	return IFX_SUCCESS;
}

void ifx_set_wan_ptm_channel_config(httpd_t wp, char_t * path, char_t * query)
{
	char_t *Ptm_channel_name = NULL;
	char_t sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	char_t *Vlan_id = NULL;
	char_t *Override_mac_add = NULL;
	char_t *Mac_addr = NULL;
	int32 ret = IFX_SUCCESS;
	char_t remove[15];
	char8 *retVal = NULL;
	char_t *remove_num = NULL;
	uint32 flags = IFX_F_DEFAULT;
	char_t *pSubmit_Action =
	    ifx_httpdGetVar(wp, T("submit_action_ptm"), T(""));
	char_t *page = ifx_httpdGetVar(wp, T("page"), T(""));
	int operation = 0, num = 0, i = 0;
	sValue[0] = '\0';
	sBuf[0] = '\0';
	WAN_PHY_CFG pstWanPhy;
	PTM_CH_CFG ptm_ch;
	WAN_CONN_DEV wan_connDev;
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	int outFlag = IFX_F_DEFAULT;
	ATM_VCC_INFO vcc;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	memset(&vcc, 0x00, sizeof(vcc));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
#endif
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
	int outFlag1 = IFX_F_DEFAULT;
	ETH_CH_CFG eth_ch;
	memset(&eth_ch, 0x00, sizeof(eth_ch));
#endif
	/* Get the PTM Channel Information */
	Ptm_channel_name = ifx_httpdGetVar(wp, T("ptm_channel_name"), T(""));
	Vlan_id = ifx_httpdGetVar(wp, T("vlan_id"), T(""));
	Override_mac_add = ifx_httpdGetVar(wp, T("override_mac_add"), T(""));
	Mac_addr = ifx_httpdGetVar(wp, T("mac_addr"), T(""));
	gstrcpy(ptm_ch.ptm_ch_name, Ptm_channel_name);
	gstrcpy(ptm_ch.mac_addr, Mac_addr);
	ptm_ch.macOverride = Override_mac_add[0];
	ptm_ch.vlanId = atoi(Vlan_id);
	ptm_ch.preempt = 0;
	ptm_ch.f_enable = 1;
	if (atoi(Vlan_id) != 0) {
		sprintf(ptm_ch.l2ifname, "ptm0.%d", atoi(Vlan_id));
	} else
		sprintf(ptm_ch.l2ifname, "ptm%d", atoi(Vlan_id));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	wan_connDev.iid.pcpeId.Id = 1;
	/* ADD PTM Channel Information */
	if (!gstrcmp(pSubmit_Action, T("addPTM"))) {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
		wan_connDev.iid.config_owner = IFX_WEB;
		wan_connDev.vc.pvc.vpi = 256;
		wan_connDev.vc.pvc.vci = 0;
		snprintf(wan_connDev.iid.cpeId.secName,
			 strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
			 TAG_WAN_CONN_DEVICE);
		//if ((ret = ifx_set_wan_conn_dev_Without_TR69(operation, &wan_connDev, flags)) != IFX_SUCCESS) 
		if ((ret =
		     ifx_set_wan_conn_dev(operation, &wan_connDev,
					  flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error-->Trying to get the ptm connection device iid !!\n\n",
			     __FUNCTION__);
#endif
			return;
		}

		snprintf(ptm_ch.iid.cpeId.secName, strlen(TAG_PTM_CHANNEL) + 1,
			 "%s", TAG_PTM_CHANNEL);
		ptm_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		strncpy(ptm_ch.iid.pcpeId.secName,
			wan_connDev.iid.pcpeId.secName,
			strlen(wan_connDev.iid.pcpeId.secName));
		ptm_ch.iid.config_owner = IFX_WEB;
		/* call the api to update the ptm channel section  */
		if (ifx_set_ptm_ch_cfg(operation, &ptm_ch, flags) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to set wan ptm channel config !!"));
			return;
		}
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
		/* ATM F5 Object created along with channel addition */
		atmf5_diag.iid.config_owner = IFX_WEB;
		atmf5_diag.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		atmf5_diag.vpi = 256;
		sprintf(atmf5_diag.iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
		sprintf(atmf5_diag.iid.pcpeId.secName, "%s",
			TAG_WAN_CONN_DEVICE);
		//ret = ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD, &atmf5_diag, IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE);
		ret =
		    ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD, &atmf5_diag,
						   IFX_F_INT_ADD);
		if (ret != IFX_SUCCESS)
			ifx_httpdError(wp, 500,
				       "Error : Failed to add the atmf5 object [%d/%d] !!",
				       atmf5_diag.vpi, atmf5_diag.vci);
		/* addition of dummy ATM channel */
		vcc.vc.pvc.vpi = 256;
		vcc.type = LINK_TYPE_PPPOE;
		snprintf(vcc.iid.cpeId.secName, strlen(TAG_ADSL_VCCHANNEL) + 1,
			 "%s", TAG_ADSL_VCCHANNEL);
		vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		strncpy(vcc.iid.pcpeId.secName, wan_connDev.iid.pcpeId.secName,
			strlen(wan_connDev.iid.pcpeId.secName));
		vcc.iid.config_owner = IFX_WEB;
		/* call the api to update the adsl vcchannel section for this vpi/vci */
		ret =
		    ifx_set_vcc_cfg(IFX_OP_ADD, &vcc,
				    IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE);
		if (ret == IFX_FAILURE)
			ifx_httpdError(wp, 400,
				       "Error : Failed to add the vc channel for [%d/%d] !!",
				       vcc.vc.pvc.vpi, vcc.vc.pvc.vci);
#endif
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
		memset(&eth_ch, 0x00, sizeof(eth_ch));
		gstrcpy(eth_ch.eth_ch_name, "");
		gstrcpy(eth_ch.mac_addr, "");
		eth_ch.vlanId = 4096;
		snprintf(eth_ch.iid.cpeId.secName, strlen(TAG_ETH_CHANNEL) + 1,
			 "%s", TAG_ETH_CHANNEL);
		eth_ch.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		strncpy(eth_ch.iid.pcpeId.secName,
			wan_connDev.iid.pcpeId.secName,
			strlen(wan_connDev.iid.pcpeId.secName));
		eth_ch.iid.config_owner = IFX_WEB;
		/* call the api to update the eth channel section  */
		ret =
		    ifx_set_eth_ch_cfg(IFX_OP_ADD, &eth_ch,
				       IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("In Function [%s] : Failed to set wan eth channel config !!",
			     __FUNCTION__);
#endif
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to set wan eth channel config !!"));
		}
#endif

	}
	/* Delete PTM Channel Information */
	else if (!gstrcmp(pSubmit_Action, T("delPTM"))) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
		PTM_CH_CFG *ptm_ch1 = NULL;
		memset(&ptm_ch1, 0x00, sizeof(ptm_ch1));
#if 0
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
		ETH_CH_CFG *eth_ch1 = NULL;
		memset(&eth_ch, 0x00, sizeof(eth_ch));
		if (ifx_get_all_eth_info(&num, &eth_ch1, IFX_F_DEFAULT) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to get Ethernet Channel information!"));
			IFX_MEM_FREE(eth_ch1);
			return;
		}
#endif
#endif

		/* Get all the PTM related information */
		if (ifx_get_all_ptm_info(&num, &ptm_ch1, IFX_F_DEFAULT) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to get the configured wan connections"));
			IFX_MEM_FREE(ptm_ch1);
			IFX_MEM_FREE(retVal);
			return;
		}
		for (i = 0; i < num; i++) {
			if (((ptm_ch1 + i)->vlanId) != 4096) {
				snprintf(remove, sizeof(remove), "remove%d",
					 (ptm_ch1 + i)->iid.cpeId.Id);
				remove_num = NULL;
				remove_num =
				    ifx_httpdGetVar(wp, T(remove), T(""));
				if (!gstrcmp(remove_num, "1")) {
					/* Check if there's a WAN connection already configured on
					 * the selected PTM Channel. In this case, it cannot be deleted */
					sprintf(sBuf, "%u",
						(ptm_ch1 + i)->vlanId);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_WAN_MAIN,
					      "vlanId", sBuf,
					      &retVal)) == IFX_SUCCESS) {
						ifx_httpdError(wp, 400,
							       "This Ptm Channel is currently being used - Cannot Delete !!");
						IFX_MEM_FREE(ptm_ch1);
						IFX_MEM_FREE(retVal)
						    return;
					}

					/* Populate the WAN Connection Device and PTM Channel Information */
					wan_connDev.iid.cpeId.Id =
					    (ptm_ch1 + i)->iid.pcpeId.Id;
					wan_connDev.iid.config_owner = IFX_WEB;
					/* Special Value of VPI/VCI */
					wan_connDev.vc.pvc.vpi = 0;
					wan_connDev.vc.pvc.vci = 0;
					snprintf(wan_connDev.iid.cpeId.secName,
						 strlen(TAG_WAN_CONN_DEVICE) +
						 1, "%s", TAG_WAN_CONN_DEVICE);
					snprintf((ptm_ch1 +
						  i)->iid.cpeId.secName,
						 strlen(TAG_PTM_CHANNEL) + 1,
						 "%s", TAG_PTM_CHANNEL);
					strncpy((ptm_ch1 +
						 i)->iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					(ptm_ch1 + i)->iid.config_owner =
					    IFX_WEB;
#if 0
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
					snprintf((eth_ch1 +
						  i)->iid.cpeId.secName,
						 strlen(TAG_ETH_CHANNEL) + 1,
						 "%s", TAG_ETH_CHANNEL);
					strncpy((eth_ch1 +
						 i)->iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					(eth_ch1 + i)->iid.config_owner =
					    IFX_WEB;
					if (ifx_set_eth_ch_cfg
					    (operation, (eth_ch1 + i),
					     flags) != IFX_SUCCESS) {
						ifx_httpdError(wp, 500,
							       T
							       ("Error deleting vc channel entry  !!"));
						return;
					}
#endif
#endif

					/* delete dummy eth wan vc section */
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
					memset(&eth_ch, 0x00, sizeof(eth_ch));
					eth_ch.iid.config_owner = IFX_WEB;
					eth_ch.iid.pcpeId.Id =
					    wan_connDev.iid.cpeId.Id;
					IFX_MEM_FREE(retVal)
					    sprintf(sValue, "%d",
						    eth_ch.iid.pcpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_ETH_CHANNEL,
					      "pcpeId", sValue,
					      &retVal)) != IFX_SUCCESS) {
						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for eth channel!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					sprintf(sBuf, "%s_cpeId", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_ETH_CHANNEL,
					     sBuf, IFX_F_GET_ENA,
					     (IFX_OUT uint32 *) & outFlag1,
					     sValue) != IFX_SUCCESS) {
						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for eth channel!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					eth_ch.iid.cpeId.Id = atoi(sValue);
					sprintf(eth_ch.iid.cpeId.secName, "%s",
						TAG_ETH_CHANNEL);
					sprintf(eth_ch.iid.pcpeId.secName, "%s",
						TAG_WAN_CONN_DEVICE);
					ret =
					    ifx_set_eth_ch_cfg(IFX_OP_DEL,
							       &eth_ch,
							       IFX_F_DELETE);
					if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("In Function [%s] : Failed to set wan eth channel config !!",
						     __FUNCTION__);
#endif
						ifx_httpdError(wp, 500,
							       T
							       ("Error deleting vc channel entry  !!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
#endif

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT

					/* deletion of corresponding dummy atm channel */

					memset(&vcc, 0x00, sizeof(vcc));
					snprintf(vcc.iid.cpeId.secName,
						 strlen(TAG_ADSL_VCCHANNEL) + 1,
						 "%s", TAG_ADSL_VCCHANNEL);
					vcc.iid.pcpeId.Id =
					    wan_connDev.iid.cpeId.Id;
					strncpy(vcc.iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					vcc.iid.config_owner = IFX_WEB;
					IFX_MEM_FREE(retVal)

					    sprintf(sValue, "%d",
						    vcc.iid.pcpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					      "pcpeId", sValue,
					      &retVal)) != IFX_SUCCESS) {

						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the pcpeid for corresponding vcc channel!!"));
						return;
					}

					sprintf(sBuf, "%s_cpeId", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					     sBuf, IFX_F_GET_ENA,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {

						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for corresponding vcc channel!!"));
						return;
					}

					vcc.iid.cpeId.Id = atoi(sValue);
					IFX_DBG
					    ("\n\n In Function [%s:%d]  vcc.iid.cpeId.Id -> %d\n\n",
					     __FUNCTION__, __LINE__,
					     vcc.iid.cpeId.Id);
					ret =
					    ifx_set_vcc_cfg(operation, &vcc,
							    flags);
					if (ret == IFX_FAILURE) {
						ifx_httpdError(wp, 500,
							       "Error deleting corresponding vc channel entry !!");
						IFX_MEM_FREE(retVal)
						    return;
					}

					/* deletion of corresponding dummy atm f5 object */

					memset(&atmf5_diag, 0x00,
					       sizeof(atmf5_diag));
					snprintf(vcc.iid.cpeId.secName,
						 strlen(TAG_WAN_ATMF5) + 1,
						 "%s", TAG_WAN_ATMF5);
					atmf5_diag.iid.pcpeId.Id =
					    wan_connDev.iid.cpeId.Id;
					strncpy(atmf5_diag.iid.pcpeId.secName,
						wan_connDev.iid.pcpeId.secName,
						strlen(wan_connDev.iid.pcpeId.
						       secName));
					atmf5_diag.iid.config_owner = IFX_WEB;
					IFX_MEM_FREE(retVal)
					    sprintf(sValue, "%d",
						    atmf5_diag.iid.pcpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_WAN_ATMF5,
					      "pcpeId", sValue,
					      &retVal)) != IFX_SUCCESS) {

						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the pcpeid for corresponding atm f5 object!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					sprintf(sBuf, "%s_cpeId", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_WAN_ATMF5, sBuf,
					     IFX_F_GET_ENA,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {

						ifx_httpdError(wp, 405,
							       T
							       ("Failed to find the cpeid for corresponding atm f5 object!!"));
						IFX_MEM_FREE(retVal)
						    return;
					}
					atmf5_diag.iid.cpeId.Id = atoi(sValue);
					IFX_DBG
					    ("\n\n In Function [%s:%d]  atmf5_diag.iid.cpeId.Id  -> %d\n\n",
					     __FUNCTION__, __LINE__,
					     atmf5_diag.iid.cpeId.Id);
					ret =
					    ifx_set_atmf5_loop_diagnostics
					    (operation, &atmf5_diag, flags);
					if (ret == IFX_FAILURE) {

						ifx_httpdError(wp, 500,
							       "Error deleting corresponding atm f5 object !!");
						IFX_MEM_FREE(retVal)
						    return;
					}
#endif

					if (ifx_set_ptm_ch_cfg
					    (operation, (ptm_ch1 + i),
					     flags) != IFX_SUCCESS) {
						ifx_httpdError(wp, 500,
							       T
							       ("Error deleting ptm channel entry  !!"));
						return;
					}
					//if((ret = ifx_set_wan_conn_dev_Without_TR69(operation, &wan_connDev, flags)) != IFX_SUCCESS) 
					if ((ret =
					     ifx_set_wan_conn_dev(operation,
								  &wan_connDev,
								  flags)) !=
					    IFX_SUCCESS) {
						ifx_httpdError(wp, 500,
							       "Error deleting ptm connection device entry !!");
						return;
					}
				}
			}
		}
		//IFX_MEM_FREE(eth_ch1);
		IFX_MEM_FREE(ptm_ch1);
		websNextPage(wp);
	} else {
		operation = 0;
	}
	if (!strcmp(page, "wan_ptm_channel_creation.asp"))
		ifx_httpdRedirect(wp, T("ptm_channel_config.asp"));
	else
		websNextPage(wp);
}

int ifx_cgi_set_wan_config(int32 operation, WAN_CONN_CFG * wan_cfg,
			   uint32 flags)
{
	int32	ret = IFX_SUCCESS;
#if 0
	WAN_MODE WanType;
	WAN_PHY_CFG pstWanPhy;
	WAN_COMMON_CFG pWan;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	WanType = ifx_get_wan_mode_selected();
	GET_WAN_COMM_PTR(pWan, wan_cfg)
	if( WanType == WAN_MODE_ATM)
	{
	pWan.wan_mode.mode = WAN_MODE_ATM;
	} 
	else if( WanType == WAN_MODE_PTM)
	{
	// TBD: vlan id is not stored in WAN section now. Think how to handle ? 

	// Extract the pCPEId from the WAN_VCC value: PTMx where x: pCPEId 
	//           if (ifx_GetObjData(FILE_SYSTEM_STATUS,TAG_WAN_MAIN,"WAN_VCC", IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS);
	pWan.iid.pcpeId.Id=atoi(sValue + 3);
	ret=ifx_get_another_fvp_from_dist_fvp(TAG_PTM_CHANNEL, "pcpeId", sValue + 3, "vlanId",svlanId, IFX_F_GET_ANY);
	if(ret != IFX_SUCCESS){
	IFX_DBG("[%s:%d] Error is finding ptm vlan ID, return vlan Id is : %s",__FUNCTION__,__LINE__,svlanId);
	return -1;
	}
	wan_cfg->vlanId=atoi(svlanId);
	if(pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
	//wan_cfg->wan_mode.mode = WAN_MODE_PTM;
	pWan.wan_mode.mode = WAN_MODE_PTM;
	else if(pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
	//wan_cfg->wan_mode.mode = WAN_MODE_VDSL_PTM;
	pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
	IFX_DBG("[%s:%d] wan mode [%d]", __FUNCTION__, __LINE__, pWan.wan_mode.mode);

	}
	else
	{
	// TBD: vlan id is not stored in WAN section now. Think how to handle ? 
	#if 0
	// Extract the pCPEId from the WAN_VCC value: ETHx where x: pCPEId 
	if (ifx_GetObjData(FILE_SYSTEM_STATUS,TAG_WAN_MAIN,"WAN_VCC", IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS);
	wan_cfg->iid.pcpeId.Id=atoi(sValue + 3);
	ret=ifx_get_another_fvp_from_dist_fvp(TAG_ETH_CHANNEL, "pcpeId", sValue + 3, "vlanId",svlanId, IFX_F_GET_ANY);
	if(ret != IFX_SUCCESS){
	IFX_DBG("[%s:%d] Error is finding eth vlan ID, return vlan Id is : %s",__FUNCTION__,__LINE__,svlanId);
	return -1;
	}
	wan_cfg->vlanId=atoi(svlanId);
	IFX_DBG("[%s:%d] phy mode [%d]", __FUNCTION__, __LINE__, pstWanPhy.phy_mode);
	if(pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0 || pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
	wan_cfg->wan_mode.mode = WAN_MODE_ETH0;
	if(pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
	wan_cfg->wan_mode.mode = WAN_MODE_ETH1;
	IFX_DBG("[%s:%d] wan mode [%d]", __FUNCTION__, __LINE__, wan_cfg->wan_mode.mode);
	#endif // 0
	}
	if (ifx_mapi_set_wan_config(operation, wan_cfg, flags) != IFX_SUCCESS) {
		return -1;
	}
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;

#else

	ret = ifx_mapi_set_wan_config(operation, wan_cfg, flags);
	return ret;
#endif
}

int ifx_get_wan_setting_config(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	int wanip_count = 0, wanppp_count = 0, i = 0, j = 0;
	char_t sValue[100];
	sValue[0] = '\0';
	/* Pramod : Not working properly, so commented
	int current_wan = 1;
	if (ifx_GetCfgData
	    (FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC", sValue) == 1)
		current_wan = atoi(sValue);
	*/

	if (ifx_get_sec_count(TAG_WAN_IP, &wanip_count) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}
	if (ifx_get_sec_count(TAG_WAN_PPP, &wanppp_count) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	for (j = 0; j < 2; j++) {
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
		//v "wanppp_0_*" is reserved for CELL WAN, We are forbidding user to view CELLWAN's PPP info
		//v Traverse from "1" for WANPPP
		for (i = (j == 0 ? 0 : 1); i < (j == 0 ? wanip_count : wanppp_count); i++) {
#else
		for (i = 0 ; i < (j == 0 ? wanip_count : wanppp_count); i++) {
#endif
	
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			if (j == 0) {	/* WANIP connections are getting traversed */
				//ifx_httpdWrite(wp,T("document.write(\"<td id=\'wan_vcc_no%d\'><span class='decBold'>WANIP%d</span></td>\");\n"),i, i);
				ifx_httpdWrite(wp,T("document.write(\"<td>\");\n"));
				ifx_httpdWrite(wp,T("document.write(\"<input type=radio name='WAN' value='%d' onClick=update_type('WANIP%d');\");\n"),i, i);
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
                                ifx_httpdWrite( wp,T("get_wan_mode(%d,\"IP\");\n"), i );
#endif			
				ifx_httpdWrite(wp,T("document.write(\"></td>\");\n"));
				ifx_httpdWrite(wp,T("document.write(\"<td id=\'wan_vcc_no%d\'><span class='decBold'>\");\n"),i);
				ifx_httpdWrite(wp, T("update_conname(\"IP\",%d);"),i);
				ifx_httpdWrite(wp,T("document.write(\"</span>\");\n"));
				ifx_httpdWrite(wp,T("document.write(\"</td>\");\n"));
			} else {
				//ifx_httpdWrite(wp,T("document.write(\"<td id=\'wan_vcc_no%d\'><span class='decBold'>WANPPP%d</span></td>\");\n"), i, i);
				ifx_httpdWrite(wp,T("document.write(\"<td>\");\n"));
				ifx_httpdWrite(wp,T("document.write(\"<input type=radio name='WAN' value='%d' onClick=update_type('WANPPP%d');\");\n"),i, i);
				ifx_httpdWrite(wp,T("document.write(\"></td>\");\n"));
				ifx_httpdWrite(wp,T("document.write(\"<td id=\'wan_vcc_no%d\'><span class='decBold'>\");\n"),i);
				ifx_httpdWrite(wp, T("update_conname(\"PPP\",%d);"),i);
				ifx_httpdWrite(wp,T("document.write(\"</span>\");\n"));
				ifx_httpdWrite(wp,T("document.write(\"</td>\");\n"));
			}
			/* Pramod : not working properly, so commented
			if (i == current_wan)
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\" checked \");"));
			*/
			ifx_httpdWrite(wp,T("document.write(\"<td id=\'wan_vcc_wch%d\'>\");\n"),i);
			if (j == 0) {	/* WANIP connections are getting traversed */
				ifx_httpdWrite(wp, T("get_vcc_enc(%d,\"IP\");"),i);
			} else {
							ifx_httpdWrite(wp,
															T("get_vcc_enc(%d,\"PPP\");"),
															i);
			}
			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td id=\'wan_vcc_type%d\'>\");\n"),
				       i);
			if (j == 0) {	/* WANIP connections are getting traversed */
				ifx_httpdWrite(wp, T("get_type(%d,\"IP\");"),
					       i);
			} else {
				ifx_httpdWrite(wp, T("get_type(%d,\"PPP\");"),
					       i);
			}
			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td id=\'wan_vcc_gway%d\'>\");\n"),
				       i);
			if (j == 0) {	/* WANIP connections are getting traversed */
				ifx_httpdWrite(wp,
					       T
					       ("get_default_gateway(%d,\"IP\");\n"),
					       i);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("get_default_gateway(%d,\"PPP\");\n"),
					       i);
			}
			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));
		}
	}

	/* Set WAN_VCC value to NULL in system_status file. This value is used to know
	   which WAN connection is selected for modify/delete operation */
	sprintf(sValue, "WAN_VCC=\"\"\n");
	ifx_SetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select",
		       IFX_F_MODIFY, 1, sValue);
	return IFX_SUCCESS;
}

int ifx_get_wan_status_config(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	//char *result = NULL;
	int wan_idx = 1, i = 0, j = 0, cnt = 0;
	int wanip_count = 0, wanppp_count = 0, ret = 0, tmp = 0;
	//WAN_CONN_CFG *p_wancfg = NULL;
	WAN_CONN_CFG wan_cfg;
	WAN_PHY_CFG pstWanPhy;
	ifx_get_wan_phy_cfg(&pstWanPhy);
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
	int cwan_idx = 0;
	char8 sValue[100];
	uint32 outFlag = IFX_F_DEFAULT;
	LTQ_MAPI_Cell_WAN cell_wan;
#endif
#ifdef CONFIG_FEATURE_IPv6
	char *name = NULL;
	if (ifx_httpd_parse_args(argc, arg_v, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
#endif

	/* if Wan mode is 3G Display Values of active 3G wan */

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_CELL_WAN) {
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_CELL_WAN, "cell_wan_Count",
		     IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
		     sValue) != IFX_SUCCESS) {
		#ifdef IFX_LOG_DEBUG	
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
			return IFX_FAILURE;
		}
		cwan_idx = atoi(sValue);
		if (ifx_GetObjData
                    (FILE_RC_CONF, TAG_WAN_PPP, "wanppp_0_connName",
                     IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
                     sValue) != IFX_SUCCESS) {
                #ifdef IFX_LOG_DEBUG    
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
                #endif
                        return IFX_FAILURE;
                }

		for (i = 0; i < cwan_idx; i++) {

			ret = ltq_mapi_get_cell_wan(&cell_wan, i, 0);
			if ((ret == IFX_SUCCESS)) {
				if (cell_wan.ena) {

					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<tr>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td>%d</td>\");\n"),
						       i);
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td>WWAN</td>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td>PPP</td>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td>%s</td>\");\n"),
						       cell_wan.STATUS);
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td >%s</td>\");\n")
						       , cell_wan.IP);
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td >%s</td>\");\n"),
						       cell_wan.MASK);
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td>%s</td>\");\n"),
						       sValue);

					if (!gstrcmp
					    (cell_wan.STATUS, "CONNECTED")) {
						ifx_httpdWrite(wp,
							       T
							       ("document.write(\"<td class='colInput'><a class='button' href='#' value='Disconnect' name='disconnect' onClick='suspend(%d);'>Disconnect</a></td>\");\n"),
							       i);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("document.write(\"<td class='colInput'><a class='button' href='#' value='Connect' name='connect' onClick='resume(%d);'>Connect</a></td>\");\n"),
							       i);
					}
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"</tr>\");\n"));
				}	//check if any cell wan active
			}
		}
#endif
	} else {
		/* IF NOT 3G */
		/*
		   sValue[0]='\0';
		   if (ifx_GetObjData(FILE_RC_CONF, "wan_main", "wan_main_index", IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
		   return 0;
		   }
		   sValue[strlen(sValue)-1]='\0';
		   result = strtok( sValue, "," );
		   while( result != NULL ) {
		   pValue[length]=atoi(result);length++;
		   result = strtok( NULL,"," );
		   }

		   for(i=0; i<length-1;i++)
		   {
		   for (j=i+1;j<length;j++)
		   {
		   if (pValue[i] > pValue[j])
		   {
		   pValue[i]^=pValue[j];
		   pValue[j]^=pValue[i];
		   pValue[i]^=pValue[j];
		   }
		   }
		   }
		 */

		if (ifx_get_sec_count(TAG_WAN_IP, &wanip_count) != IFX_SUCCESS) {
		}

		if (ifx_get_sec_count(TAG_WAN_PPP, &wanppp_count) !=
		    IFX_SUCCESS) {
		}

		for (j = 0; j < 2; j++) {
			cnt = (j == 0) ? wanip_count : wanppp_count;
			wan_cfg.type = (j == 0) ? WAN_TYPE_IP : WAN_TYPE_PPP;
			for (i = 0; i < cnt; i++) {

				if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
					if (pstWanPhy.wan_tc == WAN_TC_ATM) {
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ATM,IFX_F_GET_ANY);
					} else {
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_PTM,IFX_F_GET_ANY);
					}
				} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) {
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH0,IFX_F_GET_ANY);
				} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg,WAN_MODE_ETH1,IFX_F_GET_ANY);
				} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) {
					if (pstWanPhy.wan_tc == WAN_TC_ATM) {
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_ATM,IFX_F_GET_ANY);
					} else {
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_PTM,IFX_F_GET_ANY);
					}
				}
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
				else if(pstWanPhy.phy_mode == WAN_PHY_MODE_LTE){
						ret = mapi_get_wan_config_for_mode(i, &wan_cfg,WAN_MODE_LTE,IFX_F_GET_ANY);
				}
#endif

				if (ret == IFX_SUCCESS) {
					tmp++;
					wan_idx = i;
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<tr>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td id=\'wan_no%d\'>%d</td>\");\n"),
						       wan_idx, tmp);
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td id=\'wan_channel%d\'>\");\n"),
						       wan_idx);
					if (j == 0) {	/* IP connections are being traversed */
						ifx_httpdWrite(wp,
							       T
							       ("get_vcc_enc(%d,\"IP\");\n"),
							       wan_idx);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("get_vcc_enc(%d,\"PPP\");\n"),
							       wan_idx);
					}
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"</td>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td id=\'wan_ctype%d\'>\");\n"),
						       wan_idx);
					if (j == 0) {	/* IP connections are being traversed */
						ifx_httpdWrite(wp,
							       T
							       ("get_type(%d,%s,\"IP\");\n"),
							       wan_idx, "true");
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("get_type(%d,%s,\"PPP\");\n"),
							       wan_idx, "true");
					}
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"</td>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td id=\'wan_status%d\'>\");\n"),
						       wan_idx);
					if (j == 0) {	/* IP connections are being traversed */
						ifx_httpdWrite(wp,
							       T
							       ("get_wan_if_info(%d,2,\"IP\");\n"),
							       wan_idx);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("get_wan_if_info(%d,2,\"PPP\");\n"),
							       wan_idx);
					}
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"</td>\");\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td id=\'wan_ip%d\'>\");\n"),
						       wan_idx);
					if (j == 0) {	/* IP connections are being traversed */
						ifx_httpdWrite(wp,
							       T
							       ("get_wan_if_info(%d,0,\"IP\");\n"),
							       wan_idx);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("get_wan_if_info(%d,0,\"PPP\");\n"),
							       wan_idx);
					}
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"</td>\");\n"));
#ifdef CONFIG_FEATURE_IPv6
					if (gstrcmp(name, "IPv6")) {
#endif
						ifx_httpdWrite(wp,
							       T
							       ("document.write(\"<td id=\'wan_nmask%d\'>\");\n"),
							       wan_idx);
						if (j == 0) {	/* IP connections are being traversed */
							ifx_httpdWrite(wp,
								       T
								       ("get_wan_if_info(%d,1,\"IP\");\n"),
								       wan_idx);
						} else {
							ifx_httpdWrite(wp,
								       T
								       ("get_wan_if_info(%d,1,\"PPP\");\n"),
								       wan_idx);
						}
						ifx_httpdWrite(wp,
							       T
							       ("document.write(\"</td>\");\n"));
#ifdef CONFIG_FEATURE_IPv6
					}
#endif
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td id=\'wan_conf_cname%d\'>\");\n"),
						       wan_idx);
					if (j == 0) {	/* IP connections are being traversed */
						ifx_httpdWrite(wp,
							       T
							       ("get_wan_conn_name(%d,\"IP\");\n"),
							       wan_idx);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("get_wan_conn_name(%d,\"PPP\");\n"),
							       wan_idx);
					}
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"</td>\");\n"));
					if (j == 0) {	/* IP connections are being traversed */
						ifx_httpdWrite(wp,
							       T
							       ("wanMode = get_type(%d,%s,\"IP\");\n"),
							       wan_idx,
							       "false");
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("wanMode = get_type(%d,%s,\"PPP\");\n"),
							       wan_idx,
							       "false");
					}
					ifx_httpdWrite(wp,
						       T
						       ("if (wanMode == 1)\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td class='colInput'><a class='button' href='#' value='Release' name='rlease' onClick='suspend(%d, \\\"ip\\\");'>Release</a><a class='button' href='#' value='Renew' name='rnew' onClick='resume(%d,\\\"ip\\\");'>Renew</a></td>\");"),
						       wan_idx, wan_idx);
					ifx_httpdWrite(wp,
						       T
						       ("else if (wanMode == 3){\n"));
					ifx_httpdWrite(wp,
						       T
						       ("if (w_status == \"CONNECTED\"){\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td class='colInput'><a class='button' href='#' value='Disconnect' name='disconnect' onClick='suspend(%d, \\\"ppp\\\");'>Disconnect</a></td>\");\n"),
						       wan_idx);
					ifx_httpdWrite(wp, T("}else\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td class='colInput'><a class='button' href='#' value='Connect' name='connect' onClick='resume(%d, \\\"ppp\\\");'>Connect</a></td>\");\n"),
						       wan_idx);
					ifx_httpdWrite(wp, T("}\n"));
					ifx_httpdWrite(wp,
						       T
						       ("else if (wanMode == 4)\n"));
					ifx_httpdWrite(wp,
						       T
						       ("document.write(\"<td class='colInput'><a class='button' href='#' value='Disconnect' name='disconnect' onClick='suspend(%d, \\\"ppp\\\");'>Disconnect</a><a class='button' href='#' value='Connect' name='connect' onClick='resume(%d, \\\"ppp\\\");'>Connect</a></td>\");\n"),
						       wan_idx, wan_idx);
					ifx_httpdWrite(wp,
						       T
						       ("else\ndocument.write(\"<td>&nbsp;</td></tr>\");\n"));
				}
			}
		}
	}
	return IFX_SUCCESS;
}

int ifx_get_wan_mode_check(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char_t phy_mode[8] = {0};
	char_t phy_tc[8] = {0};
	char_t *name;
	char_t sValue[100];
	int length = 0;
#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS
	int iad = 1;
#endif
	uint32 outFlag = IFX_F_DEFAULT;
	if (ifx_httpd_parse_args(argc, arg_v, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, T("wanphy_phymode"))) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_phymode",
						IFX_F_DEFAULT, &outFlag, phy_mode);
		ifx_httpdWrite(wp, T("%d"), atoi(phy_mode));
	}

	if (!gstrcmp(name, T("wanphy_settc"))) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_settc",
						IFX_F_DEFAULT, &outFlag, phy_tc);
		ifx_httpdWrite(wp, T("%d"), atoi(phy_tc));
	}

	if (!gstrcmp(name, T("wan_phymode"))) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG,
			"wanphy_setphymode", IFX_F_DEFAULT, &outFlag,phy_tc);
		ifx_httpdWrite(wp, T("%d"), atoi(phy_tc));
	}

	if (!gstrcmp(name, T("wan_Vlan"))) {
		ifx_GetCfgData(FILE_RC_CONF, TAG_WAN_VLAN, "WAN_VLAN_STATUS",phy_tc);
		ifx_httpdWrite(wp, T("%d"), atoi(phy_tc));
	}

	if (!gstrcmp(name, T("wanphy_tc"))) {
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_tc",
						IFX_F_DEFAULT, &outFlag, phy_tc);
		ifx_httpdWrite(wp, T("%d"), atoi(phy_tc));
	}
#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	if (!gstrcmp(name, T("dual_wan_graph"))) {
		ifx_GetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, "dw_failover_state",
                                                        IFX_F_DEFAULT, &outFlag, phy_mode);
		if(atoi(phy_mode) != 0) {
                	ifx_GetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, "dw_sec_wanphy_phymode",
                                                        IFX_F_DEFAULT, &outFlag, phy_mode);

	                ifx_GetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, "dw_sec_wanphy_tc",
                                                        IFX_F_DEFAULT, &outFlag, phy_tc);
			ifx_httpdWrite(wp, T("}, {\n name : \""));
			if (atoi(phy_mode) == 0 && atoi(phy_tc) == 0) {
				ifx_httpdWrite(wp, T("ADSL-ATM"));
			} else if (atoi(phy_mode) == 1) {
				ifx_httpdWrite(wp, T("Ethernet-MII-0"));
			} else if (atoi(phy_mode) == 2) {
				ifx_httpdWrite(wp, T("Ethernet-MII-1"));
			} else if (atoi(phy_mode) == 0 && atoi(phy_tc) == 1) {
				ifx_httpdWrite(wp, T("ADSL-PTM"));
			} else if (atoi(phy_mode) == 3) {
				ifx_httpdWrite(wp, T("VDSL-PTM"));
			} else if (atoi(phy_mode) == 6) {
				ifx_httpdWrite(wp, T("LTE"));
			}
			ifx_httpdWrite(wp, T(" I/O\", \n lineWidth: 0.5,\n data: sec_vdsl2IO,\n"));
			ifx_httpdWrite(wp, T(" pointStart: dateStart,\n pointInterval: 30 * 1000\n"));
		}
	}
#endif
	if (!gstrcmp(name, T("wan_graph"))) {
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
		ifx_GetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, "dw_failover_state",
                                                        IFX_F_DEFAULT, &outFlag, phy_mode);
		if(atoi(phy_mode) != 0) {
			ifx_GetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, "dw_pri_wanphy_phymode",
                                                        IFX_F_DEFAULT, &outFlag, phy_mode);

                        ifx_GetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, "dw_pri_wanphy_tc",
                                                        IFX_F_DEFAULT, &outFlag, phy_tc);
		} else {
#endif
			ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_phymode",
							IFX_F_DEFAULT, &outFlag, phy_mode);
			ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_tc",
							IFX_F_DEFAULT, &outFlag, phy_tc);
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
		}
#endif
		if (atoi(phy_mode) == 0 && atoi(phy_tc) == 0) {
			ifx_httpdWrite(wp, T("ADSL-ATM"));
		} else if (atoi(phy_mode) == 1) {
			ifx_httpdWrite(wp, T("Ethernet-MII-0"));
		} else if (atoi(phy_mode) == 2) {
			ifx_httpdWrite(wp, T("Ethernet-MII-1"));
		} else if (atoi(phy_mode) == 0 && atoi(phy_tc) == 1) {
			ifx_httpdWrite(wp, T("ADSL-PTM"));
		} else if (atoi(phy_mode) == 3) {
			ifx_httpdWrite(wp, T("VDSL-PTM"));
		} else if (atoi(phy_mode) == 6) {
			ifx_httpdWrite(wp, T("LTE"));
		}
	}

	if (!gstrcmp(name, T("IAD"))) {
#ifdef CONFIG_FEATURE_IFX_VOIP
		ifx_httpdWrite(wp, T("%d"), iad);
#endif
#ifndef CONFIG_FEATURE_IFX_VOIP
		iad = 0;
		ifx_httpdWrite(wp, T("%d"), iad);
#endif
	}
	if (!gstrcmp(name, T("Tflow"))) {
		char T_flow[5];
		FILE *pFile;
		if (system("cat /proc/sys/net/netfilter/nf_conntrack_count > /tmp/x.txt")== 0) {
			pFile = fopen("/tmp/x.txt", "r");
			if (pFile == NULL ){
				ifx_httpdError(wp,400,T("Unable to open data file\n"));
				return -1;
			}
			while (feof(pFile) <= 0) {
				if (fscanf(pFile, "%5s", T_flow) <= 0) {
					ifx_httpdWrite(wp, T("%d"),atoi(T_flow));
				}
			}
			if (pFile != NULL)
				fclose(pFile);
		}
	}
	if (!gstrcmp(name, T("WLAN"))) {
		int W = 1;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		ifx_httpdWrite(wp, T("%d"), W);
#endif
#ifndef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		W = 0;
		ifx_httpdWrite(wp, T("%d"), W);
#endif
	}
	if (!gstrcmp(name, T("cpu_speed"))) {
		FILE *fp;
		int cpu_spd;
		fp = popen("cat /proc/driver/ifx_cgu/clk_setting  | grep 'cpu clock' | awk '{ print $4 }'", "r");
		if (fp == NULL)
			perror("unable to execute ls -l");
		else {
			fscanf(fp, "%d", &cpu_spd);
			ifx_httpdWrite(wp, T("%d"), cpu_spd);
			if (pclose(fp) == -1) {
				perror("unable to close file pointer of popen");
			}
		}
	}

	if (!gstrcmp(name, T("pecostat"))) {
		system("insmod /lib/modules/*/pecostat.ko &");
		ifx_httpdWrite(wp, T(""));
	}
#endif
	if (!gstrcmp(name, T("ip_stat"))) {
		sValue[0] = '\0';
		if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_Count", IFX_F_DEFAULT,&outFlag, sValue) != IFX_SUCCESS) {
			ifx_httpdWrite( wp,T("0"));
			return 0;
		}
		length = atoi( sValue );
		ifx_httpdWrite(wp, T("%d"), length);
	}

	if (!gstrcmp(name,T("ppp_stat"))){
		sValue[0] = '\0';
		if (ifx_GetObjData( FILE_RC_CONF,"wan_ppp","wan_ppp_Count",IFX_F_DEFAULT,&outFlag,sValue) != IFX_SUCCESS){
			ifx_httpdWrite( wp,T("0"));
			return 0;
		}
		length = atoi( sValue );
		ifx_httpdWrite(wp,T("%d"),length);
	}
	return IFX_SUCCESS;
}

/*manohar : added to bring only default wan information*/
int ifx_get_default_RuntimeWanIPMask(int eid, httpd_t wp, int argc,char_t ** argv)
{
	char_t  sTAG_NAME[MAX_NAME_SIZE],sValue[MAX_NAME_SIZE];
	char_t sCFG_NAME[MAX_NAME_SIZE], sNM[MAX_IP_ADDR_LEN];
	char_t link_name[MAX_FILELINE_LEN], sAtmProto[MAX_FILELINE_LEN];
	IP_TYPE nWanType;
	uint32 outFlag = IFX_F_DEFAULT;
	char *name = NULL, *secName = NULL, *def = "UNDEFINED";
	int nWanMode = IP_BOOT_UNKNOWN, j = 0;
	WAN_CONN_CFG wan_cfg;
	char wanConnName[MAX_CONN_NAME_LEN];
	WAN_PHY_CFG pstWanPhy;
	/* code for getting default wan index */
	IFX_ID iid;
	int32 nWAN_IDX = 0;
	/* Get current global wan mode */
	ifx_get_wan_phy_cfg(&pstWanPhy);
	memset(&iid, 0x00, sizeof(iid));
	if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT) != IFX_SUCCESS) 
	{
		IFX_DBG("[%s:%d] [Failed to bring default wan index]",__FUNCTION__, __LINE__);
		return -1;
	}
	/*end */

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) 
	{
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, "IP")) 
	{
		sNM[0] = '\0';
		if (strstr(wanConnName, "WANIP")) 
		{
			sprintf(sCFG_NAME, "WanIP%d_IF_Info", nWAN_IDX);
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCFG_NAME, name, IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sNM) != IFX_SUCCESS) 
				ifx_httpdWrite(wp,T("var WANIP_%s = \"%s\";\n"),name, def);
			else 
				ifx_httpdWrite(wp,T("var WANIP_%s = \"%s\";\n"),name, sNM);
		} else if (strstr(wanConnName, "WANPPP")) {
			sprintf(sCFG_NAME, "WanPPP%d_IF_Info", nWAN_IDX);
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCFG_NAME, name, IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sNM) != IFX_SUCCESS) 
				ifx_httpdWrite(wp,T("var WANPPP_%s = \"%s\";\n"),name, def);
			else 
				ifx_httpdWrite(wp,T("var WANPPP_%s = \"%s\";\n"),name, sNM);
		}
	}
	else if (!gstrcmp(name, "STATUS")) 
	{
		sValue[0] = '\0';
		if (strstr(wanConnName, "WANIP")) {
			sprintf(sTAG_NAME, "WanIP%d_IF_Info", nWAN_IDX);
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sTAG_NAME,name,IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sValue) != IFX_SUCCESS) 
			{
				for (j = 1; sValue[j] != '\0'; j++) 
				{
					if (sValue[j] >= 65 && sValue[j] <= 91)
						sValue[j] = sValue[j] + 32;
					}
				ifx_httpdWrite(wp,T("var WANIP_STATUS =\"%s\";\n"),def);
			}
			else
				ifx_httpdWrite(wp, T("var WANIP_STATUS =\"%s\";\n"),sValue);
		}
		if (strstr(wanConnName, "WANPPP")) 
		{
			snprintf(sTAG_NAME, sizeof(sTAG_NAME),"WanPPP%d_IF_Info", nWAN_IDX);
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sTAG_NAME,name,IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sValue) != IFX_SUCCESS) 
			{
				for (j = 1; sValue[j] != '\0'; j++) 
				{
					if (sValue[j] >= 65 && sValue[j] <= 91)
						sValue[j] = sValue[j] + 32;
					}
				ifx_httpdWrite(wp,T("var WANPPP_STATUS = \"%s\";\n"),def);
			}
			else
				ifx_httpdWrite(wp, T("var WANPPP_STATUS =\"%s\";\n"),sValue);
		}
	} else if (!gstrcmp(name, "Mode")) {
		link_name[0] = '\0';
		sAtmProto[0] = '\0';
		if (strstr(wanConnName, "WANIP")) 
		{
			wan_cfg.type = WAN_TYPE_IP;
			secName = TAG_WAN_IP;
			sprintf(sTAG_NAME, "wanip_%d_linkType", nWAN_IDX);
		} else if (strstr(wanConnName, "WANPPP")) 
		{
			wan_cfg.type = WAN_TYPE_PPP;
			secName = TAG_WAN_PPP;
			sprintf(sTAG_NAME, "wanppp_%d_linkType", nWAN_IDX);
		}
		if (ifx_GetObjData(FILE_RC_CONF, secName, sTAG_NAME, IFX_F_DEFAULT,(IFX_OUT uint32 *) & outFlag, sAtmProto) != IFX_SUCCESS) 
		{
			ifx_httpdWrite(wp, T("var ATM_PROTO = \"%s\";\n"), "");
			IFX_DBG("[%s:%d] [Failed to bring default wan atmproto]",__FUNCTION__, __LINE__);
		} 
		else 
		{
			get_atm_proto_name_by_id(link_name, atoi(sAtmProto));
			ifx_httpdWrite(wp, T("var ATM_PROTO = \"%s\";\n"),link_name);
		}

		if ( pstWanPhy.phy_mode == WAN_PHY_MODE_CELL_WAN && nWAN_IDX == 0) 
		{
			nWanMode = IP_BOOT_WWAN;
			ifx_httpdWrite(wp, T("var WAN_TYPE = %d;\n"), nWanMode);
		}
		else
		{
			if ((nWanMode = getWanMode(nWAN_IDX, wan_cfg.type)) == IFX_FAILURE) 
			{
				IFX_DBG("[%s:%d] [Failed to get wan mode of default wan]", __FUNCTION__, __LINE__);
			} 
			else 
			{
				if (nWanMode == IP_BOOT_ETH || nWanMode == IP_BOOT_PTM) 
				{
					if (ifx_get_wanip_conn_type(&nWanType,nWAN_IDX) == IFX_SUCCESS) 
					{
						switch (nWanType) 
						{
								case IP_TYPE_DHCP:
									nWanMode = IP_BOOT_DHCPC;
								break;
								case IP_TYPE_STATIC:
									nWanMode = IP_BOOT_FIXED;
								break;
								case IP_TYPE_AUTO:
									nWanMode = IP_BOOT_BRIDGE;
								break;
						}
					}
				}
			ifx_httpdWrite(wp, T("var WAN_TYPE = %d;\n"), nWanMode);
			}
		}
	}
	return 0;
}

int ifx_get_DhcpClientNum_default(int eid, httpd_t wp, int argc, char_t ** argv)
{
	/* Initialization Block */
	int ret, dhcp_client;

	/* API Call Block */
	ret =
	    ifx_read_dhcp_lease_file("dumpleases -s | grep -c seconds",
				     &dhcp_client);

	if (ret != IFX_SUCCESS) {
		return -1;
	}

	/* Error Check and HTML Block */
	if (ret != -1) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] [dhclient = %d]", __FUNCTION__, __LINE__,
			dhcp_client);
#endif
		ifx_httpdWrite(wp,
			       "document.write(\"<tr><td colspan='1'>Connected Clients</td><td colspan='2'>%d</td></tr>\");\n",
			       dhcp_client);
	} else
		ifx_httpdError(wp, 500, "Error");

	return 0;
}

int ifx_get_wlan_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	uint32 status_radio1 = 0;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	uint32 status_radio2 = 0;
#endif
	FILE *fp = NULL;
	char8 buf[MAX_FILELINE_LEN], *pTmpStr = NULL, *pTmpStr2;
	char8 sRadioDynInfo[MAX_DATA_LEN];
	uint32	radioCpeId = 1;

	if (ltq_mapi_get_wlan_vendor(radioCpeId, IFX_F_DEFAULT) ==
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		fp = popen("host_api get $$ wlan0 WLSEnabled", "r");

		if (!fp) {
			goto IFX_Handler;
		}

		status_radio1 = (int)fgetc(fp);
		status_radio1 -= 48;	// convert ascii to integer
		pclose(fp);
	} else {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		memset(sRadioDynInfo, 0x00, sizeof(sRadioDynInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_RADIO_DYN_INFO, radioCpeId-1);

		/* call script and store information */
		if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sRadioDynInfo) == 0) {
			IFX_DBG("[%s:%d] [Failed to get radio dyn info]", __FUNCTION__,
				__LINE__);
			goto IFX_Handler;
		}

		/* get status information */
		if ((pTmpStr = strstr(sRadioDynInfo, "status=")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				goto IFX_Handler;
			}
			status_radio1 = atoi(pTmpStr2);
		}
	}

	ifx_httpdWrite(wp, T("var wlan_status_0 = \""));
	if (status_radio1)
		ifx_httpdWrite(wp, T("1\";\n"));
	else
		ifx_httpdWrite(wp, T("0\";\n"));

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	/* radioCpeId hard-coded */
	radioCpeId = 2;
	if (ltq_mapi_get_wlan_vendor(radioCpeId, IFX_F_DEFAULT) ==
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		fp = popen("host_api get $$ wlan1 WLSEnabled", "r");

		if (!fp) {
			goto IFX_Handler;
		}

		status_radio2 = (int)fgetc(fp);
		status_radio2 -= 48;	// convert ascii to integer
		pclose(fp);
	} else {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		memset(sRadioDynInfo, 0x00, sizeof(sRadioDynInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_RADIO_DYN_INFO, radioCpeId-1);

		/* call script and store information */
		if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sRadioDynInfo) == 0) {
			IFX_DBG("[%s:%d] [Failed to get radio dyn info]", __FUNCTION__,
				__LINE__);
			goto IFX_Handler;
		}

		/* get status information */
		if ((pTmpStr = strstr(sRadioDynInfo, "status=")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				goto IFX_Handler;
			}
			status_radio2 = atoi(pTmpStr2);
		}
	}
	ifx_httpdWrite(wp, T("var wlan_status_1 = \""));
	if (status_radio2)
		ifx_httpdWrite(wp, T("1\";\n"));
	else
		ifx_httpdWrite(wp, T("0\";\n"));
#else
	ifx_httpdWrite(wp, T("var wlan_status_1;"));
#endif				/* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */

#else
	ifx_httpdWrite(wp, T("0"));
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */

#ifdef CONFIG_FEATURE_IFX_WIRELESS
      IFX_Handler:
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */
	return 0;
}

/*manohar end*/


#define WANIP 			"wanip"
#define WANPPP 			"wanppp"
#define TAG_DEF_WAN 	"def"
int ifx_get_default_wan_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_FILENAME_LEN], WAN_NAME[MAX_FILENAME_LEN];

	uint32 outFlag = IFX_F_DEFAULT;

	char sec_tag[MAX_FILENAME_LEN];

	int nWAN_IDX = 1, nWAN_MODE = 0, ret = 0;

	WAN_TYPE	wan_type;

	memset(sValue, 0x00, sizeof(sValue));

	IFX_GET_WAN_SELECTED_INDEX(IFX_F_DEFAULT, outFlag, sValue, nWAN_IDX, wan_type)
	    nWAN_MODE = ifx_get_wan_mode_selected();
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	memset(sValue, 0x00, sizeof(sValue));

	/*Frame WAN Name frome WAN Index passed by caller */
	sprintf(WAN_NAME, "%s%d",
		(wan_type == WAN_TYPE_IP) ? "WANIP" : "WANPPP", nWAN_IDX);

	/* default_wan_2_conn_connName */
	sprintf(sec_tag, "%s_%d_%s", "default_wan", nWAN_MODE, "conn_connName");
	ret =
	    ifx_GetCfgData(FILE_RC_CONF, "default_wan_cfg_fused", sec_tag,
			   sValue);

	if (ret == 1) {
		if (strcmp(sValue, WAN_NAME) == 0)
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));
	}

	return IFX_SUCCESS;
}

int ifx_get_vlan_config(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	int i = 0, idx_count = 0;
	uint32 flags = IFX_F_DEFAULT;
	vlan_ch_cfg_t *vlan_chcfg = NULL;

	if (mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get all VLAN info !!");
		IFX_MEM_FREE(vlan_chcfg);
		return -1;
	}

	if (idx_count != 0) {
		for(i=0; i<idx_count; i++) {
				if((vlan_chcfg+i)->vlanId != -1)
				{
				 ifx_httpdWrite(wp, T("<tr>\n"));
				 ifx_httpdWrite(wp, T("<td id=\'vlan_name%d\'>%s\n"), (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->chName);
				 ifx_httpdWrite(wp, T("</td>\n"));
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] i[%d] %s", __FUNCTION__, __LINE__, (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->chName);
#endif
				 ifx_httpdWrite(wp, T("<td id=\'base_wan_name%d\'>%s\n"), (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->baseIf);
				 ifx_httpdWrite(wp, T("</td>\n"));
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] i[%d] %s", __FUNCTION__, __LINE__, (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->baseIf);
#endif
				 ifx_httpdWrite(wp, T("<td id=\'vlan_id%d\'>%d\n"), (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->vlanId);
				 ifx_httpdWrite(wp, T("</td>\n"));
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] i[%d] %d", __FUNCTION__, __LINE__, (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->vlanId);
#endif
				 ifx_httpdWrite(wp, T("<td id=\'if_name%d\'>%s\n"), (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->l2ifName);
				 ifx_httpdWrite(wp, T("</td>\n"));
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] i[%d] %s", __FUNCTION__, __LINE__, (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->l2ifName);
#endif
				ifx_httpdWrite(wp, T("<td id=\'mac_addr%d\'>%s\n"), (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->macAddr);
				 ifx_httpdWrite(wp, T("</td>\n"));
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] i[%d] %s", __FUNCTION__, __LINE__, (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->macAddr);
#endif
				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<input type='checkbox' name='remove%d' value='1'>\n"),(vlan_chcfg+i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</td>\n"));
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] i[%d] %d", __FUNCTION__, __LINE__, (vlan_chcfg+i)->iid.cpeId.Id,(vlan_chcfg+i)->iid.cpeId.Id);
#endif
				ifx_httpdWrite(wp, T("</tr>\n"));
				}
		}
	} else {
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
			       T("<td colspan='5'>No Channel Configured</td>"));
		ifx_httpdWrite(wp, T("</tr>"));
	}

	IFX_MEM_FREE(vlan_chcfg);
	return IFX_SUCCESS;
}

/*vlan channel ADDITION*/

void cgi_set_vlan_ch_entry(httpd_t wp, char_t * path, char_t * query)
{
	char_t *vlan_channel_name = NULL;
	char_t sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	char_t *base_wan_name = NULL;
	char_t pscpe_sec[MAX_FILELINE_LEN];
	char_t *Vlan_id = NULL;
	char_t *Override_mac_add = NULL;
	char_t *Mac_addr = NULL;
	int32 ret = IFX_SUCCESS;
	char_t remove[15];
	char8 *retVal = NULL;
	char_t *pSubmit_Action = ifx_httpdGetVar(wp, T("submit_action_vlan"), T(""));
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	if(pSubmit_Action != NULL)
		if (!gstrcmp(pSubmit_Action, T("ads_update"))) {
			if(ltq_cgi_set_autodetect_config(wp, "vlan") == IFX_SUCCESS){
				ifx_httpdRedirect(wp, T("vlan_display.asp"));
			}
			return;
		}
#endif

	char_t *remove_num = NULL;
	uint32 flags = IFX_F_DEFAULT;
/* QS Modifications */
	char_t *pNewVcc = NULL;
	char8 buf[MAX_FILELINE_LEN];
	buf[0] = '\0';
	int status = 0;
	status = gatoi(ifx_httpdGetVar(wp, T("qs_status"), T("")));
/* QS Modifications END*/
	int operation = 0, num = 0, i = 0;
	int outFlag = IFX_F_DEFAULT;
#ifdef  CONFIG_FEATURE_PTM_WAN_SUPPORT
	PTM_CH_CFG ptm_ch;
	memset(&ptm_ch, 0x00, sizeof(ptm_ch));
#endif
	sValue[0] = '\0';
	sBuf[0] = '\0';

	//      WAN_PHY_CFG pstWanPhy;
	vlan_ch_cfg_t vlan_ch;
	//      ATM_VCC_INFO    vcc;

	memset(&vlan_ch, 0x00, sizeof(vlan_ch));
	//memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	//      memset(&vcc, 0x00, sizeof(vcc));


	base_wan_name = ifx_httpdGetVar(wp, T("Channel"), T(""));
	vlan_channel_name = ifx_httpdGetVar(wp, T("Vlan_channel_name"), T(""));
	Vlan_id = ifx_httpdGetVar(wp, T("vlan_id"), T(""));
	Override_mac_add = ifx_httpdGetVar(wp, T("override_mac_add"), T(""));
	Mac_addr = ifx_httpdGetVar(wp, T("mac_addr"), T(""));


	if (strstr(base_wan_name, "nas") != NULL) {
		/* QS Modifications */
		if (status != 1) {
			pNewVcc = ifx_httpdGetVar(wp, T("vcSetting"), T(""));
			if ((ret =
			     ifx_ret_substr_from_distfield(FILE_RC_CONF,
							   TAG_ADSL_VCCHANNEL,
							   "vcc", pNewVcc,
							   &retVal)) !=
			    IFX_SUCCESS) {
				return;
			} else {
				sprintf(buf, "%s_l2ifName", retVal);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf,
				     IFX_F_GET_ANY, NULL,
				     base_wan_name) == IFX_SUCCESS) {
				}
			}
		}
		/* QS Modifications END */
		gstrcpy(pscpe_sec, "adsl_vcchannel");
		sprintf(sBuf, "%s", base_wan_name);
		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_ADSL_VCCHANNEL,
						   "l2ifName", sBuf,
						   &retVal)) == IFX_SUCCESS) {
			sprintf(sBuf, "%s_cpeId", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sBuf,
			     IFX_F_GET_ENA, (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
				ifx_httpdError(wp, 405,
					       T
					       ("Failed to find the cpeid for eth channel!!"));
				IFX_MEM_FREE(retVal)
				    return;
			}
		}
		snprintf(vlan_ch.iid.pcpeId.secName,
			 strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
			 TAG_ADSL_VCCHANNEL);
		vlan_ch.iid.pcpeId.Id = atoi(sValue);

	} else if (strstr(base_wan_name, "eth") != NULL) {
		gstrcpy(pscpe_sec, "eth_channel");

		sprintf(sBuf, "%s", base_wan_name);
		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_ETH_CHANNEL, "l2ifName",
						   sBuf,
						   &retVal)) == IFX_SUCCESS) {
			sprintf(sBuf, "%s_cpeId", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_ETH_CHANNEL, sBuf, IFX_F_GET_ENA,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
				ifx_httpdError(wp, 405,
					       T
					       ("Failed to find the cpeid for eth channel!!"));
				IFX_MEM_FREE(retVal)
				    return;
			}
		}
		snprintf(vlan_ch.iid.pcpeId.secName,
			 strlen(TAG_ETH_CHANNEL) + 1, "%s", TAG_ETH_CHANNEL);
		vlan_ch.iid.pcpeId.Id = atoi(sValue);
	} else if (strstr(base_wan_name, "ptm") != NULL) {
		gstrcpy(pscpe_sec, "ptm_channel");

		sprintf(sBuf, "%s", base_wan_name);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]sBuf------------------>>>> %s", __FUNCTION__,
			__LINE__, sBuf);
#endif
		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_PTM_CHANNEL, "l2ifName",
						   sBuf,
						   &retVal)) == IFX_SUCCESS) {
			sprintf(sBuf, "%s_cpeId", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_PTM_CHANNEL, sBuf, IFX_F_GET_ENA,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
				ifx_httpdError(wp, 405,
					       T
					       ("Failed to find the cpeid for eth channel!!"));
				IFX_MEM_FREE(retVal)
				    return;
			}
		}

		IFX_MEM_FREE(retVal)

		snprintf(vlan_ch.iid.pcpeId.secName,
			 strlen(TAG_PTM_CHANNEL) + 1, "%s", TAG_PTM_CHANNEL);
		vlan_ch.iid.pcpeId.Id = atoi(sValue);
	} else {
           pscpe_sec[0] = '\0';
        }

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] mapi_set_vlan_ch_entry called, baseif [%s] [%s]",
		__FUNCTION__, __LINE__, vlan_ch.baseIf, base_wan_name);
#endif
	strncpy(vlan_ch.baseIf, base_wan_name, strlen(base_wan_name));
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] mapi_set_vlan_ch_entry called, baseif [%s] ",
		__FUNCTION__, __LINE__, vlan_ch.baseIf);
#endif

	snprintf(vlan_ch.iid.cpeId.secName, strlen(TAG_VLAN_CHANNEL) + 1, "%s",
		 TAG_VLAN_CHANNEL);
	vlan_ch.iid.config_owner = IFX_WEB;
	strncpy(vlan_ch.iid.pcpeId.secName, pscpe_sec, MAX_TAG_LEN-1);
	vlan_ch.iid.pcpeId.secName[MAX_TAG_LEN-1] = '\0';
	vlan_ch.fEnable = IFX_ENABLED;

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] mapi_set_vlan_ch_entry called, baseif [%s] ",
		__FUNCTION__, __LINE__, vlan_ch.baseIf);
#endif
	gstrcpy(vlan_ch.chName, vlan_channel_name);

	if (Vlan_id != NULL && gstrcmp(Vlan_id, "")) {
		vlan_ch.vlanId = atoi(Vlan_id);
	}
	vlan_ch.macAddrOvrd = Override_mac_add[0];
	gstrcpy(vlan_ch.macAddr, Mac_addr);

	/* While adding Ethernet Channels, we create dummy channels for corresponding
	 * ATM devices with VPI=256 and VCI=0 (only for ATM WAN Connections)
	 * Work-around for now to modify the DS in DevM Stack */
	if (!gstrcmp(pSubmit_Action, T("addVLAN"))) {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;

		/* Update the Ethernet Channel Information */
		/* call the MAPI to update the eth channel section in sysconfig */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] mapi_set_vlan_ch_entry called, baseif [%s] ",
			__FUNCTION__, __LINE__, vlan_ch.baseIf);
#endif
		ret = mapi_set_vlan_ch_entry(operation, &vlan_ch, flags);
		if ((ret != IFX_SUCCESS) && (ret == IFX_DUPLICATE_ENTRY)) {
			/* In case Channel already configured - report to user */
			COPY_TO_STATUS("%s",
                               "<span class=\"textTitle\">VLan allready configured in this Wan mode!!</span>");	
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		} else if (ret != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to set wan eth channel config !!"));
			return;
		}

	} else if (!gstrcmp(pSubmit_Action, T("delVLAN"))) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		vlan_ch_cfg_t *vlan_ch1 = NULL;
		memset(&vlan_ch1, 0x00, sizeof(vlan_ch1));


		if (mapi_get_all_vlan_ch_entries(&num, &vlan_ch1, flags) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to get vlan Channel information!"));
			IFX_MEM_FREE(vlan_ch1);
			return;
		}
		for (i = 0; i < num; i++) {
			if (((vlan_ch1 + i)->vlanId) != 4096) {
				/* Option set to Delete a particular Ethernet Channel */
				snprintf(remove, sizeof(remove), "remove%d",
					 (vlan_ch1 + i)->iid.cpeId.Id);
				remove_num = NULL;
				remove_num =
				    ifx_httpdGetVar(wp, T(remove), T(""));
				if (!gstrcmp(remove_num, "1")) {
					/* Check if the selected Ethernet Channel has any WAN Connections
					 * configured on it. If so, fail this operation */
					sprintf(sBuf, "%u",
                                                (vlan_ch1 + i)->iid.cpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					      "cpeId", sBuf,
					      &retVal)) == IFX_SUCCESS) {
						sprintf(sBuf, "%s_l2ifName",
							retVal);
						if (ifx_GetObjData
						    (FILE_RC_CONF,
						     TAG_VLAN_CHANNEL, sBuf,
						     IFX_F_GET_ENA,
						     (IFX_OUT uint32 *) &
						     outFlag,
						     sValue) != IFX_SUCCESS) {
							ifx_httpdError(wp, 405,
								       T
								       ("Failed to find the cpeid for eth channel!!"));
							IFX_MEM_FREE(retVal)
							    return;
						}
						if ((ret =
						     ifx_ret_substr_from_distfield
						     (FILE_RC_CONF, TAG_WAN_IP,
						      "l2ifName", sValue,
						      &retVal)) ==
						    IFX_SUCCESS) {
							ifx_httpdError(wp, 400,
								       "Vlan Channel is currently being used - Cannot Delete !!");
							IFX_MEM_FREE(vlan_ch1);
							IFX_MEM_FREE(retVal);
							return;
						}
						if ((ret =
						     ifx_ret_substr_from_distfield
						     (FILE_RC_CONF, TAG_WAN_PPP,
						      "l2ifName", sValue,
						      &retVal)) ==
						    IFX_SUCCESS) {
							ifx_httpdError(wp, 400,
								       "Vlan Channel is currently being used - Cannot Delete !!");
							IFX_MEM_FREE(vlan_ch1);
							IFX_MEM_FREE(retVal);
							return;
						}

					}

					snprintf((vlan_ch1 +
						  i)->iid.cpeId.secName,
						 strlen(TAG_VLAN_CHANNEL) + 1,
						 "%s", TAG_VLAN_CHANNEL);

					if (strstr
					    ((vlan_ch1 + i)->baseIf,
					     "nas") != NULL) {
						snprintf(vlan_ch.iid.pcpeId.
							 secName,
							 strlen
							 (TAG_ADSL_VCCHANNEL) +
							 1, "%s",
							 TAG_ADSL_VCCHANNEL);
					} else
					    if (strstr
						((vlan_ch1 + i)->baseIf,
						 "eth") != NULL) {
						snprintf(vlan_ch.iid.pcpeId.
							 secName,
							 strlen(TAG_ETH_CHANNEL)
							 + 1, "%s",
							 TAG_ETH_CHANNEL);
					} else
					    if (strstr
						((vlan_ch1 + i)->baseIf,
						 "ptm") != NULL) {
						snprintf(vlan_ch.iid.pcpeId.
							 secName,
							 strlen(TAG_PTM_CHANNEL)
							 + 1, "%s",
							 TAG_PTM_CHANNEL);
					}
					(vlan_ch1 + i)->iid.config_owner = IFX_WEB;
					/* Delete the Ethernet Channel & WAN Connection Device entires */
					if (mapi_set_vlan_ch_entry(operation, (vlan_ch1 + i),flags) != IFX_SUCCESS) {
						ifx_httpdError(wp, 500,T("Error deleting vc channel entry  !!"));
						return;
					}

				}
			}

		}

		IFX_MEM_FREE(vlan_ch1);
	}

IFX_Handler:
	/* QS Modifications */
	if (status == 1)
		ifx_httpdRedirect(wp, T("vlan_display.asp"));
	else
		websNextPage(wp);
	/* QS Modifications END */

}

int ltq_get_vlan_values_state(int eid, httpd_t wp, int argc, char_t ** argv)
{
	RESERVED_VLAN_CFG vlan_cfg;
	char_t *name;
	
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
                ifx_httpdError(wp, 400, T("Insufficient args\n"));
                return -1;
        }
	
	if(ltq_mapi_get_reserved_vlan_config(&vlan_cfg) != IFX_SUCCESS){
		ifx_httpdError(wp, 500, T("Unable to retrive the values\n"));
		return -1;
	}
	if (!gstrcmp(name, T("adsl_atm_vlan")))
		ifx_httpdWrite(wp, T("%s"), vlan_cfg.ATM_VlanId);
	else if(!gstrcmp(name, T("ptm_vlan")))
		ifx_httpdWrite(wp, T("%s"), vlan_cfg.PTM_VlanId);
        else if(!gstrcmp(name, T("mii0_vlan")))
		ifx_httpdWrite(wp, T("%s"), vlan_cfg.Mii0_VlanId);
        else if(!gstrcmp(name, T("mii1_vlan")))
		ifx_httpdWrite(wp, T("%s"),vlan_cfg.Mii1_VlanId);
        else if(!gstrcmp(name, T("portsep_vlan")))
		ifx_httpdWrite(wp, T("%s"),vlan_cfg.Portsep_VlanId);
	return IFX_SUCCESS;
}

/*manohar : This will display all the vpi/vci used*/
int ifx_get_wan_atm_channel_used(int eid, httpd_t wp, int argc,char_t ** arg_v)
{
				int num = 0, i = 0;
				ATM_VCC_INFO *vcc = NULL;
				memset(&vcc, 0x00, sizeof(vcc));
				if (ifx_get_all_vcc_info(&num, &vcc, IFX_F_DEFAULT) != IFX_SUCCESS) {
								IFX_MEM_FREE(vcc);
								return -1;
				}
				if (num != 0) 
				{
								for (i = 0; i < num; i++) 
								{
												if (((vcc + i)->vc.pvc.vpi) != 256) 
												{
																if ( i < (num - 1))
																				ifx_httpdWrite(wp,T("\"%d/%d\",\"%d\","),(vcc + i)->vc.pvc.vpi,(vcc + i)->vc.pvc.vci,(vcc + i)->type);
																else
																				ifx_httpdWrite(wp,T("\"%d/%d\",\"%d\""),(vcc + i)->vc.pvc.vpi,(vcc + i)->vc.pvc.vci,(vcc + i)->type);
												}
								}
				}
				IFX_MEM_FREE(vcc);
				return IFX_SUCCESS;
}
/*manohar end*/

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
int ltq_cgi_get_autodetect_config(int eid, httpd_t wp, int argc, char_t **argv)
{
				char_t *name, sValue[MAX_FILENAME_LEN];
				WAN_MODE wanMode = WAN_MODE_ATM;
				WAN_PHY_CFG pstWanPhy;
				auto_detect_cfg_t config;
				ifx_get_wan_phy_cfg(&pstWanPhy);

				wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);

				if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
								ifx_httpdError(wp, 400, T("Insufficient args\n"));
								return -1;
				}

				memset(sValue, 0x00, sizeof(sValue));
				memset(&config, 0x00, sizeof(config));
				ltq_mapi_get_autodetect_config(&config);
				if (!gstrcmp(name, "all")) 
				{
								if (config.auto_detect)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\","));

								if (config.auto_detect_L2)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\","));
 
								if (config.auto_detect_vdsl_atm_L2)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\",")); 

								if (config.auto_detect_Vlan_ATM)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\",")); 

								if (config.auto_detect_Vlan_ADSL_PTM)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\",")); 

								if (config.auto_detect_Vlan_VDSL_PTM)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\","));

								if (config.auto_detect_Vlan_ETH1)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\",")); 

								if (config.auto_detect_Vlan_ETH0)
												ifx_httpdWrite(wp, T("\"checked\","));	
								else
												ifx_httpdWrite(wp, T("\"0\","));

								if (config.auto_detect_L3)
												ifx_httpdWrite(wp, T("\"checked\""));
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
 
								if (config.auto_detect_vdsl_atm_L3)
												ifx_httpdWrite(wp, T("\"checked\""));
								else
												ifx_httpdWrite(wp, T("\"0\""));  

								if (config.auto_detect_adsl_ptm_L3)
												ifx_httpdWrite(wp, T("\"checked\""));
								else
												ifx_httpdWrite(wp, T("\"0\""));  

								if (config.auto_detect_vdsl_ptm_L3)
												ifx_httpdWrite(wp, T("\"checked\""));
								else
												ifx_httpdWrite(wp, T("\"0\""));  

								if (config.auto_detect_mii1_L3)
												ifx_httpdWrite(wp, T("\"checked\""));
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
 
								if (config.auto_detect_mii0_L3)
												ifx_httpdWrite(wp, T("\"checked\""));
								else
												ifx_httpdWrite(wp, T("\"0\""));  
				}else if(!gstrcmp(name, "dsl")){
								if (config.auto_detect)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "l2")){
								if (config.auto_detect_L2 && wanMode != WAN_MODE_VDSL_ATM)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "l2_vlan")){
								if ((config.auto_detect_Vlan_ADSL_PTM && wanMode == WAN_MODE_PTM) || (config.auto_detect_Vlan_VDSL_PTM && wanMode == WAN_MODE_VDSL_PTM) || (config.auto_detect_Vlan_ETH1 && wanMode == WAN_MODE_ETH1) || (config.auto_detect_Vlan_ETH0 && wanMode == WAN_MODE_ETH0))
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "atm_vlan")){
								if (config.auto_detect_Vlan_ATM)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "adsl_ptm_vlan")){
								if (config.auto_detect_Vlan_ADSL_PTM)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "vdsl_ptm_vlan")){
								if (config.auto_detect_Vlan_VDSL_PTM)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "mii1_vlan")){
								if (config.auto_detect_Vlan_ETH1)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "mii0_vlan")){
								if (config.auto_detect_Vlan_ETH0)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "l3")){
								if (config.auto_detect_L3 && wanMode != WAN_MODE_VDSL_ATM)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "ads_l3")){
								if ((config.auto_detect_L3 && wanMode == WAN_MODE_ATM) || (config.auto_detect_adsl_ptm_L3 && wanMode == WAN_MODE_PTM) || (config.auto_detect_vdsl_ptm_L3 && wanMode == WAN_MODE_VDSL_PTM) || (config.auto_detect_mii1_L3 && wanMode == WAN_MODE_ETH1) || (config.auto_detect_mii0_L3 && wanMode == WAN_MODE_ETH0))
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "adsl_ptm_l3")){
								if (config.auto_detect_adsl_ptm_L3)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "vdsl_ptm_l3")){
								if (config.auto_detect_vdsl_ptm_L3)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "mii1_l3")){
								if (config.auto_detect_mii1_L3)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "mii0_l3")){
								if (config.auto_detect_mii0_L3)
												ifx_httpdWrite(wp, T("\"checked\""));	
								else
												ifx_httpdWrite(wp, T("\"0\"")); 
				}else if(!gstrcmp(name, "vcc_pool")){
								ifx_httpdWrite(wp, T("%s"), config.auto_detect_Vcc);
				}else if(!gstrcmp(name, "atm_vlan_pool")){
								ifx_httpdWrite(wp, T("%s"), config.auto_detect_ATM_VlanId);
				}else if(!gstrcmp(name, "adsl_ptm_vlan_pool")){
								ifx_httpdWrite(wp, T("%s"), config.auto_detect_ADSL_PTM_VlanId);
				}else if(!gstrcmp(name, "vdsl_ptm_vlan_pool")){
								ifx_httpdWrite(wp, T("%s"), config.auto_detect_VDSL_PTM_VlanId);
				}else if(!gstrcmp(name, "mii1_vlan_pool")){
								ifx_httpdWrite(wp, T("%s"), config.auto_detect_ETH1_VlanId);
				}else if(!gstrcmp(name, "mii0_vlan_pool")){
								ifx_httpdWrite(wp, T("%s"), config.auto_detect_ETH0_VlanId);
				}else {
								ifx_httpdError(wp, 500, T("Failed to GET DW Configurations"));
				}

				return IFX_SUCCESS; 
}

/* 	Update autodetect status.
 *	ads : Auto Detect Status
 */

int ltq_cgi_set_autodetect_config(httpd_t wp, char *layer)
{
	auto_detect_cfg_t config;
	char_t *status = NULL;
	WAN_MODE wanMode = WAN_MODE_ATM;
	WAN_PHY_CFG pstWanPhy;
	memset(&config, 0x00, sizeof(config));
	ltq_mapi_get_autodetect_config(&config);
	ifx_get_wan_phy_cfg(&pstWanPhy);
	wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);

	if (!gstrcmp(layer, "all")) 
	{
		if((status = ifx_httpdGetVar(wp, T("ads_dsl"), T(""))) != NULL)
			config.auto_detect 	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_l2"), T(""))) != NULL)
			config.auto_detect_L2	=	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_l3"), T(""))) != NULL)
  			config.auto_detect_L3	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_adsl_ptm_l3"), T(""))) != NULL)
  			config.auto_detect_adsl_ptm_L3	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_vdsl_ptm_l3"), T(""))) != NULL)
  			config.auto_detect_vdsl_ptm_L3	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_mii1_l3"), T(""))) != NULL)
  			config.auto_detect_mii1_L3	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_mii0_l3"), T(""))) != NULL)
  			config.auto_detect_mii0_L3	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_vlan_adsl_ptm"), T(""))) != NULL)
			config.auto_detect_Vlan_ADSL_PTM	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_vlan_vdsl_ptm"), T(""))) != NULL)
			config.auto_detect_Vlan_VDSL_PTM	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_vlan_mii1"), T(""))) != NULL)
			config.auto_detect_Vlan_ETH1	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_vlan_mii0"), T(""))) != NULL)
			config.auto_detect_Vlan_ETH0	= 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("ads_vlan_atm"), T(""))) != NULL)
 			config.auto_detect_Vlan_ATM = 	atoi(status);

		if((status = ifx_httpdGetVar(wp, T("vcc_pool"), T(""))) != NULL){
			strcpy(config.auto_detect_Vcc, status);
		}
#if 0 //atm vlan not supported for actiontec
		if((status = ifx_httpdGetVar(wp, T("atm_vlan_pool"), T(""))) != NULL){
			strcpy(config.auto_detect_ATM_VlanId, status);
		}
#endif

		if((status = ifx_httpdGetVar(wp, T("ptm_vlan_pool"), T(""))) != NULL){
			 strcpy(config.auto_detect_ADSL_PTM_VlanId, status);
		}
	}
	else if(!gstrcmp(layer, "dsl")){
    	if((status = ifx_httpdGetVar(wp, T("ads_dsl"), T(""))) != NULL)
			config.auto_detect 	= 	atoi(status);
	}
 	else if(!gstrcmp(layer, "l2")){
		if((status = ifx_httpdGetVar(wp, T("ads_l2"), T(""))) != NULL)
			config.auto_detect_L2	=	atoi(status);
			IFX_DBG("[%s:%d] auto_detect_L2 = [%d]\n",__FUNCTION__,__LINE__,atoi(status));
	}
 	else if(!gstrcmp(layer, "vlan")){
#if 0 //ATM VLAN Not Supported
		if((status = ifx_httpdGetVar(wp, T("ads_vlan_atm"), T(""))) != NULL)
 			config.auto_detect_Vlan_ATM = 	atoi(status);    
#endif
    	if((status = ifx_httpdGetVar(wp, T("ads_vlan"), T(""))) != NULL)
			{
				if(wanMode == WAN_MODE_PTM)
					config.auto_detect_Vlan_ADSL_PTM	= 	atoi(status);
				else if(wanMode == WAN_MODE_VDSL_PTM)
					config.auto_detect_Vlan_VDSL_PTM	= 	atoi(status);
				else if(wanMode == WAN_MODE_ETH1)
					config.auto_detect_Vlan_ETH1	= 	atoi(status);
				else if(wanMode == WAN_MODE_ETH0)
					config.auto_detect_Vlan_ETH0	= 	atoi(status);
			}
	}else if(!gstrcmp(layer, "l3")){
    	if((status = ifx_httpdGetVar(wp, T("ads_l3"), T(""))) != NULL)
			{
				if(wanMode == WAN_MODE_ATM)
  				config.auto_detect_L3	= 	atoi(status);
				else if(wanMode == WAN_MODE_PTM)
  				config.auto_detect_adsl_ptm_L3	= 	atoi(status);
				else if(wanMode == WAN_MODE_VDSL_PTM)
  				config.auto_detect_vdsl_ptm_L3	= 	atoi(status);
				else if(wanMode == WAN_MODE_ETH1)
  				config.auto_detect_mii1_L3	= 	atoi(status);
				else if(wanMode == WAN_MODE_ETH0)
  				config.auto_detect_mii0_L3	= 	atoi(status);
			}
	}else if(!gstrcmp(layer,"ad_vlan_l2")){
    		if((status = ifx_httpdGetVar(wp, T("ads_vlan_adsl_ptm"), T(""))) != NULL)
					config.auto_detect_Vlan_ADSL_PTM	= 	atoi(status);
    		if((status = ifx_httpdGetVar(wp, T("ads_vlan_vdsl_ptm"), T(""))) != NULL)
					config.auto_detect_Vlan_VDSL_PTM	= 	atoi(status);
    		if((status = ifx_httpdGetVar(wp, T("ads_vlan_mii1"), T(""))) != NULL)
					config.auto_detect_Vlan_ETH1	= 	atoi(status);
    		if((status = ifx_httpdGetVar(wp, T("ads_vlan_mii0"), T(""))) != NULL)
					config.auto_detect_Vlan_ETH0	= 	atoi(status);
	}else if(!gstrcmp(layer, "ad_l3")){
 		if((status = ifx_httpdGetVar(wp, T("ads_l3"), T(""))) != NULL)
  			config.auto_detect_L3	= 	atoi(status);
 		if((status = ifx_httpdGetVar(wp, T("ads_adsl_ptm_l3"), T(""))) != NULL)
  			config.auto_detect_adsl_ptm_L3	= 	atoi(status);
 		if((status = ifx_httpdGetVar(wp, T("ads_vdsl_ptm_l3"), T(""))) != NULL)
  			config.auto_detect_vdsl_ptm_L3	= 	atoi(status);
 		if((status = ifx_httpdGetVar(wp, T("ads_mii1_l3"), T(""))) != NULL)
  			config.auto_detect_mii1_L3	= 	atoi(status);
 		if((status = ifx_httpdGetVar(wp, T("ads_mii0_l3"), T(""))) != NULL)
  			config.auto_detect_mii0_L3	= 	atoi(status);
	}	
	else if(!gstrcmp(layer, "vcc_pool")){ 
		if((status = ifx_httpdGetVar(wp, T("vcc_pool"), T(""))) != NULL)
			strcpy(config.auto_detect_Vcc, status);
	}	
#if 0 //atm vlan not supported for actiontec
	else if(!gstrcmp(layer, "atm_vlan_pool")){
			if((status = ifx_httpdGetVar(wp, T("atm_vlan_pool"), T(""))) != NULL)
				strcpy(config.auto_detect_ATM_VlanId, status);
	} 
#endif
	else if(!gstrcmp(layer, "adsl_ptm_vlan_pool")){ 
			if((status = ifx_httpdGetVar(wp, T("adsl_ptm_vlan_pool"), T(""))) != NULL)
			 strcpy(config.auto_detect_ADSL_PTM_VlanId, status);
	}	
	else if(!gstrcmp(layer, "vdsl_ptm_vlan_pool")){ 
			if((status = ifx_httpdGetVar(wp, T("vdsl_ptm_vlan_pool"), T(""))) != NULL)
			 strcpy(config.auto_detect_ADSL_PTM_VlanId, status);
	}	
	else if(!gstrcmp(layer, "mii1_vlan_pool")){ 
			if((status = ifx_httpdGetVar(wp, T("mii1_vlan_pool"), T(""))) != NULL)
			 strcpy(config.auto_detect_ADSL_PTM_VlanId, status);
	}	
	else if(!gstrcmp(layer, "mii0_vlan_pool")){ 
			if((status = ifx_httpdGetVar(wp, T("mii0_vlan_pool"), T(""))) != NULL)
			 strcpy(config.auto_detect_ADSL_PTM_VlanId, status);
	}	
	else {
		IFX_DBG("[%s][%d] Provide Valid Auto Detect Layer\n",__func__, __LINE__);
		return IFX_FAILURE;
	}
 
	if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
 		ifx_httpdError(wp, 400, "Failed to update [%s] Auto Detect Status", layer);
 		return IFX_FAILURE;
  } 

	return IFX_SUCCESS;
}

/* This function will be called independently whenever a new VPI/VCI or VLAN is added  
 * Calling Method: In web page call, 
 *						1. ltq_cgi_update_autodetect_pool("vcc_add");
 *						2. ltq_cgi_update_autodetect_pool("atm_vlan_add");
 *						3. ltq_cgi_update_autodetect_pool("ptm_vlan_add");
 * 						4. ltq_cgi_update_autodetect_pool("vcc_add");
 *						5. ltq_cgi_update_autodetect_pool("atm_vlan_add");
 *						6. ltq_cgi_update_autodetect_pool("ptm_vlan_add"); 
 */
int ltq_cgi_update_autodetect_pool(httpd_t wp, char_t * path, char_t * query)
{
 	char *value; 
 	char_t 	*pSubmit_Action = ifx_httpdGetVar(wp, T("submit_action"), T("")), 
					*operation = ifx_httpdGetVar(wp, T("operation"), T(""));
		
	if(!gstrcmp(pSubmit_Action, T("vcc"))){
		value = ifx_httpdGetVar(wp, T("vcc"), T(""));
		if(!gstrcmp(operation, T("add"))){
        ltq_mapi_update_autodetect_pool(VCC_POOL_FIELD, value, IFX_F_INT_ADD);
		}else if(!gstrcmp(operation, T("del"))){
				ltq_mapi_update_autodetect_pool(VCC_POOL_FIELD, value, IFX_F_DELETE);
		}
	}else if(!gstrcmp(pSubmit_Action, T("adsl_ptm_vlan"))){
		value = ifx_httpdGetVar(wp, T("adsl_ptm_vlan"), T(""));
		if(!gstrcmp(operation, T("add"))){
        ltq_mapi_update_autodetect_pool(ADSL_PTM_VLAN_POOL_FIELD, value, IFX_F_INT_ADD);
		}else if(!gstrcmp(operation, T("del"))){
        ltq_mapi_update_autodetect_pool(ADSL_PTM_VLAN_POOL_FIELD, value, IFX_F_DELETE);
		}
	}else if(!gstrcmp(pSubmit_Action, T("vdsl_ptm_vlan"))){
		value = ifx_httpdGetVar(wp, T("vdsl_ptm_vlan"), T(""));
		if(!gstrcmp(operation, T("add"))){
        ltq_mapi_update_autodetect_pool(VDSL_PTM_VLAN_POOL_FIELD, value, IFX_F_INT_ADD);
		}else if(!gstrcmp(operation, T("del"))){
        ltq_mapi_update_autodetect_pool(VDSL_PTM_VLAN_POOL_FIELD, value, IFX_F_DELETE);
		}
	}else if(!gstrcmp(pSubmit_Action, T("mii1_vlan"))){
		value = ifx_httpdGetVar(wp, T("mii1_vlan"), T(""));
		if(!gstrcmp(operation, T("add"))){
        ltq_mapi_update_autodetect_pool(ETH1_VLAN_POOL_FIELD, value, IFX_F_INT_ADD);
		}else if(!gstrcmp(operation, T("del"))){
        ltq_mapi_update_autodetect_pool(ETH1_VLAN_POOL_FIELD, value, IFX_F_DELETE);
		}
	}else if(!gstrcmp(pSubmit_Action, T("mii0_vlan"))){
		value = ifx_httpdGetVar(wp, T("mii0_vlan"), T(""));
		if(!gstrcmp(operation, T("add"))){
        ltq_mapi_update_autodetect_pool(ETH0_VLAN_POOL_FIELD, value, IFX_F_INT_ADD);
		}else if(!gstrcmp(operation, T("del"))){
        ltq_mapi_update_autodetect_pool(ETH0_VLAN_POOL_FIELD, value, IFX_F_DELETE);
		}
	}else	if (!gstrcmp(pSubmit_Action, T("atm_vlan"))) {
		value = ifx_httpdGetVar(wp, T("atm_vlan"), T(""));
		if(!gstrcmp(operation, T("add"))){
        ltq_mapi_update_autodetect_pool(ATM_VLAN_POOL_FIELD, value, IFX_F_INT_ADD);
		}else if(!gstrcmp(operation, T("del"))){
        ltq_mapi_update_autodetect_pool(ATM_VLAN_POOL_FIELD, value, IFX_F_DELETE);
		}
	}else	if (!gstrcmp(pSubmit_Action, T("check"))) {
		if(!gstrcmp(operation, T("ad_vlan_l2")))
					ltq_cgi_set_autodetect_config(wp, "ad_vlan_l2");
		else if(!gstrcmp(operation, T("l2")))
					ltq_cgi_set_autodetect_config(wp, "l2");
		else if(!gstrcmp(operation, T("dsl")))
					ltq_cgi_set_autodetect_config(wp, "dsl");
		else if(!gstrcmp(operation, T("ad_l3")))
					ltq_cgi_set_autodetect_config(wp, "ad_l3");
#if 0
		else if(!gstrcmp(operation, T("adsl_ptm_l3")))
					ltq_cgi_set_autodetect_config(wp, "adsl_ptm_l3");
		else if(!gstrcmp(operation, T("vdsl_ptm_l3")))
					ltq_cgi_set_autodetect_config(wp, "vdsl_ptm_l3");
		else if(!gstrcmp(operation, T("mii1_l3")))
					ltq_cgi_set_autodetect_config(wp, "mii1_l3");
		else if(!gstrcmp(operation, T("mii0_l3")))
					ltq_cgi_set_autodetect_config(wp, "mii0_l3");
#endif
	}
	ifx_httpdRedirect(wp, T("autodetect.asp"));
	return IFX_SUCCESS;
}
#endif

int ltq_get_wan_dns(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
        char_t sWAN_IDX[MAX_NAME_SIZE];
        int nWAN_IDX = -1;
        uint32 outFlag = IFX_F_DEFAULT;
        WAN_TYPE sWAN_TYPE;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
                ifx_httpdError(wp, 400, T("Insufficient args\n"));
                return -1;
        }
        /* TBD: need to know how to find connection type based on which IFX_GET_WANIP_SELECTED_INDEX or IFX_GET_WANPPP_SELECTED_INDEX AND ifx_get_wanip_conn_type can be called */
        IFX_GET_WAN_SELECTED_INDEX(IFX_F_DEFAULT, outFlag, sWAN_IDX, nWAN_IDX,
                                   sWAN_TYPE)
	/* Based on the current wan mode and the arguments passed with the selected wan, call is made*/
	if (sWAN_TYPE == WAN_TYPE_IP) {
		ifx_get_wanip(eid, wp, argc, argv);
	} else {
		ifx_get_wan_ppp(eid, wp, argc, argv);
	}
	return 0;
}

