#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#ifdef CONFIG_FEATURE_FIREWALL
#include "ifx_api_fw.h"
#endif

extern char *status_str;
extern char natcpeId[MAX_FILELINE_LEN];
extern char natvsAction[MAX_FILELINE_LEN];

extern int ifx_get_all_lan_conn_names(char **lan_conn_names, int *count);
extern int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count);
#if defined (CONFIG_FEATURE_NAPT) && (CONFIG_FEATURE_FIREWALL)
static int portExists(int port, int type);
#endif
extern int netmask2bits(u_int32_t netmask);
#if 1
extern bool IFX_SET_FIREWALL_DENY_SERVICES(int operation, int IFtype,
					   __u16 port, __u16 protocol);
extern bool IFX_SET_FIREWALL_ACCEPT_SERVICES(int operation, __u16 port,
					     __u16 protocol, bool acl);
extern bool IFX_SET_NAPT_REDIRECT_SERVICES(int operation, __u16 service_port,
					   __u16 protocol, __u32 IPADDR,
					   __u16 target_port);
#endif
#if 0
extern int IFX_SET_FIREWALL_DENY_SERVICES(int operation, int IFtype, __u16 port,
					  __u16 protocol);
extern int IFX_SET_FIREWALL_ACCEPT_SERVICES(int operation, __u16 port,
					    __u16 protocol, int acl);
extern int IFX_SET_NAPT_REDIRECT_SERVICES(int operation, __u16 service_port,
					  __u16 protocol, __u32 IPADDR,
					  __u16 target_port);
#endif
extern int websGetCfgData2Table(httpd_t wp, const char_t * pFileName,
				char_t * pTag, const char_t * pSymbol,
				CGI_TABLE_S * pTable, int nTableType);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ifx_set_mac_filter_rules(int nCount, struct mac_filter *MF);
extern void websNextPage(httpd_t wp);
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
extern int32 lan_port_sep_enable_get();
#endif
#ifdef CONFIG_FEATURE_VLAN
int websUpdate_Vlan(int nCount, char *prefix, char *tag);
void ifx_set_vlan_bridge(httpd_t wp, char_t * path, char_t * query);
#endif				//CONFIG_FEATURE_VLAN
#ifdef CONFIG_FEATURE_FIREWALL
void ifx_set_firewall_mac(httpd_t wp, char_t * path, char_t * query);	// firewall_mac.asp
void ifx_set_firewall_main(httpd_t wp, char_t * path, char_t * query);	//firewall_main.asp
void ifx_set_firewall_disablewan(httpd_t wp, char_t * path, char_t * query);	//firewall_disablewan.asp
void ifx_set_firewall_packetfilter(httpd_t wp, char_t * path, char_t * query);	//ifx_set_firewall_packetfilter.asp
void ifx_set_firewall_packetfilter_add(httpd_t wp, char_t * path,
				       char_t * query);
void ifx_set_firewall_packetfilter_mod(httpd_t wp, char_t * path,
				       char_t * query);
int ifx_get_FirewallStatus(int eid, httpd_t wp, int argc, char_t ** argv);
#ifdef POLICY_ROUTING
void ifx_set_policy_routing(httpd_t wp, char_t * path, char_t * query);
void ifx_set_policy_routing_add(httpd_t wp, char_t * path, char_t * query);
#endif
#endif				//CONFIG_FEATURE_FIREWALL
#ifdef CONFIG_FEATURE_NAPT
void ifx_set_apps_settings(httpd_t wp, char_t * path, char_t * query);
#endif				// CONFIG_FEATURE_NAPT
#ifdef CONFIG_FEATURE_FIREWALL
int ifx_get_MacControl(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_MacFilter(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_MacFilter_modified(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_firewall_disablewan(int eid, httpd_t wp, int argc, char_t ** argv);	//firewall_disablewan.asp
int ifx_get_firewall_packetfilter(int eid, httpd_t wp, int argc, char_t ** argv);	//firewall_packetfilter.asp
int ifx_get_firewall_packetfilter_rule(int eid, httpd_t wp, int argc, char_t ** argv);	//firewall_packetfilter_mod.asp
#endif				//CONFIG_FEATURE_FIREWALL
#ifdef CONFIG_FEATURE_NAPT
#ifdef CONFIG_FEATURE_ALGS
int ifx_get_algs_setting(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				//CONFIG_FEATURE_ALGS
int ifx_get_apps_setting(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				// CONFIG_FEATURE_NAPT
void ifx_set_servers_acl(httpd_t wp, char_t * path, char_t * query);	//servers_acl.asp

int websSetData2Table(httpd_t wp, const char_t * pFileName, char_t * pTag,
		      const char_t * pSymbol, CGI_TABLE_S * pTable)
{
	char_t sValue[MAX_DATA_LEN], sCommand[MAX_FILELINE_LEN];
	int nCount = 0, nIndex = 0;

	memset(pTable, 0, sizeof(*pTable));
	gsprintf(sCommand, T("%sCount"), pSymbol);
	if (ifx_GetCfgData((char_t *) pFileName, pTag, sCommand, sValue) == 0) {
		ifx_httpdError(wp, 204, T("%sCount not found"), sCommand);
		return -1;
	}

	nCount = gatoi(sValue);
	for (nIndex = 0; nIndex < nCount; nIndex++) {
		// Get value form file
		gsprintf(sCommand, T("grep \"^%s%d\" %s | cut -f2 -d'\"'"),
			 pSymbol, nIndex, pFileName);
		if (ifx_GetCfgData((char_t *) sCommand, NULL, "1", sValue) == 0) {
			ifx_httpdError(wp, 204, T("%s not found"), sCommand);
			return -1;
		}

		if (nIndex)
			pTable[nIndex].nIndex = nIndex;
		LTQ_STRNCPY(pTable[nIndex].Data.sValue, sValue,
			sizeof(pTable[nIndex].Data.sValue));

		// Get status form file
		gsprintf(sCommand, T("grep \"^%sSTAT%d\" %s | cut -f2 -d'\"'"),
			 pSymbol, nIndex, pFileName);
		if (ifx_GetCfgData((char_t *) sCommand, NULL, "1", sValue) == 1) {
			pTable[nIndex].nState = atoi(sValue);
		}
	}

	return nCount;
}

int ifx_set_mac_filter_rules(int nCount, struct mac_filter *MF)
{
	char_t sBuf[MAX_DATA_LEN];
	int nIndex = 0;
	gsprintf(sBuf, T("%sCount=\"%d\"\n"), PREFIX_FIREWALL_PC, nCount);

	for (nIndex = 0; nIndex < nCount; nIndex++) {
		char_t sLine[MAX_FILELINE_LEN];
		// Print following strings
		gsprintf(sLine, T("%sSTATUS%d=\"%d\"\n%sMACADDR%d=\"%s\"\n"),
			 PREFIX_FIREWALL_PC, nIndex, MF[nIndex].state,
			 PREFIX_FIREWALL_PC, nIndex, MF[nIndex].mac_addr);
		LTQ_STRNCAT(sBuf, sLine, sizeof(sBuf));
		gsprintf(sLine, T("%sDAYSELECTION%d=\"%s\"\n"),
			 PREFIX_FIREWALL_PC, nIndex, MF[nIndex].day_selection);
		gstrcat(sBuf, sLine);
		gsprintf(sLine, T("%sTIMESTART%d=\"%s\"\n"), PREFIX_FIREWALL_PC,
			 nIndex, MF[nIndex].time_start);
		gstrcat(sBuf, sLine);
		gsprintf(sLine, T("%sTIMEEND%d=\"%s\"\n"), PREFIX_FIREWALL_PC,
			 nIndex, MF[nIndex].time_end);
		gstrcat(sBuf, sLine);
	}

	IFX_MEM_FREE(MF)
	    return (ifx_SetCfgData(FILE_RC_CONF, TAG_FIREWALLMAC, 1, sBuf));
}

int ifx_get_ssh_server_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_SSH_SERVER
	ifx_httpdWrite(wp, T("%s"), "DEFINE");
#else
	ifx_httpdWrite(wp, T("%s"), "UNDEFINE");
#endif
	return 0;
}

#ifdef CONFIG_FEATURE_FIREWALL
void ifx_set_firewall_main(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck/*, sCheck[MAX_FILELINE_LEN]*/;

	IFX_MAPI_Firewall fw;

	a_assert(wp);
//	sCheck[0] = '\0';

	memset(&fw, 0x00, sizeof(fw));

	// Get value from ASP filz
	pCheck = ifx_httpdGetVar(wp, T("FirewallStatus"), T(""));

	fw.iid.config_owner = IFX_WEB;

	fw.enable = atoi(pCheck);
	ifx_mapi_set_firewall_status(&fw, IFX_F_MODIFY);

	websNextPage(wp);
}
#endif				//CONFIG_FEATURE_FIREWALL

#ifdef CONFIG_FEATURE_FIREWALL
//////////////////////////////////////////////////////////////////////////////////
// firewall_disablewan.asp
//
void ifx_set_firewall_disablewan(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pDoSProtect, *pC1, *pPingGW;
	/*, *pPortScan, *pScanSecu, *pNetBios,
		    *pDefrag, *pSendIcmpErr;*/
	char_t sDoSProtect[MAX_FILELINE_LEN], sC1[MAX_FILELINE_LEN],
	    sPingGW[MAX_FILELINE_LEN];
//	char_t sPortScan[MAX_FILELINE_LEN], sScanSecu[MAX_FILELINE_LEN];
//	    sNetBios[MAX_FILELINE_LEN]
//	char_t sDefrag[MAX_FILELINE_LEN], sSendIcmpErr[MAX_FILELINE_LEN];
	char_t sCommand[MAX_DATA_LEN];

	a_assert(wp);
	sDoSProtect[0] = '\0';
	sC1[0] = '\0';
	sPingGW[0] = '\0';
//	sPortScan[0] = '\0';
//	sScanSecu[0] = '\0';
//	sNetBios[0] = '\0';
//	sDefrag[0] = '\0';
//	sSendIcmpErr[0] = '\0';

	// Get value from ASP file
	pDoSProtect = ifx_httpdGetVar(wp, T("DoSProtect"), T(""));
	pC1 = ifx_httpdGetVar(wp, T("C1"), T(""));
	pPingGW = ifx_httpdGetVar(wp, T("PingGW"), T(""));
	/*pPortScan =*/ ifx_httpdGetVar(wp, T("PortScan"), T(""));
	/*pScanSecu =*/ ifx_httpdGetVar(wp, T("ScanSecu"), T(""));
	/*pNetBios =*/ ifx_httpdGetVar(wp, T("NetBios"), T(""));
	/*pDefrag =*/ ifx_httpdGetVar(wp, T("Defrag"), T(""));
	/*pSendIcmpErr =*/ ifx_httpdGetVar(wp, T("SendIcmpErr"), T(""));

	if (!gstrcmp(pDoSProtect, "1")) {
		gsprintf(sDoSProtect,
			 T("ENABLE_HACKER_ATTACK_PROTECT=\"%s\"\n"),
			 pDoSProtect);
		gsprintf(sCommand, "%s --DoS 1\n", NAPTCFG);
	} else {
		gsprintf(sDoSProtect,
			 T("ENABLE_HACKER_ATTACK_PROTECT=\"0\"\n"));
		gsprintf(sCommand, "%s --DoS 0\n", NAPTCFG);
	}
	system(sCommand);
	if (!gstrcmp(pC1, "1")) {
		gsprintf(sC1, T("DISCARD_PING_FROM_WAN_SIDE=\"%s\"\n"), pC1);
		gsprintf(sCommand, "%s --Ping 1\n", NAPTCFG);
	} else {
		gsprintf(sC1, T("DISCARD_PING_FROM_WAN_SIDE=\"0\"\n"));
		gsprintf(sCommand, "%s --Ping 0\n", NAPTCFG);
	}
	system(sCommand);

	if (!gstrcmp(pPingGW, "1")) {
		gsprintf(sPingGW, T("ALLOW_PING_THE_GW=\"%s\"\n"), pPingGW);
		gsprintf(sCommand, "%s --WPing 1\n", NAPTCFG);
	} else {
		gsprintf(sPingGW, T("ALLOW_PING_THE_GW=\"0\"\n"));
		gsprintf(sCommand, "%s --WPing 0\n", NAPTCFG);
	}
	system(sCommand);

	ifx_SetCfgData(FILE_RC_CONF, TAG_FIREWALL_DISABLEWAN, 3, sDoSProtect,
		       sC1, sPingGW);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	//Runtime Change
	websNextPage(wp);
}

void ifx_set_firewall_packetfilter(httpd_t wp, char_t * path, char_t * query)
{
	char_t buf[MAX_DATA_LEN];
	char_t *pCheck, *pPfStatus;
	char_t *pIndex = ifx_httpdGetVar(wp, T("delindex"), T(""));
	char_t *pSubAction = ifx_httpdGetVar(wp, T("subaction"), T(""));
	int nIndex, nPacketFilter_Size = 0;

	IFX_MAPI_Firewall_PF pfstatus;
	IFX_MAPI_Firewall_PFRule *pfrules = NULL;

	a_assert(wp);

	buf[0] = '\0';

	if (!gstrcmp(pSubAction, T("SUBMIT"))) {

		pPfStatus = ifx_httpdGetVar(wp, T("pfStatus"), T(""));

		ifx_mapi_get_firewall_pfstatus(&pfstatus, IFX_F_DEFAULT);
		pfstatus.enable = atoi(pPfStatus);
		pfstatus.iid.config_owner = IFX_WEB;
		ifx_mapi_set_firewall_pfstatus(&pfstatus, IFX_F_MODIFY);

		ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,
					      IFX_F_DEFAULT);

		// Get Enable checkbox status & Update PacketFilterTable
		for (nIndex = 0; nIndex < nPacketFilter_Size; nIndex++) {
			gsprintf(buf, "PF_F%d", nIndex);
			pCheck = ifx_httpdGetVar(wp, buf, T(""));
			pfrules[nIndex].iid.config_owner = IFX_WEB;
			strcpy(pfrules[nIndex].iid.cpeId.secName,
			       TAG_FIREWALL_PACKETFILTER);
			strcpy(pfrules[nIndex].iid.pcpeId.secName,
			       TAG_FIREWALL_PACKETFILTER_STATUS);
			if (!gstrcmp(pCheck, "1")) {
				if (!pfrules[nIndex].enable) {
					pfrules[nIndex].enable = 1;
					ifx_mapi_set_firewall_pfrule(IFX_OP_MOD,
								     pfrules +
								     nIndex,
								     IFX_F_MODIFY
								     |
								     IFX_F_DONT_CHECKPOINT);
				}
			} else {
				if (pfrules[nIndex].enable) {
					pfrules[nIndex].enable = 0;
					ifx_mapi_set_firewall_pfrule(IFX_OP_MOD,
								     pfrules +
								     nIndex,
								     IFX_F_MODIFY
								     |
								     IFX_F_DONT_CHECKPOINT);
				}
			}
		}
	}

	else if (!gstrcmp(pSubAction, T("DELETE_ENTRY"))) {

		ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,
					      IFX_F_DEFAULT);

		char_t *pDelIndex = ifx_httpdGetVar(wp, T("delindex"), T(""));
		int nDelIndex = gatoi(pDelIndex);
		if ((pfrules) && (nDelIndex >= 0) && (nDelIndex < 32767)) {
			pfrules[nDelIndex].iid.config_owner = IFX_WEB;
			strcpy(pfrules[nDelIndex].iid.cpeId.secName,
			       TAG_FIREWALL_PACKETFILTER);
			strcpy(pfrules[nDelIndex].iid.pcpeId.secName,
			       TAG_FIREWALL_PACKETFILTER_STATUS);
		}
		//trace(8, "Del table\n");
		if (nDelIndex >= 0 && nDelIndex < 32767)
			ifx_mapi_set_firewall_pfrule(IFX_OP_DEL,
						     pfrules + nDelIndex,
						     IFX_F_DELETE |
						     IFX_F_DONT_CHECKPOINT);
	}

	else if (!gstrcmp(pSubAction, T("DELETE_ALL"))) {

		ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,
					      IFX_F_DEFAULT);
		for (nIndex = nPacketFilter_Size - 1; nIndex >= 0; nIndex--) {

			pfrules[nIndex].iid.config_owner = IFX_WEB;
			strcpy(pfrules[nIndex].iid.cpeId.secName,
			       TAG_FIREWALL_PACKETFILTER);
			strcpy(pfrules[nIndex].iid.pcpeId.secName,
			       TAG_FIREWALL_PACKETFILTER_STATUS);

			ifx_mapi_set_firewall_pfrule(IFX_OP_DEL,
						     pfrules + nIndex,
						     IFX_F_DELETE |
						     IFX_F_DONT_CHECKPOINT);
		}
	}

	else if (!gstrcmp(pSubAction, T("ADD_ENTRY"))) {

		strcpy(natvsAction, pSubAction);
		ifx_httpdRedirect(wp, "firewall_packetfilter_add.asp");
		return;

	}

	else if (!gstrcmp(pSubAction, T("MODIFY_ENTRY"))) {

		strcpy(natvsAction, pSubAction);
		strcpy(natcpeId, pIndex);
		ifx_httpdRedirect(wp, "firewall_packetfilter_mod.asp");
		return;

	}

	if (pfrules != NULL)
		IFX_MEM_FREE(pfrules);

	ifx_httpdRedirect(wp, "firewall_packetfilter.asp");

}

void ifx_set_firewall_packetfilter_mod(httpd_t wp, char_t * path,
				       char_t * query)
{
	char_t conn_if[IFNAMSIZE];
	char_t *pIndex = ifx_httpdGetVar(wp, T("modindex"), T(""));
	int nPacketFilter_Size = 0;
	int nIndex = atoi(pIndex);
	WAN_TYPE in_wan_type = WAN_TYPE_IP, out_wan_type = WAN_TYPE_IP;

	IFX_MAPI_Firewall_PFRule *pfrules = NULL;

	char_t *pPF_F = ifx_httpdGetVar(wp, T("PF_F_ADD"), T(""));
	char_t *pPF_IP_SRC_IP =
	    ifx_httpdGetVar(wp, T("PF_IP_SRC_IP_ADD"), T(""));
	char_t *pPF_IP_SRC_TYPE =
	    ifx_httpdGetVar(wp, T("PF_IP_SRC_TYPE_ADD"), T(""));
	char_t *pPF_IP_SRC_MASK =
	    ifx_httpdGetVar(wp, T("PF_IP_SRC_MASK_ADD"), T(""));
	char_t *pPF_IP_DST_TYPE =
	    ifx_httpdGetVar(wp, T("PF_IP_DST_TYPE_ADD"), T(""));
	char_t *pPF_IP_DST_IP =
	    ifx_httpdGetVar(wp, T("PF_IP_DST_IP_ADD"), T(""));
	char_t *pPF_IP_DST_MASK =
	    ifx_httpdGetVar(wp, T("PF_IP_DST_MASK_ADD"), T(""));
	char_t *pPF_PORT_SRC_START =
	    ifx_httpdGetVar(wp, T("PF_PORT_SRC_START_ADD"), T(""));
	char_t *pPF_PORT_SRC_END =
	    ifx_httpdGetVar(wp, T("PF_PORT_SRC_END_ADD"), T(""));
	char_t *pPF_PORT_DST_START =
	    ifx_httpdGetVar(wp, T("PF_PORT_DST_START_ADD"), T(""));
	char_t *pPF_PORT_DST_END =
	    ifx_httpdGetVar(wp, T("PF_PORT_DST_END_ADD"), T(""));
	char_t *pPF_MAC = ifx_httpdGetVar(wp, T("PF_MAC_ADD"), T(""));
	char_t *pPF_TYPE = ifx_httpdGetVar(wp, T("PF_TYPE_ADD"), T(""));
	char_t *pPF_IN_IF = ifx_httpdGetVar(wp, T("PF_IN_IF_ADD"), T(""));
	char_t *pPF_OUT_IF = ifx_httpdGetVar(wp, T("PF_OUT_IF_ADD"), T(""));

	if (strstr(pPF_IN_IF, "WANIP"))
		in_wan_type = WAN_TYPE_IP;
	else if (strstr(pPF_IN_IF, "WANPPP"))
		in_wan_type = WAN_TYPE_PPP;

	if (strstr(pPF_OUT_IF, "WANIP"))
		out_wan_type = WAN_TYPE_IP;
	else if (strstr(pPF_OUT_IF, "WANPPP"))
		out_wan_type = WAN_TYPE_PPP;

	memset(conn_if, 0x00, sizeof(conn_if));

	ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,
				      IFX_F_DEFAULT);
	if (pfrules) {
		if (nIndex < nPacketFilter_Size) {

			//populate the values read from the webpage
			pfrules[nIndex].enable = atoi(pPF_F);
			pfrules[nIndex].srcType = atoi(pPF_IP_SRC_TYPE);
			if (strlen(pPF_IP_SRC_IP) > 0) {
				pfrules[nIndex].srcIP.ip.s_addr =
				    inet_addr(pPF_IP_SRC_IP);
				pfrules[nIndex].srcIP.mask.s_addr =
				    inet_addr(pPF_IP_SRC_MASK);
			} else {
				pfrules[nIndex].srcIP.ip.s_addr = 0;
				pfrules[nIndex].srcIP.mask.s_addr = 0;

			}

			if (strlen(pPF_IP_DST_IP) > 0) {
				pfrules[nIndex].dstIP.ip.s_addr =
				    inet_addr(pPF_IP_DST_IP);
				pfrules[nIndex].dstIP.mask.s_addr =
				    inet_addr(pPF_IP_DST_MASK);
			} else {
				pfrules[nIndex].dstIP.ip.s_addr = 0;
				pfrules[nIndex].dstIP.mask.s_addr = 0;
			}
			pfrules[nIndex].dstType = atoi(pPF_IP_DST_TYPE);
			pfrules[nIndex].sPortRange.start_port =
			    atoi(pPF_PORT_SRC_START);
			pfrules[nIndex].sPortRange.end_port =
			    atoi(pPF_PORT_SRC_END);
			pfrules[nIndex].dPortRange.start_port =
			    atoi(pPF_PORT_DST_START);
			pfrules[nIndex].dPortRange.end_port =
			    atoi(pPF_PORT_DST_END);
			pfrules[nIndex].protoType = atoi(pPF_TYPE);

			memset(conn_if, 0x00, sizeof(conn_if));
			if (!strlen(pPF_IN_IF))
				strcpy(pfrules[nIndex].iif, "");
			else {
				ifx_get_wan_ifname_from_connName(pPF_IN_IF,
								 conn_if,
								 in_wan_type);
				if (strlen(conn_if) < 1) {
					ifx_get_lan_ifname_from_connName
					    (pPF_IN_IF, conn_if);
					if (strlen(conn_if) < 1) {
						ifx_httpdError(wp, 400,
							       T
							       ("No wan connection with [%s] name found !!"),
							       pPF_IN_IF);
						return;
					}
				}
				strcpy(pfrules[nIndex].iif, conn_if);
			}

			memset(conn_if, 0x00, sizeof(conn_if));
			if (!strlen(pPF_OUT_IF))
				strcpy(pfrules[nIndex].oif, "");
			else {
				ifx_get_wan_ifname_from_connName(pPF_OUT_IF,
								 conn_if,
								 out_wan_type);
				if (strlen(conn_if) < 1) {
					ifx_get_lan_ifname_from_connName
					    (pPF_OUT_IF, conn_if);
					if (strlen(conn_if) < 1) {
						ifx_httpdError(wp, 400,
							       T
							       ("No wan connection with [%s] name found !!"),
							       pPF_OUT_IF);
						return;
					}
				}
				strcpy(pfrules[nIndex].oif, conn_if);
			}

			if (strlen(pPF_MAC))
				sprintf(pfrules[nIndex].sMacAddr, "%s",
					pPF_MAC);
			else
				strcpy(pfrules[nIndex].sMacAddr, "");

			ifx_mapi_set_firewall_pfrule(IFX_OP_MOD,
						     pfrules + nIndex,
						     IFX_F_MODIFY |
						     IFX_F_DONT_CHECKPOINT);
		}
	}
	websNextPage(wp);
	IFX_MEM_FREE(pfrules)
}

void ifx_set_firewall_packetfilter_add(httpd_t wp, char_t * path,
				       char_t * query)
{
	char_t conn_if[IFNAMSIZE];
	IFX_MAPI_Firewall_PFRule pfrule;
	WAN_TYPE in_wan_type = WAN_TYPE_IP, out_wan_type = WAN_TYPE_IP;

	char_t *pPF_F = ifx_httpdGetVar(wp, T("PF_F_ADD"), T(""));
	char_t *pPF_IP_SRC_IP =
	    ifx_httpdGetVar(wp, T("PF_IP_SRC_IP_ADD"), T(""));
	char_t *pPF_IP_SRC_TYPE =
	    ifx_httpdGetVar(wp, T("PF_IP_SRC_TYPE_ADD"), T(""));
	char_t *pPF_IP_SRC_MASK =
	    ifx_httpdGetVar(wp, T("PF_IP_SRC_MASK_ADD"), T(""));
	char_t *pPF_IP_DST_TYPE =
	    ifx_httpdGetVar(wp, T("PF_IP_DST_TYPE_ADD"), T(""));
	char_t *pPF_IP_DST_IP =
	    ifx_httpdGetVar(wp, T("PF_IP_DST_IP_ADD"), T(""));
	char_t *pPF_IP_DST_MASK =
	    ifx_httpdGetVar(wp, T("PF_IP_DST_MASK_ADD"), T(""));
	char_t *pPF_PORT_SRC_START =
	    ifx_httpdGetVar(wp, T("PF_PORT_SRC_START_ADD"), T(""));
	char_t *pPF_PORT_SRC_END =
	    ifx_httpdGetVar(wp, T("PF_PORT_SRC_END_ADD"), T(""));
	char_t *pPF_PORT_DST_START =
	    ifx_httpdGetVar(wp, T("PF_PORT_DST_START_ADD"), T(""));
	char_t *pPF_PORT_DST_END =
	    ifx_httpdGetVar(wp, T("PF_PORT_DST_END_ADD"), T(""));
	char_t *pPF_MAC = ifx_httpdGetVar(wp, T("PF_MAC_ADD"), T(""));
	char_t *pPF_TYPE = ifx_httpdGetVar(wp, T("PF_TYPE_ADD"), T(""));
	char_t *pPF_IN_IF = ifx_httpdGetVar(wp, T("PF_IN_IF_ADD"), T(""));
	char_t *pPF_OUT_IF = ifx_httpdGetVar(wp, T("PF_OUT_IF_ADD"), T(""));

	if (strstr(pPF_IN_IF, "WANIP"))
		in_wan_type = WAN_TYPE_IP;
	else if (strstr(pPF_IN_IF, "WANPPP"))
		in_wan_type = WAN_TYPE_PPP;

	if (strstr(pPF_OUT_IF, "WANIP"))
		out_wan_type = WAN_TYPE_IP;
	else if (strstr(pPF_OUT_IF, "WANPPP"))
		out_wan_type = WAN_TYPE_PPP;

	memset(conn_if, 0x00, sizeof(conn_if));

	memset(&pfrule, 0x00, sizeof(pfrule));

	pfrule.iid.config_owner = IFX_WEB;

	//populate the values read from the webpage
	pfrule.enable = atoi(pPF_F);
	pfrule.srcType = atoi(pPF_IP_SRC_TYPE);
	if (strlen(pPF_IP_SRC_IP) > 0) {
		pfrule.srcIP.ip.s_addr = inet_addr(pPF_IP_SRC_IP);
		pfrule.srcIP.mask.s_addr = inet_addr(pPF_IP_SRC_MASK);
	}
	if (strlen(pPF_IP_DST_IP) > 0) {
		pfrule.dstIP.ip.s_addr = inet_addr(pPF_IP_DST_IP);
		pfrule.dstIP.mask.s_addr = inet_addr(pPF_IP_DST_MASK);
	}
	pfrule.dstType = atoi(pPF_IP_DST_TYPE);
	pfrule.sPortRange.start_port = atoi(pPF_PORT_SRC_START);
	pfrule.sPortRange.end_port = atoi(pPF_PORT_SRC_END);
	pfrule.dPortRange.start_port = atoi(pPF_PORT_DST_START);
	pfrule.dPortRange.end_port = atoi(pPF_PORT_DST_END);
	pfrule.protoType = atoi(pPF_TYPE);

	memset(conn_if, 0x00, sizeof(conn_if));
	if (!strlen(pPF_IN_IF))
		strcpy(pfrule.iif, "");
	else {
		ifx_get_wan_ifname_from_connName(pPF_IN_IF, conn_if,
						 in_wan_type);
		if (strlen(conn_if) < 1) {
			ifx_get_lan_ifname_from_connName(pPF_IN_IF, conn_if);
			if (strlen(conn_if) < 1) {
				ifx_httpdError(wp, 400,
					       T
					       ("No wan connection with [%s] name found !!"),
					       pPF_IN_IF);
				return;
			}
		}
		strcpy(pfrule.iif, conn_if);
	}
	memset(conn_if, 0x00, sizeof(conn_if));
	if (!strlen(pPF_OUT_IF))
		strcpy(pfrule.oif, "");
	else {
		ifx_get_wan_ifname_from_connName(pPF_OUT_IF, conn_if,
						 out_wan_type);
		if (strlen(conn_if) < 1) {
			ifx_get_lan_ifname_from_connName(pPF_OUT_IF, conn_if);
			if (strlen(conn_if) < 1) {
				ifx_httpdError(wp, 400,
					       T
					       ("No wan connection with [%s] name found !!"),
					       pPF_OUT_IF);
				return;
			}
		}
		strcpy(pfrule.oif, conn_if);
	}

	if (strlen(pPF_MAC))
		sprintf(pfrule.sMacAddr, "%s", pPF_MAC);

	ifx_mapi_set_firewall_pfrule(IFX_OP_ADD, &pfrule,
				     IFX_F_INT_ADD | IFX_F_DONT_CHECKPOINT);

	websNextPage(wp);
}
#endif				//CONFIG_FEATURE_FIREWALL

int websUpdate_FirewallMac(int nCount, CGI_TABLE_S * FirewallMacTable)
{
	struct mac_filter *MF = NULL;

	MF = (struct mac_filter *)calloc(nCount, sizeof(struct mac_filter));
	if (MF == NULL)
		return -1;

	int nIndex = 0;

	for (nIndex = 0; nIndex < nCount; nIndex++) {
		MF[nIndex].state = FirewallMacTable[nIndex].nState;
		strcpy(MF[nIndex].mac_addr,
		       FirewallMacTable[nIndex].Data.PC_TABLE.sPC_MAC_ADDR);
		strcpy(MF[nIndex].day_selection,
		       FirewallMacTable[nIndex].Data.PC_TABLE.
		       sPC_DAY_SELECTION);
		strcpy(MF[nIndex].time_start,
		       FirewallMacTable[nIndex].Data.PC_TABLE.sPC_TIME_START);
		strcpy(MF[nIndex].time_end,
		       FirewallMacTable[nIndex].Data.PC_TABLE.sPC_TIME_END);
	}
	return (ifx_set_mac_filter_rules(nCount, MF));	//FIXME (Sumedh) : this api call is included in this file itself
}

#ifdef CONFIG_FEATURE_FIREWALL
// firewall_mac.asp
void ifx_set_firewall_mac(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck = ifx_httpdGetVar(wp, T("check"), T(""));
	char_t *pAdd = ifx_httpdGetVar(wp, T("addF"), T(""));
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	int nIndex = 0, nCurNum = 0;
	char_t sBuf[MAX_DATA_LEN];
	char_t *padConnecti;
	char_t sCommand[40];

	CGI_TABLE_S FirewallMacTable[MAX_RULES];
	int tmp1 = 0;

	for (nIndex = 0; nIndex < MAX_RULES; nIndex++)
		memset(&FirewallMacTable[nIndex], 0x00,
		       sizeof(FirewallMacTable[nIndex]));

	nCurNum =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_FIREWALLMAC,
				 PREFIX_FIREWALL_PC, FirewallMacTable,
				 MAC_FILTER_TABLE_TYPE);
	if (nCurNum == -1) {
		ifx_httpdError(wp, 500,
			       "Insufficient data for firewall Mac table");
		return;
	}
// Get Allow Connect checkbox status
	for (nIndex = 0; nIndex < nCurNum; nIndex++) {
		gsprintf(sBuf, "addconnect%d", nIndex);
		padConnecti = ifx_httpdGetVar(wp, sBuf, T(""));

		FirewallMacTable[nIndex].nState = atoi(padConnecti);
	}

	////////// Update Table to File ///////////////
	websUpdate_FirewallMac(nCurNum, FirewallMacTable);

	// Submit data form press "Add" button
	if (atoi(pAdd) == 1) {
		char_t *pMacfilterAdd0 = ifx_httpdGetVar(wp, T("macfilterAdd0"), T(""));	// Text
		char_t *pMacfilterAdd1 = ifx_httpdGetVar(wp, T("macfilterAdd1"), T(""));	// Text
		char_t *pMacfilterAdd2 = ifx_httpdGetVar(wp, T("macfilterAdd2"), T(""));	// Text
		char_t *pMacfilterAdd3 = ifx_httpdGetVar(wp, T("macfilterAdd3"), T(""));	// Text
		char_t *pMacfilterAdd4 = ifx_httpdGetVar(wp, T("macfilterAdd4"), T(""));	// Text
		char_t *pMacfilterAdd5 = ifx_httpdGetVar(wp, T("macfilterAdd5"), T(""));	// Text
		char_t *pMacfilterAction = ifx_httpdGetVar(wp, T("macfilterAction"), T(""));	// checkbox
		struct mac_filter MF;

		gsprintf(MF.mac_addr, T("%s:%s:%s:%s:%s:%s"), pMacfilterAdd0,
			 pMacfilterAdd1, pMacfilterAdd2, pMacfilterAdd3,
			 pMacfilterAdd4, pMacfilterAdd5);
		for (tmp1 = 0; tmp1 < 7; tmp1++)
			MF.day_selection[tmp1] = 'x';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Mon"), T("")), "1", 1) == 0)
			MF.day_selection[0] = '1';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Tue"), T("")), "1", 1) == 0)
			MF.day_selection[1] = '1';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Wed"), T("")), "1", 1) == 0)
			MF.day_selection[2] = '1';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Thu"), T("")), "1", 1) == 0)
			MF.day_selection[3] = '1';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Fri"), T("")), "1", 1) == 0)
			MF.day_selection[4] = '1';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Sat"), T("")), "1", 1) == 0)
			MF.day_selection[5] = '1';
		if (gstrncmp(ifx_httpdGetVar(wp, T("Sun"), T("")), "1", 1) == 0)
			MF.day_selection[6] = '1';

		gstrcpy(MF.time_start,
			ifx_httpdGetVar(wp, T("start_time"), T("")));
		if (!gstrcmp(MF.time_start, "")
		    || !gstrncmp(MF.day_selection, "xxxxxxx",
				 sizeof(MF.day_selection)))
			gstrcpy(MF.time_start, "00:00");
		gstrcpy(MF.time_end, ifx_httpdGetVar(wp, T("end_time"), T("")));
		if (!gstrcmp(MF.time_end, "")
		    || !gstrncmp(MF.day_selection, "xxxxxxx",
				 sizeof(MF.day_selection)))
			gstrcpy(MF.time_end, "23:59");

		MF.state = atoi(pMacfilterAction);
		for (nIndex = 0; nIndex <= nCurNum; nIndex++) {
			if (gstrncmp
			    (FirewallMacTable[nIndex].Data.PC_TABLE.
			     sPC_MAC_ADDR, MF.mac_addr,
			     sizeof(MF.mac_addr)) == 0
			    && gstrncmp(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_DAY_SELECTION, MF.day_selection,
					sizeof(MF.day_selection)) == 0
			    && gstrncmp(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_TIME_START, MF.time_start,
					sizeof(MF.time_start)) == 0
			    && gstrncmp(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_TIME_END, MF.time_end,
					sizeof(MF.time_end)) == 0) {
				ifx_httpdError(wp, 500,
					       "Duplicate Filter Entry");
				return;
			}

			if (FirewallMacTable[nIndex].nIndex == 0
			    && !FirewallMacTable[nIndex].Data.PC_TABLE.
			    sPC_MAC_ADDR[0]) {
				FirewallMacTable[nIndex].nIndex = nIndex;
				FirewallMacTable[nIndex].nState = MF.state;
				gstrncpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					 sPC_MAC_ADDR, MF.mac_addr,
					 sizeof(MF.mac_addr));
				gstrncpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					 sPC_DAY_SELECTION, MF.day_selection,
					 sizeof(MF.day_selection));
				gstrncpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					 sPC_TIME_START, MF.time_start,
					 sizeof(MF.time_start));
				gstrncpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					 sPC_TIME_END, MF.time_end,
					 sizeof(MF.time_end));
				nCurNum = nIndex + 1;
				break;
			}
		}
		// No more space to add data
		if (nIndex > MAX_RULES) {
			ifx_httpdError(wp, 500, T("Out of space to add rules"));
			return;
		}
		////////// Update Table to File ///////////////
		websUpdate_FirewallMac(nCurNum, FirewallMacTable);
	}
	// Submit data form press delete button
	if (!gstrcmp(pDel, T("1"))) {
		char_t *pDelIndex = ifx_httpdGetVar(wp, T("delindex"), T(""));
		int nDelIndex = gatoi(pDelIndex);

		// Remove DelIndex form Table
		for (nIndex = 0; nIndex < nCurNum; nIndex++) {
			if (nIndex >= nDelIndex) {
				FirewallMacTable[nIndex].nIndex =
				    FirewallMacTable[nIndex + 1].nIndex;
				FirewallMacTable[nIndex].nState =
				    FirewallMacTable[nIndex + 1].nState;
				gstrcpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_MAC_ADDR,
					FirewallMacTable[nIndex +
							 1].Data.PC_TABLE.
					sPC_MAC_ADDR);
				gstrcpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_DAY_SELECTION,
					FirewallMacTable[nIndex +
							 1].Data.PC_TABLE.
					sPC_DAY_SELECTION);
				gstrcpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_TIME_START,
					FirewallMacTable[nIndex +
							 1].Data.PC_TABLE.
					sPC_TIME_START);
				gstrcpy(FirewallMacTable[nIndex].Data.PC_TABLE.
					sPC_TIME_END,
					FirewallMacTable[nIndex +
							 1].Data.PC_TABLE.
					sPC_TIME_END);
			}
		}

		////////// Update Table to File ///////////////
		websUpdate_FirewallMac(nCurNum - 1, FirewallMacTable);
	}

	gsprintf(sCommand, "%s --MACFilterinit\n", NAPTCFG);
//Runtime Change
	system(sCommand);

	// Normal case, press 'Apply' only
	if (!gstrcmp(pCheck, T("1"))) {
		gsprintf(sBuf, "MAC_control=\"%d\"\n", 1);
		gsprintf(sCommand, "%s --MACFilter 1\n", NAPTCFG);
	} else if (!gstrcmp(pCheck, T("2"))) {
		gsprintf(sBuf, "MAC_control=\"%d\"\n", 2);
		gsprintf(sCommand, "%s --MACFilter 2\n", NAPTCFG);
	} else {
		gsprintf(sBuf, "MAC_control=\"%d\"\n", 0);
		gsprintf(sCommand, "%s --MACFilter 0\n", NAPTCFG);
	}
	system(sCommand);

	ifx_SetCfgData(FILE_RC_CONF, TAG_FIREWALLMAC_STAT, 1, sBuf);	//FIXME (Sumedh) : API for MAC Control is not included as of now (should be integrated with all other apis)

#ifdef CONFIG_FEATURE_IPv6
	{
		extern int ifx_get_glob_IPv6();
		if(ifx_get_glob_IPv6() == 1) {
			system("/etc/rc.d/firewall6 restart filter mfilter");
		}
	}
#endif


	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	websNextPage(wp);
}
#endif				//CONFIG_FEATURE_FIREWALL

#ifdef CONFIG_FEATURE_FIREWALL
void ifx_set_AppFilter(httpd_t wp, char_t * path, char_t ** query)
{
	char_t *buffer = NULL;
	char_t *pCheck = NULL, sCheck[MAX_WEB_DATA];
	char_t sParams[][32] = {
		"APP_FILTER",
		"APP_FILTER_MSN",
		"APP_FILTER_YAHOO"
	};
	int i = 0;
	char_t
	    sCommand[(sizeof(sParams) / (32 * sizeof(char_t)))][MAX_DATA_LEN];

	a_assert(wp);
	sCheck[0] = '\0';

	buffer = (char_t *) malloc(sizeof(char_t) * (BUF_SIZE_50K));
        if (!buffer) 
            goto end;
	memset(buffer, 0x00, BUF_SIZE_50K);
	gstrcpy(buffer, "");

	for (i = 0; i < sizeof(sParams) / (32 * sizeof(char_t)); i++) {
	// Get value from ASP filz
        	pCheck = ifx_httpdGetVar(wp, sParams[i], T(""));
        	if (!gstrcmp(pCheck, "1")) {
		   snprintf(sCheck, sizeof(sCheck),
		   T("%s=\"1\"\n"), sParams[i]);
		   sprintf(sCommand[i], "%s --%s 1\n", NAPTCFG,
		        	sParams[i]);
	        } else {
	  	   snprintf(sCheck, sizeof(sCheck),
		   T("%s=\"0\"\n"), sParams[i]);
		   sprintf(sCommand[i], "%s --%s 0\n", NAPTCFG,
		    sParams[i]);
	        }
//	LTQ_STRNCAT(buffer, sCheck, sizeof(buffer));
	        strcat(buffer, sCheck);
	}
	ifx_SetCfgData(FILE_RC_CONF, TAG_APP_FILTER, 1, buffer);

	// save setting
	if (ifx_flash_write() <= 0) {
	        IFX_MEM_FREE(buffer);
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	for (i = 0; i < sizeof(sParams) / (32 * sizeof(char_t)); i++) {
		system(sCommand[i]);
	}

	IFX_MEM_FREE(buffer);
end:
	websNextPage(wp);
}

#endif
#ifdef POLICY_ROUTING
//              PAGE : policy_routing.asp
void ifx_set_policy_routing(httpd_t wp, char_t * path, char_t * query)
{
	char_t sPrStatus[MAX_DATA_LEN];
	char_t *pPrStatus = NULL;
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	char_t sCommand[MAX_DATA_LEN];
	POLICY_ROUTE policy_route;

	a_assert(wp);

	memset(&policy_route, 0x00, sizeof(policy_route));

	// Submit data form press delete button
	if (!gstrcmp(pDel, T("1"))) {
		char_t *pDelcpeID = ifx_httpdGetVar(wp, T("delcpeId"), T(""));
		policy_route.iid.cpeId.Id = atoi(pDelcpeID);
		policy_route.iid.pcpeId.Id = 1;
		/* Set owner as WEB */
		policy_route.iid.config_owner = IFX_WEB;
		if (ifx_set_policy_route
		    (IFX_OP_DEL, &policy_route, IFX_F_DELETE) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to delete the specified policy route entry !!");
			return;
		}
	} else {
		sPrStatus[0] = '\0';
		pPrStatus = ifx_httpdGetVar(wp, T("prStatus"), T(""));

		if (!gstrcmp(pPrStatus, T("1"))) {
			gsprintf(sPrStatus, T("PR_STATUS=\"1\"\n"));
		} else {
			gsprintf(sPrStatus, T("PR_STATUS=\"0\"\n"));
		}
		if (ifx_SetObjData
		    (FILE_RC_CONF, TAG_POLICY_ROUTING_STATUS, IFX_F_MODIFY, 1,
		     sPrStatus) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to enabled policy routing !!");
			return;
		}
		sprintf(sCommand, "%s --PolicyRoutingInit %s\n", NAPTCFG,
			pPrStatus);
		system(sCommand);
		system(SERVICE_POLICY_ROUTING_RESTART);
	}
	websNextPage(wp);
}

//              PAGE : policy_routing_add.asp
void ifx_set_policy_routing_add(httpd_t wp, char_t * path, char_t * query)
{
	POLICY_ROUTE policy_route;

	char_t *pPR_R = ifx_httpdGetVar(wp, T("PR_ADD"), T(""));
	char_t *pPR_SRC_IP = ifx_httpdGetVar(wp, T("PR_SRC_IP"), T(""));
	char_t *pPR_IP_SRC_TYPE =
	    ifx_httpdGetVar(wp, T("PR_IP_SRC_TYPE_ADD"), T(""));
	char_t *pPR_IP_SRC_MASK =
	    ifx_httpdGetVar(wp, T("PR_IP_SRC_MASK_ADD"), T(""));
	char_t *pPR_IP_DST_TYPE =
	    ifx_httpdGetVar(wp, T("PR_IP_DST_TYPE_ADD"), T(""));
	char_t *pPR_IP_DST_MASK =
	    ifx_httpdGetVar(wp, T("PR_IP_DST_MASK_ADD"), T(""));
	char_t *pPR_SRC_PORT = ifx_httpdGetVar(wp, T("PR_SRC_PORT"), T(""));
	char_t *pPR_DST_IP = ifx_httpdGetVar(wp, T("PR_DST_IP"), T(""));
	char_t *pPR_DST_PORT = ifx_httpdGetVar(wp, T("PR_DST_PORT"), T(""));
	char_t *pPR_PROTOCOL = ifx_httpdGetVar(wp, T("PR_PROTOCOL"), T(""));
	char_t *pPR_DIFFSERV = ifx_httpdGetVar(wp, T("PR_DIFFSERV"), T(""));
	char_t *pPR_OPIF = ifx_httpdGetVar(wp, T("PR_OP_IF"), T(""));
	char_t *pPR_GW_IP = ifx_httpdGetVar(wp, T("PR_GW_IP"), T(""));

	// copy data to Policy Routing Table
	memset(&policy_route, 0x00, sizeof(policy_route));
	if (!gstrcmp(pPR_R, "1")) {
		policy_route.f_enable = IFX_ENABLED;
	} else {
		policy_route.f_enable = IFX_DISABLED;
	}
	// copy src ip
	if (atoi(pPR_IP_SRC_TYPE) != 0 && strlen(pPR_SRC_IP)) {
		policy_route.ip_src.ip.s_addr = inet_addr(pPR_SRC_IP);
		if (atoi(pPR_IP_SRC_TYPE) == 2 && strlen(pPR_IP_SRC_MASK)) {
			policy_route.ip_src.mask.s_addr =
			    inet_addr(pPR_IP_SRC_MASK);
		} else if (atoi(pPR_IP_SRC_TYPE) == 1) {
			policy_route.ip_src.mask.s_addr =
			    inet_addr("255.255.255.255");
		} else {
			policy_route.ip_src.mask.s_addr = inet_addr("0.0.0.0");
		}
	} else {
		policy_route.ip_src.ip.s_addr = inet_addr("0.0.0.0");	/* wild card entry */
		policy_route.ip_src.mask.s_addr = inet_addr("0.0.0.0");
	}

	// copy src port
	if (strlen(pPR_SRC_PORT) && pPR_SRC_PORT[0] != '*')
		policy_route.src_ports.start_port = atoi(pPR_SRC_PORT);
	else
		policy_route.src_ports.start_port = 0;	/* wild card entry */

	policy_route.src_ports.end_port = policy_route.src_ports.start_port;

	// copy dst ip
	if (atoi(pPR_IP_DST_TYPE) != 0 && strlen(pPR_DST_IP)) {
		policy_route.ip_dst.ip.s_addr = inet_addr(pPR_DST_IP);
		if (atoi(pPR_IP_DST_TYPE) == 2 && strlen(pPR_IP_DST_MASK)) {
			policy_route.ip_dst.mask.s_addr =
			    inet_addr(pPR_IP_DST_MASK);
		} else if (atoi(pPR_IP_DST_TYPE) == 1) {
			policy_route.ip_dst.mask.s_addr =
			    inet_addr("255.255.255.255");
		} else {
			policy_route.ip_dst.mask.s_addr = inet_addr("0.0.0.0");
		}
	} else {
		policy_route.ip_dst.ip.s_addr = inet_addr("0.0.0.0");	/* wild card entry */
		policy_route.ip_dst.mask.s_addr = inet_addr("0.0.0.0");
	}
// copy dst port
	if (strlen(pPR_DST_PORT) && pPR_DST_PORT[0] != '*')
		policy_route.dst_ports.start_port = atoi(pPR_DST_PORT);
	else
		policy_route.dst_ports.start_port = 0;	/* wild card entry */

	policy_route.dst_ports.end_port = policy_route.dst_ports.start_port;

	// copy protocol
	if (!pPR_PROTOCOL[0])
		policy_route.rt_protocol = -1;	/* FIXME : should not be blank !! */
	else
		policy_route.rt_protocol = atoi(pPR_PROTOCOL);

	// copy diffserv
	if (pPR_DIFFSERV[0])
		policy_route.tos = atoi(pPR_DIFFSERV);

	// copy output interface
	if (pPR_OPIF[0] != '*')
		sprintf(policy_route.route_if, "%s", pPR_OPIF);

	if (strlen(pPR_GW_IP))
		policy_route.gw.s_addr = inet_addr(pPR_GW_IP);

	/* Set owner as WEB */
	policy_route.iid.config_owner = IFX_WEB;

	if (ifx_set_policy_route(IFX_OP_ADD, &policy_route, IFX_F_INT_ADD) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to add the specified policy route !!");
		return;
	}

	websNextPage(wp);
}
#endif


//
// get_portNum
//  function to get the port and protocol information 
//
int get_portNum( char * buf, int *portNo, char *proto_buf)
{
  char *ptr;
  char *q;
  char temp[10];

  for ( ptr = buf,q= temp; *ptr != '/' && *ptr != '\n' && *ptr != '\0'; ptr++){
      *q = *ptr;
  }
  *q = '\0';
  *portNo = atoi(temp);

  if (*ptr == '/')
    ptr++;
  else  
    return -2;
  strcpy( proto_buf,ptr);
  return 0;
}

//
// update_port 
//    function to update the port details from /etc/service file 
// 
int update_Port( char *service, int port, char *fname )
{
  FILE *ifp,*ofp;
  char *ptr;
  int port_no = 0;
  char protocol[10];
  char ofname[50];
  char buf[100];
 
  ifp = fopen( fname,"r+");
  if (!ifp ) return -1;

  sprintf(ofname,"%s_ser.temp",fname);
  ofp  = fopen( ofname,"w+");
  if (!ofp ){
    fclose( ifp );
    return -2;
  }

  while( fgets( buf, 100, ifp ) ){
   for ( ptr = buf; *ptr == ' ' || *ptr == '\t'; ptr++);
   if( strncmp( ptr,service, strlen(service) ) == 0 ){
       ptr += strlen(service);
       for ( ; *ptr == ' '|| *ptr == '\t'; ptr++);
        get_portNum( ptr,&port_no, protocol);
        if ( port_no != port ){
          sprintf( ptr,"%d/%s",port,protocol);
        }
   } 
   fprintf( ofp,"%s",buf);
  }


  fclose( ifp );
  fclose( ofp );
 
  rename( ofname, fname );
  return 0;
 
}

#if defined (CONFIG_FEATURE_NAPT) && (CONFIG_FEATURE_FIREWALL)
// apps_serv.asp
void ifx_set_apps_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pValue;
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
	char_t *pValue2;
	char_t *pValue3;
	char_t *pValue4;
	char_t *pValue5;
#endif

	char_t sValue[MAX_FILELINE_LEN];
	char_t sPreValue[3][MAX_FILELINE_LEN];
	char_t sNewValue[3][MAX_FILELINE_LEN];
	
	int i = 0, count = 0;
	char_t *pBuffer;
	int nChange = 0;
	char_t sLanIP[MAX_DATA_LEN];
	int ret = IFX_SUCCESS;
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
	char *igmp = "IGMP_ENABLE";
	char *igmp_mode = "IGMP_MODE";
	char *igmp_wanInterface = "IGMP_WAN_INTF";
	char *igmp_leave_latency = "IGMP_LEAVE_LATENCY_ENABLE";
	char *igmp_maxresptime = "IGMP_MAXRESPTIME";
	char sWanIface[MAX_DATA_LEN];
	int snoop_mode = 0;
#endif
	char *snmp = "SNMP_WAN_ENABLE";
#ifdef CONFIG_FEATURE_IFX_INETD
	int service_restart_flag = 0;
#endif
	
	unsigned short pService_Info[] = {
#ifdef CONFIG_FEATURE_HTTPS_SERVER
		443, PROTO_TCP,
#endif
#ifdef CONFIG_PACKAGE_IFX_HTTPD
		80, PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_TELNET_SERVER
		23, PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_SSH_SERVER
		22, PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_TFTP_SERVER
		69, PROTO_UDP,
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
		21, PROTO_TCP,
#endif
	};
	char_t pService[][32] = {
#ifdef CONFIG_FEATURE_HTTPS_SERVER
		SERVICE_HTTP_START, SERVICE_HTTP_STOP,
#endif
#ifdef CONFIG_PACKAGE_IFX_HTTPD
		SERVICE_HTTP_START, SERVICE_HTTP_STOP,
#endif
#ifndef CONFIG_FEATURE_IFX_INETD
#ifdef CONFIG_FEATURE_TELNET_SERVER
		SERVICE_TELNET_START, SERVICE_TELNET_STOP,
#endif
#ifdef CONFIG_FEATURE_SSH_SERVER
		SERVICE_SSH_START, SERVICE_SSH_STOP,
#endif
#ifdef CONFIG_FEATURE_TFTP_SERVER
		SERVICE_TFTP_START, SERVICE_TFTP_STOP,
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
		SERVICE_FTP_START, SERVICE_FTP_STOP,
#endif
#endif				//CONFIG_FEATURE_IFX_INETD
	};
	char_t sParams[][32] = {
#ifdef CONFIG_PACKAGE_IFX_HTTPD
		"WEB_WAN_ENABLE", "WEB_WAN_PORT", "WEB_LAN_ENABLE",
#endif				//CONFIG_PACKAGE_IFX_HTTPD
#ifdef CONFIG_FEATURE_TELNET_SERVER
		"TELNET_WAN_ENABLE", "TELNET_WAN_PORT", "TELNET_LAN_ENABLE",
#endif				//CONFIG_FEATURE_TELNET_SERVER
#ifdef CONFIG_FEATURE_SSH_SERVER
		"SSH_WAN_ENABLE", "SSH_WAN_PORT", "SSH_LAN_ENABLE",
#endif				//CONFIG_FEATURE_SSH_SERVER
#ifdef CONFIG_FEATURE_TFTP_SERVER
		"TFTP_WAN_ENABLE", "TFTP_WAN_PORT", "TFTP_LAN_ENABLE",
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
		"FTP_WAN_ENABLE", "FTP_WAN_PORT", "FTP_LAN_ENABLE",
#endif				//CONFIG_FEATURE_FTP_SERVER
		"SNMP_WAN_ENABLE",
	};
 	
	/*manohar: code change for remote access*/
	remote_access_t rt_access;
	int32 oldPort;
  	int8 oldRemoteEnable;

	if(mapi_remote_access_details_get(&rt_access,IFX_F_DEFAULT) != IFX_SUCCESS)
	{
		        IFX_DBG("Failed to get remote access details parameter");
						return;
	}

	char_t *newPort = ifx_httpdGetVar(wp, T("HTTPS_WEB_WAN_PORT"), T(""));
	char_t *newRemoteEnable = ifx_httpdGetVar(wp, T("HTTPS_WEB_WAN_ENABLE"), T(""));

#if 0
	IFX_DBG("[%s][%d] HTTPS_WEB_WAN_PORT = [%d]\n rt_access = [%d]\n HTTPS_WEB_WAN_ENABLE = [%d]\nrt_access.f_enable = [%d]\n",__FUNCTION__,__LINE__,atoi(newPort),rt_access.port,atoi(newRemoteEnable),rt_access.f_enable);
#endif  

	oldPort = rt_access.port;
  	oldRemoteEnable = rt_access.f_enable;
	
  	if(atoi(newPort) != oldPort || atoi(newRemoteEnable) != oldRemoteEnable)
	{
/*manohar: code for validating alraedy used port*/
		for (i = 0; i < sizeof(sParams) / 32; i++) {
		pValue = ifx_httpdGetVar(wp, sParams[i], T(""));
		if (strstr(sParams[i], "PORT"))
			{
			if(!strcmp(newPort,pValue))
			{
				COPY_TO_STATUS("%s","<span class=\"textTitle\">Port already in use. Try some other port</span>");
				ifx_httpdRedirect(wp, "err_page.html");
				if(ret!=IFX_SUCCESS)
				{ }
				return;
			}
		}
		}
		rt_access.port=atoi(newPort);

		if(atoi(newRemoteEnable) != oldRemoteEnable)
			rt_access.f_enable = atoi(newRemoteEnable);

		if(mapi_remote_access_details_set(&rt_access,IFX_F_MODIFY) != IFX_SUCCESS)
    		{ 
		  IFX_DBG("Failed to set modified remote access parameter");
			return;
		}
	}
	/*manohar: end*/


	IP_MASK_TYPE *ip_array_type = NULL;
	uint32 flags = IFX_F_DEFAULT;

	a_assert(wp);
	memset(sValue, 0x00, sizeof(sValue));
	pBuffer = malloc(sizeof(sParams));
	if (pBuffer == NULL) {
		goto IFX_Handler;
	}
	pBuffer[0] = '\0';
	sLanIP[0] = '\0';
	if ((ifx_get_lan_ip_mask("br0", &count, &ip_array_type, flags)) == IFX_SUCCESS) {
		if (ip_array_type != NULL) {
			strcpy(sLanIP, inet_ntoa((ip_array_type)->ip_mask.ip));
			IFX_MEM_FREE(ip_array_type);
		}
	} else {
		strcpy(sLanIP, "10.10.10.250");
	}
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
	pValue = ifx_httpdGetVar(wp, igmp, T(""));
	pValue2 = ifx_httpdGetVar(wp, igmp_mode, T(""));
	pValue3 = ifx_httpdGetVar(wp, igmp_wanInterface, T(""));
	pValue4 = ifx_httpdGetVar(wp, igmp_leave_latency, T(""));
	pValue5 = ifx_httpdGetVar(wp, igmp_maxresptime, T(""));

	if (!gstrcmp(pValue, "1") && !gstrcmp(pValue3, "")) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error:WAN connection not present.</span>");
		ifx_httpdRedirect(wp, "err_page.html");
		IFX_MEM_FREE(pBuffer)
		    IFX_MEM_FREE(ip_array_type)
		    return;
	}

	sprintf(sWanIface, "%s", pValue3);

	if (!gstrcmp(pValue, "1")) {
		gsprintf(sValue,
			 "%s=\"1\"\n%s=\"%s\"\n%s=\"%s\"\n%s=\"%s\"\n%s=\"%s\"\n",
			 igmp, igmp_mode, pValue2, igmp_wanInterface, sWanIface,
			 igmp_leave_latency, pValue4, igmp_maxresptime,
			 pValue5);
	} else {
		gsprintf(sValue,
			 "%s=\"0\"\n%s=\"%s\"\n%s=\"%s\"\n%s=\"%s\"\n%s=\"%s\"\n",
			 igmp, igmp_mode, pValue2, igmp_wanInterface, sWanIface,
			 igmp_leave_latency, pValue4, igmp_maxresptime,
			 pValue5);
	}
	strcat(pBuffer, sValue);

	if (!gstrcmp(pValue2, "2") && !gstrcmp(pValue, "1")) {
		snoop_mode = 1;
	}
#endif

	ifx_GetCfgData(FILE_RC_CONF, TAG_APPLICATION_SERVER, snmp, sValue);
	pValue = ifx_httpdGetVar(wp, snmp, T(""));
	if (!gstrcmp(pValue, "1")) {
		if (gstrcmp(sValue, pValue)) {
			IFX_SET_FIREWALL_DENY_SERVICES(DELETE, IF_WAN, htons(161), PROTO_UDP);
			IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD, htons(161), PROTO_UDP, 1);
		}
		gsprintf(sValue, "%s=\"1\"\n", snmp);
	} else {
		if (gstrcmp(sValue, pValue)) {
			IFX_SET_FIREWALL_DENY_SERVICES(ADD, IF_WAN, htons(161), PROTO_UDP);
			IFX_SET_FIREWALL_ACCEPT_SERVICES(DELETE, htons(161), PROTO_UDP, 1);
		}
		gsprintf(sValue, "%s=\"0\"\n", snmp);
	}
	for (i = 0; i < sizeof(sParams) / 32; i++) {
		// Get value from ASP file
		pValue = ifx_httpdGetVar(wp, sParams[i], T(""));
IFX_DBG("[%s][%d] sParams[i] = [%s] Value = [%s]\n",__FUNCTION__,__LINE__,sParams[i],pValue);

		if (strstr(sParams[i], "PORT")) {
			gsprintf(sValue, "%s=\"%s\"\n", sParams[i], pValue);
			gstrcpy(sNewValue[i % 3], pValue);
		} else {
			if (!gstrcmp(pValue, "1")) {
				gsprintf(sValue, "%s=\"1\"\n", sParams[i]);
				gsprintf(sNewValue[i % 3], "1");
			} else {
				gsprintf(sValue, "%s=\"0\"\n", sParams[i]);
				gsprintf(sNewValue[i % 3], "0");
			}
		}
		strcat(pBuffer, sValue);
		// get previously setting
		ifx_GetCfgData(FILE_RC_CONF, TAG_APPLICATION_SERVER, sParams[i], sPreValue[i % 3]);
		if (gstrcmp(pValue, sPreValue[i % 3]) != 0) 
		{
			nChange = 1;
		}

                if ( strstr(sParams[i],"PORT") && nChange ){
                    if( !portExists(atoi(pValue), pService_Info[(i / 3) * 2 + 1])){
                       if ( i == 4 ){
                         update_Port("telnet",atoi(pValue), "/ramdisk/services");
#ifdef CONFIG_FEATURE_IFX_INETD
                         service_restart_flag = 1;
#endif 
                         system(pService[(i / 3) * 2]+1);
                         system(pService[(i / 3) * 2]);
                       } else if ( i == 7 ){
                         update_Port("tftp ",atoi(pValue), "/ramdisk/services");
#ifdef CONFIG_FEATURE_IFX_INETD
                         service_restart_flag = 1;
#endif 
                         system(pService[(i / 3) * 2]+1);
                         system(pService[(i / 3) * 2]);
                       } else if ( i == 10 ){
                         update_Port("ftp ",atoi(pValue), "/ramdisk/services");
#ifdef CONFIG_FEATURE_IFX_INETD
                         service_restart_flag = 1;
#endif 
                         system(pService[(i / 3) * 2]+1);
                         system(pService[(i / 3) * 2]);
                       }
                    }
                }
		if (i % 3 == 2) {
			if (nChange) {
				// lan side or wan side is enable.
				if (!gstrcmp(sNewValue[0], "1") || !gstrcmp(sNewValue[2], "1")) {
					// previously setting of lan and wan were disable.
					if (!gstrcmp(sPreValue[0], "0") && !gstrcmp(sPreValue[2], "0")) {
#ifdef CONFIG_FEATURE_IFX_INETD
						if (!gstrncmp("WEB", sParams[i], 3)) {
							// start service
							system(pService[(i / 3) * 2]);
						} else {
							service_restart_flag = 1;
						}

#else
						// start service
						system(pService[(i / 3) * 2]);
#endif
					}
					// wan side setting has been changed
					if (gstrcmp(sPreValue[0], sNewValue[0]) != 0) {
						// disable
						if (!gstrcmp(sNewValue[0], "0")) {
							// wan side port is not setting as default port
							// remove the redirect port
							if (pService_Info[(i / 3) * 2] != atoi(sPreValue[1]))
							{
								if (!portExists(atoi(sPreValue[1]), pService_Info[(i / 3) * 2 + 1])) {
									IFX_SET_NAPT_REDIRECT_SERVICES
									    (DELETE, htons(atoi(sPreValue[1])), pService_Info[(i / 3) * 2 + 1],
									     inet_addr(sLanIP), htons(pService_Info[(i / 3) * 2]));
									IFX_SET_FIREWALL_ACCEPT_SERVICES
									    (DELETE, htons(atoi(sPreValue[1])), pService_Info[(i / 3) * 2 + 1], 1);
								} else {
									ifx_httpdError(wp, 500, "Port already in use. Try some other port");
									IFX_MEM_FREE(ip_array_type)
							    IFX_MEM_FREE(pBuffer)
									    return;
								}
							} else {
								// add firewall rule to drop packet from wan side
								IFX_SET_FIREWALL_DENY_SERVICES
								    (ADD, IF_WAN, pService_Info[(i / 3) * 2], pService_Info[(i / 3) * 2 + 1]);
								if (!gstrcmp(sNewValue[2], "0"))	//509081:tc.chen
									IFX_SET_FIREWALL_ACCEPT_SERVICES
								    (DELETE, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1], 1);
							}
						}
						// enable
						else {
							// wan side port is not setting as default port
							// accept wan service is changed
							// redirect the port
							if (pService_Info[(i / 3) * 2] != atoi(sNewValue[1]))
							{
								if (!portExists(atoi(sNewValue[1]), pService_Info[(i / 3) * 2 + 1])) {
									IFX_SET_NAPT_REDIRECT_SERVICES
									    (ADD, htons(atoi(sNewValue[1])), pService_Info[(i / 3) * 2 + 1],
									     inet_addr(sLanIP), htons(pService_Info[(i / 3) * 2]));
									IFX_SET_FIREWALL_ACCEPT_SERVICES
									    (ADD, htons(atoi(sNewValue[1])), pService_Info[(i / 3) * 2 + 1], 1);
								} else {
									ifx_httpdError(wp, 500, "Port already in use. Try some other port");
									IFX_MEM_FREE(ip_array_type)
							    IFX_MEM_FREE(pBuffer)
									    return;
								}
							} else {
								// remove firewall rule to accept packet from wan side
								IFX_SET_FIREWALL_DENY_SERVICES(DELETE, IF_WAN, htons(pService_Info[(i / 3) * 2]),pService_Info[(i / 3) * 2 + 1]);
								if (!gstrcmp(sNewValue[2], "0"))	//509081:tc.chen
									IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1], 1);
							}
						}
					}
// redirect port has been changed
					else if (!gstrcmp(sNewValue[0], "1") && gstrcmp(sPreValue[1], sNewValue[1]) != 0) {
						if (pService_Info[(i / 3) * 2] != atoi(sPreValue[1])) {
							if (!portExists(atoi(sPreValue[1]), pService_Info[(i / 3) * 2 + 1]))
							{
								IFX_SET_NAPT_REDIRECT_SERVICES
								    (DELETE, htons(atoi(sPreValue[1])), pService_Info[(i / 3) * 2 + 1],
								     inet_addr(sLanIP), htons(pService_Info[(i / 3) * 2]));
								IFX_SET_FIREWALL_ACCEPT_SERVICES
								    (DELETE, htons(atoi(sPreValue[1])), pService_Info[(i / 3) * 2 + 1], 1);
							} else {
								ifx_httpdError(wp, 500, "Port already in use. Try some other port");
								IFX_MEM_FREE(ip_array_type)
						    IFX_MEM_FREE(pBuffer)
								    return;
							}
						} else {
							// add firewall rule to accept packet from wan side
							IFX_SET_FIREWALL_DENY_SERVICES
							    (ADD, IF_WAN, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1]);
							if (!gstrcmp(sNewValue[2], "0"))	//509081:tc.chen
								IFX_SET_FIREWALL_ACCEPT_SERVICES
							    (DELETE, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1], 1);
						}
						if (pService_Info[(i / 3) * 2] != atoi(sNewValue[1])) {
							if (!portExists(atoi(sNewValue[1]), pService_Info[(i / 3) * 2 + 1]))
							{
								IFX_SET_NAPT_REDIRECT_SERVICES
							    (ADD, htons(atoi(sNewValue[1])), pService_Info[(i / 3) * 2 + 1],
									inet_addr(sLanIP), htons(pService_Info[(i / 3) * 2]));
								IFX_SET_FIREWALL_ACCEPT_SERVICES
							    (ADD, htons(atoi(sNewValue[1])), pService_Info[(i / 3) * 2 + 1], 1);
							} else {
								ifx_httpdError
								    (wp, 500, "Port already in use. Try some other port");
								IFX_MEM_FREE(ip_array_type)
						    IFX_MEM_FREE(pBuffer)
								    return;
							}
						} else {
							// remove firewall rule to accept packet from wan side
							IFX_SET_FIREWALL_DENY_SERVICES
							    (DELETE, IF_WAN, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1]);
							if (!gstrcmp(sNewValue[2], "0"))	//509081:tc.chen
								IFX_SET_FIREWALL_ACCEPT_SERVICES
							    (ADD, pService_Info[(i / 3) * 2], pService_Info[(i / 3) * 2 + 1], 1);
						}
					}
					// lan side setting has been changed
					if (gstrcmp(sPreValue[2], sNewValue[2]) != 0) {
						// lan side disable
						if (!gstrcmp(sNewValue[2], "0")) {
							// add firewall rule to drop packet from lan side
							IFX_SET_FIREWALL_DENY_SERVICES
							    (ADD, IF_LAN, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1]);
							if (!gstrcmp(sNewValue[0], "0"))	//509081:tc.chen
								IFX_SET_FIREWALL_ACCEPT_SERVICES
							    (DELETE, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1], 1);
						}
						// lan side enable
						else {
							// remove firewall rule to accept packet from lan side
							IFX_SET_FIREWALL_DENY_SERVICES
							    (DELETE, IF_LAN, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1]);
							IFX_SET_FIREWALL_ACCEPT_SERVICES
							    (ADD, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1], 1);
						}
					}
				}
				// lan side and wan side were disable
				else {
					// previously setting of lan side or wan side was enable.
					if (!gstrcmp(sPreValue[0], "1")
					    || !gstrcmp(sPreValue[2], "1")) {
						// previously setting of wan side were enable.
						if (!gstrcmp(sPreValue[0], "1")) {
							IFX_SET_FIREWALL_DENY_SERVICES
							    (ADD, IF_WAN, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1]);
							if (pService_Info[(i / 3) * 2] != atoi(sPreValue[1]))
							{
								IFX_SET_NAPT_REDIRECT_SERVICES(DELETE, htons(atoi(sPreValue[1])),
								     pService_Info[(i / 3) * 2 + 1], inet_addr(sLanIP), htons(pService_Info[(i / 3) * 2]));
								IFX_SET_FIREWALL_ACCEPT_SERVICES(DELETE, htons(atoi(sPreValue[1])), pService_Info[(i / 3) * 2 + 1], 1);	//509081:tc.chen
							}
						}
						// previously setting of lan side were enable.
						if (!gstrcmp(sPreValue[2], "1")) {
							IFX_SET_FIREWALL_DENY_SERVICES
							    (ADD, IF_LAN, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1]);
							IFX_SET_FIREWALL_ACCEPT_SERVICES(DELETE, htons(pService_Info[(i / 3) * 2]), pService_Info[(i / 3) * 2 + 1], 1);	//509081:tc.chen
						}
#ifdef CONFIG_FEATURE_IFX_INETD
						if (!gstrncmp("WEB", sParams[i], 3)) {
							// stop http service
							sprintf(sValue,	"(sleep 30;%s)&", pService[(i / 3) * 2 + 1]);
							system(sValue);
							//system("sleep 5;"pService[(i/3)*2+1]"&");
						} else {
							service_restart_flag = 1;
						}
#else
						// stop service
						system(pService[(i / 3) * 2 + 1]);
#endif
					}
				}
			}
			nChange = 0;
		}
	}

	// save to configure file
	ifx_SetCfgData(FILE_RC_CONF, TAG_APPLICATION_SERVER, 1, pBuffer);
	free(pBuffer);
#ifdef CONFIG_FEATURE_IPv6
	{
		extern int ifx_get_glob_IPv6();
		if(ifx_get_glob_IPv6() == 1) {
			system("/etc/rc.d/firewall6 start filter appfilter");
		}
	}
#endif
	// save setting to flash
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
#ifdef CONFIG_FEATURE_IFX_INETD
	system(SERVICE_INETD_RESTART);
#endif
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
	system(SERVICE_IGMP_RESTART);
	if (snoop_mode) {
		ifx_mapi_set_igmp_snoop_cfg(IFX_IGMPv2_SNOOPING_ENABLE, 0);
		ifx_mapi_set_igmp_router_port(6, IFX_MCAST_ROUTER_PORT_ADD, 0);
	} else {
		ifx_mapi_set_igmp_snoop_cfg(IFX_IGMPv2_SNOOPING_DISABLE, 0);
		ifx_mapi_set_igmp_router_port(6, IFX_MCAST_ROUTER_PORT_REMOVE,
					      0);
	}
#endif

	system("/usr/sbin/naptcfg --UpdateNetfilterFlag");	// 507141:tc.chen update netfilter flag to enable/disable netfilter module
      IFX_Handler:

	IFX_MEM_FREE(ip_array_type)
	    //    IFX_MEM_FREE(pBuffer)
	    websNextPage(wp);
}
#endif				// CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_FIREWALL
int ifx_get_FirewallStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	IFX_MAPI_Firewall fw;

	sValue[0] = '\0';

	memset(&fw, 0x00, sizeof(fw));

	ifx_mapi_get_firewall_status(&fw, IFX_F_DEFAULT);

	if (fw.enable)		//Enable firewall
		gstrcpy(sValue, "1");
	else
		gstrcpy(sValue, "0");

	ifx_httpdWrite(wp, T("%s"), sValue);
	return 0;
}
#endif				//CONFIG_FEATURE_FIREWALL

#ifdef CONFIG_FEATURE_FIREWALL
// firewall_disablewan.asp
int ifx_get_firewall_disablewan(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	sValue[0] = '\0';
	command[0] = '\0';
	if (!gstrcmp(name, T("DoSProtect"))) {
		gsprintf(command, T("grep \"%s\" %s | cut -f2 -d\\\""),
			 "^ENABLE_HACKER_ATTACK_PROTECT", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			if (!gstrcmp(sValue, "1"))	//Enable
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	} else if (!gstrcmp(name, T("C1"))) {
		gsprintf(command, T("grep \"%s\" %s | cut -f2 -d\\\""),
			 "^DISCARD_PING_FROM_WAN_SIDE", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			if (!gstrcmp(sValue, "1"))	//Enable
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	} else if (!gstrcmp(name, T("PingGW"))) {
		gsprintf(command, T("grep \"%s\" %s | cut -f2 -d\\\""),
			 "^ALLOW_PING_THE_GW", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			if (!gstrcmp(sValue, "1"))	//Enable
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	}
	return 0;
}

// firewall_packetfilter.asp
int ifx_get_firewall_packetfilter(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, connName[MAX_CONN_NAME_LEN];

	int i = 0, nPacketFilter_Size = 0;

	IFX_MAPI_Firewall_PF pfstatus;
	IFX_MAPI_Firewall_PFRule *pfrules = NULL;

	memset(&pfstatus, 0, sizeof(IFX_MAPI_Firewall_PF));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, T("pfStatus"))) {
		//Get PF_STATUS# value from rc.firewall file.

		ifx_mapi_get_firewall_pfstatus(&pfstatus, IFX_F_DEFAULT);
		if (pfstatus.enable)
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));

	} else if (!gstrcmp(name, T("Info"))) {

		ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,
					      IFX_F_DEFAULT);

		for (i = 0; i < nPacketFilter_Size && i < FIREW_PFILTER_NUM;
		     i++) {
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
				       i, i);
			ifx_httpdWrite(wp, T("\t\t\t<tr>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<td id=\"pfilt_no%d\">%d</td>\n"),
				       i + 1, i + 1);
			ifx_httpdWrite(wp, T("\t\t\t\t<td id=\"pfilt_sip%d\">"),
				       i + 1);

			//Source Ip
			if (pfrules[i].srcIP.ip.s_addr) {
				if (pfrules[i].srcIP.mask.s_addr) {
					ifx_httpdWrite(wp, T("%s/%d</td>\n"),
						       inet_ntoa(pfrules[i].
								 srcIP.ip),
						       netmask2bits(pfrules[i].
								    srcIP.mask.
								    s_addr));
				} else {
					ifx_httpdWrite(wp, T("%s</td>\n"),
						       inet_ntoa(pfrules[i].
								 srcIP.ip));
				}
			} else {
				ifx_httpdWrite(wp, T("*</td>\n"));
			}
			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td id=\"pfilt_sport%d\">"),
				       i + 1);

			//Source Port
			if (pfrules[i].sPortRange.start_port) {
				if (pfrules[i].sPortRange.end_port) {
					// only show PORT_START
					ifx_httpdWrite(wp, T("%d~%d</td>\n"),
						       pfrules[i].sPortRange.
						       start_port,
						       pfrules[i].sPortRange.
						       end_port);
				} else {
					// show PORT RANGE
					ifx_httpdWrite(wp, T("%d</td>\n"),
						       pfrules[i].sPortRange.
						       start_port);
				}
			} else {
				ifx_httpdWrite(wp, T("*</td>\n"));
			}
			ifx_httpdWrite(wp, T("\t\t\t\t<td id=\"pfilt_dip%d\">"),
				       i + 1);

			// show IP_DST
			if (pfrules[i].dstIP.ip.s_addr) {
				if (pfrules[i].dstIP.mask.s_addr) {
					ifx_httpdWrite(wp, T("%s/%d</td>\n"),
						       inet_ntoa(pfrules[i].
								 dstIP.ip),
						       netmask2bits(pfrules[i].
								    dstIP.mask.
								    s_addr));
				} else
					ifx_httpdWrite(wp, T("%s</td>\n"),
						       inet_ntoa(pfrules[i].
								 dstIP.ip));
			} else {
				ifx_httpdWrite(wp, T("*</td>\n"));
			}
			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td id=\"pfilt_dport%d\">"),
				       i + 1);

			// check if PORT DST_START is same as PORT DST_END
			if (pfrules[i].dPortRange.start_port) {
				if (pfrules[i].dPortRange.end_port) {
					// only show PORT_START
					ifx_httpdWrite(wp, T("%d~%d</td>\n"),
						       pfrules[i].dPortRange.
						       start_port,
						       pfrules[i].dPortRange.
						       end_port);
				} else {
					// show PORT RANGE
					ifx_httpdWrite(wp, T("%d</td>\n"),
						       pfrules[i].dPortRange.
						       start_port);
				}
			} else {
				ifx_httpdWrite(wp, T("*</td>\n"));
			}
			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td id=\"pfilt_prot%d\">"),
				       i + 1);
// Protocol type
			if (pfrules[i].protoType == PROTO_TCP) {
				ifx_httpdWrite(wp, T("TCP</td>\n"));
			} else if (pfrules[i].protoType == PROTO_UDP) {
				ifx_httpdWrite(wp, T("UDP</td>\n"));
			} else if (pfrules[i].protoType == PROTO_ICMP) {
				ifx_httpdWrite(wp, T("ICMP</td>\n"));
			} else if (pfrules[i].protoType == PROTO_ESP) {
				ifx_httpdWrite(wp, T("ESP</td>\n"));
			} else if (pfrules[i].protoType == PROTO_AH) {
				ifx_httpdWrite(wp, T("AH</td>\n"));
			} else {
				ifx_httpdWrite(wp, T("ALL</td>\n"));
			}

			// interfaces
			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td id=\"pfilt_ingint%d\">"),
				       i + 1);
			if (!strlen(pfrules[i].iif))
				ifx_httpdWrite(wp, T("%s</td>\n"),
					       pfrules[i].iif);
			else {
				memset(connName, 0x00, sizeof(connName));
				/* TBD : for all ifx_get_wan_connName_from_ifname instances below */
				if (ifx_get_wan_connName_from_ifname
				    (connName, pfrules[i].iif,
				     WAN_TYPE_IP) != IFX_SUCCESS) {
					memset(connName, 0x00,
					       sizeof(connName));
					if (ifx_get_lan_connName_from_ifname
					    (connName,
					     pfrules[i].iif) != IFX_SUCCESS) {
						ifx_httpdError(wp, 400,
							       "Failed to get connection name");
						return -1;
					}
				}
				ifx_httpdWrite(wp, T("%s</td>\n"), connName);
			}

			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td name=\"pfilt_egint%d\">"),
				       i + 1);
			if (!strlen(pfrules[i].oif))
				ifx_httpdWrite(wp, T("%s</td>\n"),
					       pfrules[i].oif);
			else {
				memset(connName, 0x00, sizeof(connName));
				if (ifx_get_wan_connName_from_ifname
				    (connName, pfrules[i].oif,
				     WAN_TYPE_IP) != IFX_SUCCESS) {
					memset(connName, 0x00,
					       sizeof(connName));
					if (ifx_get_lan_connName_from_ifname
					    (connName,
					     pfrules[i].oif) != IFX_SUCCESS) {
						ifx_httpdError(wp, 400,
							       "Failed to get connection name");
						return -1;
					}
				}
				ifx_httpdWrite(wp, T("%s</td>\n"), connName);
			}
			/*       mac address */
			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td id=\"pfilt_smac%d\">"),
				       i + 1);
			ifx_httpdWrite(wp, T("%s</td>\n"), pfrules[i].sMacAddr);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<td id=\"pfilt_en%d\"><input type=\"checkbox\" name=\"PF_F%d\" value=\"1\"%s></td>\n"),
				       i + 1, i,
				       pfrules[i].enable ? " CHECKED" : " ");
			/* ifx_httpdWrite(wp, T("\t\t\t\t<td>\n"), i,pfrules[i].enable?" CHECKED":" "); */
			ifx_httpdWrite(wp, T("\t\t\t\t</td>\n"));

			ifx_httpdWrite(wp, T("\t\t\t\t<td>\n"));

			if (i < nPacketFilter_Size) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<a href=\"#\" class=\"button\" name=\"PF_MOD%d\" value=\" Modify \" onClick=\"return modEntry(%d);\">Modify</a>\n"),
					       i, i);
				//ifx_httpdWrite(wp, T("\t\t\t\t</td>\n"));
			}
			//ifx_httpdWrite(wp, T("\t\t\t\t<td>\n"));                      

			if (i < nPacketFilter_Size) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<a href=\"#\" class=\"button\" name=\"PF_DEL%d\" value=\" Delete \" onClick=\"return delEntry(%d);\">Delete</a>\n"),
					       i, i);
			}
			ifx_httpdWrite(wp, T("\t\t\t\t</td></tr>\n"));

		}		//enf for
	}
	if (pfrules != NULL)
		IFX_MEM_FREE(pfrules);

	return 0;
}

int ifx_get_firewall_packetfilter_rule(int eid, httpd_t wp, int argc,
				       char_t ** argv)
{
	char_t connName[MAX_CONN_NAME_LEN];
	char8 *lan_conn_names = NULL, *wan_conn_names = NULL;

	int i, nIndex, nPacketFilter_Size = 0, lcount, wcount;

	IFX_MAPI_Firewall_PFRule *pfrules = NULL;

#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
	lan_port_sep_cfg_t *lps_conn_names = NULL;
	memset(&lps_conn_names, 0x00, sizeof(lps_conn_names));
	if(lan_port_sep_enable_get() == IFX_SUCCESS)
	{
		if (mapi_lan_port_sep_info_get(&lcount, &lps_conn_names, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,T("Failed to get lan port information!"));
			return -1;
		}
	}
#endif
	nIndex = atoi(natcpeId);

	if (!strcmp(natvsAction, "MODIFY_ENTRY")) {
		ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,
					      IFX_F_DEFAULT);
		if (pfrules) {
			if (nIndex < nPacketFilter_Size) {
				ifx_httpdWrite(wp,T ("\v <div align=\"center\"><table class=\"tableInput\" summary=\"\">\n"));
				ifx_httpdWrite(wp, T("    <tr>\n"));
				ifx_httpdWrite(wp, T("        <td>Protocol</td>\n"));
				ifx_httpdWrite(wp, T("        <td>\n"));
				ifx_httpdWrite(wp, T("            <select name=\"PF_TYPE_ADD\" onChange=\"ChangeEvent()\">\n"));
				if (pfrules[nIndex].protoType == PROTO_TCP)
					ifx_httpdWrite(wp, T("         <option name=\"PF_TYPE6\" value=\"6\" selected>TCP</option>\n"));
				else
					ifx_httpdWrite(wp, T("         <option name=\"PF_TYPE6\" value=\"6\">TCP</option>\n"));
				if (pfrules[nIndex].protoType == PROTO_UDP)
					ifx_httpdWrite(wp, T("         <option name=\"PF_TYPE17\" value=\"17\" selected>UDP</option>\n"));
				else
					ifx_httpdWrite(wp, T("         <option name=\"PF_TYPE17\" value=\"17\">UDP</option>\n"));
				if (pfrules[nIndex].protoType == PROTO_ICMP)
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE1\" value=\"1\" selected>ICMP</option>\n"));
				else
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE1\" value=\"1\">ICMP</option>\n"));
				if (pfrules[nIndex].protoType == PROTO_ESP)
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE51\" value=\"51\" selected>AH</option>\n"));
				else
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE51\" value=\"51\">AH</option>\n"));
				if (pfrules[nIndex].protoType == PROTO_AH)
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE50\" value=\"50\" selected>ESP</option>\n"));
				else
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE50\" value=\"50\">ESP</option>\n"));
				if (pfrules[nIndex].protoType == PROTO_ALL)
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE0\" value=\"0\" selected>ALL</option>\n"));
				else
					ifx_httpdWrite(wp, T("   <option name=\"PF_TYPE0\" value=\"0\">ALL</option>\n"));

				ifx_httpdWrite(wp, T("	   </select>\n"));
				ifx_httpdWrite(wp, T("	       </td>\n"));
				ifx_httpdWrite(wp, T("   </tr>\n"));
				ifx_httpdWrite(wp, T("   <tr>\n"));
				ifx_httpdWrite(wp, T("   <td>Source IP Type</td>\n"));
				ifx_httpdWrite(wp, T("   <td>\n"));
				ifx_httpdWrite(wp, T("	    <select name=\"PF_IP_SRC_TYPE_ADD\" onChange=\"ChangeEvent()\">\n"));
				if (pfrules[nIndex].srcType == 0)
					ifx_httpdWrite(wp, T("    <option name=\"PF_IP_SRC_TYPE*\" value=\"*\" selected>ALL</option>\n"));
				else
					ifx_httpdWrite(wp, T("    <option name=\"PF_IP_SRC_TYPE*\" value=\"*\">ALL</option>\n"));
				if (pfrules[nIndex].srcType == 1)
					ifx_httpdWrite(wp, T("    <option name=\"PF_IP_SRC_TYPE1\" value=\"1\" selected>SINGLE</option>\n"));
				else
					ifx_httpdWrite(wp, T("    <option name=\"PF_IP_SRC_TYPE1\" value=\"1\">SINGLE</option>\n"));
				if (pfrules[nIndex].srcType == 2)
					ifx_httpdWrite(wp, T("    <option name=\"PF_IP_SRC_TYPE2\" value=\"2\" selected>SUBNET</option>\n"));
				else
					ifx_httpdWrite(wp, T("    <option name=\"PF_IP_SRC_TYPE2\" value=\"2\">SUBNET</option>\n"));
				ifx_httpdWrite(wp, T("      </select>\n"));
				ifx_httpdWrite(wp, T("      </td>\n"));
				ifx_httpdWrite(wp, T("   </tr>\n"));
				ifx_httpdWrite(wp, T("<div id=\"Hidden_Src_IP\">\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("	<td>Source IP Address</td>\n"));
				ifx_httpdWrite(wp, T("  <td>\n"));
				if (pfrules[nIndex].srcIP.ip.s_addr && pfrules[nIndex].srcType != 0)
					ifx_httpdWrite(wp, T("      <input maxLength=\"15\" name=\"PF_IP_SRC_IP_ADD\" size=\"16\" value=\"%s\">\n"),
						       inet_ntoa(pfrules[nIndex].srcIP.ip));
				else
					ifx_httpdWrite(wp, T("      <input maxLength=\"15\" name=\"PF_IP_SRC_IP_ADD\" size=\"16\" value=\"\">\n"));
				ifx_httpdWrite(wp, T("  </td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));

				ifx_httpdWrite(wp, T("<div id=\"Hidden_Src_Mask\">\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("	<td>Source Netmask</td>\n"));
				ifx_httpdWrite(wp, T("	<td>\n"));
				if (pfrules[nIndex].srcIP.mask.s_addr && pfrules[nIndex].srcType == 2)
					ifx_httpdWrite(wp, T(" 	    <input maxLength=\"15\" name=\"PF_IP_SRC_MASK_ADD\" size=\"16\" value=\"%s\">\n"),
						       inet_ntoa(pfrules[nIndex].srcIP.mask));
				else
					ifx_httpdWrite(wp, T("          <input maxLength=\"15\" name=\"PF_IP_SRC_MASK_ADD\" size=\"16\" value=\"\">\n"));
				ifx_httpdWrite(wp, T("	</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));
				ifx_httpdWrite(wp, T("<div id=\"Hidden_Src_Port\">\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("<td>Source Port</td>\n"));
				ifx_httpdWrite(wp, T("<td>\n"));
				if (pfrules[nIndex].sPortRange.start_port)
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_SRC_START_ADD\" size=\"6\" value=\"%d\">~\n"),
						       pfrules[nIndex].sPortRange.start_port);
				else
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_SRC_START_ADD\" size=\"6\" value=\"\">~\n"));
				if (pfrules[nIndex].sPortRange.end_port)
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_SRC_END_ADD\" size=\"6\" value=\"%d\">\n"),
						       pfrules[nIndex].sPortRange.end_port);
				else
					ifx_httpdWrite(wp,T("<input maxLength=\"5\" name=\"PF_PORT_SRC_END_ADD\" size=\"6\" value=\"\">\n"));
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("<td>Destination IP Type</td>\n"));
				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<select name=\"PF_IP_DST_TYPE_ADD\" onChange=\"ChangeEvent()\">\n"));
				if (pfrules[nIndex].dstType == 0)
					ifx_httpdWrite(wp, T("          <option name=\"PF_IP_DST*\" value=\"*\" selected>ALL</option>\n"));
				else
					ifx_httpdWrite(wp, T("          <option name=\"PF_IP_DST*\" value=\"*\">ALL</option>\n"));
				if (pfrules[nIndex].dstType == 1)
					ifx_httpdWrite(wp, T("          <option name=\"PF_IP_DST1\" value=\"1\" selected>SINGLE</option>\n"));
				else
					ifx_httpdWrite(wp, T("          <option name=\"PF_IP_DST1\" value=\"1\">SINGLE</option>\n"));
				if (pfrules[nIndex].dstType == 2)
					ifx_httpdWrite(wp, T("          <option name=\"PF_IP_DST2\" value=\"2\" selected>SUBNET</option>\n"));
				else
					ifx_httpdWrite(wp, T("          <option name=\"PF_IP_DST2\" value=\"2\">SUBNET</option>\n"));
				ifx_httpdWrite(wp, T("              </select>\n"));
				ifx_httpdWrite(wp, T("         </td>\n"));
				ifx_httpdWrite(wp, T("   </tr>\n"));
				ifx_httpdWrite(wp, T("<div id=\"Hidden_Dst_IP\">\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("<td>Destination IP Address</td>\n"));
				ifx_httpdWrite(wp, T("<td>\n"));
				if (pfrules[nIndex].dstIP.ip.s_addr && pfrules[nIndex].dstType != 0)
					ifx_httpdWrite(wp, T("<input maxLength=\"15\" name=\"PF_IP_DST_IP_ADD\" size=\"16\" value=\"%s\">\n"),
						       inet_ntoa(pfrules[nIndex].dstIP.ip));
				else
					ifx_httpdWrite(wp, T("<input maxLength=\"15\" name=\"PF_IP_DST_IP_ADD\" size=\"16\" value=\"\">\n"));
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));
				ifx_httpdWrite(wp, T("<div id=\"Hidden_Dst_Mask\">\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("<td>Destination Netmask</td>\n"));
				ifx_httpdWrite(wp, T("<td>\n"));
				if (pfrules[nIndex].dstIP.mask.s_addr && pfrules[nIndex].dstType == 2)
					ifx_httpdWrite(wp, T("<input maxLength=\"15\" name=\"PF_IP_DST_MASK_ADD\" size=\"16\" value=\"%s\">\n"),
						       inet_ntoa(pfrules[nIndex].dstIP.mask));
				else
					ifx_httpdWrite(wp, T("<input maxLength=\"15\" name=\"PF_IP_DST_MASK_ADD\" size=\"16\" value=\"\">\n"));
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));
				ifx_httpdWrite(wp, T("<div id=\"Hidden_Dst_Port\">\n"));
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T(" <td>Destination Port</td>\n"));
				ifx_httpdWrite(wp, T(" <td>\n"));
				if (pfrules[nIndex].dPortRange.start_port)
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_DST_START_ADD\" size=\"6\" value=\"%d\">~\n"),
						       pfrules[nIndex].dPortRange.start_port);
				else
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_DST_START_ADD\" size=\"6\" value=\"\">~\n"));
				if (pfrules[nIndex].dPortRange.end_port)
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_DST_END_ADD\" size=\"6\" value=\"%d\">\n"),
						       pfrules[nIndex].dPortRange.end_port);
				else
					ifx_httpdWrite(wp, T("<input maxLength=\"5\" name=\"PF_PORT_DST_END_ADD\" size=\"6\" value=\"\">\n"));
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));

#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
				if(lan_port_sep_enable_get() == IFX_FAILURE)
					ifx_get_all_lan_conn_names(&lan_conn_names, &lcount);
#endif
				ifx_get_all_wan_conn_names(&wan_conn_names, &wcount);

				ifx_httpdWrite(wp, T("<div id=\"Hidden_Src_Interface\">\n"));
				ifx_httpdWrite(wp, T("	<tr>\n"));
				ifx_httpdWrite(wp, T("	<td>Ingress Interface</td>\n"));
				ifx_httpdWrite(wp, T("  <td>\n"));
				ifx_httpdWrite(wp, T("  <select name=\"PF_IN_IF_ADD\" size=\"1\">\n"));
				if (!strlen(pfrules[nIndex].iif)) {
					ifx_httpdWrite(wp, T("<option value=\"\"></option>\n"));
					if (lcount >= 0 && lcount < 32767) {
						for (i = 0; i < lcount; i++)
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
							if(lan_port_sep_enable_get() == IFX_SUCCESS)
								ifx_httpdWrite(wp, T("<option name=\"PF_IN_IF_%s\" value=\"%s\">%s</option>\n"),(lps_conn_names + i)->conName,(lps_conn_names + i)->conName,(lps_conn_names + i)->conName);
							else
#endif
								ifx_httpdWrite(wp, T("<option name=\"PF_IN_IF_%s\" value=\"%s\">%s</option>\n"),(lan_conn_names +(i * MAX_NAME_LEN)),(lan_conn_names +(i * MAX_NAME_LEN)),(lan_conn_names +(i * MAX_NAME_LEN)));
						for (i = 0; i < wcount; i++)
							ifx_httpdWrite(wp, T("<option name=\"PF_IN_IF_%s\" value=\"%s\">%s</option>\n"),
								       (wan_conn_names +(i * MAX_NAME_LEN)),
								       (wan_conn_names +(i * MAX_NAME_LEN)),
								       (wan_conn_names +(i * MAX_NAME_LEN)));
					}
				} else {
					memset(connName, 0x00, sizeof(connName));
					if (ifx_get_wan_connName_from_ifname (connName, pfrules[nIndex].iif, WAN_TYPE_IP) != IFX_SUCCESS) {
						memset(connName, 0x00, sizeof(connName));
						if (ifx_get_wan_connName_from_ifname (connName, pfrules[nIndex].iif, WAN_TYPE_PPP) != IFX_SUCCESS) {
							memset(connName, 0x00, sizeof(connName));
							if (ifx_get_lan_connName_from_ifname(connName, pfrules[nIndex].iif) != IFX_SUCCESS) {
		                                               if (pfrules != NULL)
			                                           IFX_MEM_FREE(pfrules);
	                	                               if (lan_conn_names != NULL)
		                	                           IFX_MEM_FREE(lan_conn_names);
	                                	               if (wan_conn_names != NULL)
		                                	           IFX_MEM_FREE(wan_conn_names);
								ifx_httpdError(wp, 400,
									       "Failed to get connection name");
								return -1;
							}
						}
					}
					if (lcount >= 0 && lcount < 32767) {
						for (i = 0; i < lcount; i++)
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
							if(lan_port_sep_enable_get() == IFX_SUCCESS){
								if (!strncmp ((lps_conn_names + i)->conName, connName, strlen(connName)))
									ifx_httpdWrite (wp, T ("<option name=\"PF_IN_IF_%s\" value=\"%s\" selected>%s</option>\n"),connName, connName, connName);
								else
									ifx_httpdWrite (wp, T ("<option name=\"PF_IN_IF_%s\" value=\"%s\">%s</option>\n"),(lps_conn_names  + i)->conName,(lps_conn_names  + i)->conName,(lps_conn_names  + i)->conName);
							}else
#endif
{
								if (!strncmp ((lan_conn_names + (i * MAX_NAME_LEN)), connName, strlen(connName)))
									ifx_httpdWrite (wp, T ("<option name=\"PF_IN_IF_%s\" value=\"%s\" selected>%s</option>\n"),connName, connName, connName);
								else
									ifx_httpdWrite (wp, T ("<option name=\"PF_IN_IF_%s\" value=\"%s\">%s</option>\n"),(lan_conn_names  + (i * MAX_NAME_LEN)),(lan_conn_names  + (i * MAX_NAME_LEN)),(lan_conn_names  + (i * MAX_NAME_LEN)));
							}
					}
					for (i = 0; i < wcount; i++)
						if (!strncmp ((wan_conn_names + (i * MAX_NAME_LEN)), connName, strlen(connName)))
							ifx_httpdWrite(wp, T ("<option name=\"PF_IN_IF_%s\" value=\"%s\" selected>%s</option>\n"),
								connName, connName, connName);
						else
							ifx_httpdWrite(wp, T ("<option name=\"PF_IN_IF_%s\" value=\"%s\">%s</option>\n"),
								       (wan_conn_names +(i * MAX_NAME_LEN)),
								       (wan_conn_names +(i * MAX_NAME_LEN)),
								       (wan_conn_names +(i * MAX_NAME_LEN)));    //modified to MAX_NAME_LEN

				}
				ifx_httpdWrite(wp, T("  </select>\n"));
				ifx_httpdWrite(wp, T("  </td>\n"));
				ifx_httpdWrite(wp, T("  </tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));
				ifx_httpdWrite(wp, T("<div id=\"Hidden_Dst_Interface\">\n"));
				ifx_httpdWrite(wp, T("	<tr>\n"));
				ifx_httpdWrite(wp, T(" <td>Egress Interface</td>\n"));
				ifx_httpdWrite(wp, T("	<td name=\"pf_mod_eg_if\">\n"));
				ifx_httpdWrite(wp, T("	<select name=\"PF_OUT_IF_ADD\" size=\"1\">\n"));
				if (!strlen(pfrules[nIndex].oif)) {
					ifx_httpdWrite(wp, T("<option value=\"\"></option>\n"));
					for (i = 0; i < lcount; i++)
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
						if(lan_port_sep_enable_get() == IFX_SUCCESS)
							ifx_httpdWrite(wp, T("<option name=\"PF_OUT_IF_%s\" value=\"%s\">%s</option>\n"),(lps_conn_names + i)->conName,(lps_conn_names + i)->conName,(lps_conn_names + i)->conName);
						else
#endif
							ifx_httpdWrite(wp, T("<option name=\"PF_OUT_IF_%s\" value=\"%s\">%s</option>\n"),(lan_conn_names + (i * MAX_NAME_LEN)),(lan_conn_names + (i * MAX_NAME_LEN)),(lan_conn_names + (i * MAX_NAME_LEN)));
					for (i = 0; i < wcount; i++)
						ifx_httpdWrite(wp, T("<option name=\"PF_OUT_IF_%s\" value=\"%s\">%s</option>\n"),
							(wan_conn_names + (i * MAX_NAME_LEN)),
							(wan_conn_names + (i * MAX_NAME_LEN)),
							(wan_conn_names + (i * MAX_NAME_LEN)));
				} else {
					memset(connName, 0x00, sizeof(connName));
					if (ifx_get_wan_connName_from_ifname(connName, pfrules[nIndex].oif, WAN_TYPE_IP) != IFX_SUCCESS) {
						memset(connName, 0x00, sizeof(connName));
						if (ifx_get_wan_connName_from_ifname(connName, pfrules[nIndex].oif, WAN_TYPE_PPP) != IFX_SUCCESS) {
							memset(connName, 0x00, sizeof(connName));
							if (ifx_get_lan_connName_from_ifname(connName, pfrules[nIndex].oif) != IFX_SUCCESS) {
	        	                                      if (pfrules != NULL)
		        	                                 IFX_MEM_FREE(pfrules);
	                        	                      if (lan_conn_names != NULL)
		                        	                 IFX_MEM_FREE(lan_conn_names);
	                                        	      if (wan_conn_names != NULL)
		                                        	 IFX_MEM_FREE(wan_conn_names);
							      ifx_httpdError(wp, 400,
									       "Failed to get connection name");
								return -1;
							}
						}
					}
					for (i = 0; i < lcount; i++)
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
						if(lan_port_sep_enable_get() == IFX_SUCCESS){
							if (!strncmp((lps_conn_names + i)->conName, connName, strlen(connName)))
								ifx_httpdWrite(wp, T ("<option name=\"PF_OUT_IF_%s\" value=\"%s\" selected>%s</option>\n"),connName, connName, connName);
							else
								ifx_httpdWrite(wp, T ("<option name=\"PF_OUT_IF_%s\" value=\"%s\">%s</option>\n"),(lps_conn_names + i)->conName,(lps_conn_names + i)->conName,(lps_conn_names + i)->conName);
						}else
#endif
{
							if (!strncmp((lan_conn_names + (i * MAX_NAME_LEN)), connName, strlen(connName)))
								ifx_httpdWrite(wp, T ("<option name=\"PF_OUT_IF_%s\" value=\"%s\" selected>%s</option>\n"),connName, connName, connName);
							else
								ifx_httpdWrite(wp, T ("<option name=\"PF_OUT_IF_%s\" value=\"%s\">%s</option>\n"),(lan_conn_names + (i * MAX_NAME_LEN)),(lan_conn_names + (i * MAX_NAME_LEN)),(lan_conn_names + (i * MAX_NAME_LEN)));
						}
					for (i = 0; i < wcount; i++)
						if (!strncmp((wan_conn_names + (i * MAX_NAME_LEN)), connName, strlen(connName)))
							ifx_httpdWrite(wp, T ("<option name=\"PF_OUT_IF_%s\" value=\"%s\" selected>%s</option>\n"),
								(wan_conn_names + (i * MAX_NAME_LEN)),
								(wan_conn_names + (i * MAX_NAME_LEN)),
								(wan_conn_names + (i * MAX_NAME_LEN)));
						else
							ifx_httpdWrite(wp, T("<option name=\"PF_OUT_IF_%s\" value=\"%s\">%s</option>\n"),
								(wan_conn_names + (i * MAX_NAME_LEN)),
								(wan_conn_names + (i * MAX_NAME_LEN)),
								(wan_conn_names + (i * MAX_NAME_LEN)));

				}
				ifx_httpdWrite(wp, T("	</select>\n"));
				ifx_httpdWrite(wp, T("	</td>\n"));
				ifx_httpdWrite(wp, T("	</tr>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));

				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("  <td>Source MAC Address</td>\n"));
				ifx_httpdWrite(wp, T("  <td name=\"pf_mod_smac\">\n"));
				if (!strlen(pfrules[nIndex].sMacAddr))
					ifx_httpdWrite(wp, T("     <input maxlength=\"17\" name=\"PF_MAC_ADD\" value=\"\">\n"));
				else
					ifx_httpdWrite(wp, T("     <input maxlength=\"17\" name=\"PF_MAC_ADD\" value=\"%s\">\n"),
						       pfrules[nIndex].sMacAddr);
				ifx_httpdWrite(wp, T(" </td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));

				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("<td>Enable</td>\n"));
				ifx_httpdWrite(wp, T("<td name=\"pf_mod_en\">\n"));
				if (pfrules[nIndex].enable)
					ifx_httpdWrite(wp, T("<input type=\"checkbox\" name=\"PF_F_ADD\" value=\"1\" CHECKED>\n"));
				else
					ifx_httpdWrite(wp, T("<input type=\"checkbox\" name=\"PF_F_ADD\" value=\"1\">\n"));

				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</table>\n"));

				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
				ifx_httpdWrite(wp, T("</table>\n"));
				ifx_httpdWrite(wp, T("</div>\n"));

				/*    ifx_httpdWrite(wp, T("<tr>\n"));
				   ifx_httpdWrite(wp, T("<td valign=\"top\" height=\"2\">\n"));
				   ifx_httpdWrite(wp, T("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n"));
				   ifx_httpdWrite(wp, T("<tr>\n"));
				   ifx_httpdWrite(wp, T("<td>\n")); */
				ifx_httpdWrite(wp, T("<br/><br/><div align=\"right\">\n"));
				ifx_httpdWrite(wp, T("<a class=\"button\" href=\"javascript:void(0);\" onClick=\"window.open('help.htm#filter','help','toolbar=0,status=0,menubar=0,scrollbars=1,resizable=1,width=530,height=400,left=150,top=150');\">"));
				ifx_httpdWrite(wp, T("Help</a>\n"));
				ifx_httpdWrite(wp, T("<a class=\"button\" href=\"javascript:document.forms[0].submit()\" onClick=\"return evaltF(%d);\">"),nIndex);
				ifx_httpdWrite(wp, T("Apply</a>\n"));
				ifx_httpdWrite(wp, T("<a class=\"button\" href=\"javascript:document.tF0.reset()\">"));
				ifx_httpdWrite(wp, T("Cancel</a>\n"));

				ifx_httpdWrite(wp, T("</div>\n"));
				/* ifx_httpdWrite(wp, T("</td>\n"));
				   ifx_httpdWrite(wp, T("</tr>\n"));
				   ifx_httpdWrite(wp, T("</table>\n"));
				   ifx_httpdWrite(wp, T("</td>\n"));
				   ifx_httpdWrite(wp, T("</tr>\n")); */

			}
		}
	}

	if (pfrules != NULL)
		IFX_MEM_FREE(pfrules);
	if (lan_conn_names != NULL)
		IFX_MEM_FREE(lan_conn_names);
	if (wan_conn_names != NULL)
		IFX_MEM_FREE(wan_conn_names);

	return 0;
}

#endif				//CONFIG_FEATURE_FIREWALL

#ifdef CONFIG_FEATURE_FIREWALL
//firewall_mac.asp
int ifx_get_MacControl(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_DATA_LEN];
	sValue[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_FIREWALLMAC_STAT, T("MAC_control"),
	     sValue) == 0) {
		ifx_httpdError(wp, 500, "MAC_control not found");
		return -1;
	}
	if (sValue[0] == name[0])
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
	return 0;
}

//604041:sumedh - Parental Control (modified MAC Filter) get API
int ifx_get_mac_filter_rules(httpd_t wp, int *num, struct mac_filter **MF)
{
	char_t sCommand[MAX_DATA_LEN], sValue[MAX_DATA_LEN];
	int nIndex = 0;

	gsprintf(sCommand, T("%sCount"), PREFIX_FIREWALL_PC);
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_FIREWALLMAC, sCommand, sValue) ==
	    0) {
		ifx_httpdError(wp, 500, T("Cannot read COUNT"));
		return -1;
	}
	//   *num=0;
	*num = gatoi(sValue);
	if (*num >= 0 && *num < 32767)
		*MF =
		    (struct mac_filter *)calloc(*num,
						sizeof(struct mac_filter));
	if (*MF == NULL) {
		ifx_httpdError(wp, 500, T("Cannot CALLOC %d rules"), num);
		return -1;	//IFX_FAIL
	}

	for (nIndex = 0; nIndex < *num; nIndex++) {
		// Get MAC Status
		gsprintf(sCommand,
			 T("grep \"^%sSTATUS%d\" %s | cut -f2 -d'\"'"),
			 PREFIX_FIREWALL_PC, nIndex, FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) sCommand, NULL, "1", sValue) == 0) {
			ifx_httpdError(wp, 500, T("Cannot read STATUS %s"),
				       nIndex);
			free(*MF);
			return -1;
		}
		(*MF + nIndex)->state = atoi(sValue);
		// Get MAC Address
		gsprintf(sCommand,
			 T("grep \"^%sMACADDR%d\" %s | cut -f2 -d'\"'"),
			 PREFIX_FIREWALL_PC, nIndex, FILE_RC_CONF);
		if (ifx_GetCfgData
		    ((char_t *) sCommand, NULL, "1",
		     (*MF + nIndex)->mac_addr) == 0) {
			ifx_httpdError(wp, 500, T("Cannot read MAC ADDR %s"),
				       nIndex);
			free(*MF);
			return -1;
		}
		// Get Day selection
		gsprintf(sCommand,
			 T("grep \"^%sDAYSELECTION%d\" %s | cut -f2 -d'\"'"),
			 PREFIX_FIREWALL_PC, nIndex, FILE_RC_CONF);
		if (ifx_GetCfgData
		    ((char_t *) sCommand, NULL, "1",
		     (*MF + nIndex)->day_selection) == 0) {
			ifx_httpdError(wp, 500, T("Cannot read DAY SEL %s"),
				       nIndex);
			free(*MF);
			return -1;
		}
		// Get Start time
		gsprintf(sCommand,
			 T("grep \"^%sTIMESTART%d\" %s | cut -f2 -d'\"'"),
			 PREFIX_FIREWALL_PC, nIndex, FILE_RC_CONF);
		if (ifx_GetCfgData
		    ((char_t *) sCommand, NULL, "1",
		     (*MF + nIndex)->time_start) == 0) {
			ifx_httpdError(wp, 500, T("Cannot read TIME START %s"),
				       nIndex);
			free(*MF);
			return -1;
		}
		// Get End time
		gsprintf(sCommand,
			 T("grep \"^%sTIMEEND%d\" %s | cut -f2 -d'\"'"),
			 PREFIX_FIREWALL_PC, nIndex, FILE_RC_CONF);
		if (ifx_GetCfgData
		    ((char_t *) sCommand, NULL, "1",
		     (*MF + nIndex)->time_end) == 0) {
			ifx_httpdError(wp, 500, T("Cannot read TIME END %s"),
				       nIndex);
			free(*MF);
			return -1;
		}
	}
	return 0;
}

int ifx_get_MacFilter(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int nCount, nIndex;
	struct mac_filter *MF = NULL;

	//FIXME (sumedh):The following is a API call. This api is currently defined in this file itself.
	if (ifx_get_mac_filter_rules(wp, &nCount, &MF) == -1) {
		ifx_httpdError(wp, 500, T("Cannot read data"));
	}
	if (MF && nCount > 0 && nCount < 32767) {
		for (nIndex = 0; nIndex < nCount; nIndex++) {
			// Print Html file
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
				       nIndex, nIndex);
			ifx_httpdWrite(wp, T("<tr align=\"center\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"pc_policy%d\" width=\"5%%\"><select name=\"addconnect%d\" size=\"1\">\n"),
				       nIndex, nIndex);
			ifx_httpdWrite(wp,
				       "<option name=\"pc_policy%d_0\" value=\"0\" %s>Disable</option>\n",
				       nIndex,
				       MF[nIndex].state ==
				       0 ? "selected" : " ");
			ifx_httpdWrite(wp,
				       "<option name=\"pc_policy%d_1\" value=\"1\" %s>Deny</option>\n",
				       nIndex,
				       MF[nIndex].state ==
				       1 ? "selected" : " ");
			ifx_httpdWrite(wp,
				       "<option name=\"pc_policy%d_2\" value=\"2\" %s>Permit</option>\n",
				       nIndex,
				       MF[nIndex].state ==
				       2 ? "selected" : " ");
			ifx_httpdWrite(wp, "</select></td>\n");

			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"pc_mac%d\"width=\"45%%\">%s</td>"),
				       nIndex, MF[nIndex].mac_addr);

			if (strncmp
			    (MF[nIndex].day_selection, "xxxxxxx",
			     sizeof(MF[nIndex].day_selection))) {
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Mon\" name=\"Mon\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[0] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Tue\" name=\"Tue\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[1] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Wed\" name=\"Wed\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[2] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Thu\" name=\"Thu\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[3] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Fri\" name=\"Fri\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[4] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Sat\" name=\"Sat\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[5] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"5%\"><input type=\"checkbox\" id=\"Sun\" name=\"Sun\" size=\"1\" value=\"\" %s disabled=\"true\"></td>"),
					       MF[nIndex].day_selection[6] ==
					       '1' ? "checked" : "");
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"start_time%d\" width=\"5%\">%s</td>"),
					       nIndex, MF[nIndex].time_start);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"end_time%d\" width=\"5%\">%s</td>"),
					       nIndex, MF[nIndex].time_end);
			} else {
				//Sumedh : the case when all days, all times are considered
				ifx_httpdWrite(wp,
					       T
					       ("<td></td> <td></td> <td></td> <td></td>"));
				ifx_httpdWrite(wp, T("<td>"));
				ifx_httpdWrite(wp,
					       T("Rule Applicable 24x7</td>"));
				ifx_httpdWrite(wp,
					       T
					       ("<td></td> <td></td> <td></td> <td></td>"));
			}

			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"5%%\"><a href=\"#\" class=\"button\" name=\"relname\" value=\" Delete\" onClick=\"macrelease(%d);\">Delete</a></td>\n"),
				       nIndex);
			ifx_httpdWrite(wp, T("</tr>\n"));
		}
	}
        if ( MF )
	    free(MF);
	return 0;
}

int ifx_get_MacFilter_modified(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int nCount, nIndex;
	struct mac_filter *MF = NULL;
	if (ifx_get_mac_filter_rules(wp, &nCount, &MF) == -1) {
		ifx_httpdError(wp, 500, T("Cannot read data"));
	}
	if (MF && nCount > 0 && nCount < 32767) {
		for (nIndex = 0; nIndex < nCount; nIndex++) {
			// Print Html file
			ifx_httpdWrite(wp,
				       T
				       ("<tr align=\"center\" bgcolor=\"#ffffff\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"5%%\"><select name=\"addconnect%d\" size=\"1\">\n"),
				       nIndex);
			ifx_httpdWrite(wp,
				       "<option value=\"0\" %s>Disable</option>\n",
				       MF[nIndex].state ==
				       0 ? "selected" : " ");
			ifx_httpdWrite(wp,
				       "<option value=\"1\" %s>Deny</option>\n",
				       MF[nIndex].state ==
				       1 ? "selected" : " ");
			ifx_httpdWrite(wp,
				       "<option value=\"2\" %s>Permit</option>\n",
				       MF[nIndex].state ==
				       2 ? "selected" : " ");
			ifx_httpdWrite(wp, "</select></td>\n");

			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"45%%\"><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%s</font></td>"),
				       MF[nIndex].mac_addr);
			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"5%%\"><center><input type=\"button\" name=\"relname\" value=\"Delete\" onClick=\"macrelease(%d);\"></center></td>\n"),
				       nIndex);
			ifx_httpdWrite(wp, T("</tr>\n"));
		}
//		free(MF);
	}
        if (MF)
            free(MF);
	return 0;
}
#endif				//CONFIG_FEATURE_FIREWALL

#ifdef CONFIG_FEATURE_NAPT

// napt_algs.asp
int ifx_get_apps_setting(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
//	char_t command[MAX_FILELINE_LEN];
	char_t *name;
	sValue[0] = '\0';
//	command[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	/*manohar: code change for getting remote port and remote enable from rc.conf*/
	if(!strcmp(name,"HTTPS_WEB_WAN_PORT"))
	{
		remote_access_t rt_access;
		if(mapi_remote_access_details_get(&rt_access,IFX_F_DEFAULT) != IFX_SUCCESS)
		{
			IFX_DBG("[%s][%d] Failed to get remote access parameter",__FUNCTION__,__LINE__);
			return -1;
		}
		ifx_httpdWrite(wp,T("%d"),rt_access.port);
		return 0;
	}
	if(!strcmp(name,"HTTPS_WEB_WAN_ENABLE"))
	{
		remote_access_t rt_access;
		if(mapi_remote_access_details_get(&rt_access,IFX_F_DEFAULT) != IFX_SUCCESS)
		{
			IFX_DBG("[%s][%d] Failed to get remote access parameter",__FUNCTION__,__LINE__);
			return -1;
		}
		if(rt_access.f_enable == 1)
			ifx_httpdWrite(wp,T("%s"),"checked");
		else	
			ifx_httpdWrite(wp,T("%s"),"");
		return 0;
	}
	/*manohar: end*/
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_APPLICATION_SERVER, name, sValue)
	    == 1) {
		if (strstr(name, "PORT")) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "IGMP_ENABLE")) {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, "checked");
			else
				ifx_httpdWrite(wp, "");
		} else if (!gstrcmp(name, "IGMP_MODE")) {
			ifx_httpdWrite(wp, sValue);
		} else if (!gstrcmp(name, "IGMP_LEAVE_LATENCY_ENABLE")) {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, "checked");
			else
				ifx_httpdWrite(wp, "");
		} else if (!gstrcmp(name, "IGMP_MAXRESPTIME")) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		} else {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, "checked");
			else
				ifx_httpdWrite(wp, "");
		}
	}

	return 0;
}
#endif				// CONFIG_FEATURE_NAPT

int ifx_get_AppFilter(int eid, httpd_t wp, int argc, char **argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t sParams[][32] = {
		"APP_FILTER",
		"APP_FILTER_MSN",
		"APP_FILTER_YAHOO"
	};
	int i = 0;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	sValue[0] = '\0';
	for (i = 0; i < sizeof(sParams) / (32 * sizeof(char_t)); i++) {
		if (!gstrcmp(name, sParams[i])) {
			IFX_WRITE_CHECKBOX_STATUS(TAG_APP_FILTER, sParams[i],
						  sValue)
		}
	}
	return 0;
}

void ifx_set_servers_acl(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck, sCheck[MAX_FILELINE_LEN];
	char_t *pIP;
	char_t sValue[MAX_FILELINE_LEN];
	char_t sBuf[BUF_SIZE_1K];
	int i = 0, c = 0;
	int count = 0;
	IP_MASK_TYPE *ip_array_type;
	uint32 flags = IFX_F_DEFAULT;
/*manohar: get global firewall enable/disable value*/
	IFX_MAPI_Firewall fw;
	memset(&fw, 0x00, sizeof(fw));
	ifx_mapi_get_firewall_status(&fw, IFX_F_DEFAULT);
/*manohar end*/

	a_assert(wp);
	memset(sCheck, 0x00, sizeof(sCheck));

	// Get value from ASP filz
	pCheck = ifx_httpdGetVar(wp, T("SERVERS_ACL_ENABLE"), T(""));

	if (!gstrcmp(pCheck, "1")) {
		sprintf(sBuf, "SERVERS_ACL_ENABLE=\"1\"\n");
	} else {
		sprintf(sBuf, "SERVERS_ACL_ENABLE=\"0\"\n");
	}

	ifx_get_lan_ip_mask("br0", &count, &ip_array_type, flags);
	//ifx_httpdWrite(wp, T("count=%d "),count);
	//ifx_httpdWrite(wp, T("ip=%s "), inet_ntoa(ip_array_type->ip_mask.ip));

	for (i = 0; i < 16; i++) {
		gsprintf(sValue, T("SERVERS_ACL%d"), i);
		pIP = ifx_httpdGetVar(wp, sValue, T(""));

		if (pIP[0]) {
			/* check ip address is same as interfaces ip address */
			for (c = 0; c < count; c++) {
				if ((ip_array_type)
				    &&
				    (strcmp
				     (pIP,
				      inet_ntoa((ip_array_type +
						 c)->ip_mask.ip)) == 0)) {
					/* Error */
					ifx_httpdError(wp, 500,
						       "Failed to configure. IP address is same as device IP address.");
					IFX_MEM_FREE(ip_array_type)
					    return;
				}
			}

			sprintf(sValue, "SERVERS_ACL%d=\"%s\"\n", i, pIP);
		} else {
			sprintf(sValue, "SERVERS_ACL%d=\"0\"\n", i);
		}
		strcat(sBuf, sValue);
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_SERVERS_ACL, 1, sBuf);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		IFX_MEM_FREE(ip_array_type)
		    return;
	}

	if (fw.enable)		//Enable firewall
	{
		system("naptcfg --ServicesACLinit");
		if (!gstrcmp(pCheck, "1"))
			system("naptcfg --ServicesACL 1");
		else
			system("naptcfg --ServicesACL 0");
	}

	IFX_MEM_FREE(ip_array_type)
	    websNextPage(wp);

}
int ifx_get_servers_acl(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	int i = 0;
	char_t sCFG_NAME[MAX_DATA_LEN];
	char_t sValue[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!strcmp(name, "acl_enable")) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SERVERS_ACL, "SERVERS_ACL_ENABLE",
		     sValue) == 1) {
			if (!strcmp(sValue, "1"))
				ifx_httpdWrite(wp, T("1"));
			else
				ifx_httpdWrite(wp, T("0"));

		} else
			ifx_httpdWrite(wp, T("0"));
	} else if (!strcmp(name, "acl_lists")) {

		for (i = 0; i < 16; i++) {
			ifx_httpdWrite(wp,
				       T("<tr align=\"center\"><td>%d</td>"),
				       i + 1);
			sprintf(sCFG_NAME, "SERVERS_ACL%d", i);
			ifx_httpdWrite(wp,
				       T
				       ("<td><input type=\"text\" size=16 maxlength=15 name=\"SERVERS_ACL%d\" value=\""),
				       i);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_SERVERS_ACL, sCFG_NAME,
			     sValue) == 1)
				if (strcmp(sValue, "0"))
					ifx_httpdWrite(wp,
						       T("%s\"</td></tr>\n"),
						       sValue);
				else
					ifx_httpdWrite(wp, T("\"</td></tr>\n"));
			else
				ifx_httpdWrite(wp, T("\"</td></tr>\n"));
		}
	}

	return 0;
}

void foo(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
	ifx_httpdWrite(wp, T("%d"), 1);
#else
	ifx_httpdWrite(wp, T("%d"), 0);
#endif
}

#if defined (CONFIG_FEATURE_NAPT) && (CONFIG_FEATURE_FIREWALL)
/************************************************************************/
/* function to check the port is already used by some other application */
/* Parses /proc/net/tcp or /proc/net/udp to read all the local ports*/
/************************************************************************/
static int portExists(int port, int type)
{
	FILE *fp;
	int count = 0, i = 0, state = 0;
	char buf[5], c, scmd[24];

	if (type == PROTO_TCP)
		strcpy(scmd, "cat /proc/net/tcp \n");
	else if (type == PROTO_UDP)
		strcpy(scmd, "cat /proc/net/udp \n");

	fp = popen(scmd, "r");
	while (fp) {
		c = fgetc(fp);
		switch (c) {
		case ':':
			if (state == 1)
				state = 2;
			else if (state == 0)
				state = 1;
			break;
		case '\n':
		case EOF:
			if (state == 3) {
				buf[i] = '\0';
				count++;
				if (port == strtol(buf, NULL, 16)) {
					state = 5;
					goto finish;
				}
			}
			i = 0;
			state = 0;
			break;
		default:
			if (state == 2) {
				if ((c >= '0' && c <= '9')
				    || (c >= 'A' && c <= 'F'))
					buf[i++] = c;
				else
					state = 3;
			}
		}
		if (c == EOF)
			break;
	}

      finish:
	if (fp != NULL)
		pclose(fp);
	if (state == 5)
		return 1;
	else
		return 0;
}

#ifdef CONFIG_FEATURE_URL_FILTERING
int ifx_get_url_entry(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	int i = 0, j = 1, num_entries = 0;

	uint32 flags = IFX_F_DEFAULT;
	url_filter_cfg_t *url_filcfg = NULL;
	memset(&url_filcfg, 0x00, sizeof(url_filcfg));

	if (mapi_get_all_url_entries(&num_entries, &url_filcfg, flags) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to get all url entries !!");
		IFX_MEM_FREE(url_filcfg);
		return -1;
	}

	if (num_entries != 0) {

		for (i = 0; i < num_entries; i++) {
				
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp, T("<td id=\'url_num%d\'>%d\n"),(url_filcfg + i)->iid.cpeId.Id,j);
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("<td id=\'url_entry%d\'>%s\n"),(url_filcfg + i)->iid.cpeId.Id,(url_filcfg + i)->URLName);
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("<td>\n"));
                               	ifx_httpdWrite(wp, T("<input type='checkbox' name='remove%d' value='1'>\n"),(url_filcfg + i)->iid.cpeId.Id);
                                ifx_httpdWrite(wp, T("</td>\n"));
				j++;
			}
		}
	else {
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
			       T("<td colspan='3'>Nothing is blocked </td>"));
		ifx_httpdWrite(wp, T("</tr>"));
	}

//	IFX_MEM_FREE(url_fil);
	return IFX_SUCCESS;
}

void ifx_set_url_entry(httpd_t wp, char_t * path, char_t * query)
{
	char_t *url_entry = NULL;
	char_t *pSubmit_Action = NULL;
	char_t *remove_num = NULL;
	char_t remove[15];
	int32 ret = IFX_SUCCESS, operation = IFX_F_DEFAULT, count = 0, i = 0;
	url_filter_cfg_t url_cfg, *urlArr = NULL;
	uint32 flags = IFX_F_DEFAULT;

	memset(&url_cfg, 0x00, sizeof(url_cfg));
	pSubmit_Action = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!gstrcmp(pSubmit_Action, T("addURL"))) {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;

		url_entry = ifx_httpdGetVar(wp, T("domain_name"), T(""));
		strncpy(url_cfg.URLName, url_entry, strlen(url_entry));

		ret = mapi_set_url_entry(operation, &url_cfg, flags);
		if ((ret != IFX_SUCCESS) && (ret == IFX_DUPLICATE_ENTRY)) {
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		} else if (ret != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to set url entry !!"));
			return;
		}

	} 
	else if (!gstrcmp(pSubmit_Action, T("delURL"))) {
		operation = IFX_OP_DEL;

		flags = IFX_F_DEFAULT;

		if (mapi_get_all_url_entries(&count, &urlArr, flags) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       ("Failed to get URL entries!"));
			IFX_MEM_FREE(urlArr);
			return;
		}

		flags = IFX_F_DELETE;
		for (i = 0; i < count; i++) {
				// Option set to Delete a particular Ethernet Channel 
				snprintf(remove, sizeof(remove), "remove%d",
					 (urlArr + i)->iid.cpeId.Id);
				remove_num = NULL;
				remove_num =
				    ifx_httpdGetVar(wp, T(remove), T(""));
				if (remove_num != NULL && !strcmp(remove_num, "1")) {
					if (mapi_set_url_entry
					    (operation, (urlArr + i),
					     flags) != IFX_SUCCESS) {
						ifx_httpdError(wp, 500,
							       T
							       ("Error deleting URL channel entry  !!"));
						goto IFX_Handler;
					}

					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
				}

		}

	}
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

IFX_Handler:
	IFX_MEM_FREE(urlArr);

	websNextPage(wp);

}
#endif

#endif				//(CONFIG_FEATURE_NAPT) && (CONFIG_FEATURE_FIREWALL)
