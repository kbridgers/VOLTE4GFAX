#ifndef _LTQ_CGI_WLAN_H
#define _LTQ_CGI_WLAN_H

extern int ifx_get_version_info(struct ifx_version_info *);

extern IFX_MAPI_WLAN_PhyCfg g_wlPhy[];
extern IFX_MAPI_WLAN_Capability g_wlCaps[];
extern IFX_MAPI_WLAN_SecCfg g_wlSec[];

extern int g_flagConfigLoaded;
extern int g_flagPhyConfig;
extern int g_flagWpsConfigured;

extern int g_idx;
extern int gNumEntries;

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
extern int gNumVapRadio1;
extern int gNumVapRadio2;
#endif				/* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */

extern IFX_MAPI_WLAN_MAC_Control g_wlMacControl[][LTQ_MAX_NUM_MAC_FILTER_ENTRIES];
extern int gMacCount[];

#define LTQ_MAX_NUM_WPS_EP_MAC	16
extern LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg g_wlWpsEpMacTable[][LTQ_MAX_NUM_WPS_EP_MAC];
extern int gWpsEpMacCount[];

#if defined (CONFIG_LTQ_AEI_CUST)
extern IFX_MAPI_WLAN_Standard gOpMode;
#endif /* #if defined (CONFIG_LTQ_AEI_CUST) */

extern char8 wlan_11b_rates [][32];
extern char8 wlan_11a_rates [][32];
extern char8 wlan_11g_rates [][32];
extern char8 wlan_11n_20_rates [][32];
extern char8 wlan_11n_20_low_rates [][32];
extern char8 wlan_11n_40_rates [][32];
extern char8 wlan_11n_40_low_rates [][32];

#undef FIX_JIRA_WAVE300_SW_2384

extern int32	g_2040CoexRadio1;
extern int32	g_2040CoexRadio2;

#ifndef WEBS_MAX_URL
#define WEBS_MAX_URL 256
#endif
#endif				/* _LTQ_CGI_WLAN_H */
