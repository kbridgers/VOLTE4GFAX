/**************************************************************************
 **   SRC_FILE          : IFX_DECT_Agent.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#ifndef __LTQ_CVOIP_MSGHDLR_H__
#define __LTQ_CVOIP_MSGHDLR_H__
e_IFX_Return LTQ_CVOIP_SendMsg(char *pcMsg, int iLen);

e_IFX_Return LTQ_CVOIP_Init();

e_IFX_Return LTQ_CVOIP_MsgRouterFdHdlr(IN int32 iFd);

e_IFX_Return LTQ_CVOIP_ProcessATCmd(uchar8 *pucATCmd);
#endif
