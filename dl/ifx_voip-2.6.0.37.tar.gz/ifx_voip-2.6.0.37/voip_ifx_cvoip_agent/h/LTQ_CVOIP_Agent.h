
/**************************************************************************
 **   SRC_FILE          : IFX_DECT_Agent.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#ifndef __IFX_DECT_AGENT_H__
#define __IFX_DECT_AGENT_H__

/*! \brief This constant defines maximum codecs supported on DECT system.
 */
#define IFX_DECT_MAX_CODEC	3

/*! \brief This enum defines events for DECT FSM. Note that these enums are 
	         events used in DECT FSM.
 */
/* Definitions for DECT NG */
#define IFX_DECTNG_CODEC_G726_32    0x02
#define IFX_DECTNG_CODEC_G722_64    0x03
#define IFX_DECTNG_CODEC_G711_A     0x04
#define IFX_DECTNG_CODEC_G711_U     0x05
#define IFX_DECTNG_CODEC_G729_32    0x06

typedef enum {
	IFX_DECT_EVT_PP_OffHook,	      /** Off-hook -- Setup from PP */
	IFX_DECT_EVT_PP_DigitReceived,	        /** Digit Received */
	IFX_DECT_EVT_IncomingCall,	/** Incoming call */
	IFX_DECT_EVT_RmtAccept,    	/** Remote accepted call */
	IFX_DECT_EVT_RmtAnswer,    	/** Remote answered call */
	IFX_DECT_EVT_RmtReleaseCall,  	/** Release call */
	IFX_DECT_EVT_RmtHold,			 	/** Remote held call */
	IFX_DECT_EVT_RmtResume,    	/** Remote resumed call */
	IFX_DECT_EVT_CallAccept,    	/**  accepted call */
	IFX_DECT_EVT_CallAnswer,    	/**  answered call */
	IFX_DECT_EVT_CallRelease,  	/** Release call */
	/* Paging key events */
	IFX_DECT_EVT_Paging,	      /** Paging button pressed */
	IFX_DECT_EVT_Attached,	      /** Handset is attached */
	IFX_DECT_EventMax
}e_IFX_DECT_Event;

/*! \brief This enum defines DECT FSM states */
typedef enum {
	IFX_DECT_STATE_IDLE,	           /** Idle*/
	IFX_DECT_STATE_PROGRESS,	         /** Call Progress */
	IFX_DECT_STATE_ACTIVE,	         /** Call active/in conversation */
	IFX_DECT_STATE_MAX
}e_IFX_DECT_States;

typedef enum {
	IFX_DECT_CS_NONE,
	IFX_DECT_CS_INITIATED,
	IFX_DECT_CS_RINGING,
	IFX_DECT_CS_ACTIVE,
	IFX_DECT_CS_HELD,
	IFX_DECT_CS_HOLD_INITIATED,
	IFX_DECT_CS_TX_INITIATED,
	IFX_DECT_CS_RESUME_INITIATED,
  IFX_DECT_CS_BUSY
}e_IFX_DECT_CallStates;

/*! \brief structure to store Call information for DECT endpoint */
typedef struct
{
	uint32 uiCallId;/** Call Id */
	e_IFX_CMGR_CallType eCallType; /** Type of call */
	e_IFX_DECT_CallStates eState; /** Call state */
	/** Call initiator's EndpointId id */
	char8  szCallInitrEndptId[IFX_MAX_ENDPOINTID_LEN];
	/** This is used to store negotiated codec */
	e_IFX_MMGR_CodecType eNegCodec;

#ifdef CAT_IQ2_0
	uint32 uiDTkCallId; /** DectToolkit CallId */
#endif
  uchar8 ucLineId; /** Line Id for the Call*/

}x_IFX_DECT_CallInfo;


/*! \enum e_IFX_DECT_MU_Events
      \brief Enum defining events notified by MU to the FT Application.
*/
typedef enum{
  LTQ_CVOIP_HS_ATTACHED=0,/*!< Handset is Attached*/
  LTQ_CVOIP_HS_REGISTERED =1,/*!< Handset is Registered*/
  LTQ_CVOIP_HS_UNREGISTERED=2,/*!< Handset is Unregistered*/
  LTQ_CVOIP_HS_REG_TIME_EXPIRED=3,/*!< Handset as acknowledged the Registration time expried*/
  LTQ_CVOIP_HS_PROP_INFO=4,/*!< Prop Info arrived in Locate Request */
}e_LTQ_CVOIP_DECT_HS_Events;


#if 0
/*!
    \brief Structure containing previous Subscription/Registration Information.   
 */

typedef struct
{
/*! \def IFX_DECT_IPUI_SIZE
      \brief Size of IPUI */
#define IFX_DECT_IPUI_SIZE 5
/*! \def IFX_DECT_TPUI_SIZE
      \brief Size of TPUI */
#define IFX_DECT_TPUI_SIZE 3
/*! \def IFX_DECT_AUTH_KEY_SIZE
      \brief Size of authentication key */
#define IFX_DECT_AUTH_KEY_SIZE 16
/*! \def IFX_DECT_CIPHER_KEY_SIZE
      \brief Size of cipher key */
#define IFX_DECT_CIPHER_KEY_SIZE 8

  uchar8  cstatus;              /*!< Handset registration  status */
  uchar8  acipui_array[IFX_DECT_IPUI_SIZE]; /*!< Handset IPUI number */
  uchar8  actpui_array[IFX_DECT_TPUI_SIZE]; /*!< Handset TPUI number */
  uchar8  acuak_array[IFX_DECT_AUTH_KEY_SIZE];    /*!< Handset authentication key*/
  uchar8  acdck_array[IFX_DECT_CIPHER_KEY_SIZE];/*!< Handset Cipher key */
  uchar8  cservice_class;/*!< Service class */
  uchar8  cmodel_id;/*!< Handset model ID */
  uint32  uiTermCap; /*!< Terminal Capabilities */
}x_IFX_DECT_SubscInfo;

#endif

/*!
    \brief Structure containing Notification information passed on to FT application.
*/
typedef struct{
  e_LTQ_CVOIP_DECT_HS_Events eEvent;/*!< Event to be notified*/
  uchar8 ucHandSet;/*!< Handset number in the range  1-6 */
  //x_IFX_DECT_SubscInfo *pxSubscInfo;/*!< Subscription info valid only in the case of attachment*/
	uint32 uiTermCap;/*!< Terminal Capability*/
  uint32 uiIEHdlr; /*!< Prop information IE Handler*/
  uchar8 ucDspLines;/*!< Number of Display Lines*/
  uchar8 ucCharPerLine; /*!< Number of Character per Line*/
}x_LTQ_CVOIP_DECT_HS_NotifyInfo;

/* Following are used as flags to support DECT FSM */

/*! \brief This flag is set when user requests to reject waiting call and is 
	         reset once user goes on-hook */
#define IFX_DECT_F_WAIT_FOR_DIAL_DIGIT	          0x00000001

/*! \brief This flag is set after allocating DECT Signaling channel and is 
	         reset once channel is deallocated */
#define IFX_DECT_F_RESOURCE_ALLOCATED	      0x00000002

/*! \brief This flag is set if voice is enabled on DECT handset and is reset
           after disabling voice */
#define IFX_DECT_F_VOICE_ENABLED		        0x00000004

/*! \brief This is used in auto-redial. This flag is set when call is initiated
	         to DECT handset for auto-redial and reset when user answers call. */
#define IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS	0x00000008

/*! \brief This flag is used for auto-redial suscription with remote party. Flag
	         is set when auto redial subscription succeeds and reset after 
           receiving final notify from remote party.  */
#define IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT	  0x00000010

/*! \brief This flag is set after successful registration of auto-redial and is
	         reset after sending notify or if remote party cancels it.  */
#define IFX_DECT_F_AUTOREDIAL_ACTIVE_IN	    0x00000020

/*! \brief This flag is set while making emergency call and reset after 
	         terminating emergency call */
#define IFX_DECT_F_EMG_CALL_PROCEDING	      0x00000040

/*! \brief This flag indicates whether call is being initiated by agent. This is
	         set when agent requests CM to initiate call and is reset after 
           receiving final response. */
#define IFX_DECT_F_CALL_INITIATED	          0x00000080

/*! \brief This flag is set when hold is initiated on active call and is reset 
	         after receiving hold response. */
#define IFX_DECT_F_HOLD_INITIATED	          0x00000100

/*! \brief This flag is set when transfer is initiated and reset after receiving
	         transfer response. */
#define IFX_DECT_F_TRANSFER_INITIATED	      0x00000200

/*! \brief This flag is used while resuming a call. Flag is set after initiating
           resume on held call and is reset after receiving resume response */
#define IFX_DECT_F_RESUME_INITIATED	        0x00000400

/*! \brief This is used in conference. It is set when conference is initiated
           and is reset after receving conference status */
#define IFX_DECT_F_CONFERENCE_INITIATED	    0x00000800

/*! \brief This is used while terminating conference. Set when conference break
           is initiated and reset after receiving conference break response */
#define IFX_DECT_F_BREAK_CONFERENCE_INITIATED	0x00001000

/*! \brief This flag is used while subscribing for auto redial. It is set when
           auto-redial request is initated and turned off after getting final
           response. */
#define IFX_DECT_F_AUTOREDIAL_REQ_INITIATED	  0x00002000

/*! \brief This flag is used for auto redialing. If auto redial notify is 
	         recived with success and DECT FSM in busy state, this flag is set 
           so that once handset goes to IDLE state, do auto-redial on last
           dialed number. */
#define IFX_DECT_F_AUTOREDIAL_ON_IDLE	        0x00004000

/*! \brief This flag is set when there is incoming call in active state. This is
	         reset - If waiting call is released 
	               - If waiting call is answered. */
#define IFX_DECT_F_CALL_WAITING	              0x00008000

/*! \brief This flag is used while paging handset. This is set after initiating 
	         paging and is reset when paging completes */
#define IFX_DECT_F_PAGE_CALL 	                0x00010000

/*! \brief This flag is set when service change request is initated by DECT 
	         handset and it is reset after completing service change process */
#define IFX_DECT_F_SERVICE_CHANGE_IN	        0x00020000

/*! \brief This flag is set when service change request is initated by DECT 
	         agent and is reset after receiving response from handset.  */
#define IFX_DECT_F_SERVICE_CHANGE_OUT	        0x00040000

/*! \brief This flag is used for media negotiation initiated by CM. This flag
	         is set if need to send media negotiation response after changing
					 on DECT side. */
#define IFX_DECT_F_MEDIA_CHANGE_REQ	          0x00080000


/*! \brief This flag is used for Checking status of tone play. If flag is set
	         tone is being played. Else tone is stopped*/
#define IFX_DECT_F_TONE_PLAYED	        0x80000000


#define IFX_DECT_F_ATX_PENDING	          0x00200000
#define IFX_DECT_F_CIPHER_INITIATED	      0x00400000
#define IFX_DECT_F_TOGGLE_INITIATED	      0x00800000
#define IFX_DECT_F_IGNORE_ATXSTATUS 0x01000000

#define IFX_DECT_F_INTERCEPT_REQ	        0x02000000
#define IFX_DECT_F_INTERCEPT_INIT	        0x04000000
#define IFX_DECT_F_INTRUDE_REQ		        0x08000000
#define IFX_DECT_F_INTRUDE_INIT        		0x10000000
/*! \brief Maximum DECT calls supported per endpoint.*/
#define IFX_MAX_DECT_CALLS	        2  

/*! \brief Invlid DECT PP instance number */
#define IFX_DECT_INVALID_INSTANCE	  0xFF

/*! \brief This contains flag that are retained even after moving to IDLE 
	         state */
#define IFX_DECT_FLAGS_IN_IDLE_STATE ( IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT | \
																			 IFX_DECT_F_AUTOREDIAL_ACTIVE_IN | \
																			 IFX_DECT_F_AUTOREDIAL_ON_IDLE )

/*! \brief The DECT Endpoint(handset) data structure */
typedef struct
{
	char8 szEndptId[IFX_MAX_ENDPOINTID_LEN]; /** EndpointId id */
	uint8 ucInstance; /** DECT Instance number 0~5*/
	boolean bWidebandEnabled; //PP supprts wideband ??
	boolean bG711Enabled; //PP supprts G711 Codec ??
	/** DECT channel number - 
			Valid only if DECT channel is allocated for endpoint */
	uint16 unDectChannel; 
	x_IFX_CIF_DectSubsInfo xDECTSubsInfo; /** Subscription information of PP */

	uint32 uiFlags; /** Flags */
	boolean bPPAttached; /** IFX_TRUE if PP is attached */

	e_IFX_DECT_States eState; /** Current state of the endpoint */
	
	uint32 uiDTkCallId; /** Temp storage DectToolkit Call handle till active call is decided*/
	
	/** Call information is stored in this array. */
	x_IFX_DECT_CallInfo axCallInfo[IFX_MAX_DECT_CALLS];
	x_IFX_DECT_CallInfo *pxActiveCall; /** Current call pointer. */

	x_IFX_MMGR_CodecList xReservedCodecs; /** Codec reserved on DECT channel */
	e_IFX_MMGR_CodecType eRunningCodec;   /** Running Codec on DECT channel */

	x_IFX_CMGR_AddressInfo xLastDialedAddr; /** Last Dialed number */
	char8 szDialledDigits[IFX_MAX_DIGITS];  /** Used to store dialed numbers */
	

	/* Following strings are used only for waiting call */
	char8 szCallerName[32]; /** Waiting call's caller name */
	char8 szCallerNumber[128]; /** Waiting call's caller number */
	uint32 uiTermCap;		/** Terminal Capabilities */
}x_IFX_DECT_EndptFsmInfo;

/*! \brief This macro sets the given flag.*/
/*! \brief This macro sets the given flag.*/
#define LTQ_CVOIP_DECT_SetEndptFlag(pxEndpt, FlagToBeSet) \
                  (((pxEndpt)->uiFlags) |= FlagToBeSet )

/*! \brief This macro resets the given flag.*/
#define LTQ_CVOIP_DECT_ResetEndptFlag(pxEndpt, FlagToBeReset) \
                  (((pxEndpt)->uiFlags) &= ~(FlagToBeReset) )
  
/*! \brief This macro is used to check flags.*/
#define LTQ_CVOIP_DECT_CheckEndptFlag(pxEndpt, FlagToBeChecked) \
                (((pxEndpt)->uiFlags) & (FlagToBeChecked))

/*! \brief Incoming call event struct. */
typedef struct
{
  uchar8 ucLineId; /** Line Id for the incoming call*/
	x_IFX_CMGR_AddressInfo* pxFrom;       /** Caller address info */
	x_IFX_CMGR_CallParams*  pxCallParams; /** Call parameters */
}x_IFX_DECT_IncCallEvent;

/*! \brief Parsed digits are stored in this struct */
typedef struct 
{
	char8 szDigits[IFX_MAX_ENDPOINTID_LEN]; /** Dialed digits are stored in this array */
}x_IFX_DECT_DigitInfo;

/*! \brief This struct holds setup message parameter needed for DECT FSM */
typedef struct 
{
	uchar8 ucBasicService; /** Basic call service */
	uchar8 ucRejectReason; /** Valid if call is rejected */
	x_IFX_DECT_DigitInfo xDigitInfo; /** For block dialing */
	uint16 aunCodec[IFX_DECT_MAX_CODEC]; /** For storing codec offered by PP */
	uint32 uiTmpDtkCallHdl; /** For storing Dect Toolkit Call Handle for outgoing call */
	uchar8 ucLineId;
}x_IFX_DECT_SetupEvent;


/*! \brief This enum defines service change request/response types */
typedef enum
{
	IFX_DECT_SC_REQUEST,
	IFX_DECT_SC_ACCEPT,
	IFX_DECT_SC_REJECT
}e_IFX_DECT_ServiceChangeType;

/*! \brief Struct to hold service change reqest/response information */
typedef struct
{
	e_IFX_DECT_ServiceChangeType eScMsgType;
  uint16 unCodecType; /* used if message is service change rq */	
}x_IFX_DECT_ServiceChangeInfo;

typedef struct {
  uint16 unCodecType; /** Codec type */ 
}x_IFX_DECT_SlotModInd;
/*! \brief This is a union that contains event related information. */
typedef union
{
	e_IFX_ReasonCode eReasonCode;    /** Reason for call release - From CM */
	uchar8           eDectReleaseReason; /** DECT call release reason */
	e_IFX_CMGR_Status eStatus;       /** Status for hold,resume & conference */
	e_IFX_TransferStatus eTxStatus;  /** transfer status */
	x_IFX_DECT_SetupEvent xSetupEvt; /** Setup info */
	x_IFX_DECT_IncCallEvent xIncCallEvt; /** Incoming call event */
	x_IFX_DECT_DigitInfo xDigitEvt;	 /* Digit event info */
	x_IFX_DECT_ServiceChangeInfo xServiceChangeInfo;
	x_IFX_DECT_SlotModInd xSlotModInd;
	/* This is used for codec info. Used for alert, connect */
	uint16 aunCodec[IFX_DECT_MAX_CODEC]; 
	boolean bPagingOn; /* IFX_TRUE - Initiate paging call, IFX_FALSE - stop paging */
	/* IFX_TRUE - If ciphering is success, IFX_FALSE - ciphering failed */
#ifdef ENABLE_ENCRYPTION
	boolean bCipheringStatus; 
#endif
}ux_IFX_DECT_EventData;


/*! \brief DECT event information is put into this struct. */
typedef struct
{
	e_IFX_DECT_Event eEvent;	/** Event type */
	uint32 uiId;	            /** Call, Request Id or timer id. */
	ux_IFX_DECT_EventData uxEventData; /** Event data */
}x_IFX_DECT_EventInfo;

/* 
 * Agent initializtion, shutdown and status functions 
 */
e_IFX_Return IFX_CVOIP_AgentInit(
	                   IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucNoOfEndpts,
	                   IN uchar8 ucDectDbgId );

e_IFX_Return IFX_CVOIP_AgentShut(
	                   IN char8  aszEndPointId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpoints );


e_IFX_Return IFX_DECT_AgentStatus(IN void *pStatistics);
//e_IFX_Retrun LTQ_CVOIP_CbRegisterWithCmgr(IN x_IFX_DECT_EndptFsmInfo *pxEndptInfo );
/*!
	\brief This routine makes DECT endpoint (PP) idle. Releases all calls for 
	       the given PP and also releases resources and resets flags related to
	       call.
	\param[in] pxEndptInfo Pointer to x_IFX_DECT_EndptFsmInfo.
	\return Retunrs IFX_SUCCESS or IFX_FAILURE. 
 */
e_IFX_Return IFX_DECT_MakeDectPPIdle(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo);

/* 
 * Following functions will be registered with call manager. For Detail 
 * description see implementation file (IFX_DECT_Agent.c)
 */	

e_IFX_Return LTQ_CVOIP_CallIncoming(
	               IN uint32 uiCallId, 
	               IN x_IFX_CMGR_AddressInfo *pxFrom,
	               IN x_IFX_CMGR_AddressInfo *pxTo, 
	               IN x_IFX_CMGR_CallParams *pxCallParams, 
	               OUT e_IFX_CMGR_Status* peStatus,
	               OUT e_IFX_ReasonCode* peReason,
	               OUT void** ppvPrivateData );

e_IFX_Return LTQ_CVOIP_RemoteCallAccept(
	             IN uint32 uiCallId,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_RemoteCallAnswer(
	             IN uint32 uiCallId,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_RemoteCallHold(
	             IN uint32 uiCallId,
	             OUT e_IFX_CMGR_Status* peStatus,
	             OUT e_IFX_ReasonCode* peReason,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_RemoteCallResume(
	             IN uint32 uiCallId,
	             OUT e_IFX_CMGR_Status* peStatus,
	             OUT e_IFX_ReasonCode* peReason,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_CallHoldResponse(
	             IN uint32 uiCallId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason, 
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_CallResumeResponse(
	             IN uint32 uiCallId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason, 
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_ConfStatus(
	             IN uint32 RequestId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_RemoteCallRelease(
	             IN uint32 uiCallId,
	             IN e_IFX_ReasonCode eReleaseReason,
	             IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
	             IN void* pvPrivateData );

 e_IFX_Return LTQ_CVOIP_CallForwardInfo(
	             IN uint32 uiCallId,
	             IN e_IFX_ReasonCode eReason, 			
	             IN x_IFX_CMGR_AddressInfo* pxFwdAddr,			
	             OUT boolean* pbFwdAllow,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_BlindTxRequest(
	             IN uint32 uiCallId,
	             IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
	             OUT e_IFX_TransferStatus* peTransferStatus,
	             OUT e_IFX_ReasonCode *peRespCode,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_AttendedTxRequest(
	             IN uint32 uiCallId,
	             IN uint32 uiReplacesCallId,
	             IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
	             OUT e_IFX_TransferStatus* peTransferStatus,
	             OUT e_IFX_ReasonCode *peRespCode,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_BlindTxStatus(
	             IN uint32 uiCallId,
	             IN e_IFX_TransferStatus eTransferStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_AttendedTxStatus(
	             IN uint32 uiCallId,
	             IN e_IFX_TransferStatus eTransferStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_CallIdReplace(
	               IN uint32 uiOldCallId,
	               IN uint32 uiNewCallId,
	               IN_OUT void** ppvPrivateData );

e_IFX_Return LTQ_CVOIP_GetMediaParams(
	               IN uint32 uiCallId,
	               OUT x_IFX_CMGR_MediaParams* pxMediaParams,
	               IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_MediaNegReq(
	               IN uint32 uiCallId,
	               IN_OUT x_IFX_CMGR_MediaParams* pxMediaParams,
	               OUT e_IFX_CMGR_Status* peStatus,
	               OUT e_IFX_ReasonCode* peReason,
	               IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_MediaNegResp(
                 IN uint32 uiCallId,
                 IN x_IFX_CMGR_MediaParams* pxMediaParams,
                 IN_OUT e_IFX_CMGR_Status* peStatus,
                 IN_OUT e_IFX_ReasonCode* peReason,
                 IN void* pvPrivateData );

e_IFX_Return LTQ_CVOIP_Dummy(IN uint32 uiCallId,
               IN void* pvPrivateData);
e_IFX_Return LTQ_CVOIP_ProcessPagekeyMessage(uint32 uiPagingKeyPressedDur);

/*
	\brief DECT FSM Event handler prototype.
	\param[in] pxEndPtInfo Pointer to endpoint info struct.
	\param[in] puxEvtInfo pointer to event info struct. This contains info
	           about the event.
	\param[out] peReason Pointer to e_IFX_ReasonCode code. 
              Valid reason code is returned in this argument	
*/
typedef e_IFX_Return (*pfn_IFX_DECT_Fsm)(
	                IN_OUT x_IFX_DECT_EndptFsmInfo *pxEndPtInfo,
	                IN x_IFX_DECT_EventInfo *puxEvtInfo,
	                OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is entry point for DECT FSM. It invokes the FSM depending
	       upon the event.
	\param[in] pxEndptInfo pointer to Endpoint Info  
	\param[in] pxEvtInfo pointer to Event Info 
	\param[out] peReason If function retunrs IFX_FAILURE, then this parameter
	            indicates the reason for failure.
	\return Retunrs IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return LTQ_CVOIP_DECT_FsmHdlr(
	               IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_DECT_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used in FSM to ignore the event. If event is not 
	       applicable for a FSM state, this function is invoked.
	\param[in] pxEndptInfo pointer to Endpoint Info  
	\param[in] pxEvtInfo pointer to Event Info 
	\param[out] peReason If function retunrs IFX_FAILURE, then this parameter
	            indicates the reason for failure.
	\return Retunrs IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return LTQ_CVOIP_DECT_IgnoreHdlr(
	               IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_DECT_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
/*
 * Following functions are used in DECT FSM. prototype of these functions
 * must be match with pfn_IFX_DECT_Fsm.
 */
e_IFX_Return LTQ_CVOIP_DECT_IdlePPOffHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_IdleIncomingCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_IdlePagingHdlr(		
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtCallAcceptHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtCallAnswerHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtCallRejectHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_AlertingCallRejectHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_AlertingCallAcceptHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_AlertingCallAnsweredHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );


e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtAcceptHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtAnswerHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ActiveRmtCallReleaseHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_DECT_ActiveCallReleaseHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );


e_IFX_Return LTQ_CVOIP_DECT_IgnoreCallHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason );

e_IFX_Return LTQ_CVOIP_INITCmdHdlr(uchar8 ucATCntxt);
e_IFX_Return IFX_CVOIP_ConstNSendATCmd(e_LTQ_ATCmd_Type eCmdType, uchar8** ppucStrParam, uchar8 ucByteParam);


#endif // __IFX_DECT_AGENT_H__
