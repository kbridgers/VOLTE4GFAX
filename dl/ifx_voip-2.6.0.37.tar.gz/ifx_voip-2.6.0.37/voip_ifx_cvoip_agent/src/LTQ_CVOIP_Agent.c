
/**************************************************************************
 **   SRC_FILE          : LTQ_CVOIP_Agent.c
 **   PROJECT           : CVoIP
 **   MODULES           : CVoIP Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 15th Sep 2011
 **   AUTHOR            : DECT team
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <time.h>
/* According to POSIX 1003.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
//#include <linux/delay.h>
#include <unistd.h>
#include <stdlib.h>

#include <sys/stat.h>
#include <fcntl.h>

#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_TimerIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_DialPlanIf.h"
#include "IFX_Misc.h"
#include "ifx_debug.h"
#include "IFX_DialPlan.h"
#include "IFX_AgentsUtils.h" 
#include "LTQ_CVOIP_MsgHdlr.h"
#include "LTQ_APP_Parser_Intf.h"
#include "LTQ_CVOIP_Agent.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
//#include "LTQ_APP_ATCmdDef.h"
//#include "LTQ_APP_Parser.h"
EXTERN e_IFX_Return
IFX_CIF_StoreValuesFromModem(e_IFX_VMAPI_ObjectId eObj,IN void *buf);
EXTERN e_IFX_Return IFX_CIF_TPCValGet(OUT x_IFX_VMAPI_TransmitPowerParam *pxTpc);
EXTERN e_IFX_Return IFX_CIF_GaussianValGet(OUT x_IFX_VMAPI_DectGFSKVal *pxGfsk);
EXTERN e_IFX_Return IFX_CIF_BMCRegparamGet(OUT x_IFX_VMAPI_DectBMCParams *pxBMCParams);
EXTERN e_IFX_Return IFX_CIF_OscTrimParamGet(OUT x_IFX_VMAPI_DectOscTrimVal *pxOscTrimVal);
EXTERN e_IFX_Return IFX_CIF_RFPIGet(OUT x_IFX_VMAPI_DectRfpi *pxRfpi);
EXTERN e_IFX_Return IFX_CIF_CtryParamGet(OUT x_IFX_VMAPI_DectCountrySettings *pxCtryset);
EXTERN e_IFX_Return IFX_CIF_RFMODGet(OUT x_IFX_VMAPI_RFMode *pxRfmode);
EXTERN e_IFX_Return IFX_CIF_XRAMGet(OUT x_IFX_VMAPI_DectXRAM *pxXram );

uchar8 vucDectAgnetModId;
STATIC boolean vbCVoipInitialized = IFX_FALSE;
STATIC x_IFX_DECT_EndptFsmInfo vaxDectEndptFsmInfo[IFX_MMGR_MAX_DECT_CHANNELS];
uchar8  vaucBaseCapabParams[LTQ_BaseCapCmd_Rekeying+1];
uchar8 vaucPcmChannelNo[6];
static int iMode;/* 0 Idle 1 Reg Mode 2 Paging */

//Pcm Configuration DS
x_LTQ_CVOIP_PcmConfig xPcmConfig[ ]={
																			{0,0},
																			{2,0},
																			{4,0},
																			{6,0}
																		};

extern uchar8  vcDECTModId; 
#define LTQ_CVOIP_MAX_ATCMD 255
#define IFX_DECT_REG_KEY_PRESS_DUR               5000
#define CVOIP_POWER_MODE_LOW               8000
#define CVOIP_POWER_MODE_HIGH               9000
//#define COSIC_STUB
#ifdef COSIC_STUB
#define LTQ_CVOIP_DEVICE_NAME         "/tmp/stub"
extern int32 viPagingKeyFd,viCVoipFd;
extern x_IFX_MSGRTR_FdInfo axDectFdInfo[2];
#endif

#define WRITE_SUBS_INFO

#define IFX_DECTAPP_MAX_DECT_ENDPTS 6

#define IFX_DECT_UpdateCallState(pxEndpt, pxCall, eCallState) \
  { \
    (pxCall)->eState = eCallState; \
  }

#define IFX_DECT_ResetCall(pxRelCall,bRelease) \
  { \
    if(pxRelCall){ \
      memset(pxRelCall,0,sizeof(x_IFX_DECT_CallInfo)); \
    }\
  } 


#define LTQ_CVOIP_DECT_UpdateEndptState(pxEndpt, state) \
	{ \
		pxEndpt->eState = state; \
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO, \
				pxEndpt->szEndptId, IFX_DECT_GetStateStr(pxEndpt->eState) ); \
	} 

#define IFX_DECT_GetCallInfo(pxEndpt, CallId, ppxCallInfo) \
  { \
    if( (pxEndpt)->axCallInfo[0].uiCallId == (CallId) ) \
      *(ppxCallInfo) = ((pxEndpt)->axCallInfo+0); \
    else if( (pxEndpt)->axCallInfo[1].uiCallId == (CallId) ) \
      *(ppxCallInfo) = ((pxEndpt)->axCallInfo+1); \
    else \
      *(ppxCallInfo) = 0; \
  }

#define IFX_DECT_GetFreeCallInfo(pxEndpt, ppxCallInfo) \
  { \
    if( (pxEndpt)->axCallInfo[0].uiCallId == 0 ) \
      *(ppxCallInfo) = ((pxEndpt)->axCallInfo+0); \
    else if( (pxEndpt)->axCallInfo[1].uiCallId == 0) \
      *(ppxCallInfo) = ((pxEndpt)->axCallInfo+1); \
    else \
      *(ppxCallInfo) = 0; \
  }

e_IFX_Return LTQ_CVOIP_DECT_HS_Info_Notify(IN x_LTQ_CVOIP_DECT_HS_NotifyInfo *pxAttachInfo);
e_IFX_Return IFX_CVOIP_ConstNSendCOAPcmd(x_IFX_DECT_EndptFsmInfo* pxEndptInfo,uchar8 pucOperation,uchar8 ucServiceChange);
e_IFX_Return LTQ_CVOIP_getCodectListFilled(IN uint32 uiClistType, OUT x_IFX_CodecList *pxCodecList);
e_IFX_Return LTQ_CVOIP_getCvoipCodectList(IN uint32 uiClistType, OUT uchar8 *aucBuf);
STATIC e_IFX_Return IFX_DECT_ExecuteDialPlan(
	                           IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo, 
										         IN e_IFX_DP_Action eDpAction, 
										         IN char8* pszDialOut, 
										         OUT uchar8* pucSignal, 
										         OUT e_IFX_DECT_States* peState );

STATIC e_IFX_Return IFX_DECT_InitiateCall(
                     IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
										 IN x_IFX_CMGR_AddressInfo* pxDialedAddr,
										 IN e_IFX_CMGR_FeatStatus eCidStatus,
	                   IN boolean bEmergencyCall,
	                   OUT e_IFX_CMGR_Status* peStatus,
	                   OUT e_IFX_ReasonCode* peReason );


void AllocPcmChannel(int32 iEndPtId);
e_IFX_Return LTQ_CVOIP_isValidDectEndPoint(uint32 uiDectHsId){
printf(" <LTQ_CVOIP_isValidDectId> %d \n",uiDectHsId);
if(uiDectHsId >=1 && uiDectHsId <= IFX_DECTAPP_MAX_DECT_ENDPTS)
	return IFX_SUCCESS;
else
	return IFX_FAILURE;

}
//e_IFX_Return LTQ_CVOIP_SendOKCmd(uchar8 ucATCntxt);

/*******************************************************************************
 * vax_LTQ_CVOIP_DECTFsm - This is FSM table for DECT endpoint.
*******************************************************************************/
pfn_IFX_DECT_Fsm vax_LTQ_CVOIP_DECTFsm[IFX_DECT_STATE_MAX][IFX_DECT_EventMax] =
{
  //LTQ_CVOIP_DECT_STATE_IDLE,             /** Idle */
  {
    LTQ_CVOIP_DECT_IdlePPOffHookHdlr,   //LTQ_CVOIP_DECT_EVT_PP_OffHook
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_DigitReceived
    LTQ_CVOIP_DECT_IdleIncomingCallHdlr,  //LTQ_CVOIP_DECT_EVT_IncomingCall
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtAccept
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtAnswer
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_ReleaseCall
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtHold
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtResume
		LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_CallAccept
		LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_CallAnswer
		LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_CallReject
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_Paging
    LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_Attached
  },
//LTQ_CVOIP_DECT_STATE_PROGRESS,          /** Outcall - Dialing */
  {
    LTQ_CVOIP_DECT_IgnoreHdlr,   //LTQ_CVOIP_DECT_EVT_PP_OffHook
    LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr,  //LTQ_CVOIP_DECT_EVT_DigitReceived
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_IncomingCall
    LTQ_CVOIP_DECT_ProgressRmtCallAcceptHdlr,  //LTQ_CVOIP_DECT_EVT_RmtAccept
    LTQ_CVOIP_DECT_ProgressRmtCallAnswerHdlr,  //LTQ_CVOIP_DECT_EVT_RmtAnswer
    LTQ_CVOIP_DECT_ProgressRmtCallRejectHdlr,  //LTQ_CVOIP_DECT_EVT_ReleaseCall
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtHold
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtResume
		LTQ_CVOIP_DECT_AlertingCallAcceptHdlr, //LTQ_CVOIP_DECT_EVT_CallAccept
		LTQ_CVOIP_DECT_AlertingCallAnsweredHdlr, //LTQ_CVOIP_DECT_EVT_CallAnswer
		LTQ_CVOIP_DECT_AlertingCallRejectHdlr, //LTQ_CVOIP_DECT_EVT_CallReject
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_Paging
    LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_Attached
},
 //LTQ_CVOIP_DECT_STATE_ACTIVE,     /** Service Call -SMS/Info send or recv */
  {
    LTQ_CVOIP_DECT_IgnoreHdlr,   //LTQ_CVOIP_DECT_EVT_PP_OffHook
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_DigitReceived
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_IncomingCall
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtAccept
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtAnswer
    LTQ_CVOIP_DECT_ActiveRmtCallReleaseHdlr,  //LTQ_CVOIP_DECT_EVT_ReleaseCall
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtHold
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_RmtHold
		LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_CallAccept
		LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_CallAnswer
		LTQ_CVOIP_DECT_ActiveCallReleaseHdlr, //LTQ_CVOIP_DECT_EVT_CallReject
    LTQ_CVOIP_DECT_IgnoreHdlr,  //LTQ_CVOIP_DECT_EVT_Paging
    LTQ_CVOIP_DECT_IgnoreHdlr, //LTQ_CVOIP_DECT_EVT_Attached
	},

};

/*---------------------------- Utility Routines -----------------------------*/
void
IFX_DECT_EndpointLineIdGet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                           OUT IN uchar8 *pucLineId){

  if(pxEndptInfo->pxActiveCall == NULL){
    *pucLineId = pxEndptInfo->axCallInfo[0].ucLineId;
  }else{
    *pucLineId = (pxEndptInfo->pxActiveCall->uiDTkCallId == pxEndptInfo->axCallInfo[0].uiDTkCallId)?
                  pxEndptInfo->axCallInfo[1].ucLineId:pxEndptInfo->axCallInfo[0].ucLineId;
   }
  return;
}

void
IFX_DECT_EndpointLineIdSet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                           IN uchar8 ucLineId){

  /*If Call is first call for the HS populate Line Id in CallInfo[0] 
    else in CallInfo[1] in EndptInfo struct*/
  if(pxEndptInfo->pxActiveCall == NULL){
    pxEndptInfo->axCallInfo[0].ucLineId = ucLineId;
  }else{
    if(pxEndptInfo->pxActiveCall->uiDTkCallId == pxEndptInfo->axCallInfo[0].uiDTkCallId)
      pxEndptInfo->axCallInfo[1].ucLineId = ucLineId;
    else
        pxEndptInfo->axCallInfo[0].ucLineId = ucLineId;
    }
  printf("\n ucLineId set in Endpt=%d\n",ucLineId);
  return;
}

e_IFX_Return
IFX_DECT_IsEndpointLineIdSet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo){

  /*Check whether Line Id is already populated for the Handset Call*/
  if(pxEndptInfo->pxActiveCall == NULL){
    if(!pxEndptInfo->axCallInfo[0].ucLineId)
      return IFX_FAILURE;
  }else{

    if(pxEndptInfo->pxActiveCall->uiDTkCallId == pxEndptInfo->axCallInfo[0].uiDTkCallId){
      if(!pxEndptInfo->axCallInfo[1].ucLineId)
        return IFX_FAILURE;
    }else{
      if(!pxEndptInfo->axCallInfo[0].ucLineId)
        return IFX_FAILURE;
     }
   }
  return IFX_SUCCESS;
}



/*******************************************************************************
 *  Function Name   : IFX_DECT_HsIdFromEPName
 *  Description     : This routine used to get endpoint info using endpoint id.
 *  Input Values    : szEndptId - DECT Endpoint id
 *  Output Values	  : ppxEndPtInfo -  If szEndptId matches with attached DECT 
 *	                  handset, pointer DECT endpoint info is returned in this.
 *  Return Value    : If endpoint is found returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
char8 IFX_DECT_HsIdFromEPName(IN char8* szEndptId)
{
	uchar8 ucIndex = 0;
	printf("Enter EPName\n");
	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
		if(strcmp(vaxDectEndptFsmInfo[ucIndex].szEndptId, szEndptId) == 0)
		{
			break;
		}
	}	
	if(ucIndex == IFX_MMGR_MAX_DECT_CHANNELS){
	  return -1;
	}
	return ucIndex+1;
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEndptName
 *  Description     : This routine returns End point Id based on Handset Id.
 *  Input Values    : Handset Id
 *  Output Values	  : Endpoint Id - String 
 *  Return Value    : IFX_SUCCESS / IFX_FAILURE
 *  Notes           :
 ******************************************************************************/

e_IFX_Return IFX_DECT_GetEndptName(IN uchar8 ucHandSetId,
																	 OUT char8 *szEndptId)
{
	if(szEndptId && ucHandSetId > 0 && ucHandSetId < IFX_DECTAPP_MAX_DECT_ENDPTS)  {

	  strcpy(szEndptId,vaxDectEndptFsmInfo[ucHandSetId-1].szEndptId);
		return IFX_SUCCESS;
	}
		return IFX_FAILURE;
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEndptInfoById
 *  Description     : This routine used to get endpoint info using endpoint id.
 *  Input Values    : szEndptId - DECT Endpoint id
 *  Output Values	  : ppxEndPtInfo -  If szEndptId matches with attached DECT 
 *	                  handset, pointer DECT endpoint info is returned in this.
 *  Return Value    : If endpoint is found returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_GetEndptInfoById(
	                                  IN char8* szEndptId,
	                                  OUT x_IFX_DECT_EndptFsmInfo **ppxEndPtInfo)
{
	uchar8 ucIndex = 0;
	*ppxEndPtInfo = 0;

	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
		if(strcmp(vaxDectEndptFsmInfo[ucIndex].szEndptId, szEndptId) == 0)
		{
			*ppxEndPtInfo = (vaxDectEndptFsmInfo+ucIndex);
			break;
		}
	}	
	return (*ppxEndPtInfo != 0)?IFX_SUCCESS:IFX_FAILURE;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEndptInfoByInstance
 *  Description     : This routine is used to retrive DECT endpoint info using
 *	                  DECT instance number.
 *  Input Values    : ucInstance - DECT instance number
 *  Output Values	  : ppxEndPtInfo - If instance number is valid, pointer to
 *	                  DECT endpoint info is returned in this variable.
 *  Return Value    : If instance number is valid, returns IFX_SUCCESS, else
 *	                  returns IFX_FAILURE.
 *  Notes           : This is used when message is received from DECT stack.
 ******************************************************************************/
e_IFX_Return IFX_DECT_GetEndptInfoByInstance(
														 IN uchar8 ucInstance,
														 OUT x_IFX_DECT_EndptFsmInfo **ppxEndPtInfo )
{
	uchar8 ucIndex = 0;
	*ppxEndPtInfo = 0;

	if( ucInstance == IFX_DECT_INVALID_INSTANCE )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Wrong Instance Number" );
		printf("wrong Instance number\n");
		return IFX_FAILURE;
	}

	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
		if(vaxDectEndptFsmInfo[ucIndex].ucInstance == ucInstance)
		{
			*ppxEndPtInfo = (vaxDectEndptFsmInfo+ucIndex);
			break;
		}
	}	
		if(*ppxEndPtInfo)	
				printf("No End Pt Info\n");
	return (*ppxEndPtInfo != 0)?IFX_SUCCESS:IFX_FAILURE;
}

#ifdef ENABLE_PAGING
/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_ProcessPagekeyMessage 
 *  Description     : This routine processes pagekey events. Paging key is used 
 *	                  for paging handsets and also for registring handsets. 
 *	                  These two events are distinguished using key pressed 
 *	                  duration.
 *	                  Paging - If registration is enabled, ignore the event. Else
 *	                  if paging is started earlier and still handsets are being 
 *	                  paged, stop paging. Otherwise start paging.
 *	                  Registration - Start registration if paging is not running
 *  Input Values    : uiPagingKeyPressedDur - Key pressed duration (in ms)
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/
e_IFX_Return 
LTQ_CVOIP_ProcessPagekeyMessage(uint32 uiPagingKeyPressedDur)
{
  e_IFX_Return eRet;
  char8 acBaseName[IFX_MAX_BASENAME]={'\0'};
  char8 acBuff[LTQ_CVOIP_MAX_ATCMD]={'\0'};
	printf("Enrty in ProcessPagekeyMessage\n");
#ifdef COSIC_STUB
	viCVoipFd = 0;
  if((viCVoipFd = open(LTQ_CVOIP_DEVICE_NAME, O_RDWR|O_NONBLOCK))<0){
    //IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      //  "Opening the CVoIP Failed");
    printf("CVOIP_Init, CVOIP open Failed2\n");
    return IFX_FAILURE;
  }
  /* Register the FDs with Message router */
  axDectFdInfo[0].uiFd = viCVoipFd;

  if(IFX_SUCCESS != IFX_MSGRTR_FdCallBackRegister(&axDectFdInfo[0], 
								1,LTQ_CVOIP_MsgRouterFdHdlr)){
   // IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		//				 "IFX_MSGRTR_FdCallBackRegister Failed");
		printf("ProcessPagekeyMessage, Registering FDs Failed\n");
		return IFX_FAILURE;
  }
		printf("ProcessPagekeyMessage, CVOIP FD is Re-Registered\n");
	return IFX_SUCCESS;
#endif
  if(uiPagingKeyPressedDur < IFX_DECT_REG_KEY_PRESS_DUR){
    /* Send AT command for paging all handsets */
		if(iMode==1){/*Registration Mode cant do paging*/
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	             "In registration mode so do not allow paging...." );
			return IFX_FAILURE;
		}
    /* TODO: Change AT command appropriately */
    strcpy(acBuff,"+CREG 0,1");
		//acBuff[5]='\r';
		//acBuff[6]=0;
    eRet = LTQ_CVOIP_SendMsg(acBuff,strlen(acBuff));
    if(eRet != IFX_SUCCESS){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
		           "Failed in sending Paging request to CVoIP...." );
			return IFX_FAILURE;
    }
    if(iMode == 2){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		           "Stop paging sent to CVoIP...." );
      iMode = 0;
    }
    else{
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		           "Start paging sent to CVoIP...." );
      iMode = 2;
    }

    /* TODO: Update the state of each endpoint if required */
  }
	else if(uiPagingKeyPressedDur == CVOIP_POWER_MODE_LOW){//To Send Low power mode to CVOIP  
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      "Sending Power Level 0 ..." );
      return  IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_HSIDLE, NULL, 0);
  }
  else if(uiPagingKeyPressedDur == CVOIP_POWER_MODE_HIGH){//To Send High power mode to CVOIP 
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      "Sending Power level High ... " );
      return  IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_HSIDLE, NULL, 1);
   }
  else{ 
    /* Event is for registration */
    if(iMode != 0){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	             "In paging/registration so do not allow registration...." );
      return IFX_FAILURE;
    }
		printf("Processing paging key, reg event came...\n");
    IFX_CIF_BS_NameGet((char8*)acBaseName);
    /* TODO: Change AT command appropriately */
    if(acBaseName[0] != '\0'){
      sprintf(acBuff,"+CREG 0,0,%s",acBaseName);
    }
    else{
      strcpy(acBuff,"+CREG 0,0,0");
    }
		printf("Processing paging key, sending command %s...\n",acBuff);
    eRet = LTQ_CVOIP_SendMsg(acBuff,strlen(acBuff));
    if(eRet != IFX_SUCCESS){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
		           "Failed in sending Registration request to CVoIP...." );
			return IFX_FAILURE;
    }
		iMode=1;
  }
  return IFX_SUCCESS;
}
#endif /* ENABLE_PAGING */
/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_INITCmdHdlr 
 *  Description     : This routine sends OK in response to ATINIT to COSIC VoIP FP. 
 *  Input Values    : cntxt value
 *  Output Values	  : 
 *  Return Value    : returns IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return 
LTQ_CVOIP_INITCmdHdlr(uchar8 ucATCntxt)
{
	char8	aszEndptIdList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
  uchar8 ucNumEndpts = IFX_MAX_ENDPTS;
  e_IFX_ReasonCode eReason;

	printf("LTQ_CVOIP_INITCmdHdlr, Entry\n");
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucATCntxt);

	IFX_CIF_DectEndptListGet(&ucNumEndpts, aszEndptIdList, &eReason);
	if( ucNumEndpts == 0 || IFX_CVOIP_AgentInit(aszEndptIdList, 
													ucNumEndpts,vcDECTModId) != IFX_SUCCESS )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"CVOIP Agent Init failed...." );
		return IFX_FAILURE;
	}
	vbCVoipInitialized = IFX_TRUE;
	
	// Send spcm for configuration
  IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Config_PCM, NULL, ucATCntxt);
	return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_ATDCmdHdlr 
 *  Description     : This API Process the ATD Command received from CVoIP
 *  Input Values    : cntxt value
 *  Output Values   : 
 *  Return Value    : returns IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return 
LTQ_CVOIP_ATDCmdHdlr(void *pRxCmdHdl)
{
  uchar8 ucCallId=0,ucLineId=0,ucCnTxId=0,ucCodec=2,ucCallType=0,ucConType=1,ucChanelId=0,ucCodec2=1,ucCodec3=3;
  x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_Return eRet =  IFX_FAILURE;
  e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	printf("<LTQ_CVOIP_ATDCmdHdlr> Entry\n");

  if (LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_CtxId, pRxCmdHdl, &ucCnTxId) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
        printf("<LTQ_CVOIP_ATDCmdHdlr>  getvalue failed \n");
        return IFX_FAILURE;
    }

	//	LTQ_CVOIP_SendOKCmd(ucCnTxId);
	// Send okay to CVoIP
	//while(IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId) != IFX_SUCCESS);
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId);
	printf(">>>>>>> [[ Sent OK From LTQ_CVOIP_ATDCmdHdlr ]]\n");

 	if( LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_CallId, pRxCmdHdl, &ucCallId) != IFX_SUCCESS){
				printf(">>>>>>> <LTQ_CVOIP_ATDCmdHdlr> Getting Call ID Failed \n");
	}
  
	//Get all Call related parameters....
	LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_CallType, pRxCmdHdl, &ucCallType);
  LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_Codec1, pRxCmdHdl, &ucCodec);
  LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_Codec2, pRxCmdHdl, &ucCodec2);
  LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_Codec3, pRxCmdHdl, &ucCodec3);
  LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_LineId, pRxCmdHdl, &ucLineId);
  LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_ConnType, pRxCmdHdl, &ucConType);
  LTQ_ATCmd_ByteValueGet(LTQ_DialCmd_ChannelId,pRxCmdHdl,&ucChanelId);

	if( IFX_SUCCESS !=
      IFX_DECT_GetEndptInfoByInstance(ucCnTxId-1, &pxEndptInfo) )
  {
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Could Not Get Handset Info (Invalid Instance Number)" );
    return IFX_FAILURE;
  }

	if(!((ucLineId >= 1) && (ucLineId <= 4))){
			ucLineId=0xFF;
	}

  if(ucLineId != 0xFF)
  {
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
      "Line ID received from DECT Tk in CallIncoming =", ucLineId);
      IFX_DECT_EndpointLineIdSet(pxEndptInfo,ucLineId);
	}
 

	 pxEndptInfo->uiDTkCallId = ucCallId;
  /* Construct the Event Info for the FSM*/
  evtInfo.uxEventData.xSetupEvt.uiTmpDtkCallHdl = ucCallId;
  evtInfo.eEvent = IFX_DECT_EVT_PP_OffHook;
  //strcpy(evtInfo.uxEventData.xSetupEvt.xDigitInfo.szDigits,pxCallParams->acRecvDigits);
  evtInfo.uxEventData.xSetupEvt.ucBasicService = ucConType;
  evtInfo.uxEventData.xSetupEvt.ucLineId = ucLineId;
  switch(ucCodec){
     case 1:
           evtInfo.uxEventData.xSetupEvt.aunCodec[0]=IFX_G726_32;
      break;

     case 2:
           evtInfo.uxEventData.xSetupEvt.aunCodec[0]=IFX_G722_64; 
      break;

  	  default:
           evtInfo.uxEventData.xSetupEvt.aunCodec[0]=IFX_G711_ALAW;

  }
  if((pxEndptInfo->pxActiveCall != NULL) && (pxEndptInfo->pxActiveCall == &pxEndptInfo->axCallInfo[0]))
    pxEndptInfo->axCallInfo[1].eCallType = ucCallType;
	else
    pxEndptInfo->axCallInfo[0].eCallType = ucCallType;
		pxEndptInfo -> unDectChannel = ucChanelId ;	
		printf("<LTQ_CVOIP_ATDCmdHdlr> Callilng FSM Handler\n");
 
	//Call CVoIP FSM Handler 
		eRet =  LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo, &evtInfo, &eReason);
  	if(IFX_SUCCESS != eRet)
	  {
  	  //*pucRejectReason = evtInfo.uxEventData.xSetupEvt.ucRejectReason;
    		printf("Error Processing ATD command.. !");
  	}
  return eRet;

}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_VTSCmdHdlr 
 *  Description     : This routine Proecss the VTS command received from  CVoIP . 
 *  Input Values    : cntxt value
 *  Output Values   : 
 *  Return Value    : returns IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return
LTQ_CVOIP_VTSCmdHdlr(void **pRxCmdHdl)
{
  uchar8 ucCnTxId=0;
	uchar8 *ucRecvDigits=NULL;
  x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_Return eRet =  IFX_FAILURE;
  e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	printf("<LTQ_CVOIP_VTSCmdHdlr> Entry ...\n");
  if (LTQ_ATCmd_ByteValueGet(LTQ_DTMFCmd_CtxId, pRxCmdHdl, &ucCnTxId) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
        return IFX_FAILURE;
    }

	//Send OK to CVoIP	
	//while(IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId) != IFX_SUCCESS);
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId); 

	printf(">>>>>>> [[ Sent OK from LTQ_CVOIP_VTSCmdHdlr]]\n");
	/* Get the Dialed Digits */
	ucRecvDigits = LTQ_ATCmd_ValueGet(LTQ_DTMFCmd_Number, pRxCmdHdl) ; 

	if(ucRecvDigits == NULL) {
				printf("<LTQ_CVOIP_VTSCmdHdlr> Receive Digits is NULL  \n");
				return IFX_FAILURE;
	}else if( IFX_SUCCESS !=
      			IFX_DECT_GetEndptInfoByInstance(ucCnTxId-1, &pxEndptInfo) )
 	 			{
					  	  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				        "Could Not Get Handset Info (Invalid Instance Number)" );
					    	return IFX_FAILURE;
  		 }
		printf("<LTQ_CVOIP_VTSCmdHdlr> Receive Digits : %s \n",ucRecvDigits);
    	// Generate the Event for FSM
			strcpy(evtInfo.uxEventData.xDigitEvt.szDigits,(char8*)ucRecvDigits);
  	  evtInfo.eEvent = IFX_DECT_EVT_PP_DigitReceived;

			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
    	evtInfo.uxEventData.xDigitEvt.szDigits, "Digits received" );
			 eRet = LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo, &evtInfo, &eReason); 
      	//*pucRejectReason = evtInfo.uxEventData.xSetupEvt.ucRejectReason;

return eRet;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_ATCACmdHdlr 
 *  Description     : This routine Handles the AT+CA Command from Cvoip. 
 *  Input Values    : cntxt value
 *  Output Values   : 
 *  Return Value    : returns IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return
LTQ_CVOIP_ATCACmdHdlr(void **pRxCmdHdl)
{
	uchar8 ucCnTxId=0,ucCallId=0;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;

	printf("<LTQ_CVOIP_ATCACmdHdlr>  Entry \n");
  if (LTQ_ATCmd_ByteValueGet(LTQ_AcceptCmd_CtxId, pRxCmdHdl, &ucCnTxId) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
        return IFX_FAILURE;
    }
	
	//Send OK to CVoIP	
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId);
	//while(IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId) != IFX_SUCCESS);
	printf(">>>>>>> [[ Sent OK From LTQ_CVOIP_ATCAmdHdlr ]]\n");

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Accepted Call" );
	
	LTQ_ATCmd_ByteValueGet(LTQ_AcceptCmd_CallId, pRxCmdHdl, &ucCallId);
	printf("<LTQ_CVOIP_ATCACmdHdlr>  Call ID %d \n",ucCallId);

	// Construct the Event for CVoIP FSM
	evtInfo.uiId = ucCallId;
	evtInfo.eEvent = IFX_DECT_EVT_CallAccept;
	if( IFX_SUCCESS !=
      IFX_DECT_GetEndptInfoByInstance(ucCnTxId-1, &pxEndptInfo) )
   {
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Could Not Get Handset Info (Invalid Instance Number)" );
      return IFX_FAILURE;
   }

  printf("<LTQ_CVOIP_ATCACmdHdlr>  Calling FSM Handler %d \n",ucCallId);
	if( IFX_SUCCESS != 
			LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "!! Remote Call Accept Failed !!");
	}
	
	return IFX_SUCCESS;

}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_ATACmdHdlr 
 *  Description     : This routine Handles the ATA Command from Cvoip. 
 *  Input Values    : cntxt value
 *  Output Values   : 
 *  Return Value    : returns IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return 
LTQ_CVOIP_ATACmdHdlr(void **pRxCmdHdl)
{
  uchar8 ucCnTxId=0, ucCallId=0,ucChanelId=0;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode eReason = IFX_MAX_REASON;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Answered Call" );

  printf("<LTQ_CVOIP_ATACmdHdlr> Entry \n");
	if (LTQ_ATCmd_ByteValueGet(LTQ_AnswerCmd_CtxId, pRxCmdHdl, &ucCnTxId) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
        return IFX_FAILURE;
    }
        printf("Context ID: %d \n",ucCnTxId);

	//Send OK to CVoIP	
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId);
	
	//while(IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId) != IFX_SUCCESS);
	printf(">>>>>>> [[ Sent OK From LTQ_CVOIP_ATACmdHdlr ]]\n");

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId, "Peer Answered the Call" );
	
	//Get All the Call related parameters..
  LTQ_ATCmd_ByteValueGet(LTQ_AnswerCmd_CallId, pRxCmdHdl,&ucCallId);
  LTQ_ATCmd_ByteValueGet(LTQ_AnswerCmd_ChannelId, pRxCmdHdl,&ucChanelId);
	
	// Construct the Event for CVoIP FSM
  evtInfo.uiId = ucCallId;
	evtInfo.eEvent = IFX_DECT_EVT_CallAnswer;
  
    printf("<LTQ_CVOIP_ATACmdHdlr> Answered Call ID %d \n",ucCallId);

	if( IFX_SUCCESS !=
      IFX_DECT_GetEndptInfoByInstance(ucCnTxId-1, &pxEndptInfo) )
   {
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Could Not Get Handset Info (Invalid Instance Number)" );
      return IFX_FAILURE;
   }
   
   printf("<LTQ_CVOIP_ATACmdHdlr> Calling FSM Handler\n");
	 pxEndptInfo -> unDectChannel = ucChanelId ;	
	if( IFX_SUCCESS != 
			LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Remote Call Answer Failed !!" );
      return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_CREGCmdHdlr 
 *  Description     : This routine processes CREG Command received from COSIC VoIP FP. 
 *  Input Values    : pointer to AT Command handler 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return 
LTQ_CVOIP_CREGCmdHdlr(void *pRxCmdHdl)
{
	uchar8 ucCnTxId=0,ucRegStatus=0,ucValue=0;
	x_LTQ_CVOIP_DECT_HS_NotifyInfo xHSAttachInfo = {0};

      printf("<LTQ_CVOIP_CREGCmdHdlr> Entry \n");
	if (LTQ_ATCmd_ByteValueGet(LTQ_CREGCmd_CtxId, pRxCmdHdl, &ucCnTxId) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
				printf("\n<LTQ_CVOIP_CREGCmdHdlr> Getting ContextID Failed \n");
        return IFX_FAILURE;
    }

	if (LTQ_ATCmd_ByteValueGet(LTQ_CREGCmd_Status, pRxCmdHdl, &ucRegStatus) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting Reg Staus value failed...." );
				printf("<LTQ_CVOIP_CREGCmdHdlr> Getting Reg Status Failed \n");
				ucRegStatus = 0;
    }
		if (ucRegStatus == 0  && LTQ_ATCmd_ByteValueGet(LTQ_CREGCmd_Cap, pRxCmdHdl, &ucValue) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting Capab value failed...." );
			 ucValue=0;
    }
	  else if(ucRegStatus == 3){/*Subs timer expired*/
			iMode=0;
		}else if(ucRegStatus == 4){/*paging on*/
			iMode=2;
		}else if(ucRegStatus == 5){/*paging OFF*/
			iMode=0;
		}else if(ucRegStatus == 6){/*In subs mode*/
			iMode=1;
		}
	printf("\n <LTQ_CVOIP_CREGCmdHdlr> Reg Status : %d \n",ucRegStatus);

	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId);
	//while(IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId) != IFX_SUCCESS);
	printf(">>>>>>> [[ Sent OK From LTQ_CVOIP_CREGCmdHdlr ]]\n");
		if(ucRegStatus > 2 ){
			return IFX_SUCCESS;
		}
	memset(&xHSAttachInfo,0,sizeof(xHSAttachInfo));

	//Fill the event related and HS Info...
	xHSAttachInfo.ucHandSet = ucCnTxId;
	xHSAttachInfo.eEvent = ucRegStatus;
	xHSAttachInfo.uiTermCap = ucValue;
	//Generate the event Based on Event type and post it.
	if( LTQ_CVOIP_DECT_HS_Info_Notify(&xHSAttachInfo) != IFX_SUCCESS){
				printf("<LTQ_CVOIP_DECT_HS_Info_Notify> Status Failed \n");
        return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_ProcessATHCmd 
 *  Description     : This routine processes ATH Command buffer received from COSIC VoIP FP. 
 *  Input Values    : pointer to ATH Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return
LTQ_CVOIP_ATHCmdHdlr(void **pRxCmdHdl)
{
	uchar8 ucCnTxId=0;
	uchar8 ucCallId=0;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;

	printf("<LTQ_CVOIP_ATHCmdHdlr>  Entry \n");
  if (LTQ_ATCmd_ByteValueGet(LTQ_HangUpCmd_CtxId, pRxCmdHdl, &ucCnTxId) != IFX_SUCCESS){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
        return IFX_FAILURE;
    }
	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId);
	//while(IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCnTxId) != IFX_SUCCESS);
	printf(">>>>>> [[ Sent OK From LTQ_CVOIP_ATHCmdHdlr ]]\n");

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId, "Peer Hanged the  Call" );

  LTQ_ATCmd_ByteValueGet(LTQ_HangUpCmd_CallId, pRxCmdHdl, &ucCallId);
  printf("<LTQ_CVOIP_ATHCmdHdlr>  Call ID %d \n",ucCallId);
  
	//Construct the Event for CVoIP-DECT FSM
  evtInfo.uiId = ucCallId;
  evtInfo.eEvent = IFX_DECT_EVT_CallRelease;
	if( IFX_SUCCESS !=
      IFX_DECT_GetEndptInfoByInstance(ucCnTxId-1, &pxEndptInfo) )
   {
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Could Not Get Handset Info (Invalid Instance Number)" );
      return IFX_FAILURE;
   }
	printf("<LTQ_CVOIP_ATHCmdHdlr> Got the End point Info %d \n",ucCnTxId);

  if( IFX_SUCCESS !=
      LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
  {
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
           pxEndptInfo->szEndptId, "!! Remote Call Answer Failed !!" );
      return IFX_FAILURE;
  }

  return IFX_SUCCESS;
}
/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_TPCCmdHdlr 
 *  Description     : This API process the TPC command received from CVoIP  
 *  Input Values    : pointer to CPIN Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_RAMCmdHdlr(void *pRxCmdHdl)
{
  uchar8 ucByteVal = 0;
	x_IFX_VMAPI_DectXRAM xXram ;

  printf("<LTQ_CVOIP_RAMCmdHdlr> Entry \n");
  //Send OK to CVoIP  
  IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

    //Get the old XRAM parms from rc.conf
	memset(&xXram, 0 , sizeof(x_IFX_VMAPI_DectXRAM));
  if( IFX_CIF_XRAMGet( &xXram ) != IFX_SUCCESS)
    return IFX_FAILURE;

 /* if( LTQ_ATCmd_ByteValueGet(LTQ_RamParamsCmd_MemType, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
      xXram.ucByte1 = ucByteVal;
  if( LTQ_ATCmd_ByteValueGet(LTQ_RamParamsCmd_Address, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
      xXram.ucByte2 = ucByteVal;*/
  if( LTQ_ATCmd_ByteValueGet(LTQ_RamParamsCmd_Value, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
      xXram.ucByte3 = ucByteVal;
  
	//Set the values into RC.CONF
     IFX_CIF_StoreValuesFromModem(IFX_VMAPI_XRAM_TEST,&xXram);

  return IFX_SUCCESS;

}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_TPCCmdHdlr 
 *  Description     : This API process the TPC command received from CVoIP  
 *  Input Values    : pointer to CPIN Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_TPCCmdHdlr(void *pRxCmdHdl)
{
	x_IFX_VMAPI_TransmitPowerParam xTpc ;
 
  printf("<LTQ_CVOIP_TPCmdHdlr> Entry \n");
  //Send OK to CVoIP  
  IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

    //Get the old Tpcparm parms from rc.conf
	memset(&xTpc, 0 , sizeof(x_IFX_VMAPI_TransmitPowerParam));
	if(	IFX_CIF_TPCValGet( &xTpc ) != IFX_SUCCESS)
		return IFX_FAILURE;
  LTQ_ATCmd_ByteValueGet(2,pRxCmdHdl,&xTpc.ucTuneDigitalRef);
  LTQ_ATCmd_ByteValueGet(3,pRxCmdHdl,&xTpc.ucPABiasRef);
  LTQ_ATCmd_ByteValueGet(4,pRxCmdHdl,&xTpc.ucPowerOffset0);
  LTQ_ATCmd_ByteValueGet(5,pRxCmdHdl,&xTpc.ucPowerOffset1);
  LTQ_ATCmd_ByteValueGet(6,pRxCmdHdl,&xTpc.ucPowerOffset2);
  LTQ_ATCmd_ByteValueGet(7,pRxCmdHdl,&xTpc.ucPowerOffset3);
  LTQ_ATCmd_ByteValueGet(8,pRxCmdHdl,&xTpc.ucPowerOffset4);
  LTQ_ATCmd_ByteValueGet(9,pRxCmdHdl,&xTpc.ucTD1);
  LTQ_ATCmd_ByteValueGet(10,pRxCmdHdl,&xTpc.ucTD2);
  LTQ_ATCmd_ByteValueGet(11,pRxCmdHdl,&xTpc.ucTD3);
  LTQ_ATCmd_ByteValueGet(12,pRxCmdHdl,&xTpc.ucPA1);
  LTQ_ATCmd_ByteValueGet(13,pRxCmdHdl,&xTpc.ucPA2);
  LTQ_ATCmd_ByteValueGet(14,pRxCmdHdl,&xTpc.ucPA3);
  LTQ_ATCmd_ByteValueGet(15,pRxCmdHdl,&xTpc.ucTuneDigital);
  LTQ_ATCmd_ByteValueGet(16,pRxCmdHdl,&xTpc.ucTXPOW_0);
  LTQ_ATCmd_ByteValueGet(17,pRxCmdHdl,&xTpc.ucTXPOW_1);
	//Set the values into RC.CONF
     IFX_CIF_StoreValuesFromModem(IFX_VMAPI_TRANS_POWER_TEST,&xTpc);

  return IFX_SUCCESS;

}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_CPINCmdHdlr 
 *  Description     : This API process the CPIN command received from CVoIP  
 *  Input Values    : pointer to CPIN Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_CPINCmdHdlr(void *pRxCmdHdl)
{
	uchar8 *ucBasePin = NULL;

  printf("<LTQ_CVOIP_CPINCmdHdlr> Entry \n");
	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);
		
	ucBasePin = LTQ_ATCmd_ValueGet(LTQ_BasePinCmd_Pin, pRxCmdHdl) ;
   if(ucBasePin == NULL){ 
			return IFX_FAILURE;
    }else if(IFX_CIF_BS_PinSet((char8*)ucBasePin) != IFX_SUCCESS){
				printf("<LTQ_CVOIP_CPINCmdHdlr> Set IFX_CIF_BS_PinSet Failed\n");
				return IFX_FAIL;
		}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_GCAPCmdHdlr 
 *  Description     : This API process the GCAP command received from CVoIP  
 *  Input Values    : pointer to CPIN Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_GCAPCmdHdlr(void *pRxCmdHdl)
{
  uchar8 ucEncryption = 0;

  printf("<LTQ_CVOIP_CPINCmdHdlr> Entry \n");
  //Send OK to CVoIP  
  IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

	if( LTQ_ATCmd_ByteValueGet(LTQ_BaseCapCmd_Encryption, pRxCmdHdl, &ucEncryption) == IFX_SUCCESS){
    if(IFX_CIF_BS_EncryptionSet(ucEncryption) != IFX_SUCCESS){
        printf("<LTQ_CVOIP_CPINCmdHdlr> Set IFX_CIF_BS_Encryption Failed\n");
        return IFX_FAIL;
    }
	} else{
		return IFX_FAIL;
	}
  return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_BMCCmdHdlr 
 *  Description     : This API process the BMC command received from CVoIP  
 *  Input Values    : pointer to BMC Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_BMCCmdHdlr(void *pRxCmdHdl)
{
	uchar8 ucByteVal = 0;
	x_IFX_VMAPI_DectBMCParams xBmcNew = {{{{0}}}};
  
	printf("<LTQ_CVOIP_BMCCmdHdlr> Entry \n");
	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

		//Get the old bmcparm parms from rc.conf
		memset(&xBmcNew,0,sizeof(xBmcNew));
		if (IFX_CIF_BMCRegparamGet(&xBmcNew) != IFX_SUCCESS)
			return IFX_FAILURE;

			
//Copy the new values form the atCMD Buffer....

	if(	LTQ_ATCmd_ByteValueGet(LTQ_BMCCmd_Rssifree, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS) 
			xBmcNew.ucDectRSSIFreeLevel = ucByteVal;
	if(	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_Rssibusy, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
		 xBmcNew.ucDectRSSIBusyLevel = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_BearerChangelimit, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectBearerChgLim = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_DefAntenna, pRxCmdHdl,&ucByteVal) == IFX_SUCCESS)
		 xBmcNew.ucDectDefaultAntenna = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_Osf, pRxCmdHdl,&ucByteVal) == IFX_SUCCESS)
			 xBmcNew.ucDectWOPNSF = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_Wsf, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectWWSF  = ucByteVal;;
 	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_ControlReg, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectCNTUPCtrlReg = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_DelayReg, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectDelayReg = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_Gsmc, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectHandOverEvalper = ucByteVal;
	if ( LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_HOPeriod, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectSYNCMCtrlReg = ucByteVal; 	
	if ( LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_NormalBattmeas, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectReserved_0 = ucByteVal; 	
	if ( LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_NormalTcoRR, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectReserved_1 = ucByteVal; 	
	if ( LTQ_ATCmd_ByteValueGet(  LTQ_BMCCmd_GreenBattmeas, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectReserved_2 = ucByteVal; 	
	if ( LTQ_ATCmd_ByteValueGet( LTQ_BMCCmd_GreenTcoRR, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectReserved_3 = ucByteVal; 	
	if ( LTQ_ATCmd_ByteValueGet(  LTQ_BMCCmd_PowerLevel, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectReserved_4 = ucByteVal; 	
	if ( LTQ_ATCmd_ByteValueGet(  LTQ_BMCCmd_PowerAlgorithm, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xBmcNew.ucDectReserved_5 = ucByteVal; 	

	
		 //Set the values into RC.CONF
		 IFX_CIF_StoreValuesFromModem(IFX_VMAPI_BMC_REG_PARAMS_TEST,&xBmcNew);	

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_FREQCmdHdlr 
 *  Description     : This API process the FREQ command received from CVoIP  
 *  Input Values    : pointer to FREQ Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_FREQCmdHdlr(void *pRxCmdHdl)
{
	x_IFX_VMAPI_DectCountrySettings xCtryset={{{{0}}}};
	uchar8 ucByteVal = 0;
  printf("<LTQ_CVOIP_BMCCmdHdlr> Entry \n");

	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);
    //Get the old bmcparm parms from rc.conf

	//Get the old country Settings value
	if ( IFX_CIF_CtryParamGet ( &xCtryset) != IFX_SUCCESS)
		return IFX_FAILURE;

		//Get the new values from the ATCmd...
		if( LTQ_ATCmd_ByteValueGet( LTQ_FreqCmd_TxOff, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
				xCtryset.ucFreqTxOffset = ucByteVal;
    if( LTQ_ATCmd_ByteValueGet( LTQ_FreqCmd_RxOff, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
				xCtryset.ucFreqRxOffset = ucByteVal;
     if( LTQ_ATCmd_ByteValueGet(LTQ_FreqCmd_Range, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
				xCtryset.ucFreqRan = ucByteVal;

			//Need to check these values...
       if ( LTQ_ATCmd_ByteValueGet( LTQ_FreqCmd_Eci, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
						xCtryset.ucEci = ucByteVal;
       if ( LTQ_ATCmd_ByteValueGet( LTQ_FreqCmd_ChMaskHigh, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
						xCtryset.ucChmaskHigh = ucByteVal;
       if ( LTQ_ATCmd_ByteValueGet(LTQ_FreqCmd_ChMaskLow, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
						xCtryset.ucChmaskLow = ucByteVal;

			IFX_CIF_StoreValuesFromModem(IFX_VMAPI_COUNTRY_SETTINGS_TEST,&xCtryset);

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_GFSKCmdHdlr 
 *  Description     : This API process the GFSK command received from CVoIP  
 *  Input Values    : pointer to GFSK Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_GFSKCmdHdlr(void *pRxCmdHdl)
{
	x_IFX_VMAPI_DectGFSKVal xGfsk={{{{0}}}};
	uchar8 ucByteVal = 0;

	//Send OK to CVoIP 
		memset(&xGfsk, 0 , sizeof(x_IFX_VMAPI_DectGFSKVal)); 
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

	//Get the old GFSK values
	if ( IFX_CIF_GaussianValGet(	&xGfsk ) != IFX_SUCCESS )
			return IFX_FAILURE;

	if ( LTQ_ATCmd_ByteValueGet(	LTQ_GfskCmd_HI, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
			xGfsk.ucDectGFSKHI = ucByteVal;

	if ( LTQ_ATCmd_ByteValueGet(  LTQ_GfskCmd_LOW, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
	 xGfsk.ucDectGFSKLOW = ucByteVal;
	
	//Store the values in rc.conf
	IFX_CIF_StoreValuesFromModem(IFX_VMAPI_GFSK_TEST,&xGfsk);


	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_RFPICmdHdlr 
 *  Description     : This API process the RFPI command received from CVoIP  
 *  Input Values    : pointer to RFPI Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_RFPICmdHdlr(void *pRxCmdHdl)
{
	x_IFX_VMAPI_DectRfpi xRfpi={{{{0}}}};
	uchar8 ucByteVal = 0;	

	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

	//Get t he old RFPI values
	memset(&xRfpi , 0 , sizeof(x_IFX_VMAPI_DectRfpi));
	if ( IFX_CIF_RFPIGet( &xRfpi ) != IFX_SUCCESS )
		return IFX_FAILURE;

	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_RfpiCmd_Byte0, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfpi.ucByte1 = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_RfpiCmd_Byte1, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfpi.ucByte2 = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_RfpiCmd_Byte2, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfpi.ucByte3 = ucByteVal;
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_RfpiCmd_Byte3, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfpi.ucByte4 = ucByteVal; 
	if ( 	LTQ_ATCmd_ByteValueGet( LTQ_RfpiCmd_Byte4, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfpi.ucByte5 = ucByteVal;

	//Store the values into RC.conf
	IFX_CIF_StoreValuesFromModem(IFX_VMAPI_RFPI_TEST,&xRfpi);

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_RFMODCmdHdlr 
 *  Description     : This API process the RFMOD command received from CVoIP  
 *  Input Values    : pointer to RFMOD Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_RFMODCmdHdlr(void *pRxCmdHdl)
{
 x_IFX_VMAPI_RFMode xRfmode={{{{0}}}};
	uchar8 ucByteVal = 0;
	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

	//Get old rfmod values
	memset(&xRfmode , 0 , sizeof(x_IFX_VMAPI_RFMode));
	if( IFX_CIF_RFMODGet ( &xRfmode ) != IFX_SUCCESS)
		return IFX_FAILURE;


	if(	LTQ_ATCmd_ByteValueGet( LTQ_RfModeCmd_TxtTestMode, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfmode.ucTxtestmode = ucByteVal ;
	if(	LTQ_ATCmd_ByteValueGet( LTQ_RfModeCmd_Channel, pRxCmdHdl,  &ucByteVal) == IFX_SUCCESS)
		xRfmode.ucChannel = ucByteVal;
	if(	LTQ_ATCmd_ByteValueGet( LTQ_RfModeCmd_Slot, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
		 xRfmode.ucSlot = ucByteVal;

	//Store the values into rc.conf	
		IFX_CIF_StoreValuesFromModem(IFX_VMAPI_RF_MODE_TEST,&xRfmode);
	return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_OSCTRIMCmdHdlr 
 *  Description     : This API process the OSCTRIM command received from CVoIP  
 *  Input Values    : pointer to OSCTRIM Command buffer
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_OSCTRIMCmdHdlr(void *pRxCmdHdl)
{
	x_IFX_VMAPI_DectOscTrimVal xOscTrim={{{{0}}}};
	uchar8 ucByteVal = 0 ;
	//Send OK to CVoIP  
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, 0);

	//Get the old osctrim values
	memset(&xOscTrim ,  0, sizeof (x_IFX_VMAPI_DectOscTrimVal));
	if(IFX_CIF_OscTrimParamGet( &xOscTrim ) != IFX_SUCCESS)
		return IFX_FAILURE;
	
	if ( LTQ_ATCmd_ByteValueGet( LTQ_OscTrimCmd_HI, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
		xOscTrim.ucDectOscTrimValHI = ucByteVal;
	if ( LTQ_ATCmd_ByteValueGet(  LTQ_OscTrimCmd_LOW, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
		xOscTrim.ucDectOscTrimValLOW = ucByteVal;
	if ( LTQ_ATCmd_ByteValueGet( LTQ_OscTrimCmd_P10, pRxCmdHdl, &ucByteVal) == IFX_SUCCESS)
		xOscTrim.ucDectP10Status = ucByteVal;

	//Store the values in to rc.conf
	IFX_CIF_StoreValuesFromModem(IFX_VMAPI_OSC_TRIM_TEST,&xOscTrim);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_ProcessATCmd 
 *  Description     : This routine processes AT Command buffer received from COSIC VoIP FP. 
 *  Input Values    : pointer to AT Command buffer
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/
e_IFX_Return 
LTQ_CVOIP_ProcessATCmd(uchar8 *pucATCmd)
{
  //char8 acBuff[LTQ_CVOIP_MAX_ATCMD]={0};
	e_LTQ_ATCmd_Type eCmdType;
	void *pRxCmdHdl = NULL; 
	uchar8 ucCmdLength = 0;
	uchar8 ucCntxt=0;
	uint16 uilen=strlen((char8 *)pucATCmd);
	//uchar8  *apucATCmdParams[LTQ_ATCMD_MAX_INDEX];
	//uchar8  aucATCmdParams[LTQ_ATCMD_MAX_INDEX];
	
	printf("$$$$$$$ <LTQ_CVOIP_ProcessATCmd> cmd recvd is %s\n",pucATCmd);
	while(ucCmdLength<uilen){
	printf("Decoded length %d String length %d\n",ucCmdLength,uilen);	
	eCmdType = LTQ_ATCmd_Parse(pucATCmd, &pRxCmdHdl, &ucCmdLength);

	switch(eCmdType){
		case LTQ_ATCmd_Init:
#if 0
			if (LTQ_ATCmd_ByteValueGet(1, pRxCmdHdl, &ucCntxt) != IFX_SUCCESS){
      	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Getting contxt value failed...." );
				printf("<LTQ_CVOIP_ProcessATCmd>  getvalue failed \n");
				return IFX_FAILURE;
			}
#else
      ucCntxt = 0;
#endif
			printf("<LTQ_CVOIP_ProcessATCmd> param is %d\n",ucCntxt);
			if (vbCVoipInitialized != IFX_TRUE)//aarif
				LTQ_CVOIP_INITCmdHdlr(ucCntxt);
			else{
					printf("CVOIP is already initialized........\n");
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Ok, NULL, ucCntxt);
					// Send spcm for configuration
				  IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Config_PCM, NULL, ucCntxt);
				}
			break;
		//case LTQ_ATCmd_DTMF:
		case LTQ_ATCmd_Capabilities:
			#if 0
			for (i=1; i<LTQ_BaseCapCmd_Rekeying+1; i++){
				if (LTQ_ATCmd_ByteValueGet(i, pRxCmdHdl, vaucBaseCapabParams+i) != IFX_SUCCESS){
      		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               	"Getting contxt value failed...." );
					printf("<LTQ_CVOIP_ProcessATCmd>  getvalue failed \n");
					return IFX_FAILURE;
				}
			}
		#endif
			LTQ_CVOIP_GCAPCmdHdlr(pRxCmdHdl);
			printf("<LTQ_CVOIP_ProcessATCmd> param is %d\n",ucCntxt);
			break;
		
			case LTQ_ATCmd_Dial:
				LTQ_CVOIP_ATDCmdHdlr(pRxCmdHdl);
			break;
			
			case LTQ_ATCmd_DTMF:
					LTQ_CVOIP_VTSCmdHdlr(pRxCmdHdl);
			break;

			case LTQ_ATCmd_Accept:
					LTQ_CVOIP_ATCACmdHdlr(pRxCmdHdl);
			break;

			case LTQ_ATCmd_Answer:
					LTQ_CVOIP_ATACmdHdlr(pRxCmdHdl);
			break;		
		
			case LTQ_ATCmd_Hangup:
							LTQ_CVOIP_ATHCmdHdlr(pRxCmdHdl);
			break;	

			case LTQ_ATCmd_CREG:
		      LTQ_CVOIP_CREGCmdHdlr(pRxCmdHdl);
      break;
		
		case  LTQ_ATCmd_TBR06: /*!< TBR6 Test */
		     ///LTQ_CVOIP_TBR06LTQ_CVOIP_TBR06CmdHdlr(pRxCmdHdl);
    break;
    case LTQ_ATCmd_Pin : /*!< Dect System */
		      LTQ_CVOIP_CPINCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_Diagnostics: /*!< Dect Diagnostics */
		      //LTQ_CVOIP_CREGCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_TPC: /*!< Transmit Power Measurement Test */
		      LTQ_CVOIP_TPCCmdHdlr(pRxCmdHdl);
    break;
    case LTQ_ATCmd_RfMode : /*!< RF Mode Test */
		      LTQ_CVOIP_RFMODCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_Rfpi: /*!< RFPI */
		      LTQ_CVOIP_RFPICmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_RAM: /*!< XRAM */
		      LTQ_CVOIP_RAMCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_Freq: /*!< DECT Country */
		      LTQ_CVOIP_FREQCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_BMC: /*!< DECT BMC */
		      LTQ_CVOIP_BMCCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_OscTrim: /*!< DECT Oscillator Trimming */
		      LTQ_CVOIP_OSCTRIMCmdHdlr(pRxCmdHdl);
    break;
    case  LTQ_ATCmd_Gfsk: /*!< DECT GFSK */
		      LTQ_CVOIP_GFSKCmdHdlr(pRxCmdHdl);
    break;
	
			default:
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Invalid AT Command...." );
			break;
	}

		LTQ_ATCmd_FreeHandle(pRxCmdHdl);
	}
  return IFX_SUCCESS;
}


/******************************************************************************
 *  Function Name   : LTQ_CVOIP_CbRegisterWithCmgr
 *  Description     : This routine registers callback functions for given DECT
 *	                  endpoint with call manager. This routine is called after
 *	                  receiving Attached indication from the Cosic VoIP
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info
 *  Output Values	  : -
 *  Return Value    : Returns IFX_SUCCESS if callbacks are registered with call
 *                    manager , else IFX_FAILURE.
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
LTQ_CVOIP_CbRegisterWithCmgr(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{
	x_IFX_CMGR_CallBackList xCallBacks = {0};
	char8 aszEndPointId[1][IFX_MAX_ENDPOINTID_LEN];
	
	xCallBacks.pfnCallIncoming = LTQ_CVOIP_CallIncoming;
	xCallBacks.pfnRemoteCallAccept = LTQ_CVOIP_RemoteCallAccept;
	xCallBacks.pfnRemoteCallAnswer = LTQ_CVOIP_RemoteCallAnswer;
	xCallBacks.pfnRemoteCallHold = LTQ_CVOIP_RemoteCallHold;
	xCallBacks.pfnRemoteCallResume = LTQ_CVOIP_RemoteCallResume;
	xCallBacks.pfnCallHoldRsp =  LTQ_CVOIP_CallHoldResponse;
	xCallBacks.pfnCallResumeRsp = LTQ_CVOIP_CallResumeResponse;
	xCallBacks.pfnRemoteCallRelease = LTQ_CVOIP_RemoteCallRelease;
	//xCallBacks.pfnCallFwdInfo = LTQ_CVOIP_CallForwardInfo;
	xCallBacks.pfnConfStatus = LTQ_CVOIP_ConfStatus;
 // xCallBacks.pfnARD_Status = LTQ_CVOIP_AutoRedialStatus;
 // xCallBacks.pfnARD_NtfnRcv = LTQ_CVOIP_AutoRedialNotifyReceived;
 // xCallBacks.pfnARD_Reg = LTQ_CVOIP_AutoRedialRegister;
  xCallBacks.pfnBlindTxReq = LTQ_CVOIP_BlindTxRequest;
  xCallBacks.pfnBlindTxStatus = LTQ_CVOIP_BlindTxStatus;
  xCallBacks.pfnAttendedTxReq = LTQ_CVOIP_AttendedTxRequest;
  xCallBacks.pfnAttendedTxStatus = LTQ_CVOIP_AttendedTxStatus;
  xCallBacks.pfnCallIdRep = LTQ_CVOIP_CallIdReplace;
	/* List Access */
	/*	xCallBacks.pfnListAccess	= LTQ_CVOIP_Dummy;
	xCallBacks.pfnFreeVmapiObj = LTQ_CVOIP_Dummy;*/

  /*Date Time Sync*/
	/*xCallBacks.pfnDateTime	= LTQ_CVOIP_Dummy;*/

	//Callbacks for codec negotiation
	xCallBacks.pfnGetMediaParams = LTQ_CVOIP_GetMediaParams; 
	xCallBacks.pfnMediaNegReq    = LTQ_CVOIP_MediaNegReq;
	xCallBacks.pfnMediaNegRsp    = LTQ_CVOIP_MediaNegResp;
#ifdef MESSAGE_SUPPORT
	xCallBacks.pfnMsgRcv     = LTQ_CVOIP_Dummy;
	xCallBacks.pfnMsgStatus  = LTQ_CVOIP_Dummy;
#endif /* MESSAGE_SUPPORT */	

	/*xCallBacks.pfnVM_NtfnRcv = LTQ_CVOIP_Dummy;*/

	strcpy(aszEndPointId[0], pxEndptInfo->szEndptId);
	return IFX_CMGR_CallBacksRegister(aszEndPointId, 1, &xCallBacks);
}

/******************************************************************************
 *  Function Name   : IFX_CVOIP_AgentInit
 *  Description     : This routine initializes DECT stack, DECT endpoints FSM.
 *	                  Registered DECT handsets information is passed to DECT 
 *	                  stack during initialization.
 *  Input Values    : aszEndPointId - list of DECT handsets to be initialized.
 *	                  ucNoOfEndpts - No of DECT handsets to be initialized.
 *	                  ucDectDbgId - DECT Agent's debug id.
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if DECT agent is initialized, else
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/

e_IFX_Return IFX_CVOIP_AgentInit(
	                            IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
	                            IN uchar8 ucNoOfEndpts,
                              IN uchar8 ucDectDbgId)
{
	x_IFX_CIF_DectSubsInfo xPPSubsInfo[IFX_MMGR_MAX_DECT_CHANNELS];
	x_IFX_CIF_DectSubsInfo* pxPPSubsInfo = 0;
	x_IFX_DECT_EndptFsmInfo* pxDectEndpt = 0;
	uchar8 ucEndptCount = 0;
	e_IFX_Return eRet = IFX_FAILURE;
	vucDectAgnetModId = ucDectDbgId;

	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Initializing CVOIP Agent.....");
	printf("CVOIP_AgentInit, Entry.\n");

#if 0
	if (LTQ_CVOIP_Init() != IFX_SUCCESS){
		IFX_DBGC( vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
      "Initializing COSIC VoIP FP chip failed");
	}
#endif

	vucDectAgnetModId = ucDectDbgId;
	
	if( ucNoOfEndpts > IFX_MMGR_MAX_DECT_CHANNELS )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
			 "Endpoints exceeded IFX_MMGR_MAX_DECT_CHANNELS");
		return eRet;
	}

#if 1
	pxDectEndpt = vaxDectEndptFsmInfo;
	pxPPSubsInfo = &xPPSubsInfo[0];
	while( ucEndptCount < ucNoOfEndpts )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				"Initializing CVOIP Endpoint", aszEndPointId[ucEndptCount]);
		strcpy(pxDectEndpt->szEndptId, aszEndPointId[ucEndptCount]);
		/*
		 * Retrieve subscription info from configuration. If subscription info is
		 * available for the endpoint, then set instance number. Otherwise no 
		 * handset is using this endpoint, so assign invalid instance number.
		 */
		if(IFX_SUCCESS != IFX_CIF_DectSubsInfoGet(pxDectEndpt->szEndptId, 
				                          pxPPSubsInfo ) )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxDectEndpt->szEndptId, 
				"!! Could Not Read Subscription Infomration !!");
		}

			memcpy(&pxDectEndpt->xDECTSubsInfo, 
							pxPPSubsInfo, sizeof(x_IFX_CIF_DectSubsInfo));
		if( pxPPSubsInfo->bIsRegistered )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxDectEndpt->szEndptId, "This Endpoint Is Registered !!");
						//Register callbacks with call manager
						pxDectEndpt->ucInstance = ucEndptCount;
						if( IFX_SUCCESS != LTQ_CVOIP_CbRegisterWithCmgr(pxDectEndpt) )
						{
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, 
								IFX_DBG_ATA_STRING_INFO, pxDectEndpt->szEndptId, 
								"Could Not Register Callbacks With Call Manager");
						}
						else
						{
							pxDectEndpt->bPPAttached = IFX_TRUE;
							printf(">>>>>>> Handset %s Registered with CallManager\n",pxDectEndpt->szEndptId);
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_NORMAL,
								IFX_DBG_ATA_STRING_INFO,	pxDectEndpt->szEndptId, 
								"Handset by default is moved to attached state for handling IOP issues");
            }
		}
		else 
		{
			//This instance does not registered, set instance number to invalid
				printf(">>>>>>> Handset %s Not Registered \n",pxDectEndpt->szEndptId);
			pxDectEndpt->ucInstance = IFX_DECT_INVALID_INSTANCE;
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxDectEndpt->szEndptId, "!! This Endpoint Is Not Registered !!");
		}
		++pxPPSubsInfo;
		++pxDectEndpt;
		++ucEndptCount;
	}
#endif

  //aucBuf[0] = '?';
  //aucBuf[1] = 0;
	//IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Capabilities, &pucBuf, 0);
    
	IFX_DBGC( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		"CVOIP Agent Initialized");
	printf(">>>>>>>> CVOIP_AgentInit, success.\n");
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetStateStr
 *  Description     : This routine is used to get human redable string for a 
 *                    given DECT FSM state. 
 *  Input Values    : eState - FSM state type.
 *  Output Values   : 
 *  Return Value    : Returns pointer to string. 
 *  Notes           :
 ******************************************************************************/
char8* IFX_DECT_GetStateStr( IN e_IFX_DECT_States eState )
{
  static char8* aszStates[IFX_DECT_STATE_MAX+1] =
  {
    "Handset Is In IDLE State",            /** Idle*/
    "Handset Is In PROGRESS State",          /** Incall - Alerting(ringing) */
    "Handset Is In ACTIVE State",          /** Call active/in conversation */
    "!!** Handset Is In INVALID State **!!"
  };

  if( eState > IFX_DECT_STATE_ACTIVE )
    eState = IFX_DECT_STATE_MAX;
  return aszStates[eState];
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEventStr 
 *  Description     : This routine is used to get human readable event string.
 *  Input Values    : eEvent - event type
 *  Output Values   : 
 *  Return Value    : Returns pointer to string. 
 *  Notes           :
 ******************************************************************************/
char8* IFX_DECT_GetEventStr( IN  e_IFX_DECT_Event eEvent)
{
  static char8* aszDectEvents[IFX_DECT_EventMax+1] =
  {
    "IFX_DECT_EVT_PP_OffHook",        /** Off-hook -- Setup from PP */
    "IFX_DECT_EVT_PP_DialedDigitReceived",         /** On-hook -- Call Release PP */
    "IFX_DECT_EVT_IncomingCall",  /** Incoming call */
    "IFX_DECT_EVT_RmtAccept",     /** Remote accepted call */
    "IFX_DECT_EVT_RmtAnswer",     /** Remote answered call */
    "IFX_DECT_EVT_ReleaseCall",   /** Release call */
    "IFX_DECT_EVT_RmtHold",       /** Remote held call */
    "IFX_DECT_EVT_RmtResume",     /** Remote resumed call */
    "IFX_DECT_EVT_CallAccept",     /** Remote accepted call */
    "IFX_DECT_EVT_CallAnswer",     /** Remote answered call */
    "IFX_DECT_EVT_CallRelease",   /** Release call */
    /* Paging key events */
    "IFX_DECT_EVT_Paging",        /** Paging button pressed */
    "IFX_DECT_EventMax"
  };

  if( eEvent > IFX_DECT_EVT_Paging )
    eEvent = IFX_DECT_EventMax;
  return aszDectEvents[eEvent];
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetMmgrCodec 
 *  Description     : This function converts CMGR codec type to MMGR codec type.
 *                    If codec is not supported by DECT system, then
 *                    IFX_MMGR_CODEC_NONE is returned. 
 *  Input Values    : uiCodec - CMGR codec type.
 *  Output Values	  : 
 *  Return Value    : Returns valid MMGR codec if DECT system supports, else
 *                    returns IFX_MMGR_CODEC_NONE.
 *  Notes           :
 ******************************************************************************/
e_IFX_MMGR_CodecType IFX_DECT_GetMmgrCodec(uint32 uiCodec)
{
	e_IFX_MMGR_CodecType eMmgrCodecType = IFX_MMGR_CODEC_NONE;
	switch(uiCodec)
	{
	case IFX_G711_ALAW: 
		eMmgrCodecType = IFX_MMGR_CODEC_ALAW;
		break;
	case IFX_G711_ULAW:
		eMmgrCodecType = IFX_MMGR_CODEC_MLAW;
		break;
	case IFX_G726_32: 
		eMmgrCodecType = IFX_MMGR_CODEC_G726_32;
		break;
	case IFX_G722_64:
		eMmgrCodecType = IFX_MMGR_CODEC_G722_64;
		break;
	/*
	case IFX_G722_1_24:
		eMmgrCodecType = IFX_MMGR_CODEC_G722_1_24;
		break;
	case IFX_G722_1_32:
		eMmgrCodecType = IFX_MMGR_CODEC_G722_1_32;
		bReturn = IFX_TRUE;
		break; */
	default:
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Unknown Codec: Not Supported On DECT System");
		break;
	}

	return eMmgrCodecType;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConvertCodecToMMGR
 *  Description     : This routine converts common(CMGR) codec list to MMGR 
 *                    codec list.
 *  Input Values    : pxList - CMGR codec list .
 *  Output Values	  : pxMmgrList - MMGR codec list.
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : If none of the CMGR codecs are supported by DECT system,
 *                    then pxMmgrList contains zero codec on return.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConvertCodecToMMGR(
	                      OUT x_IFX_MMGR_CodecList* pxMmgrList, 
	                      IN x_IFX_CodecList* pxList)
{
	x_IFX_MMGR_CodecInfo* pxMMGRCodec = pxMmgrList->axCodecs;
	x_IFX_Codec* pxCodec =  pxList->axCodec;
	uchar8 ucCount = 0;
	
	pxMmgrList->ucNoOfCodecs = 0;
	for( ; ucCount < pxList->unNoOfCodecs; ++ucCount, ++pxCodec)
	{
		if( (pxMMGRCodec->eCodecType = 
						IFX_DECT_GetMmgrCodec(pxCodec->uiCodec)) != IFX_MMGR_CODEC_NONE ) {
			++pxMmgrList->ucNoOfCodecs;
			++pxMMGRCodec;
		}
	}
	
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetCmgrCodec 
 *  Description     : This routine converts MMGR codec to CMGR codec.  
 *  Input Values    : eMmgrCodecType - MMGR codec 
 *  Output Values	  : 
 *  Return Value    : If codec is supported, returns matching CMGR codec, else
 *                    returns 0 (zero) 
 *  Notes           :
 ******************************************************************************/
uint32 IFX_DECT_GetCmgrCodec(e_IFX_MMGR_CodecType eMmgrCodecType)
{
	uint32 uiCodec = 0;
	switch(eMmgrCodecType)
	{		
		case IFX_MMGR_CODEC_ALAW: 
			uiCodec = IFX_G711_ALAW ;
			break;
		case IFX_MMGR_CODEC_MLAW: 
			uiCodec = IFX_G711_ULAW ;
			break;
		case IFX_MMGR_CODEC_G726_32:
			uiCodec = IFX_G726_32 ;
			break;
		case IFX_MMGR_CODEC_G722_64:
			uiCodec = IFX_G722_64 ;
			break;
		/*
		case IFX_MMGR_CODEC_G722_1_24:
			uiCodec = IFX_G722_1_24 ;
			break;
		case IFX_MMGR_CODEC_G722_1_32:
			uiCodec = IFX_G722_1_32 ;
			break;*/
		default:
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
					"Unknown Codec: Not Supported On DECT System");
		break;
	}
	return uiCodec;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConvertCodecToCmgr
 *  Description     : This routine converts MMGR codec list to CMGR codec list.
 *  Input Values    : pxMmgrList - MMGR codec list.
 *  Output Values	  : pxList     - CMGR codec list.
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : If there are no matching codecs, then CMGR list contains
 *                    no codecs.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConvertCodecToCmgr(
	                      OUT x_IFX_CodecList* pxList,
	                      IN x_IFX_MMGR_CodecList* pxMmgrList)
{
	x_IFX_MMGR_CodecInfo* pxMMGRCodec = pxMmgrList->axCodecs;
	x_IFX_Codec* pxCodec = pxList->axCodec;
	uchar8 ucCount = 0;

	pxList->unNoOfCodecs = 0;
	for(; ucCount < pxMmgrList->ucNoOfCodecs; ++ucCount, ++pxMMGRCodec)
	{
		if((pxCodec->uiCodec=IFX_DECT_GetCmgrCodec(pxMMGRCodec->eCodecType)) != 0 ) {
			++pxList->unNoOfCodecs;
			++pxCodec;
		}
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_IsWidebandCodec 
 *  Description     : This routine checks whether given codec is a wideband 
 *                    codec 
 *  Input Values    : eCodecType -- MMGR codec type.
 *  Output Values	  : 
 *  Return Value    : return IFX_TRUE if codec is wideband, else returns 
 *                    IFX_FALSE
 *  Notes           :
 ******************************************************************************/
boolean IFX_DECT_IsWidebandCodec(e_IFX_MMGR_CodecType eCodecType)
{
	boolean bWideband = IFX_FALSE;
	if(IFX_MMGR_CODEC_G722_64 == eCodecType )
		bWideband = IFX_TRUE;
	return bWideband;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_FsmHdlr
 *  Description     : This routine invokes DECT FSM using given event. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If DECT FSM processes event successfuly.
 *                    IFX_FAILURE - On Error.
 *  Notes           :
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_DECT_FsmHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{
  pfn_IFX_DECT_Fsm pfnFsmHandler = 0;
  e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
      IFX_DECT_GetStateStr(pxEndptInfo->eState),
      IFX_DECT_GetEventStr(pxEvtInfo->eEvent));

  printf("\n Call Info[0] = %p, Call State 0 = %d\n",pxEndptInfo->axCallInfo,pxEndptInfo->axCallInfo[0].eState);
  //printf("\n Call Info[1] = %x, Call State 1 = %d",(uint32)&pxEndptInfo->axCallInfo[1],pxEndptInfo->axCallInfo[1].eState);
  if( pxEvtInfo->eEvent >= IFX_DECT_EventMax )
  {
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Invalid Event....");
    return eRet;
  }
  if(pxEndptInfo->eState >=0 && pxEndptInfo->eState < IFX_DECT_STATE_MAX)
  pfnFsmHandler = vax_LTQ_CVOIP_DECTFsm[pxEndptInfo->eState][pxEvtInfo->eEvent];
  if(pfnFsmHandler != NULL)
    eRet = pfnFsmHandler(pxEndptInfo,pxEvtInfo,peReason);
  return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ExecuteDialPlan 
 *  Description     : This routine is called to execute the dial plan actions.
 *                    Depending on action this routine initiates a call, transfer
 *                    conference etc...  
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *	                  eDpAction   - Dial plan action to be processed.
 *	                  pszDialOut  - Pointer to string returned by Dial Plan 
 *	                                (IFX_DP_Match)
 *  Output Values	  : pucSignal   - Signal to be sent to DECT handset.(i.e. tone
 *	                   to be played on DECT). If IFX_DECT_INVALID_TONE is 
 *	                   returned, then no tone should be played on handset.
 *	                  peState     - FSM state to be updated. If state returned  
 *	                   is IFX_DECT_STATE_MAX, then there is no change in FSM 
 *	                   state.
 *  Return Value    : 
 *  Notes           : Before calling this routine dial string that use enetered
 *	                  must be passed to IFX_DP_Match. If action returned is 
 *	                  IFX_DP_DIALOUT, then call this routine.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ExecuteDialPlan(
                      IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                      IN e_IFX_DP_Action eDpAction,
                      IN char8 *pszDialOut,
                      OUT uchar8* pucSignal,
                      OUT e_IFX_DECT_States* peState)
{
	x_IFX_CMGR_AddressInfo* pxDialedAddr = NULL;

	uchar8 ucAction = 0;
	boolean bEmergencyCall = IFX_FALSE;
	boolean bMakeCall = IFX_FALSE;
  
	e_IFX_CMGR_Status  eStatus;
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_CMGR_FeatStatus eCidStatus = IFX_CMGR_DONT_CARE;

	*peState = IFX_DECT_STATE_MAX;
	printf("\n <IFX_DECT_ExecuteDialPlan> Entry \n");
	/* 
	 * IFX_DP_CALLWAITING_REJECT is hanlded in call waiting state ( see 
	 * IFX_DECT_CwInterDigitTimerExpiryHdlr )
	 */
	eRet = IFX_FAILURE;
	printf("Execute dialplan, DP Action is %d\n",eDpAction);
	switch( eDpAction )
	{
	 case IFX_DP_EXTENSION_DIAL:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Extension Call");
			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
			 strcpy(pxDialedAddr->uxAddressInfo.szEndptId, pszDialOut);
				printf("IFX_DP_EXTENSION DIAL MATCH .....\n");
			 break;
		 }
	 	
   case IFX_DP_DIALDEFAULT_DEF_IF:
     {
       IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
          pxEndptInfo->szEndptId, "DP Action : Dial Using Default Interface");
       if( IFX_SUCCESS == IFX_CIF_DefaultOutBoundIfGet(
            pxEndptInfo->szEndptId, &ucAction, &eReason) )
       {
         bMakeCall = IFX_TRUE;
         pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
         memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
         printf("\n ucAction=%d\n",ucAction);
         if( ucAction )
         {
           pxDialedAddr->eAddressType = IFX_CMGR_TYPE_FXO;
           strcpy(pxDialedAddr->uxAddressInfo.xFxoInfo.szPhoneNumber, pszDialOut);
         }
         else
         {
           pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
           pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = IFX_TEL_NUM;
           strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName, pszDialOut);
         }
       }
			printf("<ExecuteDialPlan> Dialled voip num is %s\n",pszDialOut);
       break;
     }

			default:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Unknown Dial Plan Action");
		 }
	} /* switch */

	/* 
	 * If bMakeCall is true need to initiate call. Before initiating call, If 
	 * auto redial was requested by user, cancel it. Check outgoing call bar for
	 * non-emergency calls. Don't make call if outgoing calls are barred. If 
	 * outgoing calls are not bared, initiate call. If initiate call fails, 
	 * return failure. On success, move to ringback state if remote endpoint 
	 * status is ringing or else move to conversation state.
	 *
	 * If call is not initiated or failed, reset emergency & reject waiting call 
	 * flag if set
	 */
	if( bMakeCall )
	{
		boolean bOutCallBar = IFX_FALSE;
			printf("\n Calling IFX_DECT_InitiateCall bMakeCall True....\n");
		if( IFX_FALSE == bOutCallBar )
		{
			uchar8 ucDefaultLineId = 0;
			uchar8 ucLineId = 0;
			eRet = IFX_SUCCESS;
				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->uiDTkCallId); 

        /* Populate Line Id in pxDialedAddr*/
        if(IFX_FAILURE == IFX_DECT_IsEndpointLineIdSet(pxEndptInfo)){
				  IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, 
																	  &ucDefaultLineId, &eReason);
          IFX_DECT_EndpointLineIdSet(pxEndptInfo,ucDefaultLineId);// 
          pxDialedAddr->ucLineId = ucDefaultLineId;
        }else{
          IFX_DECT_EndpointLineIdGet(pxEndptInfo,&ucLineId);
          pxDialedAddr->ucLineId = ucLineId;
         } 
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "LINE ID",pxDialedAddr->ucLineId); 
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "Default LINE ID",ucDefaultLineId); 
			printf("\n Calling IFX_DECT_InitiateCall ....\n");
			if(IFX_SUCCESS == (eRet = IFX_DECT_InitiateCall(pxEndptInfo, 
					pxDialedAddr, eCidStatus,	bEmergencyCall,	&eStatus, &eReason )) )
			{
				if( IFX_CMGR_STATUS_FAIL == eStatus )
				{
					eRet = IFX_FAILURE;
					printf("\nIFX_DECT_InitiateCall to CM fails\n");
				}
			}else{
					printf("\nIFX_DECT_InitiateCall fails\n");
			}
		} /* bOutCallBar */
		else
		{
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
									 pxEndptInfo->szEndptId, "Outgoing Call Bar Enabled" );
			memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			/* Set to non-voip call, so that user can not do auto redial request */
			pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
			eRet = IFX_FAILURE;
		}
	} /* bMakeCall */

	return eRet;
}

/*********************** FSM Related API's *********************/

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_IgnoreHdlr
 *  Description     : This is DECT FSM routine. It is used for ignoring a event.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_FAILURE 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_IgnoreHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndptId, "Event Is Not Expected: Ignoring Event" );
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
      IFX_DECT_GetStateStr(pxEndptInfo->eState),
      IFX_DECT_GetEventStr(pxEvtInfo->eEvent));

  return IFX_FAILURE;
}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_IgnoreCallHdlr
 *  Description     : This is DECT FSM routine. It is used for ignoring a event.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_FAILURE 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_IgnoreCallHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndptId, "Event Is Not Expected: Ignoring Call" );
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
      IFX_DECT_GetStateStr(pxEndptInfo->eState),
      IFX_DECT_GetEventStr(pxEvtInfo->eEvent));
   *peReason = IFX_ABNORMAL_RELEASE;
   return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_PPOffHookHdlr
 *  Description     : This is DECT FSM routine. It is used for ignoring a event.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_FAILURE 
 *  Notes           :
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_DECT_IdlePPOffHookHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SetupEvent* pxSetupEvt = &pxEvtInfo->uxEventData.xSetupEvt;

	printf("<LTQ_CVOIP_DECT_IdlePPOffHookHdlr> Entry \n");	
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entry");

	*peReason = IFX_MAX_REASON;
	x_IFX_CodecList xCodecList = {0};	
	xCodecList.unNoOfCodecs = 3;
	//Codec during the call....
		switch(pxSetupEvt->aunCodec[0]){
				case IFX_G722_64 :
						//wideband call
						LTQ_CVOIP_getCodectListFilled(1,&xCodecList);
				break;
				case IFX_G726_32 :
							//Narrowband with G726	
							LTQ_CVOIP_getCodectListFilled(2,&xCodecList);
				break;
				default:	
							//Narrowband with G711	
						LTQ_CVOIP_getCodectListFilled(3,&xCodecList);
		}

	/* Store the Dect Toolkit Call Handler into the New Call instance */
    pxEndptInfo->uiDTkCallId = pxSetupEvt->uiTmpDtkCallHdl;
		pxEndptInfo->bWidebandEnabled=pxSetupEvt->ucBasicService;
	  IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs,&xCodecList);


		LTQ_CVOIP_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_WAIT_FOR_DIAL_DIGIT);
		LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_PROGRESS);
		printf("<LTQ_CVOIP_DECT_IdlePPOffHookHdlr> Exit \n");	
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Exit");
		return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr 
 *  Description     : This routine handles Dial Digit Received event in PROGRESS state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If call is accepted.
 *                    IFX_FAILURE - On failure.
 *  Notes           :
 ******************************************************************************/

e_IFX_Return LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{

	x_IFX_DP_Rule xDpRule;
  char8  szDialOut[IFX_MAX_DIGITS];
  uchar8 ucDpAction = 0;
  e_IFX_DECT_States eState;
  e_IFX_Return eRet=IFX_FAILURE;
  uint16 unTimeOut;
	uchar8 ucLineId = 0,ucDefaultLineId=0;
  uchar8 ucSignal = 0;
	e_IFX_ReasonCode eReason;
  char8 aucPrefix[32] = "";
	x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
	boolean bCallProceed = IFX_TRUE;
printf("<LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr> Entry");
	x_IFX_DECT_DigitInfo* pxDigitEvt = (&pxEvtInfo->uxEventData.xDigitEvt);
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entry");
	uchar8 aucBuf[3] ={0};
  uchar8  *pucBuff = aucBuf;

	//Check call is for the same handset/endpoint......
	if(atoi(pxDigitEvt->szDigits) == atoi(pxEndptInfo->szEndptId)){
			printf("Cann't Initiate the call to the Same Number....\n");
			bCallProceed = IFX_FALSE;	
	}

	//Check wheather call is for Registered Handset or not
if(bCallProceed && LTQ_CVOIP_isValidDectEndPoint(atoi(pxDigitEvt->szDigits)) == IFX_SUCCESS){

	if( IFX_SUCCESS !=
      IFX_DECT_GetEndptInfoByInstance(atoi(pxDigitEvt->szDigits)-1, &pxPeerEndptInfo) )
  {
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Could Not Get Handset Info (Invalid Instance Number)" );
			bCallProceed = IFX_FALSE;	
			printf("Endpoint %s not Attached/Registered, can't Initiate the call...!!\n",pxDigitEvt->szDigits);
  }
	if(bCallProceed && (pxPeerEndptInfo->bPPAttached != IFX_TRUE || pxPeerEndptInfo->eState != IFX_DECT_STATE_IDLE ) ){
			printf("Endpoint %s not Attached/Registered, can't initiate the call...\n",pxDigitEvt->szDigits);
			bCallProceed = IFX_FALSE;	
	}
}

	if(!bCallProceed){
		if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
   		 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Setting +NOCARRIER Response failed...." );
    		return IFX_FAILURE;
  	}	
			IFX_DECT_MakeDectPPIdle(pxEndptInfo);
			return IFX_FAILURE;
	}
	
	//Copy the digits to End pointinfo..
	strcpy(pxEndptInfo->szDialledDigits, pxDigitEvt->szDigits);

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_DTMF_CM_STRING_TEST,
      pxEndptInfo->szEndptId,  "Dialed Digits", pxEndptInfo->szDialledDigits);

  if(pxEndptInfo->szDialledDigits != NULL)
  {
    if((strlen(pxEndptInfo->szDialledDigits) ==1) && ((atoi(pxEndptInfo->szDialledDigits)>0) && (atoi(pxEndptInfo->szDialledDigits)<7))){
      		printf("<LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr> Digit is %d \n",atoi(pxEndptInfo->szDialledDigits));
     	 		IFX_DECT_GetEndptName(atoi(pxEndptInfo->szDialledDigits), pxEndptInfo->szDialledDigits);
   		}else{

  		    uchar8 ucIsInternal = 0;
      		if(IFX_SUCCESS == IFX_DP_RulePrefixGet(IFX_DP_EXTENSION_DIAL,aucPrefix)){
        				if(!strncmp(pxEndptInfo->szDialledDigits,aucPrefix,strlen(aucPrefix)))
         					ucIsInternal = 1;
      		}
		      if(!ucIsInternal){
    		    	if(IFX_SUCCESS != IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, &ucDefaultLineId, &eReason)){
        	  			return IFX_FAILURE;
        			}
        		IFX_DECT_EndpointLineIdGet(pxEndptInfo,&ucLineId);
        		printf("\n ucLineId = %d\n",ucLineId);
			
				/*
        if((ucDefaultLineId == IFX_PSTN_LINE)&&(ucLineId == IFX_PSTN_LINE || ucLineId == 0)){

         memset(aucPrefix,0,sizeof(aucPrefix));
         if(IFX_SUCCESS == IFX_DP_RulePrefixGet(IFX_DP_LOCAL_PSTN_CALLS,aucPrefix)){
           memmove(&pxEndptInfo->szDialledDigits[strlen(aucPrefix)],pxEndptInfo->szDialledDigits,strlen(pxEndptInfo->szDialledDigits));
           memcpy(pxEndptInfo->szDialledDigits,aucPrefix,strlen(aucPrefix));
         }else{
           return IFX_FAILURE;
          }
         printf("\nPSTN Line Dial Plan Digits: %s \n", pxEndptInfo->szDialledDigits);
        }*/
      }
	}
}

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
                "DTK Call Handle",pxEndptInfo->uiDTkCallId);
  eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
                 IFX_TRUE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );

	 if( eRet == IFX_SUCCESS && IFX_DP_DIALOUT == ucDpAction )
  	{
				//Resource Allocation for the call.
		/* if( IFX_MMGR_SUCCESS != IFX_MMGR_DectResAlloc(pxEndptInfo->szEndptId,
                &pxEndptInfo->unDectChannel, &pxEndptInfo->xReservedCodecs) )
  	{
    			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        				pxEndptInfo->szEndptId, "Could Not Allocate DECT Resource" );
   							 //pxDigitEvt->ucRejectReason = IFX_DECT_INSUFFICIENT_RESOURCES;
								return IFX_FAILURE;
  	}*/

    	/* Send  Following Command to CVoIP

			+CDIALING: ctxid=1,cid=1 To CVoip

			*/
		//Store the Called party information....
	  strcpy(pxEndptInfo->szCallerNumber,pxEndptInfo->szDialledDigits);
	
			aucBuf[0] = (uchar8 )pxEndptInfo->uiDTkCallId;
		if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_CallProceeding,&pucBuff,pxEndptInfo->ucInstance+1)){
							      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              			 "Failed in sending +CDIALING to CVoIP...." );
										return IFX_FAILURE;
				 }

			/* Execute the Dial Plan */
				printf("\n <LTQ_CVOIP_DECT_ProgressDialDigitsRecvHdlr > Executing the Dial Plan... : %d ",xDpRule.eAction);	
				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
      		          "DTK Call Handle",pxEndptInfo->uiDTkCallId);
				   eRet = IFX_DECT_ExecuteDialPlan(pxEndptInfo, xDpRule.eAction, szDialOut,
    		                &ucSignal, &eState);
					if( eRet == IFX_SUCCESS){
								LTQ_CVOIP_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_WAIT_FOR_DIAL_DIGIT);
								LTQ_CVOIP_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_CALL_INITIATED);
								LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_PROGRESS);
					}else{
									IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
      		          "Dial plan execution failed.....",pxEndptInfo->uiDTkCallId);
									printf("\nSending NOCARRIER from %d \n",pxEndptInfo->ucInstance+1);
							if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
  	  				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
    	    			"Setting +NOCARRIER Response failed...." );
		    				return IFX_FAILURE;
  				}
							IFX_DECT_MakeDectPPIdle(pxEndptInfo);
  							return eRet;
				}
		/* Clear all collected digits */
  	memset(pxEndptInfo->szDialledDigits,0,IFX_MAX_DIGITS);
	}else	{
     /*Dial plan error */
    	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
            pxEndptInfo->szEndptId, "Dial Plan Mismatch" );
				printf("Dial Plan Miss Match\n");
		printf("\nSending NOCARRIER from %d \n",pxEndptInfo->ucInstance+1);
		if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
  	  	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
    	    "Setting +NOCARRIER Response failed...." );
		    return IFX_FAILURE;
  	}
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
						//Send error to CVoip No dial Plan MisMatch
	  	 return IFX_FAILURE;
  	}
		
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Exit");
  return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_IdleIncomingCallHdlr 
 *  Description     : This routine handles incoming call event in IDLE state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS - If call is accepted.
 *	                  IFX_FAILURE - On failure.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_IdleIncomingCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_IncCallEvent* pxIncallEvt = (&pxEvtInfo->uxEventData.xIncCallEvt);
	x_IFX_CMGR_CallParams* pxCallParams;
	x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
	void *pTxCmdHdl = NULL;
  uchar8 ucSize = 0;
	uchar8 ucIndex = 0;
	uchar8 aucBuf[6]={0};
	uchar8  *pucBuff = aucBuf;
	boolean bWidebandCall = IFX_FALSE;
	x_IFX_CodecList xCodecList = {0};
	*peReason = IFX_MAX_REASON;
	 char8 acBuff[LTQ_CVOIP_MAX_ATCMD]={'\0'};
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entry");
	printf("<LTQ_CVOIP_DECT_IdleIncomingCallHdlr> Entry \n");

	//Check wheather base is in pagemode or not.....
	if(iMode == 2){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Stop paging sent to CVoIP...." );
      iMode = 0;
		/* TODO: Change AT command appropriately */
    strcpy(acBuff,"+CREG 0,1");
    //acBuff[5]='\r';
    //acBuff[6]=0;
    if(LTQ_CVOIP_SendMsg(acBuff,strlen(acBuff)) != IFX_SUCCESS){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Failed in sending Paging request to CVoIP...." );
      return IFX_FAILURE;
    }
		sleep(1);	
  }


	pxCallParams = pxIncallEvt->pxCallParams;
	
	//Store the peer information 
	IFX_AGU_GetCallerIdInfo(pxIncallEvt->pxFrom, 
			pxEndptInfo->szCallerName, pxEndptInfo->szCallerNumber);
	
	IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs, 
			&pxCallParams->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams);

	/*	if( IFX_MMGR_SUCCESS !=
		IFX_MMGR_DectResAlloc(pxEndptInfo->szEndptId, 
						&pxEndptInfo->unDectChannel, &pxEndptInfo->xReservedCodecs))
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Allocate Resources For DECT ");

		*peReason = IFX_NO_RESOURCE;
		return IFX_FAILURE;
	}*/
	
	if(pxEndptInfo->bWidebandEnabled)
	{
		{
			if( IFX_DECT_IsWidebandCodec(
							pxEndptInfo->xReservedCodecs.axCodecs[ucIndex].eCodecType) )
			{
     		printf("%s WIDE BAND ENABLED YES",__FUNCTION__);
				bWidebandCall = IFX_TRUE;
			}
		}
	}

  //LTQ_CVOIP_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED);
	
	pxEndptInfo->pxActiveCall = (pxEndptInfo->axCallInfo+0);
	pxEndptInfo->pxActiveCall->uiCallId =  pxEndptInfo->pxActiveCall->uiDTkCallId = pxEvtInfo->uiId;
	pxEndptInfo->pxActiveCall->ucLineId = pxEvtInfo->uxEventData.xIncCallEvt.ucLineId;

	if( IFX_CMGR_TYPE_FXO == 
		(pxEndptInfo->pxActiveCall->eCallType = pxIncallEvt->pxFrom->eAddressType))
	{
		strcpy(pxEndptInfo->pxActiveCall->szCallInitrEndptId,
									pxIncallEvt->pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId );
	}
				
	/* Send following Commands to CVoIP
		+CRING:ctxid=2
		+CLIP: ctxid=2,<CallerNumber>, <CallerName> "
	*/
	// Check for caller endpoin Information

if(LTQ_CVOIP_isValidDectEndPoint(atoi(pxEndptInfo->szCallerNumber)) == IFX_SUCCESS){
	if( IFX_SUCCESS !=
      IFX_DECT_GetEndptInfoByInstance(atoi(pxEndptInfo->szCallerNumber)-1, &pxPeerEndptInfo) )
  {
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Could Not Get Handset Info (Invalid Instance Number)" );
    return IFX_FAILURE;
  }
}

	memset(&aucBuf,0,sizeof(aucBuf));
	aucBuf[0]=pxEndptInfo->pxActiveCall->ucLineId; //LineId
	if(LTQ_CVOIP_isValidDectEndPoint(atoi(pxEndptInfo->szCallerNumber)) == IFX_SUCCESS){
		aucBuf[1]=0; //Call type internal
		aucBuf[2]=pxEndptInfo->bWidebandEnabled; //Connection type Id
	}
	else{
		aucBuf[1]=1; //Call type external
		aucBuf[2]=0; //Narrow band Call
	}

//codec type negotiation
  if(LTQ_CVOIP_isValidDectEndPoint(atoi(pxEndptInfo->szCallerNumber)) == IFX_SUCCESS){ 

			if( (bWidebandCall || pxEndptInfo->bWidebandEnabled ) && 
					(pxPeerEndptInfo->bWidebandEnabled) && 
			 		(pxPeerEndptInfo->xReservedCodecs.axCodecs[0].eCodecType == IFX_MMGR_CODEC_G722_64)){
							aucBuf[2] = 1; //Wideband call
							LTQ_CVOIP_getCvoipCodectList(1,&aucBuf[3]);
								//Final codec negotiation type 
   					 LTQ_CVOIP_getCodectListFilled(1,&xCodecList);
		  } else if(pxPeerEndptInfo->xReservedCodecs.axCodecs[0].eCodecType == IFX_MMGR_CODEC_ALAW &&
								pxEndptInfo -> bG711Enabled && pxPeerEndptInfo -> bG711Enabled ){
							aucBuf[2] = 0; //Narrow band call
							LTQ_CVOIP_getCvoipCodectList(3,&aucBuf[3]);
   						LTQ_CVOIP_getCodectListFilled(3,&xCodecList);
				}	else {
							aucBuf[2] = 0; //Narrow band Call
							LTQ_CVOIP_getCvoipCodectList(2,&aucBuf[3]);
   						LTQ_CVOIP_getCodectListFilled(2,&xCodecList);
		  	}
							   IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs,&xCodecList);
							   IFX_DECT_ConvertCodecToMMGR(&pxPeerEndptInfo->xReservedCodecs,&xCodecList);
 }else {
							//may be fxs to dect call.. always.. g726
							if(pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType == IFX_MMGR_CODEC_ALAW &&
                pxEndptInfo -> bG711Enabled){ 
									LTQ_CVOIP_getCvoipCodectList(3,&aucBuf[3]);
   									LTQ_CVOIP_getCodectListFilled(3,&xCodecList);
								}else if(pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType == IFX_MMGR_CODEC_G722_64 &&
                bWidebandCall){
										LTQ_CVOIP_getCvoipCodectList(1,&aucBuf[3]);
   									LTQ_CVOIP_getCodectListFilled(1,&xCodecList);
								}else {
										LTQ_CVOIP_getCvoipCodectList(2,&aucBuf[3]);
   									LTQ_CVOIP_getCodectListFilled(2,&xCodecList);
								}
							  IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs,&xCodecList);
	}
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_IncomingCall,&pucBuff,pxEndptInfo->ucInstance+1);

	if (IFX_SUCCESS != LTQ_ATCmd_CmdTypeSet(&pTxCmdHdl,LTQ_ATCmd_CLIP)){
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
  	      "Setting +CLIP Response failed...." );
  		LTQ_ATCmd_FreeHandle(pTxCmdHdl);
    	return IFX_FAILURE;
  }else{
					LTQ_ATCmd_ByteValueSet(LTQ_CLIPCmd_CtxId, pTxCmdHdl, pxEndptInfo->ucInstance+1);
		    	LTQ_ATCmd_ValueSet(LTQ_CLIPCmd_Number, pTxCmdHdl, (uchar8*)pxEndptInfo->szCallerNumber);
		    	LTQ_ATCmd_ValueSet(LTQ_CLIPCmd_Name, pTxCmdHdl, (uchar8*)pxEndptInfo->szCallerName);
  		  	ucSize = LTQ_ATCmd_BufferGet(pTxCmdHdl, &pucBuff);
    			if(LTQ_CVOIP_SendMsg((char8*)pucBuff,ucSize) != IFX_SUCCESS){
      				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            	   "Failed in sending +CLIP to CVoIP...." );
  						LTQ_ATCmd_FreeHandle(pTxCmdHdl);
    					return IFX_FAILURE;
    			}  			
	}	
  LTQ_ATCmd_FreeHandle(pTxCmdHdl);

	IFX_DECT_UpdateCallState(pxEndptInfo, 
										pxEndptInfo->pxActiveCall, IFX_DECT_CS_INITIATED);	
	LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_PROGRESS);

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Waiting For Handset Response");

	*peReason = IFX_REQ_PENDING;
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ProgressRmtCallAcceptHdlr
 *  Description     : This routine handles remote party call accept event in 
 *	                  dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call id is valid, IFX_SUCCESS is retunred, otherwise 
 *	                  IFX_FAILURE is returned. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtCallAcceptHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	uchar8 aucBuf[2]= {0};
  uchar8  *pucBuff = aucBuf;
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId,"Entry");
printf("<LTQ_CVOIP_DECT_ProgressRmtCallAcceptHdlr> Entry");
	if( pxActCall->uiCallId != pxEvtInfo->uiId /* ||
			IFX_DECT_CS_INITIATED != pxEndptInfo->eState */ )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"FAILED: RmtAccept On Wrong Call");
		return IFX_FAILURE;
	}

	/* Send follwing Commands to CVoIP
			+CALERTING:ctxid=1,cid=1
			+CTONE:ctxid=1,1
	*/
	aucBuf[0]=(uchar8)pxEndptInfo->uiDTkCallId; //CallId;	
	if(IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_RemoteAccept, &pucBuff, pxEndptInfo->ucInstance+1)){
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Sending +CALERTING Failed");
		return IFX_FAILURE;	
	}

	// Send CTONE  on..
	aucBuf[0]=1;	
	if(IFX_SUCCESS !=IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Tone, &pucBuff, pxEndptInfo->ucInstance+1)){
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Sending +CTONE ON Failed");
				return IFX_FAILURE;
	}
  
	LTQ_CVOIP_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED);
	IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_RINGING);
printf("LTQ_CVOIP_DECT_ProgressRmtCallAcceptHdlr>>>> Exit");
IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                          pxEndptInfo->szEndptId,"Exit");

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingRmtCallAnswerHdlr
 *  Description     : This routine handles remote party call answer event in
 *	                  dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call id is valid, IFX_SUCCESS is retunred, otherwise 
 *	                  IFX_FAILURE is returned. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtCallAnswerHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	uchar8 aucBuf[6]={0};
  uchar8  *pucBuff = aucBuf;
	x_IFX_CMGR_MediaParams xMediaParams={0};
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId,"Entry");
printf("LTQ_CVOIP_DECT_ProgressRmtCallAnswerHdlr >>> Entry");
	if( pxEndptInfo->pxActiveCall->uiCallId != pxEvtInfo->uiId /* ||
			 WRONG** ( IFX_DECT_CS_INITIATED != pxEndptInfo->eState && 
			  IFX_DECT_CS_RINGING != pxEndptInfo->eState   ) */ )
	{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"FAILED: Rmt Answer On Wrong Call");
			return IFX_FAILURE;
	}
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	IFX_CMGR_MediaParamsGet(pxActCall->uiCallId, &xMediaParams);
  IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs,
					&xMediaParams.uxMediaParams.xExtnMediaParams.xCodecParams);
   
	/* Send Cvoip Following Commands:
		+CTONE:ctxid=1,0(tone Off)
		CONNECT ctxid=1,cid=1
		+COAP:ctxid=1,operation=1,cid=1
	*/

	// +CTONE Cmd params
	memset(&aucBuf,0,sizeof(aucBuf));
	if(IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Tone,&pucBuff,pxEndptInfo->ucInstance+1)){ 
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +CTONE FAILED Response failed...." );
		return IFX_FAILURE;	
	}

	//CONNECT COMMAND Params
	memset(&aucBuf,0,sizeof(aucBuf));
	aucBuf[0]=(uchar8)pxEndptInfo->uiDTkCallId;
	if(IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_Connect,&pucBuff,pxEndptInfo->ucInstance+1)){
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +CONNECT Response failed...." );
          return IFX_FAILURE;
	}
	#if 1
		x_IFX_MMGR_CodecInfo xMmgrCodec = {IFX_MMGR_CODEC_NONE};
		xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G726_32;
		if(atoi(pxEndptInfo->szCallerNumber) > 6 ){
			AllocPcmChannel(atoi(pxEndptInfo->szEndptId));
		//if(atoi(pxEvtInfo->uxEventData.pxIncallEvt->pxFrom->uxAddressInfo.szEndptId)>6){
		if( IFX_MMGR_SUCCESS != 
							IFX_MMGR_DectResActivate(pxEndptInfo->szEndptId, &xMmgrCodec,
																			 (pxEndptInfo->uiTermCap/* & IFX_DECT_MU_HS_ECHO_TCL_55*/)?0:1) )
		{
			//Configure codec on DECT Channel failed
			pxEndptInfo->eRunningCodec = 0;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
		}
		}
		#endif
	printf("Allocating2 Pcmchannel for HS:%s\n",pxEndptInfo->szEndptId);
	//Send +COAP Command with service change 
	if(IFX_SUCCESS !=	IFX_CVOIP_ConstNSendCOAPcmd(pxEndptInfo,1,1)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +COAP Response failed...." );
          return IFX_FAILURE;
  }

	
	IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_ACTIVE);
  LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                          pxEndptInfo->szEndptId,"Exit");
	printf("LTQ_CVOIP_DECT_ProgressRmtCallAnswerHdlr >>> Exit\n");

  return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ProgressRmtCallRejectHdlr
 *  Description     : This routine handles remote party call reject event in 
 *                    progress state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : If call id is valid, IFX_SUCCESS is retunred, otherwise 
 *                    IFX_FAILURE is returned. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_ProgressRmtCallRejectHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{
 	//x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                            pxEndptInfo->szEndptId);

	/* Send following AT Command  to CVoIP 
    NOCARRIER ctxid=HSID
    +COAP HSID,0,callId
	*/

	printf("\n**********Sending NOCARRIER from %d \n",pxEndptInfo->ucInstance+1);
	if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Setting +NOCARRIER Response failed...." );
    return IFX_FAILURE;
  }

	//Send +COAP Command 
	if(IFX_SUCCESS != IFX_CVOIP_ConstNSendCOAPcmd(pxEndptInfo,1,1)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +COAP Response failed...." );
          return IFX_FAILURE;
  }


	if(pxEndptInfo->pxActiveCall->eState == IFX_DECT_CS_INITIATED){
  		IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
		  pxEndptInfo->pxActiveCall = 0;
	}
	// Make DECT PP Idle...
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_EventNotHandledHdlr
 *  Description     : This rouitne is used in all FSM state. This routine is 
 *	                  invoked for events that are not mandatory or not required
 *	                  in this version.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_EventNotHandledHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_AlertingCallAcceptHdlr 
 *  Description     : This routine handles alert message from handset. 
 *	 									- Norma call : (initiated from remote)store codec info if 
 *	                  present in alert message, inform call acceptance to CM. 
 *	                  start ring timer and move to RINGING state. 
 *	                  - paging call : start paging timer.
 *	                  - Auto Redial : Store codec info if present. Note that 
 *	                  expiry event for both paging and ring timer are same.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_AlertingCallAcceptHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	
		eRet = IFX_CMGR_CallAccept(pxActCall->uiCallId, &eStatus, peReason);
		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_FAIL == eStatus )
		{	
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId,"FAILED : IFX_CMGR_CallAccept");

			IFX_DECT_ResetCall(pxActCall,1);
			pxEndptInfo->pxActiveCall = 0;
			IFX_DECT_MakeDectPPIdle(pxEndptInfo);
			LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);	
			return eRet;
		}
		else
		{
			pxEndptInfo->uiDTkCallId = pxEvtInfo->uiId;
			IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_RINGING);
		}
		
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingCallReleaseHdlr 
 *  Description     : This routine handles Reject message from handset/Cvoip in 
 *	                  Progress state. If call initiated by peer, inform CM that
 *	                  call is being rejected/terminated by handset. Make DECT endpoint
 *	                  IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_AlertingCallRejectHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	//x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	if(pxEndptInfo->pxActiveCall)
  	IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
                                        IFX_ABNORMAL_RELEASE, NULL, NULL, peReason);

	/* Send following AT Command  to CVoIP 
    NOCARRIER ctxid=HSID
    +COAP HSID,0,callId
  */
	
	printf("\nSending NOCARRIER from %d \n",pxEndptInfo->ucInstance+1);
	if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
  	  	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
    	    "Setting +NOCARRIER Response failed...." );
		    return IFX_FAILURE;
  }

	//Send +COAP Command 
	if (IFX_SUCCESS !=	IFX_CVOIP_ConstNSendCOAPcmd(pxEndptInfo,0,1)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +COAP Response failed...." );
          return IFX_FAILURE;
  }


	if(pxEndptInfo->pxActiveCall)
  	IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
  pxEndptInfo->pxActiveCall = 0;

	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingCallAnswerHdlr 
 *  Description     : This routine handles OFF-HOOK event in alerting state.
 *	                   Handles CC_CONNECT (treated as PP_OffHook event) event. 
 *                      - Cancel ring and ring pause timers
 *                      - If auto redialing flag is set, initiate a call to 
 *	                      last dialed number. If call is initiated successfuly, 
 *	                      move to ringback state if remote party accepted call, 
 *	                      else move to dialing state.
 *	                    - If page call flag is set, send release to PP and go 
 *	                      back to idle state.
 *	                    - If it is normal call, then inform remote party about 
 *                        call answer, enable dect voice, and move to active 
 *                        state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_AlertingCallAnsweredHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	//e_IFX_DECT_States eState = IFX_DECT_STATE_ACTIVE;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
printf("LTQ_CVOIP_DECT_AlertingCallAnsweredHdlr >> Entry\n");
	 //normal call
	{
		/* 
		 * Call is initiated from remote party. Answer call and move to active 
		 * state 
		 */
		x_IFX_MMGR_CodecInfo xMmgrCodec = {IFX_MMGR_CODEC_NONE};

		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
	         pxEndptInfo->szEndptId, "Incomoing Call Answered...");

		if( IFX_DECTNG_CODEC_G722_64 == pxEvtInfo->uxEventData.aunCodec[0]  )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Codec For This Call=IFX_MMGR_CODEC_G722_64");
			pxEndptInfo->eRunningCodec = 
									xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G722_64 ;
		}
		else if( pxEndptInfo->pxActiveCall != NULL && IFX_DECTNG_CODEC_G722_64 == pxEndptInfo->pxActiveCall->eNegCodec )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Codec For This Call=IFX_MMGR_CODEC_G726_32");
			pxEndptInfo->pxActiveCall->eNegCodec =
												pxEndptInfo->eRunningCodec = 
														xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G726_32;
		}
		else
		{
			//If codec is not sent by PP use G.726 
			if(pxEndptInfo->pxActiveCall != NULL && IFX_MMGR_CODEC_NONE == pxEndptInfo->pxActiveCall->eNegCodec )
			{
				pxEndptInfo->eRunningCodec = xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G726_32;
			}
			else
			{
				pxEndptInfo->eRunningCodec = 
								xMmgrCodec.eCodecType = pxEndptInfo->pxActiveCall->eNegCodec;
			}
		}

		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
						"Coder Selected for the call (mmgr)= ", pxEndptInfo->eRunningCodec);
	#if 1
		if(atoi(pxEndptInfo->szCallerNumber) > 6 ){
			AllocPcmChannel(atoi(pxEndptInfo->szEndptId));
		//if(atoi(pxEvtInfo->uxEventData.pxIncallEvt->pxFrom->uxAddressInfo.szEndptId)>6){
		if( IFX_MMGR_SUCCESS != 
							IFX_MMGR_DectResActivate(pxEndptInfo->szEndptId, &xMmgrCodec,
																			 (pxEndptInfo->uiTermCap/* & IFX_DECT_MU_HS_ECHO_TCL_55*/)?0:1) )
		{
			//Configure codec on DECT Channel failed
			pxEndptInfo->eRunningCodec = 0;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
		}
		}
		#endif
	printf("Allocating Pcmchannel for HS:%s\n",pxEndptInfo->szEndptId);
	/* Send Following command to CVoIP
					+COAP: ctxid=2,operation=1,cid=1
	*/
	
	//+COAP Command Send
  if(IFX_SUCCESS !=  IFX_CVOIP_ConstNSendCOAPcmd(pxEndptInfo,1,1)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +COAP Response failed...." );
          return IFX_FAILURE;
  }


	IFX_CMGR_CallAnswer(pxEndptInfo->pxActiveCall->uiCallId,
																								&eStatus, peReason );

		if( IFX_CMGR_STATUS_SUCCESS != eStatus )
		{
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "IFX_CMGR_CallAnswer Failed");
				//eState = IFX_DECT_STATE_ACTIVE;
    	  if(pxEndptInfo->pxActiveCall != NULL)
						pxEndptInfo->pxActiveCall->eState = IFX_DECT_CS_BUSY;
		      //ucSignal = IFX_DECT_BUSY_TONE;
		}
		else
		{
			IFX_DECT_UpdateCallState(pxEndptInfo,pxEndptInfo->pxActiveCall,
					IFX_DECT_CS_ACTIVE);
				//eState = IFX_DECT_STATE_ACTIVE;
		}
	}

		LTQ_CVOIP_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
		LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_AlertingCallReleaseHdlr 
 *  Description     : This routine handles Reject message from handset/Cvoip in 
 *                    Progress state. If call initiated by peer, inform CM that
 *                    call is being rejected/terminated by handset. Make DECT endpoint
 *                    IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_ActiveCallReleaseHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                            pxEndptInfo->szEndptId);

   if(pxActCall != NULL)
    IFX_CMGR_CallRelease(pxActCall->uiCallId, IFX_TERMINATED, NULL,
                                                          NULL, peReason);
#if 1
	/* Send following AT Command  to CVoIP 
		NOCARRIER ctxid=HSID
		+COAP HSID,0,callId
	*/
	//+COAP Command Send
  if(IFX_SUCCESS !=  IFX_CVOIP_ConstNSendCOAPcmd(pxEndptInfo,0,1)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +COAP Response failed...." );
          return IFX_FAILURE;
  }
	
	printf("\n**********Sending NOCARRIER from %d \n",pxEndptInfo->ucInstance+1);
	if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
  		  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
      		  "Setting +NOCARRIER Response failed...." );
		    return IFX_FAILURE;
  }

#endif

	//Make DECT PPIDle//DeActii
	if(vaucPcmChannelNo[atoi(pxEndptInfo->szEndptId)-1] != 0){
		printf("<ActiveCallReleaseHdlr> Deactivating Dect Res...\n");
		IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);
		vaucPcmChannelNo[atoi(pxEndptInfo->szEndptId)-1] =0;
	}
  IFX_DECT_ResetCall(pxActCall,0);
  pxEndptInfo->pxActiveCall = 0;
  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
  return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_AlertingRmtCallReleaseHdlr 
 *  Description     : This routine handles Release message from CM 
 *                    in Active state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_DECT_ActiveRmtCallReleaseHdlr(
                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                    IN x_IFX_DECT_EventInfo* pxEvtInfo,
                    OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	uchar8 aucBuf[2]={0};
  uchar8 *pucBuff= aucBuf;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                            pxEndptInfo->szEndptId);

printf("LTQ_CVOIP_DECT_ActiveRmtCallReleaseHdlr >> Entry..\n");
	/* Send Following command to CVoip 
			CTONE HsId,3
			delay 3
			+CTONE HsId,0
			NO CARRIER HsId
			+COAP HSId,0,CallId
	*/

	// Send CTONE  on..
  aucBuf[0]=3;
  if(IFX_SUCCESS !=IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Tone, &pucBuff, pxEndptInfo->ucInstance+1)){
      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndptId, "Sending +CTONE ON Failed");
        return IFX_FAILURE;
  }
	sleep(3);
	// Send CTONE  off..
  aucBuf[0]=0;
  if(IFX_SUCCESS !=IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Tone, &pucBuff, pxEndptInfo->ucInstance+1)){
      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndptId, "Sending +CTONE OFF Failed");
        return IFX_FAILURE;
  }


	//+COAP Command Send
  if (IFX_SUCCESS !=  IFX_CVOIP_ConstNSendCOAPcmd(pxEndptInfo,0,1)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "Setting +COAP Response failed...." );
          return IFX_FAILURE;
  }
	
	printf("\n**********Sending NOCARRIER from %d \n",pxEndptInfo->ucInstance+1);
	if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndptInfo->ucInstance+1)){
  		  	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
      	  "Setting +NOCARRIER Response failed...." );
			    return IFX_FAILURE;
  }


	if(vaucPcmChannelNo[atoi(pxEndptInfo->szEndptId)-1] != 0){
		printf("<ActiveCallReleaseHdlr> Deactivating Dect Res...\n");
		IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);
		vaucPcmChannelNo[atoi(pxEndptInfo->szEndptId)-1] =0;
	}
	//Clear all call related info..
   IFX_DECT_ResetCall(pxActCall,0);
   pxEndptInfo->pxActiveCall = 0;
	//Make The endpoint idle..  
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
printf("LTQ_CVOIP_DECT_ActiveRmtCallReleaseHdlr >> Exit..\n");
  return IFX_SUCCESS;
}


/******************************* Call Manager Related Call Backs ******************************/
/*******************************************************************************
 *  Function Name   : IFX_DECT_InitiateCall 
 *  Description     : This routine initates a outgoing call(from handset). If 
 *                    handset has max number of calls, then no call is initiated
 *                    and routine returns failure.  Else initiates a new call.
 *  Input Values    : pxEndptInfo  - Pointer to DECT endpoint info.
 *                    pxDialedAddr - Pointer to x_IFX_CMGR_AddressInfo struct
 *                     containing to valid parameter for the destination.
 *                    eCidStatus   - This indicates whether CID to be disabled.
 *                     IFX_CMGR_DISABLE - disable CID
 *                                 IFX_CMGR_ENABLE - enable CID
 *                                 IFX_CMGR_DONT_CARE - Use system config
 *                      If eCidStatus is IFX_CMGR_ENABLE, CM overrides this
 *                      option with system configuration.
 *                    bEmergencyCall - IFX_TRUE - for emergency call.
 *                                   IFX_FALSE - for non-emergency call. 
 *  Output Values	  : peStatus - This contains status of the initiated call.
 *                       This parameter is valid only if function returns
 *                       IFX_SUCCESS.
 *                     peReason - On return this contains the reason. If routine
 *                       returns IFX_SUCCESS, the valid values are 
 *                       IFX_ENDPOINT_RINGING and IFX_REQ_PENDING
 *  Return Value    : If call is initated returns IFX_SUCCESS, else returns 
 *                    IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_InitiateCall(
                     IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
										 IN x_IFX_CMGR_AddressInfo* pxDialedAddr,
										 IN e_IFX_CMGR_FeatStatus eCidStatus,
	                   IN boolean bEmergencyCall,
	                   OUT e_IFX_CMGR_Status* peStatus,
	                   OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxNewCall;
	e_IFX_Return eRet = IFX_FAILURE;

	/* Get free call info */
	IFX_DECT_GetFreeCallInfo(pxEndptInfo, &pxNewCall);
	printf("\n <IFX_DECT_InitiateCall> Entry \n");	
	if( pxNewCall )
	{
		x_IFX_CMGR_AddressInfo xFrom ={0};
		x_IFX_CMGR_CallParams xCallParams = {0};
		uint32 uiCallId;

		IFX_DECT_ConvertCodecToCmgr(
				&xCallParams.uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams,
				&pxEndptInfo->xReservedCodecs);

		printf("Codec 1 is %d, total codecs: %d\n",xCallParams.uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams.axCodec[0].uiCodec,xCallParams.uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams.unNoOfCodecs);
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Number of codecs reserved", pxEndptInfo->xReservedCodecs.ucNoOfCodecs);

		/* Fill from endpoint id */
		xFrom.eAddressType = IFX_CMGR_TYPE_EXTN;
		printf("agent, endptid is %s\n",pxEndptInfo->szEndptId);
		strcpy(xFrom.uxAddressInfo.szEndptId, pxEndptInfo->szEndptId);
	
		/* set call params */
		xCallParams.eAgentType = IFX_CMGR_TYPE_EXTN;
		xCallParams.uxCallParams.xExtnParams.eCallerIdStatus = eCidStatus;
		xCallParams.uxCallParams.xExtnParams.bEmergency = bEmergencyCall;

	/*	 Get wideband capability of endpoint */
		if (xCallParams.uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams.axCodec[0].uiCodec != IFX_G722_64)
			xCallParams.uxCallParams.xExtnParams.bWideBandCapable = IFX_FALSE;
		else
			xCallParams.uxCallParams.xExtnParams.bWideBandCapable = IFX_TRUE;

		 {
					printf("Call manager Call initating...! \n");
					eRet = IFX_CMGR_CallInitiate( &uiCallId,  &xFrom,
							pxDialedAddr,	&xCallParams,	peStatus,	peReason,	pxEndptInfo );
     }
	  	
		if( IFX_SUCCESS == eRet )
		{
			if( IFX_CMGR_STATUS_FAIL == (*peStatus) )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						"IFX_CMGR_CallInitiate :: STATUS FAIL", pxEndptInfo->szEndptId);
				eRet = IFX_FAILURE;
				printf( "\n IFX_CMGR_CallInitiate :: STATUS FAIL\n");
			}
			else
			{
				 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 								"Call Initiate Success. Call Id",uiCallId); 
				pxEndptInfo->pxActiveCall = pxNewCall;
				pxEndptInfo->pxActiveCall->ucLineId = pxDialedAddr->ucLineId;
				pxNewCall->uiCallId = uiCallId;

				//pxEndptInfo->pxActiveCall->uiDTkCallId =uiCallId;// pxEndptInfo->uiDTkCallId;

				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->pxActiveCall->uiDTkCallId); 
				pxNewCall->eCallType = pxEndptInfo->xLastDialedAddr.eAddressType;
				IFX_AGU_GetCallerIdInfo(pxDialedAddr,pxEndptInfo->szCallerName, 
																pxEndptInfo->szCallerNumber);
				printf("Callmanger Call Initiate Done.......\n");
				#if 0
		    strcpy(xCP.acCLIP,pxEndptInfo->szCallerNumber);

        if(pxDialedAddr->eAddressType == IFX_CMGR_TYPE_EXTN){
        		IsInternal=1;/*For Extn call */
        }
        /* Get the LineId for VoIP or FXO call */
	      if(IFX_CIF_CNIPGet(IsInternal,pxDialedAddr->ucLineId,pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS){
	        strcpy(xCP.acCNIP,pxEndptInfo->szCallerName);
        }
				xCP.uiSignal=0xFF;
		//TODO check if pxactiveCall is set or not
	      if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){
          IFX_DECT_CSU_InfoReceived(
          pxEndptInfo->pxActiveCall->uiDTkCallId,
		      &xCP);
        }

				if(  pxEndptInfo->eRunningCodec ){
					pxNewCall->eNegCodec =  pxEndptInfo->eRunningCodec;
        }
		    else {
					pxNewCall->eNegCodec = pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType;
		    }
#endif
		    if( IFX_CMGR_STATUS_SUCCESS == (*peStatus))	
		    {
		    }
				else if( IFX_CMGR_STATUS_PENDING== (*peStatus)) 
		    {
					if((atoi(pxEndptInfo->szCallerNumber) == 7) ||
										(atoi(pxEndptInfo->szCallerNumber) == 8)){//For FXS Call Need to send call accept here only
						x_IFX_DECT_EventInfo evtInfo = {0};
						e_IFX_ReasonCode eReason = IFX_MAX_REASON;

						IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
															pxEndptInfo->szEndptId, "Fxs Accepted Call" );
	
						evtInfo.eEvent = IFX_DECT_EVT_RmtAccept;
						evtInfo.uiId = pxEndptInfo->pxActiveCall->uiCallId;

						if( IFX_SUCCESS != 
							LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
						{
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId, "!! Remote Call Accept Failed !!");
						}
	
					}
			  }
		}
	}
		else
		{
			/* Failed to initiate call */
			*peStatus = IFX_CMGR_STATUS_FAIL;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "IFX_CMGR_CallInitiate Failed " );
					printf(" %s IFX_CMGR_CallInitiate Failed ", pxEndptInfo->szEndptId);
		}
     }
     else
     {
		/* Endpoint has max calls. */
	  *peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Can not Initiated :: DECT Has Max Calls " );
	}
	printf("\n <IFX_DECT_InitiateCall> Exit \n");

	return eRet;
}


/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_CallIncoming
 *  Description     : This function is called by Call Manager (it is registered 
 *	                  as callback  function) when there is incoming call for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_IncomingCall 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_IncomingCall event. If not registered reject 
 *	                  call. If FSM returns success,accept call,else reject call.
 *  Input Values    : Please refer pfnCallIncoming callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : If call is not intended for the given DECT PP or PP is 
 *	                  not attached to base then returns IFX_FAILURE, otherwise 
 *	                  returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_CallIncoming(
								 IN uint32 uiCallId, 
								 IN x_IFX_CMGR_AddressInfo *pxFrom,
								 IN x_IFX_CMGR_AddressInfo *pxTo, 
								 IN x_IFX_CMGR_CallParams *pxCallParams, 
								 OUT e_IFX_CMGR_Status* peStatus,
								 OUT e_IFX_ReasonCode* peReason,
								 OUT void** ppvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  //x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
	e_IFX_Return eRet = IFX_FAILURE;

	*peStatus = IFX_CMGR_STATUS_FAIL;
	*peReason = IFX_CIF_INVALID_ENDPOINT;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "Got Incoming Call" );
	if( IFX_CMGR_TYPE_EXTN != pxTo->eAddressType )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "Invalid Address Type" );
		return eRet;
	}
	
	if( IFX_SUCCESS != IFX_DECT_GetEndptInfoById(pxTo->uxAddressInfo.szEndptId, &pxEndptInfo) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "!! This Endpoint Does Not Exist !!" );
		return eRet;
	}

  /* If Incoming Call on PSTN Line,pass the PSTN Line Id to the Endpt. */
	/*
  if(pxFrom->eAddressType == IFX_CMGR_TYPE_FXO){
                
    pxTo->ucLineId = IFX_PSTN_LINE; 
  }*/

	if( pxEndptInfo->bPPAttached )
	{
		x_IFX_DECT_EventInfo evtInfo = {0};

		evtInfo.eEvent = IFX_DECT_EVT_IncomingCall;
		evtInfo.uiId = uiCallId;
		evtInfo.uxEventData.xIncCallEvt.pxFrom = pxFrom;
		evtInfo.uxEventData.xIncCallEvt.pxCallParams = pxCallParams;
		evtInfo.uxEventData.xIncCallEvt.ucLineId = pxTo->ucLineId;

		if( IFX_SUCCESS == LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo, &evtInfo, peReason))
		{
      if(*peReason == IFX_ABNORMAL_RELEASE){
			  *peStatus = IFX_CMGR_STATUS_FAIL;
      }
      else{
			  *peStatus = IFX_CMGR_STATUS_PENDING;
      }
			/* waiting for ALERT_IN_CC */
			/* TODO: *peReason = IFX_REQ_PENDING; ?? */
			//*peReason = IFX_MAX_REASON;  
			*ppvPrivateData = (void*)pxEndptInfo;
		}
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Call Is Rejected." );
			*peReason = IFX_ENDPOINT_BUSY;
			return IFX_FAILURE;
		}
	}
	else
	{	
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "This Handset Is Not Registered/Reachable" );
		printf("%s This Handset Is Not Registered/Reachable" , pxEndptInfo->szEndptId);

	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallAccept
 *  Description     :  This callback routine is called by call manager when peer
 *	                   party accepts the call. Pumps IFX_DECT_EVT_RmtAccept event 
 *	                   to DECT PP FSM.
 *  Input Values    : Please refer pfnRemoteCallAccept callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.  
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_RemoteCallAccept(
							 IN uint32 uiCallId,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Accepted Call" );
	
	evtInfo.eEvent = IFX_DECT_EVT_RmtAccept;
	evtInfo.uiId = uiCallId;

	if( IFX_SUCCESS != 
			LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "!! Remote Call Accept Failed !!");
	}
	
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallAnswer
 *  Description     : This callback function is called by CM once peer answers 
 *	                  call. This issues IFX_DECT_EVT_RmtAnswer event to DECT FSM
 *  Input Values    : Please refer pfnRemoteCallAnswer callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_RemoteCallAnswer(
							 IN uint32 uiCallId,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason ;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Answered Call" );

	evtInfo.eEvent = IFX_DECT_EVT_RmtAnswer;
	evtInfo.uiId = uiCallId;

	if( IFX_SUCCESS != 
			LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Remote Call Answer Failed !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallHold
 *  Description     :  This callback function is called by CM to indicate peer 
 *	                   held the call. Pumps IFX_DECT_EVT_RmtHold event to DECT 
 *	                   FSM.
 *  Input Values    : Please refer pfnRemoteCallHold callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_RemoteCallHold(
							 IN uint32 uiCallId,
							 OUT e_IFX_CMGR_Status* peStatus,
							 OUT e_IFX_ReasonCode* peReason,
							 IN void* pvPrivateData )
{
	return IFX_SUCCESS;
}

/*
 */
/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallResume
 *  Description     : This callback function is called by CM once peer resumes 
 *	                  held call. This sends IFX_DECT_EVT_RmtResume event to 
 *	                  DECT PP FSM.
 *  Input Values    : Please refer pfnRemoteCallResume callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_RemoteCallResume(
							 IN uint32 uiCallId,
							 OUT e_IFX_CMGR_Status* peStatus,
							 OUT e_IFX_ReasonCode* peReason,
							 IN void* pvPrivateData )
{
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallHoldResponse 
 *  Description     : This callback function is called by CM to inform status of 
 *	                  hold request (accepts/rejects). This sends 
 *	                  IFX_DECT_EVT_HoldResp event to DECT PP FSM.
 *  Input Values    : Please refer pfnCallHoldRsp callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_CallHoldResponse(
							 IN uint32 uiCallId,
							 IN e_IFX_CMGR_Status eStatus,
							 IN e_IFX_ReasonCode eReason, 
							 IN void* pvPrivateData )
{
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_RemoteCallRelease
 *  Description     :  This callback function is called by CM to indicate remote 
 *                     has released call. This sends IFX_DECT_EVT_ReleaseCall 
 *                     event to DECT PP FSM.
 *  Input Values    : Please refer pfnRemoteCallRelease callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return LTQ_CVOIP_RemoteCallRelease(
               IN uint32 uiCallId,
               IN e_IFX_ReasonCode eReleaseReason,
               IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
               IN void* pvPrivateData )
{
  x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode eReason ;

  pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId, "Call Is Released");

  evtInfo.eEvent = IFX_DECT_EVT_RmtReleaseCall;
  evtInfo.uiId = uiCallId;
  evtInfo.uxEventData.eReasonCode = eReleaseReason;

  if( IFX_SUCCESS !=
      LTQ_CVOIP_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
  {
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
           pxEndptInfo->szEndptId, "!! Remote Call Release Failed !!" );
  }

  return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_MakeDectPPIdle 
 *  Description     : This routine moves DECT FSM into IDLE state by 
 *	                  disconnecting DECT handset's calls and also stops timers,
 *	                  tones and release resources if allocated. This routine is 
 *	                  used in DECT FSM to bring into Idle state.
 *  Input Values    : pxEndptInfo - DECT endpoint info 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MakeDectPPIdle(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{
	x_IFX_DECT_CallInfo* pxCallInfo=0;
	uchar8 ucCount = 0;
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		     pxEndptInfo->szEndptId, "Making DECT Endpoint Idle");

	if( LTQ_CVOIP_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) )
	{
		IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
	}
	  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndptId, "Disconnect both incoming & outgoing calls");
		/* Disconnect both incoming & outgoing calls */
		pxCallInfo = pxEndptInfo->axCallInfo;
		while( ucCount < IFX_MAX_DECT_CALLS)
		{
			if( pxCallInfo->eState != IFX_DECT_CS_NONE )
			{
        /*if(!LTQ_CVOIP_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_ATX_PENDING) ){
				  if(pxCallInfo->uiCallId){
				    IFX_CMGR_CallRelease(pxCallInfo->uiCallId, IFX_TERMINATED, NULL,
						                     NULL, &eReason);
				  }
        }*/
				IFX_DECT_ResetCall(pxCallInfo,0);
			}
      else {
	      IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Call State is IFX_DECT_CS_NONE");
      }
			++ucCount;
			++pxCallInfo;
		}
		if( LTQ_CVOIP_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED) )
		{  
					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Resource Allocated. Deallocate it");
#if 0
				IFX_MMGR_DectResDealloc(pxEndptInfo->szEndptId);
				if( IFX_MMGR_SUCCESS != IFX_MMGR_DectResDealloc(pxEndptInfo->szEndptId) )
				{
						/* Could not de-allocate signaling resource !! */
						IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndptId,"Could Not Release DECT Resource");
				}	
#endif	
			/* set reserved codec list to 0 and running codec to none */
			pxEndptInfo->xReservedCodecs.ucNoOfCodecs = 0;
			pxEndptInfo->eRunningCodec = IFX_MMGR_CODEC_NONE;
	}
 /*	   
	* Reset all flags, except those that can be used in idle state. Set last		    
	* active call to NULL. Clear collected digits if exist.				   
	*/
	pxEndptInfo->uiFlags &= IFX_DECT_FLAGS_IN_IDLE_STATE ;
	pxEndptInfo->pxActiveCall = NULL;
	//pxEndptInfo->uiConfReqId = 0;
  memset(pxEndptInfo->szDialledDigits,0,IFX_MAX_DIGITS);
	pxEndptInfo->szCallerNumber[0] = pxEndptInfo->szCallerName[0] = '\0';
  pxEndptInfo->uiDTkCallId = 0;
	
	LTQ_CVOIP_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);
	
	return IFX_SUCCESS;
}

/** Registration Related API's */

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_DECT_HS_Info_Notify 
 *  Description     : This routine is used to handle Handset Registration related
											Events 
 *  Input Values    : pxEndptInfo - DECT endpoint info 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/

e_IFX_Return 
LTQ_CVOIP_DECT_HS_Info_Notify(IN x_LTQ_CVOIP_DECT_HS_NotifyInfo *pxAttachInfo)
{

  x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  uchar8 ucLineIdList[10] = {'\0'};
  e_IFX_ReasonCode eReason;
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "In LTQ_CVOIP_DECT_HS_Notify");
  pxAttachInfo->ucHandSet--;
  switch(pxAttachInfo->eEvent){
    case LTQ_CVOIP_HS_REGISTERED:
			if(iMode==1){
				iMode=0;
			}
			printf("\n REGISTERING HS %d\n",pxAttachInfo->ucHandSet + 1);

#ifdef WRITE_SUBS_INFO
        char aszRegDate[32], aszRegTime[32];
        char aszRegDateTime[64];
#endif
        if(vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].ucInstance == IFX_DECT_INVALID_INSTANCE )
        {
					printf("<LTQ_CVOIP_DECT_HS_Info_Notify>Saving into RC.Conf Info of %s \n",vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].szEndptId);
          vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].ucInstance = pxAttachInfo->ucHandSet;
					vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].xDECTSubsInfo.bIsRegistered = IFX_TRUE;
					//vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].xDECTSubsInfo.uiTermCap = pxAttachInfo->uiTermCap;
					//vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].bWidebandEnabled = pxAttachInfo->uiTermCap;

#ifdef WRITE_SUBS_INFO
          //Update Registration time
          IFX_GetDateTime(aszRegDate, aszRegTime);
          sprintf(aszRegDateTime, "%s %s", aszRegDate,aszRegTime);
          IFX_CIF_DectSubsInfoSet(vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].szEndptId,
                                &vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].xDECTSubsInfo,
                                IFX_FALSE, //Don't know at this point
                                aszRegDateTime );
					system("/etc/rc.d/backup &"); //save config

#endif
 /* If handset is not Associated to any of the line,default line,Line association is being set*/
    if(IFX_SUCCESS == IFX_CIF_AssocLineIdsGet((pxAttachInfo->ucHandSet+1), (uchar8 *)&ucLineIdList))
    {
      if(ucLineIdList[0] == 0 ) {
        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "!! Not Associated to any line  !!" );

        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Get the VoiceLineId list. Set the list to endpoint line id list" );
        IFX_CIF_LineIdListGet((uchar8 *)&ucLineIdList);

        IFX_CIF_AssocLineIdSet((pxAttachInfo->ucHandSet+1),ucLineIdList[0]);

        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Set to default VoiceLine" );
        IFX_CIF_EndptDefaultVLSet(
                   vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].szEndptId,
                   ucLineIdList[0],&eReason );

        IFX_CIF_LineAssocSet((pxAttachInfo->ucHandSet+1),ucLineIdList[0]);
        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Line association set for the Handset" );
      }
    }

    }else{
          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "!! Already Registered !!" );
    }
   break;

		case LTQ_CVOIP_HS_ATTACHED:
        if( IFX_SUCCESS !=
            IFX_DECT_GetEndptInfoByInstance(pxAttachInfo->ucHandSet, &pxEndptInfo) )
        {
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "No Handset Registered With This Instance Number" );
              printf("!!!!! Handset Not Registered with Instance Number %d\n",pxAttachInfo->ucHandSet+1);
        } else {
            pxEndptInfo->bWidebandEnabled = (pxAttachInfo->uiTermCap & 1);
            pxEndptInfo->bG711Enabled = ( (pxAttachInfo->uiTermCap >> 1) & 1 );
          /* Whenever attach comes store term caps */
          pxEndptInfo->uiTermCap = pxAttachInfo->uiTermCap;
          pxEndptInfo->xDECTSubsInfo.uiTermCap = pxAttachInfo->uiTermCap;
          printf("Term Capab : %d & Attached Info %d\n",pxAttachInfo->uiTermCap,pxEndptInfo->bPPAttached);
          if( IFX_TRUE != pxEndptInfo->bPPAttached )
          {
            IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
                     IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId,
                     "Endpt is not attached.");
            	//Register callbacks with call manager
	            pxEndptInfo->bPPAttached = IFX_TRUE;
						/* Save terminal Capabilities of the remote part */
            if( IFX_SUCCESS != LTQ_CVOIP_CbRegisterWithCmgr(pxEndptInfo) )
            {
              IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
                IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId,
                "Could Not Register Callbacks With Call Manager");
								return IFX_FAILURE;
            }
  
		            IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,  pxEndptInfo->szEndptId,
                "Handset Attached. It Can Make/Receive Calls");
          }
					vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].xDECTSubsInfo.uiTermCap = pxAttachInfo->uiTermCap;
					vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].bWidebandEnabled = pxAttachInfo->uiTermCap;
          IFX_CIF_DectSubsInfoSet(vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].szEndptId,
                                &vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].xDECTSubsInfo,
                                pxEndptInfo->bWidebandEnabled,
                                NULL );
					system("/etc/rc.d/backup &"); //save config
				printf(">>>>>>> Handset %s Attached. It Can Make/Receive Calls",pxEndptInfo->szEndptId);		
      }
        break;
    case LTQ_CVOIP_HS_UNREGISTERED:
        if( IFX_SUCCESS !=
          IFX_DECT_GetEndptInfoByInstance(pxAttachInfo->ucHandSet, &pxEndptInfo) )
        {
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Could Not Retrieve Handset Information" );
        } else {
       					  pxEndptInfo->bPPAttached = IFX_FALSE;
			      	    pxEndptInfo->ucInstance = IFX_DECT_INVALID_INSTANCE;
      			    	pxEndptInfo->xDECTSubsInfo.bIsRegistered = 0;
				          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_NORMAL,IFX_DBG_ATA_STRING_INFO,
			            pxEndptInfo->szEndptId, "Handset Is Unregistered" );
      			      printf("\n\n Handset Is Unregistered %s",pxEndptInfo->szEndptId);
			            IFX_CIF_DectSubsInfoSet(pxEndptInfo->szEndptId,
      			            &pxEndptInfo->xDECTSubsInfo,
            			      pxEndptInfo->bWidebandEnabled, NULL);

        }
        break;
 		default:
  	     break;
   }/* end of switch*/
   return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : LTQ_CVOIP_AgentShut
 *  Description     : This function unregisters DECT handset. Before
 *                    unregistering calls will be disconnected.
 *  Input Values    : aszEndPointId - List of DECT endpoint Ids
 *                    ucNoOfEndpts  - Number of DECT endpoints available in the
 *                      list
 *  Output Values   : -
 *  Return Value    : If handset is unregistered successfully, this routine
 *                    returns IFX_SUCCESS, otherwise IFX_FAILURE.
 *  Notes           : If handset is not attached it may not get unregister
 *                    request
 ******************************************************************************/
e_IFX_Return IFX_CVOIP_AgentShut(
                    IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
                    IN uchar8 ucNoOfEndpts)
{
  uchar8 ucEndptSlot = 0;
  uchar8 ucEndptIndex = 0;
  boolean bShutProblem = IFX_FALSE;
	char8 acBuff[LTQ_CVOIP_MAX_ATCMD]={'\0'};
  IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                                            "Shutting Down DECT Endpoint(s)");
	e_IFX_ReasonCode peReason;
  /*
   * For each endpoint in aszEndPointId, make endpoint idle
   */
  while( ucEndptIndex < ucNoOfEndpts )
  {
    ucEndptSlot = 0;
    while( ucEndptSlot < IFX_MMGR_MAX_DECT_CHANNELS )
    {
      if( strcmp(aszEndPointId[ucEndptIndex],
        vaxDectEndptFsmInfo[ucEndptSlot].szEndptId) == 0 )
      {
        break;
      }
		++ucEndptSlot;
    }
 if( IFX_MMGR_MAX_DECT_CHANNELS == ucEndptSlot )
    {
      bShutProblem = IFX_TRUE;
    }
    else
    {
      x_IFX_DECT_EndptFsmInfo* pxEndPtInfo = (vaxDectEndptFsmInfo+ucEndptSlot);

      if( IFX_TRUE == pxEndPtInfo->bPPAttached )
      {
        if( IFX_DECT_STATE_IDLE != pxEndPtInfo->eState ) {
				if(pxEndPtInfo->pxActiveCall)
					    IFX_CMGR_CallRelease(pxEndPtInfo->pxActiveCall->uiCallId,
                                        IFX_ABNORMAL_RELEASE, NULL, NULL, &peReason);
  				/* Send following AT Command  to CVoIP
					    NOCARRIER ctxid=HSID
				  */	
  				printf("\nSending NOCARRIER from %d \n",pxEndPtInfo->ucInstance+1);
				  if (IFX_SUCCESS != IFX_CVOIP_ConstNSendATCmd(LTQ_ATResp_NoCarrier, NULL, pxEndPtInfo->ucInstance+1)){
        			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
		          "Setting +NOCARRIER Response failed...." );
    			    return IFX_FAILURE;
					  }
          IFX_DECT_MakeDectPPIdle(pxEndPtInfo);
        }
			if( IFX_SUCCESS != IFX_CMGR_CallBacksUnRegister(aszEndPointId+ucEndptIndex, 1))
        {
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
              aszEndPointId[0], "IFX_CMGR_CallBacksUnRegister FAILED");
          bShutProblem = IFX_TRUE;
        }
      }
          if(pxEndPtInfo->ucInstance != IFX_DECT_INVALID_INSTANCE){
        			/* Unregister PP */
				        //IFX_DECT_MU_UNRegister(0,pxEndPtInfo->ucInstance+1);
							/* TODO: Change AT command appropriately */
				    sprintf(acBuff,"+CREG %d,2,,0",pxEndPtInfo->ucInstance+1);
						printf("************ UnRegister Message to CVoIP : %s\n",acBuff);
    	if(LTQ_CVOIP_SendMsg(acBuff,strlen(acBuff)) != IFX_SUCCESS){
      			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Failed in sending Un-Register request to CVoIP...." );
    	}
	
            }
      memset(pxEndPtInfo,0,sizeof(x_IFX_DECT_EndptFsmInfo));
      //Don't erase endpt id
      strcpy(pxEndPtInfo->szEndptId, aszEndPointId[ucEndptIndex]);
//Erase subscription info from configuration.
      IFX_CIF_DectSubsInfoSet(pxEndPtInfo->szEndptId,
                                &pxEndPtInfo->xDECTSubsInfo,
                                pxEndPtInfo->bWidebandEnabled, "");

#ifndef UTA
    system("/etc/rc.d/backup"); //save config
#endif
      pxEndPtInfo->ucInstance = IFX_DECT_INVALID_INSTANCE;
    }
++ucEndptIndex;
  } /* while */

  return (IFX_TRUE == bShutProblem)?IFX_FAILURE:IFX_SUCCESS;
}


/**** Dummy Callmanager callbacks */

e_IFX_Return LTQ_CVOIP_CallResumeResponse(
               IN uint32 uiCallId,
               IN e_IFX_CMGR_Status eStatus,
               IN e_IFX_ReasonCode eReason,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_ConfStatus(
               IN uint32 RequestId,
               IN e_IFX_CMGR_Status eStatus,
               IN e_IFX_ReasonCode eReason,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

 e_IFX_Return LTQ_CVOIP_CallForwardInfo(
               IN uint32 uiCallId,
               IN e_IFX_ReasonCode eReason,
               IN x_IFX_CMGR_AddressInfo* pxFwdAddr,
               OUT boolean* pbFwdAllow,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_BlindTxRequest(
               IN uint32 uiCallId,
               IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
               OUT e_IFX_TransferStatus* peTransferStatus,
               OUT e_IFX_ReasonCode *peRespCode,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_AttendedTxRequest(
               IN uint32 uiCallId,
               IN uint32 uiReplacesCallId,
               IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
               OUT e_IFX_TransferStatus* peTransferStatus,
               OUT e_IFX_ReasonCode *peRespCode,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_BlindTxStatus(
               IN uint32 uiCallId,
               IN e_IFX_TransferStatus eTransferStatus,
               IN e_IFX_ReasonCode eRespCode,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_AttendedTxStatus(
               IN uint32 uiCallId,
               IN e_IFX_TransferStatus eTransferStatus,
               IN e_IFX_ReasonCode eRespCode,
               IN void* pvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_CallIdReplace(
                 IN uint32 uiOldCallId,
                 IN uint32 uiNewCallId,
                 IN_OUT void** ppvPrivateData ){ return IFX_SUCCESS; }

e_IFX_Return LTQ_CVOIP_GetMediaParams(
                 IN uint32 uiCallId,
                 OUT x_IFX_CMGR_MediaParams* pxMediaParams,
                 IN void* pvPrivateData ){
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo 
																	= (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	x_IFX_CMGR_ExtnMediaParams* pxExtnMediaParams = 
											&pxMediaParams->uxMediaParams.xExtnMediaParams;

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Call Manager Is Requesting For Media Params");
		pxMediaParams->eAgentType = IFX_CMGR_TYPE_EXTN;
		pxExtnMediaParams->xCodecParams.unNoOfCodecs = 1;
		pxExtnMediaParams->xCodecParams.axCodec[0].uiCodec = 
													IFX_DECT_GetCmgrCodec(pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType);
		return IFX_SUCCESS;
}

e_IFX_Return LTQ_CVOIP_MediaNegReq(
                 IN uint32 uiCallId,
                 IN_OUT x_IFX_CMGR_MediaParams* pxMediaParams,
                 OUT e_IFX_CMGR_Status* peStatus,
                 OUT e_IFX_ReasonCode* peReason,
                 IN void* pvPrivateData ){ 
return IFX_SUCCESS; 
}

e_IFX_Return LTQ_CVOIP_MediaNegResp(
                 IN uint32 uiCallId,
                 IN x_IFX_CMGR_MediaParams* pxMediaParams,
                 IN_OUT e_IFX_CMGR_Status* peStatus,
                 IN_OUT e_IFX_ReasonCode* peReason,
                 IN void* pvPrivateData ){ 
return IFX_SUCCESS; 
}


e_IFX_Return
IFX_CVOIP_ConstNSendATCmd(e_LTQ_ATCmd_Type eCmdType, uchar8 **ppucStrParam, uchar8 ucByteParam)
{
  void *pTxCmdHdl = NULL;
  uchar8  *pucBuff = NULL, ucSize = 0, i = 0, j=0;

  printf("<IFX_CVOIP_ConstNSendATCmd>, Entry\n");

  if (IFX_SUCCESS != LTQ_ATCmd_CmdTypeSet(&pTxCmdHdl, eCmdType)){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Setting AT Cmd failed...." );
    printf("IFX_CVOIP_ConstNSendATCmd, LTQ_ATCmd_CmdTypeSet failed for %d Cmd\n",eCmdType);
    return IFX_FAILURE;
  }
	if (ppucStrParam != NULL && ppucStrParam[0][0] == '?'){
        LTQ_ATCmd_ValueSet(1, pTxCmdHdl, (uchar8 *)"0?");
	}else {
					switch(eCmdType){

					case	LTQ_ATCmd_Config_PCM :
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, 0);
							LTQ_ATCmd_ValueSet(3, pTxCmdHdl,(uchar8 *)"2048");
							LTQ_ATCmd_ByteValueSet(4, pTxCmdHdl,8);
							j=5;
							for(i = 0 ; i < 4 ; i++){
								//nTimeslotRX;
								//nTimeslotTX
								LTQ_ATCmd_ByteValueSet(j++, pTxCmdHdl, xPcmConfig[i].nTimeslotTX);
								//LTQ_ATCmd_ByteValueSet(j++, pTxCmdHdl, xPcmConfig[i].nTimeslotRX);
								LTQ_ATCmd_ByteValueSet(j++, pTxCmdHdl, i);
							}
							 LTQ_ATCmd_ByteValueSet(j++, pTxCmdHdl,0);
               LTQ_ATCmd_ByteValueSet(j++, pTxCmdHdl,0);
					break;

						case LTQ_ATCmd_TBR06:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ucByteParam);
							break;

						case LTQ_ATCmd_TPC:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<LTQ_TPCCmd_TxBias-1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;
						
						case LTQ_ATCmd_Pin:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							LTQ_ATCmd_ValueSet(2, pTxCmdHdl, ppucStrParam[0]);
							break;

						case LTQ_ATResp_Ok:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
							break;

						case LTQ_ATCmd_BMC:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<  LTQ_BMCCmd_HOPeriod-1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
								LTQ_ATCmd_ByteValueSet(LTQ_BMCCmd_PowerLevel, pTxCmdHdl, ppucStrParam[0][i+4]);
								LTQ_ATCmd_ByteValueSet(LTQ_BMCCmd_PowerAlgorithm, pTxCmdHdl, ppucStrParam[0][i+5]);
								LTQ_ATCmd_ByteValueSet(LTQ_BMCCmd_NormalTcoRR, pTxCmdHdl, ppucStrParam[0][i+1]);
								LTQ_ATCmd_ByteValueSet(LTQ_BMCCmd_NormalBattmeas, pTxCmdHdl, ppucStrParam[0][i+0]);
								LTQ_ATCmd_ByteValueSet(LTQ_BMCCmd_GreenTcoRR, pTxCmdHdl, ppucStrParam[0][i+3]);
								LTQ_ATCmd_ByteValueSet(LTQ_BMCCmd_GreenBattmeas, pTxCmdHdl, ppucStrParam[0][i+2]);
							break;

						case LTQ_ATCmd_OscTrim:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<LTQ_OscTrimCmd_P10-1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;

						case LTQ_ATCmd_Gfsk:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<LTQ_GfskCmd_LOW-1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;

						case LTQ_ATCmd_RfMode:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<LTQ_RfModeCmd_Slot-1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;
						case LTQ_ATCmd_Rfpi:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<LTQ_RfpiCmd_Byte4-1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;

						case LTQ_ATCmd_RAM:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ucByteParam);
							for (i=0; i<LTQ_RfpiCmd_Byte4-2; i++){//aarif
								LTQ_ATCmd_ByteValueSet(i+3, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;

						case LTQ_ATCmd_Freq:
							LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
							for (i=0; i<LTQ_FreqCmd_ChMaskLow - 1; i++){
								LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
							}
							break;

						case LTQ_ATCmd_Capabilities:
							/*switch (ppucStrParam[0][0]){
								case '?':
									LTQ_ATCmd_ValueSet(1, pTxCmdHdl, (uchar8 *)"0?");
									break;

								case LTQ_BaseCapCmd_Encryption:
									LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
									vaucBaseCapabParams[LTQ_BaseCapCmd_Encryption] = ucByteParam;
									for (i=2; i<LTQ_BaseCapCmd_Rekeying+1; i++){
										LTQ_ATCmd_ByteValueSet(i, pTxCmdHdl, vaucBaseCapabParams[i]);
									}
									break;
								default:*/
									LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
									LTQ_ATCmd_ByteValueSet(LTQ_BaseCapCmd_Encryption, pTxCmdHdl,ucByteParam);
							//		break;
							//}
							break;

					case	LTQ_ATCmd_Reset:            /*!< AT Command for Modem reset */
					//case  LTQ_ATCmd_Save:
								LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
								LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, 1);
					break;

							case LTQ_ATResp_NoCarrier:
								LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
						break;

							case LTQ_ATResp_Connect:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
										LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ppucStrParam[0][i]);
							break;
						
						case LTQ_ATCmd_COAP:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
									for (i = 0; i < LTQ_COAPCmd_Codec3 - 1; i++){
										LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
									}
									LTQ_ATCmd_ByteValueSet(LTQ_COAPCmd_Codec3+1, pTxCmdHdl,1);
						break;

						case LTQ_ATCmd_Tone:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
										LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ppucStrParam[0][i]);
						break;
						
						case LTQ_ATCmd_IncomingCall:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
									for (i = 0; i < LTQ_CallIncomingCmd_Codec3 - 1; i++){
										LTQ_ATCmd_ByteValueSet(i+2, pTxCmdHdl, ppucStrParam[0][i]);
									}
						break;

						case  LTQ_ATCmd_RemoteAccept:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
										LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ppucStrParam[0][i]);	
						break;
					
						case LTQ_ATCmd_CallProceeding:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, ucByteParam);
										LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ppucStrParam[0][i]);	
						break;
						
						case LTQ_ATCmd_HSIDLE:
										LTQ_ATCmd_ByteValueSet(1, pTxCmdHdl, 0);
										LTQ_ATCmd_ByteValueSet(2, pTxCmdHdl, ucByteParam);	
						break;

						default:
								LTQ_ATCmd_FreeHandle(pTxCmdHdl);
								return IFX_FAILURE;
  			}
	}
  ucSize = LTQ_ATCmd_BufferGet(pTxCmdHdl, &pucBuff);

  printf ("**************<IFX_CVOIP_ConstNSendATCmd> Cmd is %s\n",pucBuff);

  if(LTQ_CVOIP_SendMsg((char8*)pucBuff,ucSize) != IFX_SUCCESS){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Failed in sending AT cmd to CVoIP...." );
  }

  LTQ_ATCmd_FreeHandle(pTxCmdHdl);
  return IFX_SUCCESS;
}


e_IFX_Return
IFX_CVOIP_ConstNSendCOAPcmd(x_IFX_DECT_EndptFsmInfo* pxEndptInfo,uchar8 pucOperation,uchar8 ucServiceChange)
{
	uchar8 aucBuf[6]={0};
	uchar8 *pucBuff= aucBuf;
	//x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
	
	//+COAP Command Send
  memset(&aucBuf,0,sizeof(aucBuf));
  aucBuf[0]=(uchar8)pxEndptInfo->uiDTkCallId; //CallId
  aucBuf[1]=pucOperation; //Operation
  //aucBuf[2]=pxEndptInfo->unDectChannel; //Channel Id
	aucBuf[2] = vaucPcmChannelNo[atoi(pxEndptInfo->szEndptId)-1]-1;

//wideband call
  switch (pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType) { 
					case IFX_MMGR_CODEC_G722_64:
							LTQ_CVOIP_getCvoipCodectList(1,&aucBuf[3]);
					break;

				  case IFX_MMGR_CODEC_G726_32:
	 							LTQ_CVOIP_getCvoipCodectList(2,&aucBuf[3]);
					break;
			
						default :
							LTQ_CVOIP_getCvoipCodectList(3,&aucBuf[3]);
	}
 
if(ucServiceChange){
	if(!LTQ_CVOIP_isValidDectEndPoint(atoi(pxEndptInfo->szCallerNumber)) == IFX_SUCCESS){
		//aucBuf[2] = vaucPcmChannelNo[atoi(pxEndptInfo->szEndptId)-1]-1;
		if(pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType == IFX_MMGR_CODEC_ALAW &&
                pxEndptInfo -> bG711Enabled){
										LTQ_CVOIP_getCvoipCodectList(3,&aucBuf[3]);
                }
								else if(pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType == IFX_MMGR_CODEC_G722_64 &&
                pxEndptInfo ->bWidebandEnabled){
										LTQ_CVOIP_getCvoipCodectList(1,&aucBuf[3]);
								}
								else {
										LTQ_CVOIP_getCvoipCodectList(2,&aucBuf[3]);
                }
		//aucBuf[3]=IFX_DECTNG_CODEC_G726_32 - 1; //codec 1
    //aucBuf[4]=IFX_DECTNG_CODEC_G711_A - 1; //codec 3
	}
}

	return  IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_COAP,&pucBuff,pxEndptInfo->ucInstance+1);
}

void AllocPcmChannel(int32 iEndPtId)
{
	uchar8 i=0;

	for (i=0; i<4; i++){
		if(vaucPcmChannelNo[i] == 0){
			vaucPcmChannelNo[iEndPtId-1] = i+1;
			break;
		}
	}
	printf("--------Channel:%d allocated for HS:%d----\n",i+1,iEndPtId);
	return;
}

/* Function returns the codec list based on the type */
e_IFX_Return LTQ_CVOIP_getCodectListFilled(IN uint32 uiClistType, OUT x_IFX_CodecList *pxCodecList){

	switch(uiClistType){
		case 2:		
		  	  pxCodecList->axCodec[0].uiCodec = IFX_G726_32;
					pxCodecList->axCodec[1].uiCodec = IFX_G722_64; //IFX_G722_64;//high priority
		    	pxCodecList->axCodec[2].uiCodec = IFX_G711_ALAW;
		break;

		case 3:		
		    	pxCodecList->axCodec[0].uiCodec = IFX_G711_ALAW;
		  	  pxCodecList->axCodec[1].uiCodec = IFX_G726_32;
					pxCodecList->axCodec[2].uiCodec = IFX_G722_64; //IFX_G722_64;//high priority
		break;

		default:
					pxCodecList->axCodec[0].uiCodec = IFX_G722_64; //IFX_G722_64;//high priority
		  	  pxCodecList->axCodec[1].uiCodec = IFX_G726_32;
		    	pxCodecList->axCodec[2].uiCodec = IFX_G711_ALAW;
		break;	
	}
pxCodecList->unNoOfCodecs = 3; // number of codecs
return IFX_SUCCESS;
}

/* Function returns the codec list based on the type */
e_IFX_Return LTQ_CVOIP_getCvoipCodectList(IN uint32 uiClistType, OUT uchar8 *aucBuf){

	switch(uiClistType){
      case 2:
					aucBuf[0]=IFX_DECTNG_CODEC_G726_32 - 1; //codec 1
		      aucBuf[1]=IFX_DECTNG_CODEC_G722_64 - 1; //codec 2
    		  aucBuf[2]=IFX_DECTNG_CODEC_G711_A - 1; //codec 3
			break;
			case 3:	
	      aucBuf[0]=IFX_DECTNG_CODEC_G711_A - 1; //codec 1
  	    aucBuf[1]=IFX_DECTNG_CODEC_G722_64 - 1; //codec 2
    	  aucBuf[2]=IFX_DECTNG_CODEC_G726_32 - 1; //codec 3
			break;
			default:		
					aucBuf[0]=IFX_DECTNG_CODEC_G722_64 - 1; //codec 1
    		  aucBuf[1]=IFX_DECTNG_CODEC_G726_32 - 1; //codec 2
      		aucBuf[2]=IFX_DECTNG_CODEC_G711_A - 1; //codec 3
			break;
  }
return IFX_SUCCESS;
}
