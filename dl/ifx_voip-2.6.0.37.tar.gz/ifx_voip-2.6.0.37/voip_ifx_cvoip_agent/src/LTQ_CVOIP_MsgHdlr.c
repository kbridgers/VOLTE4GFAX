/**************************************************************************
 **   SRC_FILE          : LTQ_CVOIP_MsgHdlr.c
 **   PROJECT           : COSIC VoIP
 **   MODULES           : Cosic VoIP Message handler
 **   SRC VERSION       : v0.1
 **   DATE              : 15/9/2011
 **   AUTHOR            :
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
//#ifdef LTQ_CVOIP_DECT
#include <stdio.h>
#include <string.h>
/* According to POSIX 1003.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
//#include <linux/delay.h>
#include "ifx_common_defs.h"
#include "IFX_Config.h"
//#define printf(...)

#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "IFX_TimerIf.h"
#include "LTQ_CVOIP_MsgHdlr.h"
#include "LTQ_APP_Parser_Intf.h"
#include "LTQ_CVOIP_Agent.h"

/* Local defines */
#define LTQ_CVOIP_PAGEKEY_DRV	        "/dev/pb"
//#define COSIC_STUB
#ifdef COSIC_STUB
x_IFX_MSGRTR_FdInfo axDectFdInfo[2];
#define LTQ_CVOIP_DEVICE_NAME         "/tmp/stub"
#else
#define LTQ_CVOIP_DEVICE_NAME         "/dev/dect_drv"
#endif

/* Static variables */
//STATIC int32 viPagingKeyFd,viCVoipFd; /** Fd used to read Paging Key events */
int32 viPagingKeyFd,viCVoipFd; /** Fd used to read Paging Key events */
EXTERN uchar8 vucDectAgnetModId;

/******************************************************************
*  Function Name    :LTQ_CVOIP_MsgRoterFdHdlr
*  Description      :This function handles messages received from the 
*                    Fds registered with Msg Router 
*  Input Values     :FD that unblocked
*  Output Values    :None
*  Return Value     :IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_Return 
LTQ_CVOIP_MsgRouterFdHdlr(IN int32 iFd)
{
	printf("Entry in LTQ_CVOIP_MsgRouterFdHdlr\n");
#ifdef ENABLE_PAGING
	if(viPagingKeyFd == iFd){
	printf("LTQ_CVOIP_MsgRouterFdHdlr, paging FD unblocked....\n");
		uint32 uiPageKeyPressDur;
		char8  aucPagingInfo[32];
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
																			"Paging Key Pressed");
		if(read(viPagingKeyFd, aucPagingInfo, 32)>0){
			uiPageKeyPressDur = atoi(aucPagingInfo);
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO, 
				"Actual Duration Of Key Pressed = ", uiPageKeyPressDur);
			printf("LTQ_CVOIP_MsgRouterFdHdlr, paging key pressed for %d \n",uiPageKeyPressDur);
			LTQ_CVOIP_ProcessPagekeyMessage(uiPageKeyPressDur*100);
		}
		else{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
								"Could Not Read Paging Data Properly");
	printf("LTQ_CVOIP_MsgRouterFdHdlr, read failed\n");
		}
	}
#endif
	if(viCVoipFd == iFd){
		printf("LTQ_CVOIP_MsgRouterFdHdlr, CVOIP FD unblocked....\n");
	  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
			       "CVoIP FD unblocked");
    /* Handle the AT command received from the modem */
		uchar8 aucATCmdBuff[256] = {0};
		//if(errno)
			//perror("After rewind cvoip fd");
		if(read(viCVoipFd, aucATCmdBuff, 256)>0){
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
								"AT cmd is read from CVoip FD");
			printf("LTQ_CVOIP_MsgRouterFdHdlr, cmd is %s....\n",aucATCmdBuff);
			//rewind((FILE *)viCVoipFd);
			//fseek((FILE *)viCVoipFd, 0L, SEEK_SET);
#ifdef COSIC_STUB
			if (IFX_MSGRTR_FdUnregister(&axDectFdInfo[0]) != IFX_SUCCESS){
				printf("LTQ_CVOIP_MsgRouterFdHdlr, CVOIP FD unreg failed....1\n");
			}else{
				printf("LTQ_CVOIP_MsgRouterFdHdlr, CVOIP FD unreged....1\n");
			}
#endif
      LTQ_CVOIP_ProcessATCmd(aucATCmdBuff);
    }else{
			perror("Could not read from cvoip fd");
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Could Not read AT cmd");
#ifdef COSIC_STUB
			if (IFX_MSGRTR_FdUnregister(&axDectFdInfo[0]) != IFX_SUCCESS){
				printf("LTQ_CVOIP_MsgRouterFdHdlr, CVOIP FD unreg failed....2\n");
			}else{
				printf("LTQ_CVOIP_MsgRouterFdHdlr, CVOIP FD unreged....2\n");
			}
#endif
			printf("LTQ_CVOIP_MsgRouterFdHdlr, could not read at cmd....\n");
    }
#ifdef COSIC_STUB
		if (close(viCVoipFd) < 0)
			perror("closing cvoip fd failed");
#endif
	} 
//aarif
	return IFX_SUCCESS;
}

/******************************************************************
*  Function Name    :LTQ_CVOIP_Init
*  Description      :This function opens both the driver Fds 
*  Input Values     :None 
*  Output Values    :None
*  Return Value     :IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_Return
LTQ_CVOIP_Init()
{
#ifndef COSIC_STUB
  x_IFX_MSGRTR_FdInfo axDectFdInfo[2];
#endif
  uint32 uiNoOfFdsReg=0;
  /* Open the page button driver */
#ifdef ENABLE_PAGING 
  if((viPagingKeyFd = open(LTQ_CVOIP_PAGEKEY_DRV, O_RDWR|O_NONBLOCK))<0){
    //IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				//"Paging Key Drv open Failed");
		printf("CVOIP_Init, Paging Key Drv open Failed\n");
    return IFX_FAILURE;
  } 
#endif
  /* Open the DECT driver */
  if((viCVoipFd = open(LTQ_CVOIP_DEVICE_NAME, O_RDWR|O_NONBLOCK))<0){
    //IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			//	"Opening the CVoIP Failed");
		printf("CVOIP_Init, CVOIP open Failed\n");
    return IFX_FAILURE;
  } 
	/* Powering on the CVoIP so that CV can igone first CS low*/
	//system("echo 1 > /sys/class/leds/ledc_8/brightness");
  /* Register the FDs with Message router */
  axDectFdInfo[0].uiFd = viCVoipFd;
  axDectFdInfo[0].eFdSetType = IFX_MSGRTR_READ_TYPE;
  uiNoOfFdsReg++;
#ifdef ENABLE_PAGING 
 	axDectFdInfo[1].uiFd = viPagingKeyFd;
	axDectFdInfo[1].eFdSetType = IFX_MSGRTR_READ_TYPE;
  uiNoOfFdsReg++;
#endif
#ifdef TEST_CV
	{
		fd_set  xTempReadFdSet;
    int32 iNumFds;
		FD_ZERO(&xTempReadFdSet);
		FD_SET(viCVoipFd, &xTempReadFdSet);
    iNumFds = select(viCVoipFd+1, &xTempReadFdSet, NULL, NULL, NULL);
    if (iNumFds <= 0)
    {
			perror("return from select");
      /* something wrong has happened, exit from this place */
      printf(" select failed :: EXITING APPLICATION\n" );
      exit(-1);
    }
	}
#else
  if(IFX_SUCCESS != IFX_MSGRTR_FdCallBackRegister(axDectFdInfo, 
								uiNoOfFdsReg,LTQ_CVOIP_MsgRouterFdHdlr)){
   // IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		//				 "IFX_MSGRTR_FdCallBackRegister Failed");
		printf("CVOIP_Init, Registering FDs Failed\n");
		return IFX_FAILURE;
  }
#endif
	printf("CVOIP_Init, Success\n");
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :LTQ_CVOIP_SendMsg
*  Description      :This function Sends Msg to Cosic Via via SPI interface 
*  Input Values     :Buffer, Length of buffer 
*  Output Values    :None
*  Return Value     :IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_Return
LTQ_CVOIP_SendMsg(char *pcMsg, int iLen)
{
#ifndef COSIC_STUB
  int32 iRet;
  iRet = write(viCVoipFd,pcMsg,iLen);
  if(iRet < 0){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				"Sending Message to CVoIP failed");
		printf("^^^^^^^^^LTQ_CVOIP_SendMsg, write failed 1st Time....\n");
		//udelay(300000);	
  	iRet = write(viCVoipFd,pcMsg,iLen);
  if(iRet < 0){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				"Sending Message to CVoIP failed");
				printf("^^^^^^^^^LTQ_CVOIP_SendMsg, write failed 2nd Time....\n");
    return IFX_FAILURE;
	}
 }
#endif
		printf("LTQ_CVOIP_SendMsg, writen successfully\n");
  return IFX_SUCCESS;
}
//#endif
