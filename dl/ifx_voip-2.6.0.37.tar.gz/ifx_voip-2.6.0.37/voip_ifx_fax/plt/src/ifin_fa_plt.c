/**************************************************************************
 **   SRC_FILE          : ifin_fa.c
 **   PROJECT           : T.38 Fax Relay
 **   MODULES           :
 **   SRC VERSION       : v1.0
 **   DATE              : 
 **   AUTHOR            : Haribalram. R
 **   DESCRIPTION       : T.38 Fax Agent
 **   FUNCTIONS         :
 **   COMPILER          :
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT      	: Copyright © 2004 Infineon Technologies AG
 **                     	St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER     	: Any use of this Software is subject to the conclusion
 **                    	of a respective License Agreement.Without such a
 **                    	License Agreement no rights to the Software are grant.
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
 **************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <string.h>
#define  TAPI_TYPES_DEFINED
#include "ifx_common_defs.h"
//#include "ifx_types.h"
#include "drv_tapi_io.h"
#include "ifin_fa.h"
//#include "ifx_faxapp_app.h"
#include "ifx_debug.h"
#include "mt_t38_interface_import.h"
#define IFX_KPI_SUPPORT 1
#ifdef IFX_KPI_SUPPORT
#include "drv_tapi_kpi_io.h"
#include "drv_tapi_qos_io.h"
#endif
#define USE_SWITCH_API_ENUM_H
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_faxapp_app.h"

#define IFX_FA_GAIN_MIN     -24
#define IFX_FA_GAIN_MAX      12
#define IFX_FA_GAIN_TBL_ROW   7
uint16 dBToVinGainTbl[IFX_FA_GAIN_TBL_ROW] = { 0, 4, 8, 13, 19, 25 , 31 };
#ifdef IFX_T38_FW
STATIC int16 IFX_FA_PLT_VinGainTodB(uint16, int16* );
// #else
//STATIC int16 IFX_FA_PLT_dBToVinGain(int16, uint16* );
#endif

EXTERN char8 vcFaxModId;

/* EXTERN Functions */

/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_Init
 *  Description     : Function to initialize the variables used in Platform
 *                    Interface module
 *  Input Values    : void
 *  Output Values   : void
 *  Return Value    : IFIN_FA_SUCCESS - On Success
 *                    IFIN_FA_FAIL - On Failure
 *  Notes           :
 ****************************************************************************/

PUBLIC char8
IFIN_FA_PLT_Init(void)
{
#ifdef VINETIC_INIT_REQD 
  int16 iFd;
  iFd = open("/dev/vin10", O_RDWR);
  if (iFd < 0)
  {
    IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, 
                         IFX_DBG_STR, "Cannot Open Vinetic Device");
    return IFIN_FA_FAIL;
  }
  if (!(ioctl(iFd, FIO_VINETIC_INIT, 0)))
  {
    IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, 
                        IFX_DBG_STR, "Cannot Initialise Vinetic Device");
  }
  IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FUNC_SUCCESS, 
                "Vinetic Device Initialisation");
#endif
  return IFIN_FA_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_Shut
 *  Description     : Function to free the memory used in Platform Interface
 *                    module
 *  Input Values    : void
 *  Output Values   : void
 *  Return Value    : IFIN_FA_SUCCESS - On Success
 *                    IFIN_FA_FAIL - On Failure
 *  Notes           :
 ****************************************************************************/
PUBLIC char8
IFIN_FA_PLT_Shut(void)
{
   /* To be filled later*/
  return IFIN_FA_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_AllocateChannel
 *  Description     : Function to allocate Coder channel resource
 *  Input Values    : Phone Channel number,
 *                    RTP and JB configuration values filled in structure
 *                    x_IFIN_DataChannelParams
 *  Output Values   : Retruns Data channel File descriptor
 *  Return Value    : IFIN_FA_SUCCESS - If channel is opened Succeesfully and
 *                    RTP, JB Cinfigurations are succesful
 *                    IFIN_FA_FAIL - If Channel open and other 
 *                    configuration fails
 *  Notes           : Device number calculation can be used for 4 VIP or 8 VIP
 *                    by changing IFIN_MAX_PHONE_CHANNELS per VINETIC
 ****************************************************************************/

PUBLIC char8
IFIN_FA_PLT_AllocateChannel(IN char8 *szDeviceName,
                            IN uchar8 ucCoder,
                  			    OUT int16 *pnFaxFd)
{
   //IFX_TAPI_MAP_DATA_t xDataMap;
    IFX_TAPI_KPI_CH_CFG_t xKpiChCfg;
    
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_CHANNEL, 
          "AllocateChannel", ucCoder, ucCoder);

   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_RM_DEV_NAME, szDeviceName);

   *pnFaxFd = open(szDeviceName, O_RDWR);

   if (*pnFaxFd < 0)
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_RM_DEV_ERR,
                "AllocateChannel", "Error Opening Device", szDeviceName);
      return(IFIN_FA_FAIL);
   }
   memset(&xKpiChCfg, 0, sizeof(IFX_TAPI_KPI_CH_CFG_t));

   xKpiChCfg.nStream = IFX_TAPI_KPI_STREAM_COD;
   xKpiChCfg.nKpiCh = IFX_TAPI_KPI_GROUP1 | (ucCoder - 1);

   if (ioctl(*pnFaxFd, IFX_TAPI_KPI_CH_CFG_SET, &xKpiChCfg) != IFX_SUCCESS)
   {
      close(*pnFaxFd);
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                             "AllocateChannel - Error Configuring KPI channel");
      return IFIN_FA_FAIL;
   }


  /* memset(&xDataMap, 0, sizeof(IFX_TAPI_MAP_DATA_t));
   xDataMap.nDstCh = ucCoder - 1;
   if (ioctl(*pnFaxFd, IFX_TAPI_MAP_DATA_ADD, &xDataMap) < 0)
   {
      close(*pnFaxFd);
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "AllocateChannel - Error Adding Data Channels");
      return IFIN_FA_FAIL;
   }*/
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, 
                        IFX_DBG_FUNC_SUCCESS, "Allocate Channel");
   return IFIN_FA_SUCCESS;
}



/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_DeallocateChannel
 *  Description     : Function to de-allocate Coder channel and memory
 *                    (if any) associated with channel
 *  Input Values    : Coder Channel File descriptor
 *  Output Values   : void 
 *  Return Value    : IFIN_FA_SUCCESS - channel is closed Succeesfully
 *                    IFIN_FA_FAIL - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC char8
IFIN_FA_PLT_DeallocateChannel(IN uchar8 ucChannelNum,
                              IN uchar8 ucCoder,
                              IN int16 nFaxFd) 
{
/*   IFX_TAPI_MAP_DATA_t xDataMap;
   
   memset(&xDataMap, 0, sizeof(IFX_TAPI_MAP_DATA_t));
   xDataMap.nDstCh = ucChannelNum - 1;
   if (ioctl(nFaxFd, IFX_TAPI_MAP_DATA_REMOVE, &xDataMap) < 0)
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, 
                           IFX_DBG_STR, "Error Removing Phone Channel");
   }*/
   close(nFaxFd);
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, 
                        IFX_DBG_FUNC_SUCCESS, "Data Channel Deallocation");
   return IFIN_FA_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_DeviceRead
 *  Description     : Function to read Fax packets from device
 *  Input Values    : nFaxFd - Coder Channel File descriptor
 *                    unBufLen - Number of bytes to be read
 *  Output Values   : *pcFaxBuf - data read from device
 *  Return Value    : Actual number of byets read from device
 *                    IFIN_FA_FAIL - If device read fails
 *  Notes           : Device read is non-blocking call, if there is no data to
 *                    be read, read returns 0
 ****************************************************************************/
PUBLIC int16
IFIN_FA_PLT_DeviceRead(IN int32 nFaxFd,
                       OUT char8 *pcFaxBuf,
                       IN uint16 unBufLen)
{
   int16 nLen; 
   nLen = read(nFaxFd, pcFaxBuf, unBufLen);
   return(nLen);
}

/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_DeviceWrite
 *  Description     : Function to write Fax packets to device
 *  Input Values    : nFaxFd - Coder Channel File descriptor
 *                    unBufLen - unBufLen - Number of bytes to be written
 *                    cVoiceBuf - Buffer containing data
 *  Output Values   : void
 *  Return Value    : Actual number of byets written to device
 *                    IFIN_FA_FAIL - If device write fails
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_PLT_DeviceWrite(IN int32 nFaxFd,
                        IN char8 *pcFaxBuf,
                        IN uint16 unBufLen)
{
   int16 nLen;

   nLen = write(nFaxFd, pcFaxBuf, unBufLen);
   if(nLen < 0)
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"WRITE_FAILURE");
      return(IFIN_FA_FAIL);
   }
   return(nLen);
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_StartModulator
 *  Description     : Function to Start Datapump Modulator
 *  Input Values    : nFaxFd - Fd of the channel hosting the Fax Call
 *                    ucDBM - Desired Output Signal Level
 *                    ucTEP - Flag to indicate TEP Setting
 *                    ucTRN - Flag to the training Sequence
 *                    ucSTD - Standard/Signal which has to be modulated
 *                    unSGLEN - Duration of signal in millisecs
 *                    ucDPNR - Datapump resource number
 *                    unGain1- Gain for upstream
 *                    unGain2- Gain for downstream
 *                    unMOBSM- Modulation Buffer,level for start modulation
 *                    unMOBRD- Modulation Buffer,Request for more data
 *                    unDMBSD- Demodulation Buffer,Send data level
 *                   
 *  Output Values   : None
 *  Return Value    : IFIN_FA_SUCCESS - if success 
 *                    IFIN_FA_FAIL - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_PLT_StartModulator(IN int16 nFaxFd,
                           IN uchar8 ucDBM,
                           IN uchar8 ucTEP, 
                           IN uchar8 ucTRN, 
                           IN uchar8 ucSTD,
                           IN uint16 unSGLEN, 
                           IN uchar8 ucDPNR, 
                           IN uint16 unGain1,
                           IN uint16 unGain2, 
                           IN uint16 unMOBSM, 
                           IN uint16 unMOBRD,
                           IN uint16 unDMBSD)
{
	IFX_TAPI_T38_MOD_DATA_t xTapiFaxModData;
	int16 nRetVal = 0;

	xTapiFaxModData.nStandard = ucSTD;
	xTapiFaxModData.nSigLen = unSGLEN;
	xTapiFaxModData.nGainTx = unGain2;
	xTapiFaxModData.nDbm = ucDBM;
	xTapiFaxModData.nTEP = ucTEP;
	xTapiFaxModData.nTraining = ucTRN;
	xTapiFaxModData.nMobsm = unMOBSM;
	xTapiFaxModData.nMobrd = unMOBRD;

	/* What about DPNR, and Mailbox Sizes */

   nRetVal = ioctl(nFaxFd, IFX_TAPI_T38_MOD_START, &xTapiFaxModData);

   if (nRetVal != 0)
   {
      return IFIN_FA_FAIL;
   }
   return IFIN_FA_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_StartDemodulator
 *  Description     : Function to Start Datapump Demodulator
 *  Input Values    : nFaxFd - Fd of the channel hosting the Fax Call
 *                    ucTRN - Flag to the training Sequence
 *                    ucEQ - Flag to Equaliser 
 *                    ucSTD2 - Alternative Standard/Signal
 *                    ucSTD1 - Desired Standard/Signal
 *                    ucDPNR - Datapump resource number
 *                    unGain1- Gain for upstream
 *                    unGain2- Gain for downstream
 *                    unMOBSM- Modulation Buffer,level for start modulation
 *                    unMOBRD- Modulation Buffer,Request for more data
 *                    unDMBSD- Demodulation Buffer,Send data level
 *                   
 *  Output Values   : None
 *  Return Value    : IFIN_FA_SUCCESS - if success 
 *                    IFIN_FA_FAIL - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_PLT_StartDemodulator(IN int16 nFaxFd,
                             IN uchar8 ucTRN, 
                             IN uchar8 ucEQ, 
                             IN uchar8 ucSTD2,
                             IN uchar8 ucSTD1,
                             IN uchar8 ucDPNR, 
                             IN uint16 unGain1,
                             IN uint16 unGain2, 
                             IN uint16 unMOBSM, 
                             IN uint16 unMOBRD,
                             IN uint16 unDMBSD)
{
   IFX_TAPI_T38_DEMOD_DATA_t xTapiFaxDemodData;
   int16 nRetVal = 0;

   xTapiFaxDemodData.nStandard1 = ucSTD1;
   xTapiFaxDemodData.nStandard2 = ucSTD2;
   xTapiFaxDemodData.nGainRx = unGain1;
   xTapiFaxDemodData.nEqualizer = ucEQ;
   xTapiFaxDemodData.nTraining = ucTRN;
   xTapiFaxDemodData.nDmbsd = unDMBSD;
	 //xTapiFaxDemodData.nSigLen = 50;
   /* What about DPNR, and Mailbox Sizes */

   nRetVal = ioctl(nFaxFd, IFX_TAPI_T38_DEMOD_START, &xTapiFaxDemodData);

   if (nRetVal != 0)
   {
      return IFIN_FA_FAIL;
   }
   return IFIN_FA_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_PLT_DisableDataPump
 *  Description     : Function to Disable Datapump
 *  Input Values    : nFaxFd - Fd of the channel hosting the Fax Call
 *                   
 *  Output Values   : None
 *  Return Value    : IFIN_FA_SUCCESS - if success 
 *                    IFIN_FA_FAIL - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_PLT_DisableDataPump(IN uchar8 ucChannelNum, 
                            IN int16 nFaxFd)
{
   int16 nRetVal = 0;
   nRetVal = ioctl(nFaxFd, IFX_TAPI_T38_STOP, NULL);

   if (nRetVal < 0)
   {
      return IFIN_FA_FAIL;
   }
   return IFIN_FA_SUCCESS;
}


/*****************************************************************************/
 /**  Function configures and starts T.38 session

   \param     *pxT38_InitParam - pointer to parameters structure
              *pxT38_ConnProfile - pointer to parameters structure
              *pxT38_ConnInfo - pointer to connection info structure
              nCh - data channel index
              *pucMlibId - pointer to MlibId

    \return      IFIN_FA_SUCCESS - if success
                      IFIN_FA_FAIL - If failure

    \remarks

*/
 /******************************************************************************/

#ifdef IFX_T38_FW
PUBLIC int16
IFX_FA_PLT_T38_StartSession(x_MT_T38_InitParam *pxT38_InitParam,
                              x_MT_T38_Caps *pxT38_ConnProfile,
                              x_IFX_FAXAPP_ConnectionInfo *pxT38_ConnInfo,
                             uchar8 nCh, void *pucMlibId)
{
  // IFX_TAPI_EVENT_t tapiEvent;
   uint16 err = 0;
   IFX_TAPI_T38_FDP_CFG_t xT38Cfg_Fdp;
   IFX_TAPI_T38_FAX_CFG_t xT38Cfg_Fax;
   IFX_TAPI_T38_SESS_CFG_t xT38Cfg_Sess;
#ifdef IFX_KPI_SUPPORT
   QOS_INIT_SESSION xQosSession;
   memset(&xQosSession, 0, sizeof(QOS_INIT_SESSION));
   xQosSession.srcPort  = htons(pxT38_ConnInfo->unLocalPort);
   xQosSession.destPort = htons(pxT38_ConnInfo->unRemotePort);
   xQosSession.srcAddr  = inet_addr(pxT38_ConnInfo->acLocalIpAddr);
   xQosSession.destAddr = inet_addr(pxT38_ConnInfo->acRemoteIpAddr);

   /*IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,"srcport ",xQosSession.srcPort);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,"destport ",xQosSession.destPort);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,"srcaddr ",xQosSession.srcAddr);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,"destaddr ",xQosSession.destAddr);*/

   if (ioctl(pxT38_ConnInfo->nFaxFd, FIO_QOS_START, &xQosSession) != IFX_SUCCESS)
   {
     IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, 
                        IFX_DBG_STR, "Cannot Initialise Vinetic Device");
      return IFIN_FA_FAIL;
   }
#endif
   memset(&xT38Cfg_Fdp, 0, sizeof(IFX_TAPI_T38_FDP_CFG_t));
   //xT38Cfg_Fdp.nMobsz = pxT38_InitParam->unMOBSZ;
   xT38Cfg_Fdp.nMobsz = 320;
   xT38Cfg_Fdp.nMobsm = pxT38_InitParam->unMOBSM;
   xT38Cfg_Fdp.nMobrd = pxT38_InitParam->unMOBRD;
   xT38Cfg_Fdp.nDmbsd = pxT38_InitParam->unDMBSD;
   if (ioctl(pxT38_ConnInfo->nFaxFd, IFX_TAPI_T38_FDP_CFG_SET,(int32) &xT38Cfg_Fdp) == IFX_ERROR)
   {
     IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, 
                        IFX_DBG_STR, "T38 Cfg Failed");
       return IFIN_FA_FAIL;
    
   }
   memset(&xT38Cfg_Fax, 0, sizeof(IFX_TAPI_T38_FAX_CFG_t));
   /* GainRx */
   if (pxT38_InitParam->unGain1 > IFX_FA_GAIN_MAX)
   {
      if (IFX_FA_PLT_VinGainTodB((uint16)pxT38_InitParam->unGain1,
                                       &xT38Cfg_Fax.nGainRx) != IFIN_FA_SUCCESS)
      {
         xT38Cfg_Fax.nGainRx = IFX_TAPI_T38_CFG_DEFAULT_GAIN;
         printf("FA: Wrong GainRx(%d) for channel=%d! Setting to default.\n",
                                                  pxT38_InitParam->unGain1, nCh);
      }
   }
   else
         xT38Cfg_Fax.nGainRx = pxT38_InitParam->unGain1;
   /* GainTx */
   if (pxT38_InitParam->unGain2 > IFX_FA_GAIN_MAX)
   {
      if (IFX_FA_PLT_VinGainTodB((uint16)pxT38_InitParam->unGain2,
                                       &xT38Cfg_Fax.nGainTx) != IFIN_FA_SUCCESS)
      {
         xT38Cfg_Fax.nGainTx = IFX_TAPI_T38_CFG_DEFAULT_GAIN;
         printf("FA: Wrong GainRx(%d) for channel=%d! Setting to default.\n",
                                                  pxT38_InitParam->unGain2, nCh);
      }
   }
   else
         xT38Cfg_Fax.nGainTx = pxT38_InitParam->unGain2;

   xT38Cfg_Fax.OptionMask = pxT38_InitParam->iOptions;
   xT38Cfg_Fax.nPktFec = pxT38_InitParam->uiUdpPriorPacketsForFEC;
   xT38Cfg_Fax.nDWT = pxT38_InitParam->uiDataWaitTime * 10;
   xT38Cfg_Fax.nModAutoStartTime = pxT38_InitParam->uiAutoStartWaitTime;
   xT38Cfg_Fax.nSpoofAutoInsTime = pxT38_InitParam->uiAutoSpoofingTime * 10;
   xT38Cfg_Fax.nDbm = pxT38_InitParam->uiDBmLevel;
   xT38Cfg_Fax.nPktRecovHiSpeed =
                               pxT38_InitParam->uiUdpHighRateErrRecoveryPackets;
   xT38Cfg_Fax.nPktRecovLoSpeed =
                                pxT38_InitParam->uiUdpLowRateErrRecoveryPackets;
   xT38Cfg_Fax.nPktRecovInd = pxT38_InitParam->uiUdpIndicatorDuplicationPackets;
   xT38Cfg_Fax.nNsxLen = pxT38_InitParam->uiNsxInfoFieldSz;
   memcpy(xT38Cfg_Fax.aNsx, pxT38_InitParam->pucNsxInfoField,
                            sizeof(uchar8) * pxT38_InitParam->uiNsxInfoFieldSz);
   xT38Cfg_Fax.nIFPSI = 20;
   usleep(10000);

   /*IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Gain Rx",xT38Cfg_Fax.nGainRx);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Gain Tx",xT38Cfg_Fax.nGainTx);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Options",xT38Cfg_Fax.OptionMask);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "FEC",xT38Cfg_Fax.nPktFec);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "DWT",xT38Cfg_Fax.nDWT);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Auto Start time ",xT38Cfg_Fax.nModAutoStartTime);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Auto Spoof time ",xT38Cfg_Fax.nSpoofAutoInsTime);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "DBM ",xT38Cfg_Fax.nDbm);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Hi Speed ",xT38Cfg_Fax.nPktRecovHiSpeed);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Low Speed ",xT38Cfg_Fax.nPktRecovLoSpeed);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Recover Ind ",xT38Cfg_Fax.nPktRecovInd);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "NSXlen ",xT38Cfg_Fax.nNsxLen);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "IFPSI ",xT38Cfg_Fax.nIFPSI);*/

   if (ioctl(pxT38_ConnInfo->nFaxFd, IFX_TAPI_T38_CFG_SET,(int32) &xT38Cfg_Fax) == IFX_ERROR)
   {
       return IFIN_FA_FAIL;
   }
   memset(&xT38Cfg_Sess, 0, sizeof(IFX_TAPI_T38_SESS_CFG_t));
   xT38Cfg_Sess.nRateManagement = pxT38_ConnProfile->ucRateManagement;
   xT38Cfg_Sess.nProtocol = pxT38_ConnProfile->uiTransportProtocol + 1;
   xT38Cfg_Sess.FacConvOpt = pxT38_ConnProfile->uiBitOptions;
   xT38Cfg_Sess.nBitRateMax = pxT38_ConnProfile->unMaxBitRate;
   xT38Cfg_Sess.nUDPErrCorr = pxT38_ConnProfile->ucUDPErrCorrection - 1;
	 if (pxT38_ConnProfile->unUDPMaxBufferSize){
   	xT38Cfg_Sess.nUDPBuffSizeMax = pxT38_ConnProfile->unUDPMaxBufferSize;
	 }else{
   	xT38Cfg_Sess.nUDPBuffSizeMax = 4096;
	 }
	 if(pxT38_ConnProfile->unUDPMaxDatagramSize){
   	xT38Cfg_Sess.nUDPDatagramSizeMax = pxT38_ConnProfile->unUDPMaxDatagramSize;
	 }else{
   	xT38Cfg_Sess.nUDPDatagramSizeMax = 512;
	 }
   xT38Cfg_Sess.nT38Ver = pxT38_ConnProfile->ucVersion;
   if (ioctl(pxT38_ConnInfo->nFaxFd, IFX_TAPI_T38_SESS_START,
                                            (int32) &xT38Cfg_Sess) == IFX_ERROR)
   {
        IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_CHANNEL, 
          "Session Start Error  ", nCh, err);
          return IFIN_FA_FAIL;
   }
   return IFIN_FA_SUCCESS;
}


/*****************************************************************************/
 /**  Function stops T.38 session

   \param     *pxT38_ConnInfo - pointer to connection info structure
              nCh - data channel index

    \return      IFIN_FA_SUCCESS - if success
                      IFIN_FA_FAIL - If failure

    \remarks

*/
 /******************************************************************************/

PUBLIC int16
IFX_FA_PLT_T38_StopSession(x_IFX_FAXAPP_ConnectionInfo *pxT38_ConnInfo,
                                                                uchar8 nCh)
{
   IFX_TAPI_T38_SESS_STOP_t xT38SessStop;

   memset(&xT38SessStop, 0, sizeof(IFX_TAPI_T38_SESS_STOP_t));

   if (ioctl(pxT38_ConnInfo->nFaxFd, IFX_TAPI_T38_SESS_STOP,
                                            (int32) &xT38SessStop) == IFX_ERROR)
      return IFIN_FA_FAIL;

#ifdef IFX_KPI_SUPPORT
   if (ioctl(pxT38_ConnInfo->nFaxFd, FIO_QOS_STOP,
                             htons(pxT38_ConnInfo->unLocalPort)) != IFX_SUCCESS)
      return IFIN_FA_FAIL;
#endif

   return IFIN_FA_SUCCESS;
}

/*****************************************************************************/
 /**  Function to convert Vinetic Gains to dB

   \param     unGain - vinetic gain
              *pnGain - pointer to gain in dB (OUT)

    \return      IFIN_FA_SUCCESS - if success
                      IFIN_FA_FAIL - If failure

    \remarks

*/
 /******************************************************************************/
STATIC int16 IFX_FA_PLT_VinGainTodB(uint16 unGain, int16 *pnGain)
{
   int16 i;
   uint16 unGainLess, unGainMost;

   if (unGain >= 256)
   {
      *pnGain = -24;
      return IFIN_FA_SUCCESS;
   }
   if (unGain <= 63)
   {
      *pnGain = 12;
      return IFIN_FA_SUCCESS;
   }

   unGainLess = unGain & 0x1F;
   unGainMost = (unGain >> 5) & 7;

   for (i = 0; i < IFX_FA_GAIN_TBL_ROW; i++)
   {
      if (dBToVinGainTbl[i] >= unGainLess)
         break;
   }
   if (i < IFX_FA_GAIN_TBL_ROW )
   {
      if (unGainLess <= ((dBToVinGainTbl[i] + dBToVinGainTbl[i - 1]) / 2))
         i--;
   }

   *pnGain = (IFX_FA_GAIN_MAX - ((unGainMost - 1) * (IFX_FA_GAIN_TBL_ROW - 1)))
                                                                            + i;

   return IFIN_FA_SUCCESS;
}
#endif
