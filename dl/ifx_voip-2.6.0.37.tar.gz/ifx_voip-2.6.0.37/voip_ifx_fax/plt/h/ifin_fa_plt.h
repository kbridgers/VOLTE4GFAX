/**************************************************************************
 **   FILE NAME       : ifin_fa_plt.h
 **   PROJECT         : FoIP 
 **   MODULES         : Fax Agent module
 **   SRC VERSION     : V0.1
 **   DATE            : 21-08-2003
 **   AUTHOR          : Hari 
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **   COPYRIGHT     	 : Copyright © 2004 Infineon Technologies AG
 **                     	St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER      : Any use of this Software is subject to the conclusion
 **                    	of a respective License Agreement.Without such a
 **                    	License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFIN_FA_PLT_H__
#define	__IFIN_FA_PLT_H__

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

typedef unsigned char       uchar8;
typedef char                char8;
typedef unsigned long int   uint64;

#define	IFIN_FA_FAILURE   -1
#define	IFIN_FA_SUCCESS    0

#define IN
#define OUT
#define IN_OUT

#define STATIC static
#define EXTERN extern
#define PUBLIC

#define IFIN_FA_DBG_LVL_1   1 
#define IFIN_FA_DBG_LVL_2   2 
#define IFIN_FA_DBG_LVL_3   3 
#define IFIN_FA_MAX_DBG_LVL IFIN_FA_DBG_LVL_3

#define IFIN_FA_MAX_PHONE_CHANNELS 4



#endif


