/**************************************************************************
 **   FILE NAME       : IFX_FAXAPP_App.c
 **   PROJECT         : FAX Application
 **   MODULES         : FAX Application  Module.
 **   SRC VERSION     : V0.1
 **   DATE            :26-04-2006.
 **   AUTHOR          :Voip Lib Team.
 **   DESCRIPTION     :FAX Application.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines.
 **
 **   COPYRIGHT       : Copyright © 2004
 **                     Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
/*Common Files*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <sys/times.h>
#include <sched.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "mt_t38_interface_import.h"
#include "mt_t38_caps.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "IFX_MLIB_Main.h"

/*Stack Files*/
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "ifx_faxapp_app.h"
#include "IFX_FAX_Agent.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#define printf(...)

/* EXTERN Functions */
EXTERN char8 IFIN_FA_PLT_AllocateChannel(IN char8 *szDeviceName,
                                         IN uchar8 ucCoder,
                                         OUT int16 *pnFaxFd);
EXTERN char8 IFIN_FA_PLT_DeallocateChannel(IN uchar8 ucChannelNum, 
                                           IN uchar8 ucCoder,
                                           IN int16 nFaxFd);
EXTERN int16 IFIN_FA_PLT_DeviceRead(IN int32 nFaxFd,
                                    OUT char8 *pcFaxBuf,
                                    IN uint16 unBufLen);
EXTERN int16 IFIN_FA_PLT_DeviceWrite(IN int32 nFaxFd,
                                    OUT char8 *pcFaxBuf,
                                    IN uint16 unBufLen);

EXTERN int32 IFIN_FA_PLT_StartModulator(int16 nFaxFd, 
   uchar8 ucDBM, uchar8 ucTEP, uchar8 ucTRN, uchar8 ucSTD,
   uint16 unSGLEN, uchar8 ucDPNR, uint16 unGain1,
   uint16 unGain2, uint16 unMOBSM, uint16 unMOBRD, uint16 unDMBSD);

EXTERN int32 IFIN_FA_PLT_StartDemodulator(int16 nFaxFd, 
   uchar8 ucTRN, uchar8 ucEQ, uchar8 ucSTD2, uchar8 ucSTD1,
   uchar8 ucDPNR, uint16 unGain1, uint16 unGain2, uint16 unMOBSM,
   uint16 unMOBRD, uint16 unDMBSD);

EXTERN int32 IFIN_FA_PLT_DisableDataPump(IN uchar8 ucChannelNum, 
                                         IN int16 nFaxFd);

EXTERN void IFX_MLIB_DbgInfo(IFX_MLIB_Id MlibId);
#ifdef IFX_T38_FW
EXTERN int16 IFX_FA_PLT_T38_StartSession(IN x_MT_T38_InitParam *pxT38_InitParam,
                                         IN x_MT_T38_Caps *pxT38_ConnProfile,
                                       IN x_IFX_FAXAPP_ConnectionInfo *pxT38_ConnInfo,
                                       uchar8 nCh, void *pucMlibId);

EXTERN int16 IFX_FA_PLT_T38_StopSession(x_IFX_FAXAPP_ConnectionInfo *pxT38_ConnInfo,
                                                               uchar8 nCh);
#endif
/* Global Variables */
STATIC int16 v_nFAXAPPFifoFd,v_nFAXAgentFifoFd;

/* Connection Info Table */
STATIC x_IFX_FAXAPP_ConnectionInfo vxConnectionTbl[IFX_FAXAPP_MAX_CONNECTIONS];

#ifndef IFX_T38_FW
/* No. of Active Connections */
STATIC uchar8 v_ucNoOfConnections = 0;
#endif
/* Read Fds for FA */
STATIC fd_set vxReadFds;
STATIC fd_set vxTmpReadFds;

/* Write Fds for FA */
STATIC fd_set vxWriteFds;
STATIC fd_set vxTmpWriteFds;

/* Memory Lib Id */
STATIC IFX_MLIB_Id vxMLibId;

/* Error Flag for Datapump */
STATIC char8 cDatapumpError[IFX_FAXAPP_MAX_CONNECTIONS] = {0};

/* Error Flag for Start Session */
//STATIC char8 cStartSessError[IFX_FAXAPP_MAX_CONNECTIONS] = {0};

/* Error Flag for End Fax Flag */
STATIC char8 cEndFaxCallFlag[IFX_FAXAPP_MAX_CONNECTIONS] = {0};
STATIC char8 cEndFaxMsgSent[IFX_FAXAPP_MAX_CONNECTIONS] = {0};

/* T.38 Fax Relay Parameters */
STATIC x_MT_T38_InitParam vxT38_InitParam;
uint8 vcFaxModId;

uchar8
IFX_FAXAPP_EndFaxCall(IN uchar8 ucChannelNum);
EXTERN char8** vppcArgv; //This is to set application title
/*
 ******************************************************************************
 * Function Name: IFIN_IAD_OutTraceString
 * Description  : Trace
 * Input Values : pcString - String to trace
 * Output Values:
 * Return Value :
 * Notes        :
 ******************************************************************************
*/
PUBLIC void 
IFIN_IAD_OutTraceString(IN char8 * pcString)
{
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, pcString);
   /*IFX_DBG_Log(vcFaxModId, IFX_DBG_LVL_HIGH, pcString);*/
   return;
}

/*
 ******************************************************************************
 * Function Name: IFIN_FA_SendPacket
 * Description  : Send packet to remote side
 * Input Values : unChannelID - The T.38 Fax Relay channel identifier
 *                pucOutBuffer - Pointer to output packet data
 *                               (TCP or UPD payload)
 *                uiOutBufferSize - Packet size in bytes
 * Output Values:
 * Return Value : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 * Notes        :
 ******************************************************************************
*/
PUBLIC int32 
IFIN_FA_SendPacket(IN uint16 unChannelID,
                   IN uchar8 * pucOutBuffer, 
                   IN uint32 uiOutBufferSize) 
{
   int16 nBytes = 0;
   struct sockaddr_in xRemoteAddr;
   socklen_t nSockAddrLen = sizeof(xRemoteAddr);

   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_SEND_PKT_TO_NET,
				                      unChannelID, uiOutBufferSize );
   if (vxConnectionTbl[unChannelID].nTcpSendSockFd)
   {
      /* TCP connection */
     nBytes = send(vxConnectionTbl[unChannelID].nTcpSendSockFd, 
			pucOutBuffer, uiOutBufferSize, 0); 
   }
   else if (vxConnectionTbl[unChannelID].nUdpSockFd)
   {
     bzero(&xRemoteAddr, sizeof(xRemoteAddr));
     xRemoteAddr.sin_family = AF_INET;
     inet_pton(AF_INET, vxConnectionTbl[unChannelID].acRemoteIpAddr,  
                           &xRemoteAddr.sin_addr);
     xRemoteAddr.sin_port = htons(vxConnectionTbl[unChannelID].unRemotePort);
     nBytes = sendto(vxConnectionTbl[unChannelID].nUdpSockFd,
           pucOutBuffer, uiOutBufferSize, 0,
           (struct sockaddr *) &xRemoteAddr, nSockAddrLen);
   }
   if (nBytes < 0)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_SOCK_SEND_ERR,
                               vxConnectionTbl[unChannelID].nUdpSockFd);
     return IFX_FAILURE;
   }
   if (IFX_MLIB_FreeMem(vxMLibId, pucOutBuffer) != IFX_MLIB_SUCCESS)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Mem Free Error");
   }
   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 *  Function Name   : IFIN_FA_EndFaxCall
 *  Description     : Ends a Fax Call
 *                    
 *  Input Values    : Channel Number
 *  Output Values   : None 
 *  Return Value    : IFIN_FA_SUCCESS 
 *  Notes           :
 ******************************************************************************
 */
uchar8
IFIN_FA_EndFaxCall(IN uchar8 ucChannelNum)
{
   return IFX_FAXAPP_EndFaxCall(ucChannelNum);
}


/*
 ******************************************************************************
 * Function Name: IFIN_FA_EndOfFAXData
 * Description  : Report normal termination of fax session
 * Input Values : unChannelID - The T.38 Fax Relay channel identifier
 * Output Values:
 * Return Value : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 * Notes        :
 ****************************************************************************** 
*/
PUBLIC int32 
IFIN_FA_EndOfFAXData(IN uint16 unChannelID) 
{
#ifdef IFIN_FA_T38_STAT_REQD
   x_MT_T38_statistics_t T38Stat;
#endif


   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_END_OF_FAX, unChannelID);

   if (cEndFaxCallFlag[unChannelID] == 2)
   {
      /* End T.38 Session Mesg had already come
       * Cleanup everything.  No need to send EndFaxCall to UA
       */
      
#ifdef IFIN_FA_T38_STAT_REQD
      if (MT_T38_GetT38Statistics(unChannelID,&T38Stat) !=IFX_SUCCESS)
      {
         IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_FUNC_START,
            "Error Getting T38 Statistics", unChannelID);
      }
      else
      {
         printf("T38 Connection Statistics");
         printf("###################");
         if(T38Stat.i_Standards==0x0001)
         {
           printf("Standard used : V27TER_2400");
         }
         if(T38Stat.i_Standards==0x0002)
         {
           printf("Standard used : V27TER_4800");
         }
         if(T38Stat.i_Standards==0x0004)
         {
           printf("Standard used : V29_7200");
         }
         if(T38Stat.i_Standards==0x0008)
         {
           printf("Standard used : V29_9600");
         }
         if(T38Stat.i_Standards==0x0010)
         {
           printf("Standard used : V17_7200");
         }
         if(T38Stat.i_Standards==0x0020)
         {
           printf("Standard used : V17_9600");
         }
         if(T38Stat.i_Standards==0x0040)
         {
           printf("Standard used : V17_12000");
         }
         if(T38Stat.i_Standards==0x0080)
         {
           printf("Standard used : V17_14400");
         }
         
         printf("Flags : %d",T38Stat.i_Flags);
         printf("Lost Packets : %d",T38Stat.ui_LostPackets);
         printf("Recovered Packets : %d",T38Stat.ui_RecoveredPackets);
         printf("Max Lost Consecutive Packets : %d",
                              T38Stat.ui_MaxLostPcksGroup);
         printf("Number of TCF Respond with FTT : %d",
                              T38Stat.ui_StatFTTcount);
         printf("Transfered pages quantity : %d",
                              T38Stat.ui_PagesTransfered);
         printf("Number of broken Non-ECM page lines : %d",
                              T38Stat.ui_LineBreaks);
         printf("Number of broken Modulation of v21 frames : %d",
                              T38Stat.ui_v21FrmBreaks);
         printf("Number of broken ECM Frames Modulation : %d",
                              T38Stat.ui_ECM_FrmBreaks);
         printf("T38 Ver : %d.%d",T38Stat.ui_MajorVersion,
                                          T38Stat.ui_MinirVersion);
   }
#endif

#ifdef IFX_T38_FW   
     if (IFX_FA_PLT_T38_StopSession(&vxConnectionTbl[unChannelID],unChannelID) !=IFX_SUCCESS)
#else
      if (MT_T38_SessionStop(unChannelID) != IFX_SUCCESS)
#endif
      {
         IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_SESS_STOP_ERR,
                                                  unChannelID);
      }
      else
      {
         IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_SUCCCESS,
            "T38 SessionStop", unChannelID);
      }
      cDatapumpError[unChannelID] = 0;
      if (!(vxConnectionTbl[unChannelID].nUdpSockFd))
      {
         /* TCP Connection is in progress */
         FD_CLR(vxConnectionTbl[unChannelID].nTcpServerSockFd, &vxReadFds);
      }
   cEndFaxCallFlag[unChannelID] = 0;
   }
   else
   {
      cEndFaxCallFlag[unChannelID] = 1;

      /* Send IFIN_FA_END_FAX_CALL_REQ to UA */
      IFIN_FA_EndFaxCall(unChannelID);
   }
   return IFX_SUCCESS;
}


/*
 ******************************************************************************
 * Function Name: IFIN_FA_SendDataToDataPump
 * Description  : Send Data to DSP
 * Input Values : unChannelID - The T.38 Fax Relay channel identifier 
 *                pucMsgToDataPump - Pointer to the data to be sent to DSP
 *                uiMsgSize - data size in bytes
 * Output Values: None
 * Return Value : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 * Notes        :
 ******************************************************************************
*/

PUBLIC int32
IFIN_FA_SendDataToDataPump(IN uint16 unChannelID,
                           IN uchar8 * pucMsgToDataPump,
                           IN uint32 uiMsgSize
                          )
{
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_SEND_DATA_TO_DP,
                                        unChannelID, uiMsgSize);
   /* Get Device Fd for Channel */
   /* Call Device Write to Write to the Data Pump */
   if (IFIN_FA_PLT_DeviceWrite(vxConnectionTbl[unChannelID].nFaxFd,
                                   (char8 *) pucMsgToDataPump,
                                   (uint16) uiMsgSize) < 0)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_FUNC_FAIL,
        "Write Failure", vxConnectionTbl[unChannelID].nFaxFd, unChannelID);
      return IFX_FAILURE;
   }
        
   /* Free memory here */
   if (IFX_MLIB_FreeMem(vxMLibId, pucMsgToDataPump) != IFX_MLIB_SUCCESS)
   {
     IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Memory Free error");
   }
   return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFIN_FA_SetModDemodParam
 *  Description     : Function to Set Modulator/Demodulator Parameters
 *  Input Values    : unChannelID - Channel Number hosting Fax Call
 *                    ucDPNR - Datapump resource number
 *                    unGain1- Gain for upstream
 *                    unGain2- Gain for downstream
 *                    unMOBSM- Modulation Buffer,level for start modulation
 *                    unMOBRD- Modulation Buffer,Request for more data
 *                    unDMBSD- Demodulation Buffer,Send data level
 *                   
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - if success 
 *                    IFX_FAILURE - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_SetModDemodParams(IN uint16 unChannelID, 
                          IN uchar8 ucDPNR,
                          IN uint16 unGain1,
                          IN uint16 unGain2,
                          IN uint16 unMOBSM,
                          IN uint16 unMOBRD,
                          IN uint16 unDMBSD)
{
   vxConnectionTbl[unChannelID].ucDPNR = ucDPNR;
   vxConnectionTbl[unChannelID].unGain1 = unGain1;
   vxConnectionTbl[unChannelID].unGain2 = unGain2; 
   vxConnectionTbl[unChannelID].unMOBSM = unMOBSM;
   vxConnectionTbl[unChannelID].unMOBRD = unMOBRD;
   vxConnectionTbl[unChannelID].unDMBSD = unDMBSD;

   return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFIN_FA_StartModulator
 *  Description     : Function to Start Datapump Modulator
 *  Input Values    : unChannelID - Channel Number hosting Fax Call
 *                    ucDBM - Desired Output Signal Level
 *                    ucTEP - Flag to indicate TEP Setting
 *                    ucTRN - Flag to the training Sequence
 *                    ucSTD - Standard/Signal which has to be modulated
 *                    unSGLEN - Duration of signal in millisecs
 *                   
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - if success 
 *                    IFX_FAILURE - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_StartModulator(IN uint16 unChannelID, 
                       IN uchar8 ucDBM,
                       IN uchar8 ucTEP, 
                       IN uchar8 ucTRN, 
                       IN uchar8 ucSTD,
                       IN uint16 unSGLEN)
{
   int16 nRetVal = 0;
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
                                     "Start Modulator", unChannelID);
   nRetVal = IFIN_FA_PLT_StartModulator(
                  vxConnectionTbl[unChannelID].nFaxFd,
                  ucDBM, ucTEP, ucTRN, ucSTD, unSGLEN,
                  vxConnectionTbl[unChannelID].ucDPNR,
                  vxConnectionTbl[unChannelID].unGain1,
                  vxConnectionTbl[unChannelID].unGain2,
                  vxConnectionTbl[unChannelID].unMOBSM,
                  vxConnectionTbl[unChannelID].unMOBRD,
                  vxConnectionTbl[unChannelID].unDMBSD);
   if (nRetVal == IFX_FAILURE)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, 
                           IFX_DBG_FUNC_ERROR, "StartModulator");
      return nRetVal;
   }
   return IFX_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_StartDemodulator
 *  Description     : Function to Start Datapump Demodulator
 *  Input Values    : unChannelID - Channel Number hosting Fax Call
 *                    ucTRN - Flag to the training Sequence
 *                    ucEQ - Flag to Equaliser 
 *                    ucSTD2 - Alternative Standard/Signal
 *                    ucSTD1 - Desired Standard/Signal
 *                   
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - if success 
 *                    IFX_FAILURE - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_StartDemodulator(IN uint16 unChannelID, 
                         IN uchar8 ucTRN, 
                         IN uchar8 ucEQ, 
                         IN uchar8 ucSTD2,
                         IN uchar8 ucSTD1)
{
   int16 nRetVal = 0;
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
                                     "Start Demodulator", unChannelID);
   nRetVal = IFIN_FA_PLT_StartDemodulator(
                       vxConnectionTbl[unChannelID].nFaxFd,
                       ucTRN, ucEQ, ucSTD2, ucSTD1,
                       vxConnectionTbl[unChannelID].ucDPNR,
                       vxConnectionTbl[unChannelID].unGain1,
                       vxConnectionTbl[unChannelID].unGain2,
                       vxConnectionTbl[unChannelID].unMOBSM,
                       vxConnectionTbl[unChannelID].unMOBRD,
                       vxConnectionTbl[unChannelID].unDMBSD);
   if (nRetVal == IFX_FAILURE)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR,
                           IFX_DBG_FUNC_ERROR, "StartDemodulator");
      return nRetVal;
   }
   return IFX_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : IFIN_FA_DisableDataPump
 *  Description     : Function to Disable Datapump
 *  Input Values    : unChannelID - Channel Number hosting Fax Call
 *                   
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - if success 
 *                    IFX_FAILURE - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC int16
IFIN_FA_DisableDataPump(IN uint16 unChannelID)
{
   int16 nRetVal = 0;
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
                                   "Disable Datapump", unChannelID);
   nRetVal = IFIN_FA_PLT_DisableDataPump(unChannelID + 1,
        vxConnectionTbl[unChannelID].nFaxFd);
   if (nRetVal == IFX_FAILURE)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, 
                       IFX_DBG_FUNC_ERROR, "DisableDatapump");
      return nRetVal;
   }
   return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_FAXAPP_EventNotifier
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int8 IFX_FAXAPP_EventNotifier(uint32 uiCallId, e_IFX_ReasonCode eReasonCode)
{
  x_IFX_FAX_AGENT_App2Agent xAppInfo ={0};
  xAppInfo.uiCallId = uiCallId;
  xAppInfo.eErrCode = eReasonCode;

   return IFX_FAXAPP_SendMsgToFifo(v_nFAXAgentFifoFd,(char*)&xAppInfo,
	                                sizeof(x_IFX_FAX_AGENT_App2Agent));

}
/*****************************************************************************
 *  Function Name   : IFIN_FA_TimerCallback
 *  Description     : Function to handle Timeout
 *  Input Values    : unChannelID - Channel Number hosting Fax Call
 *                   
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - if success 
 *                    IFX_FAILURE - If failure
 *  Notes           :
 ****************************************************************************/
PUBLIC void
IFIN_FA_TimerCallback(IN void *pvInfo)
{
	
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Time Out");
	 /*IFX_FAXAPP_CloseT38Session((uint32) pvInfo);
	 IFX_FAXAPP_EventNotifier(
			vxConnectionTbl[(uint32) pvInfo].uiCallId,IFX_FAX_TIMEOUT);*/
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_SignalHandler
 *  Description     : Handles the SIG_KILL signal
 *
 *  Input Values    : None
 *  Output Values   : None
 *  Return Value    : None
 *  Notes           :
 ******************************************************************************
*/

STATIC void
IFX_FAXAPP_SignalHandler(IN int32 unSigParam)
{
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                                     "Shutting Down Fax Agent");
   exit(0);
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_CreateT38_Socket
 *  Description     : 
 *
 *  Input Values    : Protocol, Local & Remote Ports, Remote Address
 *                  : Socket Type
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/

STATIC int16
IFX_FAXAPP_CreateT38_Socket(IN uchar8 ucProtocol,
                         IN uint16 unLocalPort,
                         IN uint16 unRemotePort,
                         IN char8 * pacRemoteIpAddress,
                         IN char8 * pacLocalIpAddress,
                         IN uchar8 ucTcpSocketType)
{
   int16 nSockFd = -1, nResult = 0;
	
   int32 iOn = 1; 

   struct sockaddr_in xLocalAddr, xRemoteAddr;

   /* Create the Socket */
   if (ucProtocol == IFX_TRPROTO_TCP)
   {
     nSockFd = socket(AF_INET, SOCK_STREAM, 0);
   }
   else if (ucProtocol == IFX_TRPROTO_UDP)
   {
     nSockFd = socket(AF_INET, SOCK_DGRAM, 0);
   }
   else
   {
     IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR, "Profile");
     return IFX_FAILURE;
   }
   if (nSockFd < 0) 
   {
     IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							"Socket creation Failed");
     return nSockFd;
   }

   /* Set the non-blocking flag for the socket */
	
	/*
   iFlags = fcntl(nSockFd, F_GETFL, 0);
   iFlags = iFlags | O_NONBLOCK ;
   fcntl(nSockFd, F_SETFL, iFlags);
   */
   if (ucProtocol == IFX_TRPROTO_TCP)
   {
      setsockopt(nSockFd, SOL_SOCKET, SO_REUSEADDR, &iOn, sizeof(iOn));
   }

   bzero(&xLocalAddr, sizeof(xLocalAddr));
   xLocalAddr.sin_family = AF_INET;
	 inet_pton(AF_INET, pacLocalIpAddress,  &xLocalAddr.sin_addr);
   xLocalAddr.sin_port = htons(unLocalPort);

   /* IFX_FAXAPP_AddrCmp(&xLocalAddr); */

   /* Bind the Socket to the local port */
   nResult = bind(nSockFd, (struct sockaddr *) &xLocalAddr, sizeof(xLocalAddr));
   if (nResult < 0)
   {
	  perror("Bind Error:");
     IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                                    "Socket Bind Failure");
    close(nSockFd); 
		return IFX_FAILURE;
   }

   /* If the protocol is TCP, we need to know the type of socket.
    * Whether its a server socket or a client socket
    */
   if (ucProtocol == IFX_TRPROTO_TCP)
   {
     if (ucTcpSocketType == IFX_FAXAPP_TCP_SOCKTYPE_CLIENT)
     {
       IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_REMOTE_ADDR,
                              pacRemoteIpAddress, unRemotePort);
       bzero(&xRemoteAddr, sizeof(xRemoteAddr)); 
       xRemoteAddr.sin_family = AF_INET;
       inet_pton(AF_INET, pacRemoteIpAddress,  &xRemoteAddr.sin_addr);
       xRemoteAddr.sin_port = htons(unRemotePort);
      
       /* Introduce a sleep so that a connect doesnt go before
        * a SetupT38 Session request.  If a connect goes before a 
        * SetupT38 Session request, it is impossible to map the accept
        * to a channel 
        */
       nResult = connect(nSockFd, (struct sockaddr *) &xRemoteAddr, 
			                                 sizeof(xRemoteAddr));

       if (nResult < 0)
       {  
         IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Connect to Remote Socket Failure");
         close(nSockFd);
					return IFX_FAILURE;
       }
     }
     else if (ucTcpSocketType == IFX_FAXAPP_TCP_SOCKTYPE_SERVER)
     {
       listen(nSockFd, 5);
     }
   }
   return nSockFd;
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_CloseT38Session
 *  Description     : Closes the T.38 Session
 *
 *  Input Values    : Channel Number
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/

STATIC char8 
IFX_FAXAPP_CloseT38Session(IN uchar8 ucChannelNum)
{
#ifdef IFX_FAXAPP_T38_STAT_REQD
   x_MT_T38_statistics_t T38Stat;
#endif


#ifdef IFX_FAXAPP_T38_STAT_REQD
   if (MT_T38_GetT38Statistics(ucChannelNum,&T38Stat) !=IFX_SUCCESS)
   {
         IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_FUNC_START,
           "Error Getting T38 Statistics", ucChannelNum);
   }
   else
   {
      printf("T38 Connection Statistics");
      printf("###################");
      if(T38Stat.i_Standards==0x0001)
      {
        printf("Standard used : V27TER_2400");
      }
      if(T38Stat.i_Standards==0x0002)
      {
        printf("Standard used : V27TER_4800");
      }
      if(T38Stat.i_Standards==0x0004)
      {
        printf("Standard used : V29_7200");
      }
      if(T38Stat.i_Standards==0x0008)
      {
        printf("Standard used : V29_9600");
      }
      if(T38Stat.i_Standards==0x0010)
      {
        printf("Standard used : V17_7200");
      }
      if(T38Stat.i_Standards==0x0020)
      {
        printf("Standard used : V17_9600");
      }
      if(T38Stat.i_Standards==0x0040)
      {
        printf("Standard used : V17_12000");
      }
      if(T38Stat.i_Standards==0x0080)
      {
        printf("Standard used : V17_14400");
      }

      printf("Flags : %d",T38Stat.i_Flags);
      printf("Lost Packets : %d",T38Stat.ui_LostPackets);
      printf("Recovered Packets : %d",T38Stat.ui_RecoveredPackets);
      printf("Max Lost Consecutive Packets : %d",
                           T38Stat.ui_MaxLostPcksGroup);
      printf("Number of TCF Respond with FTT : %d",
                           T38Stat.ui_StatFTTcount);
      printf("Transfered pages quantity : %d",
                           T38Stat.ui_PagesTransfered);
      printf("Number of broken Non-ECM page lines : %d",
                           T38Stat.ui_LineBreaks);
      printf("Number of broken Modulation of v21 frames : %d",
                           T38Stat.ui_v21FrmBreaks);
      printf("Number of broken ECM Frames Modulation : %d",
                           T38Stat.ui_ECM_FrmBreaks);
      printf("T38 Ver : %d.%d",T38Stat.ui_MajorVersion,
                                       T38Stat.ui_MinirVersion);

   }
#endif
#ifdef IFX_T38_FW   
    if (IFX_FA_PLT_T38_StopSession(&vxConnectionTbl[ucChannelNum],ucChannelNum) !=IFX_SUCCESS)
#else
   if (MT_T38_SessionStop(ucChannelNum) != IFX_SUCCESS)
#endif
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, 
                           IFX_DBG_FA_SESS_STOP_ERR, ucChannelNum);
   }
   IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_SUCCCESS,
	                        "SessionStop",  ucChannelNum);
   cDatapumpError[ucChannelNum] = 0;
   if (!(vxConnectionTbl[ucChannelNum].nUdpSockFd))
   {
      /* TCP Connection is in progress */
      FD_CLR(vxConnectionTbl[ucChannelNum].nTcpServerSockFd, &vxReadFds);
   }
   if (vxT38_InitParam.iOptions & MT_T38_INIT_OPT_CALLING)
   {
      /* Clear the Calling Flag */
      vxT38_InitParam.iOptions &= ~MT_T38_INIT_OPT_CALLING;
   }

   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 * Function Name: IFX_FAXAPP_Shut
 * Description  : Shutdown the Fax Agent Module
 * Input Values : None
 * Output Values:
 * Return Value : None
 * Notes        :
 ****************************************************************************** 
*/
PUBLIC char8
IFX_FAXAPP_Shut(void)
{
   int16 nIdx;
   /* Clean up all the memory and
    * Close Rx Fifo, Tx Fifo
    * Close all open socket descriptors
    * Send SIGNAL to itself 
    */
   close(v_nFAXAPPFifoFd);
   close(v_nFAXAgentFifoFd);
   unlink(IFX_IPC_FAX_AGENT_FIFO);
   unlink(IFX_IPC_FAX_APP_FIFO);
   for (nIdx = 0; nIdx < IFX_FAXAPP_MAX_CONNECTIONS; nIdx++)
   {
     if (vxConnectionTbl[nIdx].nTcpSendSockFd)
     {
       close(vxConnectionTbl[nIdx].nTcpSendSockFd);
     }
     if (vxConnectionTbl[nIdx].nTcpRecvSockFd)
     {
       close(vxConnectionTbl[nIdx].nTcpRecvSockFd);
     }
     if (vxConnectionTbl[nIdx].nUdpSockFd)
     {
       close(vxConnectionTbl[nIdx].nUdpSockFd);
     }
     if (vxConnectionTbl[nIdx].nFaxFd)
     {
#ifdef IFX_T38_FW   
       IFX_FA_PLT_T38_StopSession(&vxConnectionTbl[nIdx],nIdx);
#else
       MT_T38_SessionStop(nIdx);
#endif
       close(vxConnectionTbl[nIdx].nFaxFd);
     }
   }
   /* Shut down the Memory library */
   sleep(1);
   /* Wait for the signal to be handled */
   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_SetT38InitParam
 *  Description     : Initialises default parameters for the T.38 Stack
 *
 *  Input Values    : None 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/
STATIC char8
IFX_FAXAPP_SetT38InitParam(x_IFX_VMAPI_T38Cfg  *pxFA_T38Cfg)
{
   /* Now get the configured values for the T38 stack */
   uchar8 ucCount = 0;
   uint16 uiTemp1, uiTemp2, uiTemp3;
   static char nsx [] = {0xc5,0x00};
   /* The PRofile ID is not relevant for some parameters
    * and should be moved into System Settings at a later point of time */
   memset(&vxT38_InitParam, 0, sizeof(x_MT_T38_InitParam)); 
//#ifdef IFX_T38_FW
   vxT38_InitParam.iOptions = 14; /* Derived from TAPI flags mentioned below*/
		/*IFX_TAPI_T38_FEAT_NON | IFX_TAPI_T38_FEAT_ASN1 |IFX_TAPI_T38_FEAT_LONG*/
   vxT38_InitParam.uiDBmLevel = 13;
   vxT38_InitParam.unGain1 = 96;
   vxT38_InitParam.unGain2 = 96;
   vxT38_InitParam.ucDPNR = 0;
   vxT38_InitParam.ucInputSignal = 50;
   vxT38_InitParam.unMOBSM = 320;
   vxT38_InitParam.unMOBRD = 233;
   vxT38_InitParam.unDMBSD = 32;
   vxT38_InitParam.uiAutoStartWaitTime = 2000;
   vxT38_InitParam.uiAutoSpoofingTime = 41;
 	 vxT38_InitParam.uiUdpPriorPacketsForFEC = 0;
   vxT38_InitParam.uiDataWaitTime = 5;
   vxT38_InitParam. uiUdpHighRateErrRecoveryPackets= 1;
   vxT38_InitParam. uiUdpLowRateErrRecoveryPackets= 4;
   vxT38_InitParam.uiUdpIndicatorDuplicationPackets = 4 ;
   vxT38_InitParam.uiNsxInfoFieldSz = sizeof(nsx);;
   vxT38_InitParam.pucNsxInfoField = (uchar8*) nsx;
   //vxT38_InitParam.uiIFPSI = 20;
//#else
#if 0
   vxT38_InitParam.iOptions = 14;
   vxT38_InitParam.uiDBmLevel = 10;
   /* Pending - NSX Info has to be set properly */
   vxT38_InitParam.unGain1 = 96;
   vxT38_InitParam.unGain2 = 96;
   vxT38_InitParam.ucDPNR = 0;
   vxT38_InitParam.ucInputSignal = 50;
   vxT38_InitParam.unMOBSM = 320;
   vxT38_InitParam.unMOBRD = 233;
   vxT38_InitParam.unDMBSD = 32;
   vxT38_InitParam.uiAutoStartWaitTime = 2000;
   vxT38_InitParam.uiAutoSpoofingTime = 410;
#endif
   if (pxFA_T38Cfg->ucOldAsn1)
   {
     IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "ASN Configured");
     vxT38_InitParam.iOptions |= MT_T38_INIT_OPT_USE_OLD_ASN98;
   }
   if (pxFA_T38Cfg->ucNsxSize)
   {
     IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "NSX Configured");
     vxT38_InitParam.iOptions |= MT_T38_INIT_OPT_NSXPATCH;
     vxT38_InitParam.uiNsxInfoFieldSz = pxFA_T38Cfg->ucNsxSize;
     /* Write Logic to put in the NSX Patch Info */
     if((vxT38_InitParam.pucNsxInfoField = 
         malloc(vxT38_InitParam.uiNsxInfoFieldSz)) == NULL){
     	IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Malloc Failed....!!");
   		return IFX_FAILURE;
			}
     memcpy(vxT38_InitParam.pucNsxInfoField, "00", 
                 vxT38_InitParam.uiNsxInfoFieldSz);
     for (ucCount = 0;
          ucCount< ((vxT38_InitParam.uiNsxInfoFieldSz * 2) - 1);
          ucCount = ucCount + 2)
     {
        if (isalpha(pxFA_T38Cfg->ucNsxInfoField[ucCount]))
        {		  
           uiTemp1 = 
            (tolower(pxFA_T38Cfg->ucNsxInfoField[ucCount]-'a'+
                     IFX_FAXAPP_DEC_VALUE) *IFX_FAXAPP_MAX_BYTE_VALUE);
        }
        else
        {
           uiTemp1 = (pxFA_T38Cfg->ucNsxInfoField[ucCount]-'0') 
                      * IFX_FAXAPP_MAX_BYTE_VALUE;
        }
        if (isalpha(pxFA_T38Cfg->ucNsxInfoField[ucCount+1]))
        {		  
          uiTemp2 =
          (tolower(pxFA_T38Cfg->ucNsxInfoField[ucCount+1]-'a'+
                   IFX_FAXAPP_DEC_VALUE));
        }
        else
        {
           uiTemp2 =(pxFA_T38Cfg->ucNsxInfoField[ucCount+1]-'0');
        }
        uiTemp3 =uiTemp1 + uiTemp2;
        *vxT38_InitParam.pucNsxInfoField = uiTemp3;
        vxT38_InitParam.pucNsxInfoField++;
     }
   }
   vxT38_InitParam.uiDataWaitTime = pxFA_T38Cfg->ucDataWaitTime;
   vxT38_InitParam.uiUdpHighRateErrRecoveryPackets = 
                      pxFA_T38Cfg->unUdpHRErrRecPkts;
   vxT38_InitParam.uiUdpLowRateErrRecoveryPackets = 
                      pxFA_T38Cfg->unUdpLRErrRecPkts;
   vxT38_InitParam.uiUdpPriorPacketsForFEC = 
                      pxFA_T38Cfg->unUdpPriorFecPkts;
   vxT38_InitParam.ucDataFrameLength = 
                      pxFA_T38Cfg->unFrameLength = 0 /*20*/;

   return IFX_SUCCESS;
}

/* ******************************************************************************
 *  Function Name   : IFX_FAXAPP_GetCoderChannel
 *  Description     : Return Coder Channel number
 *
 *  Input Values    : Fax Agent Message
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/
int32 IFX_FAXAPP_GetCoderChannel(char8 *pcCoderDeviceName)
{
	char8 cTemp,cTemp1;
	int32 iCoderNum=0,iLen=strlen(pcCoderDeviceName)-1;
	cTemp=pcCoderDeviceName[iLen-1];
	cTemp1=pcCoderDeviceName[iLen];
	switch(cTemp){
		case '2':
			iCoderNum=2;
		case '1':
			if(cTemp1 == '1'){
				return iCoderNum;
			}else{
				return iCoderNum+1;
			}
			break;
	}
	return -1;
}				
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_CleanupConnection
 *  Description     : Cleans up the Connection Info on a Channel
 *
 *  Input Values    : Channel number
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, IFX_FAILURE
 *  Notes           :
 ******************************************************************************
*/
STATIC uchar8
IFX_FAXAPP_CleanupConnection(IN uchar8 ucChannelNum)
{
   FD_CLR(vxConnectionTbl[ucChannelNum].nTcpServerSockFd, &vxReadFds); 
   if (vxConnectionTbl[ucChannelNum].nTcpSendSockFd)
   {
      FD_CLR(vxConnectionTbl[ucChannelNum].nTcpSendSockFd, &vxReadFds); 
      close(vxConnectionTbl[ucChannelNum].nTcpSendSockFd);
      vxConnectionTbl[ucChannelNum].nTcpSendSockFd = 0;
   }  
   if (vxConnectionTbl[ucChannelNum].nTcpRecvSockFd)
   {
     FD_CLR(vxConnectionTbl[ucChannelNum].nTcpRecvSockFd, &vxReadFds); 
     close(vxConnectionTbl[ucChannelNum].nTcpRecvSockFd);
     vxConnectionTbl[ucChannelNum].nTcpRecvSockFd = 0;
   }
   if (vxConnectionTbl[ucChannelNum].nUdpSockFd)
   {
     FD_CLR(vxConnectionTbl[ucChannelNum].nUdpSockFd, &vxReadFds); 
     close(vxConnectionTbl[ucChannelNum].nUdpSockFd);
     vxConnectionTbl[ucChannelNum].nUdpSockFd = 0;
   }
   if (vxConnectionTbl[ucChannelNum].nFaxFd)
   {
     FD_CLR(vxConnectionTbl[ucChannelNum].nFaxFd, &vxReadFds);
     FD_CLR(vxConnectionTbl[ucChannelNum].nFaxFd, &vxWriteFds);
     close(vxConnectionTbl[ucChannelNum].nFaxFd);
     vxConnectionTbl[ucChannelNum].nFaxFd = 0;
   }
   vxConnectionTbl[ucChannelNum].ucCallStatus = IFX_FAXAPP_NO_CALL;
   vxConnectionTbl[ucChannelNum].ucTcpTOC = 0;
   vxConnectionTbl[ucChannelNum].unLocalPort = 0;
   vxConnectionTbl[ucChannelNum].unRemotePort = 0;
   vxConnectionTbl[ucChannelNum].ucCoder = 0;
   vxConnectionTbl[ucChannelNum].uiCallId = 0;
   if(cEndFaxCallFlag[ucChannelNum] != 2)
   	cEndFaxCallFlag[ucChannelNum] = 0;
   cEndFaxMsgSent[ucChannelNum] = 0;
   cDatapumpError[ucChannelNum] = 0;
   strcpy(vxConnectionTbl[ucChannelNum].acRemoteIpAddr, " ");
   return (IFX_SUCCESS);
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_ProcessStartT38SessMsg
 *  Description     : Processes the Start T38 Session request from UA
 *
 *  Input Values    : Fax Agent Message
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/
STATIC char8 
IFX_FAXAPP_ProcessStartT38SessMsg(IN x_IFX_CMGR_FaxAgentInfo *pxFaxAgentInfo)
{
    /* Start the fax session */
   int32 iCoderNum= -1,i,iFree=-1;
#ifndef IFX_T38_FW
   char8 cRetVal;
#endif

   x_MT_T38_Caps xT38_ConnProfile={0};
	 
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Start T38 Sess Req");
	 
	 
	 for(i=0;i<IFX_FAXAPP_MAX_CONNECTIONS;i++){
		 if(vxConnectionTbl[i].uiCallId == pxFaxAgentInfo->uiCallId){
			 iCoderNum = i;
       break;			 
		 }
     else if(vxConnectionTbl[i].uiCallId == 0){
			 iFree = i;			 
		 }		 
	 }
   if((i==IFX_FAXAPP_MAX_CONNECTIONS)&&(iFree != -1)){
		 iCoderNum = iFree;
     vxConnectionTbl[iCoderNum].uiCallId = pxFaxAgentInfo->uiCallId;		 
	 }
   //iCoderNum=IFX_FAXAPP_GetCoderChannel(pxFaxAgentInfo->szCoderDeviceName);
	 if(iCoderNum < 0){
		 IFX_FAXAPP_EventNotifier(pxFaxAgentInfo->uiCallId,
									 IFX_FAXAPP_START_T38_SESSION_ERR_RSP);
	 
     IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_ERR_REASON,
         "Start T38 Session Error", iCoderNum,
			   IFX_FAXAPP_START_T38_SESSION_ERR_RSP);
		}
		if(iCoderNum >= 0)
		   cEndFaxMsgSent[iCoderNum] = 0;
   memcpy(&xT38_ConnProfile, &pxFaxAgentInfo->axFaxParams[0].xFaxCfg,
                                           sizeof(x_IFX_FaxCfg));
#ifdef IFX_T38_FW

#else
   if (pxFaxAgentInfo->axFaxParams[0].xFaxCfg.uiTransportProtocol
			  == IFX_TRPROTO_TCP)
   {
			/*Due to mismatch in enums, converting it to MT_enums*/
			xT38_ConnProfile.uiTransportProtocol = MT_T38_CapType_TCP;
      /* Fd set the server sock fd */
      if (pxFaxAgentInfo->axFaxParams[0].uiRemoteFaxPort)
      { 
				 pxFaxAgentInfo->axFaxParams[0].uiLocalFaxPort = 0;
         /* We have to issue a connect now */
         vxConnectionTbl[iCoderNum].nTcpSendSockFd =
								 IFX_FAXAPP_CreateT38_Socket(IFX_TRPROTO_TCP,
                             //pxFaxAgentInfo->axFaxParams[0].uiLocalFaxPort,
																 0,
                             pxFaxAgentInfo->axFaxParams[0].uiRemoteFaxPort,
                             (char*)pxFaxAgentInfo->axFaxParams[0].szRemoteFaxIpAddr,
														 (char*)pxFaxAgentInfo->axFaxParams[0].szLocalFaxIpAddr,
                             IFX_FAXAPP_TCP_SOCKTYPE_CLIENT);

         if ( vxConnectionTbl[iCoderNum].nTcpSendSockFd < 0) 
         {
           /* If not able to create socket */
           IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, 
                    IFX_DBG_FUNC_ERROR, "IFX_FAXAPP_CreateT38_Socket");
	        /* Send Error Msg to UA */
           goto SendErrResp;
         }
      }
   }
   else if (pxFaxAgentInfo->axFaxParams[0].xFaxCfg.uiTransportProtocol
									 == IFX_TRPROTO_UDP)
   {
      /* UDP Connection - Create UDP Socket */
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, 
                        IFX_DBG_STR, "UDP Connection Requested");

        vxConnectionTbl[iCoderNum].nUdpSockFd =
							 	IFX_FAXAPP_CreateT38_Socket(IFX_TRPROTO_UDP,
                           pxFaxAgentInfo->axFaxParams[0].uiLocalFaxPort,
													 0, NULL, (char*)pxFaxAgentInfo->axFaxParams[0].szLocalFaxIpAddr,0);
       if ( vxConnectionTbl[iCoderNum].nUdpSockFd <= 0)
       {
          /* If not able to create socket */
          IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR,
                "IFX_FAXAPP_CreateT38_Socket");
          goto SendErrResp;
       }
   }
   else
   {
       goto SendErrResp;
   }
#endif
	if(iCoderNum >= 0){
   vxConnectionTbl[iCoderNum].unLocalPort = 
					 pxFaxAgentInfo->axFaxParams[0].uiLocalFaxPort;
   vxConnectionTbl[iCoderNum].unRemotePort = 
					 pxFaxAgentInfo->axFaxParams[0].uiRemoteFaxPort;
   strcpy(vxConnectionTbl[iCoderNum].acRemoteIpAddr,
          (char8 *)pxFaxAgentInfo->axFaxParams[0].szRemoteFaxIpAddr);
   strcpy(vxConnectionTbl[iCoderNum].acLocalIpAddr,
          (char8 *)pxFaxAgentInfo->axFaxParams[0].szLocalFaxIpAddr);
	}

  /* printf(" Local Port %d Remote port %d Remote address %s Local address %s \n",vxConnectionTbl[iCoderNum].unLocalPort,vxConnectionTbl[iCoderNum].unRemotePort,vxConnectionTbl[iCoderNum].acRemoteIpAddr,vxConnectionTbl[iCoderNum].acLocalIpAddr);*/


   if (pxFaxAgentInfo->bFaxInitiator)
   {
      vxT38_InitParam.iOptions |= MT_T38_INIT_OPT_CALLING;
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
                        "Calling End", iCoderNum);
   }
   if (iCoderNum >= 0 && IFIN_FA_PLT_AllocateChannel(pxFaxAgentInfo->szCoderDeviceName,iCoderNum,
         &vxConnectionTbl[iCoderNum].nFaxFd) == IFX_FAILURE)
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR,
                                                "Allocate Channel");
      goto SendErrResp;
   }
   if (iCoderNum >= 0 && vxConnectionTbl[iCoderNum].nFaxFd < 0)
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR,
                   IFX_DBG_FUNC_ERROR, "Fax Channel Fd");
      goto SendErrResp;
   }

   /*Update the Modulator/DeModulator releated Parameters in Connection Table */
	if(iCoderNum >= 0 ){
   vxConnectionTbl[iCoderNum].ucDPNR = 
                          vxT38_InitParam.ucDPNR;
   vxConnectionTbl[iCoderNum].unGain1 = 
                          vxT38_InitParam.unGain1;
   vxConnectionTbl[iCoderNum].unGain2 = 
                          vxT38_InitParam.unGain2;
   vxConnectionTbl[iCoderNum].unMOBSM = 
                          vxT38_InitParam.unMOBSM;
   vxConnectionTbl[iCoderNum].unMOBRD = 
                          vxT38_InitParam.unMOBRD;
   vxConnectionTbl[iCoderNum].unDMBSD = 
                          vxT38_InitParam.unDMBSD;
	}
   /* Modify the Bit Rate from the SS to suit T.38 Stack */

#ifndef IFX_T38_FW
   xT38_ConnProfile.unMaxBitRate /= 100;
#endif

  /* IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Transport Protocol", xT38_ConnProfile.uiTransportProtocol);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "T.38 Version", xT38_ConnProfile.ucVersion);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Rate Management", xT38_ConnProfile.ucRateManagement);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Max Bit Rate", xT38_ConnProfile.unMaxBitRate);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "Fill Bit Options", xT38_ConnProfile.uiBitOptions);
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "UDP Max Buff Size", xT38_ConnProfile.unUDPMaxBufferSize);
	IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "UDP Datagram Size", xT38_ConnProfile.unUDPMaxDatagramSize);
	IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_HEX_DISPLAY,
           "UDP Error Correction", xT38_ConnProfile.ucUDPErrCorrection);
    Set BitOptions to 0 even if announced from Remote  Party */
   xT38_ConnProfile.uiBitOptions = 0;

#ifdef IFX_T38_FW
   /* Start T.38 Session */
 if (iCoderNum >= 0 && IFX_FA_PLT_T38_StartSession(&vxT38_InitParam, &xT38_ConnProfile,
           &vxConnectionTbl[iCoderNum], iCoderNum, &vxMLibId)
                                                            != IFX_SUCCESS)
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR,
                       IFX_DBG_FA_SESS_START_ERR, iCoderNum);
      goto SendErrResp;
   }
#else
   if ((cRetVal = MT_T38_SessionStart(iCoderNum, &vxT38_InitParam,
           &xT38_ConnProfile, &vxMLibId)) != IFX_SUCCESS)
   {
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, 
                       IFX_DBG_FA_SESS_START_ERR, iCoderNum);
      goto SendErrResp;
   }
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
      "MT_T38_SessionStart Success", iCoderNum);
   v_ucNoOfConnections++;
   if (iCoderNum >= 0 && vxConnectionTbl[iCoderNum].nTcpServerSockFd)
   {
      FD_SET(vxConnectionTbl[iCoderNum].nTcpServerSockFd, &vxReadFds);
   }
   if (iCoderNum >= 0 && vxConnectionTbl[iCoderNum].nTcpSendSockFd)
   {
      FD_SET(vxConnectionTbl[iCoderNum].nTcpSendSockFd, &vxReadFds);
   }
   if (iCoderNum >= 0 && vxConnectionTbl[iCoderNum].nUdpSockFd)
   {
      FD_SET(vxConnectionTbl[iCoderNum].nUdpSockFd, &vxReadFds);
   }
   if(iCoderNum >= 0 && vxConnectionTbl[iCoderNum].nFaxFd)
   {
      FD_SET(vxConnectionTbl[iCoderNum].nFaxFd, &vxReadFds);
      FD_SET(vxConnectionTbl[iCoderNum].nFaxFd, &vxWriteFds);
   }
#endif
	if(iCoderNum >= 0 ){
   vxConnectionTbl[iCoderNum].ucCallStatus = IFX_FAXAPP_CALL_IN_PROG;
   vxConnectionTbl[iCoderNum].ucCoder = iCoderNum;
   vxConnectionTbl[iCoderNum].uiCallId = pxFaxAgentInfo->uiCallId;
	} 
   return IFX_SUCCESS;
SendErrResp:
   IFX_FAXAPP_CleanupConnection(iCoderNum);
   /* Send REQ_DEALLOC_CODER to RM and wait for Response */
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH,
                           IFX_DBG_STR, "Dealloc Coder Req sent to RM");
	 
	 IFX_FAXAPP_EventNotifier(pxFaxAgentInfo->uiCallId,
									 IFX_FAXAPP_START_T38_SESSION_ERR_RSP);
	 
   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_ERR_REASON,
       "Start T38 Session Error", iCoderNum,
			 IFX_FAXAPP_START_T38_SESSION_ERR_RSP);
   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_ProcessEndT38SessMsg
 *  Description     : Processes the EndT38 Session request from UA
 *
 *  Input Values    : Channel Number, End T38 Session Message
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/

STATIC char8 
IFX_FAXAPP_ProcessEndT38SessMsg(IN x_IFX_CMGR_FaxAgentInfo *pxFaxAgentInfo)
{
	 int32 iCoderNum=-1,i;
	 for(i=0;i<IFX_FAXAPP_MAX_CONNECTIONS;i++){
		 if(vxConnectionTbl[i].uiCallId == pxFaxAgentInfo->uiCallId){
			 iCoderNum = i;
       break;			 
		 }
	 }
   //iCoderNum=IFX_FAXAPP_GetCoderChannel(pxFaxAgentInfo->szCoderDeviceName);
	 if(iCoderNum < 0){
 
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH,
               IFX_DBG_STR, "Invalid Call ID");
			IFX_FAXAPP_EventNotifier(pxFaxAgentInfo->uiCallId,
											         IFX_FAXAPP_END_T38_SESSION_ERR_RSP);
			return IFX_FAILURE;
		}

   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "End T38 Session");
   if (vxConnectionTbl[iCoderNum].ucCallStatus != IFX_FAXAPP_CALL_IN_PROG)
   {
      /* This is a redundant request, to be ignored */
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "Redundant End T38 Session Msg");
      return IFX_SUCCESS;
   }
   /* We should not do a session stop here without checking if
    * fax transmission was finished.  Should wait for End of Fax Data
    */
   if (cEndFaxCallFlag[iCoderNum] == 1) 
   {
      /* End of Fax Data had come in already */
      IFX_FAXAPP_CloseT38Session(iCoderNum);
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, 
          IFX_DBG_FUNC_SUCCESS, "Close T38 Session as EndFaxCallFlag is set");
   }
   else 
   {
      if (1/*pxFaxAgentInfo->bFaxOnHk*/)
      {
         /* On-Hook from UA */
         IFX_FAXAPP_CloseT38Session(iCoderNum);
         IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, 
                              IFX_DBG_FUNC_SUCCESS, "Close T38 Session");
      }
      else
      {
         /* Set End of T.38 Session Flag */
         cEndFaxCallFlag[iCoderNum] = 2;
         IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, 
           IFX_DBG_FUNC_SUCCESS,"EndT38Session, wait for End T38 indication");

      }
   }
   vxConnectionTbl[iCoderNum].ucCallStatus = IFX_FAXAPP_CALL_TEAR_DOWN;
   /* Clean up the connection table and send a response to the UA */
   /* Before the connection is closed, we should close the Coder Fd*/

  if ( &vxConnectionTbl[iCoderNum].nFaxFd) 
	{
     IFIN_FA_PLT_DeallocateChannel(iCoderNum,
										 iCoderNum,vxConnectionTbl[iCoderNum].nFaxFd); 
	}
  IFX_FAXAPP_CleanupConnection(iCoderNum);
	vxConnectionTbl[iCoderNum].uiCallId = 0;
   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_ProcessStartT38Server
 *  Description     : Processes the Start T.38 server
 *  Input Values    : Channel Number, End T38 Session Message
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/

STATIC char8 
IFX_FAXAPP_ProcessStartT38Server(IN x_IFX_CMGR_FaxAgentInfo *pxFaxAgentInfo)
{
	 int32 iCoderNum=-1,i;
	 /*Stop Listing*/
	 if(pxFaxAgentInfo->bStopListen==IFX_TRUE){
  	 for(i=0;i<IFX_FAXAPP_MAX_CONNECTIONS;i++){
	  	 if(vxConnectionTbl[i].uiCallId == pxFaxAgentInfo->uiCallId){
		  	 iCoderNum = i;
         break;			 
		   }
	   }
	   if(iCoderNum < 0){
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH,
               IFX_DBG_STR, "Invalid Call ID");
			IFX_FAXAPP_EventNotifier(pxFaxAgentInfo->uiCallId,
											         IFX_FAXAPP_START_SERVER_T38_SESSION_ERR_RSP);
			return IFX_FAILURE;
		}
    FD_CLR(vxConnectionTbl[iCoderNum].nTcpServerSockFd, &vxReadFds);
		close(vxConnectionTbl[iCoderNum].nTcpServerSockFd);
		vxConnectionTbl[iCoderNum].nTcpServerSockFd=0;
		vxConnectionTbl[i].uiCallId =0;
		return IFX_SUCCESS;
	 }
	 /* Start Server is the first call so allocate a new slot */
	 for(i=0;i<IFX_FAXAPP_MAX_CONNECTIONS;i++){
		 if(vxConnectionTbl[i].uiCallId == 0){
			 iCoderNum = i;
			 vxConnectionTbl[i].uiCallId = pxFaxAgentInfo->uiCallId; 
       break;			 
		 }			 
	 }
	 if(iCoderNum < 0){
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH,
               IFX_DBG_STR, "Max Fax calls already in place");
			IFX_FAXAPP_EventNotifier(pxFaxAgentInfo->uiCallId,
											         IFX_FAXAPP_START_SERVER_T38_SESSION_ERR_RSP);
			return IFX_FAILURE;
		}

   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "StartT38Server");
   vxConnectionTbl[iCoderNum].nTcpServerSockFd =
				 IFX_FAXAPP_CreateT38_Socket(IFX_TRPROTO_TCP,
              pxFaxAgentInfo->axFaxParams[0].uiLocalFaxPort,
              0, 0,
							(char8 *)pxFaxAgentInfo->axFaxParams[0].szLocalFaxIpAddr,
              IFX_FAXAPP_TCP_SOCKTYPE_SERVER);

   if (vxConnectionTbl[iCoderNum].nTcpServerSockFd < 0)
   {
      /* If not able to create socket */
       IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_FUNC_FAIL,
                 "TCP Server Socket Create", vxConnectionTbl[iCoderNum].nTcpServerSockFd);
			IFX_FAXAPP_EventNotifier(pxFaxAgentInfo->uiCallId,
											         IFX_FAXAPP_START_SERVER_T38_SESSION_ERR_RSP);
      return IFX_FAILURE;     
   }
   FD_SET(vxConnectionTbl[iCoderNum].nTcpServerSockFd, &vxReadFds);
   return IFX_SUCCESS;	
}
 /******************************************************************************
 *  Function Name   : IFX_FAX_SendMsgToFifo
 *  Description     : This module writes Msg to FIFO 
 *
 *  Input Values    : ua Message
 *  Output Values   : None
 *  Return Value    :
 *  Notes           :
 ******************************************************************************
*/
int8 IFX_FAXAPP_SendMsgToFifo(IN int16 nFifoFd, 
					          IN char *pcFifoMsg,
							  IN int16 nMsgLen )
{
   int16 nBytes = 0;
   nBytes = IFX_OS_WriteFifo(nFifoFd, (char8 *) pcFifoMsg,nMsgLen);
	if (nBytes != nMsgLen)
	{
       IFX_DBGC(vcFaxModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "<FAX> Error Writing to Fifo" );
       return IFX_FAILURE;
	}
   IFX_DBGC(vcFaxModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "<FAX>  Writtng to Fifo Success");
   return IFX_SUCCESS;
}


/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_ProcessNewTcpConnections
 *  Description     : Processes New TCP Connection Requests
 *
 *  Input Values    : None
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/

STATIC char8 
IFX_FAXAPP_ProcessNewTcpConnections(void)
{
   int16 nNewSockFd = 0;
   struct sockaddr_in xRemoteAddr;
   socklen_t  nSockAddrLen = sizeof(xRemoteAddr);
   int16 nIdx = 0;

   for (nIdx = 0; nIdx < IFX_FAXAPP_MAX_CONNECTIONS; nIdx++)
   {
      if (FD_ISSET(vxConnectionTbl[nIdx].nTcpServerSockFd, &vxTmpReadFds))
      {
        /* Connect Request from Peer
         * Accept the connect
         * Process new TCP connection
         */
        /*
        IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
                                                    "Accept Req", nIdx);
        */
        nNewSockFd = accept(vxConnectionTbl[nIdx].nTcpServerSockFd, 
                     (struct sockaddr *)&xRemoteAddr, &nSockAddrLen);
        if (nNewSockFd < 0)
        {
           IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_FUNC_FAIL, 
             "Accept", vxConnectionTbl[nIdx].nTcpServerSockFd, nIdx);
					close(nNewSockFd);
           return IFX_FAILURE;
        }
        vxConnectionTbl[nIdx].nTcpRecvSockFd = nNewSockFd;
#if 0
        if (vxConnectionTbl[nIdx].ucTcpTOC ==
                                  IFX_FAXAPP_TCP_TOC_BIDIRECTIONAL)
        {
           vxConnectionTbl[nIdx].nTcpSendSockFd = nNewSockFd;
        }
#endif
        FD_SET(vxConnectionTbl[nIdx].nTcpRecvSockFd, &vxReadFds);
      }
   } /* End for */
   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_EndFaxCall
 *  Description     : Ends a Fax Call
 *                    
 *  Input Values    : Channel Number
 *  Output Values   : None 
 *  Return Value    : IFX_SUCCESS 
 *  Notes           :
 ******************************************************************************
 */
uchar8
IFX_FAXAPP_EndFaxCall(IN uchar8 ucChannelNum)
{
   if (cEndFaxMsgSent[ucChannelNum])
   {
      IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
         "Duplicate End Fax Call", ucChannelNum);
      return IFX_SUCCESS;
   }

   IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
         "EndFaxCall", ucChannelNum);
   cDatapumpError[ucChannelNum] = 1;
   /* We want to End the fax call, we are not bothered about
    * End of Fax data now
    */
   if (cEndFaxCallFlag[ucChannelNum] == 2)
   {
      /* End T38 Session has already come */
      return IFX_SUCCESS;
   }
   else
   {
      cEndFaxCallFlag[ucChannelNum] = 1;
      IFX_FAXAPP_EventNotifier(vxConnectionTbl[ucChannelNum].uiCallId,
									         IFX_FAX_END_SESSION);		
      IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
         "End Fax Call Mesg Sent", ucChannelNum);
      cEndFaxMsgSent[ucChannelNum] = 1;
   }
   return IFX_SUCCESS;
}
/*
 ******************************************************************************
 *  Function Name   : IFX_FAXAPP_ProcessExistingConnections
 *  Description     : Processes Existing Connections
 *
 *  Input Values    : None
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS, on success; IFX_FAILURE, on failure.
 *  Notes           :
 ******************************************************************************
*/

STATIC char8 
IFX_FAXAPP_ProcessExistingConnections(void)
{
   int16  nBytes = 0;
   int16 nIdx = 0;
   uint32 unBuffLen = IFX_FAXAPP_MAX_BUFFER_LEN;
   struct sockaddr_in xRemoteAddr;
   socklen_t nSockAddrLen = sizeof(xRemoteAddr);
 
   for (nIdx = 0; nIdx < IFX_FAXAPP_MAX_CONNECTIONS; nIdx++)
   {
     /* FaxFd has to be checked in ReadFds for availability of data */
     if (vxConnectionTbl[nIdx].nFaxFd)
     {
        if (FD_ISSET(vxConnectionTbl[nIdx].nFaxFd, &vxTmpReadFds))
        {
           /* Read Fd Set, data to be read from channel */
           vxConnectionTbl[nIdx].pucBuffer = 
                      IFX_MLIB_AllocMem(vxMLibId, 
                              (uint16) IFX_FAXAPP_MAX_BUFFER_LEN);
           if (vxConnectionTbl[nIdx].pucBuffer == IFX_MLIB_NULL)
           {
              IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_MEM_ALLOC_ERR,
                                     IFX_FAXAPP_MAX_BUFFER_LEN);
              IFX_FAXAPP_EndFaxCall(nIdx);
              return (IFX_FAILURE);
           }
           nBytes = IFIN_FA_PLT_DeviceRead(vxConnectionTbl[nIdx].nFaxFd, 
               (char8 *) vxConnectionTbl[nIdx].pucBuffer, unBuffLen);
           if (nBytes <= 0)
           {
              IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR,
                                             "Datapump Read");
               /* We may have to tear down the connection now 
                * When the read fails, there is some error 
                * and so it is better to shutdown the datapump
                */
              if (IFX_MLIB_FreeMem(vxMLibId, 
                  vxConnectionTbl[nIdx].pucBuffer) != IFX_MLIB_SUCCESS)
              {
                 IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
												 "Error Freeing Memory");
              }
              return IFX_FAILURE;
           }
           /* How can we distinguish between a command and data here ??? */
           if (!cDatapumpError[nIdx])
           {
              /* If there was a problem already observed with the 
               * datapump, drop the packet destined for T.38.
               */
              IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_DATA,
                 "MT_T38_DataRcvdFromDataPump", nIdx, nBytes);
#ifndef IFX_T38_FW
              if (MT_T38_DataRcvdFromDataPump(nIdx,
               vxConnectionTbl[nIdx]. pucBuffer, nBytes) != IFX_SUCCESS)
	           {
                 IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR,
                     "MT_T38_DataRcvdFromDataPump");
                 IFX_FAXAPP_EndFaxCall(nIdx);
              }
#endif
           }
           else
           {
              if (IFX_MLIB_FreeMem(vxMLibId, 
                 vxConnectionTbl[nIdx].pucBuffer) != IFX_MLIB_SUCCESS)
              {
                 IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
												 "Error Freeing Memory");
              }
           }
        }
        if (FD_ISSET(vxConnectionTbl[nIdx].nFaxFd, &vxTmpWriteFds))
        {
           /* Write Fd Set, request for more data from datapump
            * Inform T.38 stack 
            */
          if (!cDatapumpError[nIdx])
          {
             IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_FUNC_START,
                "FDP-REQ from DataPump", nIdx);
#ifndef IFX_T38_FW
             if (MT_T38_StatusBitsInfo(nIdx, MT_DSP_FDP_REQ_BIT)
	                            != IFX_SUCCESS)
             {
                IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR,
                               "MT_T38_StatusBitsInfo");
                IFX_FAXAPP_EndFaxCall(nIdx);
             }
#endif
          }
        }
     }
     if (vxConnectionTbl[nIdx].nTcpRecvSockFd)
     {
       if (FD_ISSET(vxConnectionTbl[nIdx].nTcpRecvSockFd, &vxTmpReadFds))
       {
         /* TCP Connection */
         vxConnectionTbl[nIdx].pucBuffer = 
                              IFX_MLIB_AllocMem(vxMLibId, 
                              (uint16) IFX_FAXAPP_MAX_BUFFER_LEN);
         if (vxConnectionTbl[nIdx].pucBuffer == IFX_MLIB_NULL)
         {
            IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
										 "Error Freeing Memory");
            IFX_FAXAPP_EndFaxCall(nIdx);
            return (IFX_FAILURE);
         }
         nBytes = recv(vxConnectionTbl[nIdx].nTcpRecvSockFd,
                          vxConnectionTbl[nIdx].pucBuffer, unBuffLen, 0);
         if (nBytes <= 0)
         {
           if (errno != EINTR)
           {
               IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FA_FUNC_FAIL,
                        "TCP Sock Read", nIdx); 
               FD_CLR(vxConnectionTbl[nIdx].nTcpRecvSockFd, &vxReadFds);
               IFX_FAXAPP_EndFaxCall(nIdx);
           }
           if (IFX_MLIB_FreeMem(vxMLibId, 
                vxConnectionTbl[nIdx].pucBuffer) != IFX_MLIB_SUCCESS)
           {	
              IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							  			 "Error Freeing Memory");
           }
           return IFX_FAILURE;
         }
         if (!cDatapumpError[nIdx])
         {
            IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_DATA,
               "MT_T38_PacketInfo", nIdx, nBytes);
#ifndef IFX_T38_FW
            if (MT_T38_PacketReceived(nIdx, 
                  vxConnectionTbl[nIdx].pucBuffer, nBytes) != IFX_SUCCESS)
            {
               IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_FUNC_ERROR,
                                                "MT_T38_PacketReceived Error");
               IFX_FAXAPP_EndFaxCall(nIdx);
            }
#endif
         }
         else
         {
            if (IFX_MLIB_FreeMem(vxMLibId, 
               vxConnectionTbl[nIdx].pucBuffer) != IFX_MLIB_SUCCESS)
            {
              IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							  			 "Error Freeing Memory");
            }
         }
       }
     } /* TCP Socket Processing Over */
     if (FD_ISSET(vxConnectionTbl[nIdx].nUdpSockFd, &vxTmpReadFds))
     {
       /* UDP T.38 Connection */
       vxConnectionTbl[nIdx].pucBuffer = 
        IFX_MLIB_AllocMem(vxMLibId, (uint16) IFX_FAXAPP_MAX_BUFFER_LEN);
       if (vxConnectionTbl[nIdx].pucBuffer == IFX_MLIB_NULL)
       {
          IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_MEM_ALLOC_ERR,
                                  IFX_FAXAPP_MAX_BUFFER_LEN);
           IFX_FAXAPP_EndFaxCall(nIdx);
           return (IFX_FAILURE);
       }
       nBytes = recvfrom(vxConnectionTbl[nIdx].nUdpSockFd, 
              (void *) vxConnectionTbl[nIdx].pucBuffer, unBuffLen, 0, 
              (struct sockaddr *)&xRemoteAddr, &nSockAddrLen);
       if (nBytes <= 0)
       {
          IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, 
                       IFX_DBG_FUNC_ERROR, "UDP Sock Read");
          FD_CLR(vxConnectionTbl[nIdx].nUdpSockFd, &vxReadFds);
          if (IFX_MLIB_FreeMem(vxMLibId, 
             vxConnectionTbl[nIdx].pucBuffer) != IFX_MLIB_SUCCESS)
          {
             IFX_DBGC(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							  			 "Error Freeing Memory");
          }
          IFX_FAXAPP_EndFaxCall(nIdx);
          return IFX_FAILURE;
       }
       if (!cDatapumpError[nIdx])
       {
          IFX_DBGA(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FA_DATA,
             "MT_T38_PacketInfo", nIdx, nBytes);
#ifndef IFX_T38_FW
          if (MT_T38_PacketReceived(nIdx, 
                 vxConnectionTbl[nIdx].pucBuffer, nBytes) != IFX_SUCCESS)
          {
             IFX_DBGC(vcFaxModId, IFX_DBG_LVL_HIGH, IFX_DBG_FUNC_ERROR,
                                                 "MT_T38_PacketReceived Error");
             IFX_FAXAPP_EndFaxCall(nIdx);
          }
#endif
       }
       else
       {
          if (IFX_MLIB_FreeMem(vxMLibId, 
               vxConnectionTbl[nIdx].pucBuffer) != IFX_MLIB_SUCCESS)
          {
             IFX_DBGA(vcFaxModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							  			 "Error Freeing Memory");
          }
       }
     }
   } /* for loop */
   return (IFX_SUCCESS);
}




/******************************************************************************
 *  Function Name   : IFX_FAXAPP_AppInit
 *  Description     : This Function is responsible of Initializing the FAX Application.  
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_FAXAPP_AppInit(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg *pxFA_T38Cfg)
{
   
   pid_t nPid;
   /* Create the new process for FAX/RTCP module */
   nPid = fork();
   if( nPid == -1 )
   {
#ifdef __LINUX__           
      printf(" fork fail \n");
#endif      
      return IFX_FAILURE;
   }
   if( nPid == 0 )
   {
			memset(*vppcArgv,0,strlen(*vppcArgv));
			strcpy(*vppcArgv, "Fax");
      IFX_FAXAPP_AppMain(ucDbgLvl,ucDbgType,pxFA_T38Cfg);
   }
   return nPid;
}
/******************************************************************
 * *  Function Name  :  IFX_FAX_DbgInit
 * *  Description      :  this function is responsible for initializing
 * *                 the debug module
 * *  Input Values      :  void
 * *  Output Values  :  void
 * *  Return Value      :  void
 * *  Notes       :
 * *********************************************************************/
int8 IFX_FAXAPP_DbgInit(uchar8 ucDbgLvl,uchar8 ucDbgType)
{
   int8 cRet = IFX_SUCCESS;
   IFX_DBG_Init(IFX_IPC_APP_NAME_FAX,ucDbgType,
                ucDbgLvl, &vcFaxModId, &cRet);
   if (cRet != IFX_SUCCESS)
   {
#ifdef __LINUX__           
      printf("Error Registering with DBG Libary, exiting\n");
#endif      
	   return IFX_FAILURE;
   }
   return IFX_SUCCESS;

}
/******************************************************************************
 *  Function Name   : IFX_FAXAPP_AppMain
 *  Description     : This Function is responsible of process messages recieved from
                      Fifo.  
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_FAXAPP_AppMain(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg  *pxFA_T38Cfg)
{
   int8 cRet = IFX_SUCCESS;
   int32 iNoOfFds=0;
   int16 nBufSize=0;

   cRet = IFX_FAXAPP_DbgInit(ucDbgLvl,ucDbgType);
   if (cRet != IFX_SUCCESS)
   {
#ifdef __LINUX__           
      printf("Error Registering with DBG Libary, exiting\n");
#endif
      return cRet;
   }
   /* Create FAX Fifo */ 
   umask( 0 );
   if(access( IFX_IPC_FAX_APP_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_FAX_APP_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGC(vcFaxModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_FAX_APP_FIFO");
         return cRet;
      }
   }
   if((v_nFAXAPPFifoFd = IFX_OS_OpenFifo( (uchar8 *)IFX_IPC_FAX_APP_FIFO,O_RDWR)) 
	   == -1 )
   {
      IFX_DBGC(vcFaxModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
	       "<AppMain> IFX_IPC_FAX_APP_FIFO");
      return cRet;
   }

   if(access( IFX_IPC_FAX_AGENT_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_FAX_AGENT_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGC(vcFaxModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_FAX_AGENT_FIFO");
         return cRet;
      }
   }
   if((v_nFAXAgentFifoFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_FAX_AGENT_FIFO,O_RDWR))
     == -1 )
   {
      IFX_DBGC(vcFaxModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
             "<AppMain> IFX_IPC_FAX_AGENT_FIFO");
      return cRet;
   }

   
   IFX_OS_FdZero( &vxReadFds );

   /* parent is waiting , resume parent process*/
   IFX_DBGC(vcFaxModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		    " <AppMain>Init success\n");
   IFX_OS_FdSet( v_nFAXAPPFifoFd,&vxReadFds );


   /* Register Signal handler for module termination */
   signal(SIGUSR1, IFX_FAXAPP_SignalHandler);
	 
   /* Initialise T.38 Fax Relay Parameters - Set to default values */
   IFX_FAXAPP_SetT38InitParam(pxFA_T38Cfg);

   while( 1 )
   {
     IFX_DBGC(vcFaxModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		"<AppMain> Select Block\n");
     memcpy(&vxTmpReadFds,&vxReadFds,sizeof(fd_set));
     memcpy(&vxTmpWriteFds, &vxWriteFds, sizeof(fd_set));

     iNoOfFds = select( FD_SETSIZE,&vxTmpReadFds,&vxTmpWriteFds,NULL,NULL );
     IFX_DBGC(vcFaxModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		"<AppMain> Select UnBlock");
     if( iNoOfFds < 0 )
     {
         if( errno == EINTR )
         {
						IFX_DBGC(vcFaxModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
										 "Interupted System Call");
            continue;
         }
         continue;
     }
     if( iNoOfFds == 0 )
     {
         continue;
     }
    /* Socket Fd's have to be checked before fifo fd.
      * There is a race condition when a connect request and
      * EndT38 session request land up at the same time.
      * The connect has to be processed prior to the EndT38
      * request
      */

     /* Process New TCP Connections */
     IFX_FAXAPP_ProcessNewTcpConnections(); 

     /* Process Existing Connections and Fax Data from Datapump */
     IFX_FAXAPP_ProcessExistingConnections();

     /* Check for msgs in the FAX  Fifo */
     if( IFX_OS_FdIsSet( v_nFAXAPPFifoFd,&vxTmpReadFds ))
     {
	     x_IFX_FAX_AGENT_Agent2App xAgentInfo;
       IFX_DBGC(vcFaxModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                "<AppMain> Message from FIFO");
       iNoOfFds--;
 	     nBufSize = IFX_OS_ReadFifo( v_nFAXAPPFifoFd,( char8 * )&xAgentInfo,
                                   sizeof( x_IFX_FAX_AGENT_Agent2App ) );
       if( nBufSize < 0 )
       {
         IFX_DBGC(vcFaxModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_READ_ERR,
			            "<AppMain>  FAX SS Fifo\n" );
       }
       switch(xAgentInfo.eAction)
	     {
		     case IFX_FAX_AGENT_START_SESSION:
            IFX_FAXAPP_ProcessStartT38SessMsg(&xAgentInfo.xAgentInfo);
			      break;
         case IFX_FAX_AGENT_STOP_SESSION:
            IFX_FAXAPP_ProcessEndT38SessMsg(&xAgentInfo.xAgentInfo);
			      break;
		     case IFX_FAX_AGENT_START_SERVER:
			      IFX_FAXAPP_ProcessStartT38Server(&xAgentInfo.xAgentInfo);
		        break;
				 case IFX_FAX_AGENT_MODIFY_CFG:
			      IFX_DBG_Set(IFX_IPC_APP_NAME_FAX,vcFaxModId,xAgentInfo.ucDbgType,
						             xAgentInfo.ucDbgLvl);
						break;
						
		   }
       
     }/*if FAX fd set */
   } /* while(1) end */
   IFX_FAXAPP_Shut();
   IFX_DBGC(vcFaxModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
   			"<AppMain> Terminated successfully\n" );
   return IFX_SUCCESS;
   
}

PUBLIC void 
  IFIN_FA_FaxStateChanged( uint16 uiChannelID, uint32 uiNewState )
{

}

