/**************************************************************************
**   FILE NAME      : IFX_SIP_Message.h
**   PROJECT        : SIP
**   MODULES        : Transaction User
**   SRC VERSION    : V2.0
**   DATE           : 15-12-2004
**   AUTHOR         : SIP Team
**   DESCRIPTION    : This contains the functions to send and receive InstMsg.
**   COMPILER       : gcc
**   REFERENCE      :
**   COPYRIGHT      : Copyright (c) 2004
**                    Infineon Technologies AG, st. Martin Strasse 53;
**                    81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_Message.h
    \brief File containing the Constants, enumerations, related Data structures
     and API's for any SIP Message construction.

*/
#ifndef __IFX_SIP_MESSAGE_H__
#define __IFX_SIP_MESSAGE_H__
 /**  \ingroup SIP_API
	   \defgroup MESSAGEAPI MESSAGE Method
     \brief This section lists the functions for handling message method.
*/
/* @{ */



/*! 
    \brief Listed below are the callback functions which can be registered
	for getting invoked while sending or receiving a MESSAGE method
	in the SIP message.

     Order of Callback invocations for outgoing request:
     The callback  pfnMsgToEncode is invoked whenever there is a request
     or a response going out.When a response arrives for the request sent out
     pfnMsgRespArrived is invoked. 

     Order of Callbacks invocation for Incoming request:
      The callback pfnReqArrived is invoked whenever there is an incoming 
      request, the application can now associate this transaction with a new 
      UserData.

    If the InstMsg request is challenged by a 401/407 Response
     The API IFX_SIP_InstMsgAuthenticate MUST be invoked within the
     pfnRespArrived callback.Transaction is automatically freed in case the 
     above callback's returns IFX_SIP_FAILURE.
*/
typedef struct
{
   e_IFX_SIP_Return (*pfnRequestArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiInstMsgHdl,
			            IN uint32 uiDialogHdl,
                        IN_OUT void **ppvUserData);/*!< Called on Request arrival */

  e_IFX_SIP_Return (*pfnTimeOutOrError)(
                        IN e_IFX_SIP_TransErrorCode eErrorType,
                        IN uint32 uiInstMsgHdl,
                        IN void *pvUserData);/*!< Called on Timeout or transport Error */

  e_IFX_SIP_Return  (*pfnMsgToEncode)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiInstMsgHdl,
                        IN void *pvUserData);/*!< Called before  message is encoded */

  e_IFX_SIP_Return (*pfnRespArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiInstMsgHdl,
                        IN void *pvUserData);/*!< Called on Response Arrival */

  e_IFX_SIP_Return  (*pfnDnsResolved)(
                        IN uint32 uiInstMsgHdl,
                        IN void *pvUserData);/*!<Called on resolving DNS address */

	uint32 uiStackHdl;/*!< Stack Instance Identifier*/

}x_IFX_SIP_InstMsgCallBks;

/* API to SIP User agent*/
/*! \brief Register all Call backs for SIP InstMsg Method.
    \param[in] pxCallBks Handle to the InstMsg Callback functions
               structure.
*/
void
IFX_SIP_InstMsgRegisterCallBk(IN x_IFX_SIP_InstMsgCallBks *pxCallBks);

/*! \brief Creates a Instant message node.

    \param[in] pvUserData User Data to be supplied at all call backs
    \param[out] puiInstMsgHdl Pointer to Handle to the InstMsg node.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_InstMsgCreate(IN void *pvUserData,
                      OUT uint32 *puiInstMsgHdl); 

/*! \brief  Associate InstMsg handle to specfic Stack and Interface.
    \param[in] uiInstMsgHdl Instant Msg Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the subscription will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_AssociateInstMsg(IN uint32 uiInstMsgHdl,
                         IN uint32 uiStackHdl,
                         IN uint32 uiIFHdl);

/*! \brief  Get Message specfic Stack and Interface handles.
    \param[in] uiInstMsgHdl Instant Msg Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_InstMsgGetStackIf(IN uint32 uiInstMsgHdl,
                         OUT uint32 *puiStackHdl,
                         OUT uint32 *puiIFHdl);

/*! \brief Sets the next hop address of the SIP request.

    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \param[in] pcRemoteAddr Remote Address.
    \param[in] unLocalPort Local Port.
    \param[in] unRemotePort Remote Port.
    \param[in] eProtocol Transport Protcol.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_InstMsgSetNextHopAddr(IN uint32 uiInstMsgHdl,
                              IN char8 *pcRemoteAddr,
                              IN uint16 unLocalPort,
                              IN uint16 unRemotePort,
                              IN e_IFX_SIP_Protocol eProtocol);

/*! \brief Sends out the Instant Message request with the given from and to address.

    If Instant Message request need to be sent out within a dialog, then the dialog related
    parameter should be filled in the message at pfnMsgToEncode callback.

    \note The InstMsg Handler is freed once a final response is arrived.
    This API Free's the uiMsgHdl and uiInstMsgHdl if any internal error occured.
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \param[in] pcTo To Address.
    \param[in] pcFrom From Address.
    \param[in] uiMsgHdl SIP Msg Hdlr.
    \param[in] uiDlgHdl Handle to the Dialog node.
    \param[in] unTcpClientPort Client port to be used in case of TCP connection.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return 
IFX_SIP_SendInstMsgReq(IN uint32 uiInstMsgHdl,
                       IN char8 *pcTo,
                       IN char8 *pcFrom,
		       IN uint32 uiMsgHdl,
                       IN uint32 uiDlgHdl,
		       IN uint16 unTcpClientPort);

/*! \brief Sends out the response to the received Instant Message request.

    The Instant Message response is constructed with the given response code 
    and reason phrase supplied otherwise default reason is sent.

    \note This API Free's the uiMsgHdl and uiInstMsgHdl 
          if any internal error occured.
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \param[in] uiMsgHdl SIP Msg Hdlr.
    \param[in] uiRespCode Response code.
    \param[in] pszReasonPhrase Reason phrase to be sent out in the response line
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_InstMsgSendResp(IN uint32 uiInstMsgHdl,
		        IN uint32 uiMsgHdl,
		        IN uint32 uiRespCode,
                        IN char8 *pszReasonPhrase);

/*! \brief Gets the message to encode handle.
    
    These API's can be used only within the pfnMsgToEncode Callback Function
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \return SIP message handle.
*/
uint32
IFX_SIP_InstMsgGetMsgToEncode(IN uint32 uiInstMsgHdl);

/*! \brief Gets the decoded SIP message handle.
    
    These API's can be used only within the pfnReqArrived and pfnRespArrived Callback Function
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \return SIP message handle.
*/
 uint32
IFX_SIP_InstMsgGetDecodedMsg(IN uint32 uiInstMsgHdl);


/*! \brief Adds the Auth header to the SIP message.
    \note MUST be called with the callback pfnRespArrived.

    Can be called when 401/407 response recived for the transaction request. 
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \param[in] pcUserName UserName to access the challenged domain.
    \param[in] pcPasswd Password to access the challenged domain.
    \param[in,out] uiSipMsgHdl  Handle to SIP message. 
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_InstMsgAuthenticate(IN uint32 uiInstMsgHdl,
                            IN char8 *pcUserName,
                            IN char8 *pcPasswd,
                            IN uint32 uiSipMsgHdl);


/*! \brief Free's the Memory associated with the Instant Message node.
 
    The User application has to take care of clearing the InstantMsg node
    for both client and server.
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
*/
 void
IFX_SIP_InstMsgFree(IN uint32 uiInstMsgHdl);

/*! \brief Send Request to next Dns Resolve IP list.
 
    \note The InstMsg Handler is freed once a final response is arrived.
    This API Free's the uiMsgHdl and uiInstMsgHdl if any internal error occured.
    \param[in] uiInstMsgHdl Handle to the InstMsg node.
    \param[in] uiSipMsgHdl Handle to the SIP Msg node.
*/
e_IFX_SIP_Return
IFX_SIP_InstMsgSendReqToNxtAddr(IN uint32 uiInstMsgHdl,IN uint32 uiSipMsgHdl);

/*! \brief Destroy the Inst Message transaction abruptly.

    Called for destroying a Inst Msg transaction.
    \param[in] uiInstMsgHdl Handle Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_InstMsgDestroy(IN uint32 uiInstMsgHdl);

/* @} */
#endif /* __IFX_SIP_MESSAGE_H__*/

