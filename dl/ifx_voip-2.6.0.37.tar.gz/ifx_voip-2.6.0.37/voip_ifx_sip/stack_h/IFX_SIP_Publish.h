/**************************************************************************
**   FILE NAME      : IFX_SIP_Publish.h
**   PROJECT        : SIP
**   MODULES        : Transaction User
**   SRC VERSION    : V2.3
**   DATE           : 
**   AUTHOR         : SIP Team
**   DESCRIPTION    : This contains the functions to send and receive Publish.
**   COMPILER       : gcc
**   REFERENCE      :
**   COPYRIGHT      : Copyright (c) 2004
**                    Infineon Technologies AG, st. Martin Strasse 53;
**                    81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifdef RFC_3903

/*! \file IFX_SIP_Publish.h
    \brief File containing the Constants, enumerations, related Data structures
     and API's for PUBLISH method implementation.

     Order of Callback invocations for outgoing request:
     The callback  pfnMsgToEncode is invoked whenever there is a request
     or a response going out. When a response arrives for the request, which 
     had been sent out, the callback pfnMsgRespArrived is invoked     

     Order of Callbacks invocation for Incoming request:
      On receiving an incoming request the callback pfnReqArrived is invoked, 
      the appliction can now associate this transaction with a new UserData.

    If the PUBLISH  request is challenged by 401/407  Response
     The API IFX_SIP_PublishAuthenticate MUST be invoked within the
     pfnRespArrived callback.Transaction is automatically freed in case the below 
     callback's returns IFX_SIP_FAILURE.

*/
 /** \ingroup SIP_API 
	   \defgroup PUBLISHAPI PUBLISH Method
     \brief This section lists the functions for handling PUBLISH method.
*/
/* @{ */

#ifndef __IFX_SIP_PUBLISH_H__
#define __IFX_SIP_PUBLISH_H__

/*! 
    \brief Provided below is a list of callback functions which are invoked 
     for supporting the PUBLISH method.
*/
typedef struct
{
   e_IFX_SIP_Return (*pfnRequestArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiPublishHdl,
                        IN uint32 uiDialogId,
                        IN_OUT void **ppvUserData);/*!< Called on Request arrival */

  e_IFX_SIP_Return (*pfnTimeOutOrError)(
                        e_IFX_SIP_TransErrorCode eErrorType,
                        IN uint32 uiPublishHdl,
                        IN void *pvUserData);/*!< Called on Timeout or transport Error */

  e_IFX_SIP_Return  (*pfnMsgToEncode)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiPublishHdl,
                        IN void *pvUserData);/*!< Called before  message is encoded */

  e_IFX_SIP_Return (*pfnRespArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiPublishHdl,
                        IN void *pvUserData);/*!< Called on Response Arrival */

  e_IFX_SIP_Return  (*pfnDnsResolved)(
                        IN uint32 uiPublishHdl,
                        IN void *pvUserData);/*!<Called on resolving DNS address */

  uint32 uiStackHdl;/*!< Stack Instance Identifier*/
}x_IFX_SIP_PublishCallBks;


/* API to SIP User agent*/
/*! \brief Register all Call backs for SIP PUBLISH Method.
    \param[in] pxCallBacks is a structure to the PUBLISH Callback functions
*/
 void
IFX_SIP_PublishRegisterCallBk(IN x_IFX_SIP_PublishCallBks *pxCallBacks);


/*! \brief Creates a PUBLISH node.
    \param[in] pvUserData User Data to be supplied in all call backs
    \param[out] puiPublishHdl Handle to the PUBLISH node
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_PublishCreate(IN void *pvUserData,
                      OUT uint32 *puiPublishHdl); 

/*! \brief  Associate PUBLISH handle to specfic Stack and Interface.
    \param[in] uiPublishHdl PUBLISH Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the request will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_AssociatePublish(IN uint32 uiPublishHdl,
                         IN uint32 uiStackHdl,
                         IN uint32 uiIFHdl);

/*! \brief  Get PUBLISH specfic Stack and Interface handles.
    \param[in] uiPublishHdl PUBLISH Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_PublishGetStackIf(IN uint32 uiPublishHdl,
                         OUT uint32 *puiStackHdl,
                         OUT uint32 *puiIFHdl);



/*! \brief Sets the next hop address of the sip request.
    \param[in] uiPublishHdl Handle to the PUBLISH node
    \param[in] pcRemoteAddr remote Address
    \param[in] unLocalPort Local Port
    \param[in] unRemotePort Remote Port
    \param[in] eProtocol Transport Protcol
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_PublishSetNextHopAddr(IN uint32 uiPublishHdl,
                              IN char8 *pcRemoteAddr,
                              IN uint16 unLocalPort,
                              IN uint16 unRemotePort,
                              IN e_IFX_SIP_Protocol eProtocol);

/*! \brief Sends out the PUBLISH request with the given from and to address.

    If PUBLISH request need to be sent out within a dialog, then the dialog related
    parameter should be passed to this function.
    \param[in] uiPublishHdl Handle to the PUBLISH node
    \param[in] uiMsgHdl SIP Message Handle
    \param[in] pcTo To Address
    \param[in] pcFrom From Addess
    \param[in] uiDlgHdl Dialog Handle
    \param[in] unTcpClientPort TCP client port to be used
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_PublishSendReq(IN uint32 uiPublishHdl,
                       IN uint32 uiMsgHdl,
                       IN char8 *pcTo,
                       IN char8 *pcFrom,
                       IN uint32 uiDlgHdl,
		       IN uint16 unTcpClientPort);

/*! \brief Sends the SIP request on the next DNS Resolved Address on transaction timeout 

    \param[in] uiPublishHdl Handle to the PUBLISH node
    \param[in] uiSipMsgHdl Handle to the SIP Message.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
e_IFX_SIP_Return
IFX_SIP_PublishSendReqToNxtAddr(IN uint32 uiPublishHdl,IN uint32 uiSipMsgHdl);

/*! \brief Sends out the response to the received PUBLISH request.

    The PUBLISH response is constructed with the given response code 
    and reason phrase if reason phrase is null default reason is sent.
    \param[in] uiPublishHdl Handle to the PUBLISH node
    \param[in] uiMsgHdl SIP Message Handle
    \param[in] uiRespCode Response code.
    \param[in] szReasonPhrase  Reason phrase to be sent out in the response line
    \param[in] unPort Port to be used
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_PublishSendResp(IN uint32 uiPublishHdl,
		        IN uint32 uiMsgHdl,
		        IN uint32 uiRespCode,
                        IN char8 *szReasonPhrase,
                        IN uint16 unPort);

/*! \brief Gets the message to encode.
    
    These API's can be used only within the pfnRegArrived and pfnRespArrived Functions
    \param[in] uiPublishHdl Handle to the PUBLISH node
    \return Handle to SIP Message
*/
PUBLIC uint32
IFX_SIP_PublishGetMsgToEncode(IN uint32 uiPublishHdl);

/*! \brief Gets the message to decode.
    
    These API's can be used only within the pfnMsgToEncode  Functions.
    \param[in] uiPublishHdl Handle to the PUBLISH node
    \return Handle to SIP Message
*/
uint32
IFX_SIP_PublishGetDecodedMsg(IN uint32 uiPublishHdl);


/*! \brief Adds the Auth header to the sip message and sends it out.

    Can be called when 401/407 response recived for the transaction request.
    \param[in] uiPublishHdl Handle to the PUBLISH node
    \param[in] pcUserName User name
    \param[in] pcPasswd Password
    \param[in,out] uiMsgToEncode Handle to SIP  message
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIP_PublishAuthenticate(IN uint32 uiPublishHdl,
                            IN char8 *pcUserName,
                            IN char8 *pcPasswd,
                            IN uint32 uiMsgToEncode);


/*! \brief Free's the  memory associated with the PUBLISH node.
 
    The User application has to take care of clearing the PUBLISH node
    if PUBLISH send request is not called
    \param[in] uiPublishHdl Handle to the PUBLISH node
*/
PUBLIC void
IFX_SIP_PublishFree(IN uint32 uiPublishHdl);

/*! \brief Destroy the PUBLISH transaction abruptly.

    Called for destroying a PUBLISH transaction.
    \param[in] uiPublishHdl PUBLISH Handle Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_PublishDestroy(IN uint32 uiPublishHdl);


#endif /* __IFX_SIP_Publish_H__*/

/* @} */
#endif /* RFC_3903 */
