/**************************************************************************
**   FILE NAME    : IFX_SIP_MsgApi.h
**   PROJECT      : SIP 
**   MODULES      : Get and Set APIs for constructing the SIP Message
**   SRC VERSION  : V2.2.1
**   DATE         : 
**   AUTHOR       : SIP Team
**   DESCRIPTION  : APIs for using the SIP Message.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
/*! \file IFX_SIP_MsgApi.h
    \brief File containing the Constants, enumerations, related Data structures
    \ And API's for any SIP Message construction.

*/

#ifndef __IFX_SIP_MsgApi_H__
#define __IFX_SIP_MsgApi_H__
/**  \ingroup SIP_API
	  \defgroup MSGAPI Protocol Message handling 
    \brief This section lists the message functions.
*/


/*########################SIP Message#########################*/
 /** \ingroup  MSGAPI
	\defgroup General Generic Message Methods
    \brief This section contains the APIs for Creating a message, Copying a message, Freeing a Message, Getting and setting type of message.
*/
/* @{ */

/*! \brief      Construct a SIP Message    
    \param[out] puiSipMsgHdl stores the address of the pointer to the SIP Message
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CreateMsg(OUT IN uint32 *puiSipMsgHdl);

/*! \brief      Copy the SIP Message    
    \param[in]  uiFromSipMsgHdl Reference to the SIP Message
	\param[out] puiToSipMsgHdl Reference to the copied SIP Message
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CopyMsg(IN uint32 uiFromSipMsgHdl,
                OUT uint32 *puiToSipMsgHdl);

/*! \brief      Free the SIP Message    
    \param[in]  uiSipMsgHdl Reference to the SIP Message
*/
void
IFX_SIP_FreeMsg(IN uint32 uiSipMsgHdl);

/*! \brief      Parse the message and return a message handle    
    \param[in]  pszMsg Reference to the SIP buffer
    \return     Returns a message handle in case it is properly parsed else 0
*/
uint32
IFX_SIP_ParseMsg(IN char8* pszMsg);

/*! \brief      Return Type of SipMessage (i.e Request/Response)
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Request OR Response
*/
e_IFX_SIP_MsgType
IFX_SIP_GetMessageType(IN uint32 uiSipMsgHdl);



/*! \brief      Sets Type of SIP Message 
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  eMsgType IFX_SIP_REQUEST or IFX_SIP_RESPONSE
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SetMessageType(IN uint32 uiSipMsgHdl,
                       IN e_IFX_SIP_MsgType eMsgType);

/*! \brief      Verifies if the header the given string is in the Address 
                type format
    \param[in]  pcAddr Address Type
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Verify_AddressFormat(IN char8* pcAddr);

/* @} */

  /** \ingroup MSGAPI 
  \defgroup Body Add message Body
    \brief This section contains the APIs for Getting and setting the message bodies.
*/
/* @{ */
               
/*! \brief      Add the Message body to the SIP Message    
    \param[in]  uiSipMsgHdl Reference to the SIP Message
	\param[in]  iLen Length of the body
	\param[in]  szBody Body to add to the Message
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AddMsgBody(IN uint32 uiSipMsgHdl,
		   IN int32 iLen,
                   IN char8* szBody);

/*! \brief      Get the Message body of the SIP Message    
    \param[in]  uiSipMsgHdl Reference to the SIP Message
    \return     MsgBody or NULL pointer on failure
*/
char8*
IFX_SIP_GetMsgBody(IN uint32 uiSipMsgHdl);

/* @} */

/*##################Get Header By Type#########################*/
  /** \ingroup MSGAPI 
  \defgroup Hdr Getting the Header Handles
    \brief This section contains the APIs for Getting and setting the Headers.
*/
/* @{ */

/*! \brief      Gets the Header Information by type
    \param[in]  uiSipMsgHdl Reference to the SIP Message Header
    \param[in]  eHdrType Enumeration of the  header
    \param[in]  iLocation Particular parameter of the Header
    \param[in,out]  puiHdrHdl Stores the address of that header
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_GetHeaderByType(IN  uint32 uiSipMsgHdl,
                        IN  e_IFX_SIP_TypeOfHdr  eHdrType,
                        IN  int32 iLocation,
                        OUT uint32 *puiHdrHdl);

/*##################Get Header By Name#########################*/

/*! \brief      Gets the Header Information by type
    \param[in]  uiSipMsgHdl Reference to the SIP Message Header
    \param[in]  szHdrName Header name
    \param[in]  iLocation Particular parameter of the Header
    \param[in,out]  puiHdrHdl Handle to the header
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_GetHeaderByName(IN  uint32 uiSipMsgHdl,
                        IN  char8 *szHdrName,
                        IN  int32 iLocation,
                        OUT uint32 *puiHdrHdl);

/*##################Set Header By Type#########################*/

/*! \brief      Sets the Header Information by type
    \param[in]  uiSipMsgHdl Reference to the SIP Message Header
    \param[in]  eHdrType Enumeration of the  header
    \param[in,out]  puiHdrHdl Stores the address of that header
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SetHeaderByType(IN  uint32 uiSipMsgHdl,
                        IN  e_IFX_SIP_TypeOfHdr  eHdrType,
                        OUT uint32 *puiHdrHdl);

/*! \brief      Sets the header by name
    \param[in]  uiSipMsgHdl SIP message handle
    \param[in]  szHdrName Header name
    \param[out]  puiHdrHdl Handle to the requested header
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SetHeaderByName(IN  uint32 uiSipMsgHdl,
                        IN  char8 *szHdrName,
                        OUT uint32 *puiHdrHdl);

/* @} */

#ifdef RFC_3262
/*##################RAck Header#########################*/
/** \ingroup MSGAPI 
	\defgroup RAck RAck Header
    \brief This section contains the APIs for getting and setting parameters in the RAck Header
*/
/* @{ */

/*! \brief 	Set RSeqNumber in RAck Header
    \param[in] 	uiRackHdl Reference to the RAck Header
    \param[in] 	iRSeq RSeq Number    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIP_RAck_SetRSeqNumber(IN uint32 uiRackHdl,
                           IN int32 iRSeq);


/*! \brief 	Set CSeq Number in RAck Header
    \param[in] 	uiRackHdl Reference to the RAck Header
    \param[in] 	iCSeq CSeq Number
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIP_RAck_SetCSeqNumber(IN uint32 uiRackHdl,
                           IN int32 iCSeq);


/*! \brief 	Set Method in RAck Header
    \param[in] 	uiRackHdl Reference to the RAck Header
    \param[in] 	MethodName  Enumeration from  eBasicMethod
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIP_RAck_SetMethod(IN uint32 uiRackHdl,
                       IN e_IFX_SIP_BasicMethod MethodName);


/*! \brief 	Get RSeq number from RAck Header
    \param[in] 	uiRackHdl Reference to the RAck Header
    \return 	RSeq number 
*/

PUBLIC int32
IFX_SIP_RAck_GetRSeqNumber(IN uint32 uiRackHdl);

/*! \brief 	Get CSeq number from RAck Header
    \param[in] 	uiRackHdl Reference to the RAck Header 
    \return	CSeq number
*/

PUBLIC int32
IFX_SIP_RAck_GetCSeqNumber(IN uint32 uiRackHdl);

/*! \brief 	Get Method name from RAck Header
    \param[in] 	uiRackHdl Reference to the RAck Header
    \return 	BasicMethod Name 
*/

PUBLIC e_IFX_SIP_BasicMethod
IFX_SIP_RAck_GetMethod(IN uint32 uiRackHdl );

/* @} */

/*##################RSeq Header#########################*/
/** \ingroup MSGAPI 
	\defgroup RSeq RSeq Header
    \brief This section contains the APIs for getting and setting parameters in the RSeq Header
*/
/* @{ */

/*! \brief 	Set RSeq Number in RSeq Header Field
    \param[in] 	uiRSeqHdl Reference to the RAck Header
    \param[in] 	iRSeq RSeq value
    \return 	IFX_SIP_SUCCESS OR IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIP_RSeq_SetRSeqNumber(IN uint32 uiRSeqHdl,
                           IN int32 iRSeq );

/*! \brief 	Get RSeq Number from RSeq Header Field
    \param[in] 	uiRSeqHdl Reference to the RAck Header
    \return 	RSeq Number
*/

PUBLIC int32
IFX_SIP_RSeq_GetRSeqNumber(IN uint32 uiRSeqHdl);

/* @} */
#endif /*RFC_3262*/

/*##################Option#################################*/
/** \ingroup MSGAPI 
	\defgroup OptionTag Supported/Proxy-Require/Require/Unsupported headers
    \brief This section contains the APIs for getting and setting Option tags in Supported/Proxy-Require/Require/Unsupported headers
*/
/* @{ */

/*! \brief 	Set the option tag in given Header field 
           	(Supported,Proxy-Require,Require,Unsupported)
    \param[in] 	uiOptionTagHdl Pointer to headerfield Suppoted/Proxy-Require/
                Require/Unspported
    \param[in] 	szOptionTag Option tag to be set  
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIP_SetOptionTag(IN uint32 uiOptionTagHdl,
                     IN char8* szOptionTag );

/*! \brief      Get the option tag in given Header field
                (Supported,Proxy-Require,Require,Unsupported)
    \param[in]  uiOptionTagHdl Handle 
    \return     Tag
*/
char8*
IFX_SIP_GetOptionTag(IN uint32 uiOptionTagHdl);

/* @} */

/*##################Contact Header#########################*/
/** \ingroup MSGAPI 
	\defgroup Contact Contact header
    \brief This section contains the APIs for getting and setting the parameters inside the contat header
*/
/* @{ */

/*! \brief  	Get Expire value from Contact Header Field
    \param[in] 	uiContactParamHdl Reference to the Contact param
    \return 	Expire Value
*/
uint32
IFX_SIP_Contact_GetExpire(IN uint32 uiContactParamHdl );


/*! \brief  	Get Q value from Contact Header Field
    \param[in] 	uiContactParamHdl Reference to the Contact param
    \return 	QValue
*/
char8*
IFX_SIP_Contact_GetQValue(IN uint32 uiContactParamHdl);


/*! \brief  	Set QValue in Contact Header Field
    \param[in] 	uiContactParamHdl Reference to the Contact param
    \param[in] 	pcQValue To be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_Contact_SetQValue(IN uint32 uiContactParamHdl,
                           IN char8 *pcQValue );


/*! \brief  	Set Expire value from Contact Header Field
    \param[in] 	uiContactParamHdl Reference to the Contact param
    \param[in] 	uiCpExpires Expire Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Contact_SetExpire(IN uint32 uiContactParamHdl,
                           IN uint32 uiCpExpires );

/*! \brief  	Gets the reference to the Address type of Contact Param. 
    \param[in] 	uiContactParamHdl Reference to the Contact param
    \return 	Reference to the Address Type parameter 
*/
uint32
IFX_SIP_Contact_GetAddressType(IN uint32 uiContactParamHdl); 

/*! \brief  	Check whether the Token is present in Contact Param.
    \param[in]  uiContactParamHdl Reference to the Contact Param
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Contact_HasToken(IN uint32 uiContactParamHdl,
                             IN char8* pcToken);


/*! \brief      Gets the generic param value of the Contact Param   
    \param[in]  uiContactParamHdl Reference to the Contact Param
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_Contact_GetGenericParam(IN uint32 uiContactParamHdl,
                                IN int32 iLocation,
                                IN char8* pcToken);

/*! \brief      Sets the generic param value to the Contact Param
    \param[in]  uiContactParamHdl Reference to the Contact Param
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Contact_SetGenericParam(IN uint32 uiContactParamHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the Contact Parameter in the specified location   
    \param[in]  uiContactParamHdl Reference to the Contact Param
    \param[in]  iLocation Location(starts from 1) of the Contact 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Contact_GetParam(IN uint32 uiContactParamHdl,
                         IN int32 iLocation,
                         IN char8** pcName,
                         IN char8** pcValue);

/* @} */

/*##################Event Header#########################*/
/** \ingroup MSGAPI 
	\defgroup Event Event header
    \brief This section contains the APIs for getting and setting the parameters inside the Event header
*/
/* @{ */

/*! \brief  	Get EventID from Event Header Field
    \param[in] 	uiEventHdrHdl Reference to the Event Header
    \return Event Id or Null Pointer on Failure 
*/
char8*
IFX_SIP_Event_GetEventID(IN uint32 uiEventHdrHdl);


/*! \brief  	Set EventID in Event Header Field
    \param[in] 	uiEventHdrHdl Reference to the Event Header
    \param[in] 	pcID Event Id to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Event_SetEventID(IN uint32 uiEventHdrHdl,
                         IN char8 *pcID );


/*! \brief  	Get EventType from Event Header Field
    \param[in] 	uiEventHdrHdl Reference to the Event Header
    \return 	Reference to the Event Type 
*/
uint32
IFX_SIP_Event_GetEventType(IN uint32 uiEventHdrHdl);


/*! \brief  	Set EventType  in Event Header Field
    \param[in] 	uiEventHdrHdl Reference to the Event Header
    \param[in] 	uiEventTypesHdl Reference to the Event Type
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_Event_SetEventType(IN uint32 uiEventHdrHdl,
                           IN uint32 uiEventTypesHdl);

/*! \brief  	Get the package of this Event Header 
    \param[in] 	uiEventHdrHdl Reference to the AllowEvents Header 
    \return 	Event package name.
    \note user has to free the returned buffer 
*/
char8* 
IFX_SIP_Event_GetPackage(IN uint32 uiEventHdrHdl);


/*! \brief  	Sets the package of this Event Header 
            	to the supplied value 
    \param[in] 	uiEventHdrHdl Reference to the Event Header 
    \param[in] 	acEventPackage Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_Event_SetPackage(IN uint32 uiEventHdrHdl, 
                        IN char8* acEventPackage);

/*! \brief  	Check whether the Token is present in Event Header.
    \param[in]  uiEventHdrHdl Reference to the Event Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_Event_HasToken(IN uint32  uiEventHdrHdl,
                       IN char8* pcToken);


/*! \brief      Gets the generic param value of the Event Header,        
    \param[in]  uiEventHdrHdl Reference to the Event Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_Event_GetGenericParam(IN uint32 uiEventHdrHdl,
                              IN int32 iLocation,
                              IN char8* pcToken);

/*! \brief      Sets the generic param value to the Event Header
    \param[in]  uiEventHdrHdl Reference to the Event Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Event_SetGenericParam(IN uint32 uiEventHdrHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the Event Parameter in the specified location   
    \param[in]  uiEventHdrHdl Reference to the Contact Param
    \param[in]  iLocation Location(starts from 1) of the Contact 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Event_GetParam(IN uint32 uiEventHdrHdl,
                       IN int32 iLocation,
                       IN char8** pcName,
                       IN char8** pcValue);


/* @} */

/*##################Date Header#########################*/
/** \ingroup MSGAPI 
	\defgroup Date Date header
    \brief This section contains the APIs for getting and setting the parameters in the Date header
*/
/* @{ */

/*! \brief  	Get WeekDay from Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Name of weekDay(for exmample SUNDAY)
*/

char8*
IFX_SIP_Date_GetWeekDay(IN uint32 uiDateHdl);

/*! \brief  	Set WeekDay in Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	pcWeekDay Name of the Week Day (for example SUNDAY)
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Date_SetWeekDay(IN uint32 uiDateHdl,
                        IN char8 *pcWeekDay);


/*! \brief  	Set Day in Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	ucDay Day to be set(for example 20)
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_Date_SetDay(IN uint32 uiDateHdl,   
                    IN uchar8 ucDay);

/*! \brief  	Get Day from Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Day(for exmample 20)
*/
uchar8
IFX_SIP_Date_GetDay(IN uint32 uiDateHdl );


/*! \brief  	Set Year in Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	iYear Year to be set(for example 2006) 
    \return 	IFX_SIP_SUCCESS OR IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_Date_SetYear(IN uint32 uiDateHdl,
                     IN int16 iYear );

/*! \brief  	Get Year from Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Year(for exmample 2006)
*/

int16
IFX_SIP_Date_GetYear(IN uint32 uiDateHdl);


/*! \brief  	Set Month in Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	pcMonth Name of the Month to be set(for example MARCH)
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_Date_SetMonth(IN uint32 uiDateHdl,
                       IN char8 *pcMonth);


/*! \brief  	Get Month from Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Name of Month (for example MARCH)
*/
char8*
IFX_SIP_Date_GetMonth(IN uint32 uiDateHdl);

/*! \brief  	Set Seconds in  Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	ucDigit Seconds to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Date_SetSeconds(IN uint32 uiDateHdl,
                         IN uchar8 ucDigit);

/*! \brief  	Set Hours in  Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	ucDigit Hours to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/


e_IFX_SIP_Return
IFX_SIP_Date_SetHours(IN uint32 uiDateHdl,
                         IN uchar8 ucDigit);


/*! \brief  	Set Seconds in  Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \param[in] 	ucDigit Minutes to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_Date_SetMinutes(IN uint32 uiDateHdl,
                        IN uchar8 ucDigit);

/*! \brief  	Get Seconds from  Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Seconds value
*/

uchar8
IFX_SIP_Date_GetSeconds(IN uint32 uiDateHdl);


/*! \brief  	Get Seconds from  Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Hours value
*/

uchar8
IFX_SIP_Date_GetHours (IN uint32 uiDateHdl);


/*! \brief  	Get Minutes from  Date Header Field
    \param[in] 	uiDateHdl Reference to the Date Header
    \return 	Minutes value
*/
uchar8
IFX_SIP_Date_GetMinutes(IN uint32 uiDateHdl);

/* @} */

/*##################Subscription State Header#########################*/
/** \ingroup MSGAPI 
	\defgroup SubsState Subscription-state header
    \brief This section contains the APIs for getting and setting the parameters in the Subscription-State header
*/
/* @{ */

/*! \brief     Get Expire from SubScription State Header
    \param[in] uiSubStateHdl Reference to the Subscription State Header
    \return    Expire Value
*/
int32
IFX_SIP_SubState_GetExpires(IN uint32 uiSubStateHdl);


/*! \brief  	Set Expire value of the SubScription State Header
    \param[in] 	uiSubStateHdl Reference to the Subscription State Header
    \param[in] 	iExpire Expire value to be set
    \return 	IFX_SIP_SUCCESS OR IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_SubState_SetExpires(IN uint32 uiSubStateHdl,
                            IN int32 iExpire);

/*! \brief    	Gets the reason code value of the Subscription State Header.
    \param[in] 	uiSubStateHdl Reference to the Subscription State Header
    \return  	ReasonCode or Null Pointer on Failure 
*/
char8* 
IFX_SIP_SubState_GetReasonCode(IN uint32 uiSubStateHdl);



/*! \brief     Sets the reason code value of the Subscription State Header
    \param[in] uiSubStateHdl Reference to the Subscription State Header
    \param[in] pcReasonCode Reason code to be set
    \return    IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SubState_SetReasonCode(IN uint32 uiSubStateHdl,
                               IN char8 *pcReasonCode);


/*! \brief     Gets the retry after value from the Subscription State Header
    \param[in] uiSubStateHdl Reference to the Subscription State Header
    \return    RetryAfterValue
*/
int32
IFX_SIP_SubState_GetRetryAfter(IN uint32 uiSubStateHdl);


/*! \brief     Sets the retry after value in the Subscription State Header
    \param[in] uiSubStateHdl Reference to the Subscription State Header
    \param[in] iRetryAfter  RetryAfter Value to be set
    \return    IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_SubState_SetRetryAfter(IN uint32 uiSubStateHdl,
                               IN int32 iRetryAfter);

/*! \brief     Gets the state of Subscription State Header. 
    \param[in] uiSubStateHdl Reference to the Subscription State Header
    \return    pxSubState or Null Pointer on Failure
*/
char8*
IFX_SIP_SubState_GetState(IN uint32 uiSubStateHdl);

/*! \brief     Gets the state of Subscription State Header.
    \param[in] uiSubStateHdl Reference to the Subscription State Header
    \param[in] pcSubState State to be set
    \return    IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_SubState_SetState(IN uint32 uiSubStateHdl,
                          IN char8 *pcSubState);

/*! \brief  	Check whether the Token is present in Subscription State Header.
    \param[in]  uiSubStateHdl Reference to the Subscription State Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Subscription_HasToken(IN uint32 uiSubStateHdl,
                             IN char8* pcToken);


/*! \brief      Gets the generic param value of the Subscription State Header   
    \param[in]  uiSubStateHdl Reference to the Subscription State Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_Subscription_GetGenericParam(IN uint32 uiSubStateHdl,
                                     IN int32 iLocation,
                                     IN char8* pcToken);

/*! \brief      Sets the generic param value to the Subscription State Header
    \param[in]  uiSubStateHdl Reference to the Subscription State Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Subscription_SetGenericParam(IN uint32 uiSubStateHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the SubState Parameter in the specified location   
    \param[in]  uiSubStateHdl Handle to the Subscription state
    \param[in]  iLocation Location(starts from 1) of the Subscription 
                state parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_SubState_GetParam(IN uint32 uiSubStateHdl,
                          IN int32 iLocation,
                          IN char8** pcName,
                          IN char8** pcValue);



/* @} */
/*##################SIP URI API's#########################*/
/** \ingroup MSGAPI 
	\defgroup SipsUri SIP/SIPS URI
    \brief This section contains the APIs for getting and setting the parameters in SIP URI
*/
/* @{ */

/*! \brief      Returns the header  corresponding to 
                pcHeaderName or null if it is not set
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  pcHeaderName Name for which header value is being fetched 
    \return     Returns the header value corresponding to pcHeaderName or null     
*/
char8*
IFX_SIP_SipUri_GetHeader(IN uint32 uiSipUriHdl,
                         IN char8* pcHeaderName);

				
/*! \brief      Gets the SIP/SIPS headers parameter in the specified location   
    \param[in]  uiSipUriHdl Handle to the SIP/SIPS URI
    \param[in]  iLocation Location(starts from 1) of the SIP URI 
                parameters
    \param[out]  pcName Reference to the header Name.
    \param[out]  pcValue Reference to the header value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should not free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_GetHeaderByLoc(IN uint32 uiSipUriHdl,
                              IN int32 iLocation,
                              OUT char8** pcName,
                              OUT char8** pcValue );

/*! \brief      Sets the value of the specified header fields to 
                be included in a request constructed from the URI.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  pcHeaderName Header name
    \param[in]  pcHeaderVal Header value    
    \return     IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/					

e_IFX_SIP_Return
IFX_SIP_SipUri_SetHeader(IN uint32 uiSipUriHdl,
			 IN char8* pcHeaderName,
 			 IN char8* pcHeaderVal);
					
					
/*! \brief      Returns the host part of this SipURI
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return  host or Null Pointer on failure     
*/
char8*
IFX_SIP_SipUri_GetHost( IN uint32 uiSipUriHdl);


/*! \brief      Set the host part of this SipURI to the newly 
                supplied host parameter.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  pcHostInfo Host value
    \return     IFX_SIP_SUCCESS or IFX_SIP_FALIURE    
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetHost(IN uint32 uiSipUriHdl,
                       IN char8* pcHostInfo);				    
				    
/*! \brief      Returns the value of the maddr parameter, 
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return  MAddr param or Null Pointer on failure
*/
char8*	
IFX_SIP_SipUri_GetMAddrParam(IN uint32 uiSipUriHdl);



/*! \brief      Sets the value of the maddr parameter of this SipURI
                to the newly supplied maddr value                
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  pcHostInfo Host Info (MAddr Param)
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetMAddrParam(IN uint32 uiSipUriHdl,
                             IN char8 *pcHostInfo);
				    
				    
/*! \brief      Returns the value of the method parameter
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return  Method Param or Null pointer on Failure
*/
char8*
IFX_SIP_SipUri_GetMethodParam(IN uint32 uiSipUriHdl );



/*! \brief      Sets the value of the method parameter.                
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  szExtMethod Method parameter to be set
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE    
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetMethodParam(IN uint32 uiSipUriHdl,
                               IN char8* szExtMethod);
						 
						 
						 
/*! \brief      Returns the port part of this SipURI.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return     PortNumber
*/
uint16
IFX_SIP_SipUri_GetPort(IN uint32 uiSipUriHdl );

/*! \brief      Set the port part of this SipURI to the newly 
                supplied port parameter
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  uiPort PortNumber to be set
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE    
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetPort(IN uint32 uiSipUriHdl,
                        IN uint16 uiPort );
				    
/*! \brief      Removes the port part of this SipURI
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return     void    
*/
void
IFX_SIP_SipUri_RemovePort(IN uint32 uiSipUriHdl);				    						 

/*! \brief      Gets the value of the Transport parameter, 
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return  Transport parameter OR Null
*/
char8*
IFX_SIP_SipUri_GetTransportParam(IN uint32 uiSipUriHdl );

						 
/*! \brief      Sets the value of the Transport parameter.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  szOtherTrans Transport parameter
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetTransportParam(IN uint32 uiSipUriHdl,
				  IN char8* szOtherTrans);
				    

/*! \brief      Returns the value of the TTL parameter
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return     TTLParam
*/
int32
IFX_SIP_SipUri_GetTTLParam(IN uint32 uiSipUriHdl );


/*! \brief      Sets the value of the ttl parameter.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  iTtlParam TTL parameter
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetTTLParam(IN uint32 uiSipUriHdl,
    			    IN int32 iTtlParam);

/*! \brief      Returns the user part of this SipURI.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \return  User or Null pointer on Failure
*/
char8*
IFX_SIP_SipUri_GetUser(IN uint32 uiSipUriHdl );


/*! \brief      Sets the user of SipURI.
    \param[in]  uiSipUriHdl Reference to the SIP URI
    \param[in]  pcUser User value to be set
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetUser(IN uint32 uiSipUriHdl, 
			         IN char8* pcUser);


/*! \brief          Returns the value of user param 
    \param[in]   uiSipUriHdl Reference to the SIP URI
    \return       User name or Null pointer on Failure 
*/
char8*
IFX_SIP_SipUri_GetUserParam(IN uint32 uiSipUriHdl );
			

			
/*! \brief          Sets the user of SipURI user param
    \param[in]   uiSipUriHdl Reference to the SIP URI
    \param[in]   pcUserParam User param value
    \return        IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetUserParam(IN uint32 uiSipUriHdl,
                             IN char8* pcUserParam);
					    			

/*! \brief          Return whether LrParamter is set                
    \param[in]   uiSipUriHdl Reference to the SIP URI
    \return        IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_HasLrParam(IN uint32 uiSipUriHdl);			
			

/*! \brief          Sets the value of the lr parameter of this SipURI.
    \param[in]   uiSipUriHdl Reference to the SIP URI
    \return        IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetLrParam(IN uint32 uiSipUriHdl);

/*! \brief          Gets user Password of SipUri                 
    \param[in]   uiSipUriHdl Reference to the SIP URI
    \return Password or Null pointer on Failure 
*/
char8*
IFX_SIP_SipUri_GetUserPassword(IN uint32 uiSipUriHdl );
			

			
/*! \brief          Sets user Password associated with user of SipUri
    \param[in]   uiSipUriHdl Reference to the SIP URI
    \param[in]   szPasswd Password to be set
    \return        IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetUserPassword(IN uint32 uiSipUriHdl,
                                IN char8* szPasswd );
					    			
#ifdef RFC_3486

/*! \brief      Gets Compression Parameter of this SipUri
    \param[in]   uiSipUriHdl  Reference to the SIP URI
    \return        CompressionParam or Null pointer on Failure
*/
char8*
IFX_SIP_SipUri_GetCompParam (IN uint32 uiSipUriHdl );


/*! brief          Sets Compression Parameter in SipUri
    \param[in]   uiSipUriHdl  Reference to the SIP URI
    \param[in]   pcComp Compression Parameter to be set
    \return        void
*/
void
IFX_SIP_SipUri_SetCompParam (IN uint32 uiSipUriHdl,
                             IN char8* pcComp);

#endif /*RFC_3486*/

/*! \brief      Get the generic parameter in the SIP URI
    \param[in]  uiSipUriHdl SIP URI handle
    \param[in]  iLocation Location(starts from 1) of generic parameter being requested
    \param[in]  pcParamName Parameter name for which the value is 
                being fetched
    \return     returns the parameter value associated with the name
*/
char8*
IFX_SIP_SipUri_GetGenericParam(IN uint32 uiSipUriHdl,
                               int32 iLocation,
                               char8* pcParamName);
/*! \brief      Verify the presence of given parameter name
    \param[in]  uiSipUriHdl SIP URI Handle
    \param[in]  pcParamName Parameter name
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_HasGenericParam(IN uint32 uiSipUriHdl,char8* pcParamName);

/*! \brief      Sets the generic param in a SIP URI
    \param[in]  uiSipUriHdl SIP URI handle
    \param[in]  pcParamName Parameter Name
    \param[in]  pcParamValue Parameter Value. Could pass NULL if Value 
                is not present
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_SetGenericParam(IN uint32 uiSipUriHdl,
                             IN char8 *pcParamName,
                             IN char8 *pcParamValue);

/*! \brief      Gets the SIP/SIPS URI parameter in the specified location   
    \param[in]  uiSipUriHdl Handle to the SIP/SIPS URI
    \param[in]  iLocation Location(starts from 1) of the SIP URI 
                parameters
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_SipUri_GetParam(IN uint32 uiSipUriHdl,
                        IN int32 iLocation,
                        IN char8** pcName,
                        IN char8** pcValue);



/* @} */

/*##################Absolute URI API's#########################*/
/** \ingroup MSGAPI 
	\defgroup SipUri Absolute URI
    \brief This section contains the APIs for getting and setting the parameters in Absolute URI
*/
/* @{ */

/*! \brief      Returns the value of Absolute URI 
    \param[in]  uiAbsUriHdl Reference to the Absolute URI
    \return  Address or NULL pointer on failure 
*/

char8*
IFX_SIP_AbsUri_GetValue(IN uint32 uiAbsUriHdl);

/*! \brief      Set Absolute URI
    \param[in]  uiAbsUriHdl Reference to the Absolute URI
    \param[in]  szVal Absolute URI to be set
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_AbsUri_SetValue(IN uint32 uiAbsUriHdl,
                        IN char8* szVal);
        
/* @} */

/*###############Accept-Language Header#########################*/
/** \ingroup MSGAPI 
	\defgroup AcceptLang Accept-Language header
    \brief This section contains the APIs for getting and setting the parameters in the Accept-Language header
*/
/* @{ */

/*! \brief  	Gets the language value of the AcceptLanguage Header. 
    \param[in] 	uiLangHdl Reference to the Language 
    \return 	Value of the Language or Null pointer on Failure 
*/
char8* 
IFX_SIP_AcceptLang_GetLang(IN uint32 uiLangHdl); 

/*! \brief  	Gets q-value of the media-range in AcceptLanguage Header.  
    \param[in] 	uiLangHdl Reference to the Language 
    \return 	Q-Value of the Language in Language header
*/
char8* 
IFX_SIP_AcceptLang_GetQValue(IN uint32 uiLangHdl); 
 
/*! \brief  	Sets the language parameter of this AcceptLanguage Header. 
    \param[in] 	uiLangHdl Reference to the Language 
    \param[in] 	szLang Language parameter to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_AcceptLang_SetLang(IN uint32 uiLangHdl, 
                           IN char8* szLang); 
          
/*! \brief  	Sets q-value for media-range in AcceptLanguage Header.  
    \param[in] 	uiLangHdl Reference to the Language 
    \param[in] 	pcQvalue Q Value
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_AcceptLang_SetQValue(IN uint32 uiLangHdl, 
                             IN char8 *pcQvalue); 

/* @} */
/*###############Alert-Info Header#########################*/
/** \ingroup MSGAPI 
	\defgroup AlertInfo Alert-Info header
    \brief This section contains the APIs for getting and setting the parameters in the Alert-Info header
*/
/* @{ */

/*! \brief  	Returns the AlertInfo Absolute URI of this AlertInfoHeader. 
    \param[in] 	uiAlertParamHdl Reference to the Alert Param
    \return 	Reference to the Absolute URI. 
*/
uint32
IFX_SIP_AlertInfo_GetAbsUri(IN uint32 uiAlertParamHdl); 

/*! \brief  	Sets the Absolute URI of the AlertInfoHeader . 
    \param[in] 	uiAlertParamHdl Reference to the Alert Param
    \param[in] 	uiAbsUriHdl Reference of the Absolute URI to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_AlertInfo_SetAbsUri(IN uint32 uiAlertParamHdl, 
                           IN uint32 uiAbsUriHdl);

/*! \brief  	Check whether the Token is present in Alert Param.
    \param[in]  uiAlertParamHdl Reference to the Alert Param
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_AlertInfo_HasToken(IN uint32 uiAlertParamHdl,
                           IN char8* pcToken);


/*! \brief      Gets the generic param value of the Alert Param  
    \param[in]  uiAlertParamHdl Reference to the Alert Param
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_AlertInfo_GetGenericParam(IN uint32 uiAlertParamHdl,
                                  IN int32 iLocation,
                                  IN char8* pcToken);

/*! \brief      Sets the generic param value to the Alert Param
    \param[in]  uiAlertParamHdl Reference to the Alert Param
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AlertInfo_SetGenericParam(IN  uint32 uiAlertParamHdl,
                                  IN char8* pcToken,
                                  IN char8* pcValue);

/*! \brief      Gets the Alert-Info parameter in the specified location   
    \param[in]  uiAlertParamHdl Handle to the Alert-Info Header
    \param[in]  iLocation Location(starts from 1) of the Alert-Info 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_AlertInfo_GetParam(IN uint32 uiAlertParamHdl,
                           IN int32 iLocation,
                           IN char8** pcName,
                           IN char8** pcValue);

/* @} */
/*###############CSeq Header#########################*/
/** \ingroup MSGAPI 
	\defgroup CSeq CSeq header
    \brief This section contains the APIs for getting and setting the parameters in the CSEQ header
*/
/* @{ */

/*! \brief  	Gets the method of CSeqHeader 
    \param[in] 	uiCSeqHdl Reference to the CSeq Header
    \return Method or Null pointer on Failure
*/
char8* 
IFX_SIP_CSeq_GetMethod(IN uint32 uiCSeqHdl); 

/*! \brief  	Gets the sequence number of this CSeqHeader. 
    \param[in] 	uiCSeqHdl Reference to the CSeq Header
    \return 	Sequence number
*/
int32 
IFX_SIP_CSeq_GetSeqNum(IN uint32 uiCSeqHdl); 

/*! \brief  	Sets the method of CSeqHeader 
    \param[in] 	uiCSeqHdl Reference to the CSeq Header
    \param[in] 	szMethod Method to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_CSeq_SetMethod(IN uint32 uiCSeqHdl, 
                       IN char8* szMethod); 

/*! \brief  	Sets the sequence number value of the CSeqHeader.  
    \param[in] 	uiCSeqHdl Reference to the CSeq Header
    \param[in] 	iSeqNum Sequence number to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_CSeq_SetSeqNum(IN uint32 uiCSeqHdl, 
                       IN int32 iSeqNum); 
          
/* @} */
 
/*###############From Header#########################*/
/** \ingroup MSGAPI 
	\defgroup From From header
    \brief This section contains the APIs for getting and setting the parameters in the From header
    \note For APIs on Generic Params please Refer TO Header Functions
*/
/* @{ */

/*! \brief  	Gets the tag of From Header. 
    \param[in] 	uiFromHdl Reference to the From Header
    \return Tag value or Null pointer on Failure 
*/
char8* 
IFX_SIP_From_GetTag(IN uint32 uiFromHdl); 

/*! \param[in] 	uiFromHdl Reference to the From Header
    \param[in] 	szTag From Tag
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_From_SetTag(IN uint32 uiFromHdl, 
                    IN char8 *szTag);

/*! \brief  	Gets the reference to the Address type of From Header. 
    \param[in] 	uiFromHdl Reference to the From Header
    \return 	Reference to the Address Type parameter 
*/
uint32 
IFX_SIP_From_GetAddressType(IN uint32 uiFromHdl); 

/* @} */
/*###############To Header#########################*/
/** \ingroup MSGAPI 
	\defgroup To To header
    \brief This section contains the APIs for getting and setting the parameters in the To header
*/
/* @{ */

/*! \brief  	Gets the tag of To Header. 
    \param[in] 	uiToHdl Reference to the To Header
    \return Tag value or Null pointer on Failure 
*/
char8* IFX_SIP_To_GetTag(IN uint32 uiToHdl); 

/*! \brief  	Sets the tag parameter of the To Header.  
    \param[in] 	uiToHdl Reference to the To Header
    \param[in] 	szTag From Tag
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_To_SetTag(IN uint32 uiToHdl, 
                  IN char8 *szTag);

/*! \brief  	Gets the reference to the Address type of To Header. 
    \param[in] 	uiToHdl Reference to the To Header
    \return 	Reference to the Address Type parameter 
*/
uint32 
IFX_SIP_To_GetAddressType(IN uint32 uiToHdl); 

/*! \brief  	Check whether the Token is present in To/From Header.
    \param[in]  uiFromHdl Reference to the To/From Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_ToFrom_HasToken(IN uint32  uiFromHdl,
                        IN char8* pcToken);


/*! \brief      Gets the generic param value of the From/To Header,        
    \param[in]  uiFromHdl Reference to the To/From Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_ToFrom_GetGenericParam(IN uint32 uiFromHdl,
                               IN int32 iLocation,
                               IN char8* pcToken);

/*! \brief      Sets the generic param value to the To/From Header
    \param[in]  uiFromHdl Reference to the To/From Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ToFrom_SetGenericParam(IN uint32 uiFromHdl,
                        IN char8* pcToken,
                        IN char8* pcValue );

/*! \brief      Gets the To/From parameter in the specified location   
    \param[in]  uiFromHdl Handle to the To/From Header
    \param[in]  iLocation Location(starts from 1) of the To/From 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ToFrom_GetParam(IN uint32 uiFromHdl,
                        IN int32 iLocation,
                        IN char8** pcName,
                        IN char8** pcValue);



/* @} */
/*###############Max-Forwards Header#########################*/
/** \ingroup MSGAPI 
	\defgroup MaxFwd Max-Forwards header
    \brief This section contains the APIs for getting and setting the parameters in the Max-Forwards header
*/
/* @{ */

/*! \brief  	Sets the max-forwards argument of this MaxForwards Header 
            	to the supplied maxForwards value 
    \param[in] 	uiMaxFwdHdl Reference to the Max Forward value 
    \param[in] 	iMaxFwd Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_MaxFwd_SetValue(IN uint32 uiMaxFwdHdl, 
                        IN int16 iMaxFwd);

/*! \brief  	Get the max-forwards of the MaxForwards Header 
    \param[in] 	uiMaxFwdHdl Reference to the Max Forward value 
    \return 	Max-Forward value. 
*/
int16 
IFX_SIP_MaxFwd_GetValue(IN uint32 uiMaxFwdHdl);

/* @} */

/*###############Content Length Header#########################*/ 
/** \ingroup MSGAPI 
	\defgroup ContLen Content-Length header
    \brief This section contains the APIs for getting and setting the parameters in the Content-Length header
*/
/* @{ */

/*! \brief  	Sets the content length of the SIP Msg Header to the 
                newly supplied length value.  
    \param[in] 	uiContLen Reference to the length
    \param[in] 	iContLen Length to be added to the ContentLength Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ContentLength_SetContentLength(IN uint32  uiContLen, 
                                       IN int32 iContLen);

/*! \brief  	Get the content length of the SIP Msg Header  
    \param[in] 	uiContLenHdl Reference to the Content length
    \return 	int32 ContentLength
*/
int32
IFX_SIP_ContentLength_GetContentLength(IN uint32  uiContLenHdl);

/* @} */

/*###############CallId Header#########################*/ 
/** \ingroup MSGAPI 
	\defgroup CallId Call-Id header
    \brief This section contains the APIs for getting and setting the parameters in the Call-Id header
*/
/* @{ */

/*! \brief  	Sets the callid of SIP Msg Header to the newly 
	            supplied callid value.  
    \param[in] 	uiCallidHdl Reference to the Call Id
    \param[in] 	szCallId cnonce to be added to the CallId Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_CallId_SetCallId(IN uint32 uiCallidHdl,
                         IN char8* szCallId);

/*! \brief  	Get the callid of SIP Msg Header  
    \param[in] 	uiCallidHdl Reference to the Call Id
    \return Callid
*/
char8*
IFX_SIP_CallId_GetCallId(IN uint32 uiCallidHdl);

/* @} */

/*###############Via Header#########################*/
/** \ingroup MSGAPI 
	\defgroup Via Via header
    \brief This section contains the APIs for getting and setting the parameters in the Via header
*/
/* @{ */

/*! \brief  	Gets the branch paramater of the Via Param.
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return 	Branch parameter or Null pointer on Failure
*/
char8* 
IFX_SIP_Via_GetBranch(IN uint32 uiViaParmHdl); 
          
/*! \brief  	Returns the host part of this Via Param.
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return Host or Null pointer on Failure
*/
char8* 
IFX_SIP_Via_GetHost(IN uint32 uiViaParmHdl); 
          
/*! \brief  	Gets the value of the MAddr parameter of Via Param
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return  MAddr or Null pointer on Failure
*/
char8* 
IFX_SIP_Via_GetMAddr(IN uint32 uiViaParmHdl);

          
/*! \brief  	Gets the port part of this Via Param.
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return 	Port value (int32)
*/
int32 
IFX_SIP_Via_GetPort(IN uint32 uiViaParmHdl);

/*! \brief  	Gets the response port part of this Via Param.
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return 	Port value (int32)
*/
int32 
IFX_SIP_Via_GetRPort(IN uint32 uiViaParmHdl); 
         
/*! \brief  	Gets the value of the protocol used of this Via Param 
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return protocol or Null pointer on Failure
*/
char8* 
IFX_SIP_Via_GetProtocol(IN uint32 uiViaParmHdl); 
          
/*! \brief  	Gets the received paramater of the Via Param.  
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return Received parameter or Null pointer on Failure
*/
char8* 
IFX_SIP_Via_GetReceived(IN uint32 uiViaParmHdl); 
          
/*! \brief  	Gets the value of the transport parameter of the Via Param
    \param[in] 	uiViaParmHdl Reference to the Via Param 
    \return Transport param or Null pointer on Failure
*/
char8* 
IFX_SIP_Via_GetTransport(IN uint32 uiViaParmHdl); 
          
/*! \brief  	Gets the value of the TTL parameter of the Via Param
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \return 	TTL value
*/
uchar8 
IFX_SIP_Via_GetTTL(IN uint32 uiViaParmHdl); 
          
/*! \brief  	Sets the branch parameter of the Via Param to the
                newly supplied branch value.  
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \param[in] 	szBranch Branch parameter to be populated
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetBranch(IN uint32 uiViaParmHdl,
                      IN char8* szBranch); 
          
/*! \brief  	Set the host part of this Via Param to the newly 
                supplied host parameter.
    \param[in] 	uiViaParmHdl Reference to the Via Param 
    \param[in] 	szHost Host name
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetHost(IN uint32 uiViaParmHdl,
                    IN char8 *szHost); 
          
/*! \brief  	Sets the value of the maddr parameter of this Via Param. 
    \param[in] 	uiViaParmHdl Reference to the Via Param 
    \param[in] 	szMaddr Multicast address
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetMAddr(IN uint32 uiViaParmHdl,
                     IN char8* szMaddr); 
          
/*! \brief  	Set the port part of this Via Param to the newly 
                supplied port parameter.
    \param[in] 	uiViaParmHdl Reference to the Via Param 
    \param[in] 	unPort Port to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetPort(IN uint32 uiViaParmHdl,
                    IN uint16 unPort); 
          
/*! \brief  	Set the response port param in the via params.
    \param[in] 	uiViaParmHdl Reference to the Via Param 
    \param[in] 	unPort Port to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetRPort(IN uint32 uiViaParmHdl,
                     IN uint16 unPort); 

/*! \brief  	Sets the value of the protocol of this Via Param 
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \param[in] 	szProtocol Protocol
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetProtocol(IN uint32 uiViaParmHdl,
                        IN char8* szProtocol); 
          
/*! \brief  	Sets the received parameter of Via Param.
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \param[in] 	szReceived Received parameter
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetReceived(IN uint32 uiViaParmHdl,
                        IN char8* szReceived); 
          
/*! \brief  	Sets the value of the transport of this Via param
    \param[in] 	uiViaParmHdl Reference to the Via Param  
    \param[in] 	szTransport Transport parameter to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetTransport(IN uint32 uiViaParmHdl,
                         IN char8* szTransport); 
          
/*! \brief  	Sets the value of the ttl parameter of this Via Param
    \param[in] 	uiViaParmHdl Reference to the Via Param
    \param[in] 	iTtl Time-to live parameter to be set in the Via Param
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_SetTTL(IN uint32 uiViaParmHdl,
                   IN int32 iTtl); 

#ifdef RFC_3486
/*! \brief          Returns Compression Parameter OR NULL if not present
                     from this ViaParam
    \param[in]   uiViaParmHdl Reference to the Via Parm
    \return        char8*CompressionParam or Null pointer on Failure
*/
char8*
IFX_SIP_ViaParm_GetCompParam(IN uint32 uiViaParmHdl);


/*! \brief          Sets Compression Parameter in this ViaParm
    \param[in]   uiViaParmHdl Reference to the Via Parm
    \param[in]   pcComp Compression parameter to be set
    \return        void
*/

void
IFX_SIP_ViaParm_SetCompParam (IN uint32 uiViaParmHdl,
                             IN char8* pcComp);

#endif /*RFC_3486*/

/*! \brief  	Check whether the Token is present in Via Param.
    \param[in]  uiViaParmHdl Reference to the Via Param
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_Via_HasToken(IN uint32 uiViaParmHdl,
                     IN char8* pcToken);

/*! \brief      Gets the generic param value of the Via Param  
    \param[in]  uiViaParmHdl Reference to the Via Param
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_Via_GetGenericParam(IN uint32 uiViaParmHdl,
                            IN int32 iLocation,
                            IN char8* pcToken);


/*! \brief      Sets the generic param value to the Via Param
    \param[in]  uiViaParmHdl Reference to the Via Param
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Via_SetGenericParam(IN  uint32 uiViaParmHdl,
                            IN char8* pcToken,
                            IN char8* pcValue);

/*! \brief      Gets the Via parameters in the specified location   
    \param[in]  uiViaParmHdl Reference to the Via Param
    \param[in]  iLocation Location(starts from 1) of the Via 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Via_GetParam(IN uint32 uiViaParmHdl,
                     IN int32 iLocation,
                     IN char8** pcName,
                     IN char8** pcValue);

/* @} */
/*###############Priority Header#########################*/
/** \ingroup MSGAPI 
	\defgroup Priority Priority header
    \brief This section contains the APIs for getting and setting the parameters in the Priority header
*/
/* @{ */

/*! \brief  	Gets the Values of the Priority Header.
    \param[in] 	uiPriorityHdl Reference to the Priority Header
    \return Priority value or Null pointer on Failure
*/
char8* 
IFX_SIP_Priority_GetValue(IN uint32 uiPriorityHdl); 

/*! \brief  	Set priority of Priority Header. 
    \param[in] 	uiPriorityHdl Reference to the Priority Header
    \param[in] 	szValue Value to be set
    \return 	IFX_SIP_SUCCESS OR IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Priority_SetValue(IN uint32 uiPriorityHdl, 
                          IN char8* szValue); 

/* @} */
/*###############Warning Header#########################*/   
/** \ingroup MSGAPI 
	\defgroup Warning Warning header
    \brief This section contains the APIs for getting and setting the parameters in the Warning header
*/
/* @{ */
    
/*! \brief  	Gets the agent of the server that created this Warning Header. 
    \param[in] 	uiWarningValueHdl Reference to the Warning Value
    \return Agent value or Null pointer on Failure
*/
char8* 
IFX_SIP_Warning_GetAgent(IN uint32 uiWarningValueHdl);  
          
/*! \brief  	Gets the code of the Warning Header. 
    \param[in] 	uiWarningValueHdl Reference to the Warning Value
    \return 	Warning Code value
*/
int32 
IFX_SIP_Warning_GetCode(IN uint32 uiWarningValueHdl);         

/*! \brief  	Gets text of Warning Header. 
    \param[in] 	uiWarningValueHdl Reference to the Warning Value
    \return Warning Text or Null pointer on Failure
*/
char8* 
IFX_SIP_Warning_GetText(IN uint32 uiWarningValueHdl); 
           

/*! \brief  	Sets the agent value of the Warning Header to the new 
                agent value passed to the method. 
    \param[in] 	uiWarningValueHdl Reference to the Warning Value
    \param[in] 	szAgent Agent to be added
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Warning_SetAgent(IN uint32 uiWarningValueHdl,
                         IN char8* szAgent); 

/*! \brief  	Sets the code of the Warning Header
    \param[in] 	uiWarningValueHdl Reference to the Warning Value
    \param[in] 	iCode Warning code
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Warning_SetCode(IN uint32 uiWarningValueHdl,
                        IN int32 iCode); 

/*! \brief  	Sets the text of Warning Header to the newly supplied text value.  
    \param[in] 	uiWarningValueHdl Reference to the Warning Value
    \param[in] 	szText Text to be added to the Warning Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return 
IFX_SIP_Warning_SetText(IN uint32 uiWarningValueHdl,
                        IN char8 *szText); 

/* @} */
/*###############Authentication Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup Authenticate WWW-Authenticate/Proxy-Authenticate Headers
    \brief This section contains the APIs for getting and setting the parameters in the WWW-Authenticate/Proxy-Authenticate Headers
*/
/* @{ */

/*! \brief  	Gets the domain list of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return Domain parameter or Null pointer on Failure
    \note       Application using this API should free the buffer 
*/
char8*
IFX_SIP_Authentication_GetDomain(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied domain value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szDomain Domain to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
    \note sets only one domain value at a time
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetDomain(IN uint32 uiChalParamHdl,
								 IN char8* szDomain);

/*! \brief  	Gets the nonce paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return Nonce parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authentication_GetNonce(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied nonce value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szNonce nonce to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetNonce(IN uint32 uiChalParamHdl,
								IN char8* szNonce);

/*! \brief  	Gets the opaque paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return Opaque parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authentication_GetOpaque(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied opaque value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szOpaque Opaque to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetOpaque(IN uint32 uiChalParamHdl,
								 IN char8* szOpaque);

/*! \brief  	Gets the realm paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return Realm parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authentication_GetRealm(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied realm value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szRealm Realm to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetRealm(IN uint32 uiChalParamHdl,
			        IN char8* szRealm);

/*! \brief  	Gets the QopOption paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return QopOption parameter or Null pointer on Failure
    \note       Application using this API should free the buffer 
*/
char8*
IFX_SIP_Authentication_GetQopOption(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied QopOption value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szQopOption QopOption to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetQopOption(IN uint32 uiChalParamHdl,
									IN char8* szQopOption);

/*! \brief  	Gets the Algorithm paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return Algorithm parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authentication_GetAlgorithm(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied Algorithm value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szAlgorithm Algorithm to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetAlgorithm(IN uint32 uiChalParamHdl,
									IN char8* szAlgorithm);

/*! \brief  	Gets the Scheme paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return Scheme parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authentication_GetScheme(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied Scheme value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	szScheme Scheme to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetScheme(IN uint32 uiChalParamHdl,
                                 IN char8* szScheme);

/*! \brief  	Gets the Stale paramater of the Authentication Header.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \return 	Stale parameter
*/
e_IFX_SIP_Boolean
IFX_SIP_Authentication_IsStale(IN uint32 uiChalParamHdl);

/*! \brief  	Sets the text of Authentication Header to the newly supplied Stale value.  
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	eStale Stale to be added to the Authentication Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetStale(IN uint32 uiChalParamHdl, 
                                IN e_IFX_SIP_Boolean eStale);

/*! \brief  	Check whether the Token is present in Authentication Header.
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_HasToken(IN uint32  uiChalParamHdl,
                             IN char8* pcToken);

/*! \brief      Gets the authentication param of the Authentication Header   
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in]  szParamName Authentication param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns authentication Param value
*/
char8*
IFX_SIP_Authentication_GetAuthParam(IN uint32 uiChalParamHdl,
                                   IN int32 iLocation,
                                   IN char8* szParamName);

/*! \brief      Sets the authentication param value to the Authentication Header
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in]  szParamName Authentication param token
    \param[in]  szParamVal Authentication param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_SetAuthParam(IN uint32 uiChalParamHdl,
                                   IN char8* szParamName,
                                   IN char8* szParamVal);

/*! \brief      Gets the Authentication parameters in the specified location   
    \param[in] 	uiChalParamHdl Reference to the Authentication Header
    \param[in]  iLocation Location(starts from 1) of the Authorization 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Authentication_GetParam(IN uint32 uiChalParamHdl,
                                   IN int32 iLocation,
                                   IN char8** pcName,
                                   IN char8** pcValue);


/* @} */
/*###############Authorization Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup Authorize Authorization/Proxy-Authorization Headers
    \brief This section contains the APIs for getting and setting the parameters in the Authorization/Proxy-Authorization Headers
*/
/* @{ */

/*! \brief  	Gets the Algorithm paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Algorithm parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetAlgorithm(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Algorithm value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szAlgorithm Algorithm to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetAlgorithm(IN uint32 uiCredHdl,
                                   IN char8* szAlgorithm);

/*! \brief  	Gets the CNonce paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return CNonce parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetCNonce(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied CNonce value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szCNonce Algorithm to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetCNonce(IN uint32 uiCredHdl,
                                IN char8* szCNonce);

/*! \brief  	Gets the Nonce paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Nonce parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetNonce(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Nonce value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szNonce Algorithm to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetNonce(IN uint32 uiCredHdl,
                               IN char8* szNonce);

/*! \brief  	Gets the NonceCount paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return NonceCount parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetNonceCount(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied NonceCount value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szNonceCount NonceCount to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetNonceCount(IN uint32 uiCredHdl,
                                    IN char8* szNonceCount);

/*! \brief  	Gets the Qop paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Qop parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetQop(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Qop value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szQop Qop to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetQop(IN uint32 uiCredHdl,
                             IN char8* szQop);

/*! \brief  	Gets the Opaque paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Opaque parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetOpaque(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Opaque value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in]	szOpaque Qop to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetOpaque(IN uint32 uiCredHdl,
                                IN char8* szOpaque);

/*! \brief  	Gets the Realm paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Realm parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetRealm(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Realm value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szRealm Realm to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetRealm(IN uint32 uiCredHdl,
                               IN char8* szRealm);

/*! \brief  	Gets the Response paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Response parameter or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetResponse(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Response value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szResponse Response to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetResponse(IN uint32 uiCredHdl,
                                  IN char8* szResponse);

/*! \brief  	Gets the Username paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Username value or Null pointer on Failure
*/
char8*
IFX_SIP_Authorization_GetUsername(IN uint32 uiCredHdl);

/*! \brief  	Sets the text of Authorization Header to the newly supplied Username value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szUsername Username to be added to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetUsername(IN uint32 uiCredHdl,
                                  IN char8* szUsername);

/*! \brief  	Gets the Digest URI paramater of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Digest URI or NULL pointer on failure
*/
char8*
IFX_SIP_Authorization_GetUri(IN uint32 uiCredHdl);

/*! \brief  	Sets the Digest URI of the  Authorization Header to the 
                newly supplied URI value.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	pcUri Digest URI to be added 
	            to the Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetUri(IN uint32 uiCredHdl,
                             IN char8* pcUri);

/*! \brief  	Gets the Scheme of the Authorization Header.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \return Digest URI or NULL pointer on failure
*/
char8*
IFX_SIP_Authorization_GetScheme(IN uint32 uiCredHdl);

/*! \brief  	Sets the Scheme of the  Authorization Header to the 
                newly supplied Scheme.  
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	szScheme Scheme to be added to the  
	            Authorization Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetScheme(IN uint32 uiCredHdl,
                                IN char8* szScheme);

/*! \brief  	Check whether the Token is present in Authorization Header.
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_HasToken(IN uint32  uiCredHdl,
                             IN char8* pcToken);

/*! \brief      Gets the authentication param of the Authorization Header   
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in]  szParamName Authentication param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns authentication Param value
*/
char8*
IFX_SIP_Authorization_GetAuthParam(IN uint32 uiCredHdl,
                                   IN int32 iLocation,
                                   IN char8* szParamName);

/*! \brief      Sets the authentication param value to the Authorization Header
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in]  szParamName Authentication param token
    \param[in]  szParamVal Authentication param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_SetAuthParam(IN uint32 uiCredHdl,
                                   IN char8* szParamName,
                                   IN char8* szParamVal);

/*! \brief      Gets the Authorization parameters in the specified location   
    \param[in] 	uiCredHdl Reference to the Authorization Header
    \param[in]  iLocation Location(starts from 1) of the Authorization 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Authorization_GetParam(IN uint32 uiCredHdl,
                                   IN int32 iLocation,
                                   IN char8** pcName,
                                   IN char8** pcValue);


/* @} */
/*###############AcceptEncoding Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup AccEnc Accept-Encoding Header
    \brief This section contains the APIs for getting and setting the parameters in the Accept-Encoding Header
*/
/* @{ */

/*! \brief  	Gets the QValue paramater of the AcceptEncoding Header.  
    \param[in] 	uiEncodingHdl Reference to the AcceptEncoding Header
    \return 	QValue parameter
*/
char8*
IFX_SIP_AcceptEncoding_GetQValue(IN uint32 uiEncodingHdl);

/*! \brief  	Sets the QValue of AcceptEncoding Header to the newly supplied QValue.  
    \param[in] 	uiEncodingHdl Reference to the AcceptEncoding Header
    \param[in] 	pcQValue QValue to be added to the accept encoding header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AcceptEncoding_SetQValue(IN uint32 uiEncodingHdl, 
                                 IN char8 *pcQValue);

/*! \brief      Sets the  coding of the ContentEncoding Header to the
                newly supplied value.
    \param[in]  uiEncodingHdl Handle
    \param[in]  szEnc Coding to be set to the ContentLanguage Header
    \return     IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AcceptEncoding_SetCoding(IN uint32  uiEncodingHdl,
                          IN char8*  szEnc);

/*! \brief      Get the  coding of the ContentEncoding Header 
    \param[in]  uiEncodingHdl Handle
    \return  Encoding or NULL pointer on failure
*/
char8*
IFX_SIP_AcceptEncoding_GetCoding(IN uint32  uiEncodingHdl);

/* @} */

/*##################Accept Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup Accept Accept Header
    \brief This section contains the APIs for getting and setting the parameters in the Accept Header
*/
/* @{ */

/*! \brief  	Checks if content subtypes of the Accept Header is *.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \return 	IFX_SIP_TRUE OR IFX_SIP_FALSE
*/
e_IFX_SIP_Boolean
IFX_SIP_Accept_GetAllContentSubTypes(IN uint32 uiAcceptRangeHdl);

/*! \brief  	Checks if content types of the Accept Header is *.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \return 	AllContentTypes parameter
*/
e_IFX_SIP_Boolean
IFX_SIP_Accept_GetAllContentTypes(IN uint32 uiAcceptRangeHdl);

/*! \brief      Sets the AllContentTypes paramater of the Accept Header.
    \param[in]  uiAcceptRangeHdl Reference to the Accept Header
    \return     IFX_SIP_SUCCESS OR IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_Accept_SetAllContentTypes(IN uint32 uiAcceptRangeHdl);

/*! \brief  	Gets the QValue paramater of the Accept Header.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \return 	QValue parameter
*/
char8*
IFX_SIP_Accept_GetQValue(IN uint32 uiAcceptRangeHdl);

/*! \brief  	Sets the QValue of Accept Header to the newly supplied QValue.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \param[in] 	pcQValue QValue to be added to the accept encoding header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_Accept_SetQValue(IN uint32 uiAcceptRangeHdl,
                         IN char8 *pcQValue);

/*! \brief  	Gets the Media Type of the ContentType Header.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \return Media Type or Null pointer on Failure
*/
char8*
IFX_SIP_Accept_GetMType(IN uint32 uiAcceptRangeHdl);

/*! \brief  	Sets the Media Type of the Accept Header to the newly 
                supplied value.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \param[in] 	szMType Media type to be added to the ContentType Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Accept_SetMType(IN uint32 uiAcceptRangeHdl,
                          IN char8* szMType);

/*! \brief  	Gets the Media Sub Type of the Accept Header.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \return Media SubType or Null pointer on Failure
*/
char8*
IFX_SIP_Accept_GetMSubType(IN uint32 uiAcceptRangeHdl);

/*! \brief  	Sets the Media Sub Type of the Accept Header to the newly 
                supplied value.  
    \param[in] 	uiAcceptRangeHdl Reference to the Accept Header
    \param[in] 	szMSubType Media type to be added to the ContentType Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Accept_SetMSubType(IN uint32 uiAcceptRangeHdl,
                          IN char8* szMSubType);

/*! \brief  	Check whether the Token is present in Accept Range.
    \param[in]  uiAcceptRangeHdl Reference to the Accept Range
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Accept_HasToken(IN uint32 uiAcceptRangeHdl,
                        IN char8* pcToken);


/*! \brief      Gets the generic param value of the Accept Range   
    \param[in]  uiAcceptRangeHdl Reference to the Accept Range
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_Accept_GetGenericParam(IN uint32 uiAcceptRangeHdl,
                               IN int32 iLocation,
                              IN char8* pcToken);

/*! \brief      Sets the generic param value to the Accept Range
    \param[in]  uiAcceptRangeHdl Reference to the Accept Range
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Accept_SetGenericParam(IN uint32 uiAcceptRangeHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the Accept parameters in the specified location   
    \param[in]  uiAcceptRangeHdl Reference to the Accept Range
    \param[in]  iLocation Location(starts from 1) of the Accept 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Accept_GetParam(IN uint32 uiAcceptRangeHdl,
                        IN int32 iLocation,
                        IN char8** pcName,
                        IN char8** pcValue);


/* @} */

/*###############AuthenticationInfo Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup AuthInfo Authentication-Info Header
    \brief This section contains the APIs for getting and setting the parameters in the Authentication-Info Header
*/
/* @{ */

/*! \brief  	Gets the cnonce paramater of the AuthenticationInfo Header.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \return CNonce parameter or Null pointer on Failure
*/
char8*
IFX_SIP_AuthenticationInfo_GetCNonce(IN uint32 uiAuthenInfoHdl);

/*! \brief  	Sets the CNonce of AuthenticationInfo Header to the newly supplied cnonce value.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \param[in] 	szCNonce cnonce to be added to the AuthenticationInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AuthenticationInfo_SetCNonce(IN uint32 uiAuthenInfoHdl,
                                     IN char8* szCNonce);

/*! \brief  	Gets the Qop value paramater of the AuthenticationInfo Header.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \return Qop parameter or Null pointer on Failure
*/
char8*
IFX_SIP_AuthenticationInfo_GetQop(IN uint32 uiAuthenInfoHdl);

/*! \brief  	Sets the Qop of AuthenticationInfo Header to the newly supplied Qop value.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \param[in] 	szQop Qop to be added to the AuthenticationInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AuthenticationInfo_SetQop(IN uint32 uiAuthenInfoHdl,
                                  IN char8* szQop);


/*! \brief  	Gets the nextnonce paramater of the AuthenticationInfo Header.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \return NextNonce parameter or Null pointer on Failure
*/
char8*
IFX_SIP_AuthenticationInfo_GetNextNonce(IN uint32 uiAuthenInfoHdl);

/*! \brief  	Sets the nextnonce of AuthenticationInfo Header to the newly supplied nextnonce value.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \param[in] 	szNextNonce nextcnonce to be added to the AuthenticationInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AuthenticationInfo_SetNextNonce(IN uint32 uiAuthenInfoHdl,
                                        IN char8* szNextNonce);

/*! \brief  	Gets the response paramater of the AuthenticationInfo Header.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \return Response parameter or Null pointer on Failure
*/
char8*
IFX_SIP_AuthenticationInfo_GetResponse(IN uint32 uiAuthenInfoHdl);

/*! \brief  	Sets the response of AuthenticationInfo Header to the newly supplied response value.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \param[in] 	szResponse nextcnonce to be added to the AuthenticationInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AuthenticationInfo_SetResponse(IN uint32 uiAuthenInfoHdl,
                                       IN char8* szResponse);

/*! \brief  	Gets the noncecount paramater of the AuthenticationInfo Header.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \return NonceCount parameter or Null pointer on Failure
*/
char8*
IFX_SIP_AuthenticationInfo_GetNonceCount(IN uint32 uiAuthenInfoHdl);

/*! \brief  	Sets the noncecount of AuthenticationInfo Header to the newly supplied noncecount value.  
    \param[in] 	uiAuthenInfoHdl Reference to the AuthenticationInfo Header
    \param[in] 	szNonceCount noncecount to be added to the AuthenticationInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_AuthenticationInfo_SetNonceCount(IN uint32 uiAuthenInfoHdl,
                                         IN char8* szNonceCount);

/* @} */

/*###############CallInfo Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup CallInfo Call-Info Header
    \brief This section contains the APIs for getting and setting the parameters in the Call-Info Header
*/
/* @{ */

/*! \brief  	Gets the info paramater of the CallInfo Header.  
    \param[in] 	uiInfoHdl Reference to the CallInfo Header
    \return 	Reference to the Absolute URI parameter
*/
uint32
IFX_SIP_CallInfo_GetInfo(IN uint32 uiInfoHdl);

/*! \brief  	Sets the text of CallInfo Header to the newly supplied info value.  
    \param[in] 	uiInfoHdl Reference to the CallInfo Header
    \param[in] 	uiAbsUriHdl Reference of the Absolute URI to be added
	            to the CallInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_CallInfo_SetInfo(IN uint32 uiInfoHdl,
                         IN uint32 uiAbsUriHdl);

/*! \brief  	Gets the purpose paramater of the CallInfo.  
    \param[in] 	uiInfoHdl Reference to the CallInfo Header
    \return Purpose value or Null pointer on Failure
*/
char8*
IFX_SIP_CallInfo_GetPurpose(IN uint32 uiInfoHdl);

/*! \brief  	Sets the text of CallInfo Header to the newly supplied purpose value.  
    \param[in] 	uiInfoHdl Reference to the CallInfo Header
    \param[in] 	szToken Purpose to be added to the CallInfo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_CallInfo_SetPurpose(IN uint32 uiInfoHdl, 
                            IN char8* szToken);

/*! \brief  	Check whether the Token is present in SIP Info.
    \param[in]  uiInfoHdl Reference to the SIP Info
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CallInfo_HasToken(IN uint32 uiInfoHdl,
                          IN char8* pcToken);


/*! \brief      Gets the generic param value of the SIP Info  
    \param[in]  uiInfoHdl Reference to the SIP Info
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_CallInfo_GetGenericParam(IN uint32 uiInfoHdl,
                               IN int32 iLocation,
                              IN char8* pcToken);

/*! \brief      Sets the generic param value to the SIP Info
    \param[in]  uiInfoHdl Reference to the SIP Info
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CallInfo_SetGenericParam( IN  uint32 uiInfoHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the Call-Info parameters in the specified location   
    \param[in]  uiInfoHdl Reference to the Call-Info
    \param[in]  iLocation Location(starts from 1) of the Call-Info 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_CallInfo_GetParam(IN uint32 uiInfoHdl,
                          IN int32 iLocation,
                          IN char8** pcName,
                          IN char8** pcValue);

/* @} */
/*###############Content Disposition Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup ContDisp Content-Disposition Header
    \brief This section contains the APIs for getting and setting the parameters in the Content-Disposition Header
*/
/* @{ */

/*! \brief  	Gets the disposition type paramater of the ContentDisposition Header.  
    \param[in] 	uiContDispHdl Reference to the ContentDisposition Header
    \return Disposition Type or Null pointer on Failure
*/
char8*
IFX_SIP_ContentDisposition_GetDispositionType(IN uint32 uiContDispHdl);

/*! \brief  	Sets the disposition type of ContentDisposition Header to the newly 
                supplied diposition type value.  
    \param[in] 	uiContDispHdl Reference to the ContentDisposition Header
    \param[in] 	szDispExt Disposition type to be added to the ContentDisposition Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ContentDisposition_SetDispositionType(IN uint32 uiContDispHdl,
                                              IN char8* szDispExt);

/*! \brief  	Gets the handling paramater of the ContentDisposition Header.  
    \param[in] 	uiContDispHdl Reference to the ContentDisposition Header
    \return Handling value or Null pointer on Failure
*/
char8*
IFX_SIP_ContentDisposition_GetHandling(IN uint32 uiContDispHdl);

/*! \brief  	Sets the handling of ContentDisposition Header to the newly 
	            supplied purpose value.  
    \param[in] 	uiContDispHdl Reference to the ContentDisposition Header
    \param[in] 	szToken Purpose to be added to the ContentDisposition Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ContentDisposition_SetHandling(IN uint32 uiContDispHdl, 
                                       IN char8* szToken);

/*! \brief  	Check whether the Token is present in Content Disposition Header.
    \param[in]  uiContDispHdl Reference to the Content Disposition Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ContDisp_HasToken(IN uint32 uiContDispHdl,
                             IN char8* pcToken);

/*! \brief      Gets the generic param value of the Content Disposition Header  
    \param[in]  uiContDispHdl Reference to the Content Disposition Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_ContDisp_GetGenericParam(IN uint32 uiContDispHdl,
                                 IN int32 iLocation,
                                 IN char8* pcToken);

/*! \brief      Sets the generic param value to the Content Disposition Header
    \param[in]  uiContDispHdl Reference to the Content Disposition Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ContDisp_SetGenericParam(IN  uint32 uiContDispHdl,
                                 IN char8* pcToken,
                                 IN char8* pcValue);

/*! \brief      Gets the Content-Disposition param in the specified location   
    \param[in]  uiContDispHdl Reference to the Content Disposition Header
    \param[in]  iLocation Location(starts from 1) of the Content 
                disposition parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ContDisp_GetParam(IN uint32 uiContDispHdl,
                          IN int32 iLocation,
                          IN char8** pcName,
                          IN char8** pcValue);


/* @} */
/*###############Content Language Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup ContLang Content-Language Header
    \brief This section contains the APIs for getting and setting the parameters in the Content-Language Header
*/
/* @{ */

/*! \brief  	Get the  language of theContentLanguage Header  
    \param[in] 	uiContLangHdl Reference to the ContentLanguage 
    \return Language or NULL pointer on failure
*/
char8*
IFX_SIP_ContLang_GetContentLanguage(IN uint32  uiContLangHdl); 


/*! \brief  	Sets the  language ContentLanguage Header to the 
                newly supplied language value.  
    \param[in] 	uiContLangHdl Reference to the ContentLanguage 
    \param[in] 	szLangTag language type to be added to the ContentLanguage Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ContLang_SetContentLanguage(IN uint32  uiContLangHdl, 
                                    IN char8*  szLangTag);

/* @} */
/*######################## EXPIRES ##########################*/
 /** \ingroup MSGAPI 
	\defgroup Expires Expires Header
    \brief This section contains the APIs for getting and setting the parameters in the Expires Header
*/
/* @{ */

/*! \brief  	Sets the expire value of this Expires Header 
            	to the supplied value 
    \param[in] 	uiExpHdl Reference to the Expires Header 
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
uint32
IFX_SIP_Expires_GetValue(IN uint32 uiExpHdl);
                        


/*! \brief  	Sets the expire value of this Expires Header 
            	to the supplied value 
    \param[in] 	uiExpHdl Reference to the Expires Header 
    \param[in] 	uiExpires Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_Expires_SetValue(IN uint32 uiExpHdl, 
                        IN uint32 uiExpires);

/* @} */

/*######################## MIN EXPIRES ##########################*/
 /** \ingroup MSGAPI 
	\defgroup MinExpires Min-Expires Header
    \brief This section contains the APIs for getting and setting the parameters in the Min-Expires Header
*/
/* @{ */

/*! \brief  	Sets the expire value of this MinExpires Header 
            	to the supplied value 
    \param[in] 	uiMinExpHdl Reference to the MinExpires Header 
    \param[in] 	uiMinExpires Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_MinExpires_SetValue(IN uint32 uiMinExpHdl, 
                        IN uint32 uiMinExpires);

/*! \brief  	Get the expire value of this MinExpires Header 
    \param[in] 	uiMinExpHdl Reference to the MinExpires Header 
    \return 	Value
*/
int32 
IFX_SIP_MinExpires_GetValue(IN uint32 uiMinExpHdl);

/* @} */

/*######################## ALLOW EVENTS ##########################*/
 /** \ingroup MSGAPI 
	\defgroup AllowEvents Allow-Events Header
    \brief This section contains the APIs for getting and setting the parameters in the Allow-Events Header
*/
/* @{ */

/*! \brief  	Get the package of this AllowEvents Header 
    \param[in] 	uiAllowEvtHdl Reference to the AllowEvents Header 
    \return 	Event package Name.
    \note User has to free the returned buffer 
*/
char8* 
IFX_SIP_AllowEvents_GetPackage(IN uint32 uiAllowEvtHdl);


/*! \brief  	Sets the package of this AllowEvents Header 
            	to the supplied value 
    \param[in] 	uiAllowEvtHdl Reference to the AllowEvents Header 
    \param[in] 	acEventPackage Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return 
IFX_SIP_AllowEvents_SetPackage(IN uint32 uiAllowEvtHdl, 
                        IN char8* acEventPackage);

/* @} */

/*#################### ORGANIZATION ##############################*/
 /** \ingroup MSGAPI 
	\defgroup Organization Organization Header
    \brief This section contains the APIs for getting and setting the parameters in the Organization Header
*/
/* @{ */

/*! \brief  	Sets the value of the Organization Header 
            	to the supplied value 
    \param[in] 	uiOrgHdl Reference to the Organization Header 
    \param[in] 	pcValue Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/

e_IFX_SIP_Return
IFX_SIP_Organization_SetValue (IN uint32 uiOrgHdl,
                      IN char8 *pcValue );

/*! \brief  	Get the value of the Organization Header 
    \param[in] 	uiOrgHdl Reference to the Organization Header 
    \return Value or NULL pointer on failure. 
*/

char8*
IFX_SIP_Organization_GetValue (IN uint32 uiOrgHdl);

/* @} */
/*#################### MIME ##############################*/
 /** \ingroup MSGAPI 
	\defgroup Mime MIME Header
    \brief This section contains the APIs for getting and setting the parameters in the MIME Header
*/
/* @{ */

/*! \brief  	Sets the value of the Mime Header 
            	to the supplied value 
    \param[in] 	uiMimeHdl Reference to the Mime Header 
    \param[in] 	pcValue Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/

e_IFX_SIP_Return
IFX_SIP_Mime_SetValue (IN uint32 uiMimeHdl,
                      IN char8 *pcValue );

/*! \brief  	Get the value of the Mime Header 
    \param[in] 	uiMimeHdl Reference to the Mime Header 
    \return Value or NULL pointer on failure. 
*/

char8*
IFX_SIP_Mime_GetValue (IN uint32 uiMimeHdl);

/* @} */

/*####################Conetnt Encoding#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup ContEnc Content-Encoding Header
    \brief This section contains the APIs for getting and setting the parameters in the Content-Encoding Header
*/
/* @{ */

/*! \brief  	Sets the value of the ContentEncoding Header 
            	to the supplied value 
    \param[in] 	uiContEncHdl Reference to the ContentEncoding Header 
    \param[in] 	pcValue Value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SIP_Return
IFX_SIP_ContentEncoding_SetValue (IN uint32 uiContEncHdl,
                      IN char8 *pcValue );

/*! \brief  	Get the value of the ContentEncoding Header 
    \param[in] 	uiContEncHdl Reference to the ContentEncoding Header 
    \return Value or NULL pointer on failure. 
*/
char8*
IFX_SIP_ContentEncoding_GetValue (IN uint32 uiContEncHdl);

/* @} */


/*####################In Reply To Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup InReplyTo In-Reply-To Header
    \brief This section contains the APIs for getting and setting the parameters in the In-Reply-To Header
*/
/* @{ */

/*! \brief  	Sets the callid to the newly supplied value.  
    \param[in] 	uiCallIdHdl Reference to the CallId 
    \param[in] 	szCallId Call Id be added to the InReplyTo Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_InReplyTo_SetCallId(IN uint32 uiCallIdHdl, 
                            IN char8* szCallId);

/*! \brief  	Get the callid of the InReplyTo header.  
    \param[in] 	uiCallIdHdl Reference to the CallId 
    \return CallId or NULL pointer on failure
*/
char8*
IFX_SIP_InReplyTo_GetCallId(IN uint32 uiCallIdHdl);

/* @} */

/*####################Reply To Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup ReplyTo Reply-To Header
    \brief This section contains the APIs for getting and setting the parameters in the Reply-To Header
    \note To get the Address Type use IFX_SIP_ReferTo_GetAddressType API
*/
/* @{ */

/*! \brief  	Check whether the Token is present in ReplyTo Header.
    \param[in]  uiReplyToHdl Reference to the ReplyTo Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ReplyTo_HasToken(IN uint32 uiReplyToHdl,
                             IN char8* pcToken);


/*! \brief      Gets the generic param value of the ReplyTo Header  
    \param[in]  uiReplyToHdl Reference to the ReplyTo Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_ReplyTo_GetGenericParam(IN uint32 uiReplyToHdl,
                                 IN int32 iLocation,
                                   IN char8* pcToken);

/*! \brief      Sets the generic param value to the ReplyTo Header
    \param[in]  uiReplyToHdl Reference to the ReplyTo Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ReplyTo_SetGenericParam(IN  uint32 uiReplyToHdl,
                                 IN char8* pcToken,
                                 IN char8* pcValue );

/*! \brief      Gets the ReplyTo param in the specified location   
    \param[in]  uiReplyToHdl Reference to the ReplyTo Header
    \param[in]  iLocation Location(starts from 1) of the ReplyTo 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ReplyTo_GetParam(IN uint32 uiReplyToHdl,
                          IN int32 iLocation,
                          IN char8** pcName,
                          IN char8** pcValue);


/* @} */

/*####################Refer To Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup ReferTo Refer-To/Refer-By Header
    \brief This section contains the APIs for getting and setting the parameters in the Refer-To/Refer-By Header
    \note To get the generic parameters use IFX_SIP_ReplyTo_* API's
*/
/* @{ */

/*! \brief      Gets the reference to the Address type of ReferTo Header.
    \param[in]  uiReferToHdl Reference to the ReferTo Header
    \return     Reference to the Address Type parameter
*/
uint32
IFX_SIP_ReferTo_GetAddressType(IN uint32 uiReferToHdl);
/* @} */

/*####################Allow Header##########################*/
 /** \ingroup MSGAPI 
	\defgroup Allow Allow Header
    \brief This section contains the APIs for getting and setting the parameters in the Allow Header
*/
/* @{ */

/*! \brief  	Sets the method of Allow Header to the newly supplied method.  
    \param[in] 	uiMethodHdl Reference to the SIP Method
    \param[in] 	szmethod method to be set in Allow Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Allow_SetMethod(IN uint32 uiMethodHdl,
                        IN char8* szmethod);

/*! \brief  	Get the method of Allow Header   
    \param[in] 	uiMethodHdl Reference to the SIP Method
    \return Method or NULL pointer on failure
*/
char8*
IFX_SIP_Allow_GetMethod(IN uint32 uiMethodHdl);

/* @} */

/*####################Replaces Header##########################*/
 /** \ingroup MSGAPI 
	\defgroup Replaces Replaces Header
    \brief This section contains the APIs for getting and setting the parameters in the Replaces Header
*/
/* @{ */

/*! \brief  	Get the CallId of this Replaces Header 
    \param[in] 	uiReplacesHdl Reference to the Replaces Header 
    \return CallId or NULL pointer on failure
*/
char8* 
IFX_SIP_Replaces_GetCallId(IN uint32 uiReplacesHdl);


/*! \brief  	Sets the CallId of Replaces Header to the newly supplied value.  
    \param[in] 	uiReplacesHdl Reference to the Replaces Header
    \param[in] 	szCallId Call Id be set in Replaces Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Replaces_SetCallId(IN uint32 uiReplacesHdl,
                        IN char8* szCallId);

/*! \brief  	Get the TagParam of this Replaces Header 
    \param[in] 	uiReplacesHdl Reference to the Replaces Header 
    \param[in]  Tag TagParam to be fetched from the Replaces Header
    \return TagParam or NULL pointer on failure
*/
char8* 
IFX_SIP_Replaces_GetTagParam(IN uint32 uiReplacesHdl,
                             IN char8* Tag);


/*! \brief  	Sets the TagParam of Replaces Header to the newly supplied value.  
    \param[in] 	uiReplacesHdl Reference to the Replaces Header
    \param[in] 	szTagParam TagParam to be set in Replaces Header
    \param[in] 	Tag Tag to be set in Replaces Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Replaces_SetTagParam(IN uint32 uiReplacesHdl,
                             IN char8* szTagParam,
                             IN char8* Tag);

/*! \brief  	Check whether the Token is present in Replaces Header.
    \param[in]  uiReplacesHdl Reference to the Replaces Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Replaces_HasToken(IN uint32 uiReplacesHdl,
                             IN char8* pcToken);


/*! \brief      Gets the generic param value of the Replaces Header  
    \param[in]  uiReplacesHdl Reference to the Replaces Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_Replaces_GetGenericParam(IN uint32 uiReplacesHdl,
                                 IN int32 iLocation,
                                   IN char8* pcToken);

/*! \brief      Sets the generic param value to the Replaces Header
    \param[in]  uiReplacesHdl Reference to the Replaces Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Replaces_SetGenericParam(IN  uint32 uiReplacesHdl,
                                 IN char8* pcToken,
                                 IN char8* pcValue );

/*! \brief      Gets the Replaces param in the specified location   
    \param[in]  uiReplacesHdl Reference to the Replaces Header
    \param[in]  iLocation Location(starts from 1) of the Replaces 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Replaces_GetParam(IN uint32 uiReplacesHdl,
                          IN int32 iLocation,
                          IN char8** pcName,
                          IN char8** pcValue);

/* @} */

/*###############Error Info Header#########################*/ 
 /** \ingroup MSGAPI 
	\defgroup ErrInfo Error-Info Header
    \brief This section contains the APIs for getting and setting the parameters in the Error-Info Header
*/
/* @{ */

/*! \brief  	Gets the error info paramater of the ErrorUri.  
    \param[in] 	uiErrorUriHdl Reference to the ErrorUri
    \return 	Reference to the Absolute URI 
*/
uint32
IFX_SIP_ErrorInfo_GetAbsUri(IN uint32 uiErrorUriHdl);

/*! \brief  	Sets the uri of ErrorInfo Header to the newly supplied uri.  
    \param[in] 	uiErrorUriHdl Reference to the ErrorUri
    \param[in] 	uiAbsUriHdl Reference to the Absolute URI to be 
                set in ErrorUri Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ErrorInfo_SetAbsUri(IN uint32 uiErrorUriHdl, 
                            IN uint32 uiAbsUriHdl);


/*! \brief  	Gets the Error message paramater of the ErrorUri  
    \param[in] 	uiErrorUriHdl Reference to the ErrorUri
    \return Error message or Null pointer on Failure 
*/
char8*
IFX_SIP_ErrorInfo_GetErrorMsg(IN uint32 uiErrorUriHdl);

/*! \brief  	Sets the error msg of ErrorInfo Header to the newly 
                supplied error message.  
    \param[in] 	uiErrorUriHdl Reference to the ErrorUri Header
    \param[in] 	szToken Value to be set to the ErrorUri Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ErrorInfo_SetErrorMsg(IN uint32 uiErrorUriHdl, 
                              IN char8* szToken);

/*! \brief  	Check whether the Token is present in Error URI.
    \param[in]  uiErrorUriHdl Reference to the Error URI
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ErrorInfo_HasToken(IN uint32 uiErrorUriHdl,
                           IN char8* pcToken);


/*! \brief      Gets the generic param value of the Error URI  
    \param[in]  uiErrorUriHdl Reference to the Error URI
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_ErrorInfo_GetGenericParam(IN uint32 uiErrorUriHdl,
                                  IN int32 iLocation,
                                  IN char8* pcToken);

/*! \brief      Sets the generic param value to the Error URI 
    \param[in]  uiErrorUriHdl Reference to the Error URI
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ErrorInfo_SetGenericParam(IN  uint32 uiErrorUriHdl,
                                  IN char8* pcToken,
                                  IN char8* pcValue);

/*! \brief      Gets the Error-Info param in the specified location   
    \param[in]  uiErrorUriHdl Reference to the Error URI
    \param[in]  iLocation Location(starts from 1) of the Error-URI 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ErrorInfo_GetParam(IN uint32 uiErrorUriHdl,
                           IN int32 iLocation,
                           IN char8** pcName,
                           IN char8** pcValue);


/* @} */
/*##################RetryAfter Header#########################*/
 /** \ingroup MSGAPI 
	\defgroup RetryAfter Retry-After Header
    \brief This section contains the APIs for getting and setting the parameters in the Retry-After Header
*/
/* @{ */

/*! \brief 	Gets the retry after value of the RetryAfterHeader
    \param[in] 	uiRetryAfterHdl Pointer to RetryAfter Header
    \return 	Relative time value
*/
int32
IFX_SIP_RetryAfter_GetRetryAfter(IN uint32 uiRetryAfterHdl);

/*! \brief 	Sets the retry after value of the RetryAfter Header
    \param[in] 	uiRetryAfterHdl Pointer to RetryAfter Header
    \param[in] 	iTime Relative time value    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RetryAfter_SetRetryAfter(IN uint32 uiRetryAfterHdl,
                           IN int32 iTime);

/*! \brief 		Gets the comment of RetryAfterHeader
    \param[in] 	uiRetryAfterHdl Pointer to RetryAfter Header
    \return 	Comment string
*/
char8*
IFX_SIP_RetryAfter_GetComment(IN uint32 uiRetryAfterHdl);



/*! \brief 		Sets the comment value of the RetryAfter Header
    \param[in] 	uiRetryAfterHdl Pointer to RetryAfter Header
    \param[in] 	szComment Comment string    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RetryAfter_SetComment(IN uint32 uiRetryAfterHdl,
                              IN char8 *szComment);

/*! \brief 		Gets the duration value of the RetryAfter Header
    \param[in] 	uiRetryAfterHdl Pointer to RetryAfter Header
    \return 	Relative time value
*/
int32
IFX_SIP_RetryAfter_GetDuration(IN uint32 uiRetryAfterHdl);



/*! \brief 		Sets the duration value of the RetryAfter Header
    \param[in] 	uiRetryAfterHdl Pointer to RetryAfter Header
    \param[in] 	iDuration Relative time value    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RetryAfter_SetDuration(IN uint32 uiRetryAfterHdl,
                           IN int32 iDuration);

/*! \brief  	Check whether the Token is present in RetryAfter Header.
    \param[in]  uiRetryAfterHdl Reference to the RetryAfter Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RetryAfter_HasToken(IN uint32 uiRetryAfterHdl,
                            IN char8* pcToken);


/*! \brief      Gets the generic param value of the RetryAfter Header  
    \param[in]  uiRetryAfterHdl Reference to the RetryAfter Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_RetryAfter_GetGenericParam(IN uint32 uiRetryAfterHdl,
                                   IN int32 iLocation,
                                   IN char8* pcToken);

/*! \brief      Sets the generic param value to the RetryAfter Header
    \param[in]  uiRetryAfterHdl Reference to the RetryAfter Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RetryAfter_SetGenericParam( IN  uint32 uiRetryAfterHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the Retry After param in the specified location   
    \param[in]  uiRetryAfterHdl Reference to the RetryAfter Header
    \param[in]  iLocation Location(starts from 1) of the Retry After 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_RetryAfter_GetParam(IN uint32 uiRetryAfterHdl,
                            IN int32 iLocation,
                            IN char8** pcName,
                            IN char8** pcValue);

/* @} */

/*##################Server Header#########################*/
 /** \ingroup MSGAPI 
	\defgroup Server Server Header
    \brief This section contains the APIs for getting and setting the parameters in the Server Header
*/
/* @{ */

/*! \brief 		Gets product values of the Server Header
    \param[in] 	uiServerHdl Reference to the Server Header
    \return 	Product string 
*/
char8*
IFX_SIP_Server_GetProduct(IN uint32 uiServerHdl);



/*! \brief 		Sets the product values of the Server Header
    \param[in] 	uiServerHdl Reference to the Server Header
    \param[in]	szProduct String    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Server_SetProduct(IN uint32 uiServerHdl,
                           IN char8 *szProduct);

/* @} */

/*##################TimeStamp Header#########################*/
 /** \ingroup MSGAPI 
	\defgroup TimeStamp Time-Stamp Header
    \brief This section contains the APIs for getting and setting the parameters in the Time-Stamp Header
*/
/* @{ */

/*! \brief 		Gets the timestamp value of this TimeStampHeader
    \param[in] 	uiTimeStampHdl Reference to the TimeStamp Header
    \return 	Timestamp value 
*/
char8*
IFX_SIP_TimeStamp_GetTimeStamp(IN uint32 uiTimeStampHdl);



/*! \brief 		Sets the timestamp value of this TimeStamp Header 
	  			to the new timestamp value passed to this method
    \param[in] 	uiTimeStampHdl Reference to the TimeStamp Header
    \param[in] 	pcTimeStamp Timestamp value    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_TimeStamp_SetTimeStamp(IN uint32 uiTimeStampHdl,
                                IN char8* pcTimeStamp);


/*! \brief 		Gets delay of TimeStamp Header
    \param[in] 	uiTimeStampHdl Reference to the TimeStamp Header
    \return 	Delay value  
*/
char8*
IFX_SIP_TimeStamp_GetDelay(IN uint32 uiTimeStampHdl);



/*! \brief 		Sets the new Delay value of the Timestamp Header 
	  			to the delay parameter passed to this method 
    \param[in] 	uiTimeStampHdl Reference to the TimeStamp Header
    \param[in] 	pcDelay Delay value    
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_TimeStamp_SetDelay(IN uint32 uiTimeStampHdl,
                           IN char8 *pcDelay);

/* @} */
/*##################Route Header#########################*/
 /** \ingroup MSGAPI 
	\defgroup Route Route/Record-Route/Service-Route/path Headers
    \brief This section contains the APIs for getting and setting the parameters in the Route/Record-Route/Service-Route/path Headers
*/
/* @{ */

/*! \brief 	Gets the rrparams of the Route Param

    Can be used for Record-Route, Route, Service-Route, and path headers
    \param[in] 	uiRouteParamHdl Reference to the Route param
    \param[in]  szToken  Token for which value has to be fetched  
    \param[out] szValue  Value associated with the token  
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE if token is not present 
*/
e_IFX_SIP_Return
IFX_SIP_Route_GetValue(IN uint32 uiRouteParamHdl,
                       IN char8* szToken,
                       OUT char8* szValue);


/*! \brief	Sets the rrparams of the Route Param

    Can be used for Record-Route, Route, Service-Route, and path headers
    \param[in]  uiRouteParamHdl Reference to the Route param
    \param[in]  szToken  Token for which value has to be set
    \param[in] 	szValue  Value that has to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Route_SetValue(IN uint32 uiRouteParamHdl,
                       IN char8* szToken,
                       IN char8* szValue);

/*! \brief	Gets the NamedAddr structure of the Route Param

    Can be used for Record-Route, Route, Service-Route, and path headers
    \param[in] 	uiRouteParamHdl Reference to the Route param
    \return 	Reference to the Name Addr of the given Route Header  
*/
uint32
IFX_SIP_Route_GetNameAddr(IN uint32 uiRouteParamHdl);



/*! \brief	Sets the NamedAddr structure of the Route Param

    Can be used for Record-Route, Route, Service-Route, and path headers
    \param[in]  uiRouteParamHdl Reference to the Route param
    \param[in]  uiNameAddrHdl Reference to the Named Address  
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Route_SetNameAddr(IN uint32 uiRouteParamHdl,
                          IN uint32 uiNameAddrHdl);

/*! \brief  	Check whether the Token is present in Route Param
    \param[in]  uiRouteParamHdl Reference to the Route param
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Route_HasToken(IN uint32 uiRouteParamHdl,
                      IN char8* pcToken);

/*! \brief  	Gets the GenericParam of the Route Param.
    \param[in]  uiRouteParamHdl Reference to the Route param
	\param[in] iLocation Location
    \param[in] 	pcToken Token 
    \return  GenericParam value or Null pointer on Failure	
*/
char8*
IFX_SIP_Route_GetGenericParam(IN uint32 uiRouteParamHdl,
                              IN int32 iLocation,
                              IN char8* pcToken);

/*! \brief      Sets the generic param value to the Route Param. 
    \param[in]  uiRouteParamHdl Reference to the Route param
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Route_SetGenericParam( IN uint32 uiRouteParamHdl,
                               IN char8* pcToken,
                               IN char8* pcValue );

/*! \brief      Gets the Route param in the specified location   
    \param[in]  uiRouteParamHdl Reference to the Route param
    \param[in]  iLocation Location(starts from 1) of the Route
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_Route_GetParam(IN uint32 uiRouteParamHdl,
                       IN int32 iLocation,
                       IN char8** pcName,
                       IN char8** pcValue);


/* @} */
/*######################### Extension Header ######################*/
 /** \ingroup MSGAPI 
	\defgroup Extension Extension Headers
    \brief This section contains the APIs for getting and setting the parameters in the Extension Headers
*/
/* @{ */

/*! \brief      Sets the value of the extension header
    \param[in]  uiHdrHdl header handle
    \param[in]  pszHdrValue Header value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Extension_SetHdrValue(IN  uint32 uiHdrHdl,
                              IN  char8 *pszHdrValue);

/*! \brief      Gets the header value of the SIP extension header
    \param[in]  uiHdrHdl Handle to the extension header
    \return     Returns the header value
*/
char8*
IFX_SIP_Extension_GetHdrValue(IN  uint32 uiHdrHdl);

/* @} */
/*######################### Content Type ######################*/
 /** \ingroup MSGAPI 
	\defgroup ContType Content-Type Header
    \brief This section contains the APIs for getting and setting the parameters in the Content-Type Header
*/
/* @{ */

/*! \brief  	Gets the Media Type of the ContentType Header.  
    \param[in] 	uiContTypeHdl Reference to the ContentType Header
    \return Disposition Type or Null pointer on Failure
*/
char8*
IFX_SIP_ContType_GetMType(IN uint32 uiContTypeHdl);

/*! \brief  	Sets the Media Type of the ContentType Header to the newly 
                supplied value.  
    \param[in] 	uiContTypeHdl Reference to the ContentType Header
    \param[in] 	szMType Media type to be added to the ContentType Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ContType_SetMType(IN uint32 uiContTypeHdl,
                          IN char8* szMType);

/*! \brief  	Gets the Media Sub Type of the ContentType Header.  
    \param[in] 	uiContTypeHdl Reference to the ContentType Header
    \return Disposition Type or Null pointer on Failure
*/
char8*
IFX_SIP_ContType_GetMSubType(IN uint32 uiContTypeHdl);

/*! \brief  	Sets the Media Sub Type of the ContentType Header to the newly 
                supplied value.  
    \param[in] 	uiContTypeHdl Reference to the ContentType Header
    \param[in] 	szMSubType Media type to be added to the ContentType Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ContType_SetMSubType(IN uint32 uiContTypeHdl,
                          IN char8* szMSubType);

/*! \brief  	Check whether the Token is present in Content Type Header.
    \param[in]  uiContTypeHdl Reference to the Content Type Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ContType_HasToken(IN uint32 uiContTypeHdl,
                             IN char8* pcToken);

/*! \brief      Gets the generic param value of the Content Type Header  
    \param[in]  uiContTypeHdl Reference to the Content Type Header
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_ContType_GetGenericParam(IN uint32 uiContTypeHdl,
                                  IN int32 iLocation,
                                   IN char8* pcToken);

/*! \brief      Sets the generic param value to the Content Type Header
    \param[in]  uiContTypeHdl Reference to the Content Type Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ContType_SetGenericParam( IN  uint32 uiContTypeHdl,
                              IN char8* pcToken,
                              IN char8* pcValue );

/*! \brief      Gets the Content Type param in the specified location   
    \param[in]  uiContTypeHdl Reference to the Content Type Header
    \param[in]  iLocation Location(starts from 1) of the Content Type 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ContType_GetParam(IN uint32 uiContTypeHdl,
                          IN int32 iLocation,
                          IN char8** pcName,
                          IN char8** pcValue);


/* @} */

/*######################### Subject ################## */
 /** \ingroup MSGAPI 
	\defgroup Subject Subject Header
    \brief This section contains the APIs for getting and setting the parameters in the Subject Header
*/
/* @{ */

/*! \brief  	Sets the value of the Subject Header to the newly 
                supplied value.  
    \param[in] 	uiSubHdl Reference to the Subject Header
    \param[in] 	szVal Value to be added to the Subject Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_Subject_SetValue(IN uint32 uiSubHdl,
                        IN char8* szVal);

/*! \brief  	Get the value of the Subject Header  
    \param[in] 	uiSubHdl Reference to the Subject Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
char8*
IFX_SIP_Subject_GetValue(IN uint32  uiSubHdl);

/* @} */

#ifdef RFC_4028
/*######################### Session Expires ################## */
 /** \ingroup MSGAPI 
	\defgroup SessExp Session-Expires Header
    \brief This section contains the APIs for getting and setting the parameters in the Session-Expires Header
*/
/* @{ */

/*! \brief  	Sets the time of the Session Expires Header to the newly 
                supplied value.  
    \param[in] 	uiExpHdl Reference to the Session-Expires Header
    \param[in] 	uiSE Time to be added to the Session-Expires Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_SE_SetTime(IN uint32 uiExpHdl,
                        IN uint32 uiSE);

/*! \brief  	Gets the Time of the Session Expires Header.  
    \param[in] 	uiExpHdl Reference to the Session Expires Header
    \return     time in delta seconds	
*/
int32
IFX_SIP_SE_GetTime(IN uint32  uiExpHdl);

/*! \brief  	Gets the Refresher parameter.  
    \param[in] 	uiExpHdl Reference to the Session Expires Header
    \return     Uac/Uas	
*/
int32
IFX_SIP_SE_GetRefresherParam(IN uint32  uiExpHdl);

/*! \brief  	Sets the Refresher parameter.  
    \param[in] 	uiExpHdl Reference to the Session Expires Header
    \param[in] 	eRefresher Refresher type
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SE_SetRefresherParam(IN uint32  uiExpHdl,
                             IN e_IFX_SIP_RefresherType eRefresher);

/*! \brief  	Check whether the Token is present in SE Param.
    \param[in]  uiExpHdl Reference to the SE Param
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SE_HasToken(IN uint32 uiExpHdl,
                    IN char8* pcToken);

/*! \brief      Gets the generic param value of the SE Param   
    \param[in]  uiExpHdl Reference to the SE Handle
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_SE_GetGenericParam(IN uint32 uiExpHdl,
                           IN int32 iLocation,
                           IN char8* pcToken);

/*! \brief      Sets the generic param value to the SE Param
    \param[in]  uiExpHdl Reference to the SE Param
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SE_SetGenericParam(IN uint32 uiExpHdl,
                           IN char8* pcToken,
                           IN char8* pcValue);

/*! \brief      Gets the SE Parameter in the specified location   
    \param[in]  uiExpHdl Reference to the SE header
    \param[in]  iLocation Location(starts from 1) of the SE 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_SE_GetParam(IN uint32 uiExpHdl,
                         IN int32 iLocation,
                         IN char8** pcName,
                         IN char8** pcValue);


/* @} */
/*######################### MIN SE ################## */
 /** \ingroup MSGAPI 
	\defgroup MinSe Min-SE Header
    \brief This section contains the APIs for getting and setting the parameters in the Min-SE Header
*/
/* @{ */

/*! \brief  	Gets the Time of the Min SE Header.  
    \param[in] 	uiMinExpHdl Reference to the Min SE Header
    \return     time in delta seconds	
*/
int32
IFX_SIP_MIN_SE_GetTime(IN uint32  uiMinExpHdl);

/*! \brief  	Sets the time of the Min SE Header to the newly 
                supplied value.  
    \param[in] 	uiMinExpHdl Reference to the Min SE Header
    \param[in] 	uiMinSE Time to be added to the Min SE Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_MIN_SE_SetTime(IN uint32 uiMinExpHdl,
                        IN uint32 uiMinSE);

/*! \brief  	Check whether the Token is present in Min Session Expire Param.
    \param[in]  uiMinSeParamHdl Reference to the Min Session Expire Param
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_MIN_SE_HasToken(IN uint32 uiMinSeParamHdl,
                             IN char8* pcToken);

/*! \brief      Gets the generic param value of the Min Session Expire Param  
    \param[in]  uiMinSeParamHdl Reference to the Min Session Expire Param
    \param[in]  pcToken Generic param token
    \param[in]  iLocation Location(starts from 1) of 
                the generic param token
    \return     Returns generic Param value
*/
char8*
IFX_SIP_MIN_SE_GetGenericParam(IN uint32 uiMinSeParamHdl,
                               IN int32 iLocation,
                               IN char8* pcToken);

/*! \brief      Sets the generic param value to the Min Session Expire Param
    \param[in]  uiMinSeParamHdl Reference to the Min Session Expire Param
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_MIN_SE_SetGenericParam( IN  uint32 uiMinSeParamHdl,
                                IN char8* pcToken,
                                IN char8* pcValue );

/*! \brief      Gets the MIN-SE param in the specified location   
    \param[in]  uiMinSeParamHdl Reference to the Min Session Expire Param
    \param[in]  iLocation Location(starts from 1) of the Min-SE 
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_MIN_SE_GetParam(IN uint32 uiMinSeParamHdl,
                        IN int32 iLocation,
                        IN char8** pcName,
                        IN char8** pcValue);


/* @} */
#endif /*RFC_4028 */

#ifdef RFC_3903
 /** \ingroup MSGAPI 
	\defgroup Etag Entity-Tag Header
    \brief This section contains the APIs for getting and setting the parameters in the Entity-Tag Header
*/
/* @{ */

/*! \brief  	Gets the value of the ETAG Header.  
    \param[in] 	uiEtagHdl Reference to the ETAG Header
    \return  Value or NULL pointer on failure
*/
char8*
IFX_SIP_ETAG_GetValue(IN uint32  uiEtagHdl);

/*! \brief  	Sets the value of the ETAG Header to the newly 
                supplied value.  
    \param[in] 	uiEtagHdl Reference to the ETAG Header
    \param[in] 	szVal Value to be added to the ETAG Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_ETAG_SetValue(IN uint32 uiEtagHdl,
                        IN char8* szVal);

/* @} */

 /** \ingroup MSGAPI 
	\defgroup IfMatch If-Match Header
    \brief This section contains the APIs for getting and setting the parameters in the If-match Header
*/
/* @{ */

/*! \brief  	Gets the value of the IFMATCH Header.  
    \param[in] 	uiIfMatchHdl Reference to the IFMATCH Header
    \return  Value or NULL pointer on failure
*/

char8*
IFX_SIP_IFMATCH_GetValue(IN uint32  uiIfMatchHdl);

/*! \brief  	Sets the value of the IFMATCH Header to the newly 
                supplied value.  
    \param[in] 	uiIfMatchHdl Reference to the IFMATCH Header
    \param[in] 	szVal Value to be added to the IFMATCH Header
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SIP_Return
IFX_SIP_IFMATCH_SetValue(IN uint32 uiIfMatchHdl,
                        IN char8* szVal);


/* @} */
#endif /*RFC_3903 */

#ifdef RFC_3325
/*######################### PRIVACY ################## */
 /** \ingroup MSGAPI 
	\defgroup Privacy Privacy Header
    \brief This section contains the APIs for getting and setting the parameters in the Privacy Header
*/
/* @{ */

/*! \brief  	Gets the Privacy value of the Privacy Header.  
    \param[in] 	uiPrivHdl Reference to the Privacy Header
    \return  Privacy value or Null pointer on Failure	
*/

char8*
IFX_SIP_Privacy_GetValue(uint32 uiPrivHdl);

/*! \brief  	Set the Privacy value of the Privacy Header
                to the newly supplied value.  
    \param[in] 	uiPrivHdl Reference to the Privacy Header
    \param[in] 	szprivValue Privacy value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_Privacy_SetValue(IN uint32 uiPrivHdl,
                         IN char8* szprivValue);

/* @} */

/*######################### IDENTITY ################## */
 /** \ingroup MSGAPI 
	\defgroup Identify Identity Header
    \brief This section contains the APIs for getting and setting the parameters in the Identity Header
*/
/* @{ */

/*! \brief  	Gets the reference to the Address type of Identity Param. 
    \param[in] 	uiIdentityHdl Reference to the Identity param
    \return 	Reference to the Address Type parameter 
*/

uint32
IFX_SIP_Identity_GetAddressType(uint32 uiIdentityHdl);

/* @} */
#endif /* RFC_3325*/

#ifdef RFC_3327
 /** \ingroup MSGAPI 
	\defgroup SecMech Security-Mechanism Header
    \brief This section contains the APIs for getting and setting the parameters in the Security-Mechanism Header
*/
/* @{ */

/*! \brief  	Gets the Mechanism name of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \return  Security Mechanism name or Null pointer on Failure	
*/

char8*
IFX_SIP_SecurityMechanism_GetSecMechName(IN uint32 uiSecMechHdl);

/*! \brief  	Set the Mechanism name of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in] 	szSecMech Mechanism name to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_SetSecMechName(IN uint32 uiSecMechHdl,
                                         IN char8* szSecMech);

/*! \brief  	Gets the Preference value of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \return     Preference value	
*/

char8*
IFX_SIP_SecurityMechanism_GetPreference(IN uint32 uiSecMechHdl);

/*! \brief  	Sets the Preference of the Security Mechanism Header
                to the newly supplied value
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in] 	pcPref Preference value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_SetPreference(IN uint32 uiSecMechHdl,
                                        IN char8 *pcPref);


/*! \brief  	Gets the Digest Algorithm of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \return  Digest Algorithm or Null pointer on Failure	
*/

char8*
IFX_SIP_SecurityMechanism_GetDigestAlgorithm(IN uint32 uiSecMechHdl);

/*! \brief  	Sets the Digest Algorithm of the Security Mechanism Header
                to the newly supplied value
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in] 	szDigAlgo Digest algorithm value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_SetDigestAlgorithm(IN uint32 uiSecMechHdl,
                                             IN char8* szDigAlgo);

/*! \brief  	Gets the Digest Qop of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \return  Digest Qop or Null pointer on Failure	
*/

char8*
IFX_SIP_SecurityMechanism_GetDigestQoP(IN uint32 uiSecMechHdl);

/*! \brief  	Sets the Digest Qop of the Security Mechanism Header
                to the newly supplied value
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in] 	szDigQop Digest qop value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_SetDigestQoP(IN uint32 uiSecMechHdl,
                                       IN char8* szDigQop);

/*! \brief  	Gets the Digest Verify of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \return  Digest Verify or Null pointer on Failure	
*/

char8*
IFX_SIP_SecurityMechanism_GetDigestVerify(IN uint32 uiSecMechHdl);

/*! \brief  	Sets the Digest Qop of the Security Mechanism Header
                to the newly supplied value
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in] 	szDigVerify Digest verify value to be set
    \return 	IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/

e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_SetDigestVerify(IN uint32 uiSecMechHdl,
                                       IN char8* szDigVerify);


/*! \brief  	Gets the GenericParam of the Security Mechanism Header.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
	\param[in]  iLocation Location(starts from 1) of the Security
                Mechanism parameter
    \param[in] 	pcToken Token 
    \return  Generic Param value or Null pointer on Failure	
*/

char8*
IFX_SIP_SecurityMechanism_GetGenericParam(IN uint32 uiSecMechHdl,
                                          IN int32 iLocation,
                                          IN char8* pcToken);
/*! \brief      Sets the generic param value to the Security Mechanism Header
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_SetGenericParam( IN  uint32 uiSecMechHdl,
                                           IN char8* pcToken,
                                           IN char8* pcValue );
/*! \brief      Gets the SecurityMechanism param in the specified location   
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in]  iLocation Location(starts from 1) of the Security
                Mechanism parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_SecurityMechanism_GetParam(IN uint32 uiSecMechHdl,
                                   IN int32 iLocation,
                                   IN char8** pcName,
                                   IN char8** pcValue);

/*! \brief  	Check whether the Token is present.  
    \param[in] 	uiSecMechHdl Reference to the Security Mechanism Header
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SecurityMechaninsm_HasToken(IN uint32 uiSecMechHdl,
                             IN char8* pcToken);


/* @} */
#endif /*RFC_3327 */

#ifdef RFC_3455
 /** \ingroup MSGAPI 
	\defgroup pAsoUri p-Associated-URI Header
    \brief This section contains the APIs for getting and setting the parameters in the p-Associated-URI Header
*/
/* @{ */

/*! \brief  	Gets the reference to the Name Addr of p-aso-uri-spec. 
    \param[in] 	uiPAsoUriSpecHdl Reference to the p-aso-uri-spec.
    \return 	Reference to the NameAddr 
*/
uint32
IFX_SIP_PAsoUriSpec_GetNameAddr(IN uint32 uiPAsoUriSpecHdl);

/*! \brief  	Check whether the Token is present in p-aso-uri-spec.
    \param[in] 	uiPAsoUriSpecHdl Reference to the p-aso-uri-spec.
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_PAsoUriSpec_HasToken(IN uint32 uiPAsoUriSpecHdl,
                             IN char8* pcToken);

/*! \brief  	Gets the GenericParam of the  p-aso-uri-spec .  
    \param[in] 	uiPAsoUriSpecHdl Reference to the p-aso-uri-spec.
    \param[in]  iLocation Location(starts from 1) of the PAsoUriSpec
                parameter
    \param[in] 	pcToken Token 
    \return  GenericParam value or Null pointer on Failure	
*/

char8*
IFX_SIP_PAsoUriSpec_GetGenericParam(IN uint32 uiPAsoUriSpecHdl,
                                    IN int32 iLocation,
                                    IN char8* pcToken);

/*! \brief      Sets the generic param value to the p-aso-uri-spec. 
    \param[in] 	uiPAsoUriSpecHdl Reference to the p-aso-uri-spec.
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_PAsoUriSpec_SetGenericParam( IN  uint32 uiPAsoUriSpecHdl,
                                           IN char8* pcToken,
                                           IN char8* pcValue);

/*! \brief      Gets the PAsoUriSpec param in the specified location   
    \param[in] 	uiPAsoUriSpecHdl Reference to the p-aso-uri-spec.
    \param[in]  iLocation Location(starts from 1) of the PAsoUriSpec
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_PAsoUriSpec_GetParam(IN uint32 uiPAsoUriSpecHdl,
                             IN int32 iLocation,
                             IN char8** pcName,
                             IN char8** pcValue);

/* @} */

 /** \ingroup MSGAPI 
	\defgroup CalledPID Called-Party-Identifier Header
    \brief This section contains the APIs for getting and setting the parameters in the Called-Party-Identifier Header
*/
/* @{ */


/*! \brief  	Gets the reference to the Name Addr of called-pty-id-spec. 
    \param[in] 	uiCalledPtyIdSpecHdl Reference to the called-pty-id-spec
    \return 	Reference to the NameAddr 
*/
uint32
IFX_SIP_CalledPtyIdSpec_GetNameAddr(IN uint32 uiCalledPtyIdSpecHdl);

/*! \brief  	Check whether the Token is present.  
    \param[in] 	uiCalledPtyIdSpecHdl Reference to the called-pty-id-spec
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CalledPtyIdSpec_HasToken(IN uint32 uiCalledPtyIdSpecHdl,
                             IN char8* pcToken);

/*! \brief  	Gets the GenericParam of the called-pty-id-spec.
    \param[in] 	uiCalledPtyIdSpecHdl Reference to the called-pty-id-spec
    \param[in]  iLocation Location(starts from 1) of the PAsoUriSpec
                parameter
    \param[in] 	pcToken Token 
    \return  GenericParam value or Null pointer on Failure	
*/

char8*
IFX_SIP_CalledPtyIdSpec_GetGenericParam(IN uint32 uiCalledPtyIdSpecHdl,
                                        IN int32 iLocation,
                                        IN char8* pcToken);

/*! \brief      Sets the generic param value to the called-pty-id-spec. 
    \param[in] 	uiCalledPtyIdSpecHdl Reference to the called-pty-id-spec
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CalledPtyIdSpec_SetGenericParam( IN uint32 uiCalledPtyIdSpecHdl,
                                           IN char8* pcToken,
                                           IN char8* pcValue );

/*! \brief      Gets the CalledPtyIdSpec param in the specified location   
    \param[in] 	uiCalledPtyIdSpecHdl Reference to the called-pty-id-spec
    \param[in]  iLocation Location(starts from 1) of the CalledPtyIdSpec
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_CalledPtyIdSpec_GetParam(IN uint32 uiCalledPtyIdSpecHdl,
                                 IN int32 iLocation,
                                 IN char8** pcName,
                                 IN char8** pcValue);


/* @} */

 /** \ingroup MSGAPI 
	\defgroup VNetworkSpec V-Network-Spec Header
    \brief This section contains the APIs for getting and setting the parameters in the V-Network-Spec Header
*/
/* @{ */

/*! \brief  	Check whether the Token is present in vnetwork-spec
    \param[in] 	uiVNetworkSpecHdl Reference to the vnetwork-spec
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_VNetworkSpec_HasToken(IN uint32 uiVNetworkSpecHdl,
                             IN char8* pcToken);

/*! \brief  	Gets the GenericParam of the vnetwork-spec.
    \param[in] 	uiVNetworkSpecHdl Reference to the vnetwork-spec
    \param[in]  iLocation Location(starts from 1) of the vnetwork-spec
                parameter
    \param[in] 	pcToken Token 
    \return     GenericParam value or Null pointer on Failure	
*/
char8*
IFX_SIP_VNetworkSpec_GetGenericParam(IN uint32 uiVNetworkSpecHdl,
                                     IN int32 iLocation,
                                          IN char8* pcToken);

/*! \brief      Sets the generic param value to the vnetwork-spec. 
    \param[in] 	uiVNetworkSpecHdl Reference to the vnetwork-spec
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_VNetworkSpec_SetGenericParam( IN uint32 uiVNetworkSpecHdl,
                                           IN char8* pcToken,
                                           IN char8* pcValue );

/*! \brief      Gets the vnetwork-spec param in the specified location   
    \param[in] 	uiVNetworkSpecHdl Reference to the vnetwork-spec
    \param[in]  iLocation Location(starts from 1) of the vnetwork-spec
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_VNetworkSpec_GetParam(IN uint32 uiVNetworkSpecHdl,
                              IN int32 iLocation,
                              IN char8** pcName,
                              IN char8** pcValue);



/*! \brief  	Gets the token/quoted string of the vnetwork-spec.
    \param[in] 	uiVNetworkSpecHdl Reference to the vnetwork-spec
    \return     GenericParam value or Null pointer on Failure	
*/
char8*
IFX_SIP_VNetworkSpec_GetString(IN uint32 uiVNetworkSpecHdl);

/*! \brief      Sets the token/quoted string to the vnetwork-spec. 
    \param[in] 	uiVNetworkSpecHdl Reference to the vnetwork-spec
    \param[in]  szString string to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_VNetworkSpec_SetString( IN uint32 uiVNetworkSpecHdl,
                                           IN char8* szString);
/* @} */

 /** \ingroup MSGAPI 
	\defgroup AcceptNetSpec access-net-spec Header
    \brief This section contains the APIs for getting and setting the parameters in the access-net-spec Header
*/
/* @{ */

/*! \brief  	Gets the access-type of the access-net-spec.
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \return     access-type or Null pointer on Failure	
*/
char8*
IFX_SIP_AccessNetSpec_GetAccessType(IN uint32 uiAccessNetSpecHdl);

/*! \brief      Sets the access-type to the access-net-spec. 
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \param[in]  szAccessType access-type to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AccessNetSpec_SetAccessType( IN uint32 uiAccessNetSpecHdl,
                                           IN char8* szAccessType);

/*! \brief  	Gets the cgi-3gpp value of the access-net-spec.
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \return     cgi-3gpp or Null pointer on Failure	
*/
char8*
IFX_SIP_AccessNetSpec_GetCgi3gpp(IN uint32 uiAccessNetSpecHdl);

/*! \brief      Sets the cgi-3gpp value to the access-net-spec. 
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \param[in]  szCgi3gpp cgi-3gpp value to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AccessNetSpec_SetCgi3gpp(IN uint32 uiAccessNetSpecHdl,
                                 IN char8* szCgi3gpp);

/*! \brief  	Gets the utran-cell-id-3gpp value of the access-net-spec.
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \return     utran-cell-id-3gpp or Null pointer on Failure	
*/
char8*
IFX_SIP_AccessNetSpec_GetUtranCellId3gpp(IN uint32 uiAccessNetSpecHdl);

/*! \brief      Sets the utran-cell-id-3gpp value to the access-net-spec. 
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \param[in]  szUtranCellId3gpp utran-cell-id-3gpp value to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AccessNetSpec_SetUtranCellId3gpp(IN uint32 uiAccessNetSpecHdl,
                                         IN char8* szUtranCellId3gpp);

/*! \brief  	Gets the extension-access-info value of the access-net-spec.
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \return     extension-access-info or Null pointer on Failure	
*/
char8*
IFX_SIP_AccessNetSpec_GetExtAccessInfo(IN uint32 uiAccessNetSpecHdl);

/*! \brief      Sets the extension-access-info value to the access-net-spec. 
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \param[in]  szExtAccessInfo extension-access-info value to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AccessNetSpec_SetExtAccessInfo(IN uint32 uiAccessNetSpecHdl,
                                         IN char8* szExtAccessInfo);

/*! \brief      Gets the AccessNetSpec param in the specified location   
    \param[in] 	uiAccessNetSpecHdl Reference to the access-net-spec
    \param[in]  iLocation Location(starts from 1) of the AccessNetSpec
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_AccessNetSpec_GetParam(IN uint32 uiAccessNetSpecHdl,
                               IN int32 iLocation,
                               IN char8** pcName,
                               IN char8** pcValue);

/* @} */

 /** \ingroup MSGAPI 
	\defgroup ChargeAddrParams charge-addr-params  Header
    \brief This section contains the APIs for getting and setting the parameters in the charge-addr-params Header
*/
/* @{ */

/*!  \brief  	Gets the ccf value of the charge-addr-params
    \param[in] 	uiChargeAddrParamsHdl Reference to the charge-addr-params
    \return     ccf or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargeAddrParams_GetCcf(IN uint32 uiChargeAddrParamsHdl);

/*! \brief      Sets the ccf value to the charge-addr-params 
    \param[in] 	uiChargeAddrParamsHdl Reference to the charge-addr-params
    \param[in]  szCcf ccf value to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargeAddrParams_SetCcf(IN uint32 uiChargeAddrParamsHdl,
                                         IN char8* szCcf);

/*! \brief  	Gets the ecf value of the charge-addr-params
    \param[in] 	uiChargeAddrParamsHdl Reference to the charge-addr-params
    \return  ecf or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargeAddrParams_GetEcf(IN uint32 uiChargeAddrParamsHdl);

/*! \brief      Sets the ecf value to the charge-addr-params 
    \param[in] 	uiChargeAddrParamsHdl Reference to the charge-addr-params
    \param[in]  szEcf ecf value to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargeAddrParams_SetEcf(IN uint32 uiChargeAddrParamsHdl,
                                         IN char8* szEcf);

/*! \brief      Sets the generic param value to the vnetwork-spec. 
    \param[in] 	uiChargeAddrParamsHdl Reference to the charge-addr-params
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargeAddrParams_SetGenericParam( IN uint32 uiChargeAddrParamsHdl,
                                           IN char8* pcToken,
                                           IN char8* pcValue );

/*! \brief      Gets the ChargeAddrParams param in the specified location   
    \param[in] 	uiChargeAddrParamsHdl Reference to the charge-addr-params
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ChargeAddrParams_GetParam(IN uint32 uiChargeAddrParamsHdl,
                                  IN char8** pcName,
                                  IN char8** pcValue);


/* @} */

 /** \ingroup MSGAPI 
	\defgroup ChargeVector charging-vector  Header
    \brief This section contains the APIs for getting and setting the parameters in the charging-vector Header
*/
/* @{ */

/*! \brief  	Check whether the Token is present in charging-vector
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in] 	pcToken Token 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_HasToken(IN uint32 uiChargingVectorHdl,
                             IN char8* pcToken);

/*! \brief  	Gets the GenericParam of the charging-vector.
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  iLocation Location(starts from 1) of the charging-vector
                parameter
    \param[in] 	pcToken Token 
    \return     GenericParam value or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargingVector_GetGenericParam(IN uint32 uiChargingVectorHdl,
                                       IN int32 iLocation,
                                          IN char8* pcToken);

/*! \brief      Sets the generic param value to the charging-vector. 
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  pcToken Generic param token
    \param[in]  pcValue Generic param value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_SetGenericParam( IN uint32 uiChargingVectorHdl,
                                           IN char8* pcToken,
                                           IN char8* pcValue );

/*! \brief      Gets the ChargingVector param in the specified location   
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  iLocation Location(starts from 1) of the charging-vector
                parameter
    \param[out]  pcName Reference to the parameter Name.
    \param[out]  pcValue Reference to the parameter value. Null in case
                 it does not have any value.
    \return     Based on the availability of data in the specified location 
                IFX_SIP_SUCCESS or IFX_SIP_FAILURE is returned
    \note       Application using this API should free pcName and pcValue 
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_GetParam(IN uint32 uiChargingVectorHdl,
                                IN int32 iLocation,
                                IN char8** pcName,
                                IN char8** pcValue);

/*! \brief  	Gets the icid-value of the charging-vector.
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \return     icid-value or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargingVector_GetIcidValue(IN uint32 uiChargingVectorHdl);

/*! \brief      Sets the icid-value to the charging-vector. 
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  szIcidValue icid-value to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_SetIcidValue( IN uint32 uiChargingVectorHdl,
                                           IN char8* szIcidValue);

/*! \brief  	Gets the icid-gen-addr of the charging-vector.
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \return     icid-gen-addr or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargingVector_GetIcidGenAddr(IN uint32 uiChargingVectorHdl);

/*! \brief      Sets the icid-gen-addr to the charging-vector. 
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  szIcidGenAddr icid-gen-addr to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_SetIcidGenAddr( IN uint32 uiChargingVectorHdl,
                                           IN char8* szIcidGenAddr);

/*! \brief  	Gets the orig-ioi of the charging-vector.
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \return     orig-ioi or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargingVector_GetOrigIoi(IN uint32 uiChargingVectorHdl);

/*! \brief      Sets the orig-ioi to the charging-vector. 
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  szOrigIoi orig-ioi to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_SetOrigIoi( IN uint32 uiChargingVectorHdl,
                                           IN char8* szOrigIoi);

/*! \brief  	Gets the term-ioi of the charging-vector.
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \return     term-ioi or Null pointer on Failure	
*/
char8*
IFX_SIP_ChargingVector_GetTermIoi(IN uint32 uiChargingVectorHdl);

/*! \brief      Sets the term-ioi to the charging-vector. 
    \param[in] 	uiChargingVectorHdl Reference to the charging-vector
    \param[in]  szTermIoi term-ioi to be added
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_ChargingVector_SetTermIoi( IN uint32 uiChargingVectorHdl,
                                           IN char8* szTermIoi);

/* @} */
#endif
/*######################### Request / Response ################## */

 /** \ingroup MSGAPI 
	\defgroup Request Request Line
    \brief This section contains the APIs for accessing the contents of Request Line
*/
/* @{ */

/*! \brief      Return Method from Request URI   
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[out] pcMethod Reference to method string
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Request_GetMethod (IN  uint32 uiSipMsgHdl,
                           OUT char8** pcMethod);


/*! \brief      Sets method in Request URI
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  pcMethod Value to be set 
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Request_SetMethod (IN  uint32 uiSipMsgHdl,
                           IN char8* pcMethod);

/*! \brief      Returns the MethodType
    \param[in]   pcMethod Method name
    \return      e_IFX_SIP_BasicMethod
*/
e_IFX_SIP_BasicMethod
IFX_SIP_GetMethodType(IN char8* pcMethod);


/*! \brief      Returns the Handle for Address Spec   
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Returns the Handle of AddressSpec 
*/

uint32
IFX_SIP_Request_GetAddrSpec(IN uint32 uiSipMsgHdl);


/*! \brief      Returns Type of URI of SIP Message (SIP/sips/Absolute)
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Returs Type of URI of SIP Message
*/
e_IFX_SIP_UriType
IFX_SIP_Request_GetUriType (IN  uint32 uiSipMsgHdl);


/*! \brief      Returns version from Request / Response line
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Returns SIP version 
*/
char8*
IFX_SIP_GetSipVersion (IN  uint32 uiSipMsgHdl);


/*! \brief      Sets SIP Version in Request line
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  pcVersion Version to be set
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Request_SetVersion (IN  uint32 uiSipMsgHdl,
                            IN  char8* pcVersion);

/* @} */

 /** \ingroup MSGAPI 
	\defgroup Response Status Line
    \brief This section contains the APIs for accessing the contents of Status Line
*/
/* @{ */

/*! \brief      Sets SIP Version in Response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  pcVersion Version to be set
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Response_SetVersion (IN  uint32 uiSipMsgHdl,
                            IN  char8* pcVersion);


/*! \brief      Gets reason phrase from SIP response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Returns reason phrase
*/
char8*
IFX_SIP_Response_GetReasonPhrase (IN  uint32 uiSipMsgHdl);



/*! \brief      Sets reason phrase in SIP response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  pcPhrase Reason phrase 
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Response_SetReasonPhrase (IN  uint32 uiSipMsgHdl,
                                  IN  char8* pcPhrase);


/*! \brief      Gets status from SIP response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Returns status code
*/
int16
IFX_SIP_Response_GetStatusCode (IN  uint32 uiSipMsgHdl);


/*! \brief      Sets status code in response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  nStatCode Status code
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Response_SetStatusCode (IN  uint32 uiSipMsgHdl,
                                IN  int16 nStatCode);


/*! \brief      Returns status type of SIP response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     Returns status type of SIP response
*/
e_IFX_SIP_StatusType
IFX_SIP_Response_GetStatusType (IN  uint32 uiSipMsgHdl);




/*! \brief      sets status type of SIP response
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \param[in]  eStatusType Status type
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Response_SetStatusType (IN  uint32 uiSipMsgHdl,
                                  IN  e_IFX_SIP_StatusType eStatusType);

/*! \brief      Whether the response is reliable provisional or not
    \param[in]  uiSipMsgHdl Reference to SIP Message
    \return     IFX_SIP_SUCCESS/ IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_Response_IsReliable (IN  uint32 uiSipMsgHdl);

/* @} */


/* ########################Address Spec's API ####################### */

 /** \ingroup MSGAPI 
	\defgroup AddrType Address Type
    \brief This section contains the APIs for accessing the contents of Address type structure
*/
/* @{ */

/*! \brief      Returns reference to AddrSpec from AddressType structure
    \param[in]  uiAddrTypeHdl Reference to the AddressType
    \return     Reference to AddrSpec
*/
uint32
IFX_SIP_AddressType_GetAddrSpec(IN uint32 uiAddrTypeHdl);


/*! \brief      Retruns display from NameAddress structure
    \param[in]  uiAddrTypeHdl Reference to the AddressType
    \return     Returns Display name
*/
char8*
IFX_SIP_AddressType_GetDisplayName(IN uint32 uiAddrTypeHdl);



/*! \brief      Sets display name in NameAddr Structure
    \param[in]  uiAddrTypeHdl Reference to the AddressType
    \param[in]  pcName Name string 
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AddressType_SetDisplayName(IN uint32 uiAddrTypeHdl,
                                   IN char8* pcName);

/*! \brief      Get SIP or SIPS URI from AddrSpec,
    \param[in]  uiAddrTypeHdl Reference to the AddressType
    \return     Address or NULL pointer on failure 
    \note       Application using this API should free the buffer 
*/

char8*
IFX_SIP_AddrType_GetValue(IN uint32 uiAddrTypeHdl);

/*! \brief      Set SIP or SIPS URI from AddrSpec,
    \param[in]  uiAddrTypeHdl Reference to the AddressType
    \param[in]  pcAddress AddressType to be set
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AddrType_SetValue(IN uint32 uiAddrTypeHdl,
                          IN char8* pcAddress );

/*! \brief      Get Reference of the AddrSpec. 
    \param[in]  uiNameAddrHdl Reference to the NameAddr
    \return     Returns handle to the AddrSpec
*/

uint32
IFX_SIP_NameAddr_GetAddrSpec(IN uint32 uiNameAddrHdl);

/*! \brief      Get SIP or SIPS URI from NameAddr,
    \param[in]  uiNameAddrHdl Reference to the NameAddr
    \return     Address or NULL pointer on failure 
    \note       Application using this API should free the buffer 
*/

char8*
IFX_SIP_NameAddr_GetValue(IN uint32 uiNameAddrHdl);


/*! \brief      Set SIP or SIPS URI from NameAddr,
    \param[in]  uiNameAddrHdl Reference to the AddressType
    \param[in]  pcAddress AddressType to be set
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_NameAddr_SetValue(IN uint32 uiNameAddrHdl,
                          IN char8* pcAddress );

/* @} */

 /** \ingroup MSGAPI 
	\defgroup AddrSpec AddrSpec
    \brief This section contains the APIs for accessing the contents of AddressSpec
*/
/* @{ */

/*! \brief      Get SIP or SIPS URI from AddrSpec,
    \param[in]  uiAddrSpecHdl Reference to the AddrSpec
    \return     Address or NULL pointer on failure 
    \note       Application using this API should free the buffer 
*/
char8*
IFX_SIP_AddrSpec_GetValue(IN uint32 uiAddrSpecHdl);

/*! \brief      Set SIP or SIPS URI from AddrSpec,
    \param[in]  uiAddrSpecHdl Reference to the AddrSpec
    \param[in]  pcAddress AddressSpec to be set
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_AddrSpec_SetValue(IN uint32 uiAddrSpecHdl,
                          IN char8* pcAddress);

/*! \brief      Returns SIP or SIPS URI from AddrSpec,
                by default Returns reference to SIP URI
    \param[in]  uiAddrSpecHdl Reference to the AddrSpec
    \return     Reference to the SIP or SIPS URI
*/
uint32
IFX_SIP_Addrspec_GetSipUri(IN uint32 uiAddrSpecHdl );

/*! \brief      Returns the URI type of the AddrSpec
    \param[in]  uiAddrSpecHdl Reference to the AddrSpec
    \return     enum of the URI type 
*/
e_IFX_SIP_UriType
IFX_SIP_Addrspec_GetUriType(IN uint32 uiAddrSpecHdl );

#ifdef DARE_CUST
/*! \brief      Returns the Value of Diversion Header
    \param[in]  uiHdrHdl Reference to the Header Handler
	\param[out] acDiveValue Diversion header value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE 
*/
e_IFX_Return
IFX_SIP_Diversion_GetValue(IN  uint32 uiHdrHdl,
                           OUT char8 *acDivValue);
						   
/*! \brief      Sets the Value of Diversion Header
    \param[in]  uiHdrHdl Reference to the Header Handler
	\param[in] acDiveValue Diversion header value
    \return     Returns IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*/
e_IFX_Return
IFX_SIP_Diversion_SetValue(IN  uint32 uiHdrHdl,
                           IN char8 *acDivValue);
#endif
/* @} */



#endif
