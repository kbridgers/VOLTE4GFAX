/**************************************************************************
**   FILE NAME    : IFX_SDP_GetSet.h
**   PROJECT      : SIP 
**   MODULES      : Get and Set APIs for constructing the SDP fields
**   SRC VERSION  : V2.2.1
**   DATE         : 
**   AUTHOR       : SIP Team
**   DESCRIPTION  : APIs for using the SDP Message.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
/*! \file IFX_SDP_GetSet.h
    \brief This File contains the Get and Set APIs for constructing the
     SDP headers.
*/
/** \ingroup SIP_API
	  \defgroup SDPAPI SDP
    \brief This section lists the functions for setting and getting the SDP information.
*/
/* @{ */

#ifndef __IFX_SDP_GetSet_H__
#define __IFX_SDP_GetSet_H__
/*! 
    \brief An Enumeration defining possible headers in a SDP message.
*/
typedef enum{
  IFX_SDP_ORIGIN = 0,/*!< ORIGIN header */
  IFX_SDP_SDPURI=1,/*!< SDP URI */
  IFX_SDP_EMAIL=2,/*!< Email Header */
  IFX_SDP_PHONE=3,/*!< Phone Header */
  IFX_SDP_CONNECTION=4,/*!< Connection Header */
  IFX_SDP_BANDWIDTH=5,/*!< Bandwidth header field */
  IFX_SDP_TIME=6,/*!< Time Header field */
  IFX_SDP_KEY=7,/*!< Key Header field */
  IFX_SDP_ATTRIBUTES=8,/*!< session level attributes */
  IFX_SDP_MEDIA_DESC=9/*!< Media description */
} e_IFX_SDP_Param;

/*! 
    \brief An Enumeration defining possible headers within an M Line.
*/
typedef enum{
  IFX_SDP_MEDIA_MEDIA = 0,/*!< Mediaheader field */
  IFX_SDP_MEDIA_CONNECTION=1,/*!< Connection Header field */
  IFX_SDP_MEDIA_BANDWIDTH=2,/*!< Bandwidth header field */
  IFX_SDP_MEDIA_KEY=3,/*!< Key header field */
  IFX_SDP_MEDIA_MODE=4,/*!< Mode of the RTP flow */
  IFX_SDP_MEDIA_ATTRIBUTES=5,/*!< Media level attributes */
} e_IFX_SDP_MediaParam;

/*! 
    \brief An Enumeration defining Possible headers inside a time.
*/
typedef enum{
  IFX_SDP_TIME_STARTSTOP = 0,/*!< Stop and start time header */
  IFX_SDP_TIME_ZONEADJ=1,/*!< Zone Adjustment header */
  IFX_SDP_TIME_REPEAT=2, /*!< Repeat header */
} e_IFX_SDP_TimeParam;

/*! 
    \brief An Enumeration defining Network Types.
*/
typedef enum{
  IFX_SDP_IN = 1,/*!< Internet type */
  IFX_SDP_ATM=2/*!< ATM network */
} e_IFX_SDP_Network;

/*! 
    \brief An Enumeration defining the address type.
*/
typedef enum{
  IFX_SDP_IPV4 = 1,/*!< IPv4 Address */
  IFX_SDP_IPV6=2/*!< IPv6 Address */
}e_IFX_SDP_AddrTrype;

/*! 
    \brief An Enumeration defining SDP Key.
*/
typedef enum{
  IFX_SDP_PROMPT = 1,/*!< Prompt */
  IFX_SDP_CLEAR=2,/*!< Clear */
  IFX_SDP_BASE64=3,/*!< Base64 */
  IFX_SDP_URI=4/*!< URI */
}e_IFX_SDP_KEY;

/*! 
    \brief An Enumeration listing allowed media formats in the media line.
*/
typedef enum{
  IFX_SDP_AUDIO = 1,/*!< Audio */
  IFX_SDP_VIDEO=2,/*!< Video */
  IFX_SDP_DATA=3,/*!< Data */
  IFX_SDP_CONTROL=4,/*!< Control */
  IFX_SDP_APPLICATION=5,/*!< Application */
  IFX_SDP_IMAGE=6,/*!< Image */
#ifdef RFC_4566
  IFX_SDP_TEXT=7,/*!< Text */
  IFX_SDP_MESSAGE=8 /*!< Message */
#endif
}e_IFX_SDP_SdpMedia;

/*! 
    \brief An Enumeration containing return values from SDP get set functions.
*/
typedef enum{
  IFX_SDP_FAILURE=-1,/*!< Failure */
  IFX_SDP_SUCCESS=0/*!< Success */
}e_IFX_SDP_Return;

/*! 
    \brief An Enumeration defining Boolean.
*/
typedef enum{
  IFX_SDP_FALSE=0,/*!< False */
  IFX_SDP_TRUE=1/*!< True */
} e_IFX_SDP_Boolean;

/*! 
    \brief An Enumeration defining SDP Modes.
*/
typedef enum{
  IFX_SDP_SENDRECV = 0,/*!< Send Recive*/
  IFX_SDP_SENDONLY=1,/*!< Send Only*/
  IFX_SDP_RECVONLY=2,/*!< Recv Only */
  IFX_SDP_INACTIVE=3 /*!< INACTIVE */
}e_IFX_SDP_Mode;

/*###################### SDP Message #########################*/
/*! \brief      Construct a SDP Message    
    \param[out] puiSdpMsgHdl Stores the address of the pointer to the SDP Message
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_CreateMsg(OUT uint32 *puiSdpMsgHdl);

/*! \brief      Copy the SDP Message    
    \param[in]  uiFromSdpMsgHdl Reference to the SDP Message
    \param[out] uiToSdpMsgHdl Reference to the copied SDP Message
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_CopyMsg(IN uint32 uiFromSdpMsgHdl,
                OUT uint32 uiToSdpMsgHdl);

/*! \brief      Free the SDP Message    
    \param[in]  uiSdpMsgHdl Reference to the SIP Message
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_FreeMsg(IN uint32 uiSdpMsgHdl);

/*! \brief      Encode the SDP Message    
    \param[in]  uiSdpMsgHdl Reference to the SDP Message
    \param[in]  szSdpBuff Buffer to be populated after encoding
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
char8
IFX_SDP_EncodeMessage(IN uint32 uiSdpMsgHdl,
	              IN char8* szSdpBuff);
                
/*! \brief      Decode the SDP Message    
    \param[in]  pcStartIndex Start index of the SDP Message
    \param[in]  pcEndIndex End Index of the SDP Message
    \param[in]  uiSdpMsgHdl Stores the address of the pointer to the SDP Message
    \param[in]  puiErrorHdl Reference to the Error
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
char8
IFX_SDP_DecodeMessage(IN char8* pcStartIndex,
		      IN char8* pcEndIndex,
		      IN uint32 uiSdpMsgHdl,
		      IN uint32 *puiErrorHdl);

/*##################Get Header#########################*/

/*! \brief      Gets the Header Information by type
    \param[in]  uiSdpMsgHdl Reference to the SDP Message
    \param[in]  eParamType Enumeration of the SDP Parameter
    \param[in]  iLocation That particular parameter of the Header
    \param[in,out]  puiSdpHdl Stores the address of that SDP parameter
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_GetHeaderByType(IN  IN uint32 uiSdpMsgHdl,
                        IN  e_IFX_SDP_Param eParamType,
                        IN  int32 iLocation,
                        OUT uint32 *puiSdpHdl);

/*! \brief      Gets the Media Information by type
    \param[in]  uiMediaDescHdl Reference to the Media Descriptor
    \param[in]  eParamType Enumeration of the Media Parameter
    \param[in]  iLocation That particular parameter of the Media Descriptor
    \param[in,out]  puiSdpHdl stores the address of that parameter
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Media_GetParamByType(IN  uint32 uiMediaDescHdl,
                        IN  e_IFX_SDP_MediaParam eParamType,
                        IN  int32 iLocation,
                        OUT uint32 *puiSdpHdl);

/*! \brief      Gets the Time Information by type
    \param[in]  uiTimeHdl Reference to the Time parameter
    \param[in]  eParamType Enumeration of the Media Parameter
    \param[in]  iLocation That particular parameter of the Time
    \param[in,out]  puiSdpHdl stores the address of that parameter
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Time_GetParamByType(IN  uint32 uiTimeHdl,
                        IN  e_IFX_SDP_TimeParam eParamType,
                        IN  int32 iLocation,
                        OUT uint32 *puiSdpHdl);

/*##################Set Header#########################*/

/*! \brief      Sets the Header Information by type
    \param[in]  uiSdpMsgHdl Reference to the SDP Message 
    \param[in]  eParamType Enumeration of the SDP Parameter    
    \param[in,out]  puiSdpHdl Stores the address of the new location
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_SetHeaderByType(IN uint32 uiSdpMsgHdl,
                        IN  e_IFX_SDP_Param eParamType,                        
                        OUT uint32 *puiSdpHdl);

/*! brief      Sets the Media Information by type
    \param[in]  uiMediaDescHdl Reference to the Media Descriptor
    \param[in]  eParamType Enumeration of the Media Parameter    
    \param[in,out]  puiSdpHdl Stores the address of the new location
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Media_SetParamByType(IN uint32 uiMediaDescHdl,
                        IN  e_IFX_SDP_MediaParam eParamType,                        
                        OUT uint32 *puiSdpHdl);

/*! \brief      Gets the Time Information by type
    \param[in]  uiTimeHdl Reference to the Time parameter
    \param[in]  eParamType Enumeration of the Media Parameter    
    \param[in,out]  puiSdpHdl Stores the address of the new location
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Time_SetParamByType(IN  uint32 uiTimeHdl,
                        IN  e_IFX_SDP_TimeParam eParamType,                     
                        OUT uint32 *puiSdpHdl);


/*######################## Info /Session/ SdpField############################ */

/*! \brief  Returns the Pointer to the Info Field. 
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \return Returns the Pointer to the Info Field. 
*/
char8 *
IFX_SDP_GetInfo(IN uint32 uiSdpMsgHdl); 


/*! \brief  Sets the Info Field with the given values. 
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \param[in] szInfo Value of Info to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SDP_Return
IFX_SDP_SetInfo(IN uint32 uiSdpMsgHdl, 
				IN char8 *szInfo); 

/*! \brief  Returns the Pointer to the Session Field. 
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \return Returns the Pointer to the Session Field. 
*/
char8 *
IFX_SDP_GetSessionName(IN uint32 uiSdpMsgHdl); 

/*! \brief  Sets the Session Field with the given values. 
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \param[in] szSessionName Session Name
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE. 
*/
e_IFX_SDP_Return
IFX_SDP_SetSessionName(IN uint32 uiSdpMsgHdl, 
	               IN char8 *szSessionName); 


/*! \brief  Returns value of SdpField
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \return Returns value of SdpField
*/
uint16
IFX_SDP_GetSdpField(IN uint32 uiSdpMsgHdl);



/*! \brief  Sets the Session Field with the given values.
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \param[in] uiSdpField Value to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
e_IFX_SDP_Return
IFX_SDP_SetSdpField(IN uint32 uiSdpMsgHdl,
                    IN uint16 uiSdpField);

/*################## Get/Set for Version #####################*/

/*! \brief  Returns the version.
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \return Returns the version.
*/
int32
IFX_SDP_Version_GetVer(IN uint32 uiSdpMsgHdl);
                  

/*! \brief  Sets the version.  
    \param[in] uiSdpMsgHdl Reference to the SDP message
    \param[in] iVersion Version value
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Version_SetVer(IN uint32 uiSdpMsgHdl,
				       IN int32 iVersion);          


/*################## Get/Set for Origin #####################*/

/*! \brief  Returns the type of the network for this Connection. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the type of the network for this Connection. 
*/
char8* 
IFX_SDP_Origin_GetAddress(IN uint32 uiOriginHdl); 

/*! \brief  Returns the type of the address for this Connection. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the type of the address for this Connection. 
*/
e_IFX_SDP_AddrTrype 
IFX_SDP_Origin_GetAddressType(IN uint32 uiOriginHdl); 

/*! \brief  Returns the type of the network for this Connection 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the type of the network for this Connection 
*/
e_IFX_SDP_Network
IFX_SDP_Origin_GetNetworkType(IN uint32 uiOriginHdl); 
#ifndef __IMSENV__
/*! \brief  Returns the unique identity of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the unique identity of the session. 
*/
int32 
IFX_SDP_Origin_GetSessionId(IN uint32 uiOriginHdl);

/*! \brief  Returns the unique version of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the unique version of the session. 
*/
int32 
IFX_SDP_Origin_GetSessionVersion(IN uint32 uiOriginHdl);  
#else
/*! \brief  Returns the unique identity of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the unique identity of the session. 
*/
char8* 
IFX_SDP_Origin_GetSessionId(IN uint32 uiOriginHdl);

/*! \brief  Returns the unique version of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the unique version of the session. 
*/
char8* 
IFX_SDP_Origin_GetSessionVersion(IN uint32 uiOriginHdl);  
#endif

/*! \brief  Returns the name of the session originator. 
    \param[in] uiOriginHdl Reference to the Origin
    \return Returns the name of the session originator. 
*/
char8* 
IFX_SDP_Origin_GetUsername(IN uint32 uiOriginHdl);  
          
/*! \brief Sets the type of the address for this Connection. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] szAddr Address to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE  
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetAddress(IN uint32 uiOriginHdl, 
			  IN char8 *szAddr); 

/*! \brief  sets the type of the network for this Connection. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] szAddrType Address type to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetAddressType(IN uint32 uiOriginHdl,
	                      IN char8 *szAddrType); 

/*! \brief  Sets the type of the network for this Connection. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] szNwType Network type to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetNetworkType(IN uint32 uiOriginHdl,
			      IN char8 *szNwType); 
#ifndef __IMSENV__
/*! \brief  Sets the unique identity of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] iSessId ID to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetSessionId(IN uint32 uiOriginHdl,
			    IN int32 iSessId);

/*! \brief  Sets the unique version of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] iSessVer Version to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetSessionVersion(IN uint32 uiOriginHdl,
				 IN int32 iSessVer);  
#else
/*! \brief  Sets the unique identity of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] pcSessId ID to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetSessionId(IN uint32 uiOriginHdl,
			    IN char8* pcSessId);

/*! \brief  Sets the unique version of the session. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] pcSessVer Version to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetSessionVersion(IN uint32 uiOriginHdl,
				 IN char8* pcSessVer);  
#endif

/*! \brief  Sets the name of the session originator. 
    \param[in] uiOriginHdl Reference to the Origin
    \param[in] szuserName User name to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Origin_SetUsername(IN uint32 uiOriginHdl,
			   IN char8 *szuserName);  

/*################## Get/Set for Connection #####################*/

/*! \brief  Returns the type of the network for this Connection. 
    \param[in] uiConnHdl Reference to the Connection
    \return Network address or NULL pointer on failure 
*/
char8* 
IFX_SDP_Connection_GetAddress(IN uint32 uiConnHdl);  
                    

/*! \brief  Returns the type of the address for this Connection. 
    \param[in] uiConnHdl Reference to the Connection
    \return Returns the type of the address for this Connection. 
*/
 
e_IFX_SDP_AddrTrype
IFX_SDP_Connection_GetAddrType(IN uint32 uiConnHdl);   
          

/*! \brief  Returns the type of the network for this Connection.
    \param[in] uiConnHdl Reference to the Connection
    \return Returns the name of the session originator. 
*/
e_IFX_SDP_Network
IFX_SDP_Connection_GetNwType(IN uint32 uiConnHdl);  
           

/*! \brief  Sets the type of the address for this Connection. 
    \param[in] uiConnHdl Reference to the Connection
    \param[in] szAddr Address to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Connection_SetAddress(IN uint32 uiConnHdl,
			      IN char8 *szAddr);   
          

/*! \brief  Sets the Address type for this connection. 
    \param[in] uiConnHdl Reference to the Connection
    \param[in] szAddrType Address type
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Connection_SetAddressType(IN uint32 uiConnHdl,
				  IN char8 *szAddrType);  
 

/*! \brief  Sets the type of the network for this Connection. 
    \param[in] uiConnHdl Reference to the Connection
    \param[in] szNwType Type of network
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Connection_SetNwType(IN uint32 uiConnHdl,
			     IN char8 *szNwType);   
  
/*################## Get/Set for Bandwidth #####################*/

/*! \brief  Returns the bandwidth type.
    \param[in] uiBwHdl Reference to the Bandwidth
    \return  Type or NULL pointer on failure 
*/
char8* 
IFX_SDP_Bandwidth_GetType(IN uint32 uiBwHdl);

/*! \brief  Returns the bandwidth value measured in kilobits per second.
    \param[in] uiBwHdl Reference to the Bandwidth
    \return Returns the bandwidth value measured in kilobits per second.
*/
int32
IFX_SDP_Bandwidth_GetValue(IN uint32 uiBwHdl); 

/*! \brief  Sets the bandwidth type.
    \param[in] uiBwHdl Reference to the Bandwidth
    \param[in] szType Type to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Bandwidth_SetType(IN uint32 uiBwHdl, 
			  IN char8 *szType); 


/*! \brief  Sets the bandwidth Value
    \param[in] uiBwHdl Reference to the Bandwidth
    \param[in] uiBandwidth Value to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SDP_Return
IFX_SDP_Bandwidth_SetValue(IN uint32 uiBwHdl,
                          IN  uint32 uiBandwidth);


/*################## Get/Set for Email #####################*/

/*! \brief  Set email address in Email  Field.
    \param[in] uiEmailHdl Reference to Email 
    \param[in] pcMailAddr Address to be set
    \return Returns IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Email_SetAddress(IN uint32 uiEmailHdl,
                 IN char8* pcMailAddr);


/*! \brief  Gets the Email address
    \param[in] uiEmailHdl Reference to email structure
    \return Email Address
*/
char8 *
IFX_SDP_Email_GetAddress(IN uint32 uiEmailHdl);


/*! \brief  Set Name in Email  Field.
    \param[in] uiEmailHdl Reference to Email 
    \param[in] pcName Value to be set
    \return Returns IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Email_SetName(IN uint32 uiEmailHdl,
                      IN char8* pcName);

/*! \brief  Gets the Name field from  Email
    \param[in] uiEmailHdl Reference to email structure
    \return Name
*/
char8*
IFX_SDP_Email_GetName(IN uint32 uiEmailHdl);
       

/*################## Get/Set for Key #####################*/

/*! \brief  Returns the value.
    \param[in] uiKeyHdl Reference to the Key 
    \return Returns the value.
*/
char8*
IFX_SDP_Key_GetKey(IN uint32 uiKeyHdl);
                  

/*! \brief  Set the value.  
    \param[in] uiKeyHdl Reference to the Key 
    \param[in] pucKey Key string
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Key_SetKey(IN uint32 uiKeyHdl,
		   IN uchar8 *pucKey);
   
/*! \brief  Returns the name of this attribute.
    \param[in] uiKeyHdl Reference to the Key 
    \return Returns the name of Method in Key structure
*/
e_IFX_SDP_KEY
IFX_SDP_Key_GetMethod(IN uint32 uiKeyHdl);
                  

/*! \brief  Sets the id of this attribute.  
    \param[in] uiKeyHdl Reference to the Key 
    \param[in] eKey Name of Method to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Key_SetMethod(IN uint32 uiKeyHdl,
                      IN e_IFX_SDP_KEY eKey);          

/*! \brief  Determines if this attribute has an associated value.  
    \param[in] uiKeyHdl Reference to the Key 
    \return True or false
*/
e_IFX_SDP_Boolean 
IFX_SDP_Key_HasKey(IN uint32 uiKeyHdl); 
    
/*################## Get/Set for Attribute #####################*/   


/*! \brief  Returns the name of this attribute .
    \param[in] uiAttribHdl Reference to the Attribute 
    \return Returns the value.
*/
char8*
IFX_SDP_Attribute_GetName(IN uint32 uiAttribHdl);
                  

/*! \brief  Sets the id of this attribute.  
     \param[in] uiAttribHdl Reference to the Attribute 
    \param[in] pucName Name string
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Attribute_SetName(IN uint32 uiAttribHdl,
			  IN char8 *pucName);
   
/*! \brief  Returns the value.
     \param[in] uiAttribHdl Reference to the Attribute 
    \return Returns the value.
*/
char8*
IFX_SDP_Attribute_GetValue(IN uint32 uiAttribHdl);
                  

/*! \brief  Sets the value.  
     \param[in] uiAttribHdl Reference to the Attribute 
    \param[in] pucValue Value string.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Attribute_SetValue(IN uint32 uiAttribHdl,
			   IN char8* pucValue);          

/*! \brief  Determines if this attribute has an associated value.  
     \param[in] uiAttribHdl Reference to the Attribute 
    \return True or false
*/
e_IFX_SDP_Boolean 
IFX_SDP_Attribute_HasValue(IN uint32 uiAttribHdl);    

/*################## Get/Set for Uri #####################*/

/*! \brief  Gets the scheme of Uri Parameter.
    \param[in] uiUriHdl Reference to the Uri
    \return Scheme or NULL pointer on failure
*/
char8*
IFX_SDP_Uri_GetScheme(IN uint32 uiUriHdl);
                  

/*! \brief  Sets the scheme to the newly supplied value 
    \param[in] uiUriHdl Reference to the Uri
    \param[in] acScheme Scheme to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Uri_SetScheme(IN uint32 uiUriHdl,
		      IN char8* acScheme);          

/*! \brief  Gets the path of Uri Parameter.
    \param[in] uiUriHdl Reference to the Uri
    \return Path or NULL pointer on failure
*/
char8*
IFX_SDP_Uri_GetPath(IN uint32 uiUriHdl);
                  

/*! \brief  Sets the path to the newly supplied value  
    \param[in] uiUriHdl Reference to the Uri
    \param[in] acPath Path to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Uri_SetPath(IN uint32 uiUriHdl,
		    IN char8* acPath); 
         
/*################## Get/Set for Time #####################*/

/*! \brief  Returns the start time of the conference/session.
    \param[in] uiStartStopTimeHdl Reference to the StartStopTime
    \return Start time or NULL pointer on failure.
*/
char8 *
IFX_SDP_Time_StartStop_GetStartTime(IN uint32 uiStartStopTimeHdl);
                  

/*! \brief  Sets the start time of the conference/session.  
    \param[in] uiStartStopTimeHdl Reference to the StartStopTime
    \param[in] pcStartTime Start time to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Time_StartStop_SetStartTime(IN uint32 uiStartStopTimeHdl,
		                            IN char8* pcStartTime);       


/*! \brief  Returns the stop time of the session.
    \param[in] uiStartStopTimeHdl Reference to the StartStopTime
    \return Stop time or NULL pointer on failure.
*/
char8 *
IFX_SDP_Time_StartStop_GetStopTime(IN uint32 uiStartStopTimeHdl);
                  

/*! \brief  Sets the stop time of the session.  
    \param[in] uiStartStopTimeHdl Reference to the StartStopTime
    \param[in] pcStopTime Stop time to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Time_StartStop_SetStopTime(IN uint32 uiStartStopTimeHdl,
                                   IN char8 *pcStopTime); 
    
/*! \brief  Returns whether the start and stop times were set to zero (in NTP).
    \param[in] uiStartStopTimeHdl Reference to the StartStopTime
    \return Returns true or false.
*/
e_IFX_SDP_Boolean
IFX_SDP_Time_StartStop_isZero(IN uint32 uiStartStopTimeHdl);
                  

/*! \brief  Sets the start and stop times to zero (in NTP).  
    \param[in] uiStartStopTimeHdl Reference to the StartStopTime
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE 
*/
e_IFX_SDP_Return 
IFX_SDP_Time_StartStop_SetZero(IN uint32 uiStartStopTimeHdl); 



/*! \brief  Returns the Typed time of zone adjustment.
    \param[in] uiZoneAdjHdl Reference to the Zone Adjustment
    \return Returns the typed time
*/
uint32
IFX_SDP_Time_ZoneAdjustment_GetTypedTime(IN uint32 uiZoneAdjHdl);

/*! \brief  Set the Typed Time of zone adjustment.
    \param[in] uiZoneAdjHdl Reference to the Zone Adjustment
	\param[in] uiValue Typed time to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SDP_Return
IFX_SDP_Time_ZoneAdjustment_SetTypedTime(IN uint32 uiZoneAdjHdl,
                                         IN uint32 uiValue);


/*! \brief  Returns the Time unit of zone adjustment.
    \param[in] uiZoneAdjHdl Reference to the Zone Adjustment
    \return Time unit or NULL pointer on failure.
*/
char8
IFX_SDP_Time_ZoneAdjustment_GetTimeUnit(IN uint32 uiZoneAdjHdl);

/*! \brief  Set the Time unit of zone adjustment.
    \param[in] uiZoneAdjHdl Reference to the Zone Adjustment
	\param[in] cTimeUnit Time unit to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SDP_Return
IFX_SDP_Time_ZoneAdjustment_SetTimeUnit(IN uint32 uiZoneAdjHdl,
                                        IN char8 cTimeUnit);

/*! \brief  Returns the Typed time of the Repeat Field.
    \param[in] uiRepeatFieldHdl Reference to the RepeatField
    \param[in] iLocation Location of the repeat field
    \return Returns the typed time
*/
int32
IFX_SDP_Time_RepeatField_GetTypedTime(IN uint32 uiRepeatFieldHdl,
		                      IN uint8 iLocation);             

/*! \brief  Sets the Typed time of the Repeat Field.
    \param[in] uiRepeatFieldHdl Reference to the Repeat Field
	\param[in] uiValue Typed time to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SDP_Return
IFX_SDP_Time_RepeatField_SetTypedTime(IN uint32 uiRepeatFieldHdl,
                                      IN uint32 uiValue);

/*! \brief  Returns the Time unit of Repeat Field.
    \param[in] uiRepeatFieldHdl Reference to the RepeatField
    \param[in] iLocation Position of the repeat field to be fetched
    \return Time unit or NULL pointer on failure.
*/
char8
IFX_SDP_Time_RepeatField_GetTimeUnit(IN uint32 uiRepeatFieldHdl,
		                     IN uint8 iLocation);
             
/*! \brief  Sets the Time Unit of the Repeat Field.
    \param[in] uiRepeatFieldHdl Reference to the Repeat Field
	\param[in] cTimeUnit Time unit to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FALIURE
*/
e_IFX_SDP_Return
IFX_SDP_Time_RepeatField_SetTimeUnit(IN uint32 uiRepeatFieldHdl,
                                     IN char8 cTimeUnit);


/*################## Get/Set for Media#####################*/

/*! \brief      Copy the Media from Media Descriptor of the SDP Message    
    \param[in]  uiFromMediaHdl Reference to the Media
    \param[out] uiToMediaHdl Reference to the copied Media
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SDP_Return
IFX_SDP_Media_CopyMedia(IN uint32 uiFromMediaHdl,
                        OUT uint32 uiToMediaHdl);


/*! \brief  Sets the media type audio/vedio/Data/Control/Image
    \param[in] uiMediaHdl Reference to the SDP media 
    \param[in] eMedia Type of Media to be set 
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_MediaDesc_Media_SetMedia(IN uint32 uiMediaHdl,
                                 IN e_IFX_SDP_SdpMedia eMedia);



/*! \brief  Returns the type of media audio/Vedio/Data/Control/Image
    \param[in] uiMediaHdl Reference to the SDP media 
    \return Returns type of media.
*/
e_IFX_SDP_SdpMedia
IFX_SDP_MediaDesc_Media_GetMedia(IN uint32 uiMediaHdl);




/*! \brief  Sets the value of port
    \param[in] uiMediaHdl Reference to the SDP media 
    \param[in] uiPort Value of port
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_MediaDesc_Media_SetPort(IN uint32 uiMediaHdl,
                                IN uint16 uiPort );



/*! \brief  Returns the value of  port number
        \param[in] uiMediaHdl Reference to the SDP media 
    \return Returns Port Number
*/
uint16
IFX_SDP_MediaDesc_Media_GetPort(IN uint32 uiMediaHdl);



/*! \brief  Returns the value of protocol
    \param[in] uiMediaHdl Reference to the SDP media 
    \return Returns pointer to protocol string
*/

char8*
IFX_SDP_MediaDesc_Media_GetProtocol(IN uint32 uiMediaHdl);


/*! \brief  Sets the value of protocol
    \param[in] uiMediaHdl Reference to the SDP media 
    \param[in] pcProtocol Pointer to protocol string
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_MediaDesc_Media_SetProtocol(IN uint32 uiMediaHdl,
                                    IN char8* pcProtocol);


/*! \brief  Sets the value of integer in in Meida structure
    \param[in] uiMediaHdl Reference to the SDP media 
    \param[in] uiValue Value to be set
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_MediaDesc_Media_SetInteger(IN uint32 uiMediaHdl,
                                   IN uint32 uiValue);



/*! \brief  Returns the value of Integer from Media structure
    \param[in] uiMediaHdl Reference to the SDP media 
    \return Returns value of Integer from Media structure
*/
uint32
IFX_SDP_MediaDesc_Media_GetInteger(IN uint32 uiMediaHdl);


/*! \brief  Sets the value of  format paramater
    \param[in] uiMediaHdl Reference to the SDP media 
    \param[in] pcFormat Pointer format string
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SDP_Return
IFX_SDP_MediaDesc_Media_SetFormat(IN uint32 uiMediaHdl,
                                  char8* pcFormat);

/*! \brief  Returns the value of format parameter
    \param[in] uiMediaHdl Reference to the SDP media 
    \param[in] uiLocation Location of format parameter
    \return Returns char8*
*/

char8*
IFX_SDP_MediaDesc_Media_GetFormat(IN uint32 uiMediaHdl,
                                  IN uint8 uiLocation);
/*! \brief  Set the Media Mode
    \param[in] uiMediaDescHdl Reference to the SDP media 
    \param[in] eMode Mode of Media 
    \return Returns format
*/
void IFX_SDP_MediaDesc_SetMode(uint32 uiMediaDescHdl,
                               e_IFX_SDP_Mode eMode);
/*! \brief  Returns the value of Mode Parameter
    \param[in] uiMediaDescHdl Reference to the SDP media description 
    \return Returns e_IFX_SDP_Mode
*/
e_IFX_SDP_Mode  IFX_SDP_MediaDesc_GetMode(uint32 uiMediaDescHdl);
/*###################### Phone Number ######################## */

/*! \brief  Returns phone number from Phone  structure
    \param[in] uiPhoneHdl  Reference to Phone
    \return Returns phone number
*/
uint64
IFX_SDP_GetPhoneNumber(IN uint32 uiPhoneHdl);


/*! \brief  Sets phone number in Phone structure
    \param[in] uiPhoneHdl Reference to Phone
    \param[in] ulPhoneNumber Phone number
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SDP_Return
IFX_SDP_SetPhoneNumber(IN uint32 uiPhoneHdl,
                       IN uint64 ulPhoneNumber);

/*! \brief  Returns International code
    \param[in] uiPhoneHdl  Reference to Phone
    \return Returns International code
*/
uint16
IFX_SDP_Phone_GetIntCode(IN uint32 uiPhoneHdl);

/*! \brief  Sets International code
    \param[in] uiPhoneHdl  Reference to Phone
    \param[in] unInternationalCode International Code
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SDP_Return
IFX_SDP_Phone_SetInt(IN uint32 uiPhoneHdl,
                     IN uint16 unInternationalCode);


/* @} */
#endif
