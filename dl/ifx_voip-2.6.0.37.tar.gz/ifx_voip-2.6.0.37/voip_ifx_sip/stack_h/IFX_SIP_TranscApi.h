/**************************************************************************
 **   FILE NAME     : IFX_SIP_TranscApi.h
 **   PROJECT       : SIP
 **   MODULES       : Transaction layer
 **   SRC VERSION   : V2.0 
 **   DATE          : 15-12-2004
 **   AUTHOR        : SIP Team
 **   DESCRIPTION   : Implementation of Transaction Layer API's
 **   COMPILER      : gcc 
 **   REFERENCE     : Coding guide lines 
 **   COPYRIGHT     : Copyright (c) 2004
 **                   Infineon Technologies AG, st. Martin Strasse 53;
 **                   81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   Software are granted

 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_TranscApi.h
    \brief File containing the Constants, enumerations, related Data structures
     and API's for any SIP Transactions.

*/
 /**  \ingroup SIP_API
	   \defgroup TRANSCAPI Transaction handling
     \brief This section lists the functions for transaction handling. 
	 This would enable the toolkit user to cater to other methods that 
	 are not supported by the toolkit.
*/
/* @{ */

#ifndef __IFX_SIP_TRANSC_API_H__
#define __IFX_SIP_TRANSC_API_H__

/*! 
    \brief Listed below are the callback function to be registered for handling Transactions.

     Order of Callback invocations for outgoing request:
     The callback  pfnMsgToEncode is invoked whenever there is a request
     or a response going out. When a response arrives for the request sent out,
     the callback function pfnMsgRespArrived is invoked     

     Order of Callbacks invocation for Incoming request:
      On receipt of a new Request, the callback pfnReqArrived is invoked. In this
      callback, the application could associate this transaction with a new UserData.

     If the Transaction request is challenged by 401/407 Response
     The API IFX_SIP_TranscAuthenticate MUST be invoked within the
     pfnRespArrived callback. The Transaction is freed in case any of the intermediate
     callback function returns IFX_SIP_FAILURE.
*/
typedef struct
{
  e_IFX_SIP_Return (*pfnRequestArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN int32 iTransID,
                        IN uint32 uiDlgHdl,
                        IN_OUT void **ppvUserData);/*!< Called on Request arrival */

  e_IFX_SIP_Return (*pfnTimeOutOrError)(
                        IN e_IFX_SIP_TransErrorCode eErrorType,
                        IN int32 iTransID,
                        IN_OUT void *pvUserData);/*!< Called on Timeout or transport Error */

  e_IFX_SIP_Return  (*pfnMsgToEncode)(
                        IN uint32 uiSipMsgHdl,
                        IN int32 iTransID,
                        IN_OUT void *pvUserData);/*!< Called before  message is encoded */

  e_IFX_SIP_Return (*pfnMsgRespArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN int32 iTransID,
                        IN void *pvUserData);/*!< Called on Response Arrival */

  e_IFX_SIP_Return  (*pfnDnsResolved)(
                        IN uint32 uiSipMsgHdl,
                        IN int32 iTransID,
                        IN void *pvUserData);/*!<Called on resolving DNS address */
	
	uint32 uiStackHdl;/*!< Stack Instance Identifier*/
	
}x_IFX_SIP_TransCallBks;


/*! \brief Register all Call backs for SIP Transactions Methods.

    For the Methods that are  not implemented by the stack
    eMethod should be  IFX_SIP_EXTN. 
      
    \param[in] eMethod Method for which Call backs are being registered
    \param[in] pxCallBks Transaction call back functions that needs to be invoked.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_TranscRegisterCallBks(IN e_IFX_SIP_BasicMethod eMethod,
                              IN x_IFX_SIP_TransCallBks *pxCallBks);

/*! \brief Creates transaction.

    Called for creation of client transactions.
    \param[out] piTranscID Transaction Identifier
    \param[in] pvUserData Reference to User specific data required at callbacks
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_TranscCreate(OUT int32 *piTranscID,
                     IN void *pvUserData);

/*! \brief  Associate Transaction to specfic Stack and Interface.
    \param[in] iTranscID Transaction Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the transaction will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_AssociateTransc(IN int32 iTranscID,
                         IN uint32 uiStackHdl,
                         IN uint32 uiIFHdl);

/*! \brief  Get Transaction specfic Stack and Interface handles.
    \param[in] iTranscID Transaction Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_TranscGetStackIf(IN int32 iTranscID,
                         OUT uint32 *puiStackHdl,
                         OUT uint32 *puiIFHdl);

/*! \brief Destroy the transaction abruptly.

    Called for destroying a transaction.
    \param[in] iTranscID Transaction Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_TranscDestroy(IN int32 iTranscID);



/*! \brief Initializes a transaction and sends a request.

     Constructs new transaction based on given Dlg.
     Adds From,To,Max_Fwds,Via,CallId,route,Cseq and request URI Headers.
     
    \note The Transaction is freed once a final response is arrived.
     This API Free's the uiMsgHdl and iTranscID if any internal error occured.

    \param[in] iTranscID Transaction Identifier
    \param[in] szMethod Method name
    \param[in] uiMsgHdl Handle to the Sip Message that is partially
               filled or NULL constructed
    \param[in] uiDlgHdl Dialog Handle
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_TranscSendReqInsideDlg(IN int32 iTranscID,
                               IN char8 *szMethod,
                               IN uint32 uiMsgHdl,
                               IN uint32 uiDlgHdl);

/*! \brief Initializes a transaction and sends a request.

     Constructs new transaction based on given inputs.
     Adds From,To,Max_Fwds,Via,CallId,Cseq and request URI Headers.
     
    \note The Transaction is freed once a final response is arrived.
     This API Free's the uiMsgHdl and iTranscID if any internal error occured.

    \param[in] iTransID Transaction Identifier
    \param[in] szMethod Method name
    \param[in] uiSipMsgHdl Handle to the Sip Message that is partially
               filled or NULL constructed
    \param[in] pcTo To Address of the transaction
    \param[in] pcFrom From Address of the transaction
    \param[in] unTcpClientPort In case of TCP conn the SIP TCP local port.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_TranscSendRequest(IN int32 iTransID,
                          IN char8 *szMethod,
                          IN uint32 uiSipMsgHdl,
                          IN char8 *pcTo,
                          IN char8 *pcFrom,
			  IN uint16 unTcpClientPort);


/*!  \brief Sends the SIP request on the next DNS Resolved Address on 
           transaction timeout 

    \note This API Free's the uiMsgHdl and iTranscID if any internal
           error occured.
    \param[in,out] piTranscID Transaction Identifier
    \param[in] uiMsgHdl SIP message handle
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
e_IFX_SIP_Return
IFX_SIP_TranscSendReqToNxtAddr(IN int32 *piTranscID,IN uint32 uiMsgHdl);


/*! \brief Sends a response message with the given response code and 
           a reason phrase.

     \note  This API Free's the uiMsgHdl and iTranscID if any 
            internal error occured.
     \param[in] iTranscID Transaction Identifier
     \param[in] uiSipMsgHdl SIP message handle
     \param[in] unRespCode Response code
     \param[in] pcReasonPhrase String which have reason.
                if null default reason is chosen.
     \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_TranscRespond(IN int32 iTranscID,
                      IN uint32 uiSipMsgHdl,
                      IN uint16 unRespCode,
                      IN char8 *pcReasonPhrase);




/*! \brief Gets the message that was Decoded at the transaction.
    
    Need to be called only in the pfnRequestArrived and pfnRespArrived callbks.
    \param[in] iTranscID Transaction Id
    \return Handle to sip message. 
*/
uint32 
IFX_SIP_TranscGetDecodedMsg(IN int32 iTranscID);



/*! \brief Gets the message that is yet to be encoded by the
           transaction layer and sent out.

    Need to be called only in the  pfnMsgToEncode and pfnDnsResolved callbacks.
    \param[in] iTranscID Transaction Identifier
    \return Handle to sip message.
*/
uint32 
IFX_SIP_TranscGetMsgToEncode(IN int32 iTranscID);


/*! \brief Sets the Next Hop address.

    This function needs to be called before IFX_SIP_TranscSendRequest is called
    \param[in] iTranscID Transaction Identifier
    \param[in] pcRemoteAddr Remote Address.
    \param[in] unLocalPort Local Port
    \param[in] unRemotePort Remote Port
    \param[in] eProtocol Transport Protcol
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
e_IFX_SIP_Return
IFX_SIP_TranscSetNextHopAddr(IN int32 iTranscID,
                             IN char8 *pcRemoteAddr,
                             IN uint16 unLocalPort,
                             IN uint16 unRemotePort,
                             IN e_IFX_SIP_Protocol eProtocol);



/*! \brief Adds Authorization header to the SIP Message and
           sends out the request again
    \note MUST be called with the callback pfnRespArrived.

    Can be called when 401/407 response recived for the transaction request 
    \param[in] piTranscID Transaction Identifier
    \param[in] uiMsgHdl SIP Msg Hdlr
    \param[in] pcUserName Username and Passwd for 401/407 req
    \param[in] pcPasswd Passwordfor 401/407 req
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
e_IFX_SIP_Return
IFX_SIP_TranscAuthenticate(IN int32 *piTranscID,IN uint32 uiMsgHdl,
                           IN char8 *pcUserName, IN char8 *pcPasswd);



#endif

/* @} */
