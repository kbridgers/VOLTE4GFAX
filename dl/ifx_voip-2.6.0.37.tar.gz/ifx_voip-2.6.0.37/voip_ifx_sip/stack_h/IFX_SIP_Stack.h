/**************************************************************************
**   FILE NAME     : IFX_SIP_Stack.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team.
**   DESCRIPTION   : Function prototypes TU Client functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_Stack.h
    \brief This File contains the Stack Init and Configuration Functions, with
           few enumerations used within all SIP API's.
*/

/** \ingroup VoIP_LIB_API
    \defgroup SIP_API SIP Toolkit 
    \brief This section describes the SIP Toolkit.
*/

/** \ingroup SIP_API
	  \defgroup STACK Stack configuration and initialization
    \brief This section lists the functions for configuring the stack and Initializing it.
*/
/* @{ */

#ifndef __IFX_SIP_STACK_H__
#define __IFX_SIP_STACK_H__

/*!
   \brief Default value of T1
*/
#define IFX_SIP_DEFAULT_T1 500
/*!
   \brief Default SIP server port
*/
#define IFX_SIP_DEFAULT_PORT 5060
/*!
   \brief Default TLS port
*/
#define IFX_SIP_DEFAULT_TLS_PORT 5061

/*!
	\brief Internal Socket port
*/
#define IFX_SIP_INTERNAL_PORT 6080

/*! 
    \brief An Enumeration of error codes returned in the Timeout or Error Callback.
*/
typedef enum
{
  IFX_SIP_DNS_ERR=0, /*!< Destination or Dns Address resolve failed */
  IFX_SIP_SERVER_ERR=1, /*!< Creating Server transaction Error */
  IFX_SIP_DECODE_ERR=2, /*!< Decode Error */
  IFX_SIP_TIMEOUT_ERR=3,/*!< Transaction Timeout Error */
  IFX_SIP_ERR_CLEANUP=4,/*!< Internal Error Clean up the resources */
  IFX_SIP_2XXACK_TIMEOUT=5,/*!< 2xx Ack Timeout */
  IFX_SIP_SESSREFRESH_TIMEOUT=6,/*!< Session Refresh Timeout */
  IFX_SIP_SESSREFRESH_NOTIFY=7,/*!< Session Refresh Notification */
  IFX_SIP_TRANS_ERR=8,/*!< Transport error */
  IFX_SIP_SUBSCRIBER_TIMEOUT=9,/*!< Subscriber timed out */
  IFX_SIP_NOTIFIER_TIMEOUT=10, /*!< Notifier Timed out */
  IFX_SIP_INFO_TIMEOUT=11 /*!< INFO Msg timed out */
} e_IFX_SIP_TransErrorCode;

/*! 
    \brief An Enumeration defining Return type of stack API's
*/
typedef enum{
  IFX_SIP_FAILURE = -1, /*!< Failure */
  IFX_SIP_SUCCESS=0 /*!< Success */
} e_IFX_SIP_Return;

/*! 
    \brief An Enumeration defining IP Address Type
*/
typedef enum{
  IFX_SIP_TR_IPV4=0,/*!< IPv4 Address*/
  IFX_SIP_TR_IPV6=1,/*!< IPv6 Address*/
  IFX_SIP_TR_MADDR=2 /*!< Multicast Address*/
} e_IFX_SIP_IpType;

/*! 
    \brief An Enumeration defining the Event response reasons.
*/
typedef enum{
  IFX_SIP_EVNTRSN_DEACTIVATED=0,/*!< Deactivated */
  IFX_SIP_EVNTRSN_PROBATION=1,/*!< Probation */
  IFX_SIP_EVNTRSN_REJECTED=2,/*!< Rejected */
  IFX_SIP_EVNTRSN_TIMEOUT=3,/*!< Timeout */
  IFX_SIP_EVNTRSN_GIVEUP=4,/*!< Giveup */
  IFX_SIP_EVNTRSN_NORESOURSE=5,/*!< No resource */
  IFX_SIP_EVNTRSN_EXT=6/*!< Extension type */
}e_IFX_SIP_EVNTRSN;

/*! 
    \brief An Enumeration defining the Subscription Event response reasons.
*/
typedef e_IFX_SIP_EVNTRSN e_IFX_SIP_SUBSC_EVNTRSN;



/*! 
    \brief An Enumeration defining the Transport Protocol

    Used in API's to set next Hop address
*/
typedef enum{
  IFX_SIP_PROTO_UDP = 1,/*!< UDP Transport Protocol */
  IFX_SIP_PROTO_TCP=2,/*!< TCP Transport Protocol */
  IFX_SIP_PROTO_TLS=3/*!< TLS Transport Protocol */
} e_IFX_SIP_Protocol;

/*! 
    \brief An Enumeration defining the Basic methods.
*/
typedef enum{
  IFX_SIP_INVITE = 1,/*!< INVITE method */
  IFX_SIP_ACK,/*!< ACK method */
  IFX_SIP_BYE,/*!< BYE method */
  IFX_SIP_CANCEL,/*!< CANCEL method */
#ifdef RFC_3262
  IFX_SIP_PRACK,/*!< PRACK method */
#endif /* RFC_3262 */
#ifdef RFC_3311
  IFX_SIP_UPDATE,/*!< UPDATE  method */
#endif
  IFX_SIP_INFO_METHOD,/*!< INFO method */
  IFX_SIP_OPTIONS,/*!< OPTIONS method */
  IFX_SIP_REFER,/*!< REFER method */
  IFX_SIP_SUBSCRIBE,/*!< SUBSCRIBE method */
  IFX_SIP_NOTIFY,/*!< NOTIFY method */
  IFX_SIP_MESSAGE_METHOD,/*!< MESSAGE method */
#ifdef RFC_3903
  IFX_SIP_PUBLISH,/*!< PUBLISH method */
#endif
  IFX_SIP_REGISTER,/*!< REGISTER method */
  IFX_SIP_EXT_METHOD,/*!< Extension method */
}e_IFX_SIP_BasicMethod;

/*! 
    \brief An Enumeration defining Boolean.
*/
typedef enum{
  IFX_SIP_FALSE=0,/*!< False */
  IFX_SIP_TRUE=1/*!< True */
} e_IFX_SIP_Boolean;


/*! 
    \brief An Enumeration defining the status types of SIP responses.
*/
typedef enum{
  IFX_SIP_INFORMATIONAL = 1,/*!< Provisional response status code between 100 and 199 */
  IFX_SIP_STATUSSUCCESS=2,/*!< Success response, 2xx class status code */
  IFX_SIP_REDIRECTION=3,/*!< Redirection, Status code between 300 and 399 */
  IFX_SIP_CLIENT_ERROR=4,/*!< Client eror, 400 class response */
  IFX_SIP_SERVER_ERROR=5,/*!< Server error, 500 class response */
  IFX_SIP_GLOBAL_FAILURE=6,/*!< Global failure, 600 class response */
  IFX_SIP_EXTENSION_CODE=7/*!< Other extensions */
} e_IFX_SIP_StatusType;

/*! 
    \brief An Enumeration defining the Message type.
*/
typedef enum{
  IFX_SIP_REQUEST = 1,/*!< Message body is Request */
  IFX_SIP_RESPONSE=2,/*!< Message body is Response */
  IFX_SIP_INVALID=3 /*!< Invalid Message Type or wrong handle*/
} e_IFX_SIP_MsgType;

#ifdef RFC_4028
/*! 
    \brief An Enumeration defining the Refresher types.
*/
typedef enum
{
   IFX_SIP_UAC = 1,/*!< UAC */
   IFX_SIP_UAS=2,/*!< UAS */
   IFX_SIP_OTHER_REFRESHER=3/*!< OTHERS */
}e_IFX_SIP_RefresherType;
#endif /*RFC_4028*/


/*! 
    \brief An Enumeration defining the SIP URI types.
*/
typedef enum{
  IFX_SIP_ABSOLUTE_SIP_URI = 1,/*!< URI type is absolute URI */
  IFX_SIP_ABS_PATH=2/*!< URI is an absolute path */
} e_IFX_SIP_SipUriType;

/*! 
    \brief An Enumeration defining the URI types.
*/
typedef enum{
  IFX_SIP_SIP_URI = 1,/*!< SIP URI */
  IFX_SIP_SIPS_URI=2,/*!< SIPS URI */
  IFX_SIP_ABSOLUTE_URI=3/*!< Absolute URI */
} e_IFX_SIP_UriType;

/*! 
    \brief An Enumeration defining the User types.

    Note change in the order of the messages will lead to change in
    defines at Msg Hdr structure. So, Pls, ensure that before changing
*/
typedef enum{
  IFX_SIP_ACCEPT = 0,/*!< Accept Header */
  IFX_SIP_ACCEPT_ENCODING=1,/*!< Accept Encoding header */
  IFX_SIP_ACCEPT_LANGUAGE=2,/*!< Accept language header */
  IFX_SIP_ALERT_INFO=3,/*!< Alert Info header */
  IFX_SIP_ALLOW=4,/*!< Allow Header */
  IFX_SIP_AUTHENTICATION_INFO=5,/*!< Authentication Info header */
  IFX_SIP_AUTHORIZATION=6,/*!< Authorization header */
  IFX_SIP_CALL_INFO=7,/*!< Call-Info header */
  IFX_SIP_CONTACT=8,/*!< Contact header */
  IFX_SIP_CONTENT_DISPOSTION=9,/*!< Content-Disposition header */
  IFX_SIP_CONTENT_ENCODING = 10,/*!< Content-Encoding header */
  IFX_SIP_CONTENT_LANGUAGE=11,/*!< Content-Language header */
  IFX_SIP_CONTENT_TYPE=12,/*!< Content-Type header */
  IFX_SIP_DATE=13,/*!< Date header */
  IFX_SIP_ERRORINFO=14,/*!< Error-Info header */
  IFX_SIP_EXPIRES=15,/*!< Expires header */
  IFX_SIP_INREPLYTO=16,/*!< In-Reply-To header */
  IFX_SIP_MIME_VERSION=17,/*!< MIME-Version header */
  IFX_SIP_MIN_EXPIRES=18,/*!< Min-Exp header */
  IFX_SIP_ORGANIZATION=19,/*!< Organization header */
  IFX_SIP_PRIORITY = 20,/*!< Priority header */
  IFX_SIP_PROXY_AUTHENTICATE=21,/*!< Proxy-Authenticate Info header */
  IFX_SIP_PROXY_AUTHORIZATION=22,/*!< Proxy-Authorization header */
  IFX_SIP_PROXY_REQUIRE=23,/*!< Proxy-Require header */
  IFX_SIP_RECORD_ROUTE=24,/*!< Record-Route header */
  IFX_SIP_REPLY_TO=25,/*!< Reply-To header */
  IFX_SIP_REQUIRE=26,/*!< Require header */
  IFX_SIP_RETRY_AFTER=27,/*!< Retry-After header */
  IFX_SIP_ROUTE=28,/*!< Route header */
  IFX_SIP_SERVER=29,/*!< Server header */
  IFX_SIP_SUBJECT = 30,/*!< Subject header */
  IFX_SIP_SUPPORTED=31,/*!< Supported header */
  IFX_SIP_TIMESTAMP = 32,/*!< Timestamp header */
  IFX_SIP_UNSUPPORTED=33,/*!< Unsupported header */
  IFX_SIP_USER_AGENT=34,/*!< User Agent header */
  IFX_SIP_WARNING=35,/*!< Warning header */
  IFX_SIP_WWW_AUTHENTICATE=36,/*!< WWW-Authenticate header */
  /* RFC 3515 headers */
  IFX_SIP_REFER_TO=37,/*!< Refer-To header */
  IFX_SIP_REFER_BY=38,/*!< Refer-By header */
  /* RFC 3265 headers */
  IFX_SIP_EVENT=39,/*!< Event header */
  IFX_SIP_ALLOW_EVENTS=40,/*!< Allow-Events header */
  IFX_SIP_SUBSCRIPTION_STATE=41,/*!< Subscription-state header */
  /*Added for draft-ietf-sip-replaces-02.txt*/
  IFX_SIP_REPLACES=42,/*!< Replaces header */
  /*Added for draft-levy-sip-diversion-08.txt*/
  IFX_SIP_DIVERSION=43,/*!< Diversion header */
#ifdef RFC_3262
  /* Added for PRACK support, RFC 3262*/
  IFX_SIP_RACK=44,/*!< RAck Header*/
  IFX_SIP_RSEQ=45,/*!< RSeq Header*/
#endif /*RFC_3262 */
#ifdef RFC_3325
  IFX_SIP_PRIVACY=46,/*!< Privacy Header*/
  /* Added for RFC 3325 */
  IFX_SIP_PASSERTED_ID=47,/*!< P-Assested-Identity Header*/
  IFX_SIP_PPREFERRED_ID=48,/*!< P-Preferred-Identity Header*/
#endif /* RFC_3325 */
#ifdef RFC_3327
  IFX_SIP_PATH=49,/*!< Path Header*/
  IFX_SIP_SECURITY_CLIENT=50,/*!< Security-Client Header*/
  IFX_SIP_SECURITY_SERVER=51,/*!< Security-Server Header*/
  IFX_SIP_SECURITY_VERIFY=52,/*!< Security-Verify Header*/
#endif /* RFC_3327 */
#ifdef RFC_3455
  IFX_SIP_PASSOCIATED_URI=53,/*!< P-Associated-URI Header*/
  IFX_SIP_PCALLED_PARTY_ID=54,/*!< P-Called-Party-ID Header*/
  IFX_SIP_PVISITED_NETWORK_ID=55,/*!< P-Visited-Network-ID Header*/
  IFX_SIP_PACCESS_NETWORK_INFO=56,/*!< P-Access-Network-Info Header*/
  IFX_SIP_PCHARGING_FUNCTION_ADDRESSES=57,/*!< P-Charging-Function-Addresses Header*/
  IFX_SIP_PCHARGING_VECTOR=58,/*!< P-Charging-Vector Header*/
#endif /*RFC_3455*/
#ifdef RFC_4028
  IFX_SIP_SE=59,/*!< Session-Expires Header*/
  IFX_SIP_MIN_SE,/*!< Min-SE Header*/
#endif /* RFC_4028 */

#ifdef RFC_3903
  IFX_SIP_ETAG=61,/*!< SIP-ETag Header*/
  IFX_SIP_IFMATCH,/*!< SIP-If-Match Header*/
#endif /* RFC_3903 */
  IFX_SIP_EXTENSION_HEADER=63,/*!< Extension header */
  /* Mandatory Headers */
  IFX_SIP_CALL_ID,/*!< Call-Id header */
  IFX_SIP_CONTENT_LEN,/*!< Content-Lenght header */
  IFX_SIP_CSEQ,/*!< CSeq header */
  IFX_SIP_FROM,/*!< From header */
  IFX_SIP_MAX_FORWARDS,/*!< Max-Forward header */
  IFX_SIP_TO,/*!< To header */
  IFX_SIP_VIA /*!< Via header */

}e_IFX_SIP_TypeOfHdr;


/*!  \brief  Configures the Stack Instances and Interfaces

    \param[in] uiNoOfStackInst Number of Stack Instances to be supported.
    \param[in] uiNoInterfacePerStack Number of Transport Interfaces per stack Instance.
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
  \note This API could be called by the users willing to have multiple interface/stack Instances. This should be the first API called.
*/
e_IFX_SIP_Return 
IFX_SIP_CfgStackInstances(IN uint32 uiNoOfStackInst,
                          IN uint32 uiNoInterfacePerStack);

/*!\brief  Api to Get a stack Identifier
  \param[out] puiStackHdl Stack instance Handle.
  \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
  \note This API should be called after IFX_SIP_CfgStackInstances and before configuration
*/
e_IFX_SIP_Return
IFX_SIP_GetStackInstance(IN_OUT uint32 *puiStackHdl);

/*! 
    \brief Change in Debug Level's or Type
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/    
#define IFX_SIP_CFG_DEBUG      0x01

/*! 
    \brief Change in Timer T1 and Tmax
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_TIMERS     0x02

/*! 
    \brief Change in DNS Timer Value
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_DNSTIMER   0x04

/*! 
    \brief The DSCP mark options
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_DSCPMARK   0x08

/*! 
    \brief Change in Compact header options
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_COMPACTHDR 0x10

/*! 
    \brief Change in Server Port 
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_SERVERPORT 0x20

#ifdef RFC_4028                                         
/*! 
    \brief Change in Session Timer Configuration
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in session tiemr configuration
*/
#define IFX_SIP_CFG_SESSTIMER 0x40
#endif
#ifdef SIGCOMP_SUPPORT
/*! 
    \brief Change in SigComp Port
    The ucOptions in IFX_SIP_StackCfg need to be ORed with this define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_SIGCOMP 0x80
#endif

/*! 
    \brief A structure defining Configuration Parameters of Stack
 */
typedef struct
{
  uchar8 ucOptions;/*!< Options to indicate the change in config*/ 
  uchar8 ucDbgLvl;/*!<Debug Level.*/
  uchar8 ucDbgType;/*!<Debug type*/
  uint16 unServerPort;/*!< Default Interface Sip Server Port, the IF handle is 0 for this*/
#ifdef TLS_SUPPORT  
  uint16 unTlsPort;/*!<Default Interface TLS Port, the IF handle is 0 for this*/
#endif  
  uchar8 acIPAddr[128]; /*!< Default Interface IPv4/Ipv6 addr, the IF handle is 0 for this*/
  uint16 unT1;/*!<SIP Timer T1*/
  uint32 unTmax;/*!<SIP Timer TMax*/
  uint16 unDnsQueryTimeOut;/*!<Dns Query TimeOut*/
  uchar8 ucDSCPMark;/*!<Diff serve Code point*/
#ifdef RFC_4028                                         
  uint32 uiMinSe;/*!<Min Session Expires*/
  uint32 uiSRNot;/*!<Time before which application has to be notified
                                          before refresh timer expiry*/
#endif                                         
#ifdef SIGCOMP_SUPPORT
	uchar8 ucSigCompSupport;/*!<Sigcomp Support*/
  uint32 uiSigCompPort;/*!<SigComp Server Port.*/
#endif                                         
  uchar8 ucUseCompactHdrs;/*!<Compact Header ON/OFF*/
  uint16 unLocalIPCPort;/*!< Local IPC Port used for internal communication*/
}x_IFX_SIP_StackParamCfg;

/*! \brief  Api to Configure SIP stack
    \note This API should be called before IFX_SIP_Init() is called.
    \param[in] uiStackHdl Stack Instance Handle.    
    \param[in] pxParamCfg SIP Param configuration.
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	
*/
PUBLIC e_IFX_SIP_Return 
IFX_SIP_StackConfig(IN uint32 uiStackHdl,IN x_IFX_SIP_StackParamCfg *pxParamCfg);


/*! \brief  Api to Configure SIP stack
    \note This API should be called before IFX_SIP_Init() is called.
    \param[in] ucOptions Options to indicate the change in config 
    \param[in] ucDbgLvl Debug Level 
    \param[in] ucDbgType Debug type
    \param[in] unServerPort Sip Server Port
    \param[in] unTlsPort TLS Port
    \param[in] unT1 SIP Timer T1
    \param[in] unTmax SIP Timer TMax
    \param[in] unDnsQueryTimeOut Dns Query TimeOut
    \param[in] ucDSCPMark Diff serve Code point
#ifdef RFC_4028    
    \param[in] uiMinSe Min Session Expires
    \param[in] uiSRNot Time before which application has to be notified 
                       before refresh timer expiry
#endif                       
#ifdef SIGCOMP_SUPPORT
    \param[in] ucSigCompSupport SigComp Support.
    \param[in] uiSigCompPort SigComp Server Port.
#endif
    \param[in] ucUseCompactHdrs Compact Header ON/OFF
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note This api is provided for backup compatability,developers
	      adviced not to use this api.
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_StackCfg(uchar8 ucOptions,
                                         uchar8 ucDbgLvl,
                                         uchar8 ucDbgType,
                                         uint16 unServerPort,
                                         uint16 unTlsPort,
                                         uint16 unT1,
                                         uint32 unTmax,
                                         uint16 unDnsQueryTimeOut,
                                         uchar8 ucDSCPMark,
#ifdef RFC_4028                                         
                                         uint32 uiMinSe,
                                         uint32 uiSRNot,
#endif                                         
#ifdef SIGCOMP_SUPPORT
									     uchar8 ucSigCompSupport,
									     uint32 uiSigCompPort,
#endif                                         
                                         uchar8 ucUseCompactHdrs);





/*! \brief  Initilzes SIP stack In ASYNC Mode
            Creates a Thread and initlizes SIP stack.
    \param[in] uiStackHdl Stack Handle.
    \param[in] pfnInitStatus Callback function that shall be
               called after successfull initilization  
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_Init(IN uint32 uiStackHdl, IN
                void (*pfnInitStatus)(e_IFX_SIP_Return eStatus));

/*! \brief   Api to ShutDown the Stack
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_Shut(void);

/*!  \brief  Api to destroy a stack instance

    \param[in] uiStackHdl Stack Handle to be destroyed.
	\param[in] uiIFHdl Handle to be destroyed.
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
  \note This API should be the first to be called.
*/
 e_IFX_SIP_Return
 IFX_SIP_StackDestroy(IN uint32 uiStackHdl, IN uint32 uiIFHdl);

/*! 
    \brief Add fd to Read fdset.
 */
#define IFX_SIP_READ_FDSET 0x1

/*! 
    \brief Add fd to Write fdset.
 */
#define IFX_SIP_WRITE_FDSET 0x2

/*! 
    \brief Add fd to Exception fdset.
 */
#define IFX_SIP_EXCEP_FDSET 0x4

/*! 
    \brief Set SIP stack in SYNC mode.
 */
#define IFX_SIP_SYNC_MODE 0x1

/*! 
    \brief Set SIP stack in ASYNC mode.
 */
#define IFX_SIP_ASYNC_MODE 0x2

/*! 
    \brief A structure defining function pointers for 
           handling Internal socket FD's.	  
  	\note  These Callbacks need to be registered only if the SIp toolkit is
           being initialized in sync mode.
 */
typedef struct
{
	void (*pfnAddFDToSelect)(IN int32 iSipSockFd,
                 IN int32 iTypeofFDSet);/*!< Called on adding of fd to fdset */	
	void (*pfnRemoveFDToSelect) (IN int32 iSipSockFd,
            IN int32 iTypeofFDSet);/*!< Called on removing of fd from fdset */	
}x_IFX_SIP_SyncCallBks;


/*! \brief  Initilzes SIP stack in Sync Mode
    \param[in] uiStackHdl Stack Instance Handle. 
    \param[in] pfnInitStatus Callback function that shall be
               called after successfull initilization
		\param[in] pxSyncCallBks Structure that contains call back 
					     functions to add and remove internal socket fd
					     to and from Read Fd set.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_Init_Sync(IN uint32 uiStackHdl,
                IN void (*pfnInitStatus)(e_IFX_SIP_Return eStatus),
                IN x_IFX_SIP_SyncCallBks *pxSyncCallBks);


/*! \brief  Process the SIP Messages in Sync Mode
    \param[in] uiStackHdl Stack Handle
    \param[in] pxReadFds Read Fd Set
		\param[in] pxWriteFds Write Fd  
		\param[in] pxExceptFds Exception Fds  
		\param[in] piNoOfFds Number of FDs on which there was some activity
    \return 0
*/
PUBLIC int32 IFX_SIP_SyncReceiveMsg(
                                IN uint32 uiStackHdl,
                                IN void *pxReadFds, 
								IN void *pxWriteFds,
                                IN void *pxExceptFds,
     							IN int32 *piNoOfFds);
/*!  \brief  This API adds a new Interface to the  exsisting stack
	This API creates a new interface and returns the handle 
    \param[in] uiStackHdl Stack Handle
    \param[in] pcIpAddress IP Adress of the Interface
    \param[in] unServPort UDP/TCP SIP Server Port
    \param[in] unTlsServPort  TLS SIP Server Port
    \param[out] puiInterfaceHdl Interface Handle
  	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_AddInterface(IN uint32 uiStackHdl,
                                      IN char8 *pcIpAddress,
                                      IN uint16 unServPort,
                                      IN uint16 unTlsServPort,
                                      IN uint32 *puiInterfaceHdl);
/*!  \brief  This API Removes Interface of the exisitng stack

	This API closes all server sockets opened on this interface
    \param[in] uiStackHdl Stack Handle
    \param[in] uiInterfaceHdl Interface Handle
	  \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    \note This API will fail if the last interface is being removed.
          Atleast one interface should be active at any given instance
*/
e_IFX_SIP_Return IFX_SIP_RemoveInterface(IN uint32 uiStackHdl,
                                         IN uint32 uiInterfaceHdl);

/*!  \brief  This API changes exsisting server Port

	This API closes the existing UDP and TCP server and 
	opens a new UDP and TCP server on the sepcfied Server Port.
    \param[in] uiStackHdl Stack Handle
    \param[in] uiInterfaceHdl Interface Handle
    \param[in] unServPort New Server Port
    \param[in] unTlsServPort New TLS Server Port
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_ChangeServerPort(IN uint32 uiStackHdl,
                                          IN uint32 uiInterfaceHdl,
                                          IN uint16 unServPort,
                                          IN uint16 unTlsServPort);
/* @} */
#endif /*__IFX_SIP_STACK_H__*/
