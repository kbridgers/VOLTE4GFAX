/**************************************************************************
**   FILE NAME      : IFX_SIP_TUAuth.h
**   PROJECT        : SIP
**   MODULES        : Transaction User
**   SRC VERSION    : V2.0
**   DATE           : 15-12-2004
**   AUTHOR         : SIP Team
**   DESCRIPTION    : This contains the functions to send and receive Options.
**   COMPILER       : gcc
**   REFERENCE      :
**   COPYRIGHT      : Copyright (c) 2004
**                    Infineon Technologies AG, st. Martin Strasse 53;
**                    81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_TUAuth.h
    \brief File containing the Constants, enumerations, related Data structures
     and API's for any SIP Auth header construction.
*/
#ifndef __IFX_SIP_TUAUTH_H__
#define __IFX_SIP_TUAUTH_H_
 /**  \ingroup SIP_API
	    \defgroup AUTHAPI Computing Authentication response
      \brief This section lists the functions for computing the authentication response.
*/
/* @{ */


/*! 
    \brief Listed below are the callbacks to be registered by the Application 
	user for handling authentication challenges.
*/
typedef struct
{
   e_IFX_SIP_Return (*pfnComputeCreds)(
                        IN uint32 uiCredsHdl,
                        IN char8 *pszAuthUserName,
                        IN char8 *pszAuthPasswd,
                        IN uint32 uiSipMsgHdl,
                        IN int32 iAuthFlag);/*!< Called for computing Credentials */

 uint32 uiStackHdl;/*!< Stack Instance Identifer*/
}x_IFX_SIP_AuthCallBks;


/* API to SIP User agent*/
/*! \brief Register all Call backs for SIP Auth header computing.

    \param[in] pxCallBacks Pointer to the Auth Callback functions structure
*/
void
IFX_SIP_AuthRegisterCallBk(IN x_IFX_SIP_AuthCallBks *pxCallBacks);


/* @} */
#endif /* __IFX_SIP_TUOPTIONS_H__*/

