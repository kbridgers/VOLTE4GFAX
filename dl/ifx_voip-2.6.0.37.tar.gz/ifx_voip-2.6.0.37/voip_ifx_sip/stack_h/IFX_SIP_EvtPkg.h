/**************************************************************************
**   FILE NAME    : IFX_SIP_EvtPkg.h
**   PROJECT      : SIP 
**   MODULES      : Event Package Function
**   SRC VERSION  : V2.0
**   DATE         : 15-08-2005
**   AUTHOR       : SIP Team
**   DESCRIPTION  : Event Package.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
/*! \file IFX_SIP_EvtPkg.h
    \brief File containing the Constants, enumerations , related Data structures
     and API's for any subscription and notification of SIP events.

    Contains structure of subscriptions like Event Pkg, Subscription etc.
    \note In all Request/Response sending API's the parameter uiMsgHdl
          is optional, if uiMsgHdl is NULL the API creates one. simillarly the
          uiDialogHdl is optional based on the request sent within or
          outside dialog. The pcFrom and pcTo parameters are optional only in
          the case where uiDialogHdl is not NULL.
*/

 /** \ingroup SIP_API 
	   \defgroup EVNTPKGAPI Event package 
     \brief This section lists the APIs for handling Evnet notification for various packages.
*/
/* @{ */

#ifndef __IFX_SIP_EVTPKG_H__
#define __IFX_SIP_EVTPKG_H__

/* Subscription Role */
/*! 
    \brief An Enumeration defining the Role played by the Subscription.
    \note Used internall within stack.
*/
typedef enum
{
  IFX_SIP_SUBSCRIBER=1,/*!< Subscription role is has a subscriber */
  IFX_SIP_NOTIFIER=2/*!< Subscription role is has a Notifier */
}e_IFX_SIP_SUBSC_Role;

/* Subscription Events */
/*! 
    \brief An Enumeration defining all the supported Subscriptions.
    
     Any used defined Event Pkg should use IFX_SIP_SUBSC_EXTN as the 
     Event Type.
*/
typedef enum
{
  IFX_SIP_SUBSC_MSGWAIT=0,/*!< Message Waiting Subscription */
  IFX_SIP_SUBSC_REFER=1,/*!< Refer Subscription */
  IFX_SIP_SUBSC_EXTN=2, /*!< Extension Package*/
  IFX_SIP_MAX_EVENTS=3/*!< Max Subscription supported */
}e_IFX_SIP_SUBSC_EVENT;


/*! 
    \brief An Enumeration defining all the  Subscriptions state.
*/
typedef enum
{
  IFX_SIP_SUBSC_UNINT=0,/*!< Un Initlized state*/
  IFX_SIP_SUBSC_IDLE=1,/*!< IDLE State */
  IFX_SIP_SUBSC_SUBSCRIBING=2,/*!< Subscribing State */
  IFX_SIP_SUBSC_SUBSCRIBED=3,/*!< Subscribed State */
  IFX_SIP_SUBSC_PENDING=4,/*!< Pending Sate */
  IFX_SIP_SUBSC_ACTIVE=5,/*!< Active State */
  IFX_SIP_SUBSC_TIMEOUT=6,/*!< Timeout State */
  IFX_SIP_SUBSC_TERMINATED=7,/*!< Terminate State */
  IFX_SIP_SUBSC_UNAUTHENTICATED=8/*!< Unauth State */
}e_IFX_SIP_SUBSC_STATE;



/* Event Package Handlers*/
/*! 
    \brief Listed below are the function pointers for handling Subscriptions.
     
     The order of Callback invocations for outgoing requests is as follows:
     The callback given by pfnMsgToEncode is invoked whenever there is a request
     or a response going out.  For a Subscription request there is a possibility of
     receiving a subscription response or a notification request. On the 
     arrival of a Message(either a 2xx for Subscribe or Notify), the callback
     pfnDialogCreated is invoked and then subsequently
     pfnSubscRespArrived or pfnNotifyReqArrived is invoked.
     if the Subscription request is challenged by 401/407  Response
     The API IFX_SIP_SubscAuthorize MUST be invoked within the 
     pfnSubscRespArrived callback.

     The order of Callbacks invocation for Incoming request is as follows:
     There is a possibilty of receiving Unsolicited Notification  or a
     new SUBSCRIBE request. Based on the arrival of the Request message,
     either the callback function pfnSubscReqArrived or pfnNotifyReqArrived 
     is invoked. This  is followed by invocation of the callback pfnDialogCreated.

    The Subscription dialog is freed in case any of the registered callback 
	returns a IFX_SIP_FAILURE.
*/
typedef struct
{
  e_IFX_SIP_Return  (*pfnSubscReqArrived)(IN uint32 uiSipMsgHdl,
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN_OUT void **ppvUserData);/*!< Intimate on Subscription Request Arrival */

  e_IFX_SIP_Return  (*pfnNotifyReqArrived)(IN uint32 uiSipMsgHdl,
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN_OUT void **ppvUserData);/*!< Intimate on Notify Request Arrival */

  e_IFX_SIP_Return (*pfnTimeOutOrError)(
                        IN e_IFX_SIP_TransErrorCode eErrType,
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN void *pvUserData);/*!< Called on Timeout or transport Error */

  e_IFX_SIP_Return  (*pfnMsgToEncode)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN void *pvUserData);/*!< Called before  message is encoded */

  e_IFX_SIP_Return (*pfnSubscRespArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN void *pvUserData);/*!< Called on Subsc Response Arrival */

  e_IFX_SIP_Return (*pfnNotifyRespArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN void *pvUserData);/*!< Called on Notify Response Arrival */

  e_IFX_SIP_Return  (*pfnDnsResolved)(
                        IN uint32 uiSubscHdl,
                        IN void *pvUserData);/*!<Called on resolving DNS address */

  e_IFX_SIP_Return  (*pfnDialogCreated)(
                        IN uint32 uiSubscHdl,
                        IN uint32 uiDlgHdl,
                        IN void *pvUserData);/*!<Called on creation of dialogs */
	
 uint32 uiStackHdl; /*!< Stack Instance Identifier*/

}x_IFX_SIP_SubscCallBks;


/* APIS Published to SIP core Stack */

/*! \brief Registers Callback functions for the specific Event Package.

    For the packages that are  not implemented by the stack
    eEvent should be  IFX_SIP_SUBSC_EXTN.
    \param[in] eEvent Subscription Event.
    \param[in] uiMinExpiry Minimum Expiry time, used to send 423 response
               when interval is too brief.
    \param[in] uiMaxSubscAllowed Max Subscription allowed
               for this Package.
    \param[in] pxCallBks Reference to the structure containg Callbacks.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE

*/
e_IFX_SIP_Return IFX_SIP_SubscRegisterCallBks(
                                IN e_IFX_SIP_SUBSC_EVENT eEvent,
                                IN uint32 uiMinExpiry,
                                IN uint32 uiMaxSubscAllowed,
                                IN x_IFX_SIP_SubscCallBks *pxCallBks);

/*! \brief Creates a Subscription.
 
    For the packages that are  not implemented by the stack
    eEvent should be  IFX_SIP_SUBSC_EXTN.
    \param[in] pvUserData User Application Data.
    \param[in] eEvent Subscription Event.
    \param[out] puiSubscHdl Handle to the Subscription node.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscCreate(
                                IN void *pvUserData,
                                IN e_IFX_SIP_SUBSC_EVENT eEvent,
                                OUT uint32 *puiSubscHdl);
/*! \brief  Associate Subscription handle to specfic Stack and Interface.
    \param[in] uiSubscHdl Subscription Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the subscription will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_AssociateSubsc(IN uint32 uiSubscHdl,
                         IN uint32 uiStackHdl,
                         IN uint32 uiIFHdl);

/*! \brief  Get Subsc handle  specfic Stack and Interface Handles.
    \param[in] uiCallHdl Call Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_SubscGetStackIf(IN uint32 uiCallHdl,
                        OUT uint32 *puiStackHdl,
                        OUT uint32 *puiIFHdl);


/*! \brief Set the Next Hop Address.
    \note If a valid unLocalPort is given SIP toolkit will use the same for 
          establishing a TCP connection, otherwise it would pick a dynamic
          port for establishing TCP connection. This would also be used in
          all the cases where there is a switchover to TCP.

    \param[in] uiSubscHdl Handle to the Subscription node.
    \param[in] pcRemoteAddr Remote Address.
    \param[in] unLocalPort Local Port.
    \param[in] unRemotePort Remote Port.
    \param[in] eProtocol Transport Protcol.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE

*/
e_IFX_SIP_Return IFX_SIP_SubscSetNextHopAddr(
                                IN uint32 uiSubscHdl,
				IN char8 *pcRemoteAddr,
				IN uint16 unLocalPort,
				IN uint16 unRemotePort,
				IN e_IFX_SIP_Protocol eProtocol);


/*! \brief Sends out SUBSCRIBE Request

    Request could be sent within/outside a dialog .if pxDialogInfo is not null
    Message shall be sent within the dialog. otherwise the request is
    constructed using the from and to address.All Fields are Mandatory.
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \note If a valid unTcpClientPort is given SIP toolkit will use the same for 
          establishing a TCP connection, otherwise it would pick a dynamic
          port for establishing TCP connection. This would also be used in
          all the cases where there is a switchover to TCP.

    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiDlgHdl Handle to the Dialog node.
    \param[in] pcFrom Local Address.
    \param[in] pcTo Remote Address.
    \param[in] uiExpires Subscription Expiry time.
    \param[in] pcEvent Event to be subscribed.
    \param[in] uiMsgHdl SIP Message Handle.
    \param[in] unTcpClientPort TCP Client Port if any.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscSend(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN char8 *pcFrom,
                           IN char8 *pcTo,
                           IN uint32 uiExpires,
                           IN char8 *pcEvent,
                           IN uint32 uiMsgHdl,
                           IN uint16 unTcpClientPort);

/*! \brief Gets the Handle to the Dialog List, 
           for the given Subscription handler.
    \param[in] uiSubscHdl Handle to the Subscription.
    \param[out] puiDialogListHdl Handle to the dialog list.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscGetDlg(
                           IN uint32 uiSubscHdl,
                           OUT uint32 *puiDialogListHdl);


/*! \brief Trigger Auto refresh for the specified subscription handle.
    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiSecBeforeRefresh Seconds before subscription needs to be sent.
    \param[in] cStatus Can take values True/False. By default, auto refresh option is turned off.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscSetAutoRefresh(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiSecBeforeRefresh,
                           IN char8 cStatus);


/*! \brief Sends out Un subscription.

    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \param[in] uiSubscHdl Handle to the Subscription Node
    \param[in] uiDlgHdl Handle to the Dialog node.
    \param[in] uiMsgHdl SIP Message Handle.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscUnSubsc(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN uint32 uiMsgHdl);

/*! \brief Refreshes the Subscription.

    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \param[in] uiSubscHdl Handle to the Subscription Node
    \param[in] uiDlgHdl Handle to the Dialog node.
    \param[in] uiExpires Duration for which refresh is being requested.
    \param[in] uiMsgHdl SIP Message Handle.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscRefresh(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN uint32 uiExpires,
                           IN uint32 uiMsgHdl);

/*! \brief Respond the received  Subscription.

    Can be used only within the pfnSubscReqArrived callback.
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiRespCode Response Code.
    \param[in] pszReasonPhrase Reason phrase if any. 
    \param[in] uiMsgHdl SIP Message Handle.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscRespond(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiRespCode,
                           IN char8 *pszReasonPhrase,
                           IN uint32 uiMsgHdl);


/*! \brief Sends out Unsoliciated NOTIFY Request

    Request could be sent within/outside a dialog .if pxDialogInfo is not null
    Message shall be sent within the dialog. otherwise the request is
    constructed using the from and to address.
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \note If a valid unTcpPort is given SIP toolkit will use the same for 
          establishing a TCP connection, otherwise it would pick a dynamic
          port for establishing TCP connection. This would also be used in
          all the cases where there is a switchover to TCP.
    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiDlgHdl Handle to the Dialog node.
    \param[in] uiMsgHdl SIP Message Handle.
    \param[in] pcFrom Local Address.
    \param[in] pcTo Remote Address.
    \param[in] uiExpires Subscription Expiry time.
    \param[in] pcEvent Event to be subscribed.
    \param[in] eState State to be notified.
    \param[in] eReason If subscription state is terminated than
                the reason has to be specified here
    \param[in] unTcpPort TCP Client Port if any.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return IFX_SIP_SendUnSolNotify(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN uint32 uiMsgHdl,
                           IN char8 *pcFrom,
                           IN char8 *pcTo,
                           IN uint32 uiExpires,
                           IN char8 *pcEvent,
                           IN e_IFX_SIP_SUBSC_STATE eState,
                           IN e_IFX_SIP_SUBSC_EVNTRSN eReason,
                           IN uint16 unTcpPort);

/*! \brief Send out the Notify request.
    
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
 
    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiDlgHdl Handle to the Dialog Node.
    \param[in] eState Subscription State 
    \param[in] eReason If subscription state is terminated than
                the reason has to be specified here
    \param[in] uiMsgHdl SIP Message Handle.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SendNotify(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN e_IFX_SIP_SUBSC_STATE eState,
                           IN e_IFX_SIP_SUBSC_EVNTRSN eReason,
                           IN uint32 uiMsgHdl);

/*! \brief Sends Response to  the received  Notification .

    Can be used only within the pfnNotifyReqArrived callback.
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \param[in] uiSubscHdl Handle to the Subscription node.
    \param[in] uiDlgHdl SIP Dialog Handle.
    \param[in] uiMsgHdl SIP Message Handle.
    \param[in] uiRespCode Response Code.
    \param[in] pszReasonPhrase Reason phrase if any. 
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_NotifyRespond(
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN uint32 uiMsgHdl,
                           IN uint32 uiRespCode,
                           IN char8 *pszReasonPhrase);


/*! \brief Get the Message to Encode

    Can be use only within the pfnMsgToEncode callback.
    \param[in] uiSubscHdl Handle to the Subscription Node.
    \return SipMessageToEncode
*/
uint32 IFX_SIP_SubscGetMsgToEncode(
                                IN uint32 uiSubscHdl);

/*! \brief Get the Decoded Message recived
    
    Can be used only within the pfnRespArrived/pfnReqArrived callback.
    \param[in] uiSubscHdl Handle to the Subscription
    \return Decoded Sip Message
*/
uint32 IFX_SIP_SubscGetDecodedMsg(
                                IN uint32 uiSubscHdl);

/*! \brief Adds Authorization header to the SIP Message
 
    Can be called when 401/407 response recived for both Subscribe
    or Notify request. This API MUST be called in pfnSubscRespArrived or
    pfnNotifyRespArrived.
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \param[in] uiSubscHdl  Handle to the Subscription Node.
    \param[in] uiDlgHdl SIP Dialog Handle.
    \param[in] pcUserName UserName.
    \param[in] pcPasswd Password.
    \param[in,out] uiSipMsgHdl Handle to the Sip Message.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SubscAuthorize(
                                IN uint32 uiSubscHdl,
                                IN uint32 uiDlgHdl,
                                IN char8 *pcUserName,
                                IN char8 *pcPasswd,
                                IN_OUT uint32 uiSipMsgHdl);

/*! \brief Sends out Refer Request

    Request could be sent within/outside a dialog .if uiDlgHdl is not null
    Message shall be sent within  the dialog. otherwise the request is
    constructed using the from and to address.
    The uiMsgHdl and uiSubscHdl are freed by this API in case of 
    internal failures.
    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiDlgHdl Handle to the Dialog node.
    \param[in] pcFrom Local Address.
    \param[in] pcTo Remote Address.
    \param[in] uiExpires Subscription Expiry time.
    \param[in] pcEvent Event to be subscribed.
    \param[in] uiMsgHdl SIP message with some headers added in application.
    \param[in] uiReplacesDlgHdl Dialog ID to be replaced with.
    \param[in] pcReferToAddr Refer To Address.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_SendRefer(IN uint32 uiSubscHdl,
                                   IN uint32 uiDlgHdl,
                                   IN char8 *pcFrom,
                                   IN char8 *pcTo,
                                   IN uint32 uiExpires,
                                   IN char8 *pcEvent,
                                   IN uint32 uiMsgHdl,
                                   IN uint32 uiReplacesDlgHdl,
                                   IN char8 *pcReferToAddr);

/*! \brief Try Next Address recived From Dns

     should be called by the application when a Dns timeout occurs.
    \param[in] uiSubscHdl Subscription Handle Identifier
    \param[in] uiDlgHdl Handle to the Dialog node.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_SubcsTryNextAddr(IN uint32 uiSubscHdl,IN uint32 uiDlgHdl);

/*! \brief Gets Subscription State

    \param[in] uiSubscHdl Handle to the Subscription Node.
    \param[in] uiDlgHdl Handle to the Dialog node.
    \return e_IFX_SIP_SUBSC_STATE 
*/
e_IFX_SIP_SUBSC_STATE IFX_SIP_SubscGetState(IN uint32 uiSubscHdl,
		                            IN uint32 uiDlgHdl);
/*! \brief Gets application UserData if the input dialog is associted with
           any of the subscriptions. 

    \param[in] uiDlgHdl Handle to the Dialog node.
    \return e_IFX_SIP_SUBSC_STATE 
*/
void * IFX_SIP_SUBSC_GetAppData(uint32 uiDlgHdl);

/*! \brief Destroy the Subscription abruptly.
    Called for destroying a Subscription.
    \param[in] uiSubscHdl Subscription Handle Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_SubscDestroy(IN uint32 uiSubscHdl);


/*! \brief Free the Subscription

     should be called by the application if any error occurs before
     subscSend is called.
    \param[in] uiSubscHdl Subscription Handle Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_FreeSubsc(IN uint32 uiSubscHdl);

/* @} */
#endif /* __IFX_SIP_EVTPKG_H__ */
