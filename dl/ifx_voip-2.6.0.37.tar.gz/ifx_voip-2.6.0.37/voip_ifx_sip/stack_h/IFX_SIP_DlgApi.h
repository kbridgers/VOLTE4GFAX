/**************************************************************************
**   FILE NAME     : IFX_SIP_DlgApi.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE     	   : 
**   AUTHOR        : SIP team
**   DESCRIPTION   : This file contains transaction user dialog functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS, DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   Software are granted

** Version Control Section **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_DlgApi.h
    \brief File containing the Constants, enumerations, related Data structures
     and API's for any SIP Dialog Management.

    Contains structure of subscriptions like dialog state, Auth Info etc.
*/
#ifndef __IFX_SIP_DLGAPI_H__
#define __IFX_SIP_DLGAPI_H__
/**  \ingroup SIP_API
	  \defgroup DLGAPI Dialog handling
    \brief This section lists the APIs for getting the dialog Information.
*/
/* @{ */


/*! 
    \brief An Enumeration defining Dialog States.
*/
typedef enum
{
  IFX_SIP_DIALOG_IDLE=0,/*!< Idle State */
  IFX_SIP_DIALOG_EARLY=1,/*!< Early State-  first request sent out 
                            and before it received 2xx */
  IFX_SIP_DIALOG_CONFIRMED=2/*!< Confirmed State- received 2xx */
} e_IFX_SIP_DialogState;


/*! \brief Gets the Confirmed dialog in case of the forked request
            returns the dialog on which 2XX was sent out.Can be used only
	    In Invite formed Dialogs
    \param[in] uiDlgListHdl Start of dialog List.
    \param[out] puiDlgHdl Found Dialog.
    \param[out] peEcode error If any during processing.
*/
PUBLIC e_IFX_SIP_Return
IFX_SIP_DLG_GetConfDialoginDlgList(IN uint32 uiDlgListHdl,
                                   OUT uint32 *puiDlgHdl,
                                   OUT e_IFX_SIP_Ecode* peEcode);


/*! \brief Gets the dialog in case of the forked request, there can be more
           than one dialogs.Based on the puiDlgHdl value the first or the next
	   to it is returned.
    \param[in] uiDlgListHdl Start of dialog List.
    \param[in,out] puiDlgHdl If null, the first dialog is returned
                   else the next one to it.
    \param[out] peEcode error If any during processing.
*/
PUBLIC e_IFX_SIP_Return
IFX_SIP_DLG_GetDialogFromList(IN uint32 uiDlgListHdl,
                              IN_OUT uint32 *puiDlgHdl,
                              OUT e_IFX_SIP_Ecode* peEcode);


/*! \brief Gets the State of the Dialog.
    \param[in] uiDlgHdl Dialog handler
    \return Dialog State early/confirmed.
*/
PUBLIC e_IFX_SIP_DialogState 
IFX_SIP_DLG_GetState(IN uint32 uiDlgHdl);


/*! \brief Gets the Call Id of the Dialog.
    \param[in] uiDlgHdl Dialog handler
    \return Get the Call ID.
*/
PUBLIC char8* IFX_SIP_DLG_GetCallId(IN uint32 uiDlgHdl);

/*! \brief Gets the From Tag of the Dialog.
    \param[in] uiDlgHdl Dialog handler
    \return Reference to the From Tag.
*/
PUBLIC char8* IFX_SIP_DLG_GetFromTag(IN uint32 uiDlgHdl);

/*! \brief Gets the To Tag of the Dialog.
    \param[in] uiDlgHdl Dialog handler
    \return Reference to the To Tag.
*/
PUBLIC char8* IFX_SIP_DLG_GetToTag(IN uint32 uiDlgHdl);


/* @} */
#endif /*__IFX_SIP_DLGAPI_H__*/

