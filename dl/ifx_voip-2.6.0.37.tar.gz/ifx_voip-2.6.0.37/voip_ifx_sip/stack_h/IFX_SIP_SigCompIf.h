/**************************************************************************
**   FILE NAME     : IFX_SIP_SigCompIf.h
**   PROJECT       : SIP
**   MODULES       : Sig Comp Interface
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team.
**   DESCRIPTION   : Function prototypes TU Client functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_SigCompIf.h
    \brief This File contains the SigComp Interface and Configuration Functions, with
           few enums used within all SIFCOMP API's.
*/
 /** \ingroup SIP_API
	   \defgroup SIGCOMP Signaling Compression
     \brief This section lists the functions for integrating third party sigcomp stacks.
*/
/* @{ */

#ifndef __IFX_SIP_SIGCOMPIF_H__
#define __IFX_SIP_SIGCOMPIF_H__

/*! 
    \brief An Enumeration defining return type for SIGCOMP API's.
*/
typedef enum{
  IFX_SIP_SIGCOMP_INIT_SUCCESS=0,/*!< SigComp Init Success*/
  IFX_SIP_SIGCOMP_INIT_FAIL=1,/*!< SigComp Init Failed*/
  IFX_SIP_SIGCOMP_SHUT_SUCCESS=2,/*!< SigComp Shut Success*/
  IFX_SIP_SIGCOMP_SHUT_FAIL=3,/*!< SigComp Shut Fail*/
  IFX_SIP_COMPARTMENT_CREATED=4,/*!< Compartment Created  */
  IFX_SIP_COMPARTMENT_CREATE_FAILED=5,/*!< Compartment Not Created */
  IFX_SIP_COMPARTMENT_EXISTS=6, /*!< Compartment already exists*/
  IFX_SIP_COMPARTMENT_CLOSED=7,/*!< Compartment has been closed */
  IFX_SIP_COMPARTMNET_CLOSE_FAILED=8,/*!< Compartment close failed */
  IFX_SIP_COMPARTMENT_RESET_SUCCESS=9,/*!< Compartment has been reset */
  IFX_SIP_COMPARTMENT_RESET_FAIL=10,/*!< Compartment reset failed */
  IFX_SIP_COMPRESSION_SUCCESS=11,/*!< compression Success*/
  IFX_SIP_COMPRESSION_FAIL=12,/*!< Parse Error in SIP Message*/
  IFX_SIP_DECOMPRESSION_FINISHED=13,/*!< Decompression Finished*/
  IFX_SIP_DECOMPRESSION_PROCESSING=14,/*!< Decomp Message in Processing*/
  IFX_SIP_DECOMPRESSION_FAIL=15,/*!< Decomp Message Fail*/
  IFX_SIP_DECOMPRESSION_UNSUPPORT_EOS=16,/*!< Decomp Message Not Ended with 0xff*/
  IFX_SIP_DECOMPRESSION_ILLEGAL=17,/*!< Decomp Message not from authorised endpoint*/
  IFX_SIP_COMPARTMENT_MATCHED=18,/*!< Compartment Matched for the decompressed message*/
  IFX_SIP_COMPARTMENT_MISMATCH=19,/*!< Compartment did not match for the decompressed message*/
} e_IFX_SIP_SigCompRetType;

/*! 
    \brief A structure used to interact with SIGCOMP stack running in a different context 
  	\note  This structure is used in case SIGCOMP runs in a different context.
 */
typedef struct
{
  e_IFX_SIP_SigCompRetType eRet;/*!< SIGCOMP status*/
  uint32 uiCompartmentId;/*!< Compartment Identifier */
  void *pvUserData;/*!< Application specific data */
  char8 *pcMsg;/*!< compressed/decompressed message*/
  uint32 uiLength;/*!< Lenght of the message */
}x_IFX_SIP_SigCompIpcMsg;

/*! \brief  API to notify SIP stack of the SIGCOMP operation status
  	\note  This structure is used in case SIGCOMP runs in a different context.
    \param[in]  pxStackNotMsg Notification message from SIGCOMP
    \return None. 
*/
void 
IFX_SIP_SigCompNotifyHandler(x_IFX_SIP_SigCompIpcMsg *pxStackNotMsg);

/* This x_IFX_SIP_SigCompIfApi and notify functions are provided
 *  Only for integrating third party sigcomp API's and should not be used
 *  by IMS project*/

/*! 
    \brief A structure defining function pointers for 
           interfacing External Provided SigComp Stacks.	  
  	\note  These Callbacks need to be registered only in the case 
           of SIGCOMP is Provided.
 */
typedef struct
{
	e_IFX_SIP_Return (*pfnSigCompInit)();/*!< Called on Initilizing SiGComp */	
  
	e_IFX_SIP_Return (*pfnSigCompShut)();/*!< Called on Initilizing SiGComp */
	
	e_IFX_SIP_Return(*pfnSigCompDecompressorInit)(
		uint32 uiDecompression_memory_size,
		uint32 uiCycles_per_bit,
		uint32 uiSigCompVer); /*!< Called to init decompressor */
        
	e_IFX_SIP_Return (*pfnCreateCompartment)(
        IN void *pvStackData);/*!< Called for creating compartment */

  e_IFX_SIP_Return (*pfnCloseCompartment)(
        IN uint32 uiCompId,
        IN void *pvStackData);/*!< Called for closing compartment */


  e_IFX_SIP_Return (*pfnResetCompartment)(
        IN uint32 uiCompId,
        IN void *pvStackData);/*!< Called for Reseting compartment */

  e_IFX_SIP_Return (*pfnCompressSipMsg)(
        IN uint32 uiCompId,
        IN uchar8 IsStreamBasedTransport,
        IN char8 *pcSipEncodedMsg,
        IN uint32 uiSipEncodeMsgLen,
        IN void *pvStackData);/*!< Called For Compressing Sip Message */
  
  e_IFX_SIP_Return (*pfnDeCompressSipMsg)(
        IN uchar8 IsStreamBasedTransport,
        IN void *pvSigCompMsg,
        IN uint32 uiSigCompMsgLen,
        IN void *pvStackData);/*!< Called For Decompressing Sip Message */
 
  e_IFX_SIP_Return (*pfnConfirmCompartment)(
        IN uint32 uiCompId,
        IN void *pvStackData); /*!< Called For providing Compartment to decompressor and aswell to verify*/

  

}x_IFX_SIP_SigCompIfApi;


/*! \brief  Registers callbacks for  SIGCOMP stack 
    \note   Inorder to make the stack independent of any sigcomp stack
            These callbacks have been provided, The stack shall call these
            callbacks approiatley within the stack just before handing over the
            encoded sip message to transport.For requests going out if the 
            request URI or the route set contains "comp=sigcomp" parameter, the
            message is compressed. for responses if the First Via contains the
            parameter "comp=sigcomp" the response id compressed and then handed 
            over to transport.
    \param[in] pvSigCompCallbks Callback function structure that shall be
               called by the stack to acheive sigcomp feature
    \param[in] uiMaxCompartments Max Compartments the stack can create
    \return None. 
*/
PUBLIC void 
IFX_SIP_RegisterSigCompCallBacks(IN x_IFX_SIP_SigCompIfApi *pvSigCompCallbks,
                                 IN uint32 uiMaxCompartments);


/*! \brief  Notification function for the stack to know the status of the 
            Previous Sigcomp request issued
    \note   Inorder to make the stack independent of any sigcomp stack
            A single notification function has been provided. The callbacks
            implemented by the stack users shall call this notification function.
            Once the request has been completed.All parameters in this function
            expcept eRet are not mandatory and shall be filled approriatley based
            on previous request.For Eg compartment_create shall call this notify
            function once compartment has been created and fills only pvUserData
            and uiCompartmentId. the rest are set to null.compress_request shall
            and decompress_request shalluse all the parameters.
    \param[in] eRet Status indication of the previous request issued
    \param[in] uiCompartmentId Compartment Identifier
    \param[in] pvUserData Stack identifier
    \param[in] pcMsg Compressed Msg or decompressed message
    \param[in] uiLength Length of compressed or decompressed message
    \return None. 
*/

PUBLIC void 
IFX_SIP_NotifyStackSigCompStatus(IN e_IFX_SIP_SigCompRetType eRet,
                                 IN uint32 uiCompartmentId,
                                 IN void *pvUserData,
                                 IN char8 *pcMsg,
                                 IN uint32 uiLength);

/* This is the only API provided for IMS project and should not be used by
 * third party SIGCOMP stack integrators*/
                                 
 /*! \brief   This function configure the SigComp 
				Stack.
 
    \param[in] uiDecompression_memory_size Decompression memory size
    \param[in] uiCycles_per_bit VDUM cycles per bit of decompression
    \param[in] uiSigCompVer Sigcomp version
    \param[in] uistate_memory_size Memory for storing state
    \param[in] pcalgorithm Algorithm used for compression
    \param[in] uiSigCompPort SIGCOMP port
    \param[in] uiNoOfCompartments Maximum number of compartments that can be created.
	\return void
*/                                
PUBLIC void 
IFX_SIP_SigCompCfg(IN uint32 uiDecompression_memory_size,
	                 IN uint32 uiCycles_per_bit,
	                 IN uint32 uiSigCompVer,
	                 IN uint32 uistate_memory_size,
                   IN const char8 *pcalgorithm,
                   IN uint32 uiSigCompPort,
                   IN uint32 uiNoOfCompartments);
/* @} */
#endif /*__IFX_SIP_SIGCOMPIF_H__*/
