/**************************************************************************
**   FILE NAME    : IFX_SIP_RegApi.h
**   PROJECT      : SIP 
**   MODULES      : Registration Interface
**   SRC VERSION  : V2.2.1
**   DATE         : 
**   AUTHOR       : SIP Team
**   DESCRIPTION  : APIs for using the SIP Registration Client.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
/*! \file IFX_SIP_RegApi.h
    \brief This File contains the Constants, enumerations, related 
     Data structures and API's for using the Registration Client functionality 
     provided by the stack.
*/
#ifndef __IFX_SIP_REGAPI_H__
#define __IFX_SIP_REGAPI_H_
 /**  \ingroup SIP_API
	   \defgroup REGAPI Registration
     \brief This section lists the functions and call backs for a registration client.
*/
/* @{ */

/*! 
    \brief An Enumeration describing Registration Client states. These states are set by the 
     stack and state change is notified to the application using the 
     callback provided, if any.
*/ 
typedef enum {
  IFX_SIP_REG_CLIENT_IDLE = 0,/*!< Default state when the Registration Client is created */
  IFX_SIP_REG_CLIENT_REGISTERING = 1,/*!< Set when client is waiting for response of registration request */
  IFX_SIP_REG_CLIENT_UNREGISTERING=2,/*!< Set when client is waiting for response of unregistration request */
  IFX_SIP_REG_CLIENT_PROXY_AUTH_REQD=3,/*!< Set when proxy authentication is required */
  IFX_SIP_REG_CLIENT_USER_AUTH_REQD=4,/*!<  Set when user authentication is required */
  IFX_SIP_REG_CLIENT_REGISTERED = 5,/*!<  Set when client has been registered */
  IFX_SIP_REG_CLIENT_UNREGISTERED=6,/*!<  Set when client has been unregistered */
  IFX_SIP_REG_CLIENT_REDIRECTED=7,/*!<  Set when redirect response is recieved */
  IFX_SIP_REG_CLIENT_TIMEOUT=8,/*!<  Set when registration request timeout occurs */
  IFX_SIP_REG_CLIENT_FAILED = 9/*!< Set when there is a failure of reqeust */
} e_IFX_SIP_RegisterClientState;


/*! 
    \brief Call backs for Registration client. These Call backs are to be
     registered with the SIP stack for implementation of Registration Client

     Order of Callback invocations:
     The callback given by pfnStateChanged is invoked whenever there is a state
     change of the Registration. The state handler MAY ignore certain state 
     changes such as IFX_SIP_REG_CLIENT_REGISTERING and IFX_SIP_REG_CLIENT_UNREGISTERING iff
     there is no action to be taken.
     When a response is received, the callback pfnRespArrived is invoked
     first. This is followed by invoking the callback pfnStateChanged.

     Registration Client Removal:
     The Registration Client is removed under one of the following circumstances
     1. There is unregistration request.
     2. There is failure in sending register request.
     3. Failure is returned by the callbacks. The callback functions may call
        other APIs provided(For Ex - IFX_SIP_RegAUthenticate()). 
    Application has to return a failure to the SIP stack , if it is 
	desired for the Registration Client to be removed on failure of any 
	of the intermediate APIs which were invoked.
*/
typedef struct
{
  /*! Called on Timeout or transport Error */
  e_IFX_SIP_Return (*pfnTimeOutOrError)(
                   e_IFX_SIP_TransErrorCode eErrorType,
                   IN uint32 uiRegHdl,
                   IN void *pvUserData);

  /*! Pointer to function which called before sending the SIP message to the
       peer. This allows the user to add some extension headers if desired. */
  e_IFX_SIP_Return  (*pfnMsgToEncode)(IN uint32 uiMsgHdl,
                                      IN uint32 uiRegHdl,
                                      IN void *pvUserData);
      
  /*! Pointer to function which called on receiving the response from the
       registrar. */
  e_IFX_SIP_Return (*pfnRespArrived)(IN uint32 uiMsgHdl,
                                     IN uint32 uiRegHdl,
                                     IN void *pvUserData);

  /*! Called on resolving DNS address. */
  e_IFX_SIP_Return  (*pfnDnsResolved)(IN uint32 uiRegHdl,
                                      IN void *pvUserData);
 
  /*! Called on state change. */
  e_IFX_SIP_Return (*pfnStateChanged)(e_IFX_SIP_RegisterClientState eRegState,
                                      IN uint32 uiRegHdl,
                                      IN void* pvUserData);
	uint32 uiStackHdl;/*!< Stack Instance Identifier*/
	
}x_IFX_SIP_RegClient_CallBk;


/*! \brief     This API registers the callbacks with the stack.
    \param[in] pxRegClientCallBk Pointer to the callbacks
*/
void 
IFX_SIP_RegClientRegisterCallBks(
               IN x_IFX_SIP_RegClient_CallBk *pxRegClientCallBk);

			
/*! \brief      Allows the user to create a Registration Client.
  	        A handle is returned to the user for subsequent operations.
    \param[in]  pvUserData User data pointer
    \param[out] puiRegHandle Registration handler
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CreateRegisterClient(IN  void*  pvUserData,
                             OUT uint32 *puiRegHandle);

/*! \brief  Associate Register handle to specfic Stack and Interface.
    \param[in] uiRegHandle Registration Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the registration will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_AssociateRegClient(IN uint32 uiRegHandle,
                           IN uint32 uiStackHdl,
                           IN uint32 uiIFHdl);


/*! \brief  Get Reg Client specfic Stack and Interface handles.
    \param[in] uiRegHandle RegClient Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_RegClientGetStackIf(IN uint32 uiRegHandle,
                         OUT uint32 *puiStackHdl,
                         OUT uint32 *puiIFHdl);


/*! \brief     Get the expiry time associated with the Registration Client. 
    \param[in] uiRegHandle Registration handler
    \return    Expiry value of the registration
*/
uint32
IFX_SIP_GetRegClientExpiry(IN uint32 uiRegHandle);


/*!  \brief     Get the state of the Registration Client.
    \param[in] uiRegHandle Registration handler
    \return    Registration state
*/
e_IFX_SIP_RegisterClientState
IFX_SIP_GetRegClientState(IN uint32 uiRegHandle);


/*! \brief     Remove the Registration Client. This function is called when
               there is a failure return from the application and when there is
               unregistration. 
    \param[in] uiRegHandle Registration handler
    \return    IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RemoveRegClient(IN uint32 uiRegHandle);

/*! \brief Destroy the RegClient transaction abruptly.

    Called for destroying a RegClient transaction.
    \param[in] uiRegHandle RegClient Handle Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_RegClientDestroy(IN uint32 uiRegHandle);


/*! \brief     This function sets the destination host address where the
               request is to be sent.

               It is used in cases where the destination is different from that
               specified in the request-uri or route-set if any.
               For Ex - An outbound proxy.
    \param[in] uiRegClientHdl Registration handler
    \param[in] pcRemoteAddr Remote Address
    \param[in] unLocalPort Local Port
    \param[in] unRemotePort Remote Port
    \param[in] eProtocol Transport Protcol
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SetRegClientNextHopAddr(IN uint32 uiRegClientHdl,
                             IN char8 *pcRemoteAddr,
                             IN uint16 unLocalPort,
                             IN uint16 unRemotePort,
                             IN e_IFX_SIP_Protocol eProtocol);


/*! \brief     Sends a Register request to the peer with the expires specified.
    \param[in] uiRegClientHdl Registration handler
    \param[in] uiMsgHdl Message handler
    \param[in] uiExpiry Time to expire the registration. If 0, the request is
               taken to be for Unregistration.
    \param[in] pcRegAddr Register address in ABNF format.
    \param[in] pcFrom From Address in ABNF format.
    \param[in] unTcpPort TCP port if used, else 0.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_SendRegisterRequest(IN uint32 uiRegClientHdl,
                            IN uint32 uiMsgHdl,
                            IN uint32 uiExpiry,
                            IN  char8* pcRegAddr,
                            IN  char8* pcFrom,
                            IN  uint16  unTcpPort);


/*! \brief    Get the Outbound message associated with the Registration Client.
    \param[in] uiRegClientHdl Registration handler
    \return Handle to the SIP message to be encoded
*/
uint32
IFX_SIP_RegGetMsgToEncode(IN uint32 uiRegClientHdl);


/*! \brief   Get the Incoming message associated with the Registration Client.
             This can be used to access information in a sip message.
    \param[in] uiRegClientHdl Registration handler
    \return Handle to the SIP message that was decoded
*/
uint32
IFX_SIP_RegGetDecodedMsg(IN uint32 uiRegClientHdl);

/*! \brief Adds the Authourization/Proxy-Authorization header to the sip 
           message.Can be called when 401/407 response is received for the
           transaction request. It adds the credential parameters to the 
           request.It can be used in state handler function given by 
           pfnStateChanged.
    \param[in] uiRegClientHdl Handle to the Register Client node
    \param[in] pcUserName Username for the specified REALM
    \param[in] pcPasswd Password for the specified REALM
    \param[in,out] uiSipMsgHdl Handle to SIP message being encoded
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RegAuthenticate(IN uint32 uiRegClientHdl,
                        IN char8 *pcUserName,
                        IN char8 *pcPasswd,
                        IN_OUT uint32 uiSipMsgHdl);


/*! \brief Used to send the REGISTER request to the next DNS resolved address.
           
           This API can be called in the function given by pfnTimeOutOrError
           when a dns error is received.
    \param[in] uiRegClientHdl Handle to the Register Client node
    \param[in] uiMsgHdl Handle to the message being sent
    \return    IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_RegSendReqToNxtAddr(IN uint32 uiRegClientHdl, IN uint32 uiMsgHdl);

/* @} */
#endif
