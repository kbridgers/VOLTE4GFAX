/**************************************************************************
**   FILE NAME    : IFX_SIP_CCApi.h
**   PROJECT      : SIP 
**   MODULES      : Call Control APIs provided by the SIP stack
**   SRC VERSION  : V2.2.1
**   DATE         : 
**   AUTHOR       : SIP Team
**   DESCRIPTION  : APIs for using the SIP registration client.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_SIP_CCAPI_H__
#define __IFX_SIP_CCAPI_H__
/*! \file IFX_SIP_CCApi.h
    \brief This File contains the Constants, enumerations, related Data 
    structures and API's for using the call control functionality provided 
    by the SIP stack.

    \note All the APIs accepting the Message handle will overwrite the mandatory     
	Dialog related headers in case they are already set by the user. 
	SIP stack takes care of freeing the Message handle and the Per call Information. 
	If the CreateCall API is not called it is the responsibility of the application 
	to free the message and the per call Information.
*/

 /** \ingroup SIP_API 
	   \defgroup CCAPI Call Control
     \brief This section lists the Call Control functions.
*/
/* @{ */


/*!
   \brief Enable auto forwarding from stack
*/
#define IFX_CC_AUTO_FWD 0x01

/*!
    \brief An Enumeration defining the Refresh preference.
*/    
typedef enum{
  IFX_SIP_REFRESH_UAC=1,/*!< Refresh UAC*/
  IFX_SIP_REFRESH_UAS=2, /*!< Refresh UAS*/
  IFX_SIP_REFRESH_NONE=3 /*!< Refresh is not set */
}e_IFX_SIP_CC_RefPrefType;


/*! \brief Listed below are the call backs that can be registered to be invoked
     during the course of a call. By default, action dues to INVITE, ACK, CANCEL and BYE 
     are reported. PRACK, UPDATE, INFO are realized based on the conditional 
     compilation.

     The order of Callback invocations for outgoing requests is as follows:
     The callback registered for pfnMsgToEncode is invoked whenever there is a
     request or a response going out.\n pvUserData given in IFX_SIP_CC_CreateCallInfo 
	 is provided in all the call backs that are called. Once a 1xx(non-100)/200 
	 response is received the call back registered for pfnDialogCreated is called 
	 followed by the call back registered for pfnRespArrived. pfnDialogCreated is called only once 
	 when the dialog is created. If IFX_SIP_CC_CreateCall leads to a condition where resolution of a 
	 FQDN address is required, the callbacks registered for DNS Query are invoked. On  
	 successful resolution of the address, the callback, pfnDnsResolved is invoked, 
	 followed by pfnMsgToEncode. In eventuality of a failure condition due to any of 
	 the following conditions , like destination not being reachable or a transport
	 error or DNS error or Transaction timing out, the error is intimated through
	 the registered callback pfnTimeOutOrError.\n

     The order of Callbacks invocation for Incoming requests is as follows:
     When the INVITE arrives the call back registered for pfnReqArrived is 
	 first invoked. If the INVITE causes a dialog to be created, the 
	 pfnDialogCreated callback. The ppvUserData provided in the pfnReqArrived 
	 call back is given in subsequent call backs.\n In case there is an erroneous 
	 condition due to which a dialog is not created, the pfnDialogCreated is not 
	 invoked, though the callbacks pfnMsgToEncode will be invoked.

    The code has to be compiled with the necessary flags for realizing the 
    required functionality. UPDATE(RFC_3311),PRACK(RFC_3262),INFO(INFO_SUPPORT)
*/
typedef struct
{
e_IFX_SIP_Return  
(*pfnReqArrived)(IN uint32 uiMsgHdl,
                 IN uint32 uiCCHdl,
                 IN_OUT void **ppvUserData);/*!< Intimate on reception of INVITE, ACK, CANCEL, PRACK, UPDATE, INFO, BYE. */

e_IFX_SIP_Return 
(*pfnTimeOutOrError)(IN e_IFX_SIP_TransErrorCode eErrorType,
                     IN uint32 uiCCHdl,
                     IN uint32 uiDlgHdl,
                     IN void *pvUserData);/*!< Called on Timeout of transaction or transport Error */

e_IFX_SIP_Return 
(*pfnMsgToEncode)(IN uint32 uiMsgHdl,
                  IN uint32 uiCCHdl,
                  IN void *pvUserData);/*!< Called before  message is encoded */

e_IFX_SIP_Return
(*pfnRespArrived)(IN uint32 uiMsgHd,
                  IN uint32 uiCCHdl,
                  IN uint32 uiDlgHdl,
                  IN void *pvUserData);/*!< Called on receptioon of response for any of the requests sent out viz. INVITE, ACK, CANCEL, PRACK, UPDATE, INFO, BYE */

e_IFX_SIP_Return
(*pfnDnsResolved)(IN uint32 uiCCHdl,
                  IN void *pvUserData);/*!<Called on resolving DNS address */

e_IFX_SIP_Return
(*pfnDialogCreated)(IN uint32 uiCCHdl,
                    IN uint32 uiDlgHdl,
                    IN void *pvUserData);/*!<Called on creation of a new dialog */
int32 iFlag;/*!< Indicates the additional functionality requested from the 
                 stack viz Auto forwarding option*/

uint32 uiStackHdl;/*!< Stack Instance Identifier*/

}x_IFX_SIP_CCCallBacks;



/*! \brief  Registers the Call control Call back functions.
    \param[in] pxCCCB Call control call back functions
    \note Functions that are not being registered should be set to NULL.
	      This API should be usually called before initialization of stack.
		  Subsequent calls to this API would result in overwriting the previously
		  registered functions with the new functions.
*/
void
IFX_SIP_CC_RegisterCB(IN x_IFX_SIP_CCCallBacks *pxCCCB);

/*! \brief  Creates an per call Information block and returns the handle to the             same.
    \param[in] pvData User Application data associated with the Call
    \param[out] puiCallHdl Call Handle  
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_CreateCallInfo(IN void *pvData,
                          OUT uint32 *puiCallHdl);

/*! \brief  Associate Call handle to specfic Stack and Interface.
    \param[in] uiCallHdl Call Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the call will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_CC_AssociateCall(IN uint32 uiCallHdl,
                         IN uint32 uiStackHdl,
                         IN uint32 uiIFHdl);

/*! \brief  Get Call handle  specfic Stack and Interface Handles.
    \param[in] uiCallHdl Call Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_CC_GetStackIf(IN uint32 uiCallHdl,
                      OUT uint32 *puiStackHdl,
                      OUT uint32 *puiIFHdl);


/*! \brief  Remove per call Information block.
    \param[in] uiCallHdl Call Handle  
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    \note should be used only if the CreateCallInfo is called and CreateCall is not called
*/
e_IFX_SIP_Return
IFX_SIP_CC_RemoveCallInfo(IN uint32 uiCallHdl);

/*! \brief  Clear all call Information block.
    \param[in] void  
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return IFX_SIP_ClearAllCallInfo();

/*! \brief  Set the Next Hop Address.

    This API should be called before calling IFX_SIP_CC_CreateCall. This 
    ensures that the request be sent to a different address other than the
    one szTo given in IFX_SIP_CC_CreateCall. Useful when an outbound proxy
    is configured or a pre-set route exists to that destination.
    
    \note If a valid unLocalPort is given SIP toolkit will use the same for 
          establishing a TCP connection, otherwise it would pick a dynamic
          port for establishing TCP connection. This would also be used in
          all the cases where there is a switchover to TCP.

    \param[in] uiCallHdl Call Handle
    \param[in] pcRemoteAddr Remote Address.
    \param[in] unLocalPort Used when establishing a TCP connection. For UDP the                            configured server port is used.
    \param[in] unRemotePort If 0, 5060 is assumed as remote port.
    \param[in] eProtocol Unless pcRemoteAddr is FQDN, if eProtocol is not set
                         UDP is assumed.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_SetNextHopAddr(IN uint32 uiCallHdl,
                             IN char8 *pcRemoteAddr,
                             IN uint16 unLocalPort,
                             IN uint16 unRemotePort,
                             IN e_IFX_SIP_Protocol eProtocol);

/*! \brief  Constructs and sends INVITE request to the destination.

    If the destination is an FQDN this call would return success immidiately. On successfully resolving the address pfnDnsResolved followed by pfnMsgToEncode are invoked. Incase SIP stack fails to resolve the FQDN pfnTimeOutorError call back is invoked. If the destination is an IP address, pfnMsgToEncode is call before this function returns. User might decide to add additional headers/SDP in pfnMsgToEncode Callback or populate and give the message handle.
    \param[in] uiCallHdl Call Handle
    \param[in] uiMsgHdl Reason SIP Msg Handle created using the Message APIs.
    \param[in] szFrom Source address in ABNF format defined for FROM header
    \param[in] szTo To Address in ABNF format defined for TO header
	\param[in] unLocalClientPort Local Client Port
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_CreateCall(IN uint32 uiCallHdl,
		                  IN uint32 uiMsgHdl,
                      IN char8 *szFrom,
                      IN char8 *szTo,
                      IN uint16 unLocalClientPort);

/*! \brief  Accept an Incoming call.

    Leads to sending of a 1xx class response for the Invite received. Sends a 180 response if the iReliable is set to 0. 183 response with a RSeq header is sent in case iReliable is set to 1. If the status code has to be changed pfnMsgToEncode could be used.
    \param[in] uiCallHdl Call handle
    \param[in] uiMsgHdl Reason SIP Msg Hdlr.
    \param[in] iReliable Indicates the request for sending reliable provisional response.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    \note For proper functioning of the stack use Accept call to send a 1xx class response. IFX_SIP_CC_SendResponse should be used for Re-Invites and other methods.
*/
e_IFX_SIP_Return
IFX_SIP_CC_AcceptCall(IN uint32 uiCallHdl,
		                  IN uint32 uiMsgHdl,
                      IN int32 iReliable);

/*! \brief  Answer an Incoming call.

    Leads to sending of a 200 class response for the Invite received.
    \param[in] uiCallHdl Call handle
    \param[in] uiMsgHdl Reason SIP Msg Hdlr.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    \note For proper functioning of the stack use Answer call to send a 2xx class response. IFX_SIP_CC_SendResponse should be used for Re-Invites and other methods.
*/
e_IFX_SIP_Return
IFX_SIP_CC_AnswerCall(IN uint32 uiCallHdl,
		                  IN uint32 uiMsgHdl);


/*! \brief  Reject an Incoming INVITE

    Leads to sending of a Failure response with the given status code and reason phrase.
    \param[in] uiCallHdl Call handle
    \param[in] uiMsgHdl Reason SIP Msg Handle.
    \param[in] nStatusCode Status code to be sent
    \param[in] szReasonPhrase Reason phrase to be used.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    \note For proper functioning of the stack use Reject call to send a 3/4/5/6xx class responses. IFX_SIP_CC_SendResponse should be used for Re-Invites and other methods.
*/
e_IFX_SIP_Return
IFX_SIP_CC_RejectCall(IN uint32 uiCallHdl,
		                  IN uint32 uiMsgHdl,
                      IN int16 nStatusCode,
                      IN char8 *szReasonPhrase);



/*! \brief  Sends a response with the appropriate status code and reason phrase.

    Used to accept,reject, send provisional response to any request,Re-Invite
    Additional headers could be added in pfnMsgToEncode Callback
    \param[in] uiCallHdl Call Handle
    \param[in] uiMsgHdl Message handle
    \param[in] nStatusCode Status Code to be sent
    \param[in] szReasonPhrase Reason phrase to be used.
    \param[in] uiDlgHdl Dialog to be used. If the response is not being send immidiately this information can be used to populate the message.
    \param[in] szMethod Method for which response is being sent.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_SendResponse(IN uint32 uiCallHdl,
                        IN uint32 uiMsgHdl,
                        IN int16 nStatusCode,
                        IN char8 *szReasonPhrase,
                        IN uint32 uiDlgHdl,
                        IN char8 *szMethod);

/*! \brief  Adds Authorization header to the SIP Msg.

    Given the User Name and password associated with the realm the SIP stack constructs and sends a new request with the Authorization/Proxy-Authorization Header. In case the Algorithm is MD5 stack takes care of computing the response. If the Algorithm is anything other than MD5 the application registered call back is called which should take care of adding the necessary headers with appropriate response.
    \param[in] uiCallHdl Call Handle
    \param[in] pcUserName User name associated with the realm
    \param[in] pcPasswd Password associated with the realm
    \param[in,out] uiSipMsgHdl Reason SIP Message Handle.    
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
    \note This API can be called only in the context of pfnRespArrived Callback.
*/
e_IFX_SIP_Return
IFX_SIP_CC_Authenticate(IN uint32 uiCallHdl,
                        IN char8 *pcUserName,
                        IN char8 *pcPasswd,
                        IN_OUT uint32 uiSipMsgHdl);

/*! \brief  Release the SIP Call

    Releases the SIP call, CANCEL or BYE would be sent based on the state of the call. Call leg is terminated on reception of a 2xx for BYE or 487 for Invite.Call leg memory shall be freed after receving final response for bye/invite(only 487 resp)
    \param[in] uiCallHdl Call Handle
    \param[in] uiMsgHdl Reason SIP Msg Hdlr.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_ReleaseCall(IN uint32 uiCallHdl,
		                   IN uint32 uiMsgHdl);

/*! \brief  Sends a request inside the given dialog Handle

    Can be used for sending INFO,RE-INVITE,PRACK,UPDATE or new methods on the same dialog.The request will have the To, From and 
    Call-ID of the call-leg and will be sent with a current CSeq step. It will be record routed if needed.
    \param[in] uiCallHdl Call Handle
    \param[in] uiMsgHdl Msg handle
    \param[in] uiDlgHdl Dialog to be used. Sends the request over the dialog created because of Invite
    \param[in] szMethod Request being sent.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_SendRequest(IN uint32 uiCallHdl,
                       IN uint32 uiMsgHdl,
                       IN uint32 uiDlgHdl,
                       IN char8 *szMethod);

/*! \brief  Gets the pointer to the head of the dialog.
    \param[in] uiCallHdl Call Handle
    \param[in] puiDlgHeadHdl Dialog head handle
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_GetDialogHead(IN uint32 uiCallHdl,
                         OUT uint32 *puiDlgHeadHdl);

/*! \brief  Returns the Sends Re-Invite to the peer.

    Can be called only in the message to encode call back.
    \param[in] uiCallHdl Call Handle
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
uint32 
IFX_SIP_CC_GetMsgToEncode(IN uint32 uiCallHdl);


/*! \brief  Get the Incoming SIP message.

    Can be used only in RequestReceived call back.
    \param[in] uiCallHdl Call Handle
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
uint32
IFX_SIP_CC_GetDecodedMsg(IN uint32 uiCallHdl);


/*! \brief  Sends Re-Invite to the peer.
    \param[in] uiCallHdl Call Handle
    \param[in] uiMsgHdl Message handle
    \param[in] uiDlgHdl Dialog handle
    \param[in] eMethod Method (Re-Invite or Update)
               to be used for refreshing
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_SessionRefresh(IN uint32 uiCallHdl,
                          IN uint32 uiMsgHdl,
                          IN uint32 uiDlgHdl,
                          IN e_IFX_SIP_BasicMethod eMethod);

/*! \brief  Sets Session refresh parameters.

    should be call before Sending Invite/RE-Invite
    \param[in] uiCallHdl Call Handle
    \param[in] uisessionExpires Session expiry time offerd by the client.
    \param[in] uiMinSE Minimum Session expiry time accepted by the server
    \param[in] eRefPref Refresher preference for the session.
    \note if uisessionExpires is non-zero SE and refresher params are added
          in an outgoing invite. if uiMinSE is non-zero Min-SE header will be
          added
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_CC_SetSessionRefreshParam(IN uint32 uiCallHdl,
                                  IN uint32 uisessionExpires,
                                  IN uint32 uiMinSE,
                                  IN e_IFX_SIP_CC_RefPrefType eRefPref);

/*! \brief  Send request to next resolved DNS address.

    \param[in] uiCallHdl Call Handle
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return
IFX_SIP_CC_TryNextAddr(IN uint32 uiCallHdl);

/*! \brief  Get App data for given dialog.

    \param[in] uiDlgHdl Dialog handle
    \return Reference to App data
*/
void*
IFX_SIP_CC_GetAppData(IN uint32 uiDlgHdl);

#ifdef IFX_APP_ACK
/*! \brief  Sends Ack manually.
    \param[in] uiCallHdl Call handle
    \param[in] uiMsgHdl Message handle
    \param[in] uiDlgHdl Dialog handle
    \return IFX_SIP_SUCCESS/IFX_SIP_FAILURE
    \note Can be used only when compiled with IFX_APP_ACK flag
*/
e_IFX_SIP_Return
IFX_SIP_CC_SendAck(IN uint32 uiCallHdl,
		               IN uint32 uiMsgHdl,
                   IN uint32 uiDlgHdl);
#endif
/* @} */

#endif
