/**************************************************************************
**   FILE NAME      : IFX_SIP_Options.h
**   PROJECT        : SIP
**   MODULES        : Transaction User
**   SRC VERSION    : V2.0
**   DATE           : 15-12-2004
**   AUTHOR         : SIP Team
**   DESCRIPTION    : This contains the functions to send and receive OPTIONS.
**   COMPILER       : gcc
**   REFERENCE      :
**   COPYRIGHT      : Copyright (c) 2004
**                    Infineon Technologies AG, st. Martin Strasse 53;
**                    81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_Options.h
    \brief File containing the Constants, enumerations, related Data structures
     and API's for any SIP Message construction.

*/
#ifndef __IFX_SIP_OPTIONS_H__
#define __IFX_SIP_OPTIONS_H__
 /**  \ingroup SIP_API
	   \defgroup OPTIONSAPI OPTIONS Method
     \brief This section lists the Callbacks and functions for handling OPTIONS method.
*/
/* @{ */



/*! 
    \brief Listed below are the callbacks functions which can be registered for 
	handling Option Message.

     Order of Callback invocations for outgoing request:
     The callback  pfnMsgToEncode is invoked whenever there is a request
     or a response going out. When a response arrives for the request, which 
     had been sent out, the callback pfnMsgRespArrived is invoked     

     Order of Callbacks invocation for Incoming request:
      On receiving an incoming request the callback pfnReqArrived is invoked , 
      the appliction can now associate this transaction with a new UserData.

    If the OPTIONS request is challenged by 401/407  Response
     The API IFX_SIP_OptionsAuthenticate MUST be invoked within the
     pfnRespArrived callback.Transaction is automatically freed in case the below 
     callback's returns IFX_SIP_FAILURE.

*/
typedef struct
{
   e_IFX_SIP_Return (*pfnRequestArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiOptionsHdl,
                        IN uint32 uiDialogId,
                        IN_OUT void **ppvUserData);/*!< Called on Request arrival */

  e_IFX_SIP_Return (*pfnTimeOutOrError)(
                        e_IFX_SIP_TransErrorCode eErrorType,
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData);/*!< Called on Timeout or transport Error */

  e_IFX_SIP_Return  (*pfnMsgToEncode)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData);/*!< Called before  message is encoded */

  e_IFX_SIP_Return (*pfnRespArrived)(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData);/*!< Called on Response Arrival */

  e_IFX_SIP_Return  (*pfnDnsResolved)(
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData);/*!<Called on resolving DNS address */

  uint32 uiStackHdl; /*!< Stack Instance Identifier*/
	
}x_IFX_SIP_OptionsCallBks;


/* API to SIP User agent*/
/*! \brief Register all Call backs for SIP OPTIONS Method.
    \param[in] pxCallBacks Structure to the OPTIONS Callback functions
*/
 void
IFX_SIP_OptionsRegisterCallBk(IN x_IFX_SIP_OptionsCallBks *pxCallBacks);


/*! \brief Creates a OPTIONS node.
    \param[in] pvUserData User Data to be supplied at all call backs
    \param[out] puiOptionsHdl Handle to the OPTIONS node
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_OptionsCreate(IN void *pvUserData,
                      OUT uint32 *puiOptionsHdl); 

/*! \brief  Associate OPTIONS handle to specfic Stack and Interface.
    \param[in] uiOptionsHdl OPTIONS Handle
    \param[in] uiStackHdl Stack Instance Hdl
    \param[in] uiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
	\note If this api is not invoked, the subscription will be associated with the first
	       stack and interface handles.
*/
e_IFX_SIP_Return
IFX_SIP_AssociateOptions(IN uint32 uiOptionsHdl,
                         IN uint32 uiStackHdl,
                         IN uint32 uiIFHdl);

/*! \brief  Get OPTIONS handle  specfic Stack and Interface Handles.
    \param[in] uiOptionsHdl OPTIONS Handle
    \param[out] puiStackHdl Stack Instance Hdl
    \param[out] puiIFHdl Transport Interface Hdl
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
e_IFX_SIP_Return 
IFX_SIP_OptionsGetStackIf(IN uint32 uiOptionsHdl,
                      OUT uint32 *puiStackHdl,
                      OUT uint32 *puiIFHdl);



/*! \brief Sets the next hop address of the SIP request.
    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \param[in] pcRemoteAddr remote Address
    \param[in] unLocalPort Local Port
    \param[in] unRemotePort Remote Port
    \param[in] eProtocol Transport Protcol
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_OptionsSetNextHopAddr(IN uint32 uiOptionsHdl,
                              IN char8 *pcRemoteAddr,
                              IN uint16 unLocalPort,
                              IN uint16 unRemotePort,
                              IN e_IFX_SIP_Protocol eProtocol);

/*! \brief Sends out the Option request with the given from and to address.

    If option request need to be sent out within a dialog, then the dialog related
    parameter should be filled in the message at pfnMsgToEncode callback.

    \note The Option Handler is freed once a final response is arrived.
    This API Free's the uiMsgHdl and uiOptionsHdl if any internal error occured.

    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \param[in] uiMsgHdl SIP Message Handle.
    \param[in] pcTo To Address
    \param[in] pcFrom From Addess
    \param[in] uiDlgHdl Dialog Handle
    \param[in] unTcpClientPort Client port to be used when establishing TCP connection.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_OptionsSendReq(IN uint32 uiOptionsHdl,
                       IN uint32 uiMsgHdl,
                       IN char8 *pcTo,
                       IN char8 *pcFrom,
                       IN uint32 uiDlgHdl,
		       IN uint16 unTcpClientPort);

/*!  \brief Sends the SIP request on the next DNS Resolved Address on transaction timeout 

    \note The Option Handler is freed once a final response is arrived.
    This API Free's the uiMsgHdl and uiOptionsHdl if any internal error occured.
    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \param[in] uiSipMsgHdl Handle to the SIP Message
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
e_IFX_SIP_Return
IFX_SIP_OptionsSendReqToNxtAddr(IN uint32 uiOptionsHdl,IN uint32 uiSipMsgHdl);

/*! \brief Sends out the response to the received OPTIONS request.

    The OPTIONS response is constructed with the given response code 
    and reason phrase if reason phrase is null default reason is sent.

    \note This API Free's the uiMsgHdl and uiOptionsHdl 
          if any internal error occured.
    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \param[in] uiMsgHdl SIP Msg Handle
    \param[in] eRespCode Response code
    \param[in] szReasonPhrase  Reason phrase to be sent out in the response line
    \param[in] unPort Port to be used
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
 e_IFX_SIP_Return
IFX_SIP_OptionsSendResp(IN uint32 uiOptionsHdl,
		        IN uint32 uiMsgHdl,
		        IN uint32 eRespCode,
                        IN char8 *szReasonPhrase,
                        IN uint16 unPort);

/*! \brief Gets the message to encode.
    
    These API's can be used only within the pfnRegArrived and pfnRespArrived Functions
    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \return Handle to SIP Message
*/
PUBLIC uint32
IFX_SIP_OptionsGetMsgToEncode(IN uint32 uiOptionsHdl);

/*! \brief Gets the message to decode.
    
    These API's can be used only within the pfnMsgToEncode  Functions.
    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \return Handle to SIP Message
*/
uint32
IFX_SIP_OptionsGetDecodedMsg(IN uint32 uiOptionsHdl);


/*! \brief Adds the Auth header to the SIP message and sends it out.

    \note MUST be called with the callback pfnRespArrived.

    Can be called when 401/407 response recived for the transaction request.
    \param[in] uiOptionsHdl Handle to the OPTIONS node
    \param[in] pcUserName User name
    \param[in] pcPasswd Password
    \param[in,out] uiMsgToEncode Handle to SIP  message
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIP_OptionsAuthenticate(IN uint32 uiOptionsHdl,
                            IN char8 *pcUserName,
                            IN char8 *pcPasswd,
                            IN uint32 uiMsgToEncode);


/*! \brief Free's the  memory associated with the Option node.
 
    The User application has to take care of clearing the option node
    for both client and server.
    \param[in] uiOptionsHdl Handle to the OPTIONS node
*/
PUBLIC void
IFX_SIP_OptionsFree(IN uint32 uiOptionsHdl);

/*! \brief Destroy the OPTIONS transaction abruptly.

    Called for destroying a OPTIONS transaction.
    \param[in] uiOptionsHdl OPTIONS Handle Identifier
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

e_IFX_SIP_Return
IFX_SIP_OptionsDestroy(IN uint32 uiOptionsHdl);

/* @} */
#endif /* __IFX_SIP_OPTIONS_H__*/

