/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator :  
 *        File    : ifx_src_voip_sip_codec.c
 *        Abstract: CGI API's to Codec Settings 
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
 

extern int g_LINE_ID_IS;
static uchar8 aucPrio[15][2];
static uchar8 g_ucNoOfPrioCodec;

static x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodec;
static  x_IFX_VMAPI_LineCodecList xLineCodec;
static char_t f_cflag = 0;

int ifx_get_FirmwareSupportedCodecs_vmapi (int eid, httpd_t wp, int argc,
                                       char_t ** argv);
int ifx_get_T38ChangeFunction_vmapi (int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_SelectT38CheckBoxes_vmapi (int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_getArrayIndexofCodec_vmapi (x_IFX_VMAPI_CodecDesc * xCodec, int32 * unNoOfCodecs,uint32 * unPayLoad,
                               uint32 uiCodecId);
void ifx_setSelectedFrameSize(httpd_t wp,int32 nSelIndex,int32 closeRow,uint32 uiCodecId);


/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_codec
 *  Description     : This function is called void_line_codec.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_codec (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];
  int32 nSelIndex = 0, nArrCodecIndex = 0;
  uint32 unSelPayLoad;
	x_IFX_VMAPI_CodecDesc *pxTemp;
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
    
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
  memset (sValue, 0x00, MAX_DATA_LEN);

  if(g_LINE_ID_IS < 1)
  {
    return -1;
  }

if(f_cflag == 0){
  memset(&xLineCodec,0,sizeof(x_IFX_VMAPI_LineCodecList));
  xLineCodec.ucLineId = g_LINE_ID_IS;
  xLineCodec.iid.config_owner = IFX_WEB;
  if ( ifx_get_LineCodecList(&xLineCodec,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, "<GET CODEC>Fail to GET the Line Codec List !!!");
    return -1;
  }
		memset(&xVoiceCodec,0,sizeof(xVoiceCodec));	
  	xVoiceCodec.iid.config_owner = IFX_WEB;
  	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceCodecCaps(&xVoiceCodec,0))
  	{
    	ifx_httpdError (wp, 200, "<UserManagement>Fail to GET the Voice Codec Capabilities !!!");
    	return -1;
  	}
	ifx_vmapi_freeObjectList(&xVoiceCodec,IFX_VMAPI_CODEC_CAPABS);
f_cflag = 1;
}
  pxTemp = xLineCodec.pxCodecList;
  if (!gstrcmp (name, T ("g711_alaw")))
    
  {
    
    /* Get the array index for g711_alaw */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,					
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G711_ALAW);

    		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G711_ALAW &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp,
                     "<input type=\"checkbox\" value=\"1\" name=\"g711_alaw\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g711_alaw\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,1,IFX_VMAPI_CODEC_G711_ALAW);
		return 0;
  }
  else if (!gstrcmp (name, T ("g711_ulaw")))
    
  {
    
    /* Get the array index for g711_ulaw */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G711_ULAW);
    		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G711_ULAW &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp,
                     "<input type=\"checkbox\" value=\"1\" name=\"g711_ulaw\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g711_ulaw\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,1,IFX_VMAPI_CODEC_G711_ULAW);
		return 0;
  }
  
  else if (!gstrcmp (name, T ("g723")))
    
  {
    /* Get the array index for g723 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G723);
        

    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G723 &nbsp;");
		if(xLineCodec.uiPrefG723Codec == 0/*IFX_VMAPI_CODEC_G723_5_3*/)
		ifx_httpdWrite (wp, "Preferred - <select name=\"p723list\" size=\"1\"><option value=\"0\" selected>G723_5_3</option><option value=\"1\">G723_6_3</option></select>");
		else
		ifx_httpdWrite (wp, "Preferred - <select name=\"p723list\" size=\"1\"><option value=\"1\" selected>G723_6_3</option><option value=\"0\">G723_5_3</option></select>");
		ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"checkbox\" value=\"1\" " 
                     "name=\"g723\"");
		
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 30;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                      " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp, "<td >\n");
    ifx_httpdWrite (wp, "<select name=\"pframe_g723\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,1,IFX_VMAPI_CODEC_G723_5_3);
		return 0;
  }
  else if (!gstrcmp (name, T ("g729_8")))
  {
    
    /* Get the array index for g729_8 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               /*xLineCodec.uiNumCodecs*/&nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G729_8);
    
			
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G729_8 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"checkbox\" value=\"1\" " 
                     "name=\"g729_8\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, "");
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                      "<td>\n\t<select name=\"pframe_g729_8\" " 
                      "size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,1,IFX_VMAPI_CODEC_G729_8);
    
		return 0;
  }
  else if (!gstrcmp (name, T ("g729_e")))
    
  {
    
#ifndef IIP /* ATA / AMAZON */
    /* Get the array index for g729_e */ 
    nArrCodecIndex =
      ifx_getArrayIndexofCodec_vmapi (pxTemp,
                                /*xLineCodec.uiNumCodecs*/&nSelIndex, 
																							 &unSelPayLoad,  
																IFX_VMAPI_CODEC_G729_E);

		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G729_E &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"checkbox\" " 
                     "value=\"1\" name=\"g729_e\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g729_e\" " 
                     "size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,0,IFX_VMAPI_CODEC_G729_E);
 
		/* Not Configured Codec . So display the default values */ 
    if (nArrCodecIndex == -1)
      
    { 
      ifx_httpdWrite (wp, T ("\t<td> <input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\"name=\"dynpt_g729_e\" value=\"100\">\n"));
    }
    /* Configured Codec */ 
    else
    {
			
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\" name=\"dynpt_g729_e\" " 
                              "value=\"%d\" onblur=\"DynPayload_onblur(29);\">\n"),
                       /*pxTemp->ucPayloadType*/unSelPayLoad);
    }
    ifx_httpdWrite (wp, "</td>\n");
    ifx_httpdWrite (wp, "</tr>\n");

		return 0;
    
#endif  /*ATA*/
  }

  else if (!gstrcmp (name, T ("g728")))
    
  {
    
#ifndef IIP
    /* Get the array index for g728 */ 
    nArrCodecIndex =
      ifx_getArrayIndexofCodec_vmapi (pxTemp,
                                /*xLineCodec.uiNumCodecs*/&nSelIndex,
																							 &unSelPayLoad,  
															 	IFX_VMAPI_CODEC_G728);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G728 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"checkbox\" value=\"1\" name=\"g728\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp, "<td>\n\t<select name=\"pframe_g728\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,1,IFX_VMAPI_CODEC_G728);
		return 0;
#endif  /*ATA*/
  }
  else if (!gstrcmp (name, T ("g726_16")))
  {
    
    /* Get the array index for g726_16 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                              /* xLineCodec.uiNumCodecs*/&nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G726_16);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G726_16 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"checkbox\" value=\"1\" " 
                     "name=\"g726_16\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    { 
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g726_16\" " 
                     "size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,0,IFX_VMAPI_CODEC_G726_16);
      
    /* Not Configured Codec . So display the default values */ 
    if (nArrCodecIndex == -1)
      
    { 
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\"name=\"dynpt_g726_16\" value=\"101\">\n"));
    }
    /* Configured Codec */ 
    else
      
    {
			
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\" name=\"dynpt_g726_16\" " 
                              "value=\"%d\" onblur=\"DynPayload_onblur(16);\">\n"),
                       /*pxTemp->ucPayloadType*/unSelPayLoad);
    }
    ifx_httpdWrite (wp, "</td>\n");
    ifx_httpdWrite (wp, "</tr>\n");
		return 0;
  }
  
  else if (!gstrcmp (name, T ("g726_24")))
    
  {
    
    /* Get the array index for g726_24 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G726_24);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G726_24 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp,
                     "<input type=\"checkbox\" value=\"1\" name=\"g726_24\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g726_24\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,0,IFX_VMAPI_CODEC_G726_24);
    
      /* Not Configured Codec . So display the default values */ 
      if (nArrCodecIndex == -1)
      
    {
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\"	name=\"dynpt_g726_24\" value=\"102\">\n"));
    }
    
      /* Configured Codec */ 
      else
      
    {
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\" name=\"dynpt_g726_24\" value=\"%d\" "
                               "onblur=\"DynPayload_onblur(24);\">\n"),
                       /*pxTemp->ucPayloadType*/unSelPayLoad);
    }
    ifx_httpdWrite (wp, "</td>\n");
    ifx_httpdWrite (wp, "</tr>\n");
		return 0;
  }
  
  else if (!gstrcmp (name, T ("g726_32")))
  {
    
    /* Get the array index for g726_32 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G726_32);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G726_32 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp,
                     "<input type=\"checkbox\" value=\"1\" name=\"g726_32\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, "");
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g726_32\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,0,IFX_VMAPI_CODEC_G726_32);
    
      /* Not Configured Codec . So display the default values */ 
      if (nArrCodecIndex == -1)
      
    {
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\"" 
                              "size=\"5\"name=\"dynpt_g726_32\" value=\"103\">\n"));
    }
    
      /* Configured Codec */ 
      else
      
    {
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\" name=\"dynpt_g726_32\" value=\"%d\" "
                               "onblur=\"DynPayload_onblur(32);\">\n"),
                       /*pxTemp->ucPayloadType*/unSelPayLoad);
    }
    ifx_httpdWrite (wp, "</td>\n");
    ifx_httpdWrite (wp, "</tr>\n");
		return 0;
  }
  else if (!gstrcmp (name, T ("g726_40")))
  {
    
    /* Get the array index for g726_40 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G726_40);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G726_40 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp,
                     "<input type=\"checkbox\" value=\"1\" name=\"g726_40\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g726_40\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,0,IFX_VMAPI_CODEC_G726_40);
    
      /* Not Configured Codec . So display the default values */ 
      if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\"" 
                              "size=\"5\"name=\"dynpt_g726_40\" value=\"104\">\n"));
    }
      /* Configured Codec */ 
      else
      
    {
      ifx_httpdWrite (wp, T ("\t<td><input type=\"int\" maxLength=\"5\" " 
                              "size=\"5\"name=\"dynpt_g726_40\" value=\"%d\" " 
                              "onblur=\"DynPayload_onblur(40);\">\n"),
                       /*pxTemp->ucPayloadType*/unSelPayLoad);
    }
    ifx_httpdWrite (wp, "</td>\n");
    ifx_httpdWrite (wp, "</tr>\n");
		return 0;
  }
  
  else if (!gstrcmp (name, T ("g722_64")))
  {
    
      
    /* Get the array index for g722_64 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_G722_64);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td> \n");
    ifx_httpdWrite (wp, "G722_64 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp,
                     "<input type=\"checkbox\" value=\"1\" name=\"g722_64\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
      nSelIndex = 20;
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  
    }
    ifx_httpdWrite (wp,
                     " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp,
                     "<td>\n\t<select name=\"pframe_g722_64\" size=\"1\">\n");
		ifx_setSelectedFrameSize(wp,nSelIndex,1,IFX_VMAPI_CODEC_G722_64);
		return 0;
  }
  else if (!gstrcmp (name, T ("t38p")))
    
  {
#ifndef IIP
      ifx_httpdWrite (wp, T ("if(fieldName == \"t38\")\n{\n"));
    ifx_httpdWrite (wp, "ChangeT38();\n");
    ifx_httpdWrite (wp, T ("}\n"));
#endif  
		return 0;
  }
  
  else if (!gstrcmp (name, T ("t38")))
    
  {
    
#ifndef IIP
    /* Get the array index for t38 */ 
    nArrCodecIndex = ifx_getArrayIndexofCodec_vmapi (
                                               pxTemp,
                                               &nSelIndex,
																							 &unSelPayLoad,  
                                               IFX_VMAPI_CODEC_T38);
		
    ifx_httpdWrite (wp, "<tr>\n");
    ifx_httpdWrite (wp, "<td>\n");
    ifx_httpdWrite (wp, "T38 &nbsp;");
    ifx_httpdWrite (wp, "</td>");
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"checkbox\" value=\"1\" name=\"t38\"");
    
    /* Not Configured Codec , so unchecked */ 
    if (nArrCodecIndex == -1)
    {
      ifx_httpdWrite (wp, ""); 
    }
    /* Configured Codec , so Checked */ 
    else
    {
      ifx_httpdWrite (wp, "checked");  

    }
    ifx_httpdWrite (wp,
                      " onclick=\"updatePriorityCodec(this.name);\"></td>\n");
    ifx_httpdWrite (wp, "<td>&nbsp;</td>");
    ifx_httpdWrite (wp, "</tr>\n");
    
#endif  /*ATA*/
	//Re-setting the flag becoz this is the last field we going to access from voip_line_codec.asp web page */
  f_cflag = 0;	
  ifx_vmapi_freeObjectList(&xLineCodec,IFX_VMAPI_VL_CODECLIST);
		return 0;
  }
  
  else if (!gstrcmp (name, T ("psel")))
    
  {
    char_t  nFlagG711_ALaw=0, nFlagG711_ULaw=0, nFlagG723=0,
            nFlagG726_16=0 , nFlagG726_24=0 ,nFlagG726_32=0,
            nFlagG726_40=0;

    char_t  nFlagG729_8=0, nFlagG722_64=0 ;
    
#ifndef IIP /* ATA / AMAZON */
    char_t nFlagT38=0;
#endif /* ATA/AMAZON */

    /* Populating the Priority Codec list based on Received CM order
     * and also making editable the related fields of web page 
     * */
    while ( pxTemp != NULL )
    {
      
			if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G711_ALAW)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g711_alaw\";\n");
        nFlagG711_ALaw=1;
      }
     else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G711_ULAW)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g711_ulaw\";\n");
        nFlagG711_ULaw=1;
      }
      else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G723)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g723\";\n");
        nFlagG723=1;
      }
      
      else  if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G729_8)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g729_8\";\n");
        nFlagG729_8=1;
      }
      else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G722_64)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g722_64\";\n");
        nFlagG722_64=1;
      }
      
        
#ifndef IIP /* ATA / AMAZON */
      else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_T38)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"t38\";\n");
        nFlagT38=1;
      }
      
#endif  /*  */
        else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G726_16)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_16\";\n");
        nFlagG726_16=1;
      }
      else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G726_24)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_24\";\n");
        nFlagG726_24=1;
      }
      else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G726_32)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_32\";\n");
        nFlagG726_32=1;
      }
      else if (pxTemp->uiCodecId & IFX_VMAPI_CODEC_G726_40)
        
      {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_40\";\n");
        nFlagG726_40=1;
      }
    
       __ifx_list_GetNext((void *)&pxTemp);

    }

    /* Making uneditable the related Codecs which are supported by
     * the firmware but was not configured by user. 
     * */
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G711_ALAW)
        && (nFlagG711_ALaw == 0))
    
    {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g711_alaw\";\n");
    }
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G711_ULAW)
        && (nFlagG711_ULaw == 0))
    
    {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g711_ulaw\";\n");
    }
    
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G729_8)
        && (nFlagG729_8 == 0))
    {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g729_8\";\n");
    }
    
#ifndef IIP /* ATA / AMAZON */
	/*
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G729_E)
         && (nFlagG729_e == 0))
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g729_e\";\n");
    }
*/
#endif  /* ATA/ AMAZON */
    
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G723)
         && (nFlagG723 == 0))
    
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g723\";\n");
    }
    
#ifndef IIP /* ATA / AMAZON */
/*
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G728)
        && (nFlagG728 == 0))
    {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"g728\";\n");
    }
*/
#endif  /*  */
    
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_16)
         && (nFlagG726_16 == 0))
    
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_16\";\n");
    }
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_24)
          && (nFlagG726_24 == 0))
    
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_24\";\n");
    }
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_32)
          && (nFlagG726_32 == 0))
    
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_32\";\n");
    }
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_40)
        && (nFlagG726_40 == 0))
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g726_40\";\n");
    }
    
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G722_64)
        && (nFlagG722_64 == 0))
    {
  	    ifx_httpdWrite (wp, "PrCodecList[index++] = \"g722_64\";\n");
    }
    
#ifndef IIP /* ATA / AMAZON */
    if ((xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_T38)
        && (nFlagT38 == 0))
    {
        ifx_httpdWrite (wp, "PrCodecList[index++] = \"t38\";\n");
    }
#endif  /*  */
	return 0;
  }
 
  return 0;

}

int32
ifx_web_CheckIfCodecIsPresentInPriorityList(uchar8 ucIndex, uchar8 *pucPrio)
{
	int32 i=0;
	
	//IFX_CGI_DEBUG("<ifx_web_CheckIfCodecIsPresentInPriorityList>Index is %d\n",ucIndex);
	while(aucPrio[i] != NULL)
	{
		if(aucPrio[i][0] == ucIndex-1)
		{
			*pucPrio = aucPrio[i][1];
			//IFX_CGI_DEBUG("<ifx_web_CheckIfCodecIsPresentInPriorityList>pucPrio is %d\n",*pucPrio);
			return IFX_VMAPI_SUCCESS;
		}
    if(g_ucNoOfPrioCodec == i+1)
		{
			return IFX_VMAPI_FAIL;
		}		
		i++;
	}
	
	return IFX_VMAPI_FAIL;		
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_codec
 *  Description     : This function is called add_line_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 

void
ifx_set_voip_sip_codec (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pp723list = ifx_httpdGetVar (wp, T ("p723list"), T (""));
  char_t * ppframe_g711_alaw =
    ifx_httpdGetVar (wp, T ("pframe_g711_alaw"), T (""));
  char_t * ppframe_g711_ulaw =
    ifx_httpdGetVar (wp, T ("pframe_g711_ulaw"), T (""));
  char_t * ppframe_g729_8 = ifx_httpdGetVar (wp, T ("pframe_g729_8"), T (""));
  //char_t * ppframe_g729_e = ifx_httpdGetVar (wp, T ("pframe_g729_e"), T (""));
  char_t * ppframe_g723 = ifx_httpdGetVar (wp, T ("pframe_g723"), T (""));
  //char_t * ppframe_g728 = ifx_httpdGetVar (wp, T ("pframe_g728"), T (""));
  char_t * ppframe_g726_16 =
    ifx_httpdGetVar (wp, T ("pframe_g726_16"), T (""));
  char_t * ppframe_g726_24 =
    ifx_httpdGetVar (wp, T ("pframe_g726_24"), T (""));
  char_t * ppframe_g726_32 =
    ifx_httpdGetVar (wp, T ("pframe_g726_32"), T (""));
  char_t * ppframe_g726_40 =
    ifx_httpdGetVar (wp, T ("pframe_g726_40"), T (""));
  char_t * ppframe_g722_64 =
    ifx_httpdGetVar (wp, T ("pframe_g722_64"), T (""));
  char_t * pdynPT_g726_16 = ifx_httpdGetVar (wp, T ("dynpt_g726_16"), T (""));
  char_t * pdynPT_g726_24 = ifx_httpdGetVar (wp, T ("dynpt_g726_24"), T (""));
  char_t * pdynPT_g726_32 = ifx_httpdGetVar (wp, T ("dynpt_g726_32"), T (""));
  char_t * pdynPT_g726_40 = ifx_httpdGetVar (wp, T ("dynpt_g726_40"), T (""));
  char_t * pPCodecString = ifx_httpdGetVar (wp, T ("pCodecString"), T (""));

  //int32 iRet;

  int32 i=0;//,j=0;
  int32 iIndex = 0,iCount=0;
  uchar8 pucPriorityCodecList[20][32]; /*this array will contain the codecs that are set by user */
	uchar8 ucNoofCodec=0;
	x_IFX_VMAPI_LineCodecList xLineCodec;
  x_IFX_VMAPI_CodecDesc *pxTemp;
  x_IFX_VMAPI_CodecDesc xModCodec;

	x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodec;
	uchar8 ucNoofSuppCodec=0;
	uchar8 ucPrio =0;

  memset(&xLineCodec,0,sizeof(xLineCodec));
	xLineCodec.ucLineId = g_LINE_ID_IS;
  xLineCodec.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_LineCodecList(&xLineCodec,0)) 
  {
    ifx_httpdError (wp, 200, T ("Get for LineCodecList Failed\n"));
    return ;
  }
	
	memset(&xVoiceCodec,0,sizeof(xVoiceCodec));
	xVoiceCodec.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceCodecCaps(&xVoiceCodec, 0))
	{
    ifx_httpdError (wp, 200, T ("Get for Voice Codec Capabilities Failed\n"));
    return ;
	}
	ucNoofSuppCodec = xVoiceCodec.uiNumCodecs;
 
  /* Parsing  Priority Codec String */ 
  memset (pucPriorityCodecList, 0, sizeof (pucPriorityCodecList));
  if (pPCodecString != NULL)
  {
    ifx_ParseString ((uchar8 *)pPCodecString, &pucPriorityCodecList[0][0],
                                   &ucNoofCodec);
  }
  else
  {
    ifx_httpdError (wp, 200, T ("Not selected any codec "));
  }
	
	memset(&aucPrio[0][0],'\0',sizeof(aucPrio));
	for(i=0;i<ucNoofCodec;i++)
	{
		pxTemp = xVoiceCodec.pxCodecList;
		iCount =0;
  	while (pxTemp !=NULL) {
    	if (!(strcmp (pxTemp->acCodecName, (char8 *)pucPriorityCodecList[i]))) 
			{
				break;
			}
			iCount++;
	  	__ifx_list_GetNext((void **)&pxTemp);
  	}
		aucPrio[i][0] = iCount;
		aucPrio[i][1] = i+1;
		//IFX_CGI_DEBUG("<SET>pucPriorityCodecList[%d] = %s\n",i, pucPriorityCodecList[i]);
		//IFX_CGI_DEBUG("<SET>aucPrio[%d][0]=%d aucPrio[%d][1]=%d\n",i,aucPrio[i][0],i,aucPrio[i][1]);
	}
	ifx_vmapi_freeObjectList(&xVoiceCodec,IFX_VMAPI_CODEC_CAPABS);
	g_ucNoOfPrioCodec = ucNoofCodec;
	

  //for(iIndex=0;iIndex<j;iIndex++)
  for(iIndex=0;iIndex<ucNoofSuppCodec;iIndex++)
  {
    memset(&xModCodec,0,sizeof(xModCodec));
		xModCodec.ucLineId = g_LINE_ID_IS;
    xModCodec.ucIndex  = iIndex+1;
    xModCodec.iid.config_owner = IFX_WEB;
    //iRet=ifx_get_CodecDesc(&xModCodec 0); /* modify this entry  */
    if(ifx_get_CodecDesc(&xModCodec, 0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Get for CodecDesc Failed - MOD\n"));
      return ;
    }
		ucPrio =0;
		//IFX_CGI_DEBUG("<SET>CODEC is %s\n",xModCodec.acCodecName);
			
  	/* comparing the local array to codec name,if matches,set in rc.conf  */
    if (!(strcmp (xModCodec.acCodecName, "G711_ALAW"))) 
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G711_ALAW;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g711_alaw);
      strcpy(xModCodec.acCodecName,"G711_ALAW");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
				//IFX_CGI_DEBUG("<SET>ucPrio is %d\n",ucPrio);
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G711_ULAW")))
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G711_ULAW;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g711_ulaw);
      strcpy(xModCodec.acCodecName,"G711_ULAW");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
				//IFX_CGI_DEBUG("<SET>ucPrio is %d\n",ucPrio);
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G723")))
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G723;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g723);
      strcpy(xModCodec.acCodecName,"G723");    
      if (atoi (pp723list) == 0)
      {
        xLineCodec.uiPrefG723Codec = 0;/*IFX_VMAPI_CODEC_G723_5_3;*/
      }
      else
      {
        xLineCodec.uiPrefG723Codec = 1;/*IFX_VMAPI_CODEC_G723_6_3;*/
      }

			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
				//IFX_CGI_DEBUG("<SET>ucPrio is %d\n",ucPrio);
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G729_8")))
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G729_8;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g729_8);
      
      strcpy(xModCodec.acCodecName,"G729_8");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
				//IFX_CGI_DEBUG("<SET>ucPrio is %d\n",ucPrio);
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G722_64")))
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G722_64;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g722_64);
      
      strcpy(xModCodec.acCodecName,"G722_64");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
				//IFX_CGI_DEBUG("<SET>ucPrio is %d\n",ucPrio);
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
	 
#ifndef IIP /* IIP */
		/*
    else if (!(strcmp (xModCodec.acCodecName, "G729_E")))
      
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G729_E;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g729_e);
      
      strcpy(xModCodec.acCodecName,"G729_E");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
     }
    else if (!(strcmp (xModCodec.acCodecName, "G728")))
      
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G728;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g728);
      
      strcpy(xModCodec.acCodecName,"G728");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
		*/
    else if (!(strcmp (xModCodec.acCodecName, "T38")))
      
	  {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_T38;
   //   pxTemp->unCodecSuppFrameLen =
   //     atoi (ppframe_t38);
		
      strcpy(xModCodec.acCodecName,"T38");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
	  }
#endif /* ATA / AMAZON */
    else if (!(strcmp (xModCodec.acCodecName, "G726_16")))
      
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G726_16;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g726_16);
      xModCodec.ucPayloadType =
        atoi (pdynPT_g726_16);
      
      strcpy(xModCodec.acCodecName,"G726_16");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
				//IFX_CGI_DEBUG("<SET G726-16>ucPrio is %d\n",ucPrio);
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G726_24")))
      
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G726_24;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g726_24);
      xModCodec.ucPayloadType =
        atoi (pdynPT_g726_24);
      
      strcpy(xModCodec.acCodecName,"G726_24");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G726_32")))
      
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G726_32;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g726_32);
      xModCodec.ucPayloadType =
        atoi (pdynPT_g726_32);
      
      strcpy(xModCodec.acCodecName,"G726_32");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }
    else if (!(strcmp (xModCodec.acCodecName, "G726_40")))
      
    {
      xModCodec.uiCodecId =
        IFX_VMAPI_CODEC_G726_40;
      xModCodec.unCodecSuppFrameLen =
        atoi (ppframe_g726_40);
      xModCodec.ucPayloadType =
        atoi (pdynPT_g726_40);
      
      strcpy(xModCodec.acCodecName,"G726_40");    
			if(IFX_VMAPI_SUCCESS != 
						ifx_web_CheckIfCodecIsPresentInPriorityList(xModCodec.ucIndex, &ucPrio))
			{
      	xModCodec.bEnable = IFX_FALSE;
      	xModCodec.ucPriority = iIndex+ucNoofCodec;
			}
			else
			{
      	xModCodec.bEnable = IFX_TRUE;
      	xModCodec.ucPriority = ucPrio;
			}
    }

		//IFX_CGI_DEBUG("<Before SET >ucPrio=%d,Enable=%d\n",xModCodec.ucPriority,xModCodec.bEnable);
    if(IFX_VMAPI_SUCCESS !=ifx_set_CodecDesc(IFX_OP_MOD, &xModCodec, 0)) /* modify this entry  */
    {
      ifx_httpdError (wp, 200, T ("Set for CodecDesc Failed - MOD\n"));
      return ;
    }
       
  }

//#ifndef IFX_TR104
 	xLineCodec.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_LineCodecList(IFX_OP_MOD,&xLineCodec,0))
  {
    ifx_httpdError (wp, 200, T ("Set for LineCodecList Failed\n"));
    return ;
  }
//#endif
  f_cflag=0; 
	ifx_vmapi_freeObjectList(&xVoiceCodec,IFX_VMAPI_CODEC_CAPABS);
	ifx_vmapi_freeObjectList(&xLineCodec,IFX_VMAPI_VL_CODECLIST);
  ifx_httpdNextPage_New(wp);
}

/*****************************************************************************
 *  Function Name   : ifx_get_FirmwareSupportedCodecs
 *  Description     : This function is called to get the
 *  						      firmware supported codedcs used by add_line_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
  int
ifx_get_FirmwareSupportedCodecs_vmapi (int eid, httpd_t wp, int argc,
                                 char_t ** argv) 
{

  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G711_ALAW))
  {
    ifx_httpdWrite (wp, "document.codec.g711_alaw.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g711_alaw.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G711_ULAW))
    
  {
    ifx_httpdWrite (wp, "document.codec.g711_ulaw.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g711_ulaw.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G729_8))
    
  {
    ifx_httpdWrite (wp, "document.codec.g729_8.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g729_8.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G729_E))
  {
    
#ifndef IIP /* ATA / AMAZON */
		/*
    ifx_httpdWrite (wp, "document.codec.g729_e.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g729_e.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.dynpt_g729_e.disabled = true;\n");
    */
#endif  /*  */
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G723))
    
  {
    ifx_httpdWrite (wp, "document.codec.g723.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g723.disabled = true;\n");
	 ifx_httpdWrite (wp, "document.codec.p723list.disabled=true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G728))
    
  {
    
#ifndef IIP /* ATA / AMAZON */
		/*
      ifx_httpdWrite (wp, "document.codec.g728.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g728.disabled = true;\n");
    */
#endif  /*  */
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_16))
    
  {
    ifx_httpdWrite (wp, "document.codec.g726_16.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g726_16.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.dynpt_g726_16.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_24))
    
  {
    ifx_httpdWrite (wp, "document.codec.g726_24.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g726_24.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.dynpt_g726_24.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_32))
    
  {
    ifx_httpdWrite (wp, "document.codec.g726_32.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g726_32.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.dynpt_g726_32.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G726_40))
    
  {
    ifx_httpdWrite (wp, "document.codec.g726_40.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g726_40.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.dynpt_g726_40.disabled = true;\n");
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_G722_64))
    
  {
    
      ifx_httpdWrite (wp, "document.codec.g722_64.disabled = true;\n");
    ifx_httpdWrite (wp, "document.codec.pframe_g722_64.disabled = true;\n");
    
  }
  if (!(xVoiceCodec.uiFwSuppCodec & IFX_VMAPI_CODEC_T38))
    
  {
		#ifndef IIP /* ATA / AMAZON */
      ifx_httpdWrite (wp, "document.codec.t38.disabled = true;\n");
    //ifx_httpdWrite (wp, "document.codec.pframe_t38.disabled = true;\n");
		#endif  /*  */
  }

  return 0;
}


/*****************************************************************************
 *  Function Name   : ifx_SelectAllCheckBox()
 *  Description     : This function is called to emit html code to select
 *  						      all check boxes on selecting Check All option
 *  						      firmware supported codedcs used by add_line_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
  int
ifx_SelectT38CheckBoxes_vmapi (int eid, httpd_t wp, int argc, char_t ** argv) 
{
    
#ifndef IIP /* ATA / AMAZON */
	/*
    ifx_httpdWrite (wp, "\tif ((document.codec.g729_e.disabled == false) && " 
                     "( document.codec.g729_e.checked == false))\n\t{\n\t\t" 
                     "document.codec.g729_e.checked = true;\n " 
                     "document.codec.pframe_g729_e.disabled = false;\n" 
                     "addOption(\"G729_E\",\"g729_e\");\n}\n");
  ifx_httpdWrite (wp, "\tif ((document.codec.g728.disabled == false) && " 
                    "( document.codec.g728.checked == false))\n\t{\n\t\t" 
                    "document.codec.g728.checked = true;\n " 
                    "document.codec.pframe_g728.disabled = false;\n" 
                    " addOption(\"G728\",\"g728\");\n}\n");
	*/
  ifx_httpdWrite (wp, "\tif ((document.codec.t38.disabled == false) && " 
                    "( document.codec.t38.checked == false))\n\t{\n\t\t" 
                    "document.codec.t38.checked = true;\n " 
                    "ChangeT38();\n}\n");
  
#endif  /*  */
  return 0;
}

int
ifx_get_T38ChangeFunction_vmapi (int eid, httpd_t wp, int argc, char_t ** argv) 
{
#ifndef IIP /* ATA / AMAZON */
    ifx_httpdWrite (wp,"if (document.codec.t38.checked == true)\n"
                    "\n{addOption(\"T38\",\"t38\");\n" 
                    "}\nelse\n{\ndeleteChecked(\"t38\");}\n");
  
#endif  /*  */
    return 0;
}


/*****************************************************************************
 *  Function Name   : ifx_getArrayIndexofCodec_vmapi()
 *  Description     : This function is called to find the array Index of
 *  						      Codec in the Codec list provided by VMAPI.Function returns
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    :  Array index  - Success
 *                    -1 				- Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_getArrayIndexofCodec_vmapi (x_IFX_VMAPI_CodecDesc * xCodec, int32 * unSelectedIndex,uint32 * unPayLoad,
                          uint32 uiCodecId) 
{
  uchar8 ucIndex=0;
	
  while(xCodec != NULL) 
  {
    if (xCodec->uiCodecId & uiCodecId)
    {
			*unSelectedIndex=xCodec->unCodecSuppFrameLen;
			*unPayLoad=xCodec->ucPayloadType;
      return ucIndex;
    }
    __ifx_list_GetNext((void *)&xCodec);
    ucIndex++; 
  }
    return -1;
}


/*****************************************************************************
 *  Function Name   : ifx_ifx_setSelectedFrameSize()
 *  Description     : This function is called to construct a Frame size select 
											 List onto the web-page 
 *  Input Values    : nSelIndex, closeRow
 *  Output Values   :
 *
 *  Return Value    :  
 *  Notes           :
 ****************************************************************************/ 
void ifx_setSelectedFrameSize(httpd_t wp,int32 nSelIndex,int32 closeRow,uint32 uiCodecId){
int32 nIndex;
char_t sValue[MAX_DATA_LEN];

    for (nIndex = 0;
          nIndex < sizeof (web_Frame_Sizes) / sizeof (CGI_ENUMSEL_S); nIndex++)
      
    {
			if (!(((uiCodecId == IFX_VMAPI_CODEC_G723_5_3) || (uiCodecId == IFX_VMAPI_CODEC_G723_6_3)) 
				&& (web_Frame_Sizes[nIndex].value == 10 || web_Frame_Sizes[nIndex].value == 20 
				|| web_Frame_Sizes[nIndex].value == 40))){
      	if (web_Frame_Sizes[nIndex].value == nSelIndex)
        	gstrcpy (sValue, "selected");
      
      	else
        	gstrcpy (sValue, "");
      		ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                       web_Frame_Sizes[nIndex].value, sValue,
                       web_Frame_Sizes[nIndex].str);
    	}
		}
    ifx_httpdWrite (wp, "</select>\n</td>\n");
    if(closeRow){
    	ifx_httpdWrite (wp, "<td> &nbsp;</td>\n");
			ifx_httpdWrite (wp, "</tr>\n");
		}
}
