/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module 
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_line.c
 *        Abstract: common line advanced related CGI API's
 *        Date    : 17/05/07
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 ************************************************************************/
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"

extern int g_LINE_ID_IS;
static char_t f_cflag;;
static x_IFX_VMAPI_VoiceLine xVoiceLine;
static int not_flag =0;
FILE *fp;

void
ifx_AssocEndpts (httpd_t wp, uchar8 * ucSrc); 
void
ifx_AssocProfile (httpd_t wp, uchar8 * pProfNum); 
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_lineadv
 *  Description     : This function is called in add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                   
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_lineadv (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pPPhyendptsString = ifx_httpdGetVar (wp, T ("pPhyendptsString"), T (""));
	//char_t * pProfNum = ifx_httpdGetVar (wp, T ("prof_num"), T (""));
	char_t pProfNum[10];
	gstrcpy (pProfNum, "1");
	IFX_DBG("Profile Number :%s",pProfNum);
	IFX_DBG("Line Number :%d",g_LINE_ID_IS);

	void ifx_set_voip_sip_linestate (httpd_t wp, char_t * path, char_t * query);

  not_flag = 0;

  /* Associating the line with selected profile*/
  ifx_AssocProfile(wp,(uchar8 *)pProfNum);

  /* Associating the line with selected endpoints*/
	if((*pPPhyendptsString == ' ') || (*pPPhyendptsString == '\0') )
	{
    ifx_AssocEndpts(wp,NULL);
	}
	else
	{
    ifx_AssocEndpts(wp,(uchar8 *)pPPhyendptsString);
	}

	ifx_set_voip_sip_linestate (wp, path, query);	
  f_cflag=0;
	ifx_httpdNextPage_New(wp);
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_linestate
 *  Description     : This function is called in voip_line_voip.asp 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    :
 *                   
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_linestate (httpd_t wp, char_t * path, char_t * query) 
{
 
  char_t * pState = ifx_httpdGetVar (wp, T ("vlstatus"), T (""));
  char_t * pMode = ifx_httpdGetVar (wp, T ("vlmode"), T (""));
  char_t * pIntrusion = ifx_httpdGetVar (wp, T ("intrusion"), T (""));
  char_t * pLineName = ifx_httpdGetVar (wp, T ("linename"), T (""));
  x_IFX_VMAPI_VoiceLine xVoiceLine1;
 
  if(g_LINE_ID_IS < 1)
  {
    return;
  }
  memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
  xVoiceLine1.ucLineId = g_LINE_ID_IS;
  xVoiceLine1.iid.config_owner = IFX_WEB;

	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
    return;
  }

  xVoiceLine1.ucState = atoi(pState);
	//set the Line name here
	 if(strlen(pLineName) && pLineName != NULL)	
			strcpy(xVoiceLine1.acName,pLineName); 
	//set the line mode here.....
  xVoiceLine1.ucLineMode = atoi(pMode);
  xVoiceLine1.ucIntrusion = atoi(pIntrusion);

	if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine1,0))
  {
    ifx_httpdError (wp, 200, "Fail to SET the VoiceLine (VL Status) !!!");
    return ;
  }
    f_cflag = 0;

  ifx_httpdNextPage_New(wp);

}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_linestate
 *  Description     : This function is called in voip_line_voip.asp 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
  int
ifx_get_voip_sip_linestate (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  char_t sValue[MAX_DATA_LEN];
  int32 nIndex;
	char8 pcName[20];
	uchar8 uEndPointCount = IFX_VMAPI_MAX_FXS_ENDPTS;

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
		uEndPointCount+=IFX_VMAPI_MAX_DECT_ENDPTS;
#endif

  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

 if(g_LINE_ID_IS < 1)
  {
    return -1;
  }
if(g_LINE_ID_IS != IFX_VMAPI_PSTN_LINE){ 
if(f_cflag == 0){
  memset(&xVoiceLine,0,sizeof(xVoiceLine));
  xVoiceLine.ucLineId = g_LINE_ID_IS;
  xVoiceLine.iid.config_owner = IFX_WEB;

	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
    return -1;
  }
f_cflag = 1;
}

}else{
	return -1;
}
/* To display the endpoints available for association
     This calls a JavaScript in the ASP page */
  if (!gstrcmp (name, T ("updateData1")))
  {
    nIndex=0;
    while(nIndex <= uEndPointCount)
    {
      IFX_WEB_GetInterfaceName (nIndex+1, pcName);
      if(strcmp(pcName,"FXO")){//except for FXO
      ifx_httpdWrite (wp, T ( "getThePhyendptsList1(\"%s\",\"%s\");\n"),
                      pcName,
                      pcName);
      }
      memset(pcName,0,sizeof(pcName));
      nIndex++;
    }
    return 0;
  }

  /* To display the endpoints already associated
     This calls a JavaScript in the ASP page */
  else if (!gstrcmp (name, T ("updateData")))
  {
  nIndex=0;
    while(xVoiceLine.ucAssocVoiceInterface[nIndex] != 0 && nIndex != uEndPointCount)
    {
          IFX_WEB_GetInterfaceName (xVoiceLine.ucAssocVoiceInterface[nIndex], pcName);
          ifx_httpdWrite (wp, T ( "getThePhyendptsList(\"%s\",\"%s\");\n"),
                       pcName,
                       pcName);
        memset(pcName,0,sizeof(pcName));
        nIndex++;
    }
    return 0;
  }

else  if (!gstrcmp (name, T ("vlstatus")))
  {
     uint32 ucValue = xVoiceLine.ucState;
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_State) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_State[nIndex].value, sValue,
                        web_Enum_State[nIndex].str);
     }
    return 0;
  }
	//get the line mode here...
  else if (!gstrcmp (name, T ("vlmode")))
  {
     uint32 ucValue = xVoiceLine.ucLineMode;
      for (nIndex = 0;
          nIndex < sizeof (web_Line_Mode) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Line_Mode[nIndex].value, sValue,
                        web_Line_Mode[nIndex].str);
     }
    return 0;
  }
  else if (!gstrcmp (name, T ("intrusion")))
  {
     uint32 ucValue = xVoiceLine.ucIntrusion;
      for (nIndex = 0;
          nIndex < sizeof (web_Intr) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Intr[nIndex].value, sValue,
                        web_Intr[nIndex].str);
     }
 		/*Re-setting becoz last field  accessing in web-page voip_line_voip.asp*/
 		f_cflag = 0;
    return 0;
	}
	else if (!gstrcmp (name, T ("LineNo")))
  {
		ifx_httpdWrite (wp, T ("%s"), xVoiceLine.acName);
 		/*Re-setting becoz this field alone can be accessing in diffrent pages*/
		f_cflag = 0;
		return 0;
	}
 	else if (!gstrcmp (name, T ("RegistrationSatus")))
  {
		char8 acStatus[32] = "";
		switch(xVoiceLine.ucLineStatus) {
			case IFX_VMAPI_VL_STATUS_DISABLED:
					strcpy(acStatus,"INACTIVE");
					break;
			case IFX_VMAPI_VL_STATUS_UP:
					strcpy(acStatus,"ACTIVE");
					break;
			case IFX_VMAPI_VL_STATUS_ERROR:
					strcpy(acStatus,"ERROR");
					break;
			default :
					strcpy(acStatus,"REGISTERING");
					break;
		}
	  ifx_httpdWrite (wp, T ("%s"), acStatus);
    return 0;
  }

  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_lineno
 *  Description     : This function is called in voip_line_summary.asp page 
											during the edit operaton. 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_lineno (httpd_t wp, char_t * path, char_t * query) 
{
  
 char_t * pLineId = ifx_httpdGetVar (wp, T ("LineId"), T (""));
 f_cflag = 0;
 g_LINE_ID_IS = atoi(pLineId);
 IFX_DBG("Line No. Set to : %d",g_LINE_ID_IS);
 ifx_httpdNextPage (wp);
}

/*****************************************************************************
 *  Function Name   : ifx_AssocEndpts
 *  Description     : This function is called from voip_line_voip.asp page  
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/ 
void
ifx_AssocEndpts (httpd_t wp, uchar8 * ucSrc) 
{

  uchar8 pucPhyendptsList[20]; 
  uchar8 pucPhyendptsListWeb[20][IFX_VMAPI_MAX_USER_NAME_LEN]; 
  uchar8 ucNoofPhyendpts =0;
	uchar8 ucInt;
	//char8 pcName[20];
  int32 iRet;
  int32 flag1=0,count1=0,p=0,q=0,x=0;
  int32 index = 0;
  uchar8 DisAssoc_array[30]={0};
  x_IFX_VMAPI_VoiceLine xVoiceLine;
  x_IFX_VMAPI_FxsPhyIf xFXS;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
  x_IFX_VMAPI_DectHandset xDectHand;
  int32 dect_flag = 0;
#endif
  memset(&xVoiceLine,0,sizeof(xVoiceLine));
  xVoiceLine.ucLineId = g_LINE_ID_IS;
  xVoiceLine.iid.config_owner=IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceLine !!!");
    return;
  }

  /* Parsing the string set from web */
  memset (&pucPhyendptsList, 0, sizeof (pucPhyendptsList));
    
	memset (&pucPhyendptsListWeb, 0, sizeof (pucPhyendptsListWeb));
			
  /* Parse the comma seperated Endpoint List string into an array*/
  if ( ucSrc != NULL)
  {
    ifx_ParseString ( ucSrc, &pucPhyendptsListWeb[0][0],
                                   &ucNoofPhyendpts);
	}
			
  /* Conversion of logical name of the Endpoint to Interface Id */	
  for (p = 0; p < ucNoofPhyendpts; p++)
  {
    IFX_WEB_GetInterfaceId ((char8 *)pucPhyendptsListWeb[p], &ucInt);
	  pucPhyendptsList[p] = ucInt;		
	}

	/* No change in the Associated Endpoints List. Just return. */
	if( 0 == memcmp(xVoiceLine.ucAssocVoiceInterface,
			pucPhyendptsList,IFX_VMAPI_MAX_VOICE_INTERFACES) )
	{
		return;
	}
	
	p=0;
	
  memset (&(DisAssoc_array), 0, sizeof (DisAssoc_array));
  /* Comparing parsed array with AssocInterface in VoiceLine to get 
		 the Endpoints which have been disassociated*/
  while(xVoiceLine.ucAssocVoiceInterface[x] != 0)
  {
		/* All the endpoints are disassociated */
	  if(ucNoofPhyendpts == 0)
		{
			memcpy(&(DisAssoc_array),&(xVoiceLine.ucAssocVoiceInterface),
											sizeof(xVoiceLine.ucAssocVoiceInterface));
			break;
		}
		/* Some Endpoints are disassociated. Endpoints which are there in
		   the VoiceLine AssociatedInterface list but not in the parsed array 
		   list from web, are disassociated.*/
		else
		{
			for (p = 0; p < ucNoofPhyendpts; p++)
      {
        if( xVoiceLine.ucAssocVoiceInterface[x] != (pucPhyendptsList[p]))
        {
					count1++;
        }
      }
			if(count1 == ucNoofPhyendpts)
			{
        DisAssoc_array[q] = xVoiceLine.ucAssocVoiceInterface[x];
				q++;
			}
			count1=0;
		}
    x++;
  }

	count1=0;
  q=0;
  p=0;
  x=0;

  /*Assigning the associated Endpoints to the AssocVoiceInterface of Line */ 
  memset (&(xVoiceLine.ucAssocVoiceInterface), 0, 
									sizeof (xVoiceLine.ucAssocVoiceInterface));
	
  for (index = 0; index < ucNoofPhyendpts; index++)
  {
    xVoiceLine.ucAssocVoiceInterface[index] = (pucPhyendptsList[index]);
  } 
			
  /* Updating the parameters of DisAssociating Endpoints. For each disassociated
	   Endpoint the VoiceLineIdList and default VoiceLineId needs to be updated. */
  while(DisAssoc_array[q] != 0)
  {
		/* For FXS Endpoints */
	  if(DisAssoc_array[q] <3) {
			memset(&xFXS,0,sizeof(xFXS));
      xFXS.xVoiceServPhyIf.ucInterfaceId = DisAssoc_array[q];
	    iRet = ifx_get_FxsPhyInterface(&xFXS,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        ifx_httpdError (wp, 200, "Fail to GET the FXS !!");
        return;
      }

			x=0;
			
			/* If the default VoiceLineId is same as the LineId then delete that 
			   and set it to the next available VoiceLine else set it to 0 */
			if(xFXS.ucVoiceLineId == g_LINE_ID_IS)
			{
				while(xFXS.ucVoiceLineIdList[x] != 0)
				{
					if(xFXS.ucVoiceLineIdList[x] != g_LINE_ID_IS)
					{
					  xFXS.ucVoiceLineId = xFXS.ucVoiceLineIdList[x];
            break;
					}
					else
					{
						xFXS.ucVoiceLineId = 0;
					}
					x++;
				}
			}

			x=0;
			
			/* Remove the Line from the VoiceLineId List of that FXS endpoint*/
  	  while (xFXS.ucVoiceLineIdList[p] != 0)
	    {
        /* Check if the corresponding line is already there */
		    if (xFXS.ucVoiceLineIdList[p] == g_LINE_ID_IS)
		    {
		      x=p;
          while(xFXS.ucVoiceLineIdList[x] != 0)
          {
            xFXS.ucVoiceLineIdList[x] = xFXS.ucVoiceLineIdList[x+1];
            x++; 
          }
        }
        p++;
      }

			/* SET the object */
 	    if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,
															IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
      {
        ifx_httpdError (wp, 200, T ("Fail to SET FXS !!\n"));
        return ;
      }  
		}
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
    p=0;
    x=0;
    if(DisAssoc_array[q] >3) {
			/* For DECT Handset */
			memset(&xDectHand,0,sizeof(xDectHand));
      xDectHand.xVoiceServPhyIf.ucInterfaceId = DisAssoc_array[q];
	    iRet = ifx_get_DectHandset(&xDectHand,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        ifx_httpdError (wp, 200, "Fail to GET the Dect Handset !!");
        return;
      }

			/* If the default VoiceLineId is same as the Line then delete that 
			   and set it to the next available VoiceLine else 0 */
			x=0;
			if(xDectHand.ucVoiceLineId == g_LINE_ID_IS)
			{
				while(xDectHand.aucVoiceLineIdList[x] != 0)
				{
					if(xDectHand.aucVoiceLineIdList[x] != g_LINE_ID_IS)
					{
					  xDectHand.ucVoiceLineId = xDectHand.aucVoiceLineIdList[x];
            break;
					}
					else
					{
						xDectHand.ucVoiceLineId = 0;
					}
					x++;
				}
			}

			x=0;
			
			/* Remove the LineId from the VoiceLineId List */
  	  while (xDectHand.aucVoiceLineIdList[p] != 0)
	    {
        /* Check if the corresponding line is already there */
		    if (xDectHand.aucVoiceLineIdList[p] == g_LINE_ID_IS)
		    {
		      x=p;
          while(xDectHand.aucVoiceLineIdList[x] != 0)
          {
            xDectHand.aucVoiceLineIdList[x] = xDectHand.aucVoiceLineIdList[x+1];
            x++; 
          }
        }
        p++;
      }
			
			/* SET the object */
 	    if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,
															IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
      {
        ifx_httpdError (wp, 200, T ("Fail to SET Dect Handset !!\n"));
        return ;
      }  
		}

#endif
		 q++;
     p=0;
     x=0;
  }/* while loop */

  q=0;
  p=0;
  x=0;

  /* Updating the parameters of the Endpoints which are getting associated with 
	   this line. */
  while( (pucPhyendptsList[x]) != 0)
  {
	  if(pucPhyendptsList[x] <3){
      memset(&xFXS,0,sizeof(xFXS));
      xFXS.xVoiceServPhyIf.ucInterfaceId = (pucPhyendptsList[x]);
	    iRet = ifx_get_FxsPhyInterface(&xFXS,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        ifx_httpdError (wp, 200, "Fail to GET the FXS !!!");
        return;
      }

      while(xFXS.ucVoiceLineIdList[p] != 0)
      {
        /* Set the flag if this VoiceLine is already associated*/
        if(xFXS.ucVoiceLineIdList[p] == xVoiceLine.ucLineId)
        {
          flag1 = 1;
        }
        count1++;
        p++;
      }
      /*If the flag is not set then assign this VoiceLine Id to the VoiceLineIdList 
				of the Endpoint. Set the default VoiceLine parameter also if the Endpoint was
			  not associated with any VoiceLine before. */
      if ( flag1 == 0 )
      {
				if(xFXS.ucVoiceLineId == 0)
				{
          xFXS.ucVoiceLineId = xVoiceLine.ucLineId;
				}
        xFXS.ucVoiceLineIdList[count1] = xVoiceLine.ucLineId;
        iRet = ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
        if (iRet != IFX_VMAPI_SUCCESS)
        {
          ifx_httpdError (wp, 200, "Fail to SET the FXS !!!");
          return;
        }
      }
		}
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
		/* For Dect Handset */
		p=0;
    count1=0;
    if(pucPhyendptsList[x] >3){
			//IFX_CGI_DEBUG("---Dect---pucPhyendptsList[%d]=%d\n",x, pucPhyendptsList[x]);
			//IFX_CGI_DEBUG("---Dect---VoiceLineId=%d\n",xVoiceLine.ucLineId);
      memset(&xDectHand,0,sizeof(xDectHand));
      xDectHand.xVoiceServPhyIf.ucInterfaceId = (pucPhyendptsList[x]);
	    iRet = ifx_get_DectHandset(&xDectHand,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        ifx_httpdError (wp, 200, "Fail to GET the Dect Handset !!!");
        return;
      }

      while(xDectHand.aucVoiceLineIdList[p] != 0)
      {
        /* Set the flag if this VoiceLine is already associated*/
        if(xDectHand.aucVoiceLineIdList[p] == xVoiceLine.ucLineId)
        {
          dect_flag = 1;
        }
        count1++;
        p++;
      }
      /*If the flag is not set then assign this VoiceLine Id to the VoiceLineIdList 
				of the Endpoint. Set the default VoiceLine parameter also if the Endpoint was
			  not associated with any VoiceLine before. */
      if ( dect_flag == 0 )
      {
			  if(xDectHand.ucVoiceLineId == 0)
				{
          xDectHand.ucVoiceLineId = xVoiceLine.ucLineId;
				}
        xDectHand.aucVoiceLineIdList[count1] = xVoiceLine.ucLineId;
        if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,
																IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
        {
          ifx_httpdError (wp, 200, "Fail to SET the DectHandset !!!");
          return;
        }
      }
		}
#endif /*DECT_SUPPORT*/
		p=0;
    count1=0;
    flag1=0;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
		dect_flag=0;
#endif
    x++;
  } /* while loop */

			
  xVoiceLine.iid.config_owner = IFX_WEB;
  if(not_flag ==1)
	{
    iRet = ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,
									IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
	}
	else
	{
    iRet = ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0);
		not_flag =1;
	}
  if (iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, "Fail to SET the VoiceLine !!!");
		not_flag =0;
    return;
  }
 
  return;
 
}


/*****************************************************************************
 *  Function Name   : ifx_AssocProfile
 *  Description     : This function is called in ifx_set_voip_sip_lineadv/linebasicprofile
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/ 
void
ifx_AssocProfile (httpd_t wp, uchar8 * pProfNum) 
{

  int32 flag1=0,count1=0,x=0;
	uchar8 ucPrevProf =0;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
  x_IFX_VMAPI_VoiceLine xVoiceLine;

  memset(&xVoiceLine,0,sizeof(xVoiceLine));
  xVoiceLine.ucLineId = g_LINE_ID_IS;
  xVoiceLine.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceLine !!!");
    return ;
  }

	/* There is no change in Profile Association. Just return */
	if(xVoiceLine.ucProfileId == atoi((char8 *)pProfNum)){
		return;
	}
	
	/* Line is already associated with the other Profile. So LineId
	   has to be deleted from the AssoLineIds of that Profile */
	ucPrevProf = xVoiceLine.ucProfileId;


	if(ucPrevProf != 0)
	{
		memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = ucPrevProf ;
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile !!!");
      return;
    }
    /* Checking if Line is already associated*/
    while(xVoiceProf.aucAssoLineIds[x] != 0)
    {
      if(xVoiceProf.aucAssoLineIds[x] == xVoiceLine.ucLineId)
      {
        count1=x;
        xVoiceProf.ucNoOfLines-=1;
        while(xVoiceProf.aucAssoLineIds[count1] != 0)
        {
          xVoiceProf.aucAssoLineIds[count1] = xVoiceProf.aucAssoLineIds[count1+1];
          count1++; 
        }
      }
      x++;
    } 
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile !!");
      return;
    }
	}

	/* Association with the Profile means, the pCpeId of Line needs to be 
     set with the associated profile*/
	xVoiceLine.ucProfileId = atoi((char8 *)pProfNum);
 	xVoiceLine.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0))
  {
    ifx_httpdError (wp, 200, "Fail to SET the VoiceLine !!!");
	  not_flag =0;
    return;
  }
	else
	{
	  not_flag =1;
	}

  /* Profile Association*/
  /*If no profile,give error */
  if(atoi((char8 *)pProfNum) == 0)
  {
    ifx_httpdError (wp, 200, "No Profile. First Add Profile !!!");
    return;
  }

  /* If no error,Assigning Line Id to the AssoLineIds of profile */
  memset(&xVoiceProf,0,sizeof(xVoiceProf));
  xVoiceProf.ucProfileId = atoi((char8 *)pProfNum);
  xVoiceProf.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile !!!");
    return;
  }

	count1=0;
	x=0;
  /* Checking if Line is already associated in the VoiceProfile*/
  while(xVoiceProf.aucAssoLineIds[x] != 0)
  { 
    if(xVoiceProf.aucAssoLineIds[x] == xVoiceLine.ucLineId)
    {
      flag1 = 1;
			return ; /* No need to set the VoiceProfile */
    } 
		count1++;
    x++;
  } 

  /* If not associated then assign it to the AssoLineIds of the profile */
  if(flag1 == 0)
  {
    xVoiceProf.aucAssoLineIds[count1] = xVoiceLine.ucLineId;
    xVoiceProf.ucNoOfLines+=1;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile !!!");
      return;
    }
  } 

}

