/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_user
 *        Abstract: CGI API's to Access User settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


extern int g_LINE_ID_IS;
extern int g_PROFILE_ID_IS;
static char_t f_cflag;;
static  x_IFX_VMAPI_LineSignaling xLineSign;
static  x_IFX_VMAPI_LineSubscription xLineSub;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_user
 *  Description     : This function is called add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_user (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  int32 i=0;
  char8 acName[12] ="authname";
  char8 acRealm[12] ="realm";
	char8 buf[2] = {0}; 
  x_IFX_VMAPI_SipAuthCfg *pxTemp;
  x_IFX_VMAPI_LineEvents *pxTemp1;

  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if(g_LINE_ID_IS < 1)
  {
    return -1;
  }


  pxTemp = xLineSign.pxAuthCfg;
  if(f_cflag == 0 || pxTemp == NULL )
  {
    memset(&xLineSign,0,sizeof(xLineSign)); 
    xLineSign.ucLineId = g_LINE_ID_IS;
    xLineSign.iid.config_owner = IFX_WEB;
    if(ifx_get_LineSignaling(&xLineSign,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("<USER>Get for Line Signaling failed\n"));
      return -1;
    }
 
    memset(&xLineSub,0,sizeof(xLineSub)); 
    xLineSub.ucLineId = g_LINE_ID_IS;
    xLineSub.iid.config_owner = IFX_WEB;
    if(ifx_get_LineSubscription(&xLineSub,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("<USER>Get for Line Subscription failed\n"));
      return -1;
    }
    f_cflag = 1;
  }  


  if (!gstrcmp (name, T("uname_acc")))
  {
    ifx_httpdWrite (wp, T ("%s"), xLineSign.acSipUserName);
		/* Re-setting because this is the last field accessing from quick_voip.asp page */
		f_cflag=0;
		return 0;
  }
  else if (!gstrcmp (name, T ("dname_acc")))
  {
    ifx_httpdWrite (wp, T ("%s"), xLineSign.acSipDispName);
		return 0;
  }
  if (!gstrcmp (name, T ("unameMsgRet")))
  {
    ifx_httpdWrite (wp, T ("%s"), xLineSub.acMwiRetrieveUsrName);
		/*Re-setting the flag because last field accessed from web-page voip_line_sip.asp */
		f_cflag=0;
		return 0;
  }
  
  //if ( iRet == IFX_VMAPI_SUCCESS ) {
     pxTemp = xLineSign.pxAuthCfg;
     i=0;
     while (i<IFX_VMAPI_MAX_AUTH_INFO && pxTemp !=NULL) {
       memset(buf, 0 , sizeof(buf));
       memset(acName, 0 , sizeof(acName));
       memset(acRealm, 0 , sizeof(acRealm));
       strcpy(acName,"authname");
       strcpy(acRealm,"realm");
	     sprintf(buf, "%d", i+1);
	     gstrcat(acName, buf);
	     gstrcat(acRealm, buf);

       if (!gstrcmp (name, acName))
       {
         ifx_httpdWrite (wp, T ("%s"),pxTemp->acSipAuthUsrName);
         return 0;
       }
       else if (!gstrcmp (name, acRealm))
       {
         ifx_httpdWrite (wp, T ("%s"),pxTemp->acRealm);
         return 0;
       }
       i=i+1;
       __ifx_list_GetNext((void *)&pxTemp);
     }     
  //}



  //if ( iRet == IFX_VMAPI_SUCCESS ) {
     pxTemp1 = xLineSub.pxLineEvents;
     i=0;
     while (pxTemp1 !=NULL) {
      if(i==0)
      {
        if (!gstrcmp (name, T ("unameMsgDep")))
        {
          ifx_httpdWrite (wp, T ("%s"), pxTemp1->acSubspnUsrName);
          /* To free memory allocated to the Line Signaling Object List*/
          ifx_vmapi_freeObjectList(&xLineSign,IFX_VMAPI_VL_SIGNALING);
          ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);
          //g_cflag = 0;
					return 0;
        }
        if (!gstrcmp (name, T ("MWI")))
        {
          if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_IDLE)
            ifx_httpdWrite (wp, T ("%s"), "IDLE");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_SUBSCRIBING)
            ifx_httpdWrite (wp, T ("%s"), "SUBSCRIBING");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_SUBSCRIBED)
            ifx_httpdWrite (wp, T ("%s"), "SUBSCRIBED");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_PENDING)
            ifx_httpdWrite (wp, T ("%s"), "PENDING");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_ACTIVE)
            ifx_httpdWrite (wp, T ("%s"), "ACTIVE");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_TIMEOUT)
            ifx_httpdWrite (wp, T ("%s"), "TIMEOUT");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_TERMINATED)
            ifx_httpdWrite (wp, T ("%s"), "TERMINATED");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_UNAUTH)
            ifx_httpdWrite (wp, T ("%s"), "UNAUTHORISED");

          return 0;
        }
      }
      else
        break;
      i++;
      __ifx_list_GetNext((void *)&pxTemp1);
     }     
    //g_cflag = 0;
   //}

  return 0;


}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_user
 *  Description     : This function is called add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_user (httpd_t wp, char_t * path, char_t * query) 
{
  
  
  char_t * pUsername = ifx_httpdGetVar (wp, T ("uname_acc"), T (""));
  char_t * pDspname = ifx_httpdGetVar (wp, T ("dname_acc"), T (""));
  char_t * pUnameMsgRet = ifx_httpdGetVar (wp, T ("unameMsgRet"), T (""));
  char_t * pUnameMsgDep = ifx_httpdGetVar (wp, T ("unameMsgDep"), T (""));

  int32 AuthCfgCount;
  x_IFX_VMAPI_SipAuthCfg xAuthCfg;
  x_IFX_VMAPI_SipAuthCfg xAuthCfgAdd;
  x_IFX_VMAPI_LineEvents xLineEvents;
  x_IFX_VMAPI_VoiceLine xVL;

  int32 i=0,j=0, iBlank = 0; 
	char8 buf1[2] = {0}; 
  char8 input_auth[12] = "authname";
  char8 input_realm[12] = "realm";
  char8 input_pwd[12] = "authpwd";  

  memset(&xLineEvents,0,sizeof(xLineEvents));
  memset(&xAuthCfg,0,sizeof(xAuthCfg));
  memset(&xAuthCfgAdd,0,sizeof(xAuthCfgAdd));

   memset(&xLineSign,0,sizeof(xLineSign)); 
   xLineSign.ucLineId = g_LINE_ID_IS;
   xLineSign.iid.config_owner = IFX_WEB;
   if(ifx_get_LineSignaling(&xLineSign,0) != IFX_VMAPI_SUCCESS) 
   {
     ifx_httpdError (wp, 200, T ("<USER>Get for Line Signaling failed\n"));
     return ;
   }
 
   memset(&xLineSub,0,sizeof(xLineSub)); 
   xLineSub.ucLineId = g_LINE_ID_IS;
   xLineSub.iid.config_owner = IFX_WEB;
   if(ifx_get_LineSubscription(&xLineSub,0) != IFX_VMAPI_SUCCESS) 
   {
     ifx_httpdError (wp, 200, T ("<USER>Get for Line Subscription failed\n"));
     return ;
   }

  xLineEvents.ucLineId = g_LINE_ID_IS;
  xLineEvents.ucIndex = 1;
  xLineEvents.iid.config_owner = IFX_WEB;
  if(ifx_get_LineEvents(&xLineEvents,0) != IFX_VMAPI_SUCCESS) 
  {
    ifx_httpdError (wp, 200, T ("Get for Line Events failed\n"));
    return ;
  }

  AuthCfgCount = xLineSign.ucNoOfSipAuthCfg; 
 
  /* Modify the already existing number of AuthCfg*/ 
  for(i=0;i<AuthCfgCount && i<IFX_VMAPI_MAX_AUTH_INFO;i++)
  {
    xAuthCfg.ucLineId = g_LINE_ID_IS;
    xAuthCfg.ucIndex = i+1;
    xAuthCfg.iid.config_owner = IFX_WEB;

    if(ifx_get_AuthCfg(&xAuthCfg,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("Get for AuthCfg failed\n"));
      return ;
    }

	  sprintf(buf1, "%d", i+1);
    strcpy(input_auth,"authname");
    strcpy(input_pwd,"authpwd");
    strcpy(input_realm,"realm");
	  gstrcat(input_auth, buf1);
	  gstrcat(input_realm, buf1);
	  gstrcat(input_pwd, buf1);
  
    char_t * pRealm = ifx_httpdGetVar (wp, input_realm, T (""));
    char_t * pAuthpwd = ifx_httpdGetVar (wp, input_pwd, T (""));
    char_t * pAuthname = ifx_httpdGetVar (wp, input_auth, T (""));

    /* Checking if empty entry, delete it*/
    if ((strlen(pAuthname) == 0))
    {
      xAuthCfg.iid.config_owner = IFX_WEB;
      if(ifx_set_AuthCfg(IFX_OP_DEL,&xAuthCfg,0) != IFX_VMAPI_SUCCESS) 
      {
        ifx_httpdError (wp, 200, T ("Set for AuthCfg failed-DEL\n"));
        return ;
      }
     	  xLineSign.ucNoOfSipAuthCfg--;
    }
    /* If old and new entry are not same,then modify else dont*/ 
    else if ((gstrcmp (xAuthCfg.acSipAuthUsrName,pAuthname))||(gstrcmp (xAuthCfg.acSipAuthPasswd,pAuthpwd)))
		{
      gstrcpy (xAuthCfg.acSipAuthUsrName, pAuthname);
      gstrcpy (xAuthCfg.acSipAuthPasswd, pAuthpwd);
      gstrcpy (xAuthCfg.acRealm, pRealm);
 	    
      xAuthCfg.iid.config_owner = IFX_WEB;
      if(ifx_set_AuthCfg(IFX_OP_MOD,&xAuthCfg,0) != IFX_VMAPI_SUCCESS) 
      {
        ifx_httpdError (wp, 200, T ("Set for AuthCfg failed-MOD\n"));
        return ;
      }
		}
  }
  /* Adding the new AuthCfg if any*/
  for (j=i+1; j<=IFX_VMAPI_MAX_AUTH_INFO; j++)
  {

	  sprintf(buf1, "%d", j);
    strcpy(input_auth,"authname");
    strcpy(input_pwd,"authpwd");
    strcpy(input_realm,"realm");
	  gstrcat(input_auth, buf1);
	  gstrcat(input_realm, buf1);
	  gstrcat(input_pwd, buf1);
    char_t * pRealm = ifx_httpdGetVar (wp, input_realm, T (""));
    char_t * pAuthpwd = ifx_httpdGetVar (wp, input_pwd, T (""));
    char_t * pAuthname = ifx_httpdGetVar (wp, input_auth, T (""));

    /* Checking if entry is added*/
		if ((strlen(pAuthname) != 0))
		{
	    gstrcpy (xAuthCfgAdd.acSipAuthUsrName, pAuthname);
      gstrcpy (xAuthCfgAdd.acSipAuthPasswd, pAuthpwd);
      gstrcpy (xAuthCfgAdd.acRealm, pRealm);

      xAuthCfgAdd.ucLineId = g_LINE_ID_IS;
      xAuthCfgAdd.ucIndex = j-iBlank;
 	    xAuthCfgAdd.iid.config_owner = IFX_WEB;
      if(ifx_set_AuthCfg(IFX_OP_ADD,&xAuthCfgAdd,0) != IFX_VMAPI_SUCCESS) 
      {
        ifx_httpdError (wp, 200, T ("Set for AuthCfg failed-ADD\n"));
        return ;
      }
     	  xLineSign.ucNoOfSipAuthCfg++;
		}
		else
			iBlank++;
  }

#if 1
	if(strcmp (xLineSign.acSipUserName, pUsername) !=0)
	{
  /* The UserName must be unique. Check against all the lines */
  x_IFX_VMAPI_LineSignaling xLSig;
	x_IFX_VMAPI_VoiceService xVoiceServ;
	int32 j=0;
	memset(&xVoiceServ,0,sizeof(xVoiceServ));
  xVoiceServ.iid.config_owner = IFX_WEB;
  if(ifx_get_VoiceService(&xVoiceServ,0) != IFX_VMAPI_SUCCESS)
  {
      ifx_httpdError (wp, 200, T ("Cannot GET Voice Service\n"));
      return ;
  }
  /* Get the LineIdList. */
  while(xVoiceServ.ucLineIdList[j] != 0)
  {
		memset(&xLSig,0,sizeof(xLSig));
    xLSig.ucLineId = xVoiceServ.ucLineIdList[j];
    xLSig.iid.config_owner = IFX_WEB;
    if(ifx_get_LineSignaling(&xLSig,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("Get for Line Signaling failed\n"));
      return ;
    }
	
		if(strcmp (xLSig.acSipUserName, pUsername) == 0)
		{
      ifx_vmapi_freeObjectList(&xLSig,IFX_VMAPI_VL_SIGNALING);
      ifx_httpdError (wp, 200, T ("UserName Exists.\n"));
      return ;
		}
		j++;
  }
    ifx_vmapi_freeObjectList(&xLSig,IFX_VMAPI_VL_SIGNALING);
	}
#endif
	gstrcpy (xLineSign.acSipUserName, pUsername);
  gstrcpy (xLineSign.acSipDispName, pDspname);
 	xLineSign.iid.config_owner = IFX_WEB;
  if(ifx_set_LineSignaling(IFX_OP_MOD,&xLineSign,0) != IFX_VMAPI_SUCCESS) 
  {
    ifx_vmapi_freeObjectList(&xLineSign,IFX_VMAPI_VL_SIGNALING);
    ifx_httpdError (wp, 200, T ("Set for LineSignaling failed\n"));
    return ;
  }
  ifx_vmapi_freeObjectList(&xLineSign,IFX_VMAPI_VL_SIGNALING);

	/* If Retrieve userName has been changed */
	if(strcmp(xLineSub.acMwiRetrieveUsrName , pUnameMsgRet) != 0)
	{
 	  gstrcpy (xLineSub.acMwiRetrieveUsrName, pUnameMsgRet);
 	  xLineSub.iid.config_owner = IFX_WEB;
    if(ifx_set_LineSubscription(IFX_OP_MOD,&xLineSub,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);
      ifx_httpdError (wp, 200, T ("Set for LineSubscription failed\n"));
      return ;
    }
	}
  ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);

	/* If deposit UserName has been changed */
	if(strcmp(xLineEvents.acSubspnUsrName, pUnameMsgDep) !=0)
	{
	  gstrcpy (xLineEvents.acSubspnUsrName, pUnameMsgDep);
 	  xLineEvents.iid.config_owner = IFX_WEB;
	  if(ifx_set_LineEvents(IFX_OP_MOD,&xLineEvents,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("Set for Line Events failed\n"));
      return ;
    }
	}
		
  memset(&xVL,0,sizeof(x_IFX_VMAPI_VoiceLine));
	xVL.ucLineId = g_LINE_ID_IS;
 	xVL.iid.config_owner = IFX_WEB;
  if(ifx_get_VoiceLine(&xVL,0) != IFX_VMAPI_SUCCESS) 
  {
    ifx_httpdError (wp, 200, T ("Get for Voice Line failed\n"));
    return ;
  }
  /* Username has been changed. Change the DirName in VoiceLine */
	if(strcmp(xVL.acDirName , pUsername) != 0)
	{
	  strcpy(xVL.acDirName,pUsername);
 	  xVL.iid.config_owner = IFX_WEB;
    if(ifx_set_VoiceLine(IFX_OP_MOD,&xVL,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("Set for Voice Line failed\n"));
      return ;
    }
	}

    f_cflag = 0;
  ifx_httpdNextPage_New(wp);

}


/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_linebasicaccount
 *  Description     : This function is called in add_line_basic.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                   
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_linebasicaccount (httpd_t wp, char_t * path, char_t * query) 
{
  
  char_t * pUsername = ifx_httpdGetVar (wp, T ("uname_acc"), T (""));
  char_t * pDspname = ifx_httpdGetVar (wp, T ("dname_acc"), T (""));
  char_t * pUnameMsgDep = ifx_httpdGetVar (wp, T ("unameMsgDep"), T (""));
  char_t * pUnameMsgRet = ifx_httpdGetVar (wp, T ("unameMsgRet"), T (""));
  char_t * pDomain = ifx_httpdGetVar (wp, T ("domain"), T (""));
  char_t * pPass = ifx_httpdGetVar (wp, T ("pass"), T (""));

  int32 iRet;
  x_IFX_VMAPI_LineSignaling xLineSig1;
  x_IFX_VMAPI_LineSubscription xLineSub;
  x_IFX_VMAPI_LineEvents xLineEvents;
  x_IFX_VMAPI_VoiceLine xVL;
  x_IFX_VMAPI_SipAuthCfg xAuth;


  if(g_LINE_ID_IS < 1)
  {
    //g_LINE_ID_IS = 1;
	  return ;
  }


  memset(&xLineSig1,0,sizeof(xLineSig1));
  xLineSig1.ucLineId = g_LINE_ID_IS;
  xLineSig1.iid.config_owner = IFX_WEB;
	iRet = ifx_get_LineSignaling(&xLineSig1,0);
  if ( iRet != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Signaling\n"));
    return ;
    
  } 

  memset(&xLineSub,0,sizeof(xLineSub));
  xLineSub.ucLineId = g_LINE_ID_IS;
  xLineSub.iid.config_owner = 1;
	iRet = ifx_get_LineSubscription(&xLineSub,0);
  if ( iRet != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Subscription\n"));
    return ;
    
  } 

	/* Right now there is one entry of Line Event. */
  memset(&xLineEvents,0,sizeof(xLineEvents));
  xLineEvents.ucLineId = g_LINE_ID_IS;
  xLineEvents.ucIndex  = 1;
  xLineEvents.iid.config_owner = IFX_WEB;
	iRet = ifx_get_LineEvents(&xLineEvents,0);
  if ( iRet != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Events\n"));
    return ;
    
  } 

	memset(&xVL,0,sizeof(x_IFX_VMAPI_VoiceLine));
	xVL.ucLineId = g_LINE_ID_IS;
	iRet = ifx_get_VoiceLine(&xVL,0);
  if(iRet != IFX_VMAPI_SUCCESS) 
  {
    ifx_httpdError (wp, 200, T ("Get for Voice Line failed\n"));
    return ;
  }

	/* If in the Basic User Account Information Domain name is blank and
	   previously no entry is created then nothing to be done. If Domain
	   name is entered and entry is there previously then modify the first
	   entry else if no entry is there then add one entry.*/
	/* Please not that the Basic User Account Authentication information is
	   mapped to the first entry of the authentication list in the advance
	   page. */
	//if( (pDomain[0] != '\0' )) //with this condition, Domain name can't be removed after adding
	if (1)
	{
		memset(&xAuth,0,sizeof(x_IFX_VMAPI_SipAuthCfg));
	  if(xLineSig1.ucNoOfSipAuthCfg >0)
	  {
	    xAuth.ucLineId = g_LINE_ID_IS;
      xAuth.ucIndex = 1;
      xAuth.iid.config_owner = IFX_WEB;
      if(IFX_VMAPI_SUCCESS != ifx_get_AuthCfg(&xAuth,0)) 
      {
        ifx_httpdError (wp, 200, T ("Get for AuthCfg failed\n"));
        return ;
      }
			if((strcmp(xAuth.acRealm,pDomain) != 0)
			 ||(strcmp(xAuth.acSipAuthUsrName,pUsername) != 0))
			{
        strcpy(xAuth.acSipAuthUsrName,pUsername);
	      strcpy(xAuth.acRealm,pDomain);
	      strcpy(xAuth.acSipAuthPasswd,pPass);

        if(IFX_VMAPI_SUCCESS != ifx_set_AuthCfg(IFX_OP_MOD,&xAuth,0)) 
	      {
   	      ifx_httpdError (wp, 200, T ("Set for AuthCfg failed\n"));
   	      return ;
        }
			}
		}
		else
		{
		  //IFX_CGI_DEBUG("AuthCFg=%d\n", xLineSig1.ucNoOfSipAuthCfg);
	    xAuth.ucLineId = g_LINE_ID_IS;
      xAuth.ucIndex = 1;
      xAuth.iid.config_owner = IFX_WEB;
        
			strcpy(xAuth.acSipAuthUsrName,pUsername);
	    strcpy(xAuth.acRealm,pDomain);
	    strcpy(xAuth.acSipAuthPasswd,pPass);
      if(IFX_VMAPI_SUCCESS != ifx_set_AuthCfg(IFX_OP_ADD,&xAuth,0)) 
      {
        ifx_httpdError (wp, 200, T ("Set for AuthCfg failed -- ADD\n"));
        return ;
      }
      xLineSig1.ucNoOfSipAuthCfg++;
		}
	}

	gstrcpy (xLineSig1.acSipUserName, pUsername);
  gstrcpy (xLineSig1.acSipDispName, pDspname);
 
 	xLineSig1.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_LineSignaling(IFX_OP_MOD,&xLineSig1,0))
  {
    ifx_vmapi_freeObjectList(&xLineSig1,IFX_VMAPI_VL_SIGNALING);
    ifx_httpdError (wp, 200, T ("SET is failing for Line Signaling\n"));
    return;
    
  } 
  ifx_vmapi_freeObjectList(&xLineSig1,IFX_VMAPI_VL_SIGNALING);

	/* If Retrieve userName has been changed */
	if(strcmp(xLineSub.acMwiRetrieveUsrName , pUnameMsgRet) != 0)
	{
 	  gstrcpy (xLineSub.acMwiRetrieveUsrName, pUnameMsgRet);
 	  xLineSub.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineSubscription(IFX_OP_MOD,&xLineSub,0))
    {
      ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);
      ifx_httpdError (wp, 200, T ("SET is failing for Line Subscription\n"));
      return;
    }
	}	
  ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);

	/* If deposit UserName has been changed */
	if(strcmp(xLineEvents.acSubspnUsrName, pUnameMsgDep) !=0)
	{
	  gstrcpy (xLineEvents.acSubspnUsrName, pUnameMsgDep);
 	  xLineEvents.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineEvents(IFX_OP_MOD,&xLineEvents,0))
    {
      ifx_httpdError (wp, 200, T ("SET is failing for Line Events\n"));
      return ;
    }
	}	
	
  /* Username has been changed. Change the DirName in VoiceLine */
	if(strcmp(xVL.acDirName , pUsername) != 0)
	{
	  strcpy(xVL.acDirName,pUsername);
 	  xVL.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVL,0))
    {
      ifx_httpdError (wp, 200, T ("Set for Voice Line failed\n"));
      return ;
    }
	}

    f_cflag = 0;
  ifx_httpdNextPage_New(wp);

}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_linebasicaccount
 *  Description     : This function is called in add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_linebasicaccount (int eid, httpd_t wp, int argc, char_t ** argv) 
{

  char_t * name;
  x_IFX_VMAPI_LineSubscription xLineSub;
  x_IFX_VMAPI_LineEvents *pxTemp1;
  int32 i=0;
  x_IFX_VMAPI_LineSignaling xLineSig;
  x_IFX_VMAPI_SipAuthCfg xAuth;

  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
 
  if(g_LINE_ID_IS < 1)
   return -1;
  
  /* GET for Line Signaling */
  memset(&xLineSig,0,sizeof(xLineSig));
  xLineSig.ucLineId = g_LINE_ID_IS;
  xLineSig.iid.config_owner = IFX_WEB;

  if ( ifx_get_LineSignaling(&xLineSig,0) != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Signaling\n"));
    return -1;
  } 
  else
  {
    if (!gstrcmp (name, T ("uname_acc")))
    {
      ifx_httpdWrite (wp, T ("%s"), xLineSig.acSipUserName);
		  return 0;
    }
    else if (!gstrcmp (name, T ("dname_acc")))
    {
      ifx_httpdWrite (wp, T ("%s"), xLineSig.acSipDispName);
		  return 0;
    }
	} 

	if(xLineSig.ucNoOfSipAuthCfg >0)
	{
    /* GET for AuthCfg */
	  memset(&xAuth,0,sizeof(x_IFX_VMAPI_SipAuthCfg));
	  xAuth.ucLineId = g_LINE_ID_IS;
    xAuth.ucIndex = 1;
    xAuth.iid.config_owner = IFX_WEB;
    if(ifx_get_AuthCfg(&xAuth,0) != IFX_VMAPI_SUCCESS) 
    {
      ifx_httpdError (wp, 200, T ("Get for AuthCfg failed\n"));
      return -1;
    }
	  else
	  {
      if (!gstrcmp (name, T ("domain")))
      {
        ifx_httpdWrite (wp, T ("%s"),xAuth.acRealm);
		    return 0;
		  }
	  }
	}
  ifx_vmapi_freeObjectList(&xLineSig,IFX_VMAPI_VL_SIGNALING);
	
  /* GET for Line Subscription */
  memset(&xLineSub,0,sizeof(xLineSub));
  xLineSub.ucLineId = g_LINE_ID_IS;
  xLineSub.iid.config_owner = IFX_WEB;

 

  if ( ifx_get_LineSubscription(&xLineSub,0)  != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Subscription\n"));
    return -1;
    
  } 
  else
  {
    if (!gstrcmp (name, T ("unameMsgRet")))
    {
      ifx_httpdWrite (wp, T ("%s"), xLineSub.acMwiRetrieveUsrName);
			return 0;
    }

    i =0;
    pxTemp1 = xLineSub.pxLineEvents;
    while (pxTemp1 !=NULL) {
      if(i!=1)
      {
        if (!gstrcmp (name, T ("unameMsgDep")))
        {
          ifx_httpdWrite (wp, T ("%s"), pxTemp1->acSubspnUsrName);
        }
        if (!gstrcmp (name, T ("MWI")))
        {
					if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_IDLE)
            ifx_httpdWrite (wp, T ("%s"), "IDLE");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_SUBSCRIBING)
            ifx_httpdWrite (wp, T ("%s"), "SUBSCRIBING");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_SUBSCRIBED)
            ifx_httpdWrite (wp, T ("%s"), "SUBSCRIBED");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_PENDING)
            ifx_httpdWrite (wp, T ("%s"), "PENDING");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_ACTIVE)
            ifx_httpdWrite (wp, T ("%s"), "ACTIVE");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_TIMEOUT)
            ifx_httpdWrite (wp, T ("%s"), "TIMEOUT");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_TERMINATED)
            ifx_httpdWrite (wp, T ("%s"), "TERMINATED");
          else if (pxTemp1->ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_UNAUTH)
            ifx_httpdWrite (wp, T ("%s"), "UNAUTHORISED");
          
          return 0;
        }
     }
      else
        break;
      i++;
      __ifx_list_GetNext((void *)&pxTemp1);
    }     
  }
  ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);

  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_probasic
 *  Description     : This function is called quick_voip.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
int32
ifx_get_voip_sip_probasic (int eid, httpd_t wp, int argc, char_t ** argv)
{
  char_t * name, *mode;
  x_IFX_VMAPI_ProfileSignaling xProfSign;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if (g_PROFILE_ID_IS < 1)
  return IFX_VMAPI_FAIL;
    memset(&xProfSign,0,sizeof(x_IFX_VMAPI_ProfileSignaling));
    xProfSign.ucProfileId = g_PROFILE_ID_IS;
    xProfSign.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_ProfileSignaling(&xProfSign,0))
    {
      ifx_httpdError (wp, 200, T ("Failed to get Profile Signaling\n"));
      return IFX_VMAPI_FAIL;
    }

  if ( !gstrcmp (name, T ("ProxyIP")))
  {
    ifx_httpdWrite(wp,T("%s"), xProfSign.acProxyAddr);
    return 0;
  }
return IFX_VMAPI_SUCCESS;

}



/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_quick
 *  Description     : This function is called in quick_voip.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                   
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_quick (httpd_t wp, char_t * path, char_t * query) 
{
  
  char_t * pUsername = ifx_httpdGetVar (wp, T ("uname_acc"), T (""));
  char_t * pDspname = ifx_httpdGetVar (wp, T ("dname_acc"), T (""));
  char_t * pPass = ifx_httpdGetVar (wp, T ("pass"), T (""));
  char_t * pUserAgent = ifx_httpdGetVar (wp, T ("ProxyIP"), T (""));
 	char_t * pStatus = ifx_httpdGetVar (wp, T ("ProxyStatus"), T (""));
  char_t * pIP1 = ifx_httpdGetVar (wp, T ("ProxyIP"), T (""));
  char_t * pPort = ifx_httpdGetVar (wp, T ("ProxyPort"), T (""));
 	char_t * RStatus = ifx_httpdGetVar (wp, T ("ProxyStatus"), T (""));
  char_t * RIP1 = ifx_httpdGetVar (wp, T ("ProxyIP"), T (""));
  char_t * RPort = ifx_httpdGetVar (wp, T ("ProxyPort"), T (""));
  char_t * pState = ifx_httpdGetVar (wp, T ("profstatus"), T (""));
  char_t * pDisable = ifx_httpdGetVar (wp, T ("profdisable"), T (""));



  x_IFX_VMAPI_LineSignaling xLineSig1;
  x_IFX_VMAPI_LineSubscription xLineSub;
  x_IFX_VMAPI_LineEvents xLineEvents;
  x_IFX_VMAPI_VoiceLine xVL;
  x_IFX_VMAPI_SipAuthCfg xAuth;
  x_IFX_VMAPI_ProfileSignaling xProfSign;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
  x_IFX_VMAPI_EventSubscribe xVms;

  if(g_LINE_ID_IS < 1)
  {
    //g_LINE_ID_IS = 1;
	  return ;
  }


  memset(&xLineSig1,0,sizeof(xLineSig1));
  xLineSig1.ucLineId = 1;
  xLineSig1.iid.config_owner = IFX_WEB;
  if ( ifx_get_LineSignaling(&xLineSig1,0) != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Signaling\n"));
    return ;
    
  } 

  memset(&xLineSub,0,sizeof(xLineSub));
  xLineSub.ucLineId = 1;
  xLineSub.iid.config_owner = 1;
  if ( ifx_get_LineSubscription(&xLineSub,0) != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Subscription\n"));
    return ;
    
  } 

	/* Right now there is one entry of Line Event. */
  memset(&xLineEvents,0,sizeof(xLineEvents));
  xLineEvents.ucLineId = 1;
  xLineEvents.ucIndex  = 1;
  xLineEvents.iid.config_owner = IFX_WEB;
  if ( ifx_get_LineEvents(&xLineEvents,0) != IFX_VMAPI_SUCCESS )
  {
    ifx_httpdError (wp, 200, T ("GET is failing for Line Events\n"));
    return ;
    
  } 

	memset(&xVL,0,sizeof(x_IFX_VMAPI_VoiceLine));
	xVL.ucLineId = 1;
  if( ifx_get_VoiceLine(&xVL,0) != IFX_VMAPI_SUCCESS) 
  {
    ifx_httpdError (wp, 200, T ("Get for Voice Line failed\n"));
    return ;
  }

	/* If in the Basic User Account Information Domain name is blank and
	   previously no entry is created then nothing to be done. If Domain
	   name is entered and entry is there previously then modify the first
	   entry else if no entry is there then add one entry.*/
	/* Please not that the Basic User Account Authentication information is
	   mapped to the first entry of the authentication list in the advance
	   page. */
	if(1)
	{
		memset(&xAuth,0,sizeof(x_IFX_VMAPI_SipAuthCfg));
	  if(xLineSig1.ucNoOfSipAuthCfg >0)
	  {
	    xAuth.ucLineId = 1;
      xAuth.ucIndex = 1;
      xAuth.iid.config_owner = IFX_WEB;
      if(IFX_VMAPI_SUCCESS != ifx_get_AuthCfg(&xAuth,0)) 
      {
        ifx_httpdError (wp, 200, T ("Get for AuthCfg failed\n"));
        return ;
      }
			if((strcmp(xAuth.acSipAuthUsrName,pUsername) != 0)
			 ||(strcmp(xAuth.acSipAuthPasswd,pPass) != 0))
			{
        strcpy(xAuth.acSipAuthUsrName,pUsername);
	      strcpy(xAuth.acSipAuthPasswd,pPass);

        if(IFX_VMAPI_SUCCESS != ifx_set_AuthCfg(IFX_OP_MOD,&xAuth,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) 
	      {
   	      ifx_httpdError (wp, 200, T ("Set for AuthCfg failed\n"));
   	      return ;
        }
			}
		}
		else
		{
		  //IFX_CGI_DEBUG("AuthCFg=%d\n", xLineSig1.ucNoOfSipAuthCfg);
	    xAuth.ucLineId = 1;
      xAuth.ucIndex = 1;
      xAuth.iid.config_owner = IFX_WEB;
        
			strcpy(xAuth.acSipAuthUsrName,pUsername);
	    strcpy(xAuth.acSipAuthPasswd,pPass);
      if(IFX_VMAPI_SUCCESS != ifx_set_AuthCfg(IFX_OP_ADD,&xAuth,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) 
      {
        ifx_httpdError (wp, 200, T ("Set for AuthCfg failed -- ADD\n"));
        return ;
      }
      xLineSig1.ucNoOfSipAuthCfg++;
		}
	}

	gstrcpy (xLineSig1.acSipUserName, pUsername);
  gstrcpy (xLineSig1.acSipDispName, pDspname);
 
 	xLineSig1.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_LineSignaling(IFX_OP_MOD,&xLineSig1,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_vmapi_freeObjectList(&xLineSig1,IFX_VMAPI_VL_SIGNALING);
    ifx_httpdError (wp, 200, T ("SET is failing for Line Signaling\n"));
    return;
    
  } 
  ifx_vmapi_freeObjectList(&xLineSig1,IFX_VMAPI_VL_SIGNALING);

	
	
  /* Username has been changed. Change the DirName in VoiceLine */
	if((strcmp(xVL.acDirName , pUsername) != 0) || (xVL.ucState != 1) || (xVL.ucGatewayMode != 0))
	{
	  strcpy(xVL.acDirName,pUsername);
    xVL.ucState = 1;
    xVL.ucGatewayMode = 0;
 	  xVL.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVL,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, T ("Set for Voice Line failed\n"));
      return ;
    }
	}

/*  For Proxy and Registrar parameters*/
if(g_PROFILE_ID_IS < 1)
    {
	      g_PROFILE_ID_IS = 1;
    }

   memset(&xProfSign,0,sizeof(xProfSign));
   xProfSign.ucProfileId = g_PROFILE_ID_IS;
   xProfSign.iid.config_owner = IFX_WEB;
   if(IFX_VMAPI_SUCCESS != ifx_get_ProfileSignaling(&xProfSign,0))
   {
     ifx_httpdError (wp, 200, T ("Failed to get Profile Signaling\n"));
     return ;
   } 


	 if((strcmp(xProfSign.acUADomain,pUserAgent)!=0) ||
	   (xProfSign.bEnableProxy != atoi (pStatus)) ||
		  (xProfSign.unProxyPort != atoi (pPort)) ||
			(strcmp(xProfSign.acProxyAddr, pIP1) != 0) ||
			(xProfSign.bEnableRegistrar != atoi (RStatus)) ||
			(xProfSign.unRegistrarPort != atoi (RPort)) ||
			(strcmp(xProfSign.acRegistrarAddr, RIP1) != 0))
	 {
	   strcpy(xProfSign.acUADomain, pUserAgent );
	   strcpy(xProfSign.acProxyAddr, pIP1 );
     xProfSign.unProxyPort = atoi (pPort);
    xProfSign.bEnableProxy = 1;
    xProfSign.bEnableRegistrar = 1;
     strcpy (xProfSign.acRegistrarAddr, RIP1);
     xProfSign.unRegistrarPort = atoi (RPort);

     xProfSign.iid.config_owner = IFX_WEB;
     if( IFX_VMAPI_SUCCESS != ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfSign,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
     {
       ifx_httpdError (wp, 200, T ("Fail to send Profile Signaling data to VMAPI"));
     }
		/*Update VMS notifier address if Proxy address is changed*/
  	memset(&xVms,0,sizeof(xVms));
  	xVms.ucProfileId = g_PROFILE_ID_IS;
  	xVms.ucIndex = 1;
  	xVms.iid.config_owner = IFX_WEB;
  	if( IFX_VMAPI_SUCCESS == ifx_get_EventSubscribe(&xVms,0)){
  			/*Check if VMS is enabled, then only update VMS*/
    		if(xVms.acNotifierAddr[0] != '\0' && ( strcmp(xVms.acNotifierAddr,pIP1)
      || xVms.unNotifierPort != atoi(pPort)) )
    	{
        strcpy(xVms.acNotifierAddr,pIP1);
        xVms.unNotifierPort = atoi(pPort);
        ifx_set_EventSubscribe(IFX_OP_MOD,&xVms,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    	}
  	}
	}
	// To disable pfile state
  if(g_PROFILE_ID_IS < 1)
  {
    return;
	//g_PROFILE_ID_IS = 1;
  }
  
  xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
  xVoiceProf.iid.config_owner = IFX_WEB;

	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile (VP Status) !!!");
    return;
  }
     
	if(xVoiceProf.ucState != atoi(pDisable))
	{
  	xVoiceProf.ucState = atoi(pDisable);
		if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0))
  	{
    	ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile (VP Status) !!!");
    	return;
  	}
	}

	// To enable pfile state
  if(g_PROFILE_ID_IS < 1)
  {
    return;
	//g_PROFILE_ID_IS = 1;
  }
  
  xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
  xVoiceProf.iid.config_owner = IFX_WEB;

	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile (VP Status) !!!");
    return;
  }
     
	if(xVoiceProf.ucState != atoi(pState))
	{
  	xVoiceProf.ucState = atoi(pState);
		if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0))
  	{
    	ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile (VP Status) !!!");
    	return;
  	}
	}

  g_LINE_ID_IS = 1;
  system("/etc/rc.d/backup");
    f_cflag = 0;
  ifx_httpdNextPage (wp);

}

