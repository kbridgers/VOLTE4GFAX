/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_createline.c
 *        Abstract: CGI API's to Create Line ID
 *        Date    : 17-06-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
//#define IFX_TR104  
extern int g_LINE_ID_IS;
extern char_t g_cflag;;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_createline
 *  Description     : This function is called header_editline_advanced/basic page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
void
ifx_get_voip_sip_createline (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  int i=0;  
  x_IFX_VMAPI_VoiceService xVoiceServ;
  int32 iRet;
  char_t sValue[MAX_DATA_LEN];
  memset(&xVoiceServ,0,sizeof(xVoiceServ));
  xVoiceServ.iid.config_owner = IFX_WEB;
	iRet = ifx_get_VoiceService(&xVoiceServ,0);
  if (iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceService !!!");
    return ;
  }

  //ifx_httpdWrite(wp,T("<a onClick=\"javascript:parent.main3.location.href=\'pstn_advanced.asp\';void(0)\">PSTN Line</a>"));
  ifx_httpdWrite(wp,T("\t"));
  while(xVoiceServ.ucLineIdList[i] != 0)
  { 
	   x_IFX_VMAPI_VoiceLine xVoiceLine1;

  	if(g_LINE_ID_IS < 1)
	  {
	    return ;
	  }

	  memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
  	xVoiceLine1.ucLineId = xVoiceServ.ucLineIdList[i];
	  xVoiceLine1.iid.config_owner = IFX_WEB;

  	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0))
	  {
  	  ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
	    return ;
	  }

    uint32 ucValue = xVoiceLine1.ucState;
    if (1 == ucValue)
        gstrcpy (sValue, "Enabled");
    else
        gstrcpy (sValue, "Disabled");
		
		/* For Line Reg Status */
   	char_t RegStatus[20];
    if (xVoiceLine1.ucLineStatus == IFX_VMAPI_VL_STATUS_DISABLED)
     		gstrcpy (RegStatus, "INACTIVE");
    else if (xVoiceLine1.ucLineStatus == IFX_VMAPI_VL_STATUS_UP)
     		 gstrcpy (RegStatus, "ACTIVE");
    else if (xVoiceLine1.ucLineStatus == IFX_VMAPI_VL_STATUS_ERROR)
      	gstrcpy (RegStatus, "ERROR");
    else if (xVoiceLine1.ucLineStatus == IFX_VMAPI_VL_STATUS_REGISTERING)
      	gstrcpy (RegStatus, "REGISTERING");
 
    ifx_httpdWrite(wp,T("<tr><td>%d</td><td>%s</td><td>%s - %s</td><td><input type=\"radio\" name=\"lineselect\" onClick=\"selected=%d\"></td></tr>"),
                           i+2,xVoiceLine1.acName,sValue,RegStatus,xVoiceServ.ucLineIdList[i]+1);
    i++;
  }
  return ;
} /* ifx_get_voip_sip_createline() */

/*****************************************************************************
 *  Function Name   : ifx_addlinepage_adv
 *  Description     : This function is called by page_redirect_addline_adv.asp 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : If There is no Line or it reaches the Maximum Error
 *                    messages is thrown or otherwise add_line_advanced page
 *                    will be displayed.
 ****************************************************************************/ 
void 
ifx_addlinepage_adv(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 iRet=0,j=0;
	x_IFX_VMAPI_VoiceService xVoiceServ;
  memset(&xVoiceServ,0,sizeof(xVoiceServ));
  xVoiceServ.iid.config_owner = IFX_WEB;
  iRet = ifx_get_VoiceService(&xVoiceServ,0);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
      ifx_httpdError (wp, 200, T ("Cannot GET Voice Service\n"));
      return ;
  } 


  /* Max number of profiles reached. Throw an error.*/
  /* Get the position of the last created LineId from the LineIdList */
  while(xVoiceServ.ucLineIdList[j] != 0)
  {
      j++;
  }
    
  /* Max number of lines reached. Throw an error.*/
  if( j == IFX_VMAPI_MAX_VOICE_LINES)
  {
    ifx_httpdWrite(wp,T ("voip_errors.htm"));
    return ;
  }
	else
	{
    ifx_httpdWrite(wp,T ("page_createline.asp"));
    return ;
	}

}


/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_createline
 *  Description     : This function is called add_line_advanced/basic.asp 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : If TR104 is defined then the child Objects who has no
 *                    instances, will be created by the TR69 stack. This is
 *                    done by calling the ALM functions of respective child
 *                    Object. It doesn't create those Objects which have
 *                    instances. For example LineEvent, CodecList etc.

 ****************************************************************************/ 
void
ifx_set_voip_sip_createline (httpd_t wp, char_t *path, char_t *query) 
{
  int32 count1 ,x;//,index;
  x_IFX_VMAPI_VoiceLine xVoiceLine1;
  x_IFX_VMAPI_LineSubscription xLineSub1;
  x_IFX_VMAPI_LineCodecList xLineCodec;
  x_IFX_VMAPI_VoiceService xVoiceServ1;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
  x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodec;
 

#ifndef IFX_TR104
	x_IFX_VMAPI_LineSignaling xLineSign1;
  x_IFX_VMAPI_LineCallingFeatures xCallFeat1;
  //x_IFX_VMAPI_LineStats xLineStats;
  x_IFX_VMAPI_LineCodec xLineVoiceCodec;
  //x_IFX_VMAPI_SipAuthCfg xAuth;
  x_IFX_VMAPI_CodecDesc  xCodecEntry;
  x_IFX_VMAPI_CodecDesc  *pxTemp;
  x_IFX_VMAPI_LineVoiceProcessing xLineVoiceProcess;
#endif
    int32 j=0;

    /* Get the number of lines from the VoiceService LineIdList */
    memset(&xVoiceServ1,0,sizeof(xVoiceServ1));
    xVoiceServ1.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceServ1,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the Voice Service !!!");
      return ;
    }

		if (xVoiceServ1.ucLineIdList[0] == 0)
		{
      ifx_httpdError (wp, 200, "Number of lines is zero !!!");
      return ;
    }

    /* Get the position of the last created LineId from the LineIdList */
    while(xVoiceServ1.ucLineIdList[j] != 0)
    {
      j++;
    }
    /* Max number of lines reached. Throw an error.*/
    if( j == IFX_VMAPI_MAX_VOICE_LINES)
    {
      ifx_httpdError (wp, 200, T ("Cannot Add Line . Max Limit exceeded.\n"));
      return ;
    }

    memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
    xVoiceLine1.ucState = 0; 
    xVoiceLine1.ucProfileId = xVoiceServ1.ucProfileIdList[0];/*Assuming atleast one profile is created */ 
    /* Add a new VoiceLine instance */
   	xVoiceLine1.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_ADD,&xVoiceLine1,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the Voice Line - ADD !!!");
      return ;
    }

    /*Line is added already. Get the LineIdList*/
    j=0;
    memset(&xVoiceServ1,0,sizeof(xVoiceServ1));
    xVoiceServ1.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceServ1,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the Voice Service !!!");
      return ;
    }

		
    /* Get the position of the last created LineId from the LineIdList */
    while(xVoiceServ1.ucLineIdList[j] != 0)
    {
      j++;
    }
 
    /* Set the global LineId with the latest LineId from the LineIdList */
		if (j>0)
    	g_LINE_ID_IS = xVoiceServ1.ucLineIdList[j-1];
  

    /* If no error,Assigning Line Id to the AssoLineIds of profile */
    memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = xVoiceServ1.ucProfileIdList[0];
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile !!!");
      return;
    }

    count1=0;
    x=0;
    /* Checking if Line is already associated*/
    while(xVoiceProf.aucAssoLineIds[x] != 0)
    { 
      if(xVoiceProf.aucAssoLineIds[x] == g_LINE_ID_IS)
      {
			  break ; /* No need to set the VoiceProfile */
      } 
		  count1++;
      x++;
    } 

    /* If not associated then assign it to the AssoLineIds of the profile */
    xVoiceProf.aucAssoLineIds[count1] = g_LINE_ID_IS;
    xVoiceProf.ucNoOfLines+=1;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile !!!");
      return;
    }
//aarif
    memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
    xVoiceLine1.ucLineId = g_LINE_ID_IS;
    xVoiceLine1.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the VoiceLine !!!");
      return;
    }
    sprintf(xVoiceLine1.acName,"Line%d",g_LINE_ID_IS);
    xVoiceLine1.ucLineMode = 1;
    xVoiceLine1.ucIntrusion = 0;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine1,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the Voice Line - MOD !!!");
      return ;
    }
{
x_IFX_VMAPI_MissCallRegister xMissCallReg;
    /* Create the new instance of MissCall Reg */
    memset(&xMissCallReg,0,sizeof(xMissCallReg));
    xMissCallReg.ucLineId = g_LINE_ID_IS;
    xMissCallReg.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_MissCallReg(IFX_OP_ADD,&xMissCallReg,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the MissCallReg - ADD !!!");
      return ;
    }
ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
}
{
	
x_IFX_VMAPI_DialCallRegister xDialCallReg;

    /* Create the new instance of DialCall Reg */
    memset(&xDialCallReg,0,sizeof(xDialCallReg));
    xDialCallReg.ucLineId = g_LINE_ID_IS;
    xDialCallReg.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_DialCallReg(IFX_OP_ADD,&xDialCallReg,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the DialCallReg - ADD !!!");
      return ;
    }

ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
}
{
 x_IFX_VMAPI_RecvCallRegister xRecvCallReg;
    /* Create the new instance of MissCall Reg */
    memset(&xRecvCallReg,0,sizeof(xRecvCallReg));
    xRecvCallReg.ucLineId = g_LINE_ID_IS;
    xRecvCallReg.iid.config_owner = IFX_WEB;
                //xLineSign1.ucNoOfSipAuthCfg++;
    if(IFX_VMAPI_SUCCESS != ifx_set_RecvCallReg(IFX_OP_ADD,&xRecvCallReg,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the RecvCallReg - ADD !!!");
      return ;
    }
ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
}	

    /* Instance of the child object has to be created also */
#ifndef IFX_TR104		
    /* Create the new instance of LineSignaling */
    memset(&xLineSign1,0,sizeof(xLineSign1));
    xLineSign1.ucLineId = g_LINE_ID_IS;
 	  xLineSign1.iid.config_owner = IFX_WEB;
		//xLineSign1.ucNoOfSipAuthCfg++;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineSignaling(IFX_OP_ADD,&xLineSign1,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the LineSignaling - ADD !!!");
      return ;
    }
#endif

{
x_IFX_VMAPI_ContactList xContactList;
    /* Create the new instance of MissCall Reg */
    memset(&xContactList,0,sizeof(xContactList));
    xContactList.ucLineId = g_LINE_ID_IS;
    xContactList.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_ContactList(IFX_OP_ADD,&xContactList,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the MissCallReg - ADD !!!");
      return ;
    }
ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
}

    /* Create the new instance of LineSubscription */
    memset(&xLineSub1,0,sizeof(xLineSub1));
    xLineSub1.ucLineId = g_LINE_ID_IS;
#ifndef IFX_TR104
		/* Anyway Update_ChildInfo for .Line.{i}.SIP. will be incremented
		   if TR104 is configured */
		xLineSub1.ucNoOfLineEvents++;
#endif
 	  xLineSub1.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineSubscription(IFX_OP_ADD,&xLineSub1,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the LineSubscription - ADD !!!");
      return ;
    }

    /* Create the new instance of LineEvent.
       By default one will be created */
		x_IFX_VMAPI_LineEvents xLineEvent;
    memset(&xLineEvent,0,sizeof(xLineEvent));
    xLineEvent.ucLineId = g_LINE_ID_IS;
    xLineEvent.ucIndex = 1;
 	  xLineEvent.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineEvents(IFX_OP_ADD,&xLineEvent,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the LineEvent - ADD !!!");
      return ;
    }

		/* Get the Firmware supported Voice Codec capabilities list. The same
		   would be populated for Line also */
		memset(&xVoiceCodec,0,sizeof(xVoiceCodec));
		xVoiceCodec.iid.config_owner = IFX_WEB;
		if(IFX_VMAPI_SUCCESS != ifx_get_VoiceCodecCaps(&xVoiceCodec, 0))
		{
    	ifx_httpdError (wp, 200, T ("Get for Voice Codec Capabilities Failed\n"));
    	return ;
		}

		/* Create the new instance of LineCodecList */
    memset(&xLineCodec,0,sizeof(xLineCodec));
    xLineCodec.ucLineId = g_LINE_ID_IS;
 	  xLineCodec.iid.config_owner = IFX_WEB;
 	  xLineCodec.uiNumCodecs = xVoiceCodec.uiNumCodecs;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineCodecList(IFX_OP_ADD,&xLineCodec,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the LineCodecList - ADD !!!");
      return ;
    }
#ifndef IFX_TR104
		/* Copy each instance of capability list to Line Codec Entry and ADD it. */
		pxTemp = xVoiceCodec.pxCodecList;
		j=1;
  	while (pxTemp !=NULL) {
			memset(&xCodecEntry,0,sizeof(xCodecEntry));
			xCodecEntry.ucLineId = g_LINE_ID_IS;
    	xCodecEntry.ucIndex  = j;
    	xCodecEntry.iid.config_owner  = IFX_WEB;
   
			xCodecEntry.uiCodecId = pxTemp->uiCodecId;
    	xCodecEntry.unCodecSuppFrameLen = pxTemp->unCodecSuppFrameLen;
    	strcpy(xCodecEntry.acCodecName,pxTemp->acCodecName);    
			xCodecEntry.ucPayloadType = pxTemp->ucPayloadType;
			xCodecEntry.bEnable = IFX_TRUE;
			xCodecEntry.ucPriority = 1;

			if(IFX_VMAPI_SUCCESS !=ifx_set_CodecDesc(IFX_OP_ADD,&xCodecEntry, 0)) /* add this entry  */
    	{
      	ifx_httpdError (wp, 200, T ("Set for CodecDesc Failed - ADD\n"));
      	return ;
    	}
					
			j++;	
	  	__ifx_list_GetNext((void **)&pxTemp);
  	}
		ifx_vmapi_freeObjectList(&xVoiceCodec,IFX_VMAPI_CODEC_CAPABS);
#endif

#ifndef IFX_TR104
		/* Create the new instance of CallingFeature */
    memset(&xCallFeat1,0,sizeof(xCallFeat1));
    xCallFeat1.ucLineId = g_LINE_ID_IS;
 	  xCallFeat1.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineCallingFeatures(IFX_OP_ADD,&xCallFeat1,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the LineCallingFeatures - ADD !!!");
      return ;
    }

		/* Create the new instance of LineVoiceProcessing */
    memset(&xLineVoiceProcess,0,sizeof(xLineVoiceProcess));
    xLineVoiceProcess.ucLineId = g_LINE_ID_IS;
 	  xLineVoiceProcess.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineVoiceProcessing(IFX_OP_ADD,&xLineVoiceProcess,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET ifx_set_LineVoiceProcessing - ADD !!!");
      return ;
    }

		/* Create the new instance of LineVoiceCodec */
    memset(&xLineVoiceCodec,0,sizeof(xLineVoiceCodec));
    xLineVoiceCodec.ucLineId = g_LINE_ID_IS;
 	  xLineVoiceCodec.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineVoiceCodec(IFX_OP_ADD,&xLineVoiceCodec,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET ifx_set_LineVoiceCodec - ADD !!!");
      return ;
    }

#endif
  return;

}

