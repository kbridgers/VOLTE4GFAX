/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_contactlist.c
 *        Abstract: CGI API's to Access Contact List settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

extern int g_LINE_ID_IS;
static int f_cflag;
extern int g_EDIT_CONTACT_CPEID_IS;
extern int  g_EDIT_CONTACT_IS_COMMON;
static x_IFX_VMAPI_ContactListEntry xContactListEntry;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_contact_list
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_contact_list (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  
  char8 *name;
  int32 i;

x_IFX_VMAPI_ContactList xContactList;
x_IFX_VMAPI_ContactListEntry *pxTemp;
 

 if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  
  if (!gstrcmp (name, T ("cl")))
  {

	memset(&xContactList,0,sizeof(xContactList));
	xContactList.ucLineId =g_LINE_ID_IS;
	xContactList.iid.config_owner = IFX_WEB;
      
	if(IFX_VMAPI_SUCCESS != ifx_get_ContactList(&xContactList,0)){
    		ifx_httpdError (wp, 200, T ("Unable to Fetch Contact-List\n"));
    		return -1;
        }
					i=0;
        	ifx_httpdWrite (wp,T("<script type=\"text/javascript\">"));
        	ifx_httpdWrite (wp,T("maxLineEntries=%d;"),IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        	ifx_httpdWrite (wp,T("currentLineEntries=%d;"),xContactList.ucNoOfEntries);
        	ifx_httpdWrite (wp,T("</script>\n"));
	
				pxTemp = xContactList.pxContactEntries;
        while(pxTemp !=NULL)
        {
					i++;
        	ifx_httpdWrite (wp, "<tr >");
        	ifx_httpdWrite (wp, "<td class=\"curveLeft\">");
        	ifx_httpdWrite (wp,T("%d"),i);
        	ifx_httpdWrite (wp, "</td>");
        	ifx_httpdWrite (wp, "<td>");
        	ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acUserFirstName);
        	ifx_httpdWrite (wp, "</td>");
        	ifx_httpdWrite (wp, "<td >");
        	ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acUserLastName);
        	ifx_httpdWrite (wp, "</td>");
        	ifx_httpdWrite (wp, "<td >");
        	ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acContactNum);
        	ifx_httpdWrite (wp, T("</td>"));
        	ifx_httpdWrite (wp, "<td >");
        	ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acContactNumTwo);
        	ifx_httpdWrite (wp, T("</td>"));
        	ifx_httpdWrite (wp, T("<td >"));
        	ifx_httpdWrite (wp, T("<Input type=\"radio\" name=\"contact\" onClick=setContactInfo(\"%d\",\"%d\",\"0\");>"),i,pxTemp->iid.cpeId.Id);
        	//ifx_httpdWrite (wp, T("<a onClick=editContactEntry(\"%d\",\"%d\");>Edit</a>"),i,pxTemp->iid.cpeId.Id);
        	//ifx_httpdWrite (wp, T("   <a onClick=deleteContactEntry(\"%d\",\"%d\");>Delete</a>"),i,pxTemp->iid.cpeId.Id);
        	ifx_httpdWrite (wp, T("</td >"));
					ifx_httpdWrite (wp, T("</tr >\n"));
      		__ifx_list_GetNext((void *)&pxTemp);
			}
	
	memset(&xContactList,0,sizeof(xContactList));
	xContactList.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_CommonContactList(&xContactList,0)){
    		ifx_httpdError (wp, 200, T ("Unable to Fetch CommonContact-List\n"));
    		return -1;
        }
				i=0;
        	ifx_httpdWrite (wp,T("<script type=\"text/javascript\">"));
        	ifx_httpdWrite (wp,T("maxCommonEntries=%d;"),IFX_VMAPI_MAX_COMMON_CONTACT_LIST_ENTRIES);
        	ifx_httpdWrite (wp,T("currentCommonEntries=%d;"),xContactList.ucNoOfEntries);
        	ifx_httpdWrite (wp,T("</script>\n"));
				pxTemp = xContactList.pxContactEntries;
        while(pxTemp !=NULL)
        {
    			i++;
          ifx_httpdWrite (wp, "<tr >");
          ifx_httpdWrite (wp, "<td class=\"curveLeft\">");
          ifx_httpdWrite (wp,T("#%d"),i);
          ifx_httpdWrite (wp, "</td>");
          ifx_httpdWrite (wp, "<td>");
          ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acUserFirstName);
          ifx_httpdWrite (wp, "</td>");
          ifx_httpdWrite (wp, "<td >");
          ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acUserLastName);
          ifx_httpdWrite (wp, "</td>");
          ifx_httpdWrite (wp, "<td >");
          ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acContactNum);
          ifx_httpdWrite (wp, T("</td>"));
          ifx_httpdWrite (wp, "<td >");
          ifx_httpdWrite (wp,T("%s"),pxTemp->xAddress.acContactNumTwo);
          ifx_httpdWrite (wp, T("</td>"));
          ifx_httpdWrite (wp, T("<td >"));
          ifx_httpdWrite (wp, T("<Input type=\"radio\" name=\"contact\" onClick=setContactInfo(\"%d\",\"%d\",\"1\");>"),i,pxTemp->iid.cpeId.Id);
          //ifx_httpdWrite (wp, T("<a onClick=editContactEntry(\"%d\",\"%d\");>Edit</a>"),i,pxTemp->iid.cpeId.Id);
          //ifx_httpdWrite (wp, T("   <a onClick=deleteContactEntry(\"%d\",\"%d\");>Delete</a>"),i,pxTemp->iid.cpeId.Id);
          ifx_httpdWrite (wp, T("</td >"));
    			ifx_httpdWrite (wp, T("</tr >\n"));
          __ifx_list_GetNext((void *)&pxTemp);
  }
  ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);


} 
  if (!gstrcmp (name, T ("populatelist")))
  {

 				memset(&xContactList,0,sizeof(xContactList));
        xContactList.ucLineId =g_LINE_ID_IS;
        xContactList.iid.config_owner = IFX_WEB;

        if(IFX_VMAPI_SUCCESS != ifx_get_ContactList(&xContactList,0)){
                ifx_httpdError (wp, 200, T ("Unable to Fetch Contact-List\n"));
                return  -1;
        }
        i=0;
        ifx_httpdWrite (wp,T("var maxLineEntries=%d;"),IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        ifx_httpdWrite (wp,T("var currentLineEntries=%d;"),xContactList.ucNoOfEntries);

        pxTemp = xContactList.pxContactEntries;
       	if(g_EDIT_CONTACT_CPEID_IS !=0 && !g_EDIT_CONTACT_IS_COMMON ){
				 			while(pxTemp != NULL && pxTemp->iid.cpeId.Id != g_EDIT_CONTACT_CPEID_IS){
											//ifx_httpdWrite (wp,T("ListNames[%d]=\"%s\";"),i,pxTemp->xAddress.acUserLastName);
											ifx_httpdWrite (wp,T("ListNames[%d]=\"%s:%s\";"),i,pxTemp->xAddress.acUserFirstName,pxTemp->xAddress.acUserLastName);
											__ifx_list_GetNext((void *)&pxTemp);
              				i++;
          		}
				}else {
				 							while(pxTemp != NULL){
											//ifx_httpdWrite (wp,T("ListNames[%d]=\"%s\";"),i,pxTemp->xAddress.acUserLastName);
											ifx_httpdWrite (wp,T("ListNames[%d]=\"%s:%s\";"),i,pxTemp->xAddress.acUserFirstName,pxTemp->xAddress.acUserLastName);
											__ifx_list_GetNext((void *)&pxTemp);
              				i++;
          		}

				}
 				memset(&xContactList,0,sizeof(xContactList));
        xContactList.iid.config_owner = IFX_WEB;

        if(IFX_VMAPI_SUCCESS != ifx_get_CommonContactList(&xContactList,0)){
                ifx_httpdError (wp, 200, T ("Unable to Fetch CommonContact-List\n"));
                return  -1;
        }
        ifx_httpdWrite (wp,T("var maxCommonEntries=%d;"),IFX_VMAPI_MAX_COMMON_CONTACT_LIST_ENTRIES);
        ifx_httpdWrite (wp,T("var currentCommonEntries=%d;"),xContactList.ucNoOfEntries);
        
			 pxTemp = xContactList.pxContactEntries;
			 if(g_EDIT_CONTACT_CPEID_IS !=0 && g_EDIT_CONTACT_IS_COMMON ){
              while(pxTemp != NULL && pxTemp->iid.cpeId.Id != g_EDIT_CONTACT_CPEID_IS){
											//ifx_httpdWrite (wp,T("ListNames[%d]=\"%s\";"),i,pxTemp->xAddress.acUserLastName);
											ifx_httpdWrite (wp,T("ListNames[%d]=\"%s:%s\";"),i,pxTemp->xAddress.acUserFirstName,pxTemp->xAddress.acUserLastName);
                      __ifx_list_GetNext((void *)&pxTemp);
                      i++;
              }
        }else {
                      while(pxTemp != NULL){
											//ifx_httpdWrite (wp,T("ListNames[%d]=\"%s\";"),i,pxTemp->xAddress.acUserLastName);
											ifx_httpdWrite (wp,T("ListNames[%d]=\"%s:%s\";"),i,pxTemp->xAddress.acUserFirstName,pxTemp->xAddress.acUserLastName);
                      __ifx_list_GetNext((void *)&pxTemp);
                      i++;
              }

        }
		
ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST); 
  }
return 0;
}



int ifx_get_voip_sip_contact_entry(int eid, httpd_t wp, int argc, char_t ** argv)
{
  char8 *name;
 
if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

	if( f_cflag == 0)
        {

                memset(&xContactListEntry,0,sizeof(xContactListEntry));
                xContactListEntry.ucLineId = g_LINE_ID_IS;
                xContactListEntry.iid.cpeId.Id = g_EDIT_CONTACT_CPEID_IS;
                xContactListEntry.iid.config_owner = IFX_WEB;
					if(g_EDIT_CONTACT_IS_COMMON ){
                xContactListEntry.ucLineId = IFX_VMAPI_COMMON_CONTACT;
								 if(IFX_VMAPI_SUCCESS != ifx_get_CommonContactListEntry(&xContactListEntry,0))
           			{
                          ifx_httpdError (wp, 200, "Fail to get the Common contact list entry  !!!");
                           return -1;
           			}

					}else if(IFX_VMAPI_SUCCESS != ifx_get_ContactListEntry(&xContactListEntry,0))
           	{
                          ifx_httpdError (wp, 200, "Fail to get the contact list entry  !!!");
                           return -1;
           	}
        }
                
	
  if (!gstrcmp (name, T ("firstname")))
  {
        ifx_httpdWrite (wp,T("%s"),xContactListEntry.xAddress.acUserFirstName);
	return 0;
  }
  if (!gstrcmp (name, T ("lastname")))
  {
        ifx_httpdWrite (wp,T("%s"),xContactListEntry.xAddress.acUserLastName);
	return 0;
  }
  if (!gstrcmp (name, T ("contactnum")))
  {
        ifx_httpdWrite (wp,T("%s"),xContactListEntry.xAddress.acContactNum);
	return 0;
  }
  if (!gstrcmp (name, T ("contactnum2")))
  {
        ifx_httpdWrite (wp,T("%s"),xContactListEntry.xAddress.acContactNumTwo);
			f_cflag=0;	
	return 0;
	}
return 0;	                        
}

void
ifx_set_voip_sip_contactlist (httpd_t wp, char_t * path, char_t * query)
{
  char_t * pdelall = ifx_httpdGetVar (wp, T ("deleteall"), T (""));
  char_t * psavenew = ifx_httpdGetVar (wp, T ("savenew"), T (""));
  char_t * psaveedit = ifx_httpdGetVar (wp, T ("saveedit"), T (""));
  char_t * pdelentry = ifx_httpdGetVar (wp, T ("deleteentry"), T (""));
  char_t * peditentry = ifx_httpdGetVar (wp, T ("editcontact"), T (""));
	char_t * peditcancel = ifx_httpdGetVar (wp, T ("editcancel"), T (""));

if (gatoi (pdelall) == 1)
{
  	if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_CONTACT_LIST,g_LINE_ID_IS) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the ContactList  !!!");
        return;
    }
  	if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_COMMON_CONTACT_LIST,g_LINE_ID_IS) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte Common ContactList  !!!");
        return;
    }
	ifx_httpdNextPage_New(wp);
}

else if (gatoi (psavenew) == 1 )
{
			x_IFX_VMAPI_ContactListEntry xContactEntry;
			memset(&xContactEntry,0,sizeof(xContactEntry));

		char_t * pfirstname = ifx_httpdGetVar (wp, T ("firstname"), T (""));
		char_t * plastname =	   ifx_httpdGetVar (wp, T ("lastname"), T (""));
		char_t * pcontactnum =	   ifx_httpdGetVar (wp, T ("contactnum"), T (""));	 
		char_t * pcontactnum2 =	   ifx_httpdGetVar (wp, T ("contactnum2"), T (""));	 
		char_t * pisCommon =	   ifx_httpdGetVar (wp, T ("isCommon"), T (""));	 
                xContactEntry.ucLineId = g_LINE_ID_IS;
                xContactEntry.iid.config_owner = IFX_WEB;
 								gstrcpy(xContactEntry.xAddress.acUserFirstName,pfirstname);
                gstrcpy(xContactEntry.xAddress.acUserLastName,plastname);
                gstrcpy(xContactEntry.xAddress.acContactNum,pcontactnum);
                xContactEntry.xAddress.cContactType = 2;
                gstrcpy(xContactEntry.xAddress.acContactNumTwo,pcontactnum2);
                xContactEntry.xAddress.cContactTypeTwo = 4;
		if (gatoi (pisCommon) == 1){
							 xContactEntry.ucLineId = IFX_VMAPI_COMMON_CONTACT;	
							if(IFX_VMAPI_SUCCESS != ifx_set_CommonContactListEntry(IFX_OP_ADD,&xContactEntry,0))
        		{
                    ifx_httpdError (wp, 200, "Fail to Add the contact list entry  !!!");
                    return ;
        		}
	
		}else{
				if(IFX_VMAPI_SUCCESS != ifx_set_ContactListEntry(IFX_OP_ADD,&xContactEntry,0))
      	{
                		ifx_httpdError (wp, 200, "Fail to Add the contact list entry  !!!");
                		return ;	
				}
	}
	ifx_httpdNextPage_New(wp);
}
			
else if(gatoi (psaveedit) == 1){
			//copy the cpeid from the form hidden field
		char_t * pfirstname = ifx_httpdGetVar (wp, T ("firstname"), T (""));
		char_t * plastname =	   ifx_httpdGetVar (wp, T ("lastname"), T (""));
		char_t * pcontactnum =	   ifx_httpdGetVar (wp, T ("contactnum"), T (""));	 
		char_t * pcontactnum2 =	   ifx_httpdGetVar (wp, T ("contactnum2"), T (""));	 

							  xContactListEntry.ucLineId = g_LINE_ID_IS;
                xContactListEntry.iid.cpeId.Id = g_EDIT_CONTACT_CPEID_IS;
                xContactListEntry.iid.config_owner = IFX_WEB;
	
 								gstrcpy(xContactListEntry.xAddress.acUserFirstName,pfirstname);
                gstrcpy(xContactListEntry.xAddress.acUserLastName,plastname);
                gstrcpy(xContactListEntry.xAddress.acContactNum,pcontactnum);
                gstrcpy(xContactListEntry.xAddress.acContactNumTwo,pcontactnum2);
					if(g_EDIT_CONTACT_IS_COMMON ){
							  xContactListEntry.ucLineId = IFX_VMAPI_COMMON_CONTACT;
								if(IFX_VMAPI_SUCCESS != ifx_set_CommonContactListEntry(IFX_OP_MOD,&xContactListEntry,0))
        				{
                                ifx_httpdError (wp, 200, "Fail to Update the contact list entry  !!!");
                                return ;
        				}

				}else if(IFX_VMAPI_SUCCESS != ifx_set_ContactListEntry(IFX_OP_MOD,&xContactListEntry,0))
        	{
                                ifx_httpdError (wp, 200, "Fail to Update the contact list entry  !!!");
                                return ;
        	}
			g_EDIT_CONTACT_CPEID_IS=0;
			g_EDIT_CONTACT_IS_COMMON=0;
			f_cflag=0;	
	ifx_httpdNextPage_New(wp);
}

else if (gatoi (pdelentry) == 1)
{
	char_t * cisCommon = ifx_httpdGetVar (wp, T ("isCommon"), T (""));
		x_IFX_VMAPI_ContactListEntry xDelContactEntry;
		memset(&xDelContactEntry,0,sizeof(xDelContactEntry));
    xDelContactEntry.ucLineId = g_LINE_ID_IS;
    xDelContactEntry.iid.config_owner = IFX_WEB;
		xDelContactEntry.iid.cpeId.Id=gatoi(ifx_httpdGetVar (wp, T ("cpeid"), T ("")));
		xDelContactEntry.ucIndex=gatoi(ifx_httpdGetVar (wp, T ("index"), T ("")));				
		if(gatoi(cisCommon) == 1){
    xDelContactEntry.ucLineId = IFX_VMAPI_COMMON_CONTACT;
						if(IFX_VMAPI_SUCCESS != ifx_get_CommonContactListEntry(&xDelContactEntry,0))
           	{
                          ifx_httpdError (wp, 200, "Fail to get the contact list entry  !!!");
			               return ;
						}
											if(IFX_VMAPI_SUCCESS != ifx_set_CommonContactListEntry(IFX_OP_DEL,&xDelContactEntry,0))
                        {
                                ifx_httpdError (wp, 200, "Fail to Delete the contact list entry  !!!");
                                return ;
                        }

			}else {
						if(IFX_VMAPI_SUCCESS != ifx_get_ContactListEntry(&xDelContactEntry,0))
           	{
                          ifx_httpdError (wp, 200, "Fail to get the contact list entry  !!!");
													return ;
						}
						if(IFX_VMAPI_SUCCESS != ifx_set_ContactListEntry(IFX_OP_DEL,&xDelContactEntry,0))
            {
                                ifx_httpdError (wp, 200, "Fail to Delete the contact list entry  !!!");
			                          return ;
						}
			}
	ifx_httpdNextPage_New(wp);
}

else if (gatoi(peditentry) == 1)
{
	char_t * cpeid = ifx_httpdGetVar (wp, T ("cpeid"), T (""));
	char_t * cisCommon = ifx_httpdGetVar (wp, T ("isCommon"), T (""));
	g_EDIT_CONTACT_CPEID_IS=gatoi(cpeid);
	g_EDIT_CONTACT_IS_COMMON=atoi(cisCommon);	
	ifx_httpdNextPage (wp);
}
else if (gatoi(peditcancel) == 1)
{
			g_EDIT_CONTACT_CPEID_IS=0;
			g_EDIT_CONTACT_IS_COMMON=0;	
			f_cflag=0;
	ifx_httpdNextPage (wp);
}else
	ifx_httpdNextPage (wp);

}
