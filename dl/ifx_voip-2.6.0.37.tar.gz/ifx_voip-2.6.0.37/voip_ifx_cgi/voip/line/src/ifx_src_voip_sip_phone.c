/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_phone.c
 *        Abstract: CGI API's to Access Phone settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


void ifx_get_voip_make_fwd_array (httpd_t wp);

extern int g_LINE_ID_IS;
extern int g_CALLFWD;
static char_t f_cflag;;
static x_IFX_VMAPI_LineCallingFeatures xCallFeat;
extern int g_nChipVer;
CGI_ENUMSEL_S web_Forward_Types[]=
{
  {0,"Unconditional"},
  {1,"No Answer"},
  {2,"Busy"},
  //{3,"Do Not Disturb"},
};

/*****************************************************************************
 *  Function Name   : ifx_get_voip_make_fwd_array
 *  Description     : This function is called in add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
void
ifx_get_voip_make_fwd_array (httpd_t wp) 
{
  int32 nSelIndex = 0;
  if(f_cflag == 0)
  {
    memset(&xCallFeat,0,sizeof(x_IFX_VMAPI_LineCallingFeatures));
    xCallFeat.ucLineId = g_LINE_ID_IS;
    xCallFeat.iid.config_owner = IFX_WEB;
    if( ifx_get_LineCallingFeatures(&xCallFeat,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("<CURRENTPHONE>Get for CallingFeatures Failed The Line id is %d\n"),g_LINE_ID_IS);
      return ;
    }
    f_cflag =1;
  }

 /* Unconditional array populate */
  nSelIndex =
  (xCallFeat.unCallFwdCfg & IFX_VMAPI_CALL_FWD_UNCONDITIONAL) ? 1 : 0;
  ifx_httpdWrite (wp, T ("AFwdStatus[1] = %d;\n"), nSelIndex);
  nSelIndex = xCallFeat.xCfuAddress.ucAddrType -1;
  if (nSelIndex < 0)
    nSelIndex = 0;
  ifx_httpdWrite (wp, T ("AAddtype[1] = %d;\n"), nSelIndex);
  ifx_httpdWrite (wp, T ("ADname[1]=\"%s\";\n"),
                    xCallFeat.xCfuAddress.
                    acDisplayName);
  ifx_httpdWrite (wp, T ("AUname[1]=\"%s\";\n"),
                   xCallFeat.xCfuAddress.acUserName);
  ifx_httpdWrite (wp, T ("ACall[1]=\"%s\";\n"),
                   xCallFeat.xCfuAddress.acDestAddr);
  if (!xCallFeat.xCfuAddress.unPort)
    
  {
    ifx_httpdWrite (wp, T ("APort[1]=\"%d\";\n"), 0);
  }
  
  else
    
  {
    ifx_httpdWrite (wp, T ("APort[1]=\"%d\";\n"),
                     xCallFeat.xCfuAddress.unPort);
  }
 
    /* NoAns array populate  */ 
  nSelIndex =
    (xCallFeat.unCallFwdCfg & IFX_VMAPI_CALL_FWD_ON_NO_ANSWER) ? 1 : 0;
  ifx_httpdWrite (wp, T ("AFwdStatus[2] = %d;\n"), nSelIndex);
  nSelIndex = xCallFeat.xCfnaAddress.ucAddrType -1;
  if (nSelIndex < 0)
    nSelIndex = 0;
  ifx_httpdWrite (wp, T ("AAddtype[2] = %d;\n"), nSelIndex);
  ifx_httpdWrite (wp, T ("ADname[2]=\"%s\";\n"),
                    xCallFeat.xCfnaAddress.
                    acDisplayName);
  ifx_httpdWrite (wp, T ("AUname[2]=\"%s\";\n"),
                    xCallFeat.xCfnaAddress.acUserName);
  ifx_httpdWrite (wp, T ("ACall[2]=\"%s\";\n"),
                    xCallFeat.xCfnaAddress.acDestAddr);
  if (!xCallFeat.xCfnaAddress.unPort)
    
  {
    ifx_httpdWrite (wp, T ("APort[2]=\"%d\";\n"), 0);
  }
  else
  {
    ifx_httpdWrite (wp, T ("APort[2]=\"%d\";\n"),
                     xCallFeat.xCfnaAddress.unPort);
  }
 
  /* Busy array populate */ 
  nSelIndex =
    (xCallFeat.unCallFwdCfg & IFX_VMAPI_CALL_FWD_BUSY) ? 1 : 0;
  ifx_httpdWrite (wp, T ("AFwdStatus[3]=%d;\n"), nSelIndex);
  nSelIndex = xCallFeat.xCfbAddress.ucAddrType -1;
  if (nSelIndex < 0)
    nSelIndex = 0;
  ifx_httpdWrite (wp, T ("AAddtype[3]=%d;\n"), nSelIndex);
  ifx_httpdWrite (wp, T ("ADname[3]=\"%s\";\n"),
                    xCallFeat.xCfbAddress.acDisplayName);
  ifx_httpdWrite (wp, T ("AUname[3]=\"%s\";\n"),
                    xCallFeat.xCfbAddress.acUserName);
  ifx_httpdWrite (wp, T ("ACall[3]=\"%s\";\n"),
                   xCallFeat.xCfbAddress.acDestAddr);
  if (!xCallFeat.xCfbAddress.unPort)
    
  {
    ifx_httpdWrite (wp, T ("APort[3]=\"%d\";\n"), 0);
  }
  else
  {
    ifx_httpdWrite (wp, T ("APort[3]=\"%d\";\n"),
                     xCallFeat.xCfbAddress.unPort);
  }
 
  /* Do Not Disturb array populate */ 
  nSelIndex =
    (xCallFeat.unCallFwdCfg & IFX_VMAPI_CALL_FWD_DND) ? 1 : 0;
  ifx_httpdWrite (wp, T ("AFwdStatus[4]=%d;\n"), nSelIndex);
  nSelIndex = xCallFeat.xDndAddress.ucAddrType -1;
  if (nSelIndex < 0)
    nSelIndex = 0;
  ifx_httpdWrite (wp, T ("AAddtype[4]=%d;\n"), nSelIndex);
  ifx_httpdWrite (wp, T ("ADname[4]=\"%s\";\n"),
                    xCallFeat.xDndAddress.acDisplayName);
  ifx_httpdWrite (wp, T ("AUname[4]=\"%s\";\n"),
                    xCallFeat.xDndAddress.acUserName);
  ifx_httpdWrite (wp, T ("ACall[4]=\"%s\";\n"),
                   xCallFeat.xDndAddress.acDestAddr);
  if (!xCallFeat.xDndAddress.unPort)
    
  {
    ifx_httpdWrite (wp, T ("APort[4]=\"%d\";\n"), 0);
  }
  else
  {
    ifx_httpdWrite (wp, T ("APort[4]=\"%d\";\n"),
                     xCallFeat.xDndAddress.unPort);
  }
return;
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_phone
 *  Description     : This function is called in add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_phone (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  int32 nIndex = 0;
  char_t sValue[MAX_DATA_LEN];

  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if(g_LINE_ID_IS < 1)
  {
    return 0;
  }
  
if(f_cflag == 0)
  {
    memset(&xCallFeat,0,sizeof(x_IFX_VMAPI_LineCallingFeatures));
    xCallFeat.ucLineId = g_LINE_ID_IS;
    xCallFeat.iid.config_owner = IFX_WEB;
    if( ifx_get_LineCallingFeatures(&xCallFeat,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("<CURRENTPHONE>Get for CallingFeatures Failed The Line id is %d\n"),g_LINE_ID_IS);
      return -1 ;
    }
    f_cflag =1;
  }

  if (!gstrcmp (name, T ("PopulateArray")))
  {
    ifx_get_voip_make_fwd_array (wp);
 		return 0;
	}
	
	if (!gstrcmp (name, T ("callid")))
  {
		uint32 ucValue = xCallFeat.bEnableCid;
		if(ucValue == 1)
						ucValue =0;
		else
						ucValue = 1;
    for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
      else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
    }
  	return 0;
  }
  else if (!gstrcmp (name, T ("dnd")))
  {
		uint32 ucValue = xCallFeat.bEnableDnd;
    for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
      else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
    }

    return 0;
  }
  else if (!gstrcmp (name, T ("callwaiting")))
  {
		uint32 ucValue = xCallFeat.bEnableCallWaiting;
    for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_Enum_Status[nIndex].value, sValue,
                      web_Enum_Status[nIndex].str);
    }
    return 0;
  }
  else if (!gstrcmp (name, T ("anoncallblock")))
  {
		uint32 ucValue = xCallFeat.bEnableAcb;
    for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_Enum_Status[nIndex].value, sValue,
                      web_Enum_Status[nIndex].str);
    }
    return 0;
  }
  else if (!gstrcmp (name, T ("EnMwi")))
  {
    uint32 ucValue = xCallFeat.bEnableMwiIndication;
    for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_Enum_Status[nIndex].value, sValue,
                      web_Enum_Status[nIndex].str);
    }
    return 0;
   }

  else if (!gstrcmp (name, T ("fwd")))
  {
		uint32 ucValue = g_CALLFWD;
    for (nIndex = 0;
          nIndex < sizeof (web_Forward_Types) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_Forward_Types[nIndex].value, sValue,
                      web_Forward_Types[nIndex].str);
    }

    return 0;
  }

  else if (!gstrcmp (name, T ("callforward")))
  {
    uint32 ucValue = (xCallFeat.unCallFwdCfg & IFX_VMAPI_CALL_FWD_VOICE_MAIL) ? 1 : 0;
    for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_Enum_Status[nIndex].value, sValue,
                      web_Enum_Status[nIndex].str);

    }
		f_cflag = 0;
    return 0;
  }
 	
  else if (!gstrcmp (name, T ("fwdRing")))
  {
    ifx_httpdWrite (wp, T ("%d"),xCallFeat.ucCfnaRingCount);
    return 0;
  }
  
  return 0;
   
}
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_phone
 *  Description     : This function is called in add_line_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
void
ifx_set_voip_sip_phone (httpd_t wp, char_t * path, char_t * query) 
{
  //char_t * pEchoCan = ifx_httpdGetVar (wp, T ("echoCancel"), T (""));
  char_t * pDnd = ifx_httpdGetVar (wp, T ("dnd"), T (""));
 char_t * pCallid = ifx_httpdGetVar (wp, T ("callid"), T ("")); 
 char_t * pCallWait = ifx_httpdGetVar (wp, T ("callwaiting"), T (""));
  char_t * pfwdRing = ifx_httpdGetVar (wp, T ("fwdRing"), T (""));
   char_t * pAnonCallBlock = ifx_httpdGetVar (wp, T ("anoncallblock"), T (""));

  char_t * pFwdStatus1 = ifx_httpdGetVar (wp, T ("fwdStatus1"), T (""));
  char_t * pFwdStatus2 = ifx_httpdGetVar (wp, T ("fwdStatus2"), T (""));
  char_t * pFwdStatus3 = ifx_httpdGetVar (wp, T ("fwdStatus3"), T (""));

  //char_t * pFwd ;	//= ifx_httpdGetVar (wp, T ("fwd"), T (""));

  char_t * pAddtype1 = ifx_httpdGetVar (wp, T ("addtype1"), T (""));
  char_t * pAddtype2 = ifx_httpdGetVar (wp, T ("addtype2"), T (""));
  char_t * pAddtype3 = ifx_httpdGetVar (wp, T ("addtype3"), T (""));

  //char_t * pDname;	// = ifx_httpdGetVar (wp, T ("dname"), T (""));

  char_t * pUname1 = ifx_httpdGetVar (wp, T ("uname1"), T (""));
  char_t * pUname2 = ifx_httpdGetVar (wp, T ("uname2"), T (""));
  char_t * pUname3 = ifx_httpdGetVar (wp, T ("uname3"), T (""));

  char_t * pCalladdr1 = ifx_httpdGetVar (wp, T ("calladdr1"), T (""));
  char_t * pCalladdr2 = ifx_httpdGetVar (wp, T ("calladdr2"), T (""));
  char_t * pCalladdr3 = ifx_httpdGetVar (wp, T ("calladdr3"), T (""));

  char_t * pPortNo1 = ifx_httpdGetVar (wp, T ("portNo1"), T (""));
  char_t * pPortNo2 = ifx_httpdGetVar (wp, T ("portNo2"), T (""));
  char_t * pPortNo3 = ifx_httpdGetVar (wp, T ("portNo3"), T (""));

  char_t * pEnMwi = ifx_httpdGetVar (wp, T ("EnMwi"), T (""));
  char_t * pCallFwdVM = ifx_httpdGetVar (wp, T ("callforward"), T (""));

   memset(&xCallFeat,0,sizeof(x_IFX_VMAPI_LineCallingFeatures));
   xCallFeat.ucLineId = g_LINE_ID_IS;
   xCallFeat.iid.config_owner = IFX_WEB;
   if( ifx_get_LineCallingFeatures(&xCallFeat,0) != IFX_VMAPI_SUCCESS)
   {
      ifx_httpdError (wp, 200, T ("<CURRENTPHONE>Get for CallingFeatures Failed The Line id is %d\n"),g_LINE_ID_IS);
      return ;
   }
  
	/* Setting appropriate Boolean values in rc.conf*/ 
  /* For Caller Id*/
  xCallFeat.bEnableCid = atoi(pCallid);
  if( atoi(pCallid) == 1)
  {
    xCallFeat.bEnableCid = 0;
  }
  else
  {
    xCallFeat.bEnableCid = 1;
  }
  /* For Call Fwd Status*/
	if(atoi(pFwdStatus1)==1 || atoi(pFwdStatus2)==1 || atoi(pFwdStatus3)==1)
  xCallFeat.bFwdStatus = 1;

  /* Do Not Disturb*/
  xCallFeat.bEnableDnd = atoi(pDnd);
  /* For Anonymous Call Block */
  xCallFeat.bEnableAcb = atoi(pAnonCallBlock);

  /* For Call Waiting Status */
  xCallFeat.bEnableCallWaiting = atoi(pCallWait);

  xCallFeat.bEnableMwiIndication = atoi (pEnMwi);
  xCallFeat.ucCfnaRingCount = atoi (pfwdRing);
  //xCallFeat.unCallFwdCfg = atoi (pFwd);

	if(atoi(pCallFwdVM) == 1)
	{
    xCallFeat.unCallFwdCfg |= IFX_VMAPI_CALL_FWD_VOICE_MAIL;
	}
	else
	{
    xCallFeat.unCallFwdCfg &= ~IFX_VMAPI_CALL_FWD_VOICE_MAIL;
	}

  /* Depending on the Call Forward Access Type, the corresponding structure is filled and set*/
		if(atoi(pFwdStatus1))
		{
      xCallFeat.xCfuAddress.ucAddrType = atoi (pAddtype1)+1;
      xCallFeat.xCfuAddress.unPort = atoi (pPortNo1);
		  //strcpy(xCallFeat.xCfuAddress.acDisplayName, pDname);
 		  strcpy(xCallFeat.xCfuAddress.acUserName, pUname1);
  	  strcpy(xCallFeat.xCfuAddress.acDestAddr, pCalladdr1);
      xCallFeat.unCallFwdCfg |= IFX_VMAPI_CALL_FWD_UNCONDITIONAL;
		}
		else
      xCallFeat.unCallFwdCfg &= ~IFX_VMAPI_CALL_FWD_UNCONDITIONAL;
  
    if(atoi(pFwdStatus2))
		{
      xCallFeat.xCfnaAddress.ucAddrType = atoi (pAddtype2)+1;
      xCallFeat.xCfnaAddress.unPort = atoi (pPortNo2);
		  //strcpy(xCallFeat.xCfnaAddress.acDisplayName, pDname);
 		  strcpy(xCallFeat.xCfnaAddress.acUserName, pUname2);
  	  strcpy(xCallFeat.xCfnaAddress.acDestAddr, pCalladdr2);
      xCallFeat.unCallFwdCfg |= IFX_VMAPI_CALL_FWD_ON_NO_ANSWER;
		}
		else
      xCallFeat.unCallFwdCfg &= ~IFX_VMAPI_CALL_FWD_ON_NO_ANSWER;
    
		if(atoi(pFwdStatus3))
		{
      xCallFeat.xCfbAddress.ucAddrType = atoi (pAddtype3) +1;
      xCallFeat.xCfbAddress.unPort = atoi (pPortNo3);
		  //strcpy(xCallFeat.xCfbAddress.acDisplayName, pDname);
 		  strcpy(xCallFeat.xCfbAddress.acUserName, pUname3);
  	  strcpy(xCallFeat.xCfbAddress.acDestAddr, pCalladdr3);
      xCallFeat.unCallFwdCfg |= IFX_VMAPI_CALL_FWD_BUSY;
		}
		else
      xCallFeat.unCallFwdCfg &= ~IFX_VMAPI_CALL_FWD_BUSY;
  

 	xCallFeat.iid.config_owner = IFX_WEB;
  xCallFeat.ucLineId = g_LINE_ID_IS;
  if(ifx_set_LineCallingFeatures(IFX_OP_MOD,&xCallFeat,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("SET for LineCallingFeatures failed \n"));
    return;
  }

	f_cflag =0; 
  ifx_httpdNextPage_New(wp);

}


