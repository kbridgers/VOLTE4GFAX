/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_mdline.c
 *        Abstract: CGI API's to Access Delete Line
 *        Date    : 02-06-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
extern int g_LINE_ID_IS;
FILE *fp;
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_delline
 *  Description     : This function is called voip_line_summary.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_delline (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pdelline = ifx_httpdGetVar (wp, T ("line_num"), T (""));

  x_IFX_VMAPI_VoiceLine xVoiceLine;
  x_IFX_VMAPI_LineCodecList xLineCodec;
  x_IFX_VMAPI_LineSubscription xLineSub;
  x_IFX_VMAPI_VoiceService xVoiceServ;
	x_IFX_VMAPI_VoiceProfile xVoiceProf;
int32 x=0;
#ifndef IFX_TR104		
	int32 iCodecCount=0;
	int32 iLineSubCount=0;
	int32 iAuthCfgCount=0;
	int32 iNoOfSipAuthCfg=0;

 x_IFX_VMAPI_SipAuthCfg xAuthCfg;
 x_IFX_VMAPI_LineSignaling xLineSig;
  x_IFX_VMAPI_LineEvents xLineEv;
 x_IFX_VMAPI_LineCallingFeatures xCallFeat;
  x_IFX_VMAPI_LineVoiceProcessing xVoiceProc;
  x_IFX_VMAPI_CodecDesc xCodecDesc;
  x_IFX_VMAPI_LineCodec xLineVoiceCodec;
#endif

#ifndef IFX_TR104		
  /* Delete LineSignaling object */
	memset(&xLineSig,0,sizeof(xLineSig));
  xLineSig.ucLineId = atoi(pdelline);
  xLineSig.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_LineSignaling(&xLineSig,0))
  {
    ifx_httpdError (wp, 200, T ("Get for LineSignaling Failed\n"));
    return;
  } 
  ifx_vmapi_freeObjectList(&xLineSig,IFX_VMAPI_VL_SIGNALING);
  iNoOfSipAuthCfg = xLineSig.ucNoOfSipAuthCfg;	
	/* Delete AuthCfg first */
	for(iAuthCfgCount=0;iAuthCfgCount<xLineSig.ucNoOfSipAuthCfg;iAuthCfgCount++)
	{
		memset(&xAuthCfg,0,sizeof(xAuthCfg));
		xAuthCfg.ucLineId = atoi(pdelline);
    xAuthCfg.ucIndex = iAuthCfgCount+1;
		xAuthCfg.iid.config_owner = IFX_WEB;
		if(IFX_VMAPI_SUCCESS != ifx_set_AuthCfg(IFX_OP_DEL,&xAuthCfg,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, T ("Set for AuthCfg Failed-DEL\n"));
      return;
    } 
	}
  if(IFX_VMAPI_SUCCESS != ifx_set_LineSignaling(IFX_OP_DEL,&xLineSig,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_httpdError (wp, 200, T ("Set for LineSignaling Failed-DEL\n"));
    return;
  } 
		
#endif	
x_IFX_VMAPI_MissCallRegister xMissCallReg;
x_IFX_VMAPI_MissCallRegister xRecvCallReg;
x_IFX_VMAPI_MissCallRegister xDialCallReg;
x_IFX_VMAPI_ContactList xContactList;
 
if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_MISSCALL_REGISTER,atoi(pdelline)) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the MissCall - Entries !!!");
        return;
    }
	//Delete the parent MissCall Reg....
    memset(&xMissCallReg,0,sizeof(xMissCallReg));
    xMissCallReg.iid.config_owner = IFX_WEB;
    xMissCallReg.ucLineId = atoi(pdelline);
if(IFX_VMAPI_SUCCESS != ifx_set_MissCallReg(IFX_OP_DEL,&xMissCallReg,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the MissCall Register - DEL !!!");
      return ;
    }

if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_RECVCALL_REGISTER,atoi(pdelline)) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the RecvCall -Entries  !!!");
        return;
    }
	//Delete the parent RecvCall Reg....
    memset(&xRecvCallReg,0,sizeof(xRecvCallReg));
    xRecvCallReg.iid.config_owner = IFX_WEB;
    xRecvCallReg.ucLineId = atoi(pdelline);
if(IFX_VMAPI_SUCCESS != ifx_set_RecvCallReg(IFX_OP_DEL,&xRecvCallReg,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the RecvCall Register - DEL !!!");
      return ;
    }
if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_DIALCALL_REGISTER,atoi(pdelline)) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the DialCall - Entries  !!!");
        return;
    }
//Delete the parent DialCall Reg....
    memset(&xDialCallReg,0,sizeof(xDialCallReg));
    xDialCallReg.iid.config_owner = IFX_WEB;
    xDialCallReg.ucLineId = atoi(pdelline);
if(IFX_VMAPI_SUCCESS != ifx_set_DialCallReg(IFX_OP_DEL,&xDialCallReg,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the DialCall Register - DEL !!!");
      return ;
    }
	 if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_CONTACT_LIST,atoi(pdelline)) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the Contact Entries  !!!");
        return;
    }
//delete the Contact entry's.....
    memset(&xContactList,0,sizeof(xContactList));
    xContactList.iid.config_owner = IFX_WEB;
    xContactList.ucLineId = atoi(pdelline);

if(IFX_VMAPI_SUCCESS != ifx_set_ContactList(IFX_OP_DEL,&xContactList,0))
    {
      ifx_httpdError (wp, 200, "Fail to SET the ContactList - DEL !!!");
      return ;
    }

	/* Delete LineSubscription object */
	memset(&xLineSub,0,sizeof(xLineSub));
  xLineSub.ucLineId = atoi(pdelline);
  xLineSub.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_LineSubscription(&xLineSub,0))
  {
    ifx_httpdError (wp, 200, T ("Get for LineSubscription Failed\n"));
    return;
  } 
  ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);

#ifndef IFX_TR104		
  /* Delete LineEvents first */	
	for(iLineSubCount =0;iLineSubCount<xLineSub.ucNoOfLineEvents;iLineSubCount++)
	{
		memset(&xLineEv,0,sizeof(xLineEv));
		xLineEv.ucLineId = atoi(pdelline);
    xLineEv.ucIndex = iLineSubCount+1;
		xLineEv.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_LineEvents(IFX_OP_DEL,&xLineEv,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, T ("Set for CodecDesc Failed-DEL\n"));
      return;
    }  
	}
#endif	


  /* Delete LineCodecList object */
	memset(&xLineCodec,0,sizeof(xLineCodec));
  xLineCodec.ucLineId = atoi(pdelline);
  xLineCodec.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_LineCodecList(&xLineCodec,0))
  {
    ifx_httpdError (wp, 200, T ("Get for Line Codec List Failed-DEL\n"));
    return;
  }
  ifx_vmapi_freeObjectList(&xLineCodec,IFX_VMAPI_VL_CODECLIST);

#ifndef IFX_TR104		
	/* Delete all the CodecDesc */
	for(iCodecCount =0;iCodecCount<xLineCodec.uiNumCodecs;iCodecCount++)
	{
	
		memset(&xCodecDesc,0,sizeof(xCodecDesc));
		xCodecDesc.ucLineId = atoi(pdelline);
    xCodecDesc.ucIndex = iCodecCount+1;
		xCodecDesc.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_CodecDesc(IFX_OP_DEL,&xCodecDesc,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, T ("Set for CodecDesc Failed-DEL\n"));
      return;
    }  
	}

		
	/* Delete LineCallingFeatures object */
	memset(&xCallFeat,0,sizeof(xCallFeat));
  xCallFeat.ucLineId = atoi(pdelline);
  xCallFeat.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_LineCallingFeatures(IFX_OP_DEL,&xCallFeat,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_httpdError (wp, 200, T ("Set for Line Calling Features Failed-DEL\n"));
    return;
  } 


	/* Delete LineVoiceCodec object */
	memset(&xLineVoiceCodec,0,sizeof(xLineVoiceCodec));
  xLineVoiceCodec.ucLineId = atoi(pdelline);
  xLineVoiceCodec.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_LineVoiceCodec(IFX_OP_DEL,&xLineVoiceCodec,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_httpdError (wp, 200, T ("Set failed for LineVoiceCodec-DEL\n"));
    return;
  } 
	
	/* Delete LineVoiceProcessing object */
	memset(&xVoiceProc,0,sizeof(xVoiceProc));
  xVoiceProc.ucLineId = atoi(pdelline);
  xVoiceProc.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_LineVoiceProcessing(IFX_OP_DEL,&xVoiceProc,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_httpdError (wp, 200, T ("Set failed for LineVoiceProcessing-DEL\n")); //aarif
    return;
  } 

#endif
		
	/* Delete selected Line */
	memset(&xVoiceLine,0,sizeof(xVoiceLine));
  xVoiceLine.ucLineId = atoi(pdelline);
  xVoiceLine.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_DEL,&xVoiceLine,0))
  {
    ifx_httpdError (wp, 200, T ("Set for Voice Line Failed-DEL\n"));
    return ;
  }
	
	if(IFX_VMAPI_SUCCESS != ifx_set_LineSubscription(IFX_OP_DEL,&xLineSub,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_httpdError (wp, 200, T ("Set for Line Subscription Failed-DEL\n"));
    return;
  }

	if(IFX_VMAPI_SUCCESS != ifx_set_LineCodecList(IFX_OP_DEL,&xLineCodec,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    ifx_httpdError (wp, 200, T ("Set for Line Codec List Failed-DEL\n"));
    return;
  }

 /* If no error,Remove Line Id from the AssoLineIds of profile */
    memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = 1;
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile !!!");
      return;
    }

    /* Checking if Line is already associated*/
    while(xVoiceProf.aucAssoLineIds[x] != 0)
    {
      if(xVoiceProf.aucAssoLineIds[x] == atoi(pdelline) )
      {
					while(xVoiceProf.aucAssoLineIds[x] != 0){
        		xVoiceProf.aucAssoLineIds[x]=xVoiceProf.aucAssoLineIds[x+1];	
						x++;
					}
				continue;	
			}
      x++;
    }

    /* If not associated then assign it to the AssoLineIds of the profile */
    xVoiceProf.ucNoOfLines-=1;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
                            IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile !!!");
      return;
    }


//To remove access error from info page on deleting a line
  memset(&xVoiceServ,0,sizeof(xVoiceServ)); 
  xVoiceServ.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceServ,0))
   {
    ifx_httpdError (wp, 200, T ("Get for Voice Service Failed\n"));
    return;
   } 
  g_LINE_ID_IS = xVoiceServ.ucLineIdList[0];
  ifx_httpdNextPage_New(wp);
  
}

