/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_addrbook.c
 *        Abstract: CGI API's to Access address book
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int16 nNoOfPbEntries;
EXTERN char IFX_ValidateIpAddress (unsigned char *pszBuff);
int ifx_get_voip_addrbook (int eid, httpd_t wp, int argc, char_t ** argv);

extern int FXS_LINE_ID_IS;
extern int FXO_LINE_ID_IS;
extern int g_LINE_ID_IS;

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_addrbook
 *  Description     : This function is called in the voipsys_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  success 
 *                   -1  failure
 *  Notes           :
 ****************************************************************************/
int
ifx_get_voip_sip_addrbook (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  char_t sValue[MAX_DATA_LEN];
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
    
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
  memset (sValue, 0x00, MAX_DATA_LEN);
  if (!gstrcmp (name, T ("updateData")))
  {
    strcpy (argv[0], "port1");
    ifx_get_voip_addrbook (eid, wp, argc, argv);
  }
  else if (!gstrcmp (name, T ("ADial")))
  {
    
#ifndef IIP
      ifx_httpdWrite (wp, "document.sd.dial.value= ADial[num];\n");
#endif 
  }
  else if (!gstrcmp (name, T ("DialCode")))
  {
    
#ifndef IIP
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<input type=\"INT\" name=\"dial\" maxlength=16 " 
                     "size=\"16\" value=\"\">&nbsp;");
    ifx_httpdWrite (wp, "</td>");
    
#endif 
  }
  else if (!gstrcmp (name, T ("VADTAG")))
  {
    
#ifdef IIP
    ifx_httpdWrite (wp, "<td>");
    ifx_httpdWrite (wp, "<select name=\"vad\" >");
    ifx_httpdWrite (wp, "<option value=0 selected>TAG_OFF</option>");
    ifx_httpdWrite (wp, "<option value=1>TAG_ON</option>");
    ifx_httpdWrite (wp, "</select>");
    ifx_httpdWrite (wp, "</td>");
    
#endif 
  }
  else if (!gstrcmp (name, T ("DisVad")))
  {
    
#ifdef IIP
    ifx_httpdWrite (wp, "document.sd.vad.selectedIndex = AVad[num];");
    ifx_httpdWrite (wp, "document.sd.vad.disabled = true;");
    
#endif 
  }
  return 0;
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_addrbook
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_addrbook (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  int nIndex = 0;
  x_IFX_VMAPI_AddressBook xAddrBook;
  x_IFX_VMAPI_AddressBookEntry *pxTemp1;
  
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  memset(&xAddrBook,0,sizeof(xAddrBook));
  xAddrBook.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,0))
  {
    ifx_httpdError (wp, 200, T ("Get for AddrBook failed\n"));
    return -1;
  }
  else { 

  if (!gstrcmp (name, T ("port1")))
  {
  
    nNoOfPbEntries = xAddrBook.ucNoOfAddBookEntries;
  ifx_httpdWrite (wp,T( "maxAddrBookEntries = %d;"),IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES);
  ifx_httpdWrite (wp,T( "document.sd.addrEntries.length = %d;"),
                    nNoOfPbEntries);
    
    if (nNoOfPbEntries == 0)
    {
      ifx_httpdWrite (wp,T( "loc[0]=0;\n"));
      ifx_httpdWrite (wp,T( "field[0]=0;\n"));
      ifx_httpdWrite (wp,T( "ACallType[0]=0;\n"));
      ifx_httpdWrite (wp,T( "AAddrType[0]=0;\n"));
      ifx_httpdWrite (wp, T("document.sd.addrEntries[0] =" 
                       "new Option(\" \");\n"));
      ifx_httpdWrite (wp,T( "document.sd.addrEntries[0].value = 0;"));
      ifx_httpdWrite (wp,T( "AUName[0]=\"\";\n"));
      ifx_httpdWrite (wp,T( "ADName[0]=\"\";\n"));
      ifx_httpdWrite (wp,T( "AAddr[0]=\"\";\n"));
      ifx_httpdWrite (wp,T( "APort[0]=\"5060\";\n"));
      ifx_httpdWrite (wp,T( "Aaddrproto[0]=\"\";\n"));
      
#ifndef IIP
        ifx_httpdWrite (wp, T("ADial[0]=\"\";\n"));
#endif 
#ifdef IIP
        ifx_httpdWrite (wp,T( "AVad[0]=0;\n"));
#endif 
    }

    nIndex =0;
    pxTemp1 = xAddrBook.pxAddressBook;
    while (pxTemp1 !=NULL) {
      
      ifx_httpdWrite (wp,T( "loc[%d]=%d;\n"), nIndex, nIndex);
      ifx_httpdWrite (wp,T( "field[%d]=%d;\n"), nIndex, nIndex);
      ifx_httpdWrite (wp,T( "ACallType[%d]=%d;\n"), nIndex, pxTemp1->eCallType);
      ifx_httpdWrite (wp,T( "AAddrType[%d]=%d;\n"), nIndex, pxTemp1->xAddress.ucAddrType);
      ifx_httpdWrite (wp,T( "AUName[%d]=\"%s\";\n"), nIndex,
                       pxTemp1->xAddress.acUserName);
      ifx_httpdWrite (wp,T( "ADName[%d]=\"%s\";\n"), nIndex,
                        pxTemp1->xAddress.acDisplayName);
      ifx_httpdWrite (wp,T( "AAddr[%d]=\"%s\";\n"), nIndex,
                       pxTemp1->xAddress.acDestAddr);
      ifx_httpdWrite (wp,T( "APort[%d]=\"%d\";\n"), nIndex,
                       pxTemp1->xAddress.unPort);
#ifndef IIP
      ifx_httpdWrite (wp,T( "ADial[%d]=\"%s\";\n"), nIndex, pxTemp1->acDialCode);
        
#endif 
      if (pxTemp1->xAddress.ucAddrProto == 0)
          ifx_httpdWrite (wp,T( "Aaddrproto[%d]=0;\n"), nIndex);
      else if (pxTemp1->xAddress.ucAddrProto == 1)
          ifx_httpdWrite (wp,T( "Aaddrproto[%d]=1;\n"), nIndex);
      else
          ifx_httpdWrite (wp,T( "Aaddrproto[%d]=2;\n"), nIndex);
        
#ifdef IIP
      if (pxTemp1->ucVectorIndex == 0)
          ifx_httpdWrite (wp,T( "AVad[%d]=0;\n"), nIndex);
      else
          ifx_httpdWrite (wp,T( "AVad[%d]=1;\n"), nIndex);
        
#endif  
      if(pxTemp1->eCallType ==IFX_PSTN_NUM )
      {
        ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                           "new Option(\"%d -- %s/%s\");\n"), nIndex,
                            nIndex + 1,
                            pxTemp1->acDialCode,
                            pxTemp1->xAddress.acDisplayName);
          ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d].value "  "= %d;"),nIndex, nIndex);
      }
      else if(pxTemp1->eCallType ==IFX_EXTN_NUM )
      {
        ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                           "new Option(\"%d -- %s/%s\");\n"), nIndex,
                            nIndex + 1,
                            pxTemp1->acDialCode,
                            pxTemp1->xAddress.acUserName);
          ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d].value "  "= %d;"),nIndex, nIndex);
      }
      else
      {
        switch (pxTemp1->xAddress.ucAddrType)
        {
          case IFX_IP_ADDR:
          case IFX_SIP_URL:
#ifdef IIP
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                           "new Option(\"%d -- %s/%s\");\n"), nIndex,
                            nIndex + 1,
                            pxTemp1->xAddress.acUserName ,
                            pxTemp1->xAddress.acDisplayName);
#else
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                           "new Option(\"%d -- %s/%s\");\n"), nIndex,
                            nIndex + 1,
                            pxTemp1->acDialCode,
                            pxTemp1->xAddress.acDisplayName);

#endif
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d].value "  "= %d;"),nIndex, nIndex);
           break;
          case IFX_TEL_NUM:
#ifdef IIP
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                          "new Option(\"%d -- %s\");\n"), nIndex, nIndex + 1,
                           pxTemp1->xAddress.acDisplayName);
#else
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                          "new Option(\"%d -- %s/%s\");\n"),
                           nIndex, nIndex + 1,
                           pxTemp1->acDialCode,
                           pxTemp1->xAddress.acDisplayName);
     
#endif
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d].value = "  "%d;"),
                          nIndex, nIndex);
        
           break;
          case IFX_EXTN:
          default:
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d] = " 
                         "new Option(\"%d -- \");\n"), nIndex, nIndex + 1);
           ifx_httpdWrite (wp,T( "document.sd.addrEntries[%d].value = " 
                         "%d;"), nIndex, nIndex);
           ifx_httpdWrite (wp,T( "AUName[%d]=\"\";\n"), nIndex);
           ifx_httpdWrite (wp,T( "ADName[%d]=\"\";\n"), nIndex);
           ifx_httpdWrite (wp,T( "AAddr[%d]=\"\";\n"), nIndex);
           ifx_httpdWrite (wp,T( "APort[%d]=\"\";\n"), nIndex);
           ifx_httpdWrite (wp,T( "ADial[%d]=\"\";\n"), nIndex);
       }
      }
     nIndex = nIndex + 1;

     __ifx_list_GetNext((void *)&pxTemp1);
    }/* while loop */
   }/* port1 */
  }/* if IFX_VMAPI_SUCCESS */

  ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);

  return 0;
}


/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_addrbook
 *  Description     : This function is called in the voipsys_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/
void
ifx_set_voip_sip_addrbook (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * paddflag = ifx_httpdGetVar (wp, T ("addflag"), T (""));
  char_t * pmodflag = ifx_httpdGetVar (wp, T ("modflag"), T (""));
  char_t * pdelflag = ifx_httpdGetVar (wp, T ("delflag"), T (""));
  char_t * pdelallflag = ifx_httpdGetVar (wp, T ("delallflag"), T (""));
  char_t * paddrEntries = ifx_httpdGetVar (wp, T ("addrEntries"), T (""));
  
#ifndef IIP        
  char_t * pdial = ifx_httpdGetVar (wp, T ("dial"), T (""));
  
#endif 
  char_t * pcalltype = ifx_httpdGetVar (wp, T ("calltype"), T (""));
  char_t * paddrtype = ifx_httpdGetVar (wp, T ("addrtype"), T (""));
  char_t * puname = ifx_httpdGetVar (wp, T ("uname"), T (""));
  char_t * pdname = ifx_httpdGetVar (wp, T ("dname"), T (""));
  char_t * paddr = ifx_httpdGetVar (wp, T ("addr"), T (""));
  char_t * pport = ifx_httpdGetVar (wp, T ("port"), T (""));
  char_t * pproto = ifx_httpdGetVar (wp, T ("addrproto"), T (""));

  if (gatoi (paddflag) == 1)  /* press Add button */
  {
    x_IFX_VMAPI_AddressBook xAddrBook;
    x_IFX_VMAPI_AddressBookEntry xAddrEntry;

    memset(&xAddrBook,0,sizeof(xAddrBook));
    xAddrBook.iid.config_owner = IFX_WEB;
	  if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the ADDRESS BOOK !!!");
      return;
    }
    memset(&xAddrEntry,0,sizeof(xAddrEntry));

    if (nNoOfPbEntries == IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES)
    {
      ifx_httpdError (wp, 200,T(
                   "Max Phone Book Entries exceeded, Cannot add more!!!"));
      return;
    }
    xAddrEntry.eCallType = gatoi (pcalltype);
    xAddrEntry.xAddress.ucAddrType = gatoi (paddrtype);
    xAddrEntry.xAddress.ucAddrProto = gatoi (pproto);
    gstrcpy (xAddrEntry.xAddress.acDisplayName, pdname);
    gstrcpy (xAddrEntry.xAddress.acUserName, puname);
    gstrcpy (xAddrEntry.xAddress.acDestAddr, paddr);
    xAddrEntry.xAddress.unPort = gatoi (pport);
#ifndef IIP
    gstrcpy (xAddrEntry.acDialCode, pdial);
#endif  /*  */

    xAddrEntry.ucIndex = xAddrBook.ucNoOfAddBookEntries+1;
 	  xAddrEntry.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_AddrEntry(IFX_OP_ADD,&xAddrEntry,0))
    {
      ifx_httpdError (wp, 200, "Fail to ADD the ADDRESS BOOK Entry !!!");
      return;
    }
    xAddrBook.ucNoOfAddBookEntries ++;

    if(IFX_VMAPI_SUCCESS != ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to ADD the ADDRESS BOOK  !!!");
      return;
    }
  	ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
  }
  if (gatoi (pmodflag) == 1)  /* press Modify button */
  { 
    x_IFX_VMAPI_AddressBookEntry newEntry;
    memset(&newEntry,0,sizeof(newEntry));
		newEntry.ucIndex = gatoi(paddrEntries)+1;
 	  newEntry.iid.config_owner = IFX_WEB;
		if(IFX_VMAPI_SUCCESS != ifx_get_AddrEntry(&newEntry,0))
    {
      ifx_httpdError (wp, 200, "<MOD>Fail to GET the ADDRESS BOOK Entry !!!");
      return;
    }
    if (nNoOfPbEntries == 0)
    {
      ifx_httpdError (wp, 200,T("NO Phone Book Entries , Cannot modify !!!"));
      return;
    }

    newEntry.eCallType = gatoi (pcalltype);
    newEntry.xAddress.ucAddrType = gatoi (paddrtype);
    newEntry.xAddress.ucAddrProto = gatoi (pproto);
    gstrcpy (newEntry.xAddress.acDisplayName, pdname);
    gstrcpy (newEntry.xAddress.acUserName, puname);
    gstrcpy (newEntry.xAddress.acDestAddr, paddr);
    newEntry.xAddress.unPort = gatoi (pport);
#ifndef IIP
    gstrcpy (newEntry.acDialCode, pdial);
#endif  /*  */
#ifdef IIP		
    newEntry.ucVectorIndex = oldEntry.ucVectorIndex;
#endif  /*IIP*/		
    
    if(IFX_VMAPI_SUCCESS != ifx_set_AddrEntry(IFX_OP_MOD,&newEntry,0))
    {
      ifx_httpdError (wp, 200, "Fail to Modify the ADDRESS BOOK Entry !!!");
      return;
    }
  }

  if (gatoi (pdelflag) == 1)   /* press Delete button */
  {
    x_IFX_VMAPI_AddressBook xAddrBook;
    x_IFX_VMAPI_AddressBookEntry xDelEntry;
    if (nNoOfPbEntries == 0)
    {
      ifx_httpdError (wp, 200, "NO Phone Book Entries , Cannot del !!!");
      return;
    }

    memset(&xAddrBook,0,sizeof(xAddrBook));
    xAddrBook.iid.config_owner = IFX_WEB;
	  if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the ADDRESS BOOK !!!");
      return;
    }
    xDelEntry.ucIndex = gatoi(paddrEntries)+1;
		xDelEntry.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_AddrEntry(IFX_OP_DEL,&xDelEntry,0))
    {
      ifx_httpdError (wp, 200, "Fail to Delete the ADDRESS BOOK Entry !!!");
      return;
    }
    xAddrBook.ucNoOfAddBookEntries --;

    if(IFX_VMAPI_SUCCESS != ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to MODIFY the ADDRESS BOOK  !!!");
      return;
    }
  	ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
  }

  if (gatoi (pdelallflag) == 1)   /* press Delete All button */
  {
		//int32 i=0;
		x_IFX_VMAPI_AddressBook xAddrBook;
    //x_IFX_VMAPI_AddressBookEntry xDelEntry;
    if (nNoOfPbEntries == 0)
    {
      ifx_httpdError (wp, 200, "NO Phone Book Entries , Cannot del !!!");
      return;
    }

    memset(&xAddrBook,0,sizeof(x_IFX_VMAPI_AddressBook));
    xAddrBook.iid.config_owner = IFX_WEB;
	  if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the ADDRESS BOOK !!!");
      return;
    }

    if(IFX_VMAPI_SUCCESS != ifx_set_AddrBook(IFX_OP_DEL,&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to DEL the ADDRESS BOOK  !!!");
      return;
    }
		xAddrBook.ucNoOfAddBookEntries =0;
		xAddrBook.pxAddressBook = NULL;
    if(IFX_VMAPI_SUCCESS != ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,0))
    {
      ifx_httpdError (wp, 200, "Fail to ADD the ADDRESS BOOK  !!!");
      return;
    }
  	ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
	}
	
  ifx_httpdNextPage_New(wp);
}






