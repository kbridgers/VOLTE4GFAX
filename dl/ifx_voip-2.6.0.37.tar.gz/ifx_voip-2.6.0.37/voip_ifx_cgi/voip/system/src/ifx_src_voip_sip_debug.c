/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_debug.c
 *        Abstract: CGI API's to Access debug settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------


 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


//extern char_t g_cflag;
static char_t f_cflag;
static x_IFX_VMAPI_SystemDebugSettings xDbg;
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_debug
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/ 

void
ifx_set_voip_sip_debug (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pAppDT = ifx_httpdGetVar (wp, T ("AppDT"), T (""));
  char_t * pAppDL = ifx_httpdGetVar (wp, T ("AppDL"), T (""));
  char_t * pMmDT = ifx_httpdGetVar (wp, T ("MmDT"), T (""));
  char_t * pMmDL = ifx_httpdGetVar (wp, T ("MmDL"), T (""));
  char_t * pAgentDT = ifx_httpdGetVar (wp, T ("AgentDT"), T (""));
  char_t * pAgentDL = ifx_httpdGetVar (wp, T ("AgentDL"), T (""));
  char_t * pCmDT = ifx_httpdGetVar (wp, T ("CmDT"), T (""));
  char_t * pCmDL = ifx_httpdGetVar (wp, T ("CmDL"), T (""));
  char_t * pRtpDT = ifx_httpdGetVar (wp, T ("RtpDT"), T (""));
  char_t * pRtpDL = ifx_httpdGetVar (wp, T ("RtpDL"), T (""));
  char_t * pSipDT = ifx_httpdGetVar (wp, T ("SipDT"), T (""));
  char_t * pSipDL = ifx_httpdGetVar (wp, T ("SipDL"), T (""));
#ifndef IIP
  char_t * pFaxDT = ifx_httpdGetVar (wp, T ("FaxDT"), T (""));
  char_t * pFaxDL = ifx_httpdGetVar (wp, T ("FaxDL"), T (""));
#endif  

 memset(&xDbg,0,sizeof(xDbg));
 xDbg.iid.config_owner = IFX_WEB;
 if(ifx_get_DbgSettings(&xDbg,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Debug\n"));
    return ;
  }  

  xDbg.xCmDbg.ucDbgLvl = atoi (pAppDL);
  xDbg.xCmDbg.ucDbgType = atoi (pAppDT);
  xDbg.xMmDbg.ucDbgLvl = atoi (pMmDL);
  xDbg.xMmDbg.ucDbgType = atoi (pMmDT);
  xDbg.xAgentsDbg.ucDbgLvl = atoi (pAgentDL);
  xDbg.xAgentsDbg.ucDbgType = atoi (pAgentDT);
  xDbg.xVmapiDbg.ucDbgLvl = atoi (pCmDL);
  xDbg.xVmapiDbg.ucDbgType = atoi (pCmDT);
  xDbg.xRtpDbg.ucDbgLvl = atoi (pRtpDL);
  xDbg.xRtpDbg.ucDbgType = atoi (pRtpDT);
  xDbg.xSipDbg.ucDbgLvl = atoi (pSipDL);
  xDbg.xSipDbg.ucDbgType = atoi (pSipDT);

#ifndef IIP  
  xDbg.xFaxDbg.ucDbgLvl = atoi (pFaxDL);
  xDbg.xFaxDbg.ucDbgType = atoi (pFaxDT);
#endif  
  
  xDbg.iid.config_owner = IFX_WEB;
  //iRet = ifx_set_DbgSettings(IFX_OP_MOD,&xDbg,0);
  if(IFX_VMAPI_SUCCESS != ifx_set_DbgSettings(IFX_OP_MOD,&xDbg,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Debug\n"));
    return ;
  } 
	f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_debug
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_debug (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];
  int nSelIndex = 0, nIndex = 0;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }


  if(f_cflag == 0)
  {
    memset(&xDbg,0,sizeof(xDbg));
    xDbg.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_DbgSettings(&xDbg,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Debug Settings\n"));
      return -1;
    }  
    f_cflag = 1;
  }
	
  /*Call Manager  */
  if (!gstrcmp (name, T ("AppDT")))
  {
    nSelIndex = xDbg.xCmDbg.ucDbgType;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
      
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("AppDL")))
  {
    nSelIndex = xDbg.xCmDbg.ucDbgLvl;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
    }
		return 0;
  }
	/* Media Manager */
  if (!gstrcmp (name, T ("MmDT")))
  {
    nSelIndex = xDbg.xMmDbg.ucDbgType;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
      
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("MmDL")))
  {
    nSelIndex = xDbg.xMmDbg.ucDbgLvl;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
    }
		return 0;
  }
	/* Agents */
	if (!gstrcmp (name, T ("AgentDT")))
  {
    nSelIndex = xDbg.xAgentsDbg.ucDbgType;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
      
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("AgentDL")))
  {
    nSelIndex = xDbg.xAgentsDbg.ucDbgLvl;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
    }
		return 0;
  }
  if (!gstrcmp (name, T ("CmDT")))
  {
    nSelIndex = xDbg.xVmapiDbg.ucDbgType;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("CmDL")))
  {
    nSelIndex = xDbg.xVmapiDbg.ucDbgLvl;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
    }
		return 0;
  }
  if (!gstrcmp (name, T ("RtpDT")))
  {
    nSelIndex = xDbg.xRtpDbg.ucDbgType;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("RtpDL")))
  {
    nSelIndex = xDbg.xRtpDbg.ucDbgLvl;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
    }
		return 0;
  }
  if (!gstrcmp (name, T ("SipDT")))
  {
    nSelIndex = xDbg.xSipDbg.ucDbgType;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("SipDL")))
  {
    nSelIndex = xDbg.xSipDbg.ucDbgLvl;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("fax")))
  {  
#ifndef IIP          
     ifx_httpdWrite(wp,T("\
     <tr>\
     <td>FAX</td>\
     <td>\
     <select name=\"FaxDT\" size=\"1\">"));
     nSelIndex = xDbg.xFaxDbg.ucDbgType;
     for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugType) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
     {
       if (nIndex == nSelIndex)
         gstrcpy (sValue, "selected");
       else
         gstrcpy (sValue, "");
       ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_DebugType[nIndex].str);
     }
     ifx_httpdWrite(wp,T("\
     </select>\
     </td>\
     <td>\
     <select name=\"FaxDL\" size=\"1\">"));
     nSelIndex = xDbg.xFaxDbg.ucDbgLvl;
     for (nIndex = 0;
           nIndex < sizeof (web_Enum_DebugLvl) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
     {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_Enum_DebugLvl[nIndex].str);
     }
     ifx_httpdWrite(wp,T("\
     </select>\
     </td>\
     </tr>"));
#endif
   f_cflag = 0;
  }
  return 0;
}


