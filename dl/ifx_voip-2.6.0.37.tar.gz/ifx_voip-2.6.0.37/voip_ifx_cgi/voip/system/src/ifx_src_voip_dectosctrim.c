/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_debug.c
 *        Abstract: CGI API's to Access debug settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------


 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
static char_t f_cflag;
static x_IFX_VMAPI_DectOscTrimVal  xOsctrim;
extern int g_DIAGMODE;

/*****************************************************************************
 *  Function Name   : ifx_set_voip_osctrim
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/ 
void
ifx_set_voip_osctrim(httpd_t wp, char_t * path, char_t * query) 
{
  uchar8 ucStatus;
  char_t * pOsctrimhi = ifx_httpdGetVar (wp, T ("Osctrimhigh"), T (""));
  char_t * pOsctrimlo = ifx_httpdGetVar (wp, T ("Osctrimlow"), T (""));
//  char_t * pP10stat = ifx_httpdGetVar (wp, T ("P10Status"), T (""));
  char_t * pbuttonobj = ifx_httpdGetVar (wp, T ("osctrim"), T (""));
	extern void ifx_set_voip_gfsk(httpd_t wp, char_t * path, char_t * query);

 int32 iRet = IFX_VMAPI_SUCCESS;
 uchar8 ucChanged = 1;

 memset(&xOsctrim,0,sizeof(xOsctrim));
 xOsctrim.iid.config_owner = IFX_WEB;
 if(ifx_get_Osctrim(&xOsctrim,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Debug\n"));
    return ;
  }  

  
 ucStatus=atoi(pbuttonobj);
 IFX_CGI_DEBUG(" Get/Set button Pressed: ucStatus=%d\n", ucStatus);
if(ucStatus != 1 && (xOsctrim.ucDectOscTrimValHI == hd((uchar8 *)pOsctrimhi) ) && (xOsctrim.ucDectOscTrimValLOW == hd((uchar8 *)pOsctrimlo)))
	ucChanged = 0;

  xOsctrim.ucDectOscTrimValHI = hd((uchar8 *)pOsctrimhi);
  xOsctrim.ucDectOscTrimValLOW = hd((uchar8 *)pOsctrimlo);
//  xOsctrim.ucDectP10Status = hd(pP10stat);
  
  IFX_CGI_DEBUG("\nOSC TRIM High  %d",xOsctrim.ucDectOscTrimValHI);
  IFX_CGI_DEBUG("\nOSC TRIM Low  %d",xOsctrim.ucDectOscTrimValLOW);
  IFX_CGI_DEBUG("\nP10 Status  %d",xOsctrim.ucDectP10Status);

  xOsctrim.iid.config_owner = IFX_WEB;

  if(ucStatus == 1 /*&& g_DIAGMODE == 1*/) {
#if defined(CVOIP_SUPPORT)
	iRet = LTQ_CVoIP_ParamRequest(IFX_VMAPI_OSC_TRIM_REQUEST);
#elif defined(DECT_SUPPORT)
	iRet = ifx_set_OsctrimToModem(1,NULL);
#endif
  	IFX_CGI_DEBUG("\n<ifx_set_voip_osctrim>UCSTATUS=1\n");
  }
  else if(ucChanged && ucStatus == 2 /* && g_DIAGMODE == 1*/) {
#if defined(DECT_SUPPORT)
	  iRet = ifx_set_OsctrimToModem(2,&xOsctrim);
#endif
    iRet = ifx_set_Osctrim(IFX_OP_MOD,&xOsctrim,0);
  	IFX_CGI_DEBUG("\n<ifx_set_voip_osctrim>UCSTATUS=2\n");
  }
  else if(ucChanged && ucStatus == 0) {
    iRet = ifx_set_Osctrim(IFX_OP_MOD,&xOsctrim,0);
  	IFX_CGI_DEBUG("\n<ifx_set_voip_osctrim>UCSTATUS=0\n");
  }
  
	if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Debug\n"));
    return ;
  }  

#ifdef DECT_SUPPORT
	ifx_set_voip_gfsk(wp, path, query);
#endif
  f_cflag=0;
	ifx_httpdNextPage_New(wp);
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_osctrim
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_osctrim(int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t byte_value[3] = {'\0'};

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }


  if(f_cflag == 0)
  {
    memset(&xOsctrim,0,sizeof(xOsctrim));
    xOsctrim.iid.config_owner = IFX_WEB;
    if(ifx_get_Osctrim(&xOsctrim,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Debug Settings\n"));
      return -1;
    }  
    f_cflag = 1;
  }
	
  if (!gstrcmp (name, T ("Osctrimhigh")))
  {
      dh(xOsctrim.ucDectOscTrimValHI,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Osctrimlow")))
  {
      dh(xOsctrim.ucDectOscTrimValLOW,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("P10Status")))
  {
      dh(xOsctrim.ucDectP10Status,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
    f_cflag = 0;
  }
  return 0;		  
		  
}
#endif		  
