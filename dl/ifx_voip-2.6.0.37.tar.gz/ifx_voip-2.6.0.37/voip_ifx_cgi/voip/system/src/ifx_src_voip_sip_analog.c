/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_analog.c
 *        Abstract: CGI API's to Access Analog Phone Settings
 *        Date    : 17-04-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 



************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

extern int g_FXS;
static x_IFX_VMAPI_FxsPhyIf xFXS;
static x_IFX_VMAPI_FxoPhyIf xFxoIf;
static char8 f_cflag = 0;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_analog
 *  Description     : This function is called analog_advanced page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
int32
ifx_get_voip_sip_analog (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  int32 j=0,m=0;
  int32 nIndex = 0;
  char_t sValue[MAX_DATA_LEN];
	x_IFX_VMAPI_VoiceLine xVoiceLine1;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return IFX_VMAPI_FAIL;
  }

	if(g_FXS < 1)
	{
		g_FXS = 1;
	}
  if (!gstrcmp (name, T ("fxs"))) /*For creating the buttons in the header*/
  {
    int32 i;
  	memset(&xFxoIf, 0, sizeof(xFxoIf));
  	xFxoIf.xVoiceServPhyIf.ucInterfaceId = 3;
  	xFxoIf.iid.config_owner = IFX_WEB;
  	if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFxoIf, 0))
  	{
    	ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
    	return IFX_VMAPI_FAIL;
  	}
    for(i=1;i<=IFX_VMAPI_MAX_FXS_ENDPTS;i++)
    { 
	  	xFXS.xVoiceServPhyIf.ucInterfaceId = i;
  		xFXS.iid.config_owner = IFX_WEB;
			if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFXS,0))
  		{
    		ifx_httpdError (wp, 200, T ("Fail to GET FXS\n"));
    		return IFX_VMAPI_FAIL;
  		}
		 	// Number of the Phone+Phone
      if(xFXS.ucVoiceLineId ==0){
			ifx_httpdWrite(wp, T("<tr><td>%d</td><td>%s</td><td>Phone</td><td>None</td><td>N/A</td><td><input type=\"radio\" value=\"%d\" name=\"int_select\" onclick=\"selected=%d\" /></td></tr>"), i+6,xFXS.ucEndPtId,i+6,i+6);
      }else if(xFXS.ucVoiceLineId !=4) {
      	memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
        xVoiceLine1.ucLineId = xFXS.ucVoiceLineId;
        xVoiceLine1.iid.config_owner = IFX_WEB;
        if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0)){
          ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
          return IFX_VMAPI_FAIL;
        }
			ifx_httpdWrite(wp, T("<tr><td>%d</td><td>%s</td><td>Phone</td><td>%s</td><td>N/A</td><td><input type=\"radio\" value=\"%d\" name=\"int_select\" onclick=\"selected=%d\" /></td></tr>"), i+6,xFXS.ucEndPtId,xVoiceLine1.acName,i+6,i+6);
      }else{
			ifx_httpdWrite(wp, T("<tr><td>%d</td><td>%s</td><td>Phone</td><td>%s</td><td>N/A</td><td><input type=\"radio\" value=\"%d\" name=\"int_select\" onclick=\"selected=%d\" /></td></tr>"), i+6,xFXS.ucEndPtId,xFxoIf.acName,i+6,i+6);
       }
    }
  }
else if(f_cflag == 0){
  memset(&xFXS,0,sizeof(xFXS));
  xFXS.xVoiceServPhyIf.ucInterfaceId = g_FXS;
  xFXS.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFXS,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to GET FXS\n"));
    return IFX_VMAPI_FAIL;
  }  
  
  memset(&xFxoIf, 0, sizeof(xFxoIf));
  xFxoIf.xVoiceServPhyIf.ucInterfaceId = 3;
  xFxoIf.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFxoIf, 0))
  {
    ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
    return IFX_VMAPI_FAIL;
  }
f_cflag = 1;
}
 if (!gstrcmp (name, T ("numlines")))
  {
    while(xFXS.ucVoiceLineIdList[m] != 0)
    {
      m++;
    }
  ifx_httpdWrite(wp,T("%d"),m);
  }

  else if (!gstrcmp (name, T ("interfaceid")))
  {
		ifx_httpdWrite(wp, T("%d"), xFXS.xVoiceServPhyIf.ucInterfaceId);
  }
  else  if (!gstrcmp (name, T ("sms")))
  {
		if(xFXS.bSmsCapable == 1)	
		ifx_httpdWrite(wp, T("checked"));
  }
  else  if (!gstrcmp (name, T ("wideband")))
  {
	  if(xFXS.bWideBandCapable == 1)
		ifx_httpdWrite(wp, T("checked"));
  }
  else  if (!gstrcmp (name, T ("status")))
  {
		ifx_httpdWrite(wp, T("%d"), xFXS.xVoiceServPhyIf.ucStatus);
  }
  else  if (!gstrcmp (name, T ("voip_line")))
  {
		ifx_httpdWrite(wp, T("%d"), xFXS.ucVoiceLineId);
  }
  else  if (!gstrcmp (name, T ("number")))
  {
		ifx_httpdWrite(wp, T("%s"), xFXS.ucEndPtId);
  }

  else if (!gstrcmp (name, T ("defaultline")))
  {
    while(xFXS.ucVoiceLineIdList[j] != 0)
    {
      if (xFXS.ucVoiceLineIdList[j] == xFXS.ucVoiceLineId)
	      gstrcpy(sValue,"selected");
      else
	      gstrcpy(sValue,"");

      if ( xFXS.ucVoiceLineIdList[j] == 4 )
      {
        ifx_httpdWrite (wp, T("<option value= \"%d\" %s> %s </option>"),
                     xFXS.ucVoiceLineIdList[j],sValue,xFxoIf.acName);
      }
      else
      {
        memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
        xVoiceLine1.ucLineId = xFXS.ucVoiceLineIdList[j];
        xVoiceLine1.iid.config_owner = IFX_WEB;
        if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0)){
          ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
          return IFX_VMAPI_FAIL;
        }
        ifx_httpdWrite (wp, T("<option value= \"%d\" %s> %s </option>"),
                     xFXS.ucVoiceLineIdList[j],sValue,xVoiceLine1.acName);            
      } 
	    j++;
    }
	}
  else if (!gstrcmp (name, T ("echoCancel")))
  {
      uint32 ucValue = xFXS.bEnableEchoCancel;
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
     }
	f_cflag = 0;  
 }

   return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_analog
 *  Description     : This function is called analog_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_analog (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pNumber = ifx_httpdGetVar (wp, T ("number"), T (""));
  //char_t * pSmsCapable= ifx_httpdGetVar (wp, T ("sms"), T (""));
  //char_t * pWideBandCapable = ifx_httpdGetVar (wp, T ("wideband"), T (""));
  char_t * pVoipLine = ifx_httpdGetVar (wp, T ("voip_line"), T (""));
  char_t * pEchoCan = ifx_httpdGetVar (wp, T ("echoCancel"), T (""));

  //int32 n=0,l=0;
  x_IFX_VMAPI_FxsPhyIf xFXS;
  //uchar8 UArray[10]={0}; 
	char8 aucEndPt[12] = {0};
	
	int32 nIndex=0;
	int32 iRet= IFX_VMAPI_SUCCESS;
	
	x_IFX_VMAPI_VoiceServPhyIf xVoiceIf;
	x_IFX_VMAPI_FxsPhyIf xFxsIf;
	//x_IFX_VMAPI_FxsPhyIf xFxoIf;
	x_IFX_VMAPI_FxoPhyIf xFxoIf;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)	
  x_IFX_VMAPI_DectHandset xDectIf;
#endif	
	if(g_FXS < 1)
	{
		g_FXS = 1;
	}

  memset(&xFXS,0,sizeof(xFXS));
  xFXS.xVoiceServPhyIf.ucInterfaceId = g_FXS;
  xFXS.iid.config_owner = IFX_WEB;

	if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFXS,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to GET FXS\n"));
    return ;
  }  

	strcpy(aucEndPt,pNumber);
	
  //xFXS.bSmsCapable = atoi(pSmsCapable);
  xFXS.bSmsCapable = 0; 
  //xFXS.bWideBandCapable = atoi(pWideBandCapable);
  xFXS.bWideBandCapable = 0; 
  xFXS.bEnableEchoCancel = atoi (pEchoCan);
  xFXS.ucVoiceLineId = atoi (pVoipLine);
	if(strcmp((char8 *)xFXS.ucEndPtId ,pNumber) != 0)
	{
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)	
    while(nIndex != (IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS + IFX_VMAPI_MAX_DECT_ENDPTS))  
#else
    while(nIndex != (IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS))  
#endif
    {
		  memset(&xVoiceIf, 0, sizeof(xVoiceIf));
		  xVoiceIf.ucInterfaceId = nIndex+1; 
		  if(IFX_VMAPI_SUCCESS != ifx_get_VoicePhyInterface(&xVoiceIf , 0))
		  {
        ifx_httpdError (wp, 200, T ("ifx_get_VoicePhyInterface failed\n"));
        return ;
		  }
		
	    if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_FXS)
		  {
		    memset(&xFxsIf, 0, sizeof(xFxsIf));
			  xFxsIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
        if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFxsIf , IFX_F_DEFAULT))
		    {
          ifx_httpdError (wp, 200, T ("ifx_get_FxsPhyInterface failed\n"));
          return ;
		    }
			  if(strcmp((char8 *)xFxsIf.ucEndPtId , aucEndPt) == 0)
			  {
          ifx_httpdError (wp, 200, T ("EndPtId Exists for FXS\n"));
          return ;
				
			  }
			  else
			  {
          strcpy((char8 *)xFXS.ucEndPtId ,pNumber);
			  }
		  }

		  if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_FXO)
		  {
		    memset(&xFxoIf, 0, sizeof(xFxoIf));
			  xFxoIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
        iRet = ifx_get_FxoPhyInterface(&xFxoIf, 0);
        if(iRet != IFX_VMAPI_SUCCESS)
		    {
          ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
          return ;
		    }
			  if(strcmp((char8 *)xFxoIf.ucEndPtId , aucEndPt) == 0)
			  {
          ifx_httpdError (wp, 200, T ("EndPtId Exists for FXO\n"));
          return ;
				
			  }
			  else
			  {
          strcpy((char8 *)xFXS.ucEndPtId ,pNumber);
			  }
		  }	
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
			if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_DECT)
		  {
		    memset(&xDectIf, 0, sizeof(xDectIf));
			  xDectIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
        iRet = ifx_get_DectHandset(&xDectIf , 0);
        if(iRet != IFX_VMAPI_SUCCESS)
		    {
          ifx_httpdError (wp, 200, T ("ifx_get_DectHandset failed\n"));
          return ;
		    }
			  if(strcmp((char8 *)xDectIf.ucEndPtId , aucEndPt) == 0)
			  {
          ifx_httpdError (wp, 200, T ("EndPtId Exists for DECT\n"));
          return ;
				
			  }
			  else
			  {
          strcpy((char8 *)xFXS.ucEndPtId ,pNumber);
			  }
		  }	
#endif
 	    nIndex++; 
    }
	}
 
  xFXS.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to SET FXS\n"));
    return ;
  }  
f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_fxsno
 *  Description     : This function is called header_analog.htm page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Sets the g_FXS global variable and redirects to Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_fxsno (httpd_t wp, char_t * path, char_t * query) 

{
  
  char_t * pFxsId = ifx_httpdGetVar (wp, T ("FxsId"), T (""));

  g_FXS = atoi(pFxsId);
	IFX_DBG("Switching to : Analog %d",g_FXS);
f_cflag = 0;
  ifx_httpdNextPage (wp);
}
