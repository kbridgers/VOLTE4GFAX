/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_t38.c
 *        Abstract: CGI API's to Access t38 Cfg
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"
extern int g_PROFILE_ID_IS;

static char_t f_cflag;
static x_IFX_VMAPI_T38Cfg xT38Conf;
void ifx_enable_dna_configuration();
void ifx_disable_dna_configuration();

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_t38
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_t38 (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  
  char_t * name, *mode1, *mode2, *mode3, *mode4;
  if (ifx_httpd_parse_args
        (argc, argv, T ("%s%s%s%s%s"), &name, &mode1, &mode2, &mode3,
         &mode4) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
if(f_cflag == 0){ 
  xT38Conf.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_SystemT38(&xT38Conf,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to GET T38\n"));
    return -1;
  }  
	f_cflag=1;
}

  if (!gstrcmp (name, T ("oldAsn")))
  {
      ifx_httpdWrite (wp, T ("%d"), xT38Conf.ucOldAsn1);
	}
  else if (!gstrcmp (name, T ("nsx")))
  {
      ifx_httpdWrite (wp, T ("%d"), xT38Conf.ucNsxSize);
  }
  else if (!gstrcmp (name, T ("nsxinfo")))
  {
     ifx_httpdWrite (wp, T ("%s"), xT38Conf.ucNsxInfoField);
  }
  else if (!gstrcmp (name, T ("wtime")))
  {
    ifx_httpdWrite (wp, T ("%d"), xT38Conf.ucDataWaitTime);
  }
  else if (!gstrcmp (name, T ("hrPkt")))
  {
    ifx_httpdWrite (wp, T ("%d"), xT38Conf.unUdpHRErrRecPkts);
  }
  else if (!gstrcmp (name, T ("lrPkt")))
  {
     ifx_httpdWrite (wp, T ("%d"), xT38Conf.unUdpLRErrRecPkts);
  }
  else if (!gstrcmp (name, T ("priPkt")))
  {
     ifx_httpdWrite (wp, T ("%d"), xT38Conf.unUdpPriorFecPkts);
  }
  else if (!gstrcmp (name, T ("perCon")))
  {
    if (xT38Conf.ucT38Conn == IFX_VMAPI_FAX_CONN_UDP
       && !strcmp (mode1, "1"))
        ifx_httpdWrite (wp, T ("checked")); 
    else if (xT38Conf.ucT38Conn == IFX_VMAPI_FAX_CONN_TCP
            && !strcmp (mode1, "2"))
        ifx_httpdWrite (wp, T ("checked"));  
	  else if (xT38Conf.ucT38Conn == IFX_VMAPI_FAX_CONN_UDP_TCP
               && !strcmp (mode1, "3"))
        ifx_httpdWrite (wp, T ("checked"));	  
	  else if (xT38Conf.ucT38Conn == IFX_VMAPI_FAX_CONN_TCP_UDP
               && !strcmp (mode1, "4"))
       ifx_httpdWrite (wp, T ("checked"));
  		f_cflag=0;
  }
 
return 0;   
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_t38
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the Next Page
 ****************************************************************************/ 

void
ifx_set_voip_sip_t38 (httpd_t wp, char_t * path, char_t * query) 
{
#ifndef IIP
  char_t * poldAsn = ifx_httpdGetVar (wp, T ("oldAsn"), T (""));
  char_t * pnsx = ifx_httpdGetVar (wp, T ("nsx"), T (""));
  char_t * pwtime = ifx_httpdGetVar (wp, T ("wtime"), T (""));
  char_t * phrPkt = ifx_httpdGetVar (wp, T ("hrPkt"), T (""));
  char_t * plrPkt = ifx_httpdGetVar (wp, T ("lrPkt"), T (""));
  char_t * ppriPkt = ifx_httpdGetVar (wp, T ("priPkt"), T (""));
  char_t * pperCon = ifx_httpdGetVar (wp, T ("perCon"), T (""));
  char_t * pnsxinfo = ifx_httpdGetVar (wp, T ("nsxinfo"), T (""));

	x_IFX_VMAPI_Misc xMisc;


  xT38Conf.iid.config_owner = IFX_WEB;
  if(ifx_get_SystemT38(&xT38Conf,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET T38\n"));
    return ;
  }  

  xT38Conf.ucOldAsn1 = atoi (poldAsn);
  xT38Conf.ucNsxSize = atoi (pnsx);
  gstrcpy ((char8 *)xT38Conf.ucNsxInfoField, pnsxinfo);
  xT38Conf.ucDataWaitTime = atoi (pwtime);
  xT38Conf.unUdpHRErrRecPkts = atoi (phrPkt);
  xT38Conf.unUdpLRErrRecPkts = atoi (plrPkt);
  xT38Conf.unUdpPriorFecPkts = atoi (ppriPkt);
 
  if (!gstrcmp (pperCon, "1"))
  {
    xT38Conf.ucT38Conn = IFX_VMAPI_FAX_CONN_UDP;
  }
  else if (!gstrcmp (pperCon, "2"))
  {
    xT38Conf.ucT38Conn = IFX_VMAPI_FAX_CONN_TCP;
  }
  else if (!gstrcmp (pperCon, "3"))
  {
    xT38Conf.ucT38Conn = IFX_VMAPI_FAX_CONN_UDP_TCP;
  }
  else
  {
    xT38Conf.ucT38Conn = IFX_VMAPI_FAX_CONN_TCP_UDP;
  }

  if(IFX_VMAPI_SUCCESS != ifx_set_SystemT38(IFX_OP_MOD,&xT38Conf,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to SET T38\n"));
    return ;
  }  

	  /* For the Fax Port Selection */
 	char_t * pFaxPort = ifx_httpdGetVar (wp, T ("port"), T (""));
	IFX_DBG("pFaxPort : %s",pFaxPort);

  memset(&xMisc,0,sizeof(x_IFX_VMAPI_Misc));
  xMisc.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_Misc(&xMisc,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Misc\n"));
    return ;
  }

  xMisc.defaultFaxIface = atoi (pFaxPort);
  xMisc.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_Misc(IFX_OP_MOD,&xMisc,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Misc\n"));
    return ;
  }
#endif
	f_cflag=0;
  ifx_httpdNextPage_New(wp);
}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_misc
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/

int
ifx_get_voip_sip_misc (int eid, httpd_t wp, int argc, char_t ** argv)
{
  char_t * name, *mode;
  int32 nIndex=0;
  char_t sValue[MAX_DATA_LEN];
	x_IFX_VMAPI_Misc xMisc;
  
	if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
    memset(&xMisc,0,sizeof(xMisc));
    xMisc.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_Misc(&xMisc,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Misc\n"));
      return -1;
    }
	if (!gstrcmp (name, T ("port")))
  {
      uint32 ucValue = xMisc.defaultFaxIface - 1;
      for (nIndex = 0; nIndex < sizeof (web_Enum_FaxPort) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_FaxPort[nIndex].value, sValue,
                        web_Enum_FaxPort[nIndex].str);
      }
		return 0;
  }else 	if (!gstrcmp (name, T ("unotify")))
  {
			if(xMisc.bAcceptUnSolNotify == 1)
    {
      ifx_httpdWrite(wp, T("checked"));
    }

	}else   if (!gstrcmp (name, T ("dtonedur")))
  {
     ifx_httpdWrite (wp, T ("%d"), xMisc.ucDialToneDuration);
	}else   if (!gstrcmp (name, T ("sessexpires")))
  {
     ifx_httpdWrite (wp, T ("%d"), xMisc.uiSessExpires);
	}else   if (!gstrcmp (name, T ("supression")))
  {
     if ( xMisc.bSilenceSupp == 1)
			{
      	ifx_httpdWrite(wp, T("checked"));
    	}
	}else if(!gstrcmp (name, T ("FxoEn"))){
		if(xMisc.ucFxoEnable){
			ifx_httpdWrite(wp, T("checked"));
		}
	}
return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_misc
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/

void
ifx_set_voip_sip_misc (httpd_t wp, char_t * path, char_t * query)
{
  char_t * pUnotify = ifx_httpdGetVar (wp, T ("unotify"), T (""));
  char_t * pSupression = ifx_httpdGetVar (wp, T ("supression"), T (""));
  char_t * pJBuffer = ifx_httpdGetVar (wp, T ("jbuffer"), T (""));
  char_t * pSfactor = ifx_httpdGetVar (wp, T ("sfactor"), T (""));
  char_t * pInitsize = ifx_httpdGetVar (wp, T ("initsize"), T (""));
  char_t * pMaxsize = ifx_httpdGetVar (wp, T ("maxsize"), T (""));
  char_t * pMinsize = ifx_httpdGetVar (wp, T ("minsize"), T (""));
  char_t * pDtonedur = ifx_httpdGetVar (wp, T ("dtonedur"), T (""));
  char_t * pSessExpires = ifx_httpdGetVar (wp, T ("sessexpires"), T (""));
  char_t * pDiallen = ifx_httpdGetVar (wp, T ("diallen"), T (""));
  char_t * pFxoen = ifx_httpdGetVar (wp, T ("FxoEn"), T (""));
	x_IFX_VMAPI_Misc xMisc;
	x_IFX_VMAPI_ProfileMediaRTP xProfMed;
	x_IFX_VMAPI_NumPlan xNumberingPlan;
	#ifdef DECT_SUPPORT
	x_IFX_VMAPI_DectSystem xDectSys;
  char_t * pClkMaster = ifx_httpdGetVar (wp, T ("clkmaster"), T (""));
  char_t * pDna = ifx_httpdGetVar (wp, T ("dna"), T (""));
	#endif
	f_cflag=0;
	  memset(&xMisc,0,sizeof(xMisc));
    xMisc.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_Misc(&xMisc,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Misc\n"));
      return ;
    }
	
		memset(&xProfMed,0,sizeof(xProfMed));
    xProfMed.ucProfileId = g_PROFILE_ID_IS;
    xProfMed.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_ProfileMediaRTP(&xProfMed,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET RTP\n"));
      return ;
    }

	#ifdef DECT_SUPPORT
	//Get dect system struct
     memset(&xDectSys,0,sizeof(xDectSys));
    xDectSys.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xDectSys,0))
    {
      ifx_httpdError (wp, 200, T ("Could not GET Dect\n"));
      return ;
    }
	#endif
	
	if(xMisc.bAcceptUnSolNotify != atoi(pUnotify) 
			|| xMisc.ucDialToneDuration != atoi(pDtonedur) 
			|| xMisc.uiSessExpires != atoi(pSessExpires) 
			|| xMisc.bSilenceSupp != atoi(pSupression)
			|| xMisc.ucFxoEnable != atoi(pFxoen)){
    xMisc.bAcceptUnSolNotify = atoi(pUnotify);
		xMisc.ucDialToneDuration = atoi(pDtonedur);
		xMisc.uiSessExpires = atoi(pSessExpires);
		xMisc.bSilenceSupp = atoi(pSupression);
    xMisc.ucFxoEnable = atoi(pFxoen);
  	if(IFX_VMAPI_SUCCESS != ifx_set_Misc(IFX_OP_MOD,&xMisc,0))
  	{
    	ifx_httpdError (wp, 200, T ("Fail to SET Misc\n"));
    	return ;
  	}
  }
	if(xProfMed.ucJbType != atoi(pJBuffer) || xProfMed.ucScalingFactor != atoi(pSfactor) || xProfMed.unInitialSize != atoi(pInitsize) || xProfMed.unMaxSize != atoi(pMaxsize) || xProfMed.unMinSize != atoi(pMinsize)  ){
		xProfMed.ucJbType=atoi(pJBuffer);
		xProfMed.unInitialSize=atoi(pInitsize);
		xProfMed.unMaxSize=atoi(pMaxsize);
		xProfMed.ucScalingFactor=atoi(pSfactor);
		xProfMed.unMinSize = atoi(pMinsize);
		if(ifx_set_ProfileMediaRTP(IFX_OP_MOD,&xProfMed,0) != IFX_VMAPI_SUCCESS)
  	{
    		ifx_httpdError (wp, 200, T ("Fail to SET RTP Jitter Buffer\n"));
    		return ;
  	}		
	}
	memset(&xNumberingPlan,0,sizeof(xNumberingPlan));
  xNumberingPlan.iid.config_owner = IFX_WEB;
  if (IFX_VMAPI_SUCCESS != ifx_get_NumPlan(&xNumberingPlan,0))
  {
      ifx_httpdError (wp, 200, T ("Fail to get NumPlan\n"));
      return;
  }
	if(xNumberingPlan.ucNumPlanMaxDigits != atoi(pDiallen)){
			xNumberingPlan.ucNumPlanMaxDigits = atoi(pDiallen);
			if(IFX_VMAPI_SUCCESS != ifx_set_NumPlan(IFX_OP_MOD,&xNumberingPlan,0)){
      	ifx_httpdError (wp, 200, T ("SET is failing Numbering Max Dial Digits  !!\n"));
			  ifx_vmapi_freeObjectList(&xNumberingPlan,IFX_VMAPI_VS_NUM_PLAN);
      return ;
    }
	}
	ifx_vmapi_freeObjectList(&xNumberingPlan,IFX_VMAPI_VS_NUM_PLAN);
	#ifdef DECT_SUPPORT
	if(xDectSys.ucClkMaster != atoi(pClkMaster) || xDectSys.ucDnaEnable != atoi(pDna)){
			xDectSys.ucClkMaster = atoi(pClkMaster);
			if(xDectSys.ucDnaEnable != atoi(pDna) ){
				xDectSys.ucDnaEnable = atoi(pDna);
				if(xDectSys.ucDnaEnable){
						ifx_enable_dna_configuration(wp);
    		}else {
						ifx_disable_dna_configuration(wp);
				}
			}
			if(IFX_VMAPI_SUCCESS != ifx_set_DectInterface(IFX_OP_MOD,&xDectSys,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      ifx_httpdError (wp, 200, T ("SET is failing for Dect System !!\n"));
      return ;
    }
	}
	#endif

ifx_httpdNextPage_New(wp);
}


void ifx_disable_dna_configuration(httpd_t wp){
x_IFX_VMAPI_NumPlanRule xRule;
int32 iRet;
//update the numbering plan's
memset(&xRule,0,sizeof(xRule));
    xRule.ucIndex = 2;
    xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_get_NumPlanRule(&xRule,0);
	if(iRet == IFX_VMAPI_SUCCESS){
		//xRule.ucNoOfDigits2bRem = 2; 
    xRule.ucPosDigits2bRem = 1; 
		gstrcpy (xRule.acPrefix, "0");
		xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xRule,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
	}
//update the numbering plan's
memset(&xRule,0,sizeof(xRule));
    xRule.ucIndex = 14;
    xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_get_NumPlanRule(&xRule,0);
	if(iRet == IFX_VMAPI_SUCCESS){
		//xRule.ucNoOfDigits2bRem = 2; 
    xRule.ucPosDigits2bRem = 1; 
		gstrcpy (xRule.acPrefix, "0[0-9]");
		xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xRule,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
	}


}
void ifx_enable_dna_configuration(httpd_t wp){
//change the interface association for line-1
x_IFX_VMAPI_VoiceLine xVoiceLine;
x_IFX_VMAPI_FxsPhyIf xFXS;
x_IFX_VMAPI_NumPlanRule xRule;
int32 iRet ;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
  x_IFX_VMAPI_DectHandset xDectHand;
#endif
int32 x=0,p=0,nIndex;
 memset(&xVoiceLine,0,sizeof(xVoiceLine));
 xVoiceLine.ucLineId = 1;
 xVoiceLine.iid.config_owner=IFX_WEB;
 if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0))
  {
			    ifx_httpdError (wp, 200, "Fail to GET the VoiceLine !!!");
			    return;
  }
	/*Assigning the associated Endpoints to the AssocVoiceInterface of Line */
	  memset (&(xVoiceLine.ucAssocVoiceInterface), 0,
     		            sizeof (xVoiceLine.ucAssocVoiceInterface));
	//Handset 1 association
		xVoiceLine.ucAssocVoiceInterface[0]=4;
			
	//Remove association of FXS Physical interfaces for Line-1
	for(nIndex = 1 ; nIndex <	 3 ; nIndex++){
					memset(&xFXS,0,sizeof(xFXS));
      		xFXS.xVoiceServPhyIf.ucInterfaceId = nIndex;
    		  if (ifx_get_FxsPhyInterface(&xFXS,0) != IFX_VMAPI_SUCCESS)
      		{
				        ifx_httpdError (wp, 200, "Fail to GET the FXS !!");
        				return;
		      }

				x=0;

      /* If the default VoiceLineId is same as the Line-1 then delete that 
         and set it to the next available VoiceLine else set it to 0 */
      if(xFXS.ucVoiceLineId == 1)
      {
        while(xFXS.ucVoiceLineIdList[x] != 0)
        {
          if(xFXS.ucVoiceLineIdList[x] != 1)
          {
            xFXS.ucVoiceLineId = xFXS.ucVoiceLineIdList[x];
            break;
          }
          else
          {
            xFXS.ucVoiceLineId = 0;
          }
          x++;
        }
      }
			x=0;
			p=0;
      /* Remove the Line from the VoiceLineId List of that FXS endpoint*/
      while (xFXS.ucVoiceLineIdList[p] != 0)
      {
        /* Check if the corresponding line is already there */
        if (xFXS.ucVoiceLineIdList[p] == 1)
        {
          x=p;
          while(xFXS.ucVoiceLineIdList[x] != 0)
          {
            xFXS.ucVoiceLineIdList[x] = xFXS.ucVoiceLineIdList[x+1];
            x++;
          }
        }
        p++;
      }

      /* SET the object */
      if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,
                              IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
      {
        ifx_httpdError (wp, 200, T ("Fail to SET FXS !!\n"));
        return ;
      }


	}
	//Dect end points association.....
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
		for(nIndex = 5 ; nIndex <	 10 ; nIndex++){
      /* For DECT Handset */
      memset(&xDectHand,0,sizeof(xDectHand));
      xDectHand.xVoiceServPhyIf.ucInterfaceId = nIndex;
      if (ifx_get_DectHandset(&xDectHand,0) != IFX_VMAPI_SUCCESS)
      {
        ifx_httpdError (wp, 200, "Fail to GET the Dect Handset !!");
        return;
      }

      /* If the default VoiceLineId is same as the Line then delete that 
         and set it to the next available VoiceLine else 0 */
      x=0;
      if(xDectHand.ucVoiceLineId == 1)
      {
        while(xDectHand.aucVoiceLineIdList[x] != 0)
        {
          if(xDectHand.aucVoiceLineIdList[x] != 1)
          {
            xDectHand.ucVoiceLineId = xDectHand.aucVoiceLineIdList[x];
            break;
          }
          else
          {
            xDectHand.ucVoiceLineId = 0;
          }
          x++;
        }
      }
		 x=0;
     p=0;
      /* Remove the LineId from the VoiceLineId List */
      while (xDectHand.aucVoiceLineIdList[p] != 0)
      {
        /* Check if the corresponding line is already there */
        if (xDectHand.aucVoiceLineIdList[p] == 1)
        {
          x=p;
          while(xDectHand.aucVoiceLineIdList[x] != 0)
          {
            xDectHand.aucVoiceLineIdList[x] = xDectHand.aucVoiceLineIdList[x+1];
            x++;
          }
        }
        p++;
      }

      /* SET the object */
      if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,
                              IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
      {
        ifx_httpdError (wp, 200, T ("Fail to SET Dect Handset !!\n"));
        return ;
      }
	}
#endif
//Set the voice Line object....
  if (ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, "Fail to SET the VoiceLine !!!");
    return;
  }
//update the numbering plan's
memset(&xRule,0,sizeof(xRule));
    xRule.ucIndex = 2;
    xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_get_NumPlanRule(&xRule,0);
	if(iRet == IFX_VMAPI_SUCCESS){
		//xRule.ucNoOfDigits2bRem = 2; 
    xRule.ucPosDigits2bRem = 2; 
		gstrcpy (xRule.acPrefix, "#4");
		xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xRule,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
	}
//update the numbering plan's
memset(&xRule,0,sizeof(xRule));
    xRule.ucIndex = 14;
    xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_get_NumPlanRule(&xRule,0);
	if(iRet == IFX_VMAPI_SUCCESS){
		//xRule.ucNoOfDigits2bRem = 2; 
    xRule.ucPosDigits2bRem = 2; 
		gstrcpy (xRule.acPrefix, "#5[0-9]");
		xRule.iid.config_owner = IFX_WEB;
    iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xRule,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
	}

}
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_misc_new
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/

int
ifx_get_voip_sip_misc_new (int eid, httpd_t wp, int argc, char_t ** argv)
{
  char_t * name, *mode;
  int32 nIndex=0;
  char_t sValue[MAX_DATA_LEN];
	static	x_IFX_VMAPI_ProfileMediaRTP xProfMed;
	x_IFX_VMAPI_NumPlan xNumberingPlan;
	#ifdef DECT_SUPPORT
	static	x_IFX_VMAPI_DectSystem xDectSys;
	#endif
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
	if(f_cflag == 0){
		memset(&xProfMed,0,sizeof(xProfMed));
    xProfMed.ucProfileId = g_PROFILE_ID_IS;
    xProfMed.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_ProfileMediaRTP(&xProfMed,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET RTP\n"));
      return -1;
    }
	 	//Get dect system struct
		#ifdef DECT_SUPPORT
		 memset(&xDectSys,0,sizeof(xDectSys));
 	 	xDectSys.iid.config_owner = IFX_WEB;
  	if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xDectSys,0))
  	{	
    	ifx_httpdError (wp, 200, T ("Could not GET Dect\n"));
    	return -1;
  	}
	#endif	
	f_cflag=1;
	}
	
	if (!gstrcmp (name, T ("jbuffer")))
  {
 			int32 ucValue=xProfMed.ucJbType - 1;
			for (nIndex = 0;
          nIndex < sizeof (web_JitterBufSetting_Types) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_JitterBufSetting_Types[nIndex].value, sValue,
                        web_JitterBufSetting_Types[nIndex].str);
     }
	}else if (!gstrcmp (name, T ("sfactor")))
  {
     ifx_httpdWrite (wp, T ("%d"), xProfMed.ucScalingFactor);
	}else if (!gstrcmp (name, T ("initsize")))
  {
     ifx_httpdWrite (wp, T ("%d"), xProfMed.unInitialSize);
	}else if (!gstrcmp (name, T ("maxsize")))
  {
     ifx_httpdWrite (wp, T ("%d"), xProfMed.unMaxSize);
	}else if (!gstrcmp (name, T ("minsize")))
  {
     ifx_httpdWrite (wp, T ("%d"), xProfMed.unMinSize);
	#ifndef DECT_SUPPORT
		f_cflag=0;
	#endif
	}else if(!gstrcmp (name,T("diallen"))){
			memset(&xNumberingPlan,0,sizeof(xNumberingPlan));
		  xNumberingPlan.iid.config_owner = IFX_WEB;
		  if (IFX_VMAPI_SUCCESS != ifx_get_NumPlan(&xNumberingPlan,0))
		  {
    		  ifx_httpdError (wp, 200, T ("Fail to get NumPlan\n"));
      		return -1;
  		}
      ifx_httpdWrite (wp, T ("%d"), xNumberingPlan.ucNumPlanMaxDigits);
			ifx_vmapi_freeObjectList(&xNumberingPlan,IFX_VMAPI_VS_NUM_PLAN);
	}
	#ifdef DECT_SUPPORT
	else if(!gstrcmp (name,T("clkmaster"))){
			if(xDectSys.ucClkMaster == 1)
				ifx_httpdWrite(wp, T("checked"));
	}	else if(!gstrcmp (name,T("dna"))){
			if(xDectSys.ucDnaEnable == 1)
				ifx_httpdWrite(wp, T("checked"));
		f_cflag=0;
	}
	#endif

return 0;
}
