/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_dect.c
 *        Abstract: CGI API's to Access DECT Settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)    
extern int g_DECT;
static char_t f_cflag;
static x_IFX_VMAPI_DectHandset xDectHandset;
static x_IFX_VMAPI_FxoPhyIf xFxoIf;
FILE *fp;

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_dect
 *  Description     : This function is called dect_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
int32
ifx_get_voip_sip_dect (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  int32 j=0;
  int32 m = 0;
  char_t sValue[MAX_DATA_LEN];
	x_IFX_VMAPI_VoiceLine xVoiceLine1;
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if( g_DECT < 1 )
  {
    g_DECT = 1;
  }
 if (!gstrcmp (name, T ("dect"))) /*For displaying buttons in the header*/
  {
		int i;
  memset(&xFxoIf, 0, sizeof(xFxoIf));
  xFxoIf.xVoiceServPhyIf.ucInterfaceId = 3;
  if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFxoIf, 0))
  {
    ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
    return IFX_VMAPI_FAIL;
  }
    for(i=1;i<=IFX_VMAPI_MAX_DECT_ENDPTS;i++)
    { 
	 
  		xDectHandset.xVoiceServPhyIf.ucInterfaceId = i + 3;
		  xDectHandset.iid.config_owner = IFX_WEB;
		  if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
		  {
		    ifx_httpdError (wp, 200, T ("Could not GET DectHandset\n"));
		    return -1;
		  }
      if((xDectHandset.ucVoiceLineId != 4) &&(xDectHandset.ucVoiceLineId != 0)){ 
        memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
        xVoiceLine1.ucLineId = xDectHandset.ucVoiceLineId;
        xVoiceLine1.iid.config_owner = IFX_WEB;
        if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0)){
          ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
          return IFX_VMAPI_FAIL;
        }
			  ifx_httpdWrite(wp, T("<tr><td>%d</td><td>%s</td><td>Handset</td><td>%s</td><td>%s</td><td><input type=\"radio\" value=\"%d\" name=\"int_select\" onclick=\"selected=%d\" /></td></tr>"), i,xDectHandset.ucEndPtId,xVoiceLine1.acName,(xDectHandset.xSubsInfo.bIsRegistered==1)?"Registered":"Not Registered",i,i);
      }else if(xDectHandset.ucVoiceLineId == 4){
			ifx_httpdWrite(wp, T("<tr><td>%d</td><td>%s</td><td>Handset</td><td>%s</td><td>%s</td><td><input type=\"radio\" value=\"%d\" name=\"int_select\" onclick=\"selected=%d\" /></td></tr>"), i,xDectHandset.ucEndPtId,xFxoIf.acName,(xDectHandset.xSubsInfo.bIsRegistered==1)?"Registered":"Not Registered",i,i);
       } else{
			ifx_httpdWrite(wp, T("<tr><td>%d</td><td>%s</td><td>Handset</td><td>None</td><td>%s</td><td><input type=\"radio\" value=\"%d\" name=\"int_select\" onclick=\"selected=%d\" /></td></tr>"), i,xDectHandset.ucEndPtId,(xDectHandset.xSubsInfo.bIsRegistered==1)?"Registered":"Not Registered",i,i);
       } 
			/* 
      ifx_httpdWrite(wp,T("<a onClick=\"testdect(%d);\"> Handset %d</a>"),i,i);
      ifx_httpdWrite(wp,T("\t"));
			*/
    }
		return 0;
  }
else if(f_cflag == 0) { 
  memset(&xDectHandset,0,sizeof(xDectHandset));
  xDectHandset.xVoiceServPhyIf.ucInterfaceId = g_DECT + 3;
  xDectHandset.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
  {
    ifx_httpdError (wp, 200, T ("Could not GET DectHandset\n"));
    return -1;
  }
  memset(&xFxoIf, 0, sizeof(xFxoIf));
  xFxoIf.xVoiceServPhyIf.ucInterfaceId = 3;
  if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFxoIf, 0))
  {
    ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
    return IFX_VMAPI_FAIL;
  }
	f_cflag = 1;
}  
  if (!gstrcmp (name, T ("numlines")))
  {
    while(xDectHandset.aucVoiceLineIdList[m] != 0)
    { 
	    m++;
    }
  ifx_httpdWrite(wp,T("%d"),m);
  }
else if (!gstrcmp (name, T ("ipei")))
  {
		ifx_httpdWrite(wp, T("%s"), xDectHandset.acIPEI);
		return 0;
  }
  else  if (!gstrcmp (name, T ("rr_number")))
  {
		ifx_httpdWrite(wp, T("%s"), xDectHandset.ucEndPtId);
		return 0;
  }
  else  if (!gstrcmp (name, T ("Subspntime")))
  {
		ifx_httpdWrite(wp, T("%s"), xDectHandset.acSubscriptionTime);
		return 0;
  }
  else  if (!gstrcmp (name, T ("sms")))
  {
	  if(xDectHandset.bSmsCapable == IFX_TRUE)	
		ifx_httpdWrite(wp, T("checked"));
		return 0;
  }
  else  if (!gstrcmp (name, T ("reg_status")))
  {
	  if(xDectHandset.xSubsInfo.bIsRegistered == 1)	
      ifx_httpdWrite (wp, T ("%s"), "REGISTERED");
		else
      ifx_httpdWrite (wp, T ("%s"), "UNREGISTERED");
		return 0;
  }
  else  if (!gstrcmp (name, T ("button")))
  {
	  if(xDectHandset.xSubsInfo.bIsRegistered == 1)	
      //ifx_httpdWrite (wp, T ("%s"), "UNREGISTER");
      ifx_httpdWrite (wp, T ("%s"), "<button onClick=\"return submitReg();\" name=\"button\" size=\"4\">Unregister</button>");
		else
      ifx_httpdWrite (wp, T ("%s"), "");
		return 0;
  }
  else  if (!gstrcmp (name, T ("hsname")))
  {
		ifx_httpdWrite(wp, T("%s"), xDectHandset.ucEndPtName);
		return 0;
  }
  else if (!gstrcmp (name, T ("intercept")))
  {
     uint32 ucValue = xDectHandset.bIntercept;
		 uint16 nIndex=0;
      for (nIndex = 0;
          nIndex < sizeof (web_Intr) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Intr[nIndex].value, sValue,
                        web_Intr[nIndex].str);
     }
    return 0;
	}
  else if (!gstrcmp (name, T ("defaultline")))
  {
    while(xDectHandset.aucVoiceLineIdList[j] != 0)
    {
      if (xDectHandset.aucVoiceLineIdList[j] == xDectHandset.ucVoiceLineId)
	      gstrcpy(sValue,"selected");
      else
	      gstrcpy(sValue,"");

      if (xDectHandset.aucVoiceLineIdList[j] == 4)
      {
        ifx_httpdWrite (wp, T("<option value= \"%d\" %s> %s </option>"),
                     xDectHandset.aucVoiceLineIdList[j],sValue,xFxoIf.acName);
      }
      else
      {
       memset(&xVoiceLine1,0,sizeof(xVoiceLine1));
       xVoiceLine1.ucLineId = xDectHandset.aucVoiceLineIdList[j];
       xVoiceLine1.iid.config_owner = IFX_WEB;
       if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine1,0))
       {
         ifx_httpdError (wp, 200, "Fail to GET the VoiceLine (VL Status) !!!");
         return IFX_VMAPI_FAIL;
       }       
       ifx_httpdWrite (wp, T("<option value= \"%d\" %s> %s </option>"),
                     xDectHandset.aucVoiceLineIdList[j],sValue, xVoiceLine1.acName);            
      } 
	    j++;
    }
  /* This return value is used in the asp page for validation of the default Voip Line parameter*/
		f_cflag=0;
		return 0;
	}
return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_dect
 *  Description     : This function is called dect_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_dect (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pNumber = ifx_httpdGetVar (wp, T ("rr_number"), T (""));
  char_t * pSmsCapable = ifx_httpdGetVar (wp, T ("sms"), T (""));
  char_t * pVoipLine = ifx_httpdGetVar (wp, T ("voip_line"), T (""));
  char_t * pButton = ifx_httpdGetVar (wp, T ("RegVal"), T (""));
  char_t * pIntr = ifx_httpdGetVar (wp, T ("intercept"), T (""));
	char_t * pHsName = ifx_httpdGetVar(wp, T ("hsname"), T(""));
  //x_IFX_VMAPI_DectHandset xDectHandset;

	int32 nIndex=0;
	x_IFX_VMAPI_VoiceServPhyIf xVoiceIf;
	x_IFX_VMAPI_FxsPhyIf xFxsIf;
	//x_IFX_VMAPI_FxoPhyIf xFxoIf;
  x_IFX_VMAPI_DectHandset xDectIf;
	char8 aucEndPt[12] = {0};
  if( g_DECT < 1 || g_DECT > 6)
  {
    g_DECT = 1;
  }
	
  memset(&xDectHandset,0,sizeof(xDectHandset));
  xDectHandset.xVoiceServPhyIf.ucInterfaceId = g_DECT + 3;
  xDectHandset.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
  {
    ifx_httpdError (wp, 200, T ("Could not GET DectHandset\n"));
    return ;
  }

	if(atoi(pButton) == 1)
	{
	  xDectHandset.xSubsInfo.bIsRegistered = 0;
		//sprintf((char8 *)xDectHandset.ucEndPtName,"Handset%d",g_DECT);
	  xDectHandset.bIntercept = 0;
    //xDectHandset.ucEndPtName[8]='\0';
	}
	//copy the Handset Name...
	strcpy((char8 *)xDectHandset.ucEndPtName,pHsName);
  xDectHandset.bSmsCapable = atoi(pSmsCapable);
  xDectHandset.bIntercept = atoi(pIntr);
  xDectHandset.ucVoiceLineId = atoi (pVoipLine);

	strcpy(aucEndPt,pNumber);

  if(strcmp((char8 *)xDectHandset.ucEndPtId ,pNumber) != 0)
	{
      
    while(nIndex != (IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS + IFX_VMAPI_MAX_DECT_ENDPTS))  
    {
		  memset(&xVoiceIf, 0, sizeof(xVoiceIf));
		  xVoiceIf.ucInterfaceId = nIndex+1; 
		  if(IFX_VMAPI_SUCCESS != ifx_get_VoicePhyInterface(&xVoiceIf , 0))
		  {
        ifx_httpdError (wp, 200, T ("ifx_get_VoicePhyInterface failed\n"));
        return ;
		  }
		
	    if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_FXS)
		  {
		    memset(&xFxsIf, 0, sizeof(xFxsIf));
			  xFxsIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
        if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFxsIf , IFX_F_DEFAULT))
		    {
          ifx_httpdError (wp, 200, T ("ifx_get_FxsPhyInterface failed\n"));
          return ;
		    }
			  if(strcmp((char8 *)xFxsIf.ucEndPtId , aucEndPt) == 0)
			  {
          ifx_httpdError (wp, 200, T ("EndPtId Exists for FXS\n"));
          return ;
				
			  }
			 else
			  {
          strcpy((char8 *)xDectHandset.ucEndPtId ,pNumber);
			  }
		  }

		  if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_FXO)
		  {
		    memset(&xFxoIf, 0, sizeof(xFxoIf));
			  xFxoIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
        if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFxoIf, 0))
		    {
          ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
          return ;
		    }
			  if(strcmp((char8 *)xFxoIf.ucEndPtId , aucEndPt) == 0)
			  {
          ifx_httpdError (wp, 200, T ("EndPtId Exists for FXO\n"));
          return ;
				
			  }
			  else
			  {
          strcpy((char8 *)xDectHandset.ucEndPtId ,pNumber);
			  }
		  }	
			if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_DECT)
		  {
		    memset(&xDectIf, 0, sizeof(xDectIf));
			  xDectIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
        if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectIf , 0))
		    {
          ifx_httpdError (wp, 200, T ("ifx_get_DectHandset failed\n"));
          return ;
		    }
			  if(strcmp((char8 *)xDectIf.ucEndPtId , aucEndPt) == 0)
			  {
          ifx_httpdError (wp, 200, T ("EndPtId Exists for DECT\n"));
          return ;
				
			  }
			 else
			  {
          strcpy((char8 *)xDectHandset.ucEndPtId ,pNumber);
			  }
		  }
			
 	    nIndex++; 
    }
	}


  if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHandset,0))
  {
    ifx_httpdError (wp, 200, T ("SET is failing for Dect Handset\n"));
    return ;
  } 

	f_cflag = 0;
  ifx_httpdNextPage_New(wp);

}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_dectno
 *  Description     : This function is called header_dect.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Sets the DECT ID and redirects to the Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_dectno (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pDectId = ifx_httpdGetVar (wp, T ("DectId"), T (""));

  g_DECT = atoi(pDectId);
	f_cflag=0;
  ifx_httpdNextPage (wp);
}


#endif
