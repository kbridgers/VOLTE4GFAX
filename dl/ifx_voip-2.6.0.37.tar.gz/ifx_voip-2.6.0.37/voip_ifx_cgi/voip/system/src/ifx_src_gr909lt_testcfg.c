/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : WAM( WEB ADAPTATION MODULE )
 *        Block   :  
 *        Creator : Purnendu Ghosh 
 *        File    : ifx_src_gr909lt_testcfg.c
 *        Abstract: CGI API's to test Cfg
 *        Date    : 18-04-2008
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           Purnendu Ghosh     24-04-08 1.0     Initial Dev.
 ************************************************************************/  
#include <signal.h>
#include <sys/time.h>
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

/* Global Declarations */
/* Indicate the FXS Line Id which is under test .
 * Can take the value specified by 
 * e_IFX_WAM_FxsLineId
 */
EXTERN char_t	gcFXSLineId_UnderTest;	

/* Approximate time for testing */
EXTERN uint32	guiTestExp_Timer;

/* Flag indicating Test Status.
 * Can take the value specified by
 * e_IFX_WAM_TestStatus 
 */
EXTERN char_t	gcTestStatus;
static struct itimerval value;

/* structure to hold the FXS Lines */
CGI_ENUMSEL_S web_Enum_FxsLine[2] =
{
          {0, "FXS0"},
          {1, "FXS1"},
};


  FILE *fp;
/*****************************************************************************
 *  Function Name   : sigalarm_hdlr
 *  Description     : This function is called when timer ,which has been 
 *                  : started while starting the line test,expires with
 *                  : signal SIGKILL. 
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
void sigalarm_hdlr(int signum)
{
  x_IFX_VMAPI_VoiceServTestResult xtestRes;

  /* Control reaching at this point implicits that timer started at 
   * web client side is not fired and hence timer started at web sever
   * side is fired.
   */

  /* Get the test result */
	memset ( &xtestRes, 0, sizeof(x_IFX_VMAPI_VoiceServTestResult));
  if(IFX_VMAPI_SUCCESS != ifx_get_PhyInterfaceTestResult(&xtestRes ,IFX_F_DEFAULT))
  {
    //ifx_httpdError (wp, 200, T ("Fail to get the test results"));
  }
		
	/* Reset the flag gcTestStatus */
	gcTestStatus = IFX_WAM_TEST_STATUS_NONE;

  /* Reset the Timer value */
  guiTestExp_Timer = 0;

	return;
}

/*****************************************************************************
 *  Function Name   : ifx_get_gr909lt_testcfg
 *  Description     : This function is called while loading 
 *                  : gr909lt_testcfg.asp.Always on load "FXS0" line needs 
 *                  : to be high lighted by default.Also None of the test 
 *                  : configurations should be checked by default.
 *                  : User is supposed to choose the the FXS Line on which
 *                  : he needs to perform the test and also the type of
 *                  : tests. 
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
  int
ifx_get_gr909lt_testcfg (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];	
  int32 nIndex=0;
	  
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if (!gstrcmp (name, T ("fxslineid")))
  {
      uint32 ucValue = gcFXSLineId_UnderTest;
    
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_FxsLine) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_FxsLine[nIndex].value, sValue,
                        web_Enum_FxsLine[nIndex].str);
      }
  }
  return 0;

} /* ifx_get_gr909lt_testcfg() */


/*****************************************************************************
 *  Function Name   : ifx_set_gr909lt_testcfg
 *  Description     : This function is called in submition of 
 *                  : gr909lt_testcfg.asp
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
void
ifx_set_gr909lt_testcfg(httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pfxslineid = ifx_httpdGetVar (wp, T ("fxslineid"), T (""));
  char_t * pstopstatus = ifx_httpdGetVar (wp, T ("stopstatus"), T (""));
  //int32	iRet;
 // uint8	ucFXSLineStatus; /* FXS Line Status */
  x_IFX_VMAPI_VoiceServPhyIfTest xTestCfg;
  x_IFX_VMAPI_VoiceServTestResult xtestRes;
  a_assert (wp);
	
if (!gstrcmp (pstopstatus, T ("1"))){
		 /* Reset the flag gcTestStatus */
    gcTestStatus = IFX_WAM_TEST_STATUS_NONE;

    /* Reset the Timer value */
    guiTestExp_Timer = 0;

    /* Stop the timer which was started in web server side after 
     * starting the line testing.
     * Control reaching at this point implicit that timer started at 
     * web client side is fired.so we should stop the timer which is
     * on in web server side.
     */
    /* Stop the timer */
    {
      memset(&value,0,sizeof(struct itimerval));
      value.it_value.tv_sec = 0;

      if(setitimer(ITIMER_REAL,&value,NULL)== -1)
      {
        perror("setitimer");
      }
    }
		signal(SIGALRM,sigalarm_hdlr);
	//reset all the stuff
      memset(&xtestRes,0,sizeof(x_IFX_VMAPI_VoiceServTestResult));
  /*Reset the test result values */
  if(IFX_VMAPI_SUCCESS != ifx_set_PhyInterfaceTestResult(IFX_OP_MOD, &xtestRes , IFX_F_DEFAULT))
  {
    ifx_httpdError (wp, 200, T ("Fail to reset the Test results"));
    return;
  }

  /* By default set the Test State to IN_PROGRESS before sending the 
     notification to the GW APP */
      memset(&xTestCfg,0,sizeof(x_IFX_VMAPI_VoiceServPhyIfTest));
  xTestCfg.ucTestState=IFX_VMAPI_TEST_STATE_FAILURE;
  xTestCfg.ucInterfaceId = atoi(pfxslineid) +1;
  if(IFX_VMAPI_SUCCESS != ifx_set_PhyInterfaceTest(IFX_OP_MOD, &xTestCfg , IFX_F_DEFAULT))
  {
    ifx_httpdError (wp, 200, T ("Fail to SET the Phy Inteface Test config"));
    return;
  }
 
 	ifx_httpdNextPage_New(wp);
}
	
  memset( &xTestCfg,0, sizeof(x_IFX_VMAPI_VoiceServPhyIfTest));
  /* Get the test result */
  if(IFX_VMAPI_SUCCESS != ifx_get_PhyInterfaceTest(&xTestCfg , IFX_F_DEFAULT))
  {
     ifx_httpdError (wp, 200, T ("Fail to get the test config"));
     return;
  }
	else
	{
		if(xTestCfg.ucTestState == IFX_VMAPI_TEST_STATE_IN_PROGRESS)
		{
      ifx_httpdError (wp, 200, T ("Test is still running"));
      return;
		}
	}
	
	
  guiTestExp_Timer = 5;
	
	/* Populating the FXS line which is going for line test */
	/* First FXS Line is under Test */
	if( atoi(pfxslineid) == 0 )
	{
  	/* Cache globally the FXS line which is going under
	  * line test.This information will be requird by WAM
	  * to get the test result on expiry of estimated 
	  * test timer value.
  	*/
	  gcFXSLineId_UnderTest = IFX_WAM_FXSLINE_FIRST;
	
	}
	/* Second FXS Line is under Test */
	else if( atoi(pfxslineid) == 1 )
	{
  	/* Cashe globally the FXS line which is going under
	  * line test.This information will be requird by WAM
	  * to get the test result on expiry of estimated 
	  * test timer value.
  	*/
	  gcFXSLineId_UnderTest = IFX_WAM_FXSLINE_SECOND;

	}
	else {}

  /*Reset the test result values */
  memset ( &xtestRes, 0, sizeof(x_IFX_VMAPI_VoiceServTestResult));
  if(IFX_VMAPI_SUCCESS != ifx_set_PhyInterfaceTestResult(IFX_OP_MOD, &xtestRes , IFX_F_DEFAULT))
  {
    ifx_httpdError (wp, 200, T ("Fail to reset the Test results"));
    return;
  }

  /* By default set the Test State to IN_PROGRESS before sending the 
     notification to the GW APP */
  xTestCfg.ucTestState = IFX_VMAPI_TEST_STATE_IN_PROGRESS;
  xTestCfg.ucInterfaceId = atoi(pfxslineid) +1;
  if(IFX_VMAPI_SUCCESS != ifx_set_PhyInterfaceTest(IFX_OP_MOD, &xTestCfg , IFX_F_DEFAULT))
  {
    ifx_httpdError (wp, 200, T ("Fail to SET the Phy Inteface Test config"));
    return;
  }
	/* Test has started successfully. 
	 * Now We need to start the timer for value 
   * [ guiTestExp_Timer + some more seconds(5secs)].
	 * Set the flag indicating test has started.
	 * */
	else
	{
		/* Start the timer in web server side */
		{
			memset(&value,0,sizeof(struct itimerval));
			value.it_value.tv_sec = ( guiTestExp_Timer + 1 );

			/* Registering the Signal Handler */
			signal(SIGALRM,sigalarm_hdlr);

			if(setitimer(ITIMER_REAL,&value,NULL)== -1)
			{
				perror("setitimer");
				return;
				/* exit (0); */
			}
  	}
		/* set the flag indicating test is in progress */
		gcTestStatus = IFX_WAM_TEST_STATUS_INPROG;	
	}

  ifx_httpdNextPage (wp);

} /* ifx_set_gr909lt_testcfg */
