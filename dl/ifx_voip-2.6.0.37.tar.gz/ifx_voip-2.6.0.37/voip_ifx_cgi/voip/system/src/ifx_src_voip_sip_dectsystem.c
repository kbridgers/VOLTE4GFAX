/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_dect.c
 *        Abstract: CGI API's to Access DECT Settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
int32 g_DECT_TESTVER;
static char_t f_cflag;
static  x_IFX_VMAPI_DectSystem xDectSys;
extern int g_DIAGMODE;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_dectsys
 *  Description     : This function is called dect_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
int32
ifx_get_voip_sip_dectsys (int eid, httpd_t wp, int argc, char_t ** argv) 
{
 char_t * name, *mode;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

if(f_cflag == 0){
  memset(&xDectSys,0,sizeof(xDectSys));
  xDectSys.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xDectSys,0))
  {
    ifx_httpdError (wp, 200, T ("Could not GET Dect\n"));
    return -1;
  }
 f_cflag = 1;
} 
  if (!gstrcmp (name, T ("pin")))
  {
		ifx_httpdWrite(wp, T("%s"), xDectSys.acAuthCode);
 		#ifdef CVOIP_SUPPORT
			f_cflag = 0;
		#endif
		return 0;
  }
  else if (!gstrcmp (name, T ("name")))
  {
		ifx_httpdWrite(wp, T("%s"), xDectSys.acBaseName);
		return 0;
  }
  else  if (!gstrcmp (name, T ("encrypt")))
  {
		if(xDectSys.ucEncrytionEnable == 1)
		{
			ifx_httpdWrite(wp, T("checked"));
		}
 		#ifdef CVOIP_SUPPORT
 			f_cflag = 0;
		#endif
		return 0;
  }
  else  if (!gstrcmp (name, T ("nemo")))
  {
		if(xDectSys.ucNoEmo == 1)
		{
			ifx_httpdWrite(wp, T("checked"));
		}
		return 0;
  }else  if (!gstrcmp (name, T ("RfEnable")))
  {
		if(xDectSys.ucRfEnable == 1)
		{
			ifx_httpdWrite(wp, T("checked"));
		}
 		f_cflag = 0;
		return 0;
  }


  return 0;

}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_dectsys
 *  Description     : This function is called dect_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_dectsys (httpd_t wp, char_t * path, char_t * query) 
{
#ifdef DECT_SUPPORT
	extern void ifx_set_voip_rfpi(httpd_t wp, char_t * path, char_t * query);
	extern void ifx_set_voip_CtrySet(httpd_t wp, char_t * path, char_t * query);
  char_t * pName = ifx_httpdGetVar (wp, T ("name"), T (""));
  char_t * pNoEmo = ifx_httpdGetVar (wp, T ("nemo"), T (""));
  char_t * pRfEn = ifx_httpdGetVar (wp, T ("RfEnable"), T (""));
  char_t * pEncrypt = ifx_httpdGetVar (wp, T ("encrypt"), T (""));
#endif
  char_t * pPin = ifx_httpdGetVar (wp, T ("pin"), T (""));
#ifdef CVOIP_SUPPORT
 char_t * pOperation = ifx_httpdGetVar (wp, T ("sysop"), T (""));
#endif
  int iChanged=0;

#ifdef CVOIP_SUPPORT
if(atoi(pOperation) == 1)
	 LTQ_CVoIP_ParamRequest(IFX_VMAPI_DECT_SYSTEM_REQUEST);
else {
#endif
  xDectSys.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xDectSys,0))
  {
    ifx_httpdError (wp, 200, T ("Could not GET Dect System !!\n"));
    return ;
  }
  
  if(strcmp(xDectSys.acAuthCode , pPin) !=0){
    strcpy(xDectSys.acAuthCode , pPin);
    iChanged=1;
  }
#ifdef DECT_SUPPORT
  if(xDectSys.ucEncrytionEnable != atoi(pEncrypt)){
	  xDectSys.ucEncrytionEnable = atoi(pEncrypt);
    iChanged=1;
  }
  if(strcmp(xDectSys.acBaseName , pName)!=0){
    strcpy(xDectSys.acBaseName , pName);
    iChanged=1;
  }
	if(xDectSys.ucNoEmo != atoi(pNoEmo)){
			xDectSys.ucNoEmo = atoi(pNoEmo);
			iChanged=1;
	}

	if(xDectSys.ucRfEnable != atoi(pRfEn)){
			xDectSys.ucRfEnable = atoi(pRfEn);
			iChanged=1;
	}
#endif
  if(iChanged == 1){
    if(IFX_VMAPI_SUCCESS != ifx_set_DectInterface(IFX_OP_MOD,&xDectSys,0))
    {
      ifx_httpdError (wp, 200, T ("SET is failing for Dect System !!\n"));
      return ;
    }
  } 
#ifdef DECT_SUPPORT
	ifx_set_voip_rfpi(wp, path, query);
	ifx_set_voip_CtrySet(wp, path, query);
#endif
#ifdef CVOIP_SUPPORT
}
#endif

 	f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}

#ifdef CVOIP_SUPPORT
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_syscap
 *  Description     : This function is called diagnostics.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_syscap (httpd_t wp, char_t * path, char_t * query)
{
  char_t * pEncrypt = ifx_httpdGetVar (wp, T ("encrypt"), T (""));
  int iChanged=0;
  char_t * pOperation = ifx_httpdGetVar (wp, T ("sysop"), T (""));
if(atoi(pOperation) == 1)
   LTQ_CVoIP_ParamRequest(IFX_VMAPI_CVOIP_SYSTEM_CAPABALITIES);
else {
  xDectSys.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xDectSys,0))
  {
    ifx_httpdError (wp, 200, T ("Could not GET Dect System !!\n"));
    return ;
  }
  if(xDectSys.ucEncrytionEnable != atoi(pEncrypt)){
    xDectSys.ucEncrytionEnable = atoi(pEncrypt);
    iChanged=1;
  }
	if(iChanged == 1){
    if(IFX_VMAPI_SUCCESS != ifx_set_DectInterface(IFX_OP_MOD,&xDectSys,0))
    {
      ifx_httpdError (wp, 200, T ("SET is failing for Dect System !!\n"));
      return ;
    }
  }
}
 f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}
#endif


/*****************************************************************************
 *  Function Name   : ifx_set_voip_tbr_testcfg
 *  Description     : This function is called in submition of 
 *                  : gr909lt_testcfg.asp
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
void
ifx_set_voip_tbr_testcfg(httpd_t wp, char_t * path, char_t * query)
{
 char_t * pStatus = ifx_httpdGetVar (wp, T ("status"), T (""));
  uchar8  ucStatus; /* FXS Line Status */
  a_assert (wp);

  ucStatus = atoi(pStatus);
#if defined(CVOIP_SUPPORT)
if(ucStatus == 1)
LTQ_CVoIP_ParamRequest(IFX_VMAPI_TBR6_REQUEST);
else {
#endif
#if defined(DECT_SUPPORT)
  if(g_DIAGMODE == 1)
  {
#endif
    /*Reset the test result values */
    if(IFX_VMAPI_SUCCESS != ifx_set_Tbr6Test(IFX_OP_MOD, ucStatus , IFX_F_DEFAULT))
    {
      ifx_httpdError (wp, 200, T ("Fail to reset the Test results"));
      return;
    }
#if defined(DECT_SUPPORT)
  }
  else
  {
   ifx_httpdError (wp, 200, T ("DIAGNOSTICS mode is disabled\n"));
   return;
  }
#endif
#if defined(CVOIP_SUPPORT)
}
#endif

  ifx_httpdNextPage_New(wp);
} /* ifx_set_gr909lt_testcfg */
#endif

