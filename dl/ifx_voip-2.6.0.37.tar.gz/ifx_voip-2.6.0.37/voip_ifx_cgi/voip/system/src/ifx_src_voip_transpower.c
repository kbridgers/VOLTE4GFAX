/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_debug.c
 *        Abstract: CGI API's to Access debug settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------


 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
//extern char_t g_cflag;
static char_t f_cflag;
extern int g_DIAGMODE;
static x_IFX_VMAPI_TransmitPowerParam  xTpwrPar;

void selectModeByIndex(uchar8 ucIndex,uchar8 *pcByte);
void selectIndexByMode(uchar8 ucByte,uint32 *pucIndex);
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_debug
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/ 
void
ifx_set_voip_transpowertune (httpd_t wp, char_t * path, char_t * query) 
{
	uchar8 ucStatus;
  char_t * pTuneDig = ifx_httpdGetVar (wp, T ("TuneDig"), T (""));
  char_t * pSwpwrMo = ifx_httpdGetVar (wp, T ("SwPwrMde"), T (""));
  char_t * pTxBias = ifx_httpdGetVar (wp, T ("TxBias"), T (""));
	char_t * pTransPower = ifx_httpdGetVar (wp, T ("TransPower"), T (""));


	int32 iRet;
 memset(&xTpwrPar,0,sizeof(xTpwrPar));
 xTpwrPar.iid.config_owner = IFX_WEB;
 if(ifx_get_TransPower(&xTpwrPar,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Debug\n"));
    return ;
  }

  ucStatus=atoi(pTransPower);
  xTpwrPar.ucTuneDigital = hd((uchar8 *)pTuneDig);
  xTpwrPar.ucTxBias = hd((uchar8 *)pTxBias);

  if (atoi(pSwpwrMo) == 2)
    xTpwrPar.ucSWPowerMode=IFX_VMAPI_SW_POWERMODE_USER;
  else
    xTpwrPar.ucSWPowerMode=atoi(pSwpwrMo);

  xTpwrPar.iid.config_owner = IFX_WEB;

#if 1
  if(ucStatus == 1 && g_DIAGMODE == 1) {
  iRet = ifx_set_TransPowerToModem(1,NULL);
    IFX_CGI_DEBUG("\n<ifx_set_TransPowerToModem>UCSTATUS=1\n");
  }
  else if(ucStatus == 2 && g_DIAGMODE == 1) {
  iRet = ifx_set_TransPowerToModem(2,&xTpwrPar);
  iRet = ifx_set_TransPower(IFX_OP_MOD,&xTpwrPar,0);
    IFX_CGI_DEBUG("\n<ifx_set_TransPowerToModem>UCSTATUS=2\n");
  }else if(ucStatus == 0){
    iRet = ifx_set_TransPower(IFX_OP_MOD,&xTpwrPar,0);
   }else {
   ifx_httpdError (wp, 200, T ("DIAGNOSTICS mode is disabled\n"));
   return;
  }

  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Debug\n"));
    return ;
  }
#endif
    f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}

void
ifx_set_voip_transpower (httpd_t wp, char_t * path, char_t * query) 
{
 uchar8 ucStatus;
  char_t * pTunDg = ifx_httpdGetVar (wp, T ("TunDgtRef"), T (""));
  char_t * pPaBias = ifx_httpdGetVar (wp, T ("PABiasRef"), T (""));
  char_t * pPwrOff0 = ifx_httpdGetVar (wp, T ("Pwroffset0"), T (""));
  char_t * pPwrOff1 = ifx_httpdGetVar (wp, T ("Pwroffset1"), T (""));
  char_t * pPwrOff2 = ifx_httpdGetVar (wp, T ("Pwroffset2"), T (""));
  char_t * pPwrOff3 = ifx_httpdGetVar (wp, T ("Pwroffset3"), T (""));
  char_t * pPwrOff4 = ifx_httpdGetVar (wp, T ("Pwroffset4"), T (""));
  char_t * pTd1 = ifx_httpdGetVar (wp, T ("TD1"), T (""));
  char_t * pTd2 = ifx_httpdGetVar (wp, T ("TD2"), T (""));
  char_t * pTd3 = ifx_httpdGetVar (wp, T ("TD3"), T (""));
  char_t * pPa1 = ifx_httpdGetVar (wp, T ("PA1"), T (""));
  char_t * pPa2 = ifx_httpdGetVar (wp, T ("PA2"), T (""));
  char_t * pPa3 = ifx_httpdGetVar (wp, T ("PA3"), T (""));
  char_t * pSwpwrMo = ifx_httpdGetVar (wp, T ("SwPwrMde"), T (""));
  char_t * pTxpow0 = ifx_httpdGetVar (wp, T ("Txpow0"), T (""));
  char_t * pTxpow1 = ifx_httpdGetVar (wp, T ("Txpow1"), T (""));
  char_t * pTxpow2 = ifx_httpdGetVar (wp, T ("Txpow2"), T (""));
  char_t * pTxpow3 = ifx_httpdGetVar (wp, T ("Txpow3"), T (""));
  char_t * pTxpow4 = ifx_httpdGetVar (wp, T ("Txpow4"), T (""));
  char_t * pTxpow5 = ifx_httpdGetVar (wp, T ("Txpow5"), T (""));
  char_t * pDbpow = ifx_httpdGetVar (wp, T ("Dbpow"), T (""));
  char_t * pTuneDig = ifx_httpdGetVar (wp, T ("TuneDig"), T (""));
  char_t * pTxBias = ifx_httpdGetVar (wp, T ("TxBias"), T (""));
  char_t * pTransPower = ifx_httpdGetVar (wp, T ("TransPower"), T (""));
	int32 iRet=IFX_FAIL;
  
  ucStatus=atoi(pTransPower);
  if(ucStatus == 1 /*&& g_DIAGMODE == 1*/) {
		#if defined(CVOIP_SUPPORT)
			 iRet =  LTQ_CVoIP_ParamRequest(IFX_VMAPI_TRANS_POWER_REQUEST);
		#elif defined(DECT_SUPPORT)	
			iRet = ifx_set_TransPowerToModem(1,NULL);
		#endif
  } else{
 					memset(&xTpwrPar,0,sizeof(xTpwrPar));

					 xTpwrPar.iid.config_owner = IFX_WEB;
				 if(ifx_get_TransPower(&xTpwrPar,0) != IFX_VMAPI_SUCCESS)
			  {
				    ifx_httpdError (wp, 200, T ("Fail to GET Debug\n"));
				    return ;
				}  
					xTpwrPar.ucTuneDigitalRef = hd((uchar8 *)pTunDg);
					xTpwrPar.ucPABiasRef = hd((uchar8 *)pPaBias);
					xTpwrPar.ucPowerOffset0 = hd((uchar8 *)pPwrOff0);
					xTpwrPar.ucPowerOffset1 = hd((uchar8 *)pPwrOff1);
					xTpwrPar.ucPowerOffset2 = hd((uchar8 *)pPwrOff2);
					xTpwrPar.ucPowerOffset3 = hd((uchar8 *)pPwrOff3);
					xTpwrPar.ucPowerOffset4 = hd((uchar8 *)pPwrOff4);
					xTpwrPar.ucTD1 =  hd((uchar8 *)pTd1);
					xTpwrPar.ucTD2 = hd((uchar8 *)pTd2);
					xTpwrPar.ucTD3 = hd((uchar8 *)pTd3);
					xTpwrPar.ucPA1 = hd((uchar8 *)pPa1);
					xTpwrPar.ucPA2 = hd((uchar8 *)pPa2);
					xTpwrPar.ucPA3 = hd((uchar8 *)pPa3);
					xTpwrPar.ucTuneDigital = hd((uchar8 *)pTuneDig);
					xTpwrPar.ucTxBias = hd((uchar8 *)pTxBias);

					if (atoi(pSwpwrMo) == 2)
						xTpwrPar.ucSWPowerMode=IFX_VMAPI_SW_POWERMODE_USER;
					else
						xTpwrPar.ucSWPowerMode=atoi(pSwpwrMo);

					selectModeByIndex(atoi(pTxpow0),&xTpwrPar.ucTXPOW_0);
					selectModeByIndex(atoi(pTxpow1),&xTpwrPar.ucTXPOW_1);
					selectModeByIndex(atoi(pTxpow2),&xTpwrPar.ucTXPOW_2);
					selectModeByIndex(atoi(pTxpow3),&xTpwrPar.ucTXPOW_3);
					selectModeByIndex(atoi(pTxpow4),&xTpwrPar.ucTXPOW_4);
					selectModeByIndex(atoi(pTxpow5),&xTpwrPar.ucTXPOW_5);
					selectModeByIndex(atoi(pDbpow),&xTpwrPar.ucDBPOW);

				 if(ucStatus == 2 /*&& g_DIAGMODE == 1*/) {
							#if defined(DECT_SUPPORT)
								iRet = ifx_set_TransPowerToModem(2,&xTpwrPar);
							#endif
							iRet = ifx_set_TransPower(IFX_OP_MOD,&xTpwrPar,0);
				 } else if(ucStatus == 0) {
								iRet = ifx_set_TransPower(IFX_OP_MOD,&xTpwrPar,0);
	  			}
  }
  
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Debug\n"));
    return ;
  }  

  /*IFX_CGI_DEBUG("\n<CGI>TransPower Struct\n");
  IFX_CGI_DEBUG("\n<CGI>\nucTuneDigitalRef: %d",xTpwrPar.ucTuneDigitalRef);
  IFX_CGI_DEBUG("\n<CGI>\nucPABiasRef: %d",xTpwrPar.ucPABiasRef);
  IFX_CGI_DEBUG("\n<CGI>\nucPowerOffset[0]: %d",xTpwrPar.ucPowerOffset0);
  IFX_CGI_DEBUG("\n<CGI>\nucPowerOffset[1]: %d",xTpwrPar.ucPowerOffset1);
  IFX_CGI_DEBUG("\n<CGI>\nucPowerOffset[2]: %d",xTpwrPar.ucPowerOffset2);
  IFX_CGI_DEBUG("\n<CGI>\nucPowerOffset[3]: %d",xTpwrPar.ucPowerOffset3);
  IFX_CGI_DEBUG("\n<CGI>\nucPowerOffset[4]: %d",xTpwrPar.ucPowerOffset4);
  IFX_CGI_DEBUG("\n<CGI>\nucTD1: %d",xTpwrPar.ucTD1);
  IFX_CGI_DEBUG("\n<CGI>\nucTD2: %d",xTpwrPar.ucTD2);
  IFX_CGI_DEBUG("\n<CGI>\nucTD3: %d",xTpwrPar.ucTD3);
  IFX_CGI_DEBUG("\n<CGI>\nucPA1: %d",xTpwrPar.ucPA1);
  IFX_CGI_DEBUG("\n<CGI>\nucPA2: %d",xTpwrPar.ucPA2);
  IFX_CGI_DEBUG("\n<CGI>\nucPA3: %d",xTpwrPar.ucPA3);
  IFX_CGI_DEBUG("\n<CGI>\nucDBPOW: %d",xTpwrPar.ucDBPOW);
*/
    f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_transpower
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_transpower (int eid, httpd_t wp, int argc, char_t ** argv) 
{
char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];
  char_t byte_value[3] = {'\0'};
  int nIndex = 0;
  int32 iRet;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }


  if(f_cflag == 0)
  {
    memset(&xTpwrPar,0,sizeof(xTpwrPar));
    xTpwrPar.iid.config_owner = IFX_WEB;
    iRet = ifx_get_TransPower(&xTpwrPar,0);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Debug Settings\n"));
      return -1;
    }  
    f_cflag = 1;
  }
	
  if (!gstrcmp (name, T ("TunDgtRef")))
  {
      //IFX_CGI_DEBUG("\nDid it enter here  %d",xTpwrPar.ucTuneDigitalRef);
      dh(xTpwrPar.ucTuneDigitalRef,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("PABiasRef")))
  {
      dh(xTpwrPar.ucPABiasRef,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Pwroffset0")))
  {
      dh(xTpwrPar.ucPowerOffset0,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Pwroffset1")))
  {
      dh(xTpwrPar.ucPowerOffset1,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Pwroffset2")))
  {
      dh(xTpwrPar.ucPowerOffset2,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Pwroffset3")))
  {
      dh(xTpwrPar.ucPowerOffset3,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Pwroffset4")))
  {
      dh(xTpwrPar.ucPowerOffset4,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("TD1")))
  {
      dh(xTpwrPar.ucTD1,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("TD2")))
  {
      dh(xTpwrPar.ucTD2,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("TD3")))
  {
      dh(xTpwrPar.ucTD3,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("PA1")))
  {
      dh(xTpwrPar.ucPA1,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("PA2")))
  {
      dh(xTpwrPar.ucPA2,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("PA3")))
  {
      dh(xTpwrPar.ucPA3,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("TuneDig")))
  {
    dh(xTpwrPar.ucTuneDigital,(uchar8 *)byte_value);
    ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("TxBias")))
  {
    dh(xTpwrPar.ucTxBias,(uchar8 *)byte_value);
    ifx_httpdWrite (wp, T ("%s"),byte_value);
		f_cflag = 0;
  }
  else if (!gstrcmp (name, T ("SwPwrMde")))
  {
    uint32 ucValue = xTpwrPar.ucSWPowerMode;
    if (ucValue == IFX_VMAPI_SW_POWERMODE_USER)
    	ucValue=2;
    for (nIndex = 0; nIndex < sizeof (web_TransPower_SWPwrMode) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_TransPower_SWPwrMode[nIndex].value, sValue,
                        web_TransPower_SWPwrMode[nIndex].str);
    }
  }
#ifdef DECT_SUPPORT
  else if (!gstrcmp (name, T ("Txpow0")))
  {
    uint32 ucValue1 = 0;
    dh(xTpwrPar.ucTXPOW_0,(uchar8 *)byte_value);
    
    if(!gstrcmp(byte_value,"E0"))
       ucValue1 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue1 = 8;
    else
      selectIndexByMode(atoi(&byte_value[0]),&ucValue1);
    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue1)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }

  }
  else if (!gstrcmp (name, T ("Txpow1")))
  {
    uint32 ucValue2 = 0;
    dh(xTpwrPar.ucTXPOW_1,(uchar8 *)byte_value);
    if(!gstrcmp(byte_value,"E0"))
       ucValue2 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue2 = 8;
    else
    selectIndexByMode(atoi(&byte_value[0]),&ucValue2);
    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue2)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }
  	//ifx_httpdWrite (wp, T ("%d"),xTpwrPar.ucTXPOW_1);
  }
#else
  else if (!gstrcmp (name, T ("Txpow0")))
  {
    dh(xTpwrPar.ucTXPOW_0,(uchar8 *)byte_value);
    ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Txpow1")))
  {
    dh(xTpwrPar.ucTXPOW_1,(uchar8 *)byte_value);
    ifx_httpdWrite (wp, T ("%s"),byte_value);
  }

#endif
  else if (!gstrcmp (name, T ("Txpow2")))
  {  
    uint32 ucValue3 = 0;
    dh(xTpwrPar.ucTXPOW_2,(uchar8 *)byte_value);
    if(!gstrcmp(byte_value,"E0"))
       ucValue3 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue3 = 8;
    else
    selectIndexByMode(atoi(&byte_value[0]),&ucValue3);
    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue3)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }
  	//ifx_httpdWrite (wp, T ("%d"),xTpwrPar.ucTXPOW_2);
  }
  else if (!gstrcmp (name, T ("Txpow3")))
  {
    uint32 ucValue4 = 0;
    dh(xTpwrPar.ucTXPOW_3,(uchar8 *)byte_value);
    if(!gstrcmp(byte_value,"E0"))
       ucValue4 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue4 = 8;
    else
    selectIndexByMode(atoi(&byte_value[0]),&ucValue4);

    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue4)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }
    //ifx_httpdWrite (wp, T ("%d"),xTpwrPar.ucTXPOW_3);
  }
  else if (!gstrcmp (name, T ("Txpow4")))
  {
    uint32 ucValue5 = 0;
    dh(xTpwrPar.ucTXPOW_4,(uchar8 *)byte_value);
    if(!gstrcmp(byte_value,"E0"))
       ucValue5 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue5 = 8;
    else
    selectIndexByMode(atoi(&byte_value[0]),&ucValue5);
    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue5)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }
    //ifx_httpdWrite (wp, T ("%d"),xTpwrPar.ucTXPOW_4);
  }
  else if (!gstrcmp (name, T ("Txpow5")))
  {
    uint32 ucValue6 = 0;
    dh(xTpwrPar.ucTXPOW_5,(uchar8 *)byte_value);
    if(!gstrcmp(byte_value,"E0"))
       ucValue6 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue6 = 8;
    else
    selectIndexByMode(atoi(&byte_value[0]),&ucValue6);
    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue6)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }
    //ifx_httpdWrite (wp, T ("%d"),xTpwrPar.ucTXPOW_5);
  }
  else if (!gstrcmp (name, T ("Dbpow")))
  {
    uint32 ucValue7 = 0;
    dh(xTpwrPar.ucDBPOW,(uchar8 *)byte_value);
    if(!gstrcmp(byte_value,"E0"))
       ucValue7 = 7;
    else if(!gstrcmp(byte_value,"F0"))
       ucValue7 = 8;
    else
    selectIndexByMode(atoi(&byte_value[0]),&ucValue7);
    //IFX_CGI_DEBUG("\n<ifx_get_voip_tpc>ucDBPOW  %d",xTpwrPar.ucDBPOW);
    //IFX_CGI_DEBUG("\n<ifx_get_voip_tpc>byte_value  %s",byte_value);
    //IFX_CGI_DEBUG("\n<ifx_get_voip_tpc>atoi(byte_value)  %d",atoi(&byte_value[0]));
    //IFX_CGI_DEBUG("\n<ifx_get_voip_tpc>ucValue7  %d",ucValue7);
    for (nIndex = 0; nIndex < sizeof (web_TransPower_Txpow) / sizeof (CGI_ENUMSEL_S); nIndex++)
    {
      if (nIndex == ucValue7)
        gstrcpy (sValue, "selected");
      else
        gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                      web_TransPower_Txpow[nIndex].value, sValue,
                      web_TransPower_Txpow[nIndex].str);
    }
    //ifx_httpdWrite (wp, T ("%d"),xTpwrPar.ucTXPOW_5);
    f_cflag = 0;
  }	  
 return 0;		  
		  
}


void selectModeByIndex(uchar8 ucIndex,uchar8 *pcByte){
 
switch(ucIndex){

   case 0:*pcByte = IFX_VMAPI_MCEI_FULLPOWERMODE;
          break;

   case 1:*pcByte = IFX_VMAPI_MCEI_FIVEDB;
          break;

   case 2:*pcByte = IFX_VMAPI_MCEI_TENDB;
          break;

   case 3:*pcByte = IFX_VMAPI_MCEI_FIFTEENDB;
          break;

   case 4:*pcByte = IFX_VMAPI_MCEI_TWENTYDB;
          break;

   case 5:*pcByte = IFX_VMAPI_MCEI_TWENTYFIVEDB;
          break;

   case 6:*pcByte = IFX_VMAPI_MCEI_THIRTYDB;
          break;

   case 7:*pcByte = IFX_VMAPI_MCEI_MIN_POWERMODE;
          break;
   
   case 8:*pcByte = IFX_VMAPI_MCEI_USERMODE;
          break;
  
   default:
         break;
  }

}

void selectIndexByMode(uchar8 ucByte,uint32 *pucIndex){

    //IFX_CGI_DEBUG("\nselectIndexByMode Entry");
    //IFX_CGI_DEBUG("\nucByte %d",ucByte);
  switch(ucByte){

    case 0:
    IFX_CGI_DEBUG("\nFull Power Mode");
        *pucIndex = 0;
    IFX_CGI_DEBUG("\n*pucIndex  %d",*pucIndex);
        break;
 
    case 10:
    //IFX_CGI_DEBUG("\n 5 Db");
        *pucIndex = 1;
    //IFX_CGI_DEBUG("\n*pucIndex  %d",*pucIndex);
        break;

    case 20:
        *pucIndex = 2;
        break;    

    case 30:
        *pucIndex = 3;
        break;

    case 40:
        *pucIndex = 4;
        break;

    case 50:
        *pucIndex = 5;
        break;
 
    case 60:
        *pucIndex = 6;
        break;
 
    default:
        break;
                          
  }

}
#endif 
