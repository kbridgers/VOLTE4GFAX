/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_numplan.c
 *        Abstract: CGI API's to Access Numbering Plan Settings
 *        Date    : 17-04-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 



************************************************************************/  

#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

extern char_t g_NUMPLAN;
static char_t f_cflag;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_numplan
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/

int
ifx_get_voip_sip_numplan (int eid, httpd_t wp, int argc, char_t ** argv) 
{


  char_t * name = NULL;
  int32 i=0;
	static x_IFX_VMAPI_NumPlan xNumberingPlan;
  x_IFX_VMAPI_NumPlanRule *pxTemp; 
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

if(f_cflag == 0){
  memset(&xNumberingPlan,0,sizeof(xNumberingPlan));
  xNumberingPlan.iid.config_owner = IFX_WEB;
  //iRet = ifx_get_NumPlan(&xNumberingPlan,0);
  if (IFX_VMAPI_SUCCESS != ifx_get_NumPlan(&xNumberingPlan,0))
  {
      ifx_httpdError (wp, 200, T ("Fail to get NumPlan\n"));
      return -1;
  }
 f_cflag=1;
}
  if (!gstrcmp (name, T("Rules")))
  {
  	ifx_httpdWrite(wp, T("%d"), xNumberingPlan.ucNoOfNumPlanRules);
		return 0;
  }	
  else if  (!gstrcmp (name, T("update")))/*For writing all the values on the web*/
  {
  	pxTemp = xNumberingPlan.pxNumPlanRules;
  	while (pxTemp !=NULL) {
			ifx_httpdWrite(wp, T("RuleAct[%d]=\"%d\";\n"), i, pxTemp->uiMainAct);
    	ifx_httpdWrite(wp, T("Prefix[%d]=\"%s\";\n"), i, pxTemp->acPrefix);
			ifx_httpdWrite(wp, T("MinLen[%d]=\"%d\";\n"), i, pxTemp->ucMinDigits4Prefix);
			ifx_httpdWrite(wp, T("MaxLen[%d]=\"%d\";\n"), i, pxTemp->ucMaxDigits4Prefix);
			ifx_httpdWrite(wp, T("RemDgts[%d]=\"%d\";\n"), i, pxTemp->ucNoOfDigits2bRem);
			ifx_httpdWrite(wp, T("PosRem[%d]=\"%d\";\n"), i, pxTemp->ucPosDigits2bRem);
			ifx_httpdWrite(wp, T("DigIns[%d]=\"%d\";\n"), i, pxTemp->cDigits2bIns);
			ifx_httpdWrite(wp, T("PosIns[%d]=\"%d\";\n"), i, pxTemp->ucPosDigits2bIns);
			ifx_httpdWrite(wp, T("DigRep[%d]=\"%d\";\n"), i, pxTemp->cDigits2bRep);
			ifx_httpdWrite(wp, T("PosRep[%d]=\"%d\";\n"), i, pxTemp->ucPosDigits2bRep);
    
    	i++;
    __ifx_list_GetNext((void *)&pxTemp);
   }/*while loop*/
  }

 	else if (!gstrcmp (name, T ("PopulateRules")))/*Initialising all the uiMainAct's array to zero*/
   {
  	for (i=xNumberingPlan.ucNoOfNumPlanRules;i<IFX_VMAPI_MAX_NUM_PLAN_RULES;i++)
				ifx_httpdWrite(wp, T("RuleAct[%d]=\"0\";\n"), i);
		return 0;
   }
  else if (!gstrcmp (name, T("LongTmr")))
  {
		ifx_httpdWrite(wp, T("%d"), xNumberingPlan.ucInterdigTimerStd);
		return 0;
  }
  else if (!gstrcmp (name, T("ShortTmr")))
  {
  	ifx_httpdWrite(wp, T("%d"), xNumberingPlan.ucInterdigTimerProg);
		f_cflag=0;
  	ifx_vmapi_freeObjectList(&xNumberingPlan,IFX_VMAPI_VS_NUM_PLAN);
		return 0;
  }
  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_numplan
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the Next Page
 ****************************************************************************/

void
ifx_set_voip_sip_numplan (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pValue = ifx_httpdGetVar (wp, T ("rownum"), T (""));
  char_t * pLongTmr = ifx_httpdGetVar (wp, T ("LongTmr"), T (""));
  char_t * pShortTmr = ifx_httpdGetVar (wp, T ("ShortTmr"), T (""));
  int32 iRet,RuleCount;
  x_IFX_VMAPI_NumPlan xNumPlan,xNumPlan1;
  x_IFX_VMAPI_NumPlanRule xRule, xRuleAdd;
  x_IFX_VMAPI_NumPlanRule *pxRule;
	int mod_flag=0;
	int iflag=0;
	uint32 uiTempNumPlanCnt=0;
	IFX_DBG("NumPlanSet Here 1");

	/* Latest number of rows that is configured from Web */
  g_NUMPLAN = atoi(pValue);
	
  int i=0,j=0,index=0,k=0; 
	char8 buf1[3] = {0}; 
  char8 input_ruleact[12] = "RuleAct";
  char8 input_prefix[12] = "Prefix";
  char8 input_minlen[12] = "MinLen";
  char8 input_maxlen[12] = "MaxLen";  
  char8 input_remdgts[12] = "RemDgts";  
  char8 input_posrem[12] = "PosRem";  
  char8 input_digins[12] = "DigIns";
  char8 input_posins[12] = "PosIns";
  char8 input_digrep[12] = "DigRep";  
  char8 input_posrep[12] = "PosRep";  

  memset(&xNumPlan,0,sizeof(xNumPlan));
  memset(&xRuleAdd,0,sizeof(xRuleAdd));

  xNumPlan.iid.config_owner = IFX_WEB;
	iRet = ifx_get_NumPlan(&xNumPlan,0);
	IFX_DBG("NumPlanSet Here 2");
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("GET NUMPLAN FAILED\n"));
		return ;
  }
  pxRule = xNumPlan.pxNumPlanRules;
  RuleCount = xNumPlan.ucNoOfNumPlanRules;
 
  if (RuleCount < g_NUMPLAN)
		index = RuleCount; /*Number of rules previously existing*/
	else
		index = g_NUMPLAN; /*New number of rules*/

	//file = fopen("/flash/num.txt","a");
	//fprintf(file,"g_NUMPLAN =%d RuleCount=%d index =%d\n",g_NUMPLAN,RuleCount,index);
	//fclose(file);

  /* Modify of NumPlan Rule */	
  for(i=0;i<index && i<IFX_VMAPI_MAX_NUM_PLAN_RULES;i++)
  {
    memset(&xRule,0,sizeof(xRule));
    xRule.ucIndex = i+1;
    xRule.iid.config_owner = IFX_WEB;
	  iRet = ifx_get_NumPlanRule(&xRule,0);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("GET NUMPLANRULE FAILED\n"));
		  return ;
    }

		/* Making the names dynamically as Prefix1, Prefix2, Prefix3...and the like */
	  sprintf(buf1, "%d", i+1);
    strcpy(input_prefix,"Prefix");
    strcpy(input_ruleact,"RuleAct");
    strcpy(input_minlen,"MinLen");
    strcpy(input_maxlen,"MaxLen");
    strcpy(input_remdgts,"RemDgts");
    strcpy(input_posrem,"PosRem");
    strcpy(input_digins,"DigIns");
    strcpy(input_posins,"PosIns");
    strcpy(input_digrep,"DigRep");
    strcpy(input_posrep,"PosRep");
	  gstrcat(input_ruleact, buf1); 
	  gstrcat(input_prefix, buf1);
	  gstrcat(input_minlen, buf1);
	  gstrcat(input_maxlen, buf1);
	  gstrcat(input_remdgts, buf1);
	  gstrcat(input_posrem, buf1);
	  gstrcat(input_digins, buf1);
	  gstrcat(input_posins, buf1);
	  gstrcat(input_digrep, buf1);
	  gstrcat(input_posrep, buf1);
  
    char_t * pRuleAct = ifx_httpdGetVar (wp, input_ruleact, T (""));
    char_t * pPrefix = ifx_httpdGetVar (wp, input_prefix, T (""));
    char_t * pMinLen = ifx_httpdGetVar (wp, input_minlen, T (""));
    char_t * pMaxLen = ifx_httpdGetVar (wp, input_maxlen, T (""));
    char_t * pRemDgts = ifx_httpdGetVar (wp, input_remdgts, T (""));
    char_t * pPosRem = ifx_httpdGetVar (wp, input_posrem, T (""));
    char_t * pDigIns = ifx_httpdGetVar (wp, input_digins, T (""));
    char_t * pPosIns = ifx_httpdGetVar (wp, input_posins, T (""));
    char_t * pDigRep = ifx_httpdGetVar (wp, input_digrep, T (""));
    char_t * pPosRep = ifx_httpdGetVar (wp, input_posrep, T (""));

    if ((xRule.uiMainAct != atoi(pRuleAct)) || 
			 (gstrcmp (xRule.acPrefix,pPrefix)) || 
			 (xRule.ucMinDigits4Prefix != atoi(pMinLen)) || 
			 (xRule.ucMaxDigits4Prefix != atoi(pMaxLen)) || 
			 (xRule.ucNoOfDigits2bRem != atoi(pRemDgts)) || 
			 (xRule.ucPosDigits2bRem != atoi(pPosRem)))
		{
			xRule.uiMainAct = atoi(pRuleAct);	    
      gstrcpy (xRule.acPrefix, pPrefix);
			xRule.ucMinDigits4Prefix = atoi(pMinLen);	    
			xRule.ucMaxDigits4Prefix = atoi(pMaxLen);	    
			xRule.ucNoOfDigits2bRem = atoi(pRemDgts);	    
			xRule.ucPosDigits2bRem = atoi(pPosRem);	    
			xRule.cDigits2bIns = atoi(pDigIns);	    
			xRule.ucPosDigits2bIns = atoi(pPosIns);	    
			xRule.cDigits2bRep = atoi(pDigRep);	    
			xRule.ucPosDigits2bRep = atoi(pPosRep);	    

      xRule.iid.config_owner = IFX_WEB;
      iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xRule,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
      if (iRet != IFX_VMAPI_SUCCESS)
			{
        ifx_httpdError (wp, 200, T ("SET NUMPLANRULE FAILED\n"));
		    return ;
			}
			mod_flag = 1;
			iflag = 1;
		}
  } /*For loop*/

	/* Deletion of NumPlan Rule */
  pxRule = xNumPlan.pxNumPlanRules;
	if (RuleCount > g_NUMPLAN)
	{
		//for(k=i;k<RuleCount;k++)
		for(k=RuleCount;k>g_NUMPLAN;k--)
		{
			 if (pxRule == NULL)
				 break;
	     pxRule->ucIndex = k;
       pxRule->iid.config_owner  = IFX_WEB;
			 IFX_DBG("NumPlanSet Here 3 Value of K %d",k);

       iRet = ifx_set_NumPlanRule(IFX_OP_DEL,pxRule,0);
				IFX_DBG("NumPlanSet Here 4");
       if(iRet != IFX_VMAPI_SUCCESS)
       {
         ifx_httpdError (wp, 200, T ("Set for NumPlanRule Failed-DEL\n"));
         return ;
       }
 			 else
     	  	xNumPlan.ucNoOfNumPlanRules--;
          __ifx_list_GetNext((void *)&pxRule);
		}
			mod_flag = 1;
			iflag =0;
	}
	/*Addition of NumPlan Rule */
	else
	{
    for (j=RuleCount+1; j<=g_NUMPLAN && j<IFX_VMAPI_MAX_NUM_PLAN_RULES; j++)
    {

      memset(&xRuleAdd,0,sizeof(xRuleAdd));
	    sprintf(buf1, "%d", j);
      strcpy(input_prefix,"Prefix");
      strcpy(input_ruleact,"RuleAct");
      strcpy(input_minlen,"MinLen");
      strcpy(input_maxlen,"MaxLen");
      strcpy(input_remdgts,"RemDgts");
      strcpy(input_posrem,"PosRem");
      strcpy(input_digins,"DigIns");
      strcpy(input_posins,"PosIns");
      strcpy(input_digrep,"DigRep");
      strcpy(input_posrep,"PosRep");
	    gstrcat(input_ruleact, buf1);
	    gstrcat(input_prefix, buf1);
	    gstrcat(input_minlen, buf1);
	    gstrcat(input_maxlen, buf1);
	    gstrcat(input_remdgts, buf1);
	    gstrcat(input_posrem, buf1);
	    gstrcat(input_digins, buf1);
	    gstrcat(input_posins, buf1);
	    gstrcat(input_digrep, buf1);
	    gstrcat(input_posrep, buf1);

      char_t * pRuleAct = ifx_httpdGetVar (wp, input_ruleact, T (""));
      char_t * pPrefix = ifx_httpdGetVar (wp, input_prefix, T (""));
      char_t * pMinLen = ifx_httpdGetVar (wp, input_minlen, T (""));
      char_t * pMaxLen = ifx_httpdGetVar (wp, input_maxlen, T (""));
      char_t * pRemDgts = ifx_httpdGetVar (wp, input_remdgts, T (""));
      char_t * pPosRem = ifx_httpdGetVar (wp, input_posrem, T (""));
      char_t * pDigIns = ifx_httpdGetVar (wp, input_digins, T (""));
      char_t * pPosIns = ifx_httpdGetVar (wp, input_posins, T (""));
      char_t * pDigRep = ifx_httpdGetVar (wp, input_digrep, T (""));
      char_t * pPosRep = ifx_httpdGetVar (wp, input_posrep, T (""));

      if ((strlen(pPrefix) != 0) || 
					(strlen(pMinLen) != 0) || 
					(strlen(pMaxLen) != 0)|| 
					(strlen(pRemDgts) != 0) || 
					(strlen(pPosRem) != 0))
		  {
  		  xRuleAdd.uiMainAct = atoi(pRuleAct);	    
        gstrcpy (xRuleAdd.acPrefix, pPrefix);
			  xRuleAdd.ucMinDigits4Prefix = atoi(pMinLen);	    
			  xRuleAdd.ucMaxDigits4Prefix = atoi(pMaxLen);	    
			  xRuleAdd.ucNoOfDigits2bRem = atoi(pRemDgts);	    
			  xRuleAdd.ucPosDigits2bRem = atoi(pPosRem);	    
			  xRuleAdd.cDigits2bIns = atoi(pDigIns);	    
			  xRuleAdd.ucPosDigits2bIns = atoi(pPosIns);	    
			  xRuleAdd.cDigits2bRep = atoi(pDigRep);	    
			  xRuleAdd.ucPosDigits2bRep = atoi(pPosRep);	    

			  xRuleAdd.ucIndex = j;
        xRuleAdd.iid.config_owner = IFX_WEB;
			  if(IFX_VMAPI_SUCCESS == ifx_set_NumPlanRule(IFX_OP_ADD,&xRuleAdd,0))
        {
     	    xNumPlan.ucNoOfNumPlanRules++;
        }
			  else
			  {
          ifx_httpdError (wp, 200, T ("Set for NumPlanRule Failed-ADD\n"));
          return ;
			  }
		  }
	    mod_flag = 1;
	    iflag =0;

    }/* ADD for loop  */
	}

  uiTempNumPlanCnt = xNumPlan.ucNoOfNumPlanRules;
  ifx_vmapi_freeObjectList(&xNumPlan,IFX_VMAPI_VS_NUM_PLAN);

  /* Get the NumPlan object once again. Some NumPlanRules might have 
	   added or deleted earlier. So we need to get the correct list of
	   NumPlanRules once again. */	
  memset(&xNumPlan1,0,sizeof(xNumPlan1));
  xNumPlan1.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_NumPlan(&xNumPlan1,0))
  {
    ifx_httpdWrite (wp, T ("%s"), "GET NUMPLAN FAILED");
  }
	//xNumPlan1.ucInterdigTimerStd = atoi(pLongTmr);
	//xNumPlan1.ucInterdigTimerProg = atoi(pShortTmr);
  xNumPlan1.ucNoOfNumPlanRules = uiTempNumPlanCnt;

	/* NumPlanRule has not been modified or added or deleted. There is a 
	   change in the parent object NumPlan parameters only */
	if(mod_flag == 0)
	{
	  if(xNumPlan1.ucInterdigTimerStd != atoi(pLongTmr) ||
			 xNumPlan1.ucInterdigTimerProg != atoi(pShortTmr))
		{
	    xNumPlan1.ucInterdigTimerStd = atoi(pLongTmr);
	    xNumPlan1.ucInterdigTimerProg = atoi(pShortTmr);
      iRet = ifx_set_NumPlan(IFX_OP_MOD,&xNumPlan1,0);				
		}
		/*else
		{
      iRet = ifx_set_NumPlan(IFX_OP_MOD,&xNumPlan1,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
		}*/
	}
	else if(mod_flag == 1 && iflag == 1) /* this time only modification */
	{
		if(xNumPlan1.ucInterdigTimerStd != atoi(pLongTmr) ||
			 xNumPlan1.ucInterdigTimerProg != atoi(pShortTmr))
		{
	    xNumPlan1.ucInterdigTimerStd = atoi(pLongTmr);
	    xNumPlan1.ucInterdigTimerProg = atoi(pShortTmr);
      iRet = ifx_set_NumPlan(IFX_OP_MOD,&xNumPlan1,0);				
		}
		else
		{
		  /* SET happend earlier . We need send a notification for the parent object */
  	  iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xRule,
											IFX_VMAPI_SEND_NOTIFY_FORCEFULLY_TO_THIS_OBJ);
		}
  }
	else
	{
	  xNumPlan1.ucInterdigTimerStd = atoi(pLongTmr);
	  xNumPlan1.ucInterdigTimerProg = atoi(pShortTmr);
		
    iRet = ifx_set_NumPlan(IFX_OP_MOD,&xNumPlan1,0);
	}
	
	if (iRet != IFX_VMAPI_SUCCESS)
	{
    ifx_httpdWrite (wp, T ("%s"), "SET NUMPLAN FAILED");
	}
  ifx_vmapi_freeObjectList(&xNumPlan1,IFX_VMAPI_VS_NUM_PLAN);
f_cflag=0;	
  ifx_httpdNextPage_New(wp);
}

