/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_system.c
 *        Abstract: To initialise the rc.conf existing entries
 *        Date    : 17/05/07
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------


 ************************************************************************/
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_vmapi_cpeid.h"

int NUMflag;
int FXSflag;
int FXOflag;
extern int g_LINE_ID_IS;
extern int g_PROFILE_ID_IS;

/*****************************************************************************
 *  Function Name   : ifx_get_voip_webinit
 *  Description     :
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : To initialize the FXS and NumPlan existing in the rc.conf
 ****************************************************************************/ 
int32
ifx_get_voip_webinit (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
	//int32 i=0;
	int32 iRet=0;
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 400, T ("Insufficient args\n"));
    return IFX_VMAPI_FAIL;
  }

  /* To update the CpeIds for existing NumPlanRules, FXS and FXO endpoints when the VoIP link is clicked*/
  if (!gstrcmp(name,"initialize"))
  {
  x_IFX_VMAPI_VoiceService xVS;
#if 0 
  x_IFX_VMAPI_NumPlanRule xNumRule; 
  x_IFX_VMAPI_FxoPhyIf xFXO;
  x_IFX_VMAPI_FxsPhyIf xFXS;

  memset(&xNumRule,0,sizeof(xNumRule)); 
  if (NUMflag == 0)
	{
		xNumRule.ucIndex = 1;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES,&xNumRule,1);
		IFX_VMAPI_Update_CpeId_opt("NumPlanRules_CpeId",xNumRule.ucIndex,1);
		xNumRule.ucIndex = 2;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES,&xNumRule,2);
		IFX_VMAPI_Update_CpeId_opt("NumPlanRules_CpeId",xNumRule.ucIndex,2);
    xNumRule.ucIndex = 3;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES,&xNumRule,3);
		IFX_VMAPI_Update_CpeId_opt("NumPlanRules_CpeId",xNumRule.ucIndex,3);
    xNumRule.ucIndex = 4;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES,&xNumRule,4);
		IFX_VMAPI_Update_CpeId_opt("NumPlanRules_CpeId",xNumRule.ucIndex,4);

		NUMflag = 1;
	}

  memset(&xFXS,0,sizeof(xFXS)); 
  if(FXSflag == 0)
  {
		xFXS.xVoiceServPhyIf.ucInterfaceId = 1;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_PHY_IFACE_FXS,&xFXS,1);
		IFX_VMAPI_Update_CpeId_opt("FxsphyInterface_CpeId",xFXS.xVoiceServPhyIf.ucInterfaceId,1);
		xFXS.xVoiceServPhyIf.ucInterfaceId = 2;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_PHY_IFACE_FXS,&xFXS,2);
		IFX_VMAPI_Update_CpeId_opt("FxsphyInterface_CpeId",xFXS.xVoiceServPhyIf.ucInterfaceId,2);
		FXSflag = 1;
  }
  memset(&xFXO,0,sizeof(xFXO)); 
  if(FXOflag == 0)
  {
		xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
		//IFX_VMAPI_Update_CpeId(IFX_VMAPI_PHY_IFACE_FXO,&xFXO,3);
		IFX_VMAPI_Update_CpeId_opt("FxophyInterface_CpeId",(xFXO.xVoiceServPhyIf.ucInterfaceId-2),3);
		FXOflag = 1;
  }
#endif
	memset(&xVS,0,sizeof(xVS)); 
	xVS.iid.config_owner = IFX_WEB;
  iRet=ifx_get_VoiceService(&xVS,0);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Voice Service\n"));
    return IFX_VMAPI_FAIL ;
  }
	g_LINE_ID_IS = xVS.ucLineIdList[0];
	g_PROFILE_ID_IS = xVS.ucProfileIdList[0];

	}

  return 0;
}

int32 ifx_get_time_zone(){
 
 IFX_VMAPI_SendNotifyForRegObject(IFX_DUMMY_TZ_CHANGE,NULL,NULL);
 return 0;
}
