/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_cr.c
 *        Abstract: CGI API's to Access Call Register settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include <unistd.h>
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"



char8 misscall_disp[10][260];
char8 dialcall_disp[10][260];
char8 recvcall_disp[10][260];

extern int g_LINE_ID_IS;

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_cr_miss
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_cr_miss (httpd_t wp) 
{
  
  int32 i=0;
	//int32 iRet;
  x_IFX_VMAPI_MissCallRegister xMissMsg;
  x_IFX_VMAPI_MissCallRegEntry *pxTemp;

  memset(&xMissMsg,0,sizeof(xMissMsg));

  xMissMsg.ucLineId = g_LINE_ID_IS;
  xMissMsg.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xMissMsg,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the MissCallReg  !!!");
    return -1;
  }


  pxTemp = xMissMsg.pxCallRegEntries;
  memset(&misscall_disp,0, sizeof(misscall_disp)); 

  if((pxTemp == NULL) || (xMissMsg.ucNoOfEntries == 0))
    return -1;

  do{
		  /* Previous of the HeadPtr is pointing to the last entry of the linked list
		   That should be thr first entry in this case. */
      __ifx_list_GetPrev((void *)&pxTemp);

			if (pxTemp == NULL)
  		{
    		break;
  		}
      	if((pxTemp->xAddress.ucAddrType == IFX_IP_ADDR)||
                        (pxTemp->xAddress.ucAddrType ==IFX_SIP_URL ))
      {
				/*if(pxTemp->xAddress.acUserName[0])
				{
				}*/
        sprintf(misscall_disp[i],"%s/%s\n %s<%s@%s>",
                        pxTemp->acCallDate,
                        pxTemp->acCallTime, 
                        pxTemp->xAddress.acDisplayName,
                        pxTemp->xAddress.acUserName,
                        pxTemp->xAddress.acDestAddr);
      }
      else
      {
        sprintf(misscall_disp[i],"%s/%s\n %s",
                        pxTemp->acCallDate,
                        pxTemp->acCallTime, 
                        pxTemp->xAddress.acDisplayName);
                        
      }
      i++;
  }while (pxTemp != xMissMsg.pxCallRegEntries);
	
  ifx_vmapi_freeObjectList(&xMissMsg,IFX_VMAPI_VS_MISSCALL_REGISTER);
  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_cr_recv
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_cr_recv (httpd_t wp) 
{
  
  int32 i=0;
  int32 iRet;

  x_IFX_VMAPI_RecvCallRegister xRecvMsg;
  x_IFX_VMAPI_RecvCallRegEntry *pxTemp;

  memset(&xRecvMsg,0,sizeof(xRecvMsg));
  xRecvMsg.ucLineId = g_LINE_ID_IS;
  xRecvMsg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_RecvCallReg(&xRecvMsg,0);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, "Fail to GET the RecvCallReg  !!!");
    return -1;
  }

  pxTemp = xRecvMsg.pxCallRegEntries;
  memset(&recvcall_disp,0, sizeof(recvcall_disp)); 
  if((pxTemp == NULL) || (xRecvMsg.ucNoOfEntries == 0))
    return -1;

  do{
		/* Previous of the HeadPtr is pointing to the last entry of the linked list
		   That should be thr first entry in this case. */
    __ifx_list_GetPrev((void *)&pxTemp);
			if (pxTemp == NULL)
  		{
    		break;
  		}
    	if((pxTemp->xAddress.ucAddrType == IFX_IP_ADDR)||
                    (pxTemp->xAddress.ucAddrType ==IFX_SIP_URL ))
    {
      sprintf(recvcall_disp[i],"%s/%s\n %s<%s@%s>",
                        pxTemp->acCallDate,
                        pxTemp->acCallTime, 
                        pxTemp->xAddress.acDisplayName,
                        pxTemp->xAddress.acUserName,
                        pxTemp->xAddress.acDestAddr);
    }
    else
    {
      sprintf(recvcall_disp[i],"%s/%s\n %s",
                        pxTemp->acCallDate,
                        pxTemp->acCallTime, 
                        pxTemp->xAddress.acDisplayName);
                        
    }
    i++;
  }while (pxTemp != xRecvMsg.pxCallRegEntries);

  ifx_vmapi_freeObjectList(&xRecvMsg,IFX_VMAPI_VS_RECVCALL_REGISTER);
    return 0;
}
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_cr_dial
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 

int
ifx_get_voip_sip_cr_dial (httpd_t wp) 
{
  
  int32 i=0;
	int32 iRet;
  x_IFX_VMAPI_DialCallRegister xDialMsg;
  x_IFX_VMAPI_DialCallRegEntry *pxTempDial;

  memset(&xDialMsg,0,sizeof(xDialMsg));
  xDialMsg.ucLineId = g_LINE_ID_IS;
  xDialMsg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DialCallReg(&xDialMsg,0);
  if (iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, "Fail to GET the DialCallReg  !!!");
    return -1;
  }
  pxTempDial = xDialMsg.pxCallRegEntries;
  memset(&dialcall_disp,0, sizeof(dialcall_disp)); 
  if((pxTempDial == NULL)||(xDialMsg.ucNoOfEntries==0))
    return -1;
  do{
		/* Previous of the HeadPtr is pointing to the last entry of the linked list
		   That should be thr first entry in this case. */
    __ifx_list_GetPrev((void *)&pxTempDial);
			if (pxTempDial == NULL)
  		{
    		break;
  		}
    	if((pxTempDial->xAddress.ucAddrType == IFX_IP_ADDR)||
                    (pxTempDial->xAddress.ucAddrType ==IFX_SIP_URL ))
    {
      sprintf(dialcall_disp[i],"%s/%s\n %s<%s@%s>",
                        pxTempDial->acCallDate,
                        pxTempDial->acCallTime, 
                        pxTempDial->xAddress.acDisplayName,
                        pxTempDial->xAddress.acUserName,
                        pxTempDial->xAddress.acDestAddr);
    }
    else
    {
      sprintf(dialcall_disp[i],"%s/%s\n %s",
                        pxTempDial->acCallDate,
                        pxTempDial->acCallTime, 
                        (pxTempDial->xAddress.acDisplayName[0] != '\0')?
													pxTempDial->xAddress.acDisplayName:pxTempDial->xAddress.acUserName);
                        
    }
    i++;
  }while (pxTempDial != xDialMsg.pxCallRegEntries);

  ifx_vmapi_freeObjectList(&xDialMsg,IFX_VMAPI_VS_DIALCALL_REGISTER);
    return 0;
}
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_cr
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_cr (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  
  char8 *name;
  int32 i;

 
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  ifx_get_voip_sip_cr_dial (wp);
  ifx_get_voip_sip_cr_miss (wp); 
  ifx_get_voip_sip_cr_recv (wp);
  
  if (!gstrcmp (name, T ("cr")))
  {
      /*print from write index to read index*/       
      for(i=0;i<IFX_MAX_CR_ENTRIES;i++)
      {
        ifx_httpdWrite (wp, "<tr >");
        ifx_httpdWrite (wp, "<td align=\"center\" width=\"30%\" ><font class=\"A:link\">");
        ifx_httpdWrite (wp,T("%s"),misscall_disp[i]);
        ifx_httpdWrite (wp, "</font>");
        ifx_httpdWrite (wp, "</td>");
        ifx_httpdWrite (wp, "<td align=\"center\" width=\"30%\" ><font class=\"A:link\">");
        ifx_httpdWrite (wp,T("%s"),recvcall_disp[i]);
        ifx_httpdWrite (wp, "</font>");
        ifx_httpdWrite (wp, "</td>");
        ifx_httpdWrite (wp, "<td align=\"center\" width=\"30%\" ><font class=\"A:link\">");
        ifx_httpdWrite (wp,T("%s"),dialcall_disp[i]);
        ifx_httpdWrite (wp, "</font>");
        ifx_httpdWrite (wp, "</td>");
        ifx_httpdWrite (wp, "</tr >");
      }
  } 
  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_cr
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    :
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_cr (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pmisscall = ifx_httpdGetVar (wp, T ("misscall"), T (""));
  char_t * precvcall = ifx_httpdGetVar (wp, T ("recvcall"), T (""));
  char_t * pdialcall = ifx_httpdGetVar (wp, T ("dialcall"), T (""));
  char_t * pdelall = ifx_httpdGetVar (wp, T ("delall"), T (""));
 

  if (gatoi (pdialcall) == 1 || gatoi(pdelall) == 1) /* Pressed Dialled Call Delete button */
  {
   if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_DIALCALL_REGISTER,g_LINE_ID_IS) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the DialCall  !!!");
        return;
    }
  
	}
  if (gatoi(pmisscall) == 1 || gatoi(pdelall) == 1) /* Pressed Missed Call Delete button */
  {
		if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_MISSCALL_REGISTER,g_LINE_ID_IS) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the MissCall  !!!");
        return;
    }
  }

  if (gatoi(precvcall) == 1 || gatoi(pdelall) == 1) /* Pressed Received Call Delete button */
  {
   if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_RECVCALL_REGISTER,g_LINE_ID_IS) != IFX_VMAPI_SUCCESS)
    {
        ifx_httpdError (wp, 200, "Fail to Delte the MissCall  !!!");
        return;
    }
	}
  
  ifx_httpdNextPage_New(wp);
}
