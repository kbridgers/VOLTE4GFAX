/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : WAM( WEB ADAPTATION MODULE )
 *        Block   :  
 *        Creator : Purnendu Ghosh 
 *        File    : ifx_src_gr909lt_testresult.c
 *        Abstract: CGI API's to GR909 Line Testing params
 *        Date    : 18-04-2008
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           Purnendu Ghosh     24-04-08 1.0     Initial Dev.
 ************************************************************************/  

#include <signal.h>
#include <sys/time.h>
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

/* Extern Declarations */
EXTERN  char_t gcFXSLineId_UnderTest;	

/* Flag indicating Test Status.
 * Can take the value specified by
 * e_IFX_WAM_TestStatus 
 */
EXTERN char_t gcTestStatus;

/* Approximate time for testing */
EXTERN uint32  guiTestExp_Timer;

STATIC  char_t f_cflag;
STATIC x_IFX_VMAPI_VoiceServTestResult xtestRes;
STATIC x_IFX_VMAPI_VoiceServPhyIfTest xTestCfg;

/*****************************************************************************
 *  Function Name   : ifx_get_gr909lt_testresult
 *  Description     : This function is called while loading 
 *                  : gr909lt_testresult.asp
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
  int
ifx_get_gr909lt_testresult (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t *name, *mode;
  //int32  iRet;
  //char_t sValue[MAX_DATA_LEN];
 
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
	
  if( f_cflag == 0 )
  {
    /* Reset the flag gcTestStatus */
    gcTestStatus = IFX_WAM_TEST_STATUS_NONE;

    /* Reset the Timer value */
    guiTestExp_Timer = 0;

    /* Stop the timer which was started in web server side after 
     * starting the line testing.
     * Control reaching at this point implicit that timer started at 
     * web client side is fired.so we should stop the timer which is
     * on in web server side.
     */
    /* Stop the timer */
    {
  	  struct itimerval value;

	    memset(&value,0,sizeof(struct itimerval));
	    value.it_value.tv_sec = 0;

	    if(setitimer(ITIMER_REAL,&value,NULL)== -1)
	    {
		    perror("setitimer");
		    return -1;
	    }
    }

    /* Get the test status */
  	memset( &xTestCfg,0, sizeof(x_IFX_VMAPI_VoiceServPhyIfTest));
    if(IFX_VMAPI_SUCCESS != ifx_get_PhyInterfaceTest(&xTestCfg , IFX_F_DEFAULT))
    {
       ifx_httpdError (wp, 200, T ("Fail to get the test config"));
       return -1;
    }
    /* Get the test result */
    memset ( &xtestRes, 0, sizeof(x_IFX_VMAPI_VoiceServTestResult));
    if(IFX_VMAPI_SUCCESS != ifx_get_PhyInterfaceTestResult(&xtestRes ,IFX_F_DEFAULT))
    {
       ifx_httpdError (wp, 200, T ("Fail to get the test results"));
       return -1;
    }
    f_cflag = 0;
  }

  if (!gstrcmp (name, T ("channelnum")))
  {
    /* First FXS Line was under Test ,so get the result for the same */
    if( gcFXSLineId_UnderTest == IFX_WAM_FXSLINE_FIRST )
    {
	    ifx_httpdWrite (wp, "GR-909 Tests for Channel # 1");
    }
    /* Second FXS Line was under Test ,so get the result for the same */
    else if( gcFXSLineId_UnderTest == IFX_WAM_FXSLINE_SECOND )
    {
	    ifx_httpdWrite (wp, "GR-909 Tests for Channel # 2");
    }
    else {}
  }

  if (!gstrcmp (name, T ("status")))
  {
    if(xTestCfg.ucTestState == IFX_VMAPI_TEST_STATE_FAILURE)
    {
      ifx_httpdWrite(wp, T("%s"), "FAILED");
    }
    if(xTestCfg.ucTestState == IFX_VMAPI_TEST_STATE_SUCCESS)
    {
      ifx_httpdWrite(wp, T("%s"), "PASSED");
    }
    if(xTestCfg.ucTestState == IFX_VMAPI_TEST_STATE_IN_PROGRESS)
    {
      ifx_httpdWrite(wp, T("%s"), "PENDING");
    }
    /*if(xTestCfg.ucTestState == IFX_VMAPI_TEST_STATE_STOPED)
    {
      ifx_httpdWrite(wp, T("%s"), "NONE");
    }*/
  }

  /* HPT results */
  else if (!gstrcmp (name, T ("hpt_ac_r2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909HPTVoltResult.facr2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("hpt_ac_t2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909HPTVoltResult.fact2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("hpt_ac_t2r")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909HPTVoltResult.fact2r);
    return 0;
  }
  else if (!gstrcmp (name, T ("hpt_dc_r2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909HPTVoltResult.fdcr2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("hpt_dc_t2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909HPTVoltResult.fdcr2g);
    return 0;
  }
  /* FEMF results */
  else if (!gstrcmp (name, T ("femf_ac_r2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909FEMFVoltResult.facr2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("femf_ac_t2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909FEMFVoltResult.fact2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("femf_ac_t2r")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909FEMFVoltResult.fact2r);
    return 0;
  }
  else if (!gstrcmp (name, T ("femf_dc_r2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909FEMFVoltResult.fdcr2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("femf_dc_t2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909FEMFVoltResult.fdcr2g);
    return 0;
  }
  /* RFT results */
  else if (!gstrcmp (name, T ("rft_r2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909RFTResult.fr2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("rft_t2g")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909RFTResult.ft2g);
    return 0;
  }
  else if (!gstrcmp (name, T ("rft_t2r")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909RFTResult.ft2r);
    return 0;
  }
  /* ROH results */
  else if (!gstrcmp (name, T ("roh_t2r_l")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909ROHResult.ft2rl);
    return 0;
  }
  /* RI results */
  else if (!gstrcmp (name, T ("rit_res")))
  {
    ifx_httpdWrite(wp, T("%f"), xtestRes.xGr909RIResult.fRit);
    f_cflag=0;
  }

  return 0;
} /* ifx_get_gr909lt_testresult() */


