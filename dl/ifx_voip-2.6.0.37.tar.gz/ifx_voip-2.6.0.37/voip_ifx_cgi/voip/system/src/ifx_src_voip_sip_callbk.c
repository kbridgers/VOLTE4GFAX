/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module 
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_callbk.c
 *        Abstract: CGI API's to Access Call Block settings
 *        Date    : 17-04-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

static int16 nNoOfCallBlockEntries;
static char_t f_cflag;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_callbk
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_callbk (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  int32  count = 0;
  int32 nIndex = 0;
  char_t sValue[MAX_DATA_LEN];
  static x_IFX_VMAPI_CallBlock xCallbk;
  x_IFX_VMAPI_CallBlockEntry *pxTemp;
 
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
  
  if(f_cflag == 0){
	memset(&xCallbk,0,sizeof(xCallbk));

  if (IFX_VMAPI_SUCCESS != ifx_get_CallBlock(&xCallbk,0))
  {
      ifx_httpdError (wp, 200, "Fail to GET the CallBlock !!!");
      return -1;
  }
  /* Assigning a variable to the number of call block entries to check for validations*/
  nNoOfCallBlockEntries = xCallbk.uiNumCallBlockEntries;
	f_cflag = 1;	
	}
  if (!gstrcmp (name, T ("callbar")))
  {
      uint32 ucValue = xCallbk.bCallBar  ;
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
      }
		f_cflag = 0;	
  	ifx_vmapi_freeObjectList(&xCallbk,IFX_VMAPI_VS_CALL_BLOCK);
			return 0;
  }

  /* To diaplay the Call Block List already existing*/
  if (!gstrcmp (name, T ("updateData")))
  {
       pxTemp = xCallbk.pxCallBlockList;
       while (pxTemp !=NULL) 
       {
    	      ifx_httpdWrite (wp, T ( "getTheCallList(\"%s\",\"%s\");\n"),
                            pxTemp->acCallBlockNum,
                            pxTemp->acCallBlockNum);
                         
           __ifx_list_GetNext((void *)&pxTemp);
           count ++;
       } 
		return 0;
  }
  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_callbk
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/ 
void
ifx_set_voip_sip_callbk (httpd_t wp, char_t * path, char_t * query) 
{
  
  char_t * pPCallBlockString = ifx_httpdGetVar (wp, T ("pCallBlockString"), T (""));
  char_t * pCallbar = ifx_httpdGetVar (wp, T ("callbar"), T (""));
 
  int32 index = 0;
  uchar8 pucCallBlockList[20][IFX_VMAPI_MAX_USER_NAME_LEN];
  uchar8 ucNoofCall =0;
 	
  int32 i=0,j=0,count=0;
  x_IFX_VMAPI_CallBlock xCallbk;
  x_IFX_VMAPI_CallBlockEntry xCallbkEntry, xCallbkEntryAdd;

  memset(&xCallbk,0,sizeof(xCallbk));
  xCallbk.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_CallBlock(&xCallbk,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the CallBlock !!!");
    return;
  }

  xCallbk.bCallBar = atoi (pCallbar);

  memset (&pucCallBlockList[0][0], 0, sizeof (pucCallBlockList));

  if((*pPCallBlockString == ' ') || (*pPCallBlockString == '\0') )
  {
    pPCallBlockString = NULL;
  }

  if (pPCallBlockString != NULL)
  {
    ifx_ParseString ((uchar8 *)pPCallBlockString, &pucCallBlockList[0][0],
                                   &ucNoofCall);
  }

  /* Number Of CallBlockEntries before any opeartion */
  count = xCallbk.uiNumCallBlockEntries;
 
  if( count < ucNoofCall)
  {
    j = count;
  }
  else
  {
    j = ucNoofCall;
  }

			
  /* To Modify the Call Block Entry already existing*/
  for (index = 0; index < j; index++)
  {
    memset(&xCallbkEntry,0,sizeof(xCallbkEntry));
    xCallbkEntry.ucIndex = index+1;
    xCallbkEntry.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_CallBlockEntry(&xCallbkEntry,0))
    {
      ifx_httpdError (wp, 200, "Fail to GET the CallBlockEntry !!!");
      return;
    }

    gstrcpy(xCallbkEntry.acCallBlockNum,(char8 *)pucCallBlockList[index]);
			
    if(IFX_VMAPI_SUCCESS != ifx_set_CallBlockEntry(IFX_OP_MOD,&xCallbkEntry,0))
    {
      ifx_httpdError (wp, 200, "Fail to Modify the CallBlockEntry !!!");
      return;
    }
  } 


  /* To ADD the Call Block entry */
  if( ucNoofCall > count)
  {
		/* Check if number of call block entries exceeding maximum or not*/
    if (nNoOfCallBlockEntries == IFX_VMAPI_MAX_CALL_BLK_ENTRIES)
    {
      ifx_httpdError (wp, 200,T(
                 "Max Call Block Entries exceeded, Cannot add more!!!"));
      return;
    }
    for (j=count+1; j <= ucNoofCall; j++)
    {
       memset(&xCallbkEntryAdd,0,sizeof(xCallbkEntryAdd));

       gstrcpy(xCallbkEntryAdd.acCallBlockNum,(char8 *)pucCallBlockList[j-1]);
			
       xCallbkEntryAdd.iid.config_owner = IFX_WEB;
       xCallbkEntryAdd.ucIndex = j;
       if(IFX_VMAPI_SUCCESS != ifx_set_CallBlockEntry(IFX_OP_ADD,&xCallbkEntryAdd,0))
			 {
         ifx_httpdError (wp, 200, "Fail to ADD the CallBlockEntry !!!");
         return;
			 }
			 else {
         xCallbk.uiNumCallBlockEntries += 1;
			 }
    }
  }

  /* To delete the Call Block entry*/
  if(ucNoofCall < count)
  {
    for(i=index;i<count;i++)
    {
      memset(&xCallbkEntry,0,sizeof(xCallbkEntry));
      xCallbkEntry.ucIndex = index+1;
      xCallbk.uiNumCallBlockEntries -= 1;
       xCallbkEntry.iid.config_owner = IFX_WEB;
      if(IFX_VMAPI_SUCCESS != ifx_set_CallBlockEntry(IFX_OP_DEL,&xCallbkEntry,0))
      {
        ifx_httpdError (wp, 200, "Fail to DEL the CallBlockEntry !!!");
        return;
      }
    }
  }
	
	/*Since it is a system object, no Profile / Line Id is required */
  if(IFX_VMAPI_SUCCESS != ifx_set_CallBlock(IFX_OP_MOD,&xCallbk,0))
  {
    ifx_httpdError (wp, 200, "Fail to SET the CallBlock !!!");
    return;
  }
  /*freeObjectList is used to clear the memory allocated by the parent object - Call Block */ 
  ifx_vmapi_freeObjectList(&xCallbk,IFX_VMAPI_VS_CALL_BLOCK);
	f_cflag = 0;	
  ifx_httpdNextPage_New(wp);

}

