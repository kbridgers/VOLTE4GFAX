/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ltq_src_sensorsytem.c
 *        Abstract: CGI API's to Access DECT Settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

#ifdef DECT_SENSORS_SUPPORT
//#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
static char_t f_cflag;
extern int g_SENSOR_CPEID;
extern int g_SENSOR_TYPE;
extern int g_SENSOR_LIST_TYPE;
extern int g_SENSOR_READ_LIST;

static char acSensorType[25];
static x_LTQ_VMAPI_SensorList_Entry xSensor;
static x_LTQ_VMAPI_SensorAlaram_List xSensorAlaramList;
static x_LTQ_VMAPI_SensorList xSensorList;
static x_LTQ_VMAPI_PowerSensor_Entry xPowerSensor;
static x_LTQ_VMAPI_PowerSensor_List xPowerSensorList;
static x_LTQ_VMAPI_PowerSensor_ReadList xSensorReadList;
//x_LTQ_VMAPI_PowerSensor_ReadEntry *pxPowTemp=NULL;

/*****************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
void
ltq_set_sensortype (httpd_t wp, char_t * path, char_t * query)
{
  char_t * pSensortype = ifx_httpdGetVar (wp, T ("sentype"), T (""));

	switch(atoi(pSensortype)){
  case 1:
	{
		strcpy(acSensorType, "Smoke Sensor(s)");
		g_SENSOR_TYPE=IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY;
		g_SENSOR_LIST_TYPE=IFX_VMAPI_VS_SMOKE_SENSOR_LIST;
		g_SENSOR_READ_LIST=IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST;
  }
	break;  
  case 2:
  {
		strcpy(acSensorType, "Motion Sensor(s)");
		g_SENSOR_TYPE=IFX_VMAPI_VS_MOTION_SENSOR_ENTRY;
		g_SENSOR_LIST_TYPE=IFX_VMAPI_VS_MOTION_SENSOR_LIST;
		g_SENSOR_READ_LIST=IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST;
  }
	break;  
  case 3:
  {
		strcpy(acSensorType, "Power Sensor(s)");
		g_SENSOR_TYPE=IFX_VMAPI_VS_POWER_SENSOR_ENTRY;
		g_SENSOR_LIST_TYPE=IFX_VMAPI_VS_POWER_SENSOR_LIST;
		g_SENSOR_READ_LIST=IFX_VMAPI_VS_POWER_SENSOR_READ_LIST;
  }
	break;
}
  f_cflag=0;
  ifx_httpdNextPage (wp);
}


int32 ltq_get_sensorlist (int eid, httpd_t wp, int argc, char_t ** argv)
{
 char_t * name, *mode;
x_LTQ_VMAPI_SensorList_Entry *pxTemp=NULL;
x_LTQ_VMAPI_PowerSensor_Entry *pxTemp1=NULL;
int i=0;
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

switch(g_SENSOR_LIST_TYPE){
			case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
			case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
					if(f_cflag == 0){
							memset(&xSensorList,0,sizeof(xSensorList));
							xSensorList.iid.config_owner = IFX_WEB;
							if(LTQ_get_SensorList((void *)&xSensorList,g_SENSOR_LIST_TYPE,0) != IFX_VMAPI_SUCCESS){
    								ifx_httpdError (wp, 200, T ("Error getting smoke/motiong sensorlist \n"));
								    return IFX_FAILURE;
						  }
						f_cflag = 1;
					}
  					 if (!gstrcmp (name, T ("sensortype")))
  						{			
										ifx_httpdWrite(wp, T("%s"), acSensorType);
							}
							
  					 else if (!gstrcmp (name, T ("psetnum")))
  						{			
										ifx_httpdWrite(wp, T("%s"), xSensorList.ucPresetNum);
							}
  						else if (!gstrcmp (name, T ("allon")))
						  {
												if(xSensorList.bAllPowerOn == 1)
														ifx_httpdWrite(wp, T("checked") );
							}
  						else if (!gstrcmp (name, T ("talaram")))
						  {
												if(xSensorList.bToneAlaram == 1)
														ifx_httpdWrite(wp, T("checked") );
							}
  						else if (!gstrcmp (name, T ("all")))
						  {
									if(xSensorList.ucNoOfEntries > 0){
											pxTemp=xSensorList.pxSensorEntries;
											i = 1;
											while(pxTemp !=NULL)
									    {
														ifx_httpdWrite(wp, T("<tr><td>%d</td> <td>%s</td>	<td>%s</td> <td>%s</td>	<td><input type=\"radio\" name=\"sensorid\" id=\"sensorid\" onclick=setSensorInfo(\"%d\");></td></tr>"), i,pxTemp->xSensorInfo.acSensorName,(pxTemp->xSensorInfo.bRegStatus == 1)?"Registered":"Not Registered",(pxTemp->xSensorInfo.bPowerStatus==1)?"ON":"OFF", pxTemp->iid.cpeId.Id);
										      __ifx_list_GetNext((void *)&pxTemp);
														i++;
									    }				


									}else{
														ifx_httpdWrite(wp, T("---- NILL ----") );
												}
									f_cflag = 0;
							}
						break;
			
			case IFX_VMAPI_VS_POWER_SENSOR_LIST:
					if(f_cflag == 0){
						memset(&xPowerSensorList,0,sizeof(xPowerSensorList));
						xPowerSensorList.iid.config_owner = IFX_WEB;
						if(LTQ_get_SensorList((void*)&xPowerSensorList,IFX_VMAPI_VS_POWER_SENSOR_LIST,0) != IFX_VMAPI_SUCCESS){
    								ifx_httpdError (wp, 200, T ("Error getting power sensorlist \n"));
								    return IFX_FAILURE;
					  }
						f_cflag = 1;
					}
  					 if (!gstrcmp (name, T ("sensortype")))
  						{			
										ifx_httpdWrite(wp, T("%s"), acSensorType);
							}
  						else if (!gstrcmp (name, T ("allon")))
						  {
												if(xPowerSensorList.bAllPowerOn == 1)
														ifx_httpdWrite(wp, T("checked") );
							}
						else if (!gstrcmp (name, T ("all")))
              {
                  if(xPowerSensorList.ucNoOfEntries > 0){
                      pxTemp1=xPowerSensorList.pxSensorEntries;
                      i = 1;
                      while(pxTemp1 !=NULL)
                      {
                            ifx_httpdWrite(wp, T("<tr><td>%d</td> <td>%s</td> <td>%s</td> <td>%s</td> <td><input type=\"radio\" name=\"sensorid\" id=\"sensorid\" onclick=setSensorInfo(\"%d\");></td></tr>"), i,pxTemp1->xSensorInfo.acSensorName,(pxTemp1->xSensorInfo.bRegStatus == 1)?"Registered":"Not Registered",(pxTemp1->xSensorInfo.bPowerStatus==1)?"ON":"OFF", pxTemp1->iid.cpeId.Id);
                          __ifx_list_GetNext((void *)&pxTemp1);
                            i++;
                      }


                  }else{
                            ifx_httpdWrite(wp, T("<Tr><td colspan=\"4\">---- NILL ----</td></th>") );
                        }
                  f_cflag = 0;
              }	
			break;
}
return 0;
}


int32 ltq_get_sensor(int eid, httpd_t wp, int argc, char_t ** argv)
{
int i=0;
char_t * name, *mode;
uint32 uiParam[3]={0};
x_LTQ_VMAPI_SensorAlaram_Entry *pxTemp = NULL;
x_LTQ_VMAPI_PowerSensor_ReadEntry *pxTemp1 = NULL;
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
switch(g_SENSOR_TYPE){
			case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
			case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
					if(f_cflag == 0){
							memset(&xSensor,0,sizeof(xSensor));
							xSensor.iid.config_owner = IFX_WEB;
							xSensor.iid.cpeId.Id = g_SENSOR_CPEID;
							if(LTQ_get_SensorEntry((void*)&xSensor,g_SENSOR_TYPE,0) != IFX_VMAPI_SUCCESS){
									    printf("Error while Getting the Smoke  Sensor Entry.....\n");
									    return IFX_FAILURE;
								}
								memset(&xSensorAlaramList,0,sizeof(xSensorAlaramList));
							  xSensorAlaramList.iid.config_owner = IFX_WEB;
							  xSensorAlaramList.uiSensorId = g_SENSOR_CPEID;
							  if(LTQ_get_SensorAlaramList((void*)&xSensorAlaramList,g_SENSOR_READ_LIST,0) != IFX_VMAPI_SUCCESS){
							      printf("Error Getting an Smoke SensorAlaramList  \n");
							      return IFX_FAILURE;
					  		}
									f_cflag = 1;
						}
				  if (!gstrcmp (name, T ("regstatuscode")))
				  {
									ifx_httpdWrite(wp,T("%d"),xSensor.xSensorInfo.bRegStatus);			
					}
				  else if (!gstrcmp (name, T ("alaramcount")))
				  {
									ifx_httpdWrite(wp,T("%d"),xSensorAlaramList.ucNoOfEntries);			
					}
				  else if (!gstrcmp (name, T ("sname")))
				  {
									ifx_httpdWrite(wp,T("%s"),xSensor.xSensorInfo.acSensorName);			
					}
					else if (!gstrcmp (name, T ("regstatus")))
          {
									ifx_httpdWrite(wp,("%s"),(xSensor.xSensorInfo.bRegStatus == 1)?"Registered":"Not Registered");
          } 
					else if (!gstrcmp (name, T ("batstatus")))
          {
									ifx_httpdWrite(wp,("%d %"),xSensor.uiBatteryLevel);
          } 
					else if (!gstrcmp (name, T ("pstatus")))
          {
									if(xSensor.xSensorInfo.bPowerStatus == 1){
									ifx_httpdWrite(wp,("<option value=\"0\"> OFF </option> <option value=\"1\" selected> ON </option>"));
									}else {
											ifx_httpdWrite(wp,("<option value=\"0\" selected> OFF </option> <option value=\"1\" > ON </option>"));
										}
          } 
					else if (!gstrcmp (name, T ("readinterval")))
          {
									ifx_httpdWrite(wp,("%d %"),xSensor.xSensorInfo.uiInterval);
									f_cflag = 0;
          } 
					else if (!gstrcmp (name, T ("alarams")))
          {
							if(xSensorAlaramList.ucNoOfEntries > 0){
											pxTemp=xSensorAlaramList.pxAlaramEntries;
											i = 1;
    									while(pxTemp !=NULL)
									    {
												ifx_httpdWrite(wp, T("<TR><td>%d</td><td>%s &nbsp; &nbsp; %s</td></tr>"),i,pxTemp->xAlaram.acMessage, pxTemp->xAlaram.acAlaramTime);
									      __ifx_list_GetNext((void *)&pxTemp);
													i++;
									    }
										//ifx_httpdWrite(wp,T("<tr> <td colspan=\"2\" align=\"center\"><button type=\"submit\" onClick=\"return clearReads();\"> Clear </button></td> </tr>"));
							}else {
														ifx_httpdWrite(wp, T("<TR><td colspan=\"2\">---- NILL ----</td></TR>") );
							}
          } 
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
					if(f_cflag == 0){
              memset(&xPowerSensor,0,sizeof(xPowerSensor));
              xPowerSensor.iid.config_owner = IFX_WEB;
              xPowerSensor.iid.cpeId.Id = g_SENSOR_CPEID;
              if(LTQ_get_SensorEntry((void*)&xPowerSensor,g_SENSOR_TYPE,0) != IFX_VMAPI_SUCCESS){
                      return IFX_FAILURE;
                }
                 memset(&xSensorReadList,0,sizeof(xSensorReadList));
                xSensorReadList.iid.config_owner = IFX_WEB;
                xSensorReadList.uiSensorId = g_SENSOR_CPEID;
                if(LTQ_get_SensorAlaramList((void*)&xSensorReadList,g_SENSOR_READ_LIST,0) != IFX_VMAPI_SUCCESS){
                    return IFX_FAILURE;
                }
                  f_cflag = 1;
            }
						if (!gstrcmp (name, T ("regstatuscode")))
          {
                  ifx_httpdWrite(wp,T("%d"),xPowerSensor.xSensorInfo.bRegStatus);
          }
          else if (!gstrcmp (name, T ("alaramcount")))
          {
                  ifx_httpdWrite(wp,T("%d"),xSensorReadList.ucNoOfEntries);
          }
          else if (!gstrcmp (name, T ("sname")))
          {
                  ifx_httpdWrite(wp,T("%s"),xPowerSensor.xSensorInfo.acSensorName);
          }
          else if (!gstrcmp (name, T ("regstatus")))
          {
                  ifx_httpdWrite(wp,("%s"),(xPowerSensor.xSensorInfo.bRegStatus == 1)?"Registered":"Not Registered");
          }
         /* else if (!gstrcmp (name, T ("batstatus")))
          {
                  ifx_httpdWrite(wp,("%d %"),xPowerSensor.uiBatteryLevel);
          }*/
          else if (!gstrcmp (name, T ("pstatus")))
          {
                  if(xPowerSensor.xSensorInfo.bPowerStatus == 1){
                  ifx_httpdWrite(wp,("<option value=\"0\"> OFF </option> <option value=\"1\" selected> ON </option>"));
                  }else {
                      ifx_httpdWrite(wp,("<option value=\"0\" selected> OFF </option> <option value=\"1\" > ON </option>"));
                    }
          }
          else if (!gstrcmp (name, T ("readinterval")))
          {
                  ifx_httpdWrite(wp,("%d %"),xPowerSensor.xSensorInfo.uiInterval);
                  f_cflag = 0;
          }
					else if (!gstrcmp (name, T ("alarams")))
          {
              if(xSensorReadList.ucNoOfEntries > 0){
                      pxTemp1=xSensorReadList.pxPowEntries;
                      i = 1;
                      while(pxTemp1 !=NULL)
                      {
                        ifx_httpdWrite(wp, T("<TR><td>%d</td><td>%d</td><td>%d</td><td>%d</td><td>%s</td></tr>"),i,pxTemp1->xPowerRead.uiParam1, pxTemp1->xPowerRead.uiParam2,pxTemp1->xPowerRead.uiParam3,pxTemp1->xPowerRead.acMeasureTime);
												uiParam[0]+=pxTemp1->xPowerRead.uiParam1;
												uiParam[1]+=pxTemp1->xPowerRead.uiParam2;
												uiParam[2]+=pxTemp1->xPowerRead.uiParam3;
                        __ifx_list_GetNext((void *)&pxTemp1);
                          i++;
                      }
                        ifx_httpdWrite(wp, T("<TR><th>TOTAL</th><td>%d<td><td>%d</td><td>%d</td><td>-----</td></tr>"),uiParam[0],uiParam[1],uiParam[2]);
              }else {
                            ifx_httpdWrite(wp, T("<TR><td colspan=\"5\">---- NILL ----</td></TR>") );
              }
          }

			break;
}
return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_dectno
 *  Description     : This function is called header_dect.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Sets the DECT ID and redirects to the Next Page
 ****************************************************************************/
void
ltq_set_sensorid (httpd_t wp, char_t * path, char_t * query)
{
  char_t * pSensorId = ifx_httpdGetVar (wp, T ("cpeid"), T (""));

  g_SENSOR_CPEID = atoi(pSensorId);
  f_cflag=0;
  ifx_httpdNextPage (wp);
}


void
ltq_set_sensorlist (httpd_t wp, char_t * path, char_t * query)
{
  char_t * pAllon = ifx_httpdGetVar (wp, T ("allon"), T (""));
  char_t * pTalaram = ifx_httpdGetVar (wp, T ("talaram"), T (""));
  char_t * pPresetno = ifx_httpdGetVar (wp, T ("psetnum"), T (""));
	char acFlag=0;
	switch(g_SENSOR_LIST_TYPE){
      case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
      case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
              memset(&xSensorList,0,sizeof(xSensorList));
              xSensorList.iid.config_owner = IFX_WEB;
              if(LTQ_get_SensorList((void *)&xSensorList,g_SENSOR_LIST_TYPE,0) != IFX_VMAPI_SUCCESS){
                    ifx_httpdError (wp, 200, T ("Error getting smoke/motion sensorlist \n"));
              }

								if(xSensorList.bToneAlaram != atoi(pTalaram)){
												acFlag=1;
												xSensorList.bToneAlaram = atoi(pTalaram);
								} 
								if(xSensorList.bAllPowerOn != atoi(pAllon)){
												acFlag=1;
												xSensorList.bAllPowerOn = atoi(pAllon);
								} 
								if(gstrcmp ((char*)xSensorList.ucPresetNum, pPresetno)	){
											acFlag = 1;
											strcpy((char*)xSensorList.ucPresetNum,pPresetno);				
								}
              if(acFlag && LTQ_set_SensorList(IFX_OP_MOD,(void *)&xSensorList,g_SENSOR_LIST_TYPE,0) != IFX_VMAPI_SUCCESS){
                    ifx_httpdError (wp, 200, T ("Error setting smoke/motion sensorlist \n"));
              }
							//free sensor list here...
					break;		

			case IFX_VMAPI_VS_POWER_SENSOR_LIST:
            memset(&xPowerSensorList,0,sizeof(xPowerSensorList));
            xPowerSensorList.iid.config_owner = IFX_WEB;
            if(LTQ_get_SensorList((void*)&xPowerSensorList,IFX_VMAPI_VS_POWER_SENSOR_LIST,0) != IFX_VMAPI_SUCCESS){
                    ifx_httpdError (wp, 200, T ("Error getting power sensorlist \n"));
                   // return IFX_FAILURE;
            }
								if(xPowerSensorList.bAllPowerOn != atoi(pAllon)){
												acFlag=1;
												xPowerSensorList.bAllPowerOn = atoi(pAllon);
								} 
              if(acFlag && LTQ_set_SensorList(IFX_OP_MOD,(void *)&xPowerSensorList,g_SENSOR_LIST_TYPE,0) != IFX_VMAPI_SUCCESS){
                    ifx_httpdError (wp, 200, T ("Error setting smoke/motion sensorlist \n"));
              }
							//free sensor list here...
							break;	

		}	

  f_cflag=0;
  ifx_httpdNextPage (wp);
					
}
void
ltq_set_sensor_settings (httpd_t wp, char_t * path, char_t * query)
{
  char_t * paction = ifx_httpdGetVar (wp, T ("action"), T (""));
x_LTQ_VMAPI_SensorAlaram_Entry *pxTemp=NULL;
x_LTQ_VMAPI_PowerSensor_ReadEntry *pxTemp1=NULL;
switch(g_SENSOR_TYPE){
      case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
      case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
              	if(!gstrcmp(paction,"save") || !gstrcmp(paction,"unreg")){
									memset(&xSensor,0,sizeof(xSensor));
  		            xSensor.iid.config_owner = IFX_WEB;
      		        xSensor.iid.cpeId.Id = g_SENSOR_CPEID;
          		    if(LTQ_get_SensorEntry((void*)&xSensor,g_SENSOR_TYPE,0) != IFX_VMAPI_SUCCESS){
              		        printf("Error while Getting the Smoke  Sensor Entry.....\n");
	                }
										if(!gstrcmp(paction,"unreg")){
											xSensor.xSensorInfo.bRegStatus = 0;  
										}else{
  													char_t * pSensorname = ifx_httpdGetVar (wp, T ("sname"), T (""));
  													char_t * pPowerstatus = ifx_httpdGetVar (wp, T ("power"), T (""));
  													char_t * pInterval = ifx_httpdGetVar (wp, T ("interval"), T (""));
														xSensor.xSensorInfo.bPowerStatus = atoi(pPowerstatus);
														strcpy(xSensor.xSensorInfo.acSensorName,pSensorname);
														xSensor.xSensorInfo.uiInterval = atoi(pInterval);	
												}
									if(LTQ_set_SensorEntry(IFX_OP_MOD,(void*)&xSensor,g_SENSOR_TYPE,0) != IFX_VMAPI_SUCCESS){
                          printf("Error while setting the Smoke  Sensor Entry.....\n");
                  }
							}else if(!gstrcmp(paction,"clear")){
								int32 iCount=0;
                 memset(&xSensorAlaramList,0,sizeof(xSensorAlaramList));
                xSensorAlaramList.iid.config_owner = IFX_WEB;
                xSensorAlaramList.uiSensorId = g_SENSOR_CPEID;
                if(LTQ_get_SensorAlaramList((void*)&xSensorAlaramList,g_SENSOR_READ_LIST,0) != IFX_VMAPI_SUCCESS){
                    printf("Error Getting an Smoke SensorAlaramList  \n");
                }
            		if(xSensorAlaramList.ucNoOfEntries > 0){
                      pxTemp=xSensorAlaramList.pxAlaramEntries;
                      while(pxTemp !=NULL && iCount < xSensorAlaramList.ucNoOfEntries - 1)
                      {
		                        pxTemp->ucIndex=1;
    						            pxTemp->iid.config_owner = IFX_WEB;
														if(LTQ_set_SensorAlaramEntry(IFX_OP_DEL,pxTemp,g_SENSOR_READ_LIST + 1,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) != IFX_VMAPI_SUCCESS){
									      		    printf("Deleting a SensorAlaramList Entry....FAILED\n");
														}
													 iCount++;
												__ifx_list_GetNext((void *)&pxTemp);
                      }
														if(pxTemp != NULL){
		                        			pxTemp->ucIndex=1;
			    						            pxTemp->iid.config_owner = IFX_WEB;
																if(LTQ_set_SensorAlaramEntry(IFX_OP_DEL,pxTemp,g_SENSOR_READ_LIST + 1,0) != IFX_VMAPI_SUCCESS){
												      		    printf("Deleting a SensorAlaramList Entry....FAILED\n");
																}

														}
							}
					}		
			break;
			 case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
			if(!gstrcmp(paction,"save") || !gstrcmp(paction,"unreg")){
                  memset(&xSensor,0,sizeof(xSensor));
                  xPowerSensor.iid.config_owner = IFX_WEB;
                  xPowerSensor.iid.cpeId.Id = g_SENSOR_CPEID;
                  if(LTQ_get_SensorEntry((void*)&xPowerSensor,g_SENSOR_TYPE,0) != IFX_VMAPI_SUCCESS){
                          printf("Error while Getting the Smoke  Sensor Entry.....\n");
                  }
                    if(!gstrcmp(paction,"unreg")){
                      xPowerSensor.xSensorInfo.bRegStatus = 0;
                    }else{
                            char_t * pSensorname = ifx_httpdGetVar (wp, T ("sname"), T (""));
                            char_t * pPowerstatus = ifx_httpdGetVar (wp, T ("power"), T (""));
                            char_t * pInterval = ifx_httpdGetVar (wp, T ("interval"), T (""));
                            xPowerSensor.xSensorInfo.bPowerStatus = atoi(pPowerstatus);
                            strcpy(xPowerSensor.xSensorInfo.acSensorName,pSensorname);
                            xPowerSensor.xSensorInfo.uiInterval = atoi(pInterval);
                        }
                  if(LTQ_set_SensorEntry(IFX_OP_MOD,(void*)&xPowerSensor,g_SENSOR_TYPE,0) != IFX_VMAPI_SUCCESS){
                          printf("Error while setting the Smoke  Sensor Entry.....\n");
                  }
              }else if(!gstrcmp(paction,"clear")){
                int32 iCount=0;
                 memset(&xSensorReadList,0,sizeof(xSensorReadList));
                xSensorReadList.iid.config_owner = IFX_WEB;
                xSensorReadList.uiSensorId = g_SENSOR_CPEID;
                if(LTQ_get_SensorAlaramList((void*)&xSensorReadList,g_SENSOR_READ_LIST,0) != IFX_VMAPI_SUCCESS){
                    printf("Error Getting an Smoke SensorAlaramList  \n");
                }
                if(xSensorReadList.ucNoOfEntries > 0){
                      pxTemp1=xSensorReadList.pxPowEntries;
                      while(pxTemp1 !=NULL && iCount < xSensorReadList.ucNoOfEntries - 1)
                      {
                            pxTemp1->ucIndex=1;
                            pxTemp1->iid.config_owner = IFX_WEB;
                            if(LTQ_set_SensorAlaramEntry(IFX_OP_DEL,pxTemp1,g_SENSOR_READ_LIST + 1,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) != IFX_VMAPI_SUCCESS){
                                printf("Deleting a SensorAlaramList Entry....FAILED\n");
                            }
                           iCount++;
                        __ifx_list_GetNext((void *)&pxTemp1);
                      }
									if(pxTemp1 != NULL){
                                  pxTemp1->ucIndex=1;
                                  pxTemp1->iid.config_owner = IFX_WEB;
                                if(LTQ_set_SensorAlaramEntry(IFX_OP_DEL,pxTemp1,g_SENSOR_READ_LIST + 1,0) != IFX_VMAPI_SUCCESS){
                                      printf("Deleting a SensorAlaramList Entry....FAILED\n");
                                }

                            }
              }
          }	
 			 break;
}
  f_cflag=0;
  ifx_httpdNextPage (wp);
}
#endif
