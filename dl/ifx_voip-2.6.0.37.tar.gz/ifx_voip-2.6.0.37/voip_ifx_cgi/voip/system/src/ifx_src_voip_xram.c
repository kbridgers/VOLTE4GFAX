/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_debug.c
 *        Abstract: CGI API's to Access debug settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------


 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
//extern char_t g_cflag;
static char_t f_cflag;
static x_IFX_VMAPI_DectXRAM xXram;
extern int g_DIAGMODE;
static int gIndex;
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_xram
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/ 
void
ifx_set_voip_xram(httpd_t wp, char_t * path, char_t * query) 
{
  uchar8 ucStatus;
  char_t * pbyte1 = ifx_httpdGetVar (wp, T ("byte1"), T (""));
  char_t * pbyte2 = ifx_httpdGetVar (wp, T ("byte2"), T (""));
  char_t * pbyte3 = ifx_httpdGetVar (wp, T ("byte3"), T (""));
 #ifdef DECT_SUPPORT
	char_t * pbyte4 = ifx_httpdGetVar (wp, T ("byte4"), T (""));
  char_t * pbyte5 = ifx_httpdGetVar (wp, T ("byte5"), T (""));
  char_t * pbyte6 = ifx_httpdGetVar (wp, T ("byte6"), T (""));
  char_t * pbyte7 = ifx_httpdGetVar (wp, T ("byte7"), T (""));
  char_t * pbyte8 = ifx_httpdGetVar (wp, T ("byte8"), T (""));
  char_t * pbyte9 = ifx_httpdGetVar (wp, T ("byte9"), T (""));
	#endif 
  char_t * pXram = ifx_httpdGetVar (wp, T ("XRam"), T (""));
  char_t * pObj = ifx_httpdGetVar (wp, T ("accesstype"), T (""));
	
#ifdef CVOIP_SUPPORT
	char8 buff[125]="\0";
#endif
  //char_t * pObjType = ifx_httpdGetVar (wp, T ("access_t"), T (""));

  
 uchar8 ucIsSfr = 0; 
 int32 iRet;

 IFX_CGI_DEBUG("Entered ifx_set_voip_xram \n");

/*
 if(*pObjType != '\0'){
  gIndex = atoi(pObjType); 
  IFX_CGI_DEBUG("\n<ifx_set_voip_xram> gIndex on Click=%d \n",gIndex);
  ifx_httpdNextPage (wp);
  return;
 }
*/
 
 
 memset(&xXram,0,sizeof(xXram));
 xXram.iid.config_owner = IFX_WEB;
 if(ifx_get_Xram(&xXram,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET XRAM\n"));
    return ;
  }  

  if(!strcmp(pObj,"sfr")){
    ucIsSfr = 0x80;
    gIndex = 2;
  }else{
    gIndex = 1;
   }

  IFX_CGI_DEBUG("\n<ifx_set_voip_xram> ucIsSfr=%d \n",ucIsSfr);
  IFX_CGI_DEBUG("\n<ifx_set_voip_xram> gIndex=%d \n",gIndex);
  ucStatus = atoi(pXram);
 	 
  xXram.ucByte1 = hd((uchar8 *)pbyte1);
  xXram.ucByte2 = hd((uchar8 *)pbyte2);
	#ifdef CVOIP_SUPPORT
	  xXram.ucByte3 = atoi(pbyte3);
	#endif

	#ifdef DECT_SUPPORT
  IFX_CGI_DEBUG("\n<ifx_set_voip_xram> %d %d %d %d %d %d %d\n",hd((uchar8 *)pbyte1),hd((uchar8 *)pbyte2),hd((uchar8 *)pbyte3),hd((uchar8 *)pbyte4),hd((uchar8 *)pbyte5),hd((uchar8 *)pbyte6),hd((uchar8 *)pbyte7));
  
  xXram.ucByte3 = hd((uchar8 *)pbyte3);
  xXram.ucByte4 = hd((uchar8 *)pbyte4);
  xXram.ucByte5 = hd((uchar8 *)pbyte5);
  xXram.ucByte6 = hd((uchar8 *)pbyte6);
  xXram.ucByte7 = hd((uchar8 *)pbyte7);
  xXram.ucByte8 = hd((uchar8 *)pbyte8);
  xXram.ucByte9 = hd((uchar8 *)pbyte9);
	#endif
#ifdef CVOIP_SUPPORT
//check for get/set operation
	if( ifx_set_Xram(IFX_OP_MOD,&xXram,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) != IFX_VMAPI_SUCCESS ){
    ifx_httpdError (wp, 200, T ("Fail to Set XRAM Params\n"));
    return ;
	}
if(ucStatus == 1){
	//construct the request buffer
	//#RAM 0,0/1,
		if(ucIsSfr){
			sprintf(buff,"0,1,%.2x,%.2x,?",xXram.ucByte1,xXram.ucByte2);
		}else{
			sprintf(buff,"0,0,,%.2x%.2x,?",xXram.ucByte1,xXram.ucByte2);
		}
	if( (iRet = LTQ_Request_XramToModem(buff)) != IFX_VMAPI_SUCCESS ){
    ifx_httpdError (wp, 200, T ("Fail to Send Notification to CVoIP\n"));
    return ;
	}
}else {
#endif
  xXram.iid.config_owner = IFX_WEB;
	#if defined (DECT_SUPPORT)
		iRet = ifx_set_XramToModem(ucStatus | ucIsSfr,&xXram);
		sleep(2);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET XRAM\n"));
    return ;
  }  
	#elif defined(CVOIP_SUPPORT)

		if(ucIsSfr){
			sprintf(buff,"0,1,%.2x,%.2x,%d",xXram.ucByte1,xXram.ucByte2,xXram.ucByte3);
		}else{
			sprintf(buff,"0,0,,%.2x%.2x,%d",xXram.ucByte1,xXram.ucByte2,xXram.ucByte3);
		}
	if( (iRet = LTQ_Request_XramToModem(buff)) != IFX_VMAPI_SUCCESS ){
    ifx_httpdError (wp, 200, T ("Fail to Send Notification to CVoIP\n"));
    return ;
	}
	#endif

#ifdef CVOIP_SUPPORT
}
#endif
	f_cflag=0;
  ifx_httpdNextPage_New(wp);
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_xram
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_xram(int eid, httpd_t wp, int argc, char_t ** argv) 
{
char_t * name, *mode;
  char_t byte_value[3] = {'\0'};
  int32 iRet;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if(f_cflag == 0)
  {
    memset(&xXram,0,sizeof(xXram));
    xXram.iid.config_owner = IFX_WEB;
    iRet = ifx_get_Xram(&xXram,0);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET XRAM\n"));
      return -1;
    }  
    f_cflag = 1;
  }
	
  if (!gstrcmp (name, T ("byte1")))
  {
      dh(xXram.ucByte1,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte2")))
  {
      dh(xXram.ucByte2,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);	 
  }
#if defined (DECT_SUPPORT)
  else if (!gstrcmp (name, T ("byte3")))
  {
      dh(xXram.ucByte3,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte4")))
  {
      dh(xXram.ucByte4,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte5")))
  {
     dh(xXram.ucByte5,(uchar8 *)byte_value);
     ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte6")))
  {
     dh(xXram.ucByte6,(uchar8 *)byte_value);
     ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte7")))
  {
     dh(xXram.ucByte7,(uchar8 *)byte_value);
     ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte8")))
  {
     dh(xXram.ucByte8,(uchar8 *)byte_value);
     ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("byte9")))
  {
     dh(xXram.ucByte9,(uchar8 *)byte_value);
     ifx_httpdWrite (wp, T ("%s"),byte_value);
     f_cflag = 0;
  }
#elif defined(CVOIP_SUPPORT)
  else if (!gstrcmp (name, T ("byte3")))
  {
      ifx_httpdWrite (wp, T ("%d"),xXram.ucByte3);
			f_cflag = 0;
  }
#endif
  return 0;
}		  

int
ifx_get_voip_mem_access(int eid, httpd_t wp, int argc, char_t ** argv) 
{

  char_t * name, *mode;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
  if (!gstrcmp (name, T ("access")))
  {
      IFX_CGI_DEBUG("\n<ifx_set_voip_xram> gIndex=%d \n",gIndex);
      ifx_httpdWrite (wp, T ("%d"),gIndex);
  }
  return 0;
}
#endif		  
		  
