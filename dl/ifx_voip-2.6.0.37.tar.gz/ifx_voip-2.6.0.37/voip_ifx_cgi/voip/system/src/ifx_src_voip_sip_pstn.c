/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_pstn.c
 *        Abstract: CGI API's to Access PSTN settings
 *        Date    : 27-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

extern int g_LINE_ID_IS;
static  x_IFX_VMAPI_FxoPhyIf xFXO;
static char_t f_cflag;
/***************************************************************************n
 *  Function Name   : ifx_get_voip_sip_pstn
 *  Description     : This function is called pstn_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_pstn (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  int32  count = 0;
  char_t sValue[MAX_DATA_LEN];
	char8 pcName[20];
  uchar8 nIndex = 0;
	uchar8 uEndPointCount = IFX_VMAPI_MAX_FXS_ENDPTS;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
    uEndPointCount+=IFX_VMAPI_MAX_DECT_ENDPTS;
#endif


  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
if(f_cflag == 0){
  /* Get the parameters of FXO physical interface*/
  memset (&xFXO, 0, sizeof (xFXO));
  xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
  xFXO.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFXO,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to get FXO\n"));
    return -1;
  }
	f_cflag = 1;
}
  if (!gstrcmp (name, T ("updateData1")))
  { 
    nIndex=0;
    while(nIndex <= uEndPointCount)  
    {
      IFX_WEB_GetInterfaceName (nIndex+1, pcName);
			if(strcmp(pcName,"FXO")){ //except for FXO
        ifx_httpdWrite (wp, T ( "getThePhyendptsList1(\"%s\",\"%s\");\n"),
                        pcName,
                        pcName);
			}
      
			memset(pcName,0,sizeof(pcName));
			nIndex++; 
    }
    return 0; 
  }

  if (!gstrcmp (name, T ("pstnstatus")))
  {
     uint32 ucValue = xFXO.ucState;
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_State) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_State[nIndex].value, sValue,
                        web_Enum_State[nIndex].str);
     }
    return 0;
  }
  if (!gstrcmp (name, T ("intrusion")))
  {
     uint32 ucValue = xFXO.ucIntrusion;
      for (nIndex = 0;
          nIndex < sizeof (web_Intr) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Intr[nIndex].value, sValue,
                        web_Intr[nIndex].str);
     }
		f_cflag = 0;
	}

  if (!gstrcmp (name, T ("echoCancel")))
  {
      uint32 ucValue = xFXO.bEnableEchoCancel;
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
     }
  }

  /* display the endpoints already associated*/
  if (!gstrcmp (name, T ("updateData")))
  {
    while(nIndex < uEndPointCount && xFXO.ucInterfaceIdList[nIndex] != 0)
    {
		  IFX_WEB_GetInterfaceName (xFXO.ucInterfaceIdList[nIndex], pcName);
      ifx_httpdWrite (wp, T ( "getThePhyendptsList(\"%s\",\"%s\");\n"),
                         pcName,
                         pcName);
			 memset(pcName,0,sizeof(pcName));
      nIndex++;
    } 
    count ++;
  }
  if(!gstrcmp (name, T ("pstn_stat")))
  {
    ifx_httpdWrite(wp, T("%s"),web_Enum_State[xFXO.ucState].str );  
		f_cflag=0; 
 } 
  if(!gstrcmp (name, T ("pstn_name")))  //aarif
  {
    ifx_httpdWrite(wp, T("%s"),xFXO.acName );  
  }
   return 0;
}
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_pstn
 *  Description     : This function is called pstn_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_pstn (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pPPhyendptsString = ifx_httpdGetVar (wp, T ("pPhyendptsString"), T (""));
  //char_t * pPstnStatus = ifx_httpdGetVar (wp, T ("pstnstatus"), T (""));
  char_t * pEchoCan = ifx_httpdGetVar (wp, T ("echoCancel"), T (""));
  char_t * pIntr = ifx_httpdGetVar (wp, T ("intrusion"), T (""));
  
	uchar8 ucInt;
	//char8 pcName[20];
  int index = 0,p=0;
  uchar8 pucPhyendptsList[20]; 
  uchar8 pucPhyendptsListWeb[20][IFX_VMAPI_MAX_USER_NAME_LEN]; 
  uchar8 ucNoofPhyendpts =0;
  x_IFX_VMAPI_FxoPhyIf xFXO;
  uchar8 DisAssoc_array[30]={0};
  int32 flag1=0,count1=0,q=0,i=0;
  x_IFX_VMAPI_FxsPhyIf xFXS;
  int32 iRet;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)                                                                                                                                                   
  x_IFX_VMAPI_DectHandset xDectHand;                                                                                                                                  
  int32 dect_flag = 0;                                                                                                                                                
#endif                 

  memset (&xFXS, 0, sizeof (xFXS));
  memset (&xFXO, 0, sizeof (xFXO));
  xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
  xFXO.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFXO,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to get FXO\n"));
    return ;
  }

  /* Parse the string set from web*/
  memset (pucPhyendptsList, 0, sizeof (pucPhyendptsList));
  memset (pucPhyendptsListWeb, 0, sizeof (pucPhyendptsListWeb));
  //if (pPPhyendptsString != NULL)
	if(!((*pPPhyendptsString == ' ') || (*pPPhyendptsString == '\0') )){
    ifx_ParseString ((uchar8 *)pPPhyendptsString, &pucPhyendptsListWeb[0][0],
                                   &ucNoofPhyendpts);
  }
	
  for (p = 0; p < ucNoofPhyendpts; p++)  {
    IFX_WEB_GetInterfaceId ((char8 *)pucPhyendptsListWeb[p], &ucInt);
	  pucPhyendptsList[p] = ucInt;		
	}

  /* No change in the Associated Endpoints List. Just return. */ 
  if((0 == memcmp(xFXO.ucInterfaceIdList,pucPhyendptsList,
                  IFX_VMAPI_MAX_FXO_INTERFACES))&&
                  (xFXO.bEnableEchoCancel == atoi (pEchoCan))&&(xFXO.ucIntrusion == atoi (pIntr))){
    ifx_httpdNextPage (wp);
    return;
  }

  if( 0 != memcmp(xFXO.ucInterfaceIdList,pucPhyendptsList,
									IFX_VMAPI_MAX_FXO_INTERFACES) ){
	p=0;
  memset (DisAssoc_array, 0, sizeof (DisAssoc_array));                                                                                                             
  /* Comparing parsed array with InterfaceIdList in PSTN Line to get  
			the Endpoints which have been disassociated*/
	while(xFXO.ucInterfaceIdList[i] != 0){  
			/* All the endpoints are disassociated */
    	if(ucNoofPhyendpts == 0){	
					memcpy(DisAssoc_array,xFXO.ucInterfaceIdList,sizeof(xFXO.ucInterfaceIdList));                                             	break;
			}                                                                                                                                                                 
    	/* Some Endpoints are disassociated. Endpoints which are there in   
				the Fxo InterfaceId list but not in the parsed array,
				list from web, are disassociated.*/ 
			else{
				for (p = 0; p < ucNoofPhyendpts; p++) {                                                                                          if(xFXO.ucInterfaceIdList[i] != (pucPhyendptsList[p])){
								count1++;
						 } 
				}
				if(count1 == ucNoofPhyendpts) {                                                                                                DisAssoc_array[q] = xFXO.ucInterfaceIdList[i];                                                                                                      
        q++;                                                                                                                                                          
      	}
				count1=0;                                    
    	}                                                                                                                           i++;                                                                                                                     }
 count1=0;q=0;
 p=0;i=0;

 /*Assigning the associated Endpoints to the InterfaceId List of PSTN Line */                                                                                          
  memset (xFXO.ucInterfaceIdList, 0,sizeof (xFXO.ucInterfaceIdList));

  for (index = 0; index < ucNoofPhyendpts; index++) {
    xFXO.ucInterfaceIdList[index] = (pucPhyendptsList[index]);
	}

 /* Updating the parameters of DisAssociating Endpoints. For each disassociated                                                                                      
     Endpoint the VoiceLineIdList and default VoiceLineId needs to be updated. */                                                                                     
  while(DisAssoc_array[q] != 0)                                                                                                                                       
  {                                                                                                                                                                   
    /* For FXS Endpoints */                                                                                                                                           
    if(DisAssoc_array[q] <3) {                                                                                                                                        
      memset(&xFXS,0,sizeof(xFXS));                                                                                                                                   
      xFXS.xVoiceServPhyIf.ucInterfaceId = DisAssoc_array[q];                                                                                                         
      iRet = ifx_get_FxsPhyInterface(&xFXS,0);                                                                                                                        
      if (iRet != IFX_VMAPI_SUCCESS)                                                                                                                                  
      {                                                                                                                                                               
        ifx_httpdError (wp, 200, "Fail to GET the FXS !!");                                                                                                           
        return;                                                                                                                                                       
      }                                                                                                                                                               
                                                                                                                                                                      
      i=0;                                                                                                                                                            
                                                                                                                                                                      
      /* If the default VoiceLineId is same as the LineId then delete that                                                                                            
         and set it to the next available VoiceLine else set it to 0 */                                                                                               
      if(xFXS.ucVoiceLineId == IFX_VMAPI_PSTN_LINE)//g_LINE_ID_IS                                                                                                                          
      {                                                                                                                                                               
        while(xFXS.ucVoiceLineIdList[i] != 0)                                                                                                                         
        {                                                                                                                                                             
          if(xFXS.ucVoiceLineIdList[i] != IFX_VMAPI_PSTN_LINE)//g_LINE_ID_IS                                                                                                               
          {                                                                                                                                                           
            xFXS.ucVoiceLineId = xFXS.ucVoiceLineIdList[i];                                                                                                           
            break;
          }                                                                                                                                                           
          else                                                                                                                                                        
          {                                                                                                                                                           
            xFXS.ucVoiceLineId = 0;                                                                                                                                   
          }                                                                                                                                                           
          i++;                                                                                                                                                        
        }                                                                                                                                                             
      }                                                                                                                                                               
                                                                                                                                                                      
      i=0;                                                                                                                                                            
                                                      
      /* Remove the Line from the VoiceLineId List of that FXS endpoint*/                                                                                             
      while (xFXS.ucVoiceLineIdList[p] != 0)                                                                                                                          
      {                                                                                                                                                               
        /* Check if the corresponding line is already there */                                                                                                        
        if (xFXS.ucVoiceLineIdList[p] == IFX_VMAPI_PSTN_LINE) //g_LINE_ID_IS                                                                                                                
        {                                                                                                                                                             
          i=p;                                                                                                                                                        
          while(xFXS.ucVoiceLineIdList[i] != 0)                                                                                                                       
          {                                                                                                                                                           
            xFXS.ucVoiceLineIdList[i] = xFXS.ucVoiceLineIdList[i+1];                                                                                                  
            i++;                                                                                                                                                      
          }                                                                                                                                                           
        }                                                                                                                                                             
        p++;                                                                                                                                                          
      }                                                                                                                                                               
                                                                                                                                                                      
      /* SET the object */                                                                                                                                            
      if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,                                                                                               
                              IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))                                                                                                
      {                                                                                                                                                               
        ifx_httpdError (wp, 200, T ("Fail to SET FXS !!\n"));                                                                                                         
        return ;                                                                                                                                                      
      }                                                                                                                                                               
    }                                                   

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)                                                                                                                                                   
    p=0;                                                                                                                                                              
    i=0;                                                                                                                                                              
    if(DisAssoc_array[q] >3) {                                                                                                                                        
      /* For DECT Handset */                                                                                                                                          
      memset(&xDectHand,0,sizeof(xDectHand));                                                                                                                         
      xDectHand.xVoiceServPhyIf.ucInterfaceId = DisAssoc_array[q];                                                                                                    
      iRet = ifx_get_DectHandset(&xDectHand,0);                                                                                                                       
      if (iRet != IFX_VMAPI_SUCCESS)                                                                                                                                  
      {                                                                                                                                                               
        ifx_httpdError (wp, 200, "Fail to GET the Dect Handset !!");                                                                                                  
        return;                                                                                                                                                       
      }                                                                                                                                                               
                                                                                                                                                                      
      /* If the default VoiceLineId is same as the Line then delete that                                                                                              
         and set it to the next available VoiceLine else 0 */                                                                                                         
      i=0;                                                                                                                                                            
      if(xDectHand.ucVoiceLineId == IFX_VMAPI_PSTN_LINE)//g_LINE_ID_IS                                                                                                                     
      {                                                                                                                                                               
        while(xDectHand.aucVoiceLineIdList[i] != 0)                                                                                                                   
        {                                                                                                                                                             
          if(xDectHand.aucVoiceLineIdList[i] != IFX_VMAPI_PSTN_LINE) //g_LINE_ID_IS                                                                                                        
          {                                                                                                                                                           
            xDectHand.ucVoiceLineId = xDectHand.aucVoiceLineIdList[i];                                                                                                
            break;
          }                                                                                                                                                           
          else                                                                                                                                                        
          {                                                                                                                                                           
            xDectHand.ucVoiceLineId = 0;                                                                                                                              
          }                                                                                                                                                           
          i++;                                                                                                                                                        
        }                                                                                                                                                             
      }                                                                                                                                                               
                                                                                                                                                                      
      i=0;                                        
      /* Remove the LineId from the VoiceLineId List */                                                                                                               
      while (xDectHand.aucVoiceLineIdList[p] != 0)                                                                                                                    
      {                                                                                                                                                               
        /* Check if the corresponding line is already there */                                                                                                        
        if (xDectHand.aucVoiceLineIdList[p] == IFX_VMAPI_PSTN_LINE)//g_LINE_ID_IS                                                                                                          
        {                                                                                                                                                             
          i=p;                                                                                                                                                        
          while(xDectHand.aucVoiceLineIdList[i] != 0)                                                                                                                 
          {                                                                                                                                                           
            xDectHand.aucVoiceLineIdList[i] = xDectHand.aucVoiceLineIdList[i+1];                                                                                      
            i++;                                                                                                                                                      
          }                                                                                                                                                           
        }                                                                                                                                                             
        p++;                                                                                                                                                          
      }                                                                                                                                                               
                                                                                                                                                                      
      /* SET the object */                                                                                                                                            
      if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,                                                                                              
                              IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))                                                                                                
      {                                                                                                                                                               
        ifx_httpdError (wp, 200, T ("Fail to SET Dect Handset !!\n"));                                                                                                
        return ;                                                                                                                                                      
      }                                                                                                                                                               
    }                                                                                                                                                                 
                                                                                                                                                                      
#endif                                                                                                                                                                
     q++;                                                                                                                                                             
     p=0;                                                                                                                                                             
     i=0;                                                                                                                                                             
  }/* while loop */                                       

  q=0;                                                                                                                                                                
  p=0;                                                                                                                                                                
  i=0;                                                                                                                                                                
          
  /* Updating the parameters of the Endpoints which are getting associated with                                                                                       
     this line. */                                                                                                                                                    
  while( (pucPhyendptsList[i]) != 0)                                                                                                                                  
  {                                                                                                                                                                   
    if(pucPhyendptsList[i] <3){                                                                                                                                       
      memset(&xFXS,0,sizeof(xFXS));                                                                                                                                   
      xFXS.xVoiceServPhyIf.ucInterfaceId = (pucPhyendptsList[i]);                                                                                                     
      iRet = ifx_get_FxsPhyInterface(&xFXS,0);                                                                                                                        
      if (iRet != IFX_VMAPI_SUCCESS)                                                                                                                                  
      {                                                                                                                                                               
        ifx_httpdError (wp, 200, "Fail to GET the FXS !!!");                                                                                                          
        return;                                                                                                                                                       
      }                                                                                                                                                               
                                                                                                                                                                      
      while(xFXS.ucVoiceLineIdList[p] != 0)                                                                                                                           
      {                                                                                                                                                               
        /* Set the flag if this Line is already associated*/                                                                                                     
        if(xFXS.ucVoiceLineIdList[p] == IFX_VMAPI_PSTN_LINE)                                                                                                          
        {                                                                                                                                                             
          flag1 = 1;                                                                                                                                                  
        }                                                                                                                                                             
        count1++;                                                                                                                                                     
        p++;                                                                                                                                                          
      }                                                                                                                                                               
      /*If the flag is not set then assign this PSTN Line Id to the VoiceLineIdList                                                                                   
        of the Endpoint. Set the default VoiceLine parameter also if the Endpoint was                                                                                 
        not associated with any VoiceLine before. */                                                                                                                  
      if ( flag1 == 0 )                                                                                                                                               
      {                                                                                                                                                               
        if(xFXS.ucVoiceLineId == 0)                                                                                                                                   
        {                                                                                                                                                             
          xFXS.ucVoiceLineId = IFX_VMAPI_PSTN_LINE;                                                                                                                   
        }                                                                                                                                                             
        xFXS.ucVoiceLineIdList[count1] = IFX_VMAPI_PSTN_LINE;                                                                                                         
        iRet = ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);                                                                      
        if (iRet != IFX_VMAPI_SUCCESS)                                                                                                                                
        {                                                                                                                                                             
          ifx_httpdError (wp, 200, "Fail to SET the FXS !!!");                                                                                                        
          return;                                                                                                                                                     
        }                                                                                                                                                             
      }                                                                                                                                                               
    }                                                               

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)                                                                                                                                                   
    /* For Dect Handset */                                                                                                                                            
    p=0;                                                                                                                                                              
    count1=0;                                                                                                                                                         
    if(pucPhyendptsList[i] >3){                                                                                                                                       
      memset(&xDectHand,0,sizeof(xDectHand));                                                                                                                         
      xDectHand.xVoiceServPhyIf.ucInterfaceId = (pucPhyendptsList[i]);                                                                                                
      iRet = ifx_get_DectHandset(&xDectHand,0);                                                                                                                       
      if (iRet != IFX_VMAPI_SUCCESS)                                                                                                                                  
      {                                                                                                                                                               
        ifx_httpdError (wp, 200, "Fail to GET the Dect Handset !!!");                                                                                                 
        return;                                                                                                                                                       
      }                                                                                                                                                               
                                                                                                                                                                      
      while(xDectHand.aucVoiceLineIdList[p] != 0)                                                                                                                     
      {                                                                                                                                                               
        /* Set the flag if this VoiceLine is already associated*/                                                                                                     
        if(xDectHand.aucVoiceLineIdList[p] == IFX_VMAPI_PSTN_LINE)                                                                                                    
        {                                                                                                                                                             
          dect_flag = 1;                                                                                                                                              
        }                                                                                                                                                             
        count1++;                                                                                                                                                     
        p++;                                                                                                                                                          
      }                                                                                                                                                               
      /*If the flag is not set then assign this VoiceLine Id to the VoiceLineIdList                                                                                   
        of the Endpoint. Set the default VoiceLine parameter also if the Endpoint was                                                                                 
        not associated with any VoiceLine before. */                                                                                                                  
      if ( dect_flag == 0 )                                                                                                                                           
      {                                                                                                                                                               
        if(xDectHand.ucVoiceLineId == 0)                                                                                                                              
        {                                                                                                                                                             
          xDectHand.ucVoiceLineId = IFX_VMAPI_PSTN_LINE;                                                                                                              
        }                                                                                                                                                             
        xDectHand.aucVoiceLineIdList[count1] = IFX_VMAPI_PSTN_LINE;                                                                                                   
        if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,                                                                                            
                                IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))                                                                                              
        {                                                                                                                                                             
          ifx_httpdError (wp, 200, "Fail to SET the DectHandset !!!");                                                                                                
          return;                                                                                                                                                     
        }                                                                                                                                                             
      }                                                                                                                                                               
    }                                                                                                                                                                 
#endif /*DECT_SUPPORT*/                                  
    p=0;                                                                                                                                                              
    count1=0;                                                                                                                                                         
    flag1=0;                                                                                                                                                          
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)                                                                                                                                                   
    dect_flag=0;                                                                                                                                                      
#endif                                                                                                                                                                
    i++;                                                                                                                                                              
  } /* while loop */                                                                                                          }
  if (xFXO.bEnableEchoCancel != atoi (pEchoCan)){
    //xFXO.ucState = atoi (pPstnStatus);
    xFXO.bEnableEchoCancel = atoi (pEchoCan);
  }
  if (xFXO.ucIntrusion != atoi (pIntr)){
    //xFXO.ucState = atoi (pPstnStatus);
    xFXO.ucIntrusion = atoi (pIntr);
  }
  

  if(IFX_VMAPI_SUCCESS != ifx_set_FxoPhyInterface(IFX_OP_MOD,&xFXO,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to set FXO\n"));
    return ;
  }

		f_cflag = 0;
  ifx_httpdNextPage_New(wp);
} 


