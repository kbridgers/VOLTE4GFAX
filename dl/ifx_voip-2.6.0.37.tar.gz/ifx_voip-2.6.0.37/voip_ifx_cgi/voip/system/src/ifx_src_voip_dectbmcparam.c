/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_debug.c
 *        Abstract: CGI API's to Access debug settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------


 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
static char_t f_cflag;
extern int g_DIAGMODE;
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_debug
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to Next Page
 ****************************************************************************/ 

void
ifx_set_voip_Bmcparam(httpd_t wp, char_t * path, char_t * query) 
{
  uchar8 ucStatus;
  char_t * pRssifreelvl = ifx_httpdGetVar (wp, T ("Rssifreelevel"), T (""));
  char_t * pRssibuyslvl = ifx_httpdGetVar (wp, T ("Rssibusylevel"), T (""));
  char_t * pBearerchange = ifx_httpdGetVar (wp, T ("Bearerchangelimit"), T (""));
  char_t * pAntenna = ifx_httpdGetVar (wp, T ("Defaultanternna"), T (""));
  char_t * pWopnsf = ifx_httpdGetVar (wp, T ("wopnsf"), T (""));
  char_t * pWwsf = ifx_httpdGetVar (wp, T ("wwsf"), T (""));
  char_t * pDronctrlreg = ifx_httpdGetVar (wp, T ("DronCtrlReg"), T (""));
  char_t * pDval = ifx_httpdGetVar (wp, T ("Dval"), T (""));
  char_t * pHOframe = ifx_httpdGetVar (wp, T ("HOFrame"), T (""));
  char_t * pSyncMode = ifx_httpdGetVar (wp, T ("SyncMode"), T (""));
  char_t * pBmc = ifx_httpdGetVar (wp, T ("Bmcparam"), T (""));
  #ifdef CVOIP_SUPPORT
  char_t * pNTPBattmeas = ifx_httpdGetVar (wp, T ("NTPBattmeas"), T (""));
  char_t * pNTPOffset = ifx_httpdGetVar (wp, T ("NTPOffset"), T (""));
  char_t * pGreenBattmeas = ifx_httpdGetVar (wp, T ("GreenBattmeas"), T (""));
  char_t * pGreenOffset = ifx_httpdGetVar (wp, T ("GreenOffset"), T (""));
  char_t * pPowerlevel = ifx_httpdGetVar (wp, T ("powerlevel"), T (""));
  char_t * pPoweralgo = ifx_httpdGetVar (wp, T ("poweralgo"), T (""));
 #endif 
  int32 iRet;
  x_IFX_VMAPI_DectBMCParams  xBmcparam;

  //memset(&xBmcparam,0,sizeof(xBmcparam));

  xBmcparam.iid.config_owner = IFX_WEB;
  iRet = ifx_get_Bmcparam(&xBmcparam,0);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET BMC Param\n"));
    return ;
  }  
  
  ucStatus = atoi(pBmc);
  
  //IFX_CGI_DEBUG("Value from Web Page...%s\n",pPwrOff1);
  IFX_CGI_DEBUG("BMC Param Get/Set button Pressed: ucStatus=%d\n", ucStatus); 

  xBmcparam.ucDectRSSIFreeLevel = hd((uchar8 *)pRssifreelvl);
  xBmcparam.ucDectRSSIBusyLevel = hd((uchar8 *)pRssibuyslvl);
  xBmcparam.ucDectBearerChgLim  = hd((uchar8 *)pBearerchange);
  xBmcparam.ucDectDefaultAntenna  = hd((uchar8 *)pAntenna);
  xBmcparam.ucDectWOPNSF  = hd((uchar8 *)pWopnsf);
  xBmcparam.ucDectWWSF = hd((uchar8 *)pWwsf);
  xBmcparam.ucDectCNTUPCtrlReg = hd((uchar8 *)pDronctrlreg);
  xBmcparam.ucDectDelayReg = hd((uchar8 *)pDval);
  xBmcparam.ucDectHandOverEvalper = hd((uchar8 *)pHOframe);
  xBmcparam.ucDectSYNCMCtrlReg = hd((uchar8 *)pSyncMode);
#if defined(CVOIP_SUPPORT)
  xBmcparam.ucDectReserved_0 = hd((uchar8 *)pNTPBattmeas);
  xBmcparam.ucDectReserved_1 = hd((uchar8 *)pNTPOffset);
  xBmcparam.ucDectReserved_2 = hd((uchar8 *)pGreenBattmeas);
  xBmcparam.ucDectReserved_3 = hd((uchar8 *)pGreenOffset);
  xBmcparam.ucDectReserved_4 = atoi(pPowerlevel);
  xBmcparam.ucDectReserved_5 = atoi(pPoweralgo);
#endif
//check for get/set operation
  if(ucStatus == 1/* &&  g_DIAGMODE == 1*/) {
#if defined( CVOIP_SUPPORT )
	iRet =  LTQ_CVoIP_ParamRequest(IFX_VMAPI_BMC_REG_PARAMS_REQUEST);
#elif defined(DECT_SUPPORT)
	iRet = ifx_set_BmcparamToModem(1,NULL);
 	IFX_CGI_DEBUG("\n<ifx_set_voip_Bmcparam>UCSTATUS=1\n");
#endif
  }
  else if(ucStatus == 2/* &&  g_DIAGMODE == 1*/) {
#if defined(DECT_SUPPORT)
	  iRet = ifx_set_BmcparamToModem(2,&xBmcparam);
#endif
    iRet = ifx_set_Bmcparam(IFX_OP_MOD,&xBmcparam,0);
  	IFX_CGI_DEBUG("\n<ifx_set_voip_Bmcparam>UCSTATUS=2\n");
  }
  else if(ucStatus == 0) {
    iRet = ifx_set_Bmcparam(IFX_OP_MOD,&xBmcparam,0);
  	IFX_CGI_DEBUG("\n<ifx_set_voip_Bmcparam>UCSTATUS=0\n");
  }
  else {
   ifx_httpdError (wp, 200, T ("DIAGNOSTICS mode is disabled\n"));
   return;
  }

  if(iRet != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET BMC Param\n"));
    return ;
  }  
  ifx_httpdNextPage_New(wp);
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_transpower
 *  Description     : This function is called voipsys_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_Bmcparam(int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  //char_t sValue[MAX_DATA_LEN];
  char_t byte_value[3] = {'\0'};
  //int nSelIndex = 0, nIndex = 0;
  int32 iRet;
  static x_IFX_VMAPI_DectBMCParams  xBmcparam;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if(f_cflag == 0)
  {
    memset(&xBmcparam,0,sizeof(xBmcparam));
    xBmcparam.iid.config_owner = IFX_WEB;
    iRet = ifx_get_Bmcparam(&xBmcparam,0);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET BMC Param\n"));
      return -1;
    }  
    f_cflag = 1;
  }
	
  if (!gstrcmp (name, T ("Rssifreelevel")))
  {
      //IFX_CGI_DEBUG("\nDid it enter here  %d",xTpwrPar.ucTuneDigitalRef);
      dh(xBmcparam.ucDectRSSIFreeLevel,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Rssibusylevel")))
  {
      dh(xBmcparam.ucDectRSSIBusyLevel,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Bearerchangelimit")))
  {
      dh(xBmcparam.ucDectBearerChgLim,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Defaultanternna")))
  {
      dh(xBmcparam.ucDectDefaultAntenna,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("wopnsf")))
  {
      dh(xBmcparam.ucDectWOPNSF,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("wwsf")))
  {
      dh(xBmcparam.ucDectWWSF,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("DronCtrlReg")))
  {
      dh(xBmcparam.ucDectCNTUPCtrlReg,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("Dval")))
  {
      dh(xBmcparam.ucDectDelayReg,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("HOFrame")))
  {
      dh(xBmcparam.ucDectHandOverEvalper,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("SyncMode")))
  {
      dh(xBmcparam.ucDectSYNCMCtrlReg,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
		#ifdef DECT_SUPPORT
  		f_cflag = 0;
		#endif
  }
#if defined(CVOIP_SUPPORT)
  else if (!gstrcmp (name, T ("NTPBattmeas")))
  {
      dh(xBmcparam.ucDectReserved_0,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("NTPOffset")))
  {
      dh(xBmcparam.ucDectReserved_1,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("GreenBattmeas")))
  {
      dh(xBmcparam.ucDectReserved_2,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("GreenOffset")))
  {
      dh(xBmcparam.ucDectReserved_3,(uchar8 *)byte_value);
      ifx_httpdWrite (wp, T ("%s"),byte_value);
  }
  else if (!gstrcmp (name, T ("powerlevel")))
  {
      ifx_httpdWrite (wp, T ("%d"),xBmcparam.ucDectReserved_4);
  }
  else if (!gstrcmp (name, T ("poweralgo")))
  {
      ifx_httpdWrite (wp, T ("%d"),xBmcparam.ucDectReserved_5);
  		f_cflag = 0;
  }
	#endif  
return 0;		  
		  
}
#endif		  
