/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_vms.c
 *        Abstract: CGI API's to Access VoiceMail Settings
 *        Date    : 01-06-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"

extern int g_PROFILE_ID_IS;
static char_t f_cflag;
static x_IFX_VMAPI_EventSubscribe xVms;

CGI_ENUMSEL_S web_VMSForward_Types[] =
{
  {0, "None"},
  {1, "Unconditional"},
  {2, "NoAnswer"},
  {3, "Busy"},
};

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_Vms
 *  Description     : This function is called voip_profile_vms.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_Vms (httpd_t wp, char_t * path, char_t * query) 
{
  char_t *pVmsIP = ifx_httpdGetVar (wp, T ("VmsIP"), T (""));
  char_t *pVmsPort = ifx_httpdGetVar (wp, T ("VmsPort"), T (""));
  char_t *pVmsPtl = ifx_httpdGetVar (wp, T ("VmsPtl"), T (""));
  char_t *pVmsExpTime = ifx_httpdGetVar (wp, T ("VmsExpTime"), T (""));
  char_t *pVmsStatus = ifx_httpdGetVar (wp, T ("VmsStatus"), T (""));
  
 
  if (g_PROFILE_ID_IS < 1)
  {
		return;
  }
 
	memset(&xVms,0,sizeof(xVms));
  xVms.ucProfileId = g_PROFILE_ID_IS;
  xVms.ucIndex = 1;
  xVms.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_EventSubscribe(&xVms,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to GET VMS Data from RC.CONF"));
		return ;
  }
 
  if (atoi(pVmsStatus)==1)
  {
    strcpy(xVms.acNotifierAddr,pVmsIP);
    xVms.unNotifierPort = atoi(pVmsPort);
    xVms.unSubscriptionTime = atoi(pVmsExpTime);
    xVms.ucNotifierProtocol = atoi(pVmsPtl);
  }
	else
	{
			memset(xVms.acNotifierAddr,0,sizeof(xVms.acNotifierAddr));
    	xVms.unNotifierPort = 0;
	}
 
  if( IFX_VMAPI_SUCCESS != ifx_set_EventSubscribe(IFX_OP_MOD,&xVms,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to send VMS Data to RC.CONF"));
		return ;
  }
  f_cflag = 0;
  ifx_httpdNextPage_New(wp);

}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_Vms
 *  Description     : This function is called voip_profile_vms.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_Vms (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name = NULL,*mode=NULL;
  char_t sValue[MAX_DATA_LEN];
  int16 nSelIndex = 0, nIndex = 0;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
      ifx_httpdError (wp, 200, T ("Insufficient args\n"));
      return IFX_VMAPI_FAIL;
  }

  if (g_PROFILE_ID_IS < 1)
  {
    return IFX_VMAPI_FAIL;
  }
if(f_cflag == 0){
	memset(&xVms,0,sizeof(xVms));
  xVms.ucProfileId = g_PROFILE_ID_IS;
  xVms.ucIndex = 1;
  xVms.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_EventSubscribe(&xVms,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to GET VMS Data from RC.CONF"));
		return IFX_VMAPI_FAIL;
  }
	f_cflag = 1; 
}
      if (!gstrcmp (name, T ("VmsIP")))
      {
        ifx_httpdWrite (wp, T ("%s"), xVms.acNotifierAddr);
        return 0;
      }
      else if ( !gstrcmp (name, T ("VmsPort")))
      {
		    ifx_httpdWrite(wp, T("%d"), xVms.unNotifierPort);
        return 0;
      }
      else if (!gstrcmp (name, T ("VmsPtl")))
      {

        if (xVms.ucNotifierProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP
             && !strcmp (mode, "1"))
          ifx_httpdWrite (wp, T ("checked"));
        else if (xVms.ucNotifierProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP
             && !strcmp (mode, "2"))
          ifx_httpdWrite (wp, T ("checked"));
        else if (xVms.ucNotifierProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO
             && !strcmp (mode, "0"))
          ifx_httpdWrite (wp, T ("checked"));

        return 0;
      }
      else if ( !gstrcmp(name,T("VmsExpTime")))
      {
        ifx_httpdWrite (wp, T ("%d"), xVms.unSubscriptionTime);
        f_cflag =0;
    		return 0;  
		}
      else if (!gstrcmp (name, T ("VmsStatus")))
      {
	      if (strlen(xVms.acNotifierAddr) > 0)
        {
          nSelIndex = 1;
	      }
	      else
	      {
		      nSelIndex = 0;
	      }
        for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
      
        {
          if (nIndex == nSelIndex)
            gstrcpy (sValue, "selected");
      
          else
             gstrcpy (sValue, "");
	  
             ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
        }
        return 0;
      }
      else if (!gstrcmp (name, T ("VmsStatusQuery")))
      {
	      if (strlen(xVms.acNotifierAddr) > 0)
        {
          nSelIndex = 1;
	      }
	      else
	      {
		      nSelIndex = 0;
	      }
				 if (xVms.ucNotifierProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
					gstrcpy(sValue,"UDP");
				else if (xVms.ucNotifierProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP)
					gstrcpy(sValue,"TCP");
				else  if (xVms.ucNotifierProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO)
						gstrcpy(sValue,"Auto");
        ifx_httpdWrite (wp, T ("\t%s:%s:%d;transport=%s\n"), web_Enum_Status[nSelIndex].str,xVms.acNotifierAddr, xVms.unNotifierPort,sValue);
       /* Reseting the Flag becoz this filed alone can be accesing in Profile summary page */
				f_cflag=0; 
        return 0;
			}

  return 0;
}


