/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_server.c
 *        Abstract: CGI API's to Access SIP Server Settings
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           
 ************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"

extern int g_PROFILE_ID_IS;
static char_t f_cflag;
static x_IFX_VMAPI_ProfileSignaling xProfSig;
static x_IFX_VMAPI_VoiceProfile xVoiceProf;

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_server
 *  Description     : This function is called voip_profile_SIP.asp  page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
int32
ifx_get_voip_sip_server (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];
  int32 nSelIndex = 0, nIndex = 0;
  
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if (g_PROFILE_ID_IS < 1)
		return IFX_VMAPI_FAIL;

  if( f_cflag == 0)
  {

    memset(&xProfSig,0,sizeof(xProfSig));
    xProfSig.ucProfileId = g_PROFILE_ID_IS;
    xProfSig.iid.config_owner = IFX_WEB;
	  if(IFX_VMAPI_SUCCESS != ifx_get_ProfileSignaling(&xProfSig,0))
    {
      ifx_httpdError (wp, 200, T ("Cannot GET Profile Signaling\n"));
      return -1;
    } 
    
    f_cflag = 1;

  }
   
   if (!gstrcmp (name, T ("ProxyStatus")))
   {
     nSelIndex =  xProfSig.bEnableProxy;
     for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
      
     {
       if (nIndex == nSelIndex)
       gstrcpy (sValue, "selected");
      
       else
       gstrcpy (sValue, "");
	  
       ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
     }
		 return 0;
   }
   else if (!gstrcmp (name, T ("ProxyStatusQuery")))
   {
     nSelIndex =  xProfSig.bEnableProxy;
     ifx_httpdWrite (wp, T ("\%s\n"),web_Enum_Status[nSelIndex].str);
     return 0;
   }
   else if (!gstrcmp (name, T ("ProxyStatusQuery1")))
   {
     nSelIndex =  xProfSig.bEnableProxy;
     ifx_httpdWrite (wp, T ("\%d\n"),nIndex);
     return 0;
   }
	 else if ( !gstrcmp (name, T ("ProxyIP")))
   {
	   ifx_httpdWrite(wp,T("%s"), xProfSig.acProxyAddr);
		 return 0;
   }
	 else if ( !gstrcmp (name, T ("ProxyPort")))
   {
	   ifx_httpdWrite(wp, T("%d"), xProfSig.unProxyPort);
		 return 0;
   }
	 else if ( !gstrcmp (name, T ("ProxyPtl"))) 
   {
     if (xProfSig.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP
         && !gstrcmp (mode, "1"))
      ifx_httpdWrite (wp, T ("checked"));
     else if (xProfSig.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP
             && !gstrcmp (mode, "2"))
      ifx_httpdWrite (wp, T ("checked"));
     else if (xProfSig.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO
             && !gstrcmp (mode, "0"))
      ifx_httpdWrite (wp, T ("checked"));
	   return 0;
   }
	 else if ( !gstrcmp (name, T ("ProxyPtlQuery"))) 
   {
     if (xProfSig.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
      ifx_httpdWrite (wp, T ("UDP"));
     else if (xProfSig.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP)
      ifx_httpdWrite (wp, T ("TCP"));
     else if (xProfSig.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO)
      ifx_httpdWrite (wp, T ("Auto"));
	   return 0;
	 }
   else if (!gstrcmp (name, T ("OutbndProxyIP")))
   {
     ifx_httpdWrite (wp, T ("%s"),xProfSig.acOutboundProxyAddr );
		 return 0;
   }
   else if (!gstrcmp (name, T ("OutbndProxyPort")))
   {
     if ((xProfSig.unOutboundProxyPort == 0) && (strlen(xProfSig.acOutboundProxyAddr) == 0)){
        ifx_httpdWrite (wp, T (""));
     }else{
        ifx_httpdWrite (wp, T ("%d"),xProfSig.unOutboundProxyPort );
     }
		 return 0;
   }
	 else if (!gstrcmp (name, T ("RegStatus")))
   {
     nSelIndex = xProfSig.bEnableRegistrar;
     for (nIndex = 0;
           nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
      
     {
       if (nIndex == nSelIndex)
       gstrcpy (sValue, "selected");
      
       else
       gstrcpy (sValue, "");
       ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
     }
		 return 0;
   }
	 else if (!gstrcmp (name, T ("RegStatusQuery")))
   {
     nSelIndex = xProfSig.bEnableRegistrar;
     ifx_httpdWrite (wp, T ("\t%d\n"),nSelIndex);
     return 0;
		}
	 else if (!gstrcmp (name, T ("RegIP")))
   {
	   ifx_httpdWrite(wp, T("%s"), xProfSig.acRegistrarAddr);
		 return 0;
   }
   else if (!gstrcmp (name, T ("RegPort")))
   {
	   ifx_httpdWrite(wp,T("%d"), xProfSig.unRegistrarPort);
		 return 0;
   }
	 else if (!gstrcmp (name, T ("RegPtlQuery")))
   {
     if ( xProfSig.ucRegistrarProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
      ifx_httpdWrite (wp, T ("UDP"));
     else if (xProfSig.ucRegistrarProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP)
     ifx_httpdWrite (wp, T ("TCP"));
     else if ( xProfSig.ucRegistrarProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO)
      ifx_httpdWrite (wp, T ("Auto"));
 	/*Re-setting flag becoz last field accessed from web-page */
			f_cflag = 0;
		 return 0;
   }
   else if (!gstrcmp (name, T ("BackupRegIP")))
   {
	   ifx_httpdWrite(wp, T("%s"), xProfSig.acBackupRegAddr);
		 return 0;
   }
   else if (!gstrcmp (name, T ("BackupRegPort")))
   {
	   ifx_httpdWrite(wp,T("%d"), xProfSig.unBackupRegPort);
		 return 0;
   }
   else if (!gstrcmp (name, T ("BackupRegProtoQuery")))
   {
     if ( xProfSig.ucBackupRegProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
      ifx_httpdWrite (wp, T ("UDP"));
     else if (xProfSig.ucBackupRegProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP)
     ifx_httpdWrite (wp, T ("TCP"));
     else if ( xProfSig.ucBackupRegProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO)
      ifx_httpdWrite (wp, T ("Auto"));
		 return 0;
   }
	// User Agent Part added by Venkat
	else if (!gstrcmp (name, T ("SipServerPort")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSig.unUAPort);
 	/*Re-setting flag becoz last field accessed from web-page */
	   f_cflag = 0;
		return 0;
  }
  else if (!gstrcmp (name, T ("ptl")))
  {
    if (xProfSig.ucUAProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
    {
      ifx_httpdWrite (wp, T("UDP")); 
    }
    else if (xProfSig.ucUAProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP)            
    {
      ifx_httpdWrite (wp, T("TCP")); 
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("domain_name")))
  {
		ifx_httpdWrite(wp, T("%s"), xProfSig.acUADomain);
		return 0;
  }
	// End
   else if (!gstrcmp (name, T ("RegPtl")))
   {
     if ( xProfSig.ucRegistrarProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP 
         &&!gstrcmp (mode, "1"))
      ifx_httpdWrite (wp, T ("checked"));
     else if (xProfSig.ucRegistrarProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP
             &&!gstrcmp (mode, "2"))
      ifx_httpdWrite (wp, T ("checked"));
     else if ( xProfSig.ucRegistrarProtocol == IFX_VMAPI_SIG_TRANSPORT_AUTO
             &&!gstrcmp (mode, "0"))
      ifx_httpdWrite (wp, T ("checked"));
		 return 0;
   }
   else if (!gstrcmp (name, T ("RegExpTime")))
   {
     ifx_httpdWrite (wp, T ("%d"), xProfSig.uiRegExpirationTime);
		
		 return 0;
   }
   else if (!gstrcmp (name, T ("WellKnownSource")))
   {
     nSelIndex = xProfSig.bWellKnownSource;
     for (nIndex = 0;
          nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S); nIndex++)
      
     {
      if (nIndex == nSelIndex)
	    {
	      gstrcpy (sValue, "selected");
	    }
      else
	    {
        gstrcpy (sValue, "");
	    }
       ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_Status[nIndex].value, sValue,
                        web_Enum_Status[nIndex].str);
      }
		}
		else if (!gstrcmp (name, T ("RegRetryTime")))
		{
		ifx_httpdWrite (wp, T ("%d"), xProfSig.unRegRetryTime);
     return 0;
		}
     //g_cflag = 0;
		 return 0;
}
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_server
 *  Description     : This function is called voip_profile_SIP.asp  page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the next page
 ****************************************************************************/
void
ifx_set_voip_sip_server (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pState = ifx_httpdGetVar (wp, T ("profstatus"), T (""));
  //char_t * pStatus = ifx_httpdGetVar (wp, T ("ProxyStatus"), T (""));
  char_t * pIP1 = ifx_httpdGetVar (wp, T ("ProxyIP"), T (""));
  char_t * pOutbndProxyIP = ifx_httpdGetVar (wp, T ("OutbndProxyIP"), T (""));
  char_t * pOutbndProxyPort = ifx_httpdGetVar (wp, T ("OutbndProxyPort"), T (""));
  char_t * pPort = ifx_httpdGetVar (wp, T ("ProxyPort"), T (""));
  char_t * pProtocol = ifx_httpdGetVar (wp, T ("ProxyPtl"), T (""));
  //char_t * RStatus = ifx_httpdGetVar (wp, T ("RegStatus"), T (""));
  char_t * RIP1 = ifx_httpdGetVar (wp, T ("RegIP"), T (""));
  char_t * RPort = ifx_httpdGetVar (wp, T ("RegPort"), T (""));
  char_t * RProtocol = ifx_httpdGetVar (wp, T ("RegPtl"), T (""));
  char_t * RExpTime = ifx_httpdGetVar (wp, T ("RegExpTime"), T (""));
	char_t * pUAProtocol = ifx_httpdGetVar (wp, T ("ptl"), T (""));
	char_t * pSipServerPort = ifx_httpdGetVar (wp, T ("SipServerPort"), T (""));
	char_t * pdomain_name = ifx_httpdGetVar (wp, T ("domain_name"), T (""));
	char_t * pRegRtryTimeOut = ifx_httpdGetVar (wp, T ("RegRtryTimeOut"), T (""));
  char_t * pBackupRegIP = ifx_httpdGetVar (wp, T ("BackupRegIP"), T (""));
  char_t * pBackupRegPort = ifx_httpdGetVar (wp, T ("BackupRegPort"), T (""));
  char_t * pBackupRegProto = ifx_httpdGetVar (wp, T ("BackupRegProto"), T (""));

  if(g_PROFILE_ID_IS < 1)
  {
    return;
  }

  if(xVoiceProf.ucState != atoi(pState))
	{
  	xVoiceProf.ucState = atoi(pState);
		if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0))
  	{
    	ifx_httpdError (wp, 200, "Fail to SET the VoiceProfile (VP Status) !!!");
    	return;
  	}
	}

    memset(&xProfSig,0,sizeof(xProfSig));
    xProfSig.ucProfileId = g_PROFILE_ID_IS;
    xProfSig.iid.config_owner = IFX_WEB;
	  if(IFX_VMAPI_SUCCESS != ifx_get_ProfileSignaling(&xProfSig,0))
    {
      ifx_httpdError (wp, 200, T ("Cannot GET Profile Signaling\n"));
      return ;
    } 
	if(atoi (pRegRtryTimeOut)){
  	xProfSig.unRegRetryTime = atoi (pRegRtryTimeOut);
	}

	strcpy(xProfSig.acProxyAddr, pIP1 );
  xProfSig.unProxyPort = atoi (pPort);
  xProfSig.bEnableProxy = 1; //atoi (pStatus);
	strcpy (xProfSig.acOutboundProxyAddr, pOutbndProxyIP);
	xProfSig.unOutboundProxyPort = atoi (pOutbndProxyPort);
  if (!gstrcmp (pProtocol, "1"))
  {
    xProfSig.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP; 
  }
  else if (!gstrcmp (pProtocol, "2"))
  {
    xProfSig.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_TCP;
  }
  else
  {
    xProfSig.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_AUTO; 
  }


  xProfSig.bEnableRegistrar = 1;//atoi (RStatus);
  strcpy (xProfSig.acRegistrarAddr, RIP1);
  xProfSig.unRegistrarPort = atoi (RPort);
  if (!gstrcmp (RProtocol, "1"))
  {
    xProfSig.ucRegistrarProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP;
  }
  else if (!gstrcmp (RProtocol, "2"))
  {
    xProfSig.ucRegistrarProtocol = IFX_VMAPI_SIG_TRANSPORT_TCP;
  }
  else
  {
    xProfSig.ucRegistrarProtocol = IFX_VMAPI_SIG_TRANSPORT_AUTO; 
  }
  strcpy (xProfSig.acBackupRegAddr, pBackupRegIP);
  xProfSig.unBackupRegPort = atoi (pBackupRegPort);
  if (!gstrcmp (pBackupRegProto, "1"))
  {
    xProfSig.ucBackupRegProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP;
  }
  else if (!gstrcmp (pBackupRegProto, "2"))
  {
    xProfSig.ucBackupRegProtocol = IFX_VMAPI_SIG_TRANSPORT_TCP;
  }
  else
  {
    xProfSig.ucBackupRegProtocol = IFX_VMAPI_SIG_TRANSPORT_AUTO; 
  }
    if(atoi(RExpTime)){
  		xProfSig.uiRegExpirationTime = atoi (RExpTime);
		}
  
	xProfSig.unUAPort = atoi (pSipServerPort);
  if (!gstrcmp (pUAProtocol, "1"))
  {
    xProfSig.ucUAProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP;
  }
  else
  {
    xProfSig.ucUAProtocol = IFX_VMAPI_SIG_TRANSPORT_TCP;
  }
  strcpy(xProfSig.acUADomain, pdomain_name);
	//UA Part - End

  /* Set the proxy and registrar information */
  if(IFX_VMAPI_SUCCESS != ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfSig,0))
  {
    ifx_httpdError (wp, 200, T ("Fail to send Profile Signaling data to VMAPI"));
		return;
  }

  f_cflag = 0;
  ifx_httpdNextPage_New(wp);

}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_profstate
 *  Description     : This function is called voip_profile_SIP.asp & voip_profile_main.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/
int32
ifx_get_voip_sip_profstate (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  char_t sValue[MAX_DATA_LEN];
  int32 nIndex;

  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
 
  if(g_PROFILE_ID_IS < 1)
  {
     return -1;
  }

if(f_cflag == 0){
  xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
  xVoiceProf.iid.config_owner = IFX_WEB;

	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
  {
    ifx_httpdError (wp, 200, "Fail to GET the VoiceProfile (VP Status) !!!");
    return -1;
  }
f_cflag =1;
}

  if (!gstrcmp (name, T ("profstatusquery")))
  {
    ifx_httpdWrite (wp, T ("%s") ,web_Enum_State[xVoiceProf.ucState].str);
	/*Resetting becoz accessing this field as last in diffrent web-pages */
		f_cflag =0;
	}

  if (!gstrcmp (name, T ("profstatus")))
  {
     uint32 ucValue = xVoiceProf.ucState;
      for (nIndex = 0;
          nIndex < sizeof (web_Enum_State) / sizeof (CGI_ENUMSEL_S); nIndex++)
      {
        if (nIndex == ucValue)
          gstrcpy (sValue, "selected");
        else
          gstrcpy (sValue, "");
        ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        web_Enum_State[nIndex].value, sValue,
                        web_Enum_State[nIndex].str);
     }
	/*Resetting becoz accessing this field as last in diffrent web-pages */
		f_cflag =0;

  }

  return IFX_VMAPI_SUCCESS;
}
