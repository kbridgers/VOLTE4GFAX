/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_useragent.c
 *        Abstract: CGI API's to Access SIP UserAgent Param
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
static x_IFX_VMAPI_ProfileSignaling xProfSign;
extern int g_PROFILE_ID_IS;
static char_t f_cflag;
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_useragent
 *  Description     : This function is called add_profile_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the Next Page
 ****************************************************************************/ 
void
ifx_set_voip_sip_useragent (httpd_t wp, char_t * path, char_t * query) 
{
  //char_t * pProtocol = ifx_httpdGetVar (wp, T ("ptl"), T (""));
  char_t * pHdr = ifx_httpdGetVar (wp, T ("hdr"), T (""));
  //char_t * pSipServerPort = ifx_httpdGetVar (wp, T ("SipServerPort"), T (""));
  char_t * pCallOnHold = ifx_httpdGetVar (wp, T ("CallOnHold"), T (""));
  char_t * pUserAgentHeader = ifx_httpdGetVar (wp, T ("UserAgentHeader"), T (""));
  //char_t * pdomain_name = ifx_httpdGetVar (wp, T ("domain_name"), T (""));
	char_t * pTinitial = ifx_httpdGetVar (wp, T ("Tinitial"), T (""));
	char_t * pTmax = ifx_httpdGetVar (wp, T ("Tmax"), T (""));

  
   memset(&xProfSign,0,sizeof(xProfSign));
   xProfSign.ucProfileId = g_PROFILE_ID_IS;
   xProfSign.iid.config_owner = IFX_WEB;
   if(ifx_get_ProfileSignaling(&xProfSign,0) != IFX_VMAPI_SUCCESS)
   {
     ifx_httpdError (wp, 200, T ("Fail to GET Profile Signaling\n"));
     return ;
   }  
  xProfSign.ucCohMethod = atoi (pCallOnHold);
	xProfSign.bUseCompactHdrs = atoi(pHdr);
	xProfSign.unT1 = atoi (pTinitial);
	xProfSign.unTb = atoi (pTmax);					
#if 0
  xProfSign.unUAPort = atoi (pSipServerPort);
  if (!gstrcmp (pProtocol, "1"))
  {
    xProfSign.ucUAProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP;
  }
  else
  {
    xProfSign.ucUAProtocol = IFX_VMAPI_SIG_TRANSPORT_TCP;
  }
  strcpy(xProfSign.acUADomain, pdomain_name);
#endif
  strcpy(xProfSign.acUserAgentHdr, pUserAgentHeader);

  xProfSign.iid.config_owner = IFX_WEB;
  if(ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfSign,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Profile Signaling\n"));
    return ;
  }  
  f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_useragent
 *  Description     : This function is called add_profile_advanced.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_useragent (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];
  int32 nSelIndex = 0, nIndex = 0;

  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
    
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if (g_PROFILE_ID_IS < 1)
		return IFX_VMAPI_FAIL;

  if(f_cflag == 0)
  {
    memset(&xProfSign,0,sizeof(xProfSign));
    xProfSign.ucProfileId = g_PROFILE_ID_IS;
    xProfSign.iid.config_owner = IFX_WEB;
    if(ifx_get_ProfileSignaling(&xProfSign,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Profile Signaling\n"));
      return -1;
    }  
    f_cflag = 1;
  }

  if (!gstrcmp (name, T ("CallOnHold")))
  {
    nSelIndex = xProfSign.ucCohMethod;
    for (nIndex = 0;
           nIndex < sizeof (web_CallOnHold_Types) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
      
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n"),
                        nIndex, sValue, web_CallOnHold_Types[nIndex].str);
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("hdr")))    
  {
		nSelIndex = xProfSign.bUseCompactHdrs;
    for (nIndex = 0;
           nIndex < sizeof (web_Enum_Status) / sizeof (CGI_ENUMSEL_S);
           nIndex++)
      
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s</option>\n") ,
                        nIndex, sValue, web_Enum_Status[nIndex].str);
    }
		return 0;
   }
  else if (!gstrcmp (name, T ("SipServerPort")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSign.unUAPort);
		return 0;
  }
  else if (!gstrcmp (name, T ("ptl")))
  {
    if (xProfSign.ucUAProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP
         && !strcmp (mode, "1"))
    {
      ifx_httpdWrite (wp, T("checked")); 
    }
    else if (xProfSign.ucUAProtocol == IFX_VMAPI_SIG_TRANSPORT_TCP
             && !strcmp (mode, "2"))
    {
      ifx_httpdWrite (wp, T("checked")); 
    }
		return 0;
  }
  else if (!gstrcmp (name, T ("domain_name")))
  {
		ifx_httpdWrite(wp, T("%s"), xProfSign.acUADomain);
		return 0;
  }
  else if (!gstrcmp (name, T ("UserAgentHeader")))
  {
		ifx_httpdWrite(wp, T("%s"), xProfSign.acUserAgentHdr);
    f_cflag = 0;
		return 0;
  }
  return 0;
}


