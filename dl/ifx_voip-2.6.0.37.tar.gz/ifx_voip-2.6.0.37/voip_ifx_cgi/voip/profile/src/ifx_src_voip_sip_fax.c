/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_fax.c
 *        Abstract: CGI API's to Access fax Cfg
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"

extern int g_PROFILE_ID_IS;

int32 ifx_get_voip_sip_fax_array (httpd_t wp);
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_fax_init
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_fax_init (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name;
  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
    
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
  if (!gstrcmp (name, T ("PopulateArray")))
    
  {
    ifx_get_voip_sip_fax_array (wp);
  }
  
  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_fax_array
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_fax_array (httpd_t wp) 
{
  
  x_IFX_VMAPI_FaxT38 xFaxConf;
  
  if (g_PROFILE_ID_IS < 1)
		return IFX_VMAPI_FAIL;

  xFaxConf.ucProfileId = g_PROFILE_ID_IS;
  xFaxConf.iid.config_owner = IFX_WEB;	
  if(ifx_get_ProfileMediaFaxT38(&xFaxConf,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Fax\n"));
    return IFX_VMAPI_FAIL;
  }

	/* TCP array populate */
  ifx_httpdWrite (wp, T ("ARateMgn[1] = %d;\n"), 
									  xFaxConf.ucTCFMethodTcp);
  ifx_httpdWrite (wp, T ("ABitRate[1]= %d;\n"),
                    xFaxConf.uiBitRateTcp);
  ifx_httpdWrite (wp, T ("AMaxBuf[1]=\"0\";\n"));
	ifx_httpdWrite (wp, T ("AMaxDgram[1]=\"0\";\n"));
	ifx_httpdWrite (wp, T ("AErrCorrec[1]=\"0\";\n"));
   
	/* UDP array populate */
  ifx_httpdWrite (wp, T ("ARateMgn[2] = %d;\n"), 
									  xFaxConf.ucTCFMethodUdp);
  ifx_httpdWrite (wp, T ("ABitRate[2]= %d;\n"),
                    xFaxConf.uiBitRateUdp);
	ifx_httpdWrite (wp, T ("AMaxBuf[2]= %d;\n"),
                    xFaxConf.unUDPMaxBufferSize);
	ifx_httpdWrite (wp, T ("AMaxDgram[2]= %d;\n"),
                    xFaxConf.unUDPMaxDatagramSize);
	ifx_httpdWrite (wp, T ("AErrCorrec[2]= %d;\n"),
                    xFaxConf.ucUDPErrCorrection);
   
	
  return 0;
}

/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_fax
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : 
 *                     
 *  Notes           : Redirects to the next page
 ****************************************************************************/ 
void
ifx_set_voip_sip_fax (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pptl = ifx_httpdGetVar (wp, T ("ptl"), T (""));
	IFX_DBG("Protocol : %s",pptl);
  //char_t * pt38Ver = ifx_httpdGetVar (wp, T ("t38Ver"), T (""));
  char_t * prateMgn = ifx_httpdGetVar (wp, T ("rateMgn"), T (""));
  char_t * pbitRate = ifx_httpdGetVar (wp, T ("bitRate"), T (""));
  char_t * pmaxbuf = ifx_httpdGetVar (wp, T ("maxbuf"), T (""));
  char_t * pmaxData = ifx_httpdGetVar (wp, T ("maxData"), T (""));
  char_t * pecRed = ifx_httpdGetVar (wp, T ("ecRed"), T (""));
  char_t * pecFec = ifx_httpdGetVar (wp, T ("ecFec"), T (""));
  //char_t * psPort = ifx_httpdGetVar (wp, T ("sPort"), T (""));
  //char_t * pePort = ifx_httpdGetVar (wp, T ("ePort"), T (""));

  x_IFX_VMAPI_FaxT38 xFaxConf;
  x_IFX_VMAPI_ProfileMediaRTP xRTP;

	memset(&xFaxConf,0,sizeof(xFaxConf));
	memset(&xRTP,0,sizeof(xRTP));

  xRTP.ucProfileId = g_PROFILE_ID_IS;
  xRTP.iid.config_owner = IFX_WEB;	
  if(ifx_get_ProfileMediaRTP(&xRTP,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET RTP\n"));
    return ;
  }  

  xFaxConf.ucProfileId = g_PROFILE_ID_IS;
  xFaxConf.iid.config_owner = IFX_WEB;
  if(ifx_get_ProfileMediaFaxT38(&xFaxConf,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to GET Fax\n"));
    return ;
  }  

	/* Fax Port settings */
  //xRTP.unMinFaxPort = atoi (psPort);
  //xRTP.unMaxFaxPort = atoi (pePort);
  if(ifx_set_ProfileMediaRTP(IFX_OP_MOD,&xRTP,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET RTP\n"));
    return ;
	}

  /* Fax Configuration based on the protocol TCP/UDP */	
  if(gatoi(pptl) == 0) //TCP is selected
	{	
		IFX_DBG("Entering TCP");
	  //xFaxConf.ucTCFMethodUdp = atoi (prateMgn);
    xFaxConf.ucTCFMethodTcp = atoi (prateMgn);
    xFaxConf.uiBitRateTcp = atoi (pbitRate);
    if(ifx_set_ProfileMediaFaxT38(IFX_OP_MOD,&xFaxConf,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to SET Fax\n"));
      return ;
    }
	}	
  if(gatoi(pptl) == 1) //UDP is selected
	{	
		IFX_DBG("Entering UDP");
    xFaxConf.ucTCFMethodTcp = atoi (prateMgn);
	  xFaxConf.ucTCFMethodUdp = atoi (prateMgn);
    xFaxConf.uiBitRateUdp = atoi (pbitRate);
	  xFaxConf.unUDPMaxBufferSize = atoi(pmaxbuf);
	  xFaxConf.unUDPMaxDatagramSize = atoi(pmaxData);
		if(atoi(pecRed))
		  xFaxConf.ucUDPErrCorrection = atoi(pecRed);
		else
		  xFaxConf.ucUDPErrCorrection = atoi(pecFec);
    if(ifx_set_ProfileMediaFaxT38(IFX_OP_MOD,&xFaxConf,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to SET Fax\n"));
      return ;
    }
	}

  //ifx_httpdNextPage (wp);
}


