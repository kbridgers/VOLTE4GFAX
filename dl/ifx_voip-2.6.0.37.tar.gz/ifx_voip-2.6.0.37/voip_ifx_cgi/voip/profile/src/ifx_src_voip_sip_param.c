/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_param.c
 *        Abstract: CGI API's to Access SIP Param
 *        Date    : 25-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


extern int g_PROFILE_ID_IS;
static char_t f_cflag;
static x_IFX_VMAPI_ProfileSignaling xProfSign;
static x_IFX_VMAPI_VoiceProfile xVoiceProf;
/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_param
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the Next Page
 ****************************************************************************/ 
void
ifx_set_voip_sip_param (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pTinitial = ifx_httpdGetVar (wp, T ("Tinitial"), T (""));
  char_t * pTmax = ifx_httpdGetVar (wp, T ("Tmax"), T (""));
  char_t * pRegRtryTimeOut = ifx_httpdGetVar (wp, T ("RegRtryTimeOut"), T (""));
  char_t * pDnsQueryTimeOut = ifx_httpdGetVar (wp, T ("DnsQueryTimeOut"), T (""));
  char_t * pNatKeepAliveTime = ifx_httpdGetVar (wp, T ("NatKeepAliveTime"), T (""));
  char_t * pDSCPMark = ifx_httpdGetVar (wp, T ("DSCPMark"), T (""));

    memset(&xProfSign,0,sizeof(xProfSign));
    xProfSign.ucProfileId = g_PROFILE_ID_IS;
    xProfSign.iid.config_owner = IFX_WEB;
    if(ifx_get_ProfileSignaling(&xProfSign,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Profile Signaling\n"));
      return ;
    }  

    memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
    xVoiceProf.iid.config_owner = IFX_WEB;  
    if(ifx_get_VoiceProfile(&xVoiceProf,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Voice Profile\n"));
      return ;
    }  
  xProfSign.unT1 = atoi (pTinitial);
  xProfSign.unTb = atoi (pTmax);
  xProfSign.unRegRetryTime = atoi (pRegRtryTimeOut);
  xProfSign.unDnsQueryTimeOut = atoi (pDnsQueryTimeOut);
  xProfSign.ucSipDscp = atoi (pDSCPMark);
  
	xVoiceProf.xStunConfig.unNatKeepAliveTime = atoi (pNatKeepAliveTime);

  if(ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfSign,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Profile Signaling\n"));
    return ;
  }  

  if(ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Voice Profile\n"));
    return ;
  }  

  f_cflag = 0;
  ifx_httpdNextPage_New(wp);
}

/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_param
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 
 *  Notes           :
 ****************************************************************************/ 
int
ifx_get_voip_sip_param (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
 
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
    
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if(f_cflag == 0)
  {
    memset(&xProfSign,0,sizeof(xProfSign));
    xProfSign.ucProfileId = g_PROFILE_ID_IS;
    xProfSign.iid.config_owner = IFX_WEB;
    if(ifx_get_ProfileSignaling(&xProfSign,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Profile Signaling\n"));
      return -1;
    }  

    memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
    xVoiceProf.iid.config_owner = IFX_WEB;  
    if(ifx_get_VoiceProfile(&xVoiceProf,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Voice Profile\n"));
      return -1;
    }  
    f_cflag = 1;
  }
   if (!gstrcmp (name, T ("DSCPMark")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSign.ucSipDscp);
		f_cflag=0;
		return 0;
  }

  else if (!gstrcmp (name, T ("Tinitial")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSign.unT1);
		return 0;
  }

  else if (!gstrcmp (name, T ("Tmax")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSign.unTb);
		f_cflag=0;
		return 0;
  }

  else if (!gstrcmp (name, T ("RegRtryTimeOut")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSign.unRegRetryTime);
		return 0;
  }

  else if (!gstrcmp (name, T ("DnsQueryTimeOut")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfSign.unDnsQueryTimeOut);
		return 0;
  }

  else if (!gstrcmp (name, T ("NatKeepAliveTime")))
  {
		ifx_httpdWrite(wp, T("%d"), xVoiceProf.xStunConfig.unNatKeepAliveTime);
		return 0;
  }

  return 0;

}


