/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW WEB Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_media.c
 *        Abstract: CGI API's to Access Media Settings
 *        Date    : 23-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"


static x_IFX_VMAPI_VoiceProfile xVoiceProf;

extern int g_PROFILE_ID_IS;
static char_t f_cflag;
/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_media
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/

int
ifx_get_voip_sip_media (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name, *mode;
  char_t sValue[MAX_DATA_LEN];
  int nSelIndex = 0, nIndex = 0;	
 
 
  if (ifx_httpd_parse_args (argc, argv, T ("%s%s"), &name, &mode) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }

  if(f_cflag == 0 )
  {
    memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(ifx_get_VoiceProfile(&xVoiceProf,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Voice Profile\n"));
      return -1;
    }  
    f_cflag = 1;
  }

  if (!gstrcmp (name, T ("dtmf")))
    
  {
    nSelIndex = xVoiceProf.ucDtmfMethod - 1 ;    
    for (nIndex = 0;
           nIndex < sizeof (web_Dtmf_Types) / sizeof (CGI_ENUMSEL_S); nIndex++)
      
    {
      if (nIndex == nSelIndex)
        gstrcpy (sValue, "selected");
      
      else
        gstrcpy (sValue, "");
      ifx_httpdWrite (wp, T ("\t<option value=\"%d\" %s>%s" 
                               "</option>\n"), nIndex, sValue,
                        web_Dtmf_Types[nIndex].str);
    }
  }
  else if ( !gstrcmp (name, T ("payload")))
  {
		ifx_httpdWrite(wp,T("%d"),   xVoiceProf.ucDtmfPayloadType);
		/*Re-setting the Flag Becoz, this is the last field accesed in web-page voip_profile_Media.asp */
		f_cflag=0;
		return 0;
  }
 
return 0;

}


/*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_media
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Returns to the Next Page
 ****************************************************************************/
void
ifx_set_voip_sip_media (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pDTMF = ifx_httpdGetVar (wp, T ("dtmf"), T (""));
  char_t * pPayload = ifx_httpdGetVar (wp, T ("payload"), T (""));

		memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = g_PROFILE_ID_IS;
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(ifx_get_VoiceProfile(&xVoiceProf,0) != IFX_VMAPI_SUCCESS)
    {
      ifx_httpdError (wp, 200, T ("Fail to GET Voice Profile\n"));
      return ;
    }

  xVoiceProf.ucDtmfMethod = atoi (pDTMF)+ 1;
  xVoiceProf.ucDtmfPayloadType = atoi (pPayload);

  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0) )
  {
        ifx_httpdError (wp, 200, T ("Fail to send Profile Signaling data to VMAPI"));
				
  }
		f_cflag=0;
}

