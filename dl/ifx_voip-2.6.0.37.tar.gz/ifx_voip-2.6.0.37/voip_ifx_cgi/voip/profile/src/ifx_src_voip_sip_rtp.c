/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_src_voip_sip_rtp.c
 *        Abstract: CGI API's to Access Rtp Cfg
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 

************************************************************************/  
#include "ifx_common_cgi.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_common.h"

extern int g_PROFILE_ID_IS;
static char_t f_cflag;
static x_IFX_VMAPI_ProfileMediaRTP xProfMed;
extern void ifx_set_voip_sip_fax (httpd_t wp, char_t * path, char_t * query);
extern void ifx_set_voip_sip_media (httpd_t wp, char_t * path, char_t * query);

 /*****************************************************************************
 *  Function Name   : ifx_set_voip_sip_rtp
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : Redirects to the Next Page
 ****************************************************************************/ 
void
ifx_set_voip_sip_rtp (httpd_t wp, char_t * path, char_t * query) 
{
  char_t * pSPort = ifx_httpdGetVar (wp, T ("sport"), T (""));
  char_t * pEPort = ifx_httpdGetVar (wp, T ("eport"), T (""));
  char_t * pDSCPMark = ifx_httpdGetVar (wp, T ("DSCPMark"), T ("")); //RTP
	char_t * pSIPDSCPMark = ifx_httpdGetVar (wp, T ("SIPDSCPMark"), T ("")); //SIP

	//SIP DSCP Update
	x_IFX_VMAPI_ProfileSignaling xProfSign;
	xProfSign.ucProfileId = g_PROFILE_ID_IS;
 
	 xProfSign.iid.config_owner = IFX_WEB;
	 if(ifx_get_ProfileSignaling(&xProfSign,0) != IFX_VMAPI_SUCCESS)
	 {
		 ifx_httpdError (wp, 200, T ("Fail to GET Profile Signaling\n"));
		 return ;
	 }
	xProfSign.ucSipDscp = atoi (pSIPDSCPMark);
  if(ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfSign,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET Profile Signaling\n"));
    return ;
  }
 
    memset(&xProfMed,0,sizeof(xProfMed));
    xProfMed.ucProfileId = g_PROFILE_ID_IS;
    xProfMed.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_ProfileMediaRTP(&xProfMed,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET RTP\n"));
      return ;
    }  
  xProfMed.unMinRtpPort = atoi (pSPort);
  xProfMed.unMaxRtpPort = atoi (pEPort);
  xProfMed.ucRtpDscp = atoi (pDSCPMark);

	xProfMed.iid.config_owner = IFX_WEB;
  if(ifx_set_ProfileMediaRTP(IFX_OP_MOD,&xProfMed,0) != IFX_VMAPI_SUCCESS)
  {
    ifx_httpdError (wp, 200, T ("Fail to SET RTP\n"));
    return ;
  }  
	ifx_set_voip_sip_fax(wp, path, query);
	ifx_set_voip_sip_media (wp, path, query);
	f_cflag = 0;	 
  ifx_httpdNextPage_New(wp);
}


/*****************************************************************************
 *  Function Name   : ifx_get_voip_sip_rtp
 *  Description     : This function is called voip_profile_Media.asp page
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 0  - Success
 *                    -1 - Failure
 *  Notes           :
 ****************************************************************************/ 
int32
ifx_get_voip_sip_rtp (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  char_t * name = NULL;

  if (ifx_httpd_parse_args (argc, argv, T ("%s"), &name) < 1)
  {
    ifx_httpdError (wp, 200, T ("Insufficient args\n"));
    return -1;
  }
 
  if (g_PROFILE_ID_IS < 1)
		return IFX_VMAPI_FAIL;
  
  if(f_cflag == 0)
  {
    memset(&xProfMed,0,sizeof(xProfMed));
    xProfMed.ucProfileId = g_PROFILE_ID_IS;
    xProfMed.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_ProfileMediaRTP(&xProfMed,0))
    {
      ifx_httpdError (wp, 200, T ("Fail to GET RTP\n"));
      return -1;
    }  
    f_cflag = 1;
  }

  if (!gstrcmp (name, T ("sport")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfMed.unMinRtpPort);
		return 0;
  }

  else  if (!gstrcmp (name, T ("eport")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfMed.unMaxRtpPort);
		return 0;
  }
  else  if (!gstrcmp (name, T ("DSCPMark")))
  {
		ifx_httpdWrite(wp, T("%d"), xProfMed.ucRtpDscp);
		/*Resetting the flag becoz Accessed as last field in web-page voip_profile_Media.asp */
    f_cflag = 0;
		return 0;
  }
  return 0;
}

