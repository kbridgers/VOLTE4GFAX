/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_common_cgi.h
 *        Abstract: CGI fcuntions header file
 *        Date    : 17-05-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 ************************************************************************/
#ifndef	IFX_COMMON_CGI_H
#define	IFX_COMMON_CGI_H

#include "ifx_emf.h"
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "ifx_httpd_method.h"
#include <sys/ioctl.h>
#include <sys/reboot.h>
#include <net/if.h>
#include "ifx_common_defs.h"
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if_arp.h>

#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

/******************************************************************************
 * Defines, Structures and Variables
 ******************************************************************************/ 
#define IFX_WEB_MAX_PB_ENTRIES 100
#define IFX_STANDARD_CHIP "$Id: INCA-IP Standard Chip 1.4 $"
#define IFX_COMPACT_CHIP  "$Id: INCA-IP Compact Chip 1.4 $"
#define IFX_CHIP_COMPACT 1
#define IFX_CHIP_STANDARD 2

#define ifx_httpdNextPage_New(wp) \
{ \
ifx_web_Save_Setting(); \
ifx_httpdNextPage(wp); \
} 

typedef struct 
{
  unsigned int uiOpt;  /* Prefer codec*/
  unsigned char ucIdx;
  unsigned char uacCodec[10];
}
x_WEB_CodecOpt;

/* Web ASP Page select structure */ 
typedef struct 
{
  
  /* Web ASP selected option value index */ 
  unsigned int value;
   
  /* Web ASP selected option value index content */ 
  char_t * str;
 }
CGI_ENUMSEL_S;
#if 1
extern char_t g_nCurrentUserName[12]; /*char_t sCommand[MAX_DATA_LEN]; */
extern char_t g_nCurrentPassword[12]; /* Stores Current loged in password*/
extern int g_nCurrentUserLevel; /*0:admin, 1:common user, 2:general user*/
extern int g_nChipVer;
extern CGI_ENUMSEL_S web_Enum_DebugType[3];
extern CGI_ENUMSEL_S web_Enum_DebugLvl[5];
extern CGI_ENUMSEL_S web_Enum_Status[2];
extern CGI_ENUMSEL_S web_Enum_NatType[10];
extern CGI_ENUMSEL_S web_JitterBufSetting_Types[2];
extern CGI_ENUMSEL_S web_Dtmf_Types[3];
extern CGI_ENUMSEL_S web_Enum_VAD[2];
extern CGI_ENUMSEL_S web_Frame_Sizes[5];
extern CGI_ENUMSEL_S web_Enum_QosYESNOMode[2];
extern CGI_ENUMSEL_S web_Enum_QosZero2SevenMode[8];
extern CGI_ENUMSEL_S web_Enum_QosL2L3Mode[2];
extern CGI_ENUMSEL_S web_Enum_QosHandlingQueuesMode[2];
extern CGI_ENUMSEL_S web_Enum_QosLowHighMode[2];
extern CGI_ENUMSEL_S web_Enum_QosLANPCMode[2];
extern CGI_ENUMSEL_S web_Enum_QosDenyAcceptMode[2];
extern CGI_ENUMSEL_S web_Enum_QosSendTaggedorNoneMode[2];
extern CGI_ENUMSEL_S web_Enum_QosAlltaggedMode[2];
extern CGI_ENUMSEL_S web_Enum_QosONOFFMode[2];
extern CGI_ENUMSEL_S web_Enum_QosZero2TwoMode[3];
extern CGI_ENUMSEL_S web_CallOnHold_Types[2];
extern CGI_ENUMSEL_S web_Enum_Country[6];
extern CGI_ENUMSEL_S web_Enum_GWMode[2];
extern CGI_ENUMSEL_S web_Enum_State[2];
extern CGI_ENUMSEL_S web_PhyInterface_Types[10];
extern CGI_ENUMSEL_S web_Enum_FaxPort[2];
extern CGI_ENUMSEL_S web_TransPower_Txpow[9];
extern CGI_ENUMSEL_S web_TransPower_SWPwrMode[3];
extern CGI_ENUMSEL_S web_dect_CountrySettings[3];
extern CGI_ENUMSEL_S web_Line_Mode[2];
extern CGI_ENUMSEL_S web_Intr[2];
#endif
#ifdef LTAM
//extern CGI_ENUMSEL_S web_Enum_FxsLine[2];

/* Enum describing FXS Lines */
typedef enum
{
  IFX_WAM_FXSLINE_FIRST = 0,
  IFX_WAM_FXSLINE_SECOND
}e_IFX_WAM_FxsLineId;

/* Enum describing Line testing status */
typedef enum
{
	IFX_WAM_TEST_STATUS_NONE = 0,
	IFX_WAM_TEST_STATUS_INPROG 
}e_IFX_WAM_TestStatus;

#endif

#if 0
#define MAX_DATA_LEN 500
  
/*Global variables*/ 
char_t g_nCurrentUserName[12]; /* Store current user name */
char_t g_nCurrentPassword[12]; /* Stores Current loged in password */
int g_nCurrentUserLevel; /*0:admin, 1:common user, 2:general user */
int g_nChipVer;
char_t g_cflag;
char_t g_cCmStatus;/* To Store CM Init Status*/
int PROFILE_ID_IS;
int NO_OF_PROFILE_ID;
int g_LINE_ID_IS;
int FXO_LINE_ID_IS;
int FXS_LINE_ID_IS;
int g_PROFILE_ID_IS;
int g_OPERATION;
int g_FXS;
int g_DECT;
char_t g_NUMPLAN;
int PHY_FXS_LINE_ID_IS;
int PHY_FXO_LINE_ID_IS;

/* Enumerations */ 
CGI_ENUMSEL_S web_Enum_Status[2] =
{
  {0, "OFF"}, 
  {1, "ON"},
};

CGI_ENUMSEL_S web_Enum_State[2] =
{
  {0, "Disabled"}, 
  {1, "Enabled"},
};

CGI_ENUMSEL_S web_Enum_GWMode[2] =
{
  {0, "GW"}, 
  {1, "FW"},
};

CGI_ENUMSEL_S web_Enum_Country[6] =
{
  {0, "USA"}, 
  {1, "GERMANY"},
  {2, "CHINA"},
  {3, "TAIWAN"},
  {4, "INDIA"},
  {5, "JAPAN"}
};

CGI_ENUMSEL_S web_Enum_DebugType[3] =
{
  {0, "NONE"}, 
  {1, "CONSOLE"}, 
  {2, "FILE"},
};

CGI_ENUMSEL_S web_Enum_DebugLvl[5] =
{
  { 0, "NONE"}, 
  { 1, "ERROR"}, 
  { 2, "LOW"}, 
  { 3, "NORMAL"}, 
  { 4, "HIGH"},
};

CGI_ENUMSEL_S web_Enum_NatType[10] =
{
  {0, "OPEN"}, 
  {1, "FULL CONE"}, 
  {2, "RESTRICT"}, 
  {3, "PORT RESTRICT"}, 
  {4, "SYMMETRIC"}, 
  {5, "FIREWALL"}, 
  {6, "BLOCK"}, 
  {7, "UNKNOWN"}, 
  {8, "HAIRPIN"}, 
  {9, "NO NAT"},
};

CGI_ENUMSEL_S web_Enum_VAD[2] =
{
  {0, "OFF"}, 
  {1, "ON"},
};

CGI_ENUMSEL_S web_JitterBufSetting_Types[2] =
{
  {1, "Fixed"}, 
  {2, "Adaptive"},
};

CGI_ENUMSEL_S web_Dtmf_Types[3] =
{
  {1, "RFC 2833 Event"}, 
  {2, "In Band Voice"}, 
  {3, "INFO"},
};

CGI_ENUMSEL_S web_Frame_Sizes[4] =
{
  {5, "5"}, 
  {10, "10"}, 
  {20, "20"}, 
  {30, "30"},
};

CGI_ENUMSEL_S web_TelSpec[4] =
{
  {1, "Generic"}, 
  { 2, "ETSI"} , 
  { 3, "Germany"} , 
  { 4, "USA"},
};

CGI_ENUMSEL_S web_CallOnHold_Types[2] =
{
  
  {0, "Connection Address ( 0.0.0.0)"}, 
  {1, "RFC 3264 Compliant"}
};

#endif


/******************************************************************************
 * Functions
 ******************************************************************************/ 
void http_print (char *buff);
int ifx_web_Save_Setting (void);
void ifx_httpdNextPage (httpd_t wp);
extern int ifx_httpd_parse_args(int argc, char_t **argv, char_t *fmt, ...);
void ifx_httpdNextPageFail (httpd_t wp);
int ifx_get_currentUser_authority_CGI (int eid, httpd_t wp, int argc,
                                         char_t ** argv);
void ifx_get_currentUser_authority (int eid, httpd_t wp, int argc,
                                     char_t ** argv);

int
ifx_ParseString (uchar8 * ucSrc, uchar8 * ucDestList, uchar8 * iLength) ;

int
IFX_WEB_GetInterfaceId (char_t * pcPattern, uchar8 *uiId);

int
IFX_WEB_GetInterfaceName (uchar8 uiId, char8 *pcName);

void IFX_CGI_DEBUG(const char8* pszFmt, ...);
unsigned char hd(unsigned char *s);
void dh(unsigned char n,unsigned char *val);
#endif  /* IFX_COMMON_CGI_H */
  
