/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : DECT-NG-GW - Web Module
 *        Block   :  
 *        Creator : 
 *        File    : ifx_common_cgi.c
 *        Abstract: common cgi functions
 *        Date    : 17-06-2007
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 ************************************************************************/  
#include "ifx_common_cgi.h"
  
#ifdef DMALLOC
#include "dmalloc.h"
#endif  

#ifndef MAX_DATA_LEN
#define MAX_DATA_LEN 500
#endif
  
/*Global variables*/ 
char_t g_nCurrentUserName[12]; /* Store current user name */
char_t g_nCurrentPassword[12]; /* Stores Current loged in password */
int g_nCurrentUserLevel; /*0:admin, 1:common user, 2:general user */
int g_nChipVer;
char_t g_cflag;
char_t g_cCmStatus;/* To Store CM Init Status*/
int PROFILE_ID_IS;
int NO_OF_PROFILE_ID;
int g_LINE_ID_IS;
int FXO_LINE_ID_IS;
int FXS_LINE_ID_IS;
int g_PROFILE_ID_IS;
int g_OPERATION;
int g_FXS;
int g_DECT;
int g_CALLFWD;
int g_DIAGMODE;
char_t g_NUMPLAN[15];
int PHY_FXS_LINE_ID_IS;
int PHY_FXO_LINE_ID_IS;
int g_EDIT_CONTACT_CPEID_IS;
int  g_EDIT_CONTACT_IS_COMMON;
int g_SENSOR_CPEID;
int g_SENSOR_TYPE;
int g_SENSOR_LIST_TYPE;
int g_SENSOR_READ_LIST;
char_t gcFXSLineId_UnderTest;
char_t gcTestStatus;
uint32  guiTestExp_Timer;

/* Enumerations */ 
CGI_ENUMSEL_S web_Enum_Status[2] =
{
  {0, "OFF"}, 
  {1, "ON"},
};

CGI_ENUMSEL_S web_Enum_State[2] =
{
  {0, "Disabled"}, 
  {1, "Enabled"},
};

CGI_ENUMSEL_S web_Enum_GWMode[2] =
{
  {0, "FW"}, 
  {1, "GW"},
};

CGI_ENUMSEL_S web_Enum_Country[6] =
{
  {0, "USA"}, 
  {1, "GERMANY"},
  {2, "CHINA"},
  {3, "TAIWAN"},
  {4, "INDIA"},
  {5, "JAPAN"}
};

CGI_ENUMSEL_S web_Enum_DebugType[3] =
{
  {0, "NONE"}, 
  {1, "CONSOLE"}, 
  {2, "FILE"},
};

CGI_ENUMSEL_S web_Enum_DebugLvl[5] =
{
  { 0, "NONE"}, 
  { 1, "ERROR"}, 
  { 2, "LOW"}, 
  { 3, "NORMAL"}, 
  { 4, "HIGH"},
};

CGI_ENUMSEL_S web_Enum_NatType[10] =
{
  {0, "OPEN"}, 
  {1, "FULL CONE"}, 
  {2, "RESTRICT"}, 
  {3, "PORT RESTRICT"}, 
  {4, "SYMMETRIC"}, 
  {5, "FIREWALL"}, 
  {6, "BLOCK"}, 
  {7, "UNKNOWN"}, 
  {8, "HAIRPIN"}, 
  {9, "NO NAT"},
};

CGI_ENUMSEL_S web_Enum_VAD[2] =
{
  {0, "OFF"}, 
  {1, "ON"},
};

CGI_ENUMSEL_S web_JitterBufSetting_Types[2] =
{
  {1, "Fixed"}, 
  {2, "Adaptive"},
};

CGI_ENUMSEL_S web_Dtmf_Types[3] =
{
  {1, "In Band Voice"}, 
  {2, "RFC 2833 Event"}, 
  {3, "SIP INFO"},
};

CGI_ENUMSEL_S web_Frame_Sizes[5] =
{
  {10, "10"}, 
  {20, "20"}, 
  {30, "30"},
  {40, "40"},
  {60, "60"},
};

CGI_ENUMSEL_S web_TelSpec[4] =
{
  {1, "Generic"}, 
  { 2, "ETSI"} , 
  { 3, "Germany"} , 
  { 4, "USA"},
};

CGI_ENUMSEL_S web_CallOnHold_Types[2] =
{
  
  {0, "Connection Address ( 0.0.0.0)"}, 
  {1, "RFC 3264"}
};

CGI_ENUMSEL_S web_PhyInterface_Types[10] =
{
  
  {0, "None"}, 
  {1, "Phone1"}, 
  {2, "Phone2"},
  {3, "FXO"},
  {4, "Handset1"},
  {5, "Handset2"},
  {6, "Handset3"},
  {7, "Handset4"},
  {8, "Handset5"},
  {9, "Handset6"},
};

CGI_ENUMSEL_S web_Enum_FaxPort[2] =
{
  {1, "Phone 1"}, 
  {2, "Phone 2"},
};
CGI_ENUMSEL_S web_TransPower_Txpow[9] =
{
  {0, "Full Power Mode"}, 
  {1, "-5 dB"}, 
  {2, "-10 dB"},
  {3, "-15 dB"},
  {4, "-20 dB"},
  {5, "-25 dB"},
  {6, "-30 dB"},
  {7, "Minimum Power Mode"},
  {8, "User Mode"},
};
CGI_ENUMSEL_S web_TransPower_SWPwrMode[3]=
{
   {0, "Constant Power Mode"},
   {1, "Adaptive Mode"},
   {3, "User Mode"}
};

CGI_ENUMSEL_S web_dect_CountrySettings[3]=
{
   {0,"EU"},
   {1,"Latin"},
   {2,"US"}
};
		 
CGI_ENUMSEL_S web_Line_Mode[2] =
{
  {0, "Single Call"}, 
  {1, "Multi Call"},
};
CGI_ENUMSEL_S web_Intr[2] =
{
  {0, "Not Allowed"}, 
  {1, "Allowed"},
};

#ifdef LTAM
#endif /*LTAM*/

/***************************** Common API ********************************/ 
/*****************************************************************************
* Function Name: http_print
* Description  : print on console
* Input Value  : String
* Output Value :
* Return Value : void
* Notes :
*****************************************************************************/ 
void 
http_print (char *buff) 
{
  FILE * con;// = NULL;
  con = fopen ("/dev/console", "a");
//	if (con == NULL)
	//	return;
  fprintf (con, buff);
  fflush (con);
  fclose (con);
}


unsigned char hd(unsigned char *s)
{
 int i,a[20];
 unsigned long int m=1;
 unsigned char h=0;
 for(i=0;s[i]!=0;i++)
 {
  switch(s[i])
  {
	case '0':
	      a[i]=0;
	      break;
	case '1':
	      a[i]=1;
	      break;
	case '2':
	      a[i]=2;
	      break;
	case '3':
	     a[i]=3;
	     break;
	case '4':
	     a[i]=4;
	     break;
	case '5':
	     a[i]=5;
	     break;
	case '6':
	     a[i]=6;
	     break;
	case '7':
             a[i]=7;
	     break;
    	case '8':
	     a[i]=8;
	     break;
    	case '9':
	    a[i]=9;
	    break;
   	case 'a': 
   	case 'A':
	    a[i]=10;
	    break;
   	case 'b': 														      case 'B':
           a[i]=11;															 break; 
        case 'c':
        case 'C': 
          a[i]=12;
          break; 
       case 'd': 
       case 'D': 
         a[i]=13;
         break;
      case 'e':
      case 'E': 														      a[i]=14; 
        break;
      case 'f':
      case 'F': 														      a[i]=15; 
        break;
  }
}
 i--;
 for(;i>=0;i--){
   h=h+a[i]*m;
   m=m*16;
   }
  return h;
}
void dh(unsigned char n,unsigned char *val)
{
  unsigned char i;
  volatile static unsigned char j;
  volatile static unsigned char c;
  //unsigned char val[3];

  j=0;
  c++;
  if(n>0){
  i=n%16;
  n=n/16;
  dh(n,val);
  if(i>=10)
  {
         switch(i)
          {
              case 10:
                //printf("A");
                val[j++]='A';
                break;
              case 11:
                //printf("B");
                val[j++]='B';
                 break;
              case 12:
                //printf("C");
                val[j++]='C';
                break;
              case 13:
                 //printf("D");
                 val[j++]='D';
                 break;
              case 14:
                 //printf("E");
                 val[j++]='E';
                 break;
              case 15:
                 //printf("F");
                 val[j++]='F';
                 break;
        }
 }

 else
 sprintf((char8 *)&val[j++],"%d",i);

  }else if((n == 0)&&(c == 1)){
    sprintf((char8 *)&val[j++],"%d",n);
   }
 c=0;
}

/*****************************************************************************
* Function Name: ifx_web_Save_Setting
* Description  : save configuration data 
* Input Value  : 
* Output Value :
* Return Value : 0:Fail 1: Success
* Notes	:
*****************************************************************************/ 
int 
ifx_web_Save_Setting (void) 
{
  
  /* save system configuration data */ 
  system ("/etc/rc.d/backup");
  return 1;
}


/*****************************************************************************
* Function Name: ifx_httpdNextPage
* Description  : Redirect to next page if success
* Input Value  :
* Output Value :
* Return Value : void
* Notes :
*****************************************************************************/ 
void 
ifx_httpdNextPage (httpd_t wp) 
{
  /* Redirect next page */ 
  char_t * pNextPageUrl;
  pNextPageUrl = ifx_httpdGetVar (wp, T ("page"), T (""));
  if (pNextPageUrl && *pNextPageUrl)
  {
    ifx_httpdRedirect (wp, pNextPageUrl);
  }
  else
  {
    ifx_httpdDone (wp, 200);
  }
}


/*****************************************************************************
* Function Name: ifx_httpdNextPageFail
* Description  : Redirect to next page if failure
* Input Value  :
* Output Value :
* Return Value : void
* Notes :
*****************************************************************************/ 
void 
ifx_httpdNextPageFail (httpd_t wp) 
{
  
  /* Redirect next page */ 
  char_t * pNextPageUrl = ifx_httpdGetVar (wp, T ("page-fail"), T (""));
  if (pNextPageUrl && *pNextPageUrl)
    ifx_httpdRedirect (wp, pNextPageUrl);
  else
    ifx_httpdDone (wp, 200);
}


/*******************************************************************************
 *  Function Name : IFX_ValidateIpAddress
 *  Description   :This function Check the IP Address.
 *  Invoked Fns   :
 *  Input Values  :char *
 *  Output Values :
 *  Return Value  : void
 *  Note          :
 * ******************************************************************************/ 
char 
IFX_ValidateIpAddress (unsigned char *pszBuff) 
{
  int iCount = 0, iDotCount = 0,iCount1=0;
  char acTemp[4];
  while (*pszBuff != '\0')
  {
    if (*pszBuff == '.')
    {
      iDotCount++;
      acTemp[iCount] = '\0';
      if ((iCount > 0) && (atoi (acTemp) < 256))
      {
		if (iCount1 == 0 && atoi (acTemp) < 1)
		{
		  return -1;
		}
        memset (acTemp, '\0', 4);
        iCount = 0;
		iCount1++;
        pszBuff++;
      }
      else
      {
        return -1;
      }
    }
    else
    {
      if (!isdigit (*pszBuff))
      {
        return -1;
      }
      acTemp[iCount++] = *pszBuff;
      pszBuff++;
      if (iCount > 3)
      {
        return -1;
      }
    }
  }
  if (iCount < 1 || atoi (acTemp) > 255 || iDotCount != 3)
  {
    return -1;
  }
  return 0;
}

/*******************************************************************************
 *  Function Name : ifx_get_currentUser_authority
 *  Description   : This function get the user levcl
 *  Invoked Fns   :
 *  Input Values  :
 *  Output Values :
 *  Return Value  : void
 *  Note          :
 * ******************************************************************************/
void inline 
ifx_get_currentUser_authority (int eid, httpd_t wp, int argc, char_t ** argv) 
{
  if (g_nCurrentUserLevel == 0)
    ifx_httpdWrite (wp, T ("0"));
  
  else if (g_nCurrentUserLevel == 1)
    ifx_httpdWrite (wp, T ("1"));
  
  else
    ifx_httpdWrite (wp, T ("2"));
  return;
}

/*******************************************************************************
 *  Function Name : ifx_set_voip_flash_write
 *  Description   : This function writes voip settings to flash.Function called
 *                  from Voip Sub Page voip_flash_write.htm.
 *  Invoked Fns   :
 *  Input Values  :
 *  Output Values :
 *  Return Value  : void
 *  Note          :
 * ******************************************************************************/
void
ifx_set_voip_flash_write (httpd_t wp, char_t * path, char_t * query)
{
   system("/etc/rc.d/backup");
   ifx_httpdNextPage (wp);
}

/*******************************************************************************
 *  Function Name : ifx_ParseString 
 *  Description   : This function parses the comma seperated string.
 *  Invoked Fns   :
 *  Input Values  :ucSrc
 *  Output Values :ucDestList- parsed string
 *                 iLength- number of elements in the list
 *  Return Value  : void
 *  Note          :
 * ******************************************************************************/
int
ifx_ParseString (uchar8 * ucSrc, uchar8 * ucDestList, uchar8 * iLength) 
{
  int index = 0, i = 0, j = 0;
  while (ucSrc[index] != '\0')
    
  {
    if (ucSrc[index] != ',')
      
    {
      *(ucDestList + (i * 32) + j) = ucSrc[index];
      j++;
    }
    
    else
      
    {
      *(ucDestList + (i * 32) + j) = '\0';
      i++;
      j = 0;
    }
    index++;
  }
  *iLength = i + 1;
  return 0;
}

/*******************************************************************************
 *  Function Name : IFX_WEB_GetInterfaceId 
 *  Description   : This function maps the Physical Interface name with it Interface Id.
 *  Invoked Fns   :
 *  Input Values  : pcPattern - pattern to be matched
 *                :  
 *  Output Values : uiId - Interfae Id
 *  Return Value  : 0 - for SUCCESS
 *                : -1 - for FAILURE
 *  Note          :
 * ******************************************************************************/
int
IFX_WEB_GetInterfaceId (char_t * pcPattern, uchar8 *uiId)
{
	int32 nIndex=0;
#if defined(DECT_SUPPORT)||defined(CVOIP_SUPPORT)
	x_IFX_VMAPI_DectHandset xDectHandset;
	int32 ucFlag = 0;
#endif
  for (nIndex = 0;
        nIndex < sizeof (web_PhyInterface_Types) / sizeof (CGI_ENUMSEL_S) - 6; nIndex++)
  {
    if (!gstrcmp (web_PhyInterface_Types[nIndex].str,pcPattern))
		{			
      *uiId = web_PhyInterface_Types[nIndex].value;
#if defined(DECT_SUPPORT)||defined(CVOIP_SUPPORT)
			ucFlag = 1;
#endif
		  break;
		}
	}
#if defined(DECT_SUPPORT)||defined(CVOIP_SUPPORT)
if(!ucFlag)
{

  for (nIndex = 4; nIndex < 10; nIndex++){
					memset(&xDectHandset,0,sizeof(xDectHandset));
				  xDectHandset.xVoiceServPhyIf.ucInterfaceId = nIndex;
			  	xDectHandset.iid.config_owner = IFX_WEB;
		  	if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
  			{
    			return -1;
  			}
				if(!gstrcmp( (char8 *)xDectHandset.ucEndPtName,pcPattern)){
    				  *uiId = xDectHandset.xVoiceServPhyIf.ucInterfaceId ;
						  break;
				}	
	}
}
#endif
	return 0;
}	

/*******************************************************************************
 *  Function Name : IFX_WEB_GetInterfaceName 
 *  Description   : This function maps the Interface Id with the Interface name.
 *  Invoked Fns   :
 *  Input Values  : uiId - Interface Id to be matched
 *                :  
 *  Output Values : pcName - Interfae Name
 *  Return Value  : 0 - for SUCCESS
 *                : -1 - for FAILURE
 *  Note          :
 * ******************************************************************************/
int
IFX_WEB_GetInterfaceName (uchar8 uiId, char8 *pcName)
{
	int32 nIndex=0;
#if defined(DECT_SUPPORT)||defined(CVOIP_SUPPORT)
	x_IFX_VMAPI_DectHandset xDectHandset;
  if(uiId >=1 && uiId <=3 ){
#endif
	for (nIndex = 0;
        nIndex < sizeof (web_PhyInterface_Types) / sizeof (CGI_ENUMSEL_S); nIndex++)
  {
    if (web_PhyInterface_Types[nIndex].value == uiId)
		{			
      strcpy(pcName,web_PhyInterface_Types[nIndex].str);
		  break;
		}
	}
#if defined(DECT_SUPPORT)||defined(CVOIP_SUPPORT)
}else if(uiId >=4 && uiId<=9){
	memset(&xDectHandset,0,sizeof(xDectHandset));
  xDectHandset.xVoiceServPhyIf.ucInterfaceId = uiId;
  xDectHandset.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
  {
    return -1;
  }
      strcpy(pcName,(char8 *)xDectHandset.ucEndPtName);
	
}
#endif
return 0;
}	

/*******************************************************************************
 *  Function Name : IFX_WEB_IfEndPtIdExist 
 *  Description   : This function maps the Interface Id with the Interface name.
 *  Invoked Fns   :
 *  Input Values  : uiId - Interface Id to be matched
 *                :  
 *  Output Values : pcName - Interfae Name
 *  Return Value  : 0 - for SUCCESS
 *                : -1 - for FAILURE
 *  Note          :
 * ******************************************************************************/
int
IFX_WEB_IfEndPtIdExist (httpd_t wp, uchar8 *pucEndPtId)
{
	int32 nIndex=0;
	int32 iRet= IFX_VMAPI_SUCCESS;
	x_IFX_VMAPI_VoiceServPhyIf xVoiceIf;
	x_IFX_VMAPI_FxsPhyIf xFxsIf;
	x_IFX_VMAPI_FxoPhyIf xFxoIf;
 	while(nIndex != (IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS))  
  {
		memset(&xVoiceIf, 0, sizeof(xVoiceIf));
		xVoiceIf.ucInterfaceId = nIndex+1; 
		iRet = ifx_get_VoicePhyInterface(&xVoiceIf , 0);
		if(iRet != IFX_VMAPI_SUCCESS)
		{
      ifx_httpdError (wp, 200, T ("ifx_get_VoicePhyInterface failed\n"));
      return -1;
		}
		
	  if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_FXS)
		{
		  memset(&xFxsIf, 0, sizeof(xFxsIf));
			xFxsIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
      iRet = ifx_get_FxsPhyInterface(&xFxsIf , IFX_F_DEFAULT);
      if(iRet != IFX_VMAPI_SUCCESS)
		  {
        ifx_httpdError (wp, 200, T ("ifx_get_FxsPhyInterface failed\n"));
        return IFX_VMAPI_FAIL;
		  }
			if(strcmp((char8 *)xFxsIf.ucEndPtId , (char8 *)pucEndPtId) == 0)
			{
        ifx_httpdError (wp, 200, T ("FXS EndPtId Exists\n"));
        return IFX_VMAPI_FAIL;
				
			}
		}

		if(xVoiceIf.ucPortType == IFX_VMAPI_VOICE_PORT_TYPE_FXO)
		{
		  memset(&xFxoIf, 0, sizeof(xFxoIf));
			xFxoIf.xVoiceServPhyIf.ucInterfaceId = nIndex+1;
      iRet = ifx_get_FxoPhyInterface(&xFxoIf , 0);
      if(iRet != IFX_VMAPI_SUCCESS)
		  {
        ifx_httpdError (wp, 200, T ("ifx_get_FxoPhyInterface failed\n"));
        return IFX_VMAPI_FAIL;
		  }
			if(strcmp((char8 *)xFxoIf.ucEndPtId , (char8 *)pucEndPtId) == 0)
			{
        ifx_httpdError (wp, 200, T ("FXO EndPtId Exists\n"));
        return IFX_VMAPI_FAIL;
				
			}

		}	

 	  nIndex++; 
  }

	return IFX_VMAPI_SUCCESS;
}	

#if 1 
void
IFX_CGI_DEBUG(const char8* pszFmt, ...)
{
	va_list ArgList;
	FILE* fp = 0;

	if((fp = fopen("/flash/CGI_Log.txt","a")))
	{
  	va_start(ArgList, pszFmt);
  	vfprintf(fp, pszFmt, ArgList);
		fclose(fp);
	}
}
#else
#define IFX_CGI_DEBUG 
#endif

