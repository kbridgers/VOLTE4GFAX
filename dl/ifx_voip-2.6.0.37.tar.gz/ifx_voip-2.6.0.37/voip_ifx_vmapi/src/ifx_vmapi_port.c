/**************************************************************************
 **   FILE NAME       : ifx_vmapi_port.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Voice Management API Porting File
 **   SRC VERSION     : V0.1
 **   DATE            : 27-09-2006
 **   AUTHOR          : Prashant
 **   DESCRIPTION     : This file contains the portable elements in VMAPI.
 **											This file is to be used together with ifx_vmapi_port.h
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include <stdarg.h>
#include "ifx_vmapi_port.h"
#include "ifx_debug.h"

uchar8 ucVMAPIModuleId; /* For Debug Settings */
//EXTERN uchar8 vcCmModId; /* CM debug variable is used in VMAPI as well */
/******************************************************************************
*  Function Name  : IFX_VMAPI_DbgInit
*  Description    : Initializes the debug-settings for VMAPI
*  Input Values   : ucDbgType - Debug type
*										ucDbgLvl - Run time debug level
*  Output Values  : pcRet - return value of the Init call
*  Return Value   :
*  Notes          : 
******************************************************************************/
VOID IFX_VMAPI_DbgInit(
             IN char8 cDbgType,
             IN char8 cDbgLvl,
             OUT char8 *pcRet)
{
	//ucVMAPIModuleId = vcCmModId;
	IFX_DBG_Init("VMAPI", cDbgType, cDbgLvl, &ucVMAPIModuleId, pcRet);
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_DbgLvlSet
*  Description    : Sets the Debug settings at run-time
*  Input Values   : iDbgType - Debug type
*										ucDbgLvl - Run time debug level
*  Output Values  : 
*  Return Value   :
*  Notes          : 
******************************************************************************/
VOID IFX_VMAPI_DbgLvlSet(char8 cDbgType, char8 cDbgLvl)
{
	IFX_DBG_Set("CfgMod"/*VMAPI"*/, ucVMAPIModuleId, cDbgType, cDbgLvl);
}

/****************************************************************************/

void IFX_VMAPI_DBG(int ucVMAPIModuleId,
								   int ErrLevel,
									 char *acFunName,
					 				 char *acFormatStr,
            			 ...)
{

#if 0
  char acBuffer[4096];
  va_list vaList;
  va_start(vaList,acFormatStr);
  sprintf(acBuffer,"<VMAPI: %s> ",acFunName);
	vsprintf(acBuffer + strlen(acBuffer),acFormatStr,vaList);
  printf(acBuffer);
#endif

}
#if 0
PUBLIC void
IFX_VDBG_Log(IN uchar8 ucModuleId,
            IN uchar8 ucDbgLvl,
						IN char8 * pucFuncName,
            IN char8 * pucStr,
            ...)
{
   va_list ArgList;
   char8 cAppendStr[512];
   char8 cLogStr[512];
   int16 nFd = 0;

   if (vaxRegInfo[ucModuleId - 1].ucDbgLvl >= ucDbgLvl)
   {
      va_start(ArgList, pucStr);
#ifdef DBG_TIMESTAMP
      sprintf(cAppendStr, "<%lu> [%s] <%s> %s", ulTime, 
          vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#else
      sprintf(cAppendStr, "[%s] <%s> %s", 
             vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#endif
      
      
      if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_CONSOLE)
      {
         vprintf(cAppendStr, ArgList);
      }
      else if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_FILE)
      {
         vsprintf(cLogStr, cAppendStr, ArgList);
         if ((nFd = open(vaxRegInfo[ucModuleId - 1].cLogFileName, 
                             O_WRONLY | O_APPEND, 0777)) < 0)
         {
           printf("Error opening log file\n");
           return;
         }

         if (write(nFd, cLogStr, strlen(cLogStr)) < 0)
         {
           printf("Error writing to log file\n");
           return;
         }
         close(nFd);
      }
      va_end(ArgList);
      return;
   }
   else
   {
      return;
   }
   return;
}
#endif
