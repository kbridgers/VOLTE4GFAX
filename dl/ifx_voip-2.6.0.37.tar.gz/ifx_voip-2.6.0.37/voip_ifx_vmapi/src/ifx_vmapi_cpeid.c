/**************************************************************************
 **   FILE NAME       : ifx_vmapi_cpeid.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Applications requiring cpeId
 **   SRC VERSION     : V1.0
 **   DATE            : 14-06-2007
 **   AUTHOR          : 
 **   DESCRIPTION     : This file defines the mechanism for maintaining
 **											the cpeId for the use of applications reequired
 **											to call the VMAPI ifx_get* and ifx_set* APIs.
 **   FUNCTIONS       : IFX_VMAPI_Get_CpeId
 **											IFX_VMAPI_Update_CpeId								
 **											IFX_VMAPI_Get_NextCpeId
 **											
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_vmapi_cpeid.h"

  FILE *file,*fp,*fArr;
  int32 iRet,i,j;
  uint32 uiCpe;
  uint32 outFlag = 0;
  uint32 uiInFlag = 0;
//  char8 acInBuf[MAX_FILELINE_LEN] = {0};
//  char8 acCommand[MAX_FILELINE_LEN] = {0};
  char8 pucIdList[200];
  char8 pucIdList1[100][5];
  uchar8 ucNoOfIds;
//  char8 PArray[300]={0};
//  char8 NVArray[300]={0};


  /* Arrays are used to store the cpeId of the objects for a given type of 
	object */
#if 0
  uint32 uiVoicePhy[IFX_VMAPI_MAX_PHY_ENDPTS];
  uint32 uiFxs[IFX_VMAPI_MAX_FXS_ENDPTS];
  uint32 uiFxo[IFX_VMAPI_MAX_FXO_ENDPTS];
  uint32 uiDect[IFX_VMAPI_MAX_DECT_ENDPTS];
  uint32 uiAddrEntry[IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES];
  uint32 uiCallBlockEntry[IFX_VMAPI_MAX_CALL_BLK_ENTRIES];
  uint32 uiNumPlanRule[IFX_VMAPI_MAX_NUM_PLAN_RULES];

  uint32 uiProfile[IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiProfileSerProvider[IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiProfileSignaling[IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiProfileEventSubscr[IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiProfileEventSubscrEntry[IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_SUBSCR_ELMNTS];
  uint32 uiProfileRTP[IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiProfileRTCP[IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiProfileFAX[IFX_VMAPI_MAX_VOICE_PROFILES];

  uint32 uiVoiceLine[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineSignaling[IFX_MAX_VOICE_LINES*IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineAuthCfg[IFX_MAX_VOICE_LINES *IFX_VMAPI_MAX_AUTH_INFO];
  uint32 uiLineVoiceCodec[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineCodecList[IFX_MAX_VOICE_LINES* IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineCodecListEntry[87];
  //uint32 uiLineCodecListEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_CODECS];
  uint32 uiLineCallFeat[IFX_MAX_VOICE_LINES* IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineVoiceSession[IFX_MAX_VOICE_LINES* IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineVoiceProcessing[IFX_MAX_PROFILES*IFX_MAX_VOICE_LINES];
  uint32 uiLineSubscr[IFX_MAX_VOICE_LINES* IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiLineSubscrEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_SUBSCR_ELMNTS];
#ifdef MESSAGE_SUPPORT
  uint32 uiMsgIn[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiMsgInEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_MSG_IN_ENTRIES];
  uint32 uiMsgOut[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiMsgOutEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_MSG_IN_ENTRIES];
#endif
  uint32 uiContactList[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiContactListEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE];
  uint32 uiLineStats[IFX_MAX_VOICE_LINES* IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiCommonContactListEntry[IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE];

  uint32 uiRecvCallEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE];
  uint32 uiDialCallEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE];
  uint32 uiMissCallEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE];
  uint32 uiRecvCallReg[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiDialCallReg[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiMissCallReg[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiPstnMissCallEntry[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE];
  uint32 uiPstnMissCallReg[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiPstnDialCallEntry[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE];
  uint32 uiPstnDialCallReg[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiPstnRecvCallEntry[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE];
  uint32 uiPstnRecvCallReg[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiPstnContactList[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_VOICE_PROFILES];
  uint32 uiPstnContactListEntry[IFX_MAX_PSTN_LINES * IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE];
/* Now hold these array addresses into another array */
uint32 uiObjCpeIDs[] =
{
	/* For array positions that hold cpeID directly, the values MUST be same
	 * as that in rc.conf
	 */
	1, /* CpeId for IFX_VMAPI_VOICE_SERVICE */
	1, /* CpeId for IFX_VMAPI_CODEC_CAPABS */
	1, /* CpeId for IFX_VMAPI_VOICE_CAPABS */
	1, /* CpeId for IFX_VMAPI_SIP_CAPABS */
	(uint32)&uiVoicePhy, /* CpeId for IFX_VMAPI_PHY_IFACE */
	(uint32)&uiFxs, /* CpeId for IFX_VMAPI_PHY_IFACE_FXS */
	(uint32)&uiFxo, /* CpeId for IFX_VMAPI_PHY_IFACE_FXO */
	(uint32)&uiDect, /* CpeId for IFX_VMAPI_PHY_IFACE_DECT */
	1, /* CpeId for IFX_VMAPI_VS_CALL_BLOCK*/
	(uint32)&uiCallBlockEntry, /* CpeId for IFX_VMAPI_VS_CALL_BLOCK_ENTRY*/
	(uint32)&uiDialCallReg, /* CpeId for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY*/
	(uint32)&uiDialCallEntry, /* CpeId for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY*/
	(uint32)&uiMissCallReg, /* CpeId for  IFX_VMAPI_VS_MISSCALL_REGISTER*/
	(uint32)&uiMissCallEntry, /* CpeId for IFX_VMAPI_VS_MISSCALL_ENTRY*/
	(uint32)&uiRecvCallReg, /* CpeId for  IFX_VMAPI_VS_MISSCALL_REGISTER*/
	(uint32)&uiRecvCallEntry, /* CpeId for IFX_VMAPI_VS_MISSCALL_ENTRY*/
	1, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
	(uint32)&uiAddrEntry, /* Holds the adddress of AddressBookEntry array*/
	1, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
	1, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
	(uint32)&uiNumPlanRule, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
	1, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
	1, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
/* :	*/
  1,
  1,
/* :	*/
	(uint32)&uiProfile, /* Holds the address of the Profile array */
	1, /* No storage required for Add Profile operation*/
	1, /* No storage required for Delete Profile Opearation*/
	(uint32)&uiProfileSerProvider, /* CpeId for IFX_VMAPI_VP_SER_PROVIDER*/
	(uint32)&uiProfileSignaling, /* CpeId for IFX_VMAPI_VP_SIGNALING*/
	(uint32)&uiProfileEventSubscr, /* CpeId for IFX_VMAPI_VP_EVENT_SUBSCR*/
	(uint32)&uiProfileEventSubscrEntry, /* CpeId for IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY*/
	(uint32)&uiProfileRTP, /* CpeId for IFX_VMAPI_VP_RTP*/
	(uint32)&uiProfileRTCP, /* CpeId for IFX_VMAPI_VP_RTCP*/
	(uint32)&uiProfileFAX, /* CpeId for VoiceSystem at position IFX_VMAPI_VOICE_CAPABS*/
/* :	*/
	(uint32)&uiVoiceLine, /* Holds the address of the Line array */
	1, /* No storage required for Add Line operation*/
	1, /* No storage required for Delete Line Opearation*/
  (uint32)&uiLineSignaling, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineAuthCfg, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineVoiceCodec, /* CpeId for IFX_VMAPI_VL_VOICE_CODEC */
  (uint32)&uiLineCodecList, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineCodecListEntry, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineCallFeat, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineVoiceSession, /* CpeId for IFX_VMAPI_VL_VOICE_SESSION */
  (uint32)&uiLineVoiceProcessing, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineSubscr, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineSubscrEntry, /* Holds the address of the Line Signaling array */
  (uint32)&uiLineStats, /*!< Voice Line Statistics */
	1,
  	(uint32)uiContactList,
  	(uint32)uiContactListEntry,
		(uint32)&uiPstnMissCallReg, /* CpeId for  IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER*/
		(uint32)&uiPstnMissCallEntry, /* CpeId for IFX_VMAPI_VS_PSTN_MISSCALL_ENTRY*/
		(uint32)&uiPstnDialCallReg, /* CpeId for  IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER*/
		(uint32)&uiPstnDialCallEntry, /* CpeId for IFX_VMAPI_VS_PSTN_MISSCALL_ENTRY*/
		(uint32)&uiPstnRecvCallReg, /* CpeId for  IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER*/
		(uint32)&uiPstnRecvCallEntry, /* CpeId for IFX_VMAPI_VS_PSTN_MISSCALL_ENTRY*/
  	(uint32)uiPstnContactList,
  	(uint32)uiPstnContactListEntry,
  	1,//(uint32)uiCommonContactList,
  	(uint32)uiCommonContactListEntry,
	1,
#ifdef MESSAGE_SUPPORT
  (uint32)&uiMsgIn, /* Holds the address of the Message Inbox array */
  (uint32)&uiMsgInEntry, /* Holds the address of the Message Inbox Entry array */
  (uint32)&uiMsgOut, /* Holds the address of the Message Outbox array */
  (uint32)&uiMsgOutEntry, /* Holds the address of the Message Outbox Entry array */
#endif

  /*(uint32)&uiLineStats,  Holds the address of the Line Stats array */
};
#endif
/******************************************************************************
*  Function Name  : ifx_Parse_CpeId 
*  Description    : Utility function used for parsing
*  Input Values   : ucSrc - string needed to be parsed
*  Output Values  : uiDestList - list after parsing 
*  									iLength - number of elements in the string
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_Parse_CpeId (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength) 
{
  int idx = 0, j = 0;
  *iLength =0;
  while (ucSrc[idx] != '\0')
    
  {
    if (ucSrc[idx] != ',')
      
    {
      *(ucDestList + j) = ucSrc[idx];
      j++;
      ++*iLength;
    }
      
    idx++;
  }
  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_vmapi_ParseCpeId 
*  Description    : Utility function used for parsing
*  Input Values   : ucSrc - string needed to be parsed
*  Output Values  : uiDestList - list after parsing 
*  									iLength - number of elements in the string
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int
ifx_vmapi_ParseCpeId (char8 * ucSrc, char8 * ucDestList,
                              uchar8 * iLength) 
{
  int index = 0, i = 0, j = 0;
  while (ucSrc[index] != '\0')
    
  {
    if (ucSrc[index] != ',')
      
    {
      *(ucDestList + (i * 5) + j) = ucSrc[index];
      j++;
    }
    
    else
      
    {
      *(ucDestList + (i * 5) + j) = '\0';
      i++;
      j = 0;
    }
    index++;
  }
  *iLength = i + 1;
  return 0;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_CpeId_opt
*  Description    : API to get cpeId of a VMAPI object. Type of the object is
*  									passed along with the instance of the object to get the 
*  									cpeId from the configuration file (input structure). 
*  									This cpeId caould be used before the ifx_get* and 
*  									ifx_set* operations (Non-ADD). 
*
*  Input Values   : ucObjType - any of the values in IFX_VMAPI_OBJ
*  									pxObj - structure representing the object
*  Output Values  : uiCpeId - integer cpeId, 0 if there is no object found 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
PUBLIC int32 IFX_VMAPI_Get_CpeId_opt(IN char8 *pcCommand, 
																     IN uchar8 ucIndex,
																     OUT uint32 *uiCpeId)
{
  int32 iRet,i=0;
  char8 *pcTemp;
  uint32 uiInFlag=0, uiOutFlag;
  char8 acInBuf[IFX_MAX_BUFF_LEN] = {0};
  *uiCpeId = 0;

  if((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                pcCommand, uiInFlag, &uiOutFlag, acInBuf)) != IFX_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,pcCommand);
    return iRet;   
  }
	if (!ucIndex){
		*uiCpeId = 0;
  	return IFX_VMAPI_SUCCESS;
	}
  pcTemp=acInBuf;
  while(i<(ucIndex-1)){
    pcTemp = strchr(pcTemp,',');
    if(pcTemp==NULL){
	    return IFX_VMAPI_FAIL;
    }
    pcTemp++;
    i++;
  }
	*uiCpeId = atoi(pcTemp);
	return IFX_VMAPI_SUCCESS;
}

#if 0
/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_CpeId
*  Description    : API to get cpeId of a VMAPI object. Type of the object is
*  									passed along with the instance of the object to get the 
*  									cpeId from the configuration file (input structure). 
*  									This cpeId caould be used before the ifx_get* and 
*  									ifx_set* operations (Non-ADD). 
*
*  Input Values   : ucObjType - any of the values in IFX_VMAPI_OBJ
*  									pxObj - structure representing the object
*  Output Values  : uiCpeId - integer cpeId, 0 if there is no object found 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
PUBLIC int32 IFX_VMAPI_Get_CpeId(IN uchar8 ucObjType, 
																 IN VOID *pxObj,
																 OUT uint32 *uiCpeId)
{
	uint32 uiObj;
	iRet = IFX_VMAPI_FAIL;

	/* Checks like valid profile id, valid line id should be taken care 
	 * by the caller */

	/* Check for valid object */
	if (ucObjType >= IFX_VMAPI_MAX_OBJ) {
		return IFX_VMAPI_FAIL;
	}
	/* This takes care of the cpeId for non-multiple-instance type objects */
	*uiCpeId = uiObjCpeIDs[ucObjType];

	switch(ucObjType)
	{
    case	IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY: 
            {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "AddrEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiAddrEntry,0,sizeof(uiAddrEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiAddrEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_AddressBookEntry*)pxObj)->ucIndex - 1);
					}
					break;
    case	IFX_VMAPI_VS_CALL_BLOCK_ENTRY: 
            {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "CallBlockEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_CALL_BLOCK_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiCallBlockEntry,0,sizeof(uiCallBlockEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiCallBlockEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VS_CALL_BLOCK_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_CallBlockEntry*)pxObj)->ucIndex - 1);
					}
					break;

		case	IFX_VMAPI_VS_NUM_PLAN_RULES: 
            {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "NumPlanRules");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_NUM_PLAN_RULES !!");
               return iRet;   
             }
             memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiNumPlanRule,0,sizeof(uiNumPlanRule)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiNumPlanRule[i] =  atoi(pucIdList1[i]); 
             }
					   uiObj = uiObjCpeIDs[IFX_VMAPI_VS_NUM_PLAN_RULES];
					   *uiCpeId = *(((uint32 *)uiObj) +
						   	((x_IFX_VMAPI_NumPlanRule*)pxObj)->ucIndex - 1);
            }
					break;
    case	IFX_VMAPI_PHY_IFACE: 
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "PhysicalInterface");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiVoicePhy,0,sizeof(uiVoicePhy)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiVoicePhy[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_VoiceServPhyIf*)pxObj)->ucInterfaceId - 1);
          }
      		break;
    case	IFX_VMAPI_PHY_IFACE_FXS: 
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "FxsphyInterface");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE_FXS !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiFxs,0,sizeof(uiFxs)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiFxs[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE_FXS];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_FxsPhyIf*)pxObj)->xVoiceServPhyIf.ucInterfaceId - 1);
          }
      		break;
    case	IFX_VMAPI_PHY_IFACE_FXO: 
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "FxophyInterface");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE_FXO !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiFxo,0,sizeof(uiFxo)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiFxo[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE_FXO];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_FxoPhyIf*)pxObj)->xVoiceServPhyIf.ucInterfaceId - 3);
          }
					break;
    case	IFX_VMAPI_PHY_IFACE_DECT: 
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "DectHandset");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE_DECT !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiDect,0,sizeof(uiDect)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiDect[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE_DECT];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_DectHandset*)pxObj)->xVoiceServPhyIf.ucInterfaceId - 4);
          }
					break;
		case IFX_VMAPI_VOICE_PROFILE:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceProfile");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VOICE_PROFILE !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfile,0,sizeof(uiProfile)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfile[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VOICE_PROFILE];
					   *uiCpeId = *(((uint32 *)uiObj) +
						   	((x_IFX_VMAPI_VoiceProfile*)pxObj)->ucProfileId - 1);
					}
					break;
		case IFX_VMAPI_ADD_PROFILE:
					break;
		case IFX_VMAPI_DELETE_PROFILE:
					break;
		case IFX_VMAPI_VP_SER_PROVIDER:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "ServiceProvider");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_SER_PROVIDER !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileSerProvider,0,sizeof(uiProfileSerProvider)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileSerProvider[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_SER_PROVIDER];
					   *uiCpeId = *(((uint32 *)uiObj) +
						      ((x_IFX_VMAPI_ProfileServiceProviderInfo*)pxObj)->ucProfileId - 1);
					}
					break;
    case IFX_VMAPI_VP_SIGNALING:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceProfileSignaling");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_SIGNALING !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileSignaling,0,sizeof(uiProfileSignaling)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileSignaling[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_SIGNALING];
					   *uiCpeId = *(((uint32 *)uiObj) +
						      ((x_IFX_VMAPI_ProfileSignaling*)pxObj)->ucProfileId - 1);
					}
					break;
	  case IFX_VMAPI_VP_EVENT_SUBSCR:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "ProfileEvent");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_EVENT_SUBSCR !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileEventSubscr,0,sizeof(uiProfileEventSubscr)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileEventSubscr[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_EVENT_SUBSCR];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_ProfileEventSubsTable*)pxObj)->ucProfileId - 1);
					}
					break;
	  case IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "EventSubscribe");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileEventSubscrEntry,0,sizeof(uiProfileEventSubscrEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileEventSubscrEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((((x_IFX_VMAPI_EventSubscribe*)pxObj)->ucProfileId - 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+
							              ((x_IFX_VMAPI_EventSubscribe*)pxObj)->ucIndex - 1);
					}
					break;
		case IFX_VMAPI_VP_RTP:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "MediaRTPAttributes");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_RTP !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileRTP,0,sizeof(uiProfileRTP)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileRTP[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_RTP];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_ProfileMediaRTP*)pxObj)->ucProfileId - 1);
					}
					break;
		case IFX_VMAPI_VP_RTCP:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "MediaRTCPAttributes");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_RTCP !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileRTCP,0,sizeof(uiProfileRTCP)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileRTCP[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_RTCP];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_ProfileMediaRTCP*)pxObj)->ucProfileId - 1);
					}
					break;
		case IFX_VMAPI_VP_FAX:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "Fax");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_FAX !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiProfileFAX,0,sizeof(uiProfileFAX)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiProfileFAX[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_FAX];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_FaxT38*)pxObj)->ucProfileId - 1);
					}
					break;
  	case IFX_VMAPI_VOICE_LINE:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLine");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VOICE_LINE !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiVoiceLine,0,sizeof(uiVoiceLine)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiVoiceLine[i] =  atoi(pucIdList1[i]); 
             }
					   uiObj = uiObjCpeIDs[IFX_VMAPI_VOICE_LINE];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_VoiceLine*)pxObj)->ucLineId - 1);
          }
          break;
  	case IFX_VMAPI_ADD_LINE:
          break;
  	case IFX_VMAPI_DELETE_LINE:
          break;
		case IFX_VMAPI_VL_SIGNALING:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineSignaling");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_SIGNALING !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineSignaling,0,sizeof(uiLineSignaling)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineSignaling[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_SIGNALING];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_LineSignaling*)pxObj)->ucLineId - 1);
          }
					break;
		case IFX_VMAPI_VL_AUTHCFG:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "AuthCfg");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_AUTHCFG !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineAuthCfg,0,sizeof(uiLineAuthCfg)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineAuthCfg[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_AUTHCFG];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((((x_IFX_VMAPI_SipAuthCfg*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_AUTH_INFO)+
							         ((x_IFX_VMAPI_SipAuthCfg*)pxObj)->ucIndex - 1);
          }
			    break;
		case IFX_VMAPI_VL_VOICE_CODEC:
					{
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineVoiceCodec");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_VOICE_CODEC !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineVoiceCodec,0,sizeof(uiLineVoiceCodec)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineVoiceCodec[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_VOICE_CODEC];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_LineCodec*)pxObj)->ucLineId - 1);
          }
					break;
	  case IFX_VMAPI_VL_CODECLIST:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineCodecList");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_CODECLIST !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineCodecList,0,sizeof(uiLineCodecList)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineCodecList[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_CODECLIST];
					   *uiCpeId = *(((uint32 *)uiObj) +
						  	((x_IFX_VMAPI_LineCodecList*)pxObj)->ucLineId - 1);
          }
					break;
    case IFX_VMAPI_VL_CODECLIST_ENTRY:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "List");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_CODECLIST_ENTRY !!");
               return iRet;   
             }
             memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineCodecListEntry,0,sizeof(uiLineCodecListEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineCodecListEntry[i] =  atoi(pucIdList1[i]); 
             }
					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_CODECLIST_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
					       ((((x_IFX_VMAPI_CodecDesc*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_CODECS)+
						       ((x_IFX_VMAPI_CodecDesc*)pxObj)->ucIndex - 1) ;
          }
					break;
		case IFX_VMAPI_VL_CALLFEAT:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineCallFeat");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_CALLFEAT !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineCallFeat,0,sizeof(uiLineCallFeat)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineCallFeat[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_CALLFEAT];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_LineCallingFeatures*)pxObj)->ucLineId - 1);
          }
					break;
		case IFX_VMAPI_VL_VOICE_SESSION:
					{
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineSession");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_VOICE_SESSION !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineVoiceSession,0,sizeof(uiLineVoiceSession)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineVoiceSession[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_VOICE_SESSION];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_LineSession*)pxObj)->ucLineId - 1);
          }
					break;
		case IFX_VMAPI_VL_VOICE_PROCESSING:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineVoiceProcessing");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_VOICE_PROCESSING !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineVoiceProcessing,0,sizeof(uiLineVoiceProcessing)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineVoiceProcessing[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_VOICE_PROCESSING];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_LineVoiceProcessing*)pxObj)->ucLineId - 1);
          }
					break;
		case IFX_VMAPI_VL_EVENT_SUBSCR:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineSubscription");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_EVENT_SUBSCR !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineSubscr,0,sizeof(uiLineSubscr)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineSubscr[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_EVENT_SUBSCR];
					   *uiCpeId = *(((uint32 *)uiObj) +
						   	((x_IFX_VMAPI_LineSubscription*)pxObj)->ucLineId - 1);
          }
					break;
		case IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineSubEvent");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineSubscrEntry,0,sizeof(uiLineSubscrEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineSubscrEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
					        ((((x_IFX_VMAPI_LineEvents*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+
						         ((x_IFX_VMAPI_LineEvents*)pxObj)->ucIndex - 1) ;
          }
					break;
#ifdef MESSAGE_SUPPORT
		case IFX_VMAPI_MSG_INBOX:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgIn");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgIn,0,sizeof(uiMsgIn)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgIn[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_INBOX];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_IN_Message*)pxObj)->ucLineId - 1);
          }
					break;

		case IFX_VMAPI_MSG_INBOX_ENTRY:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgInEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgInEntry,0,sizeof(uiMsgInEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgInEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_INBOX_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
					       ((((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+
						       ((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucIndex - 1) ;

          }
					break;
		case IFX_VMAPI_MSG_OUTBOX:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgOut");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgOut,0,sizeof(uiMsgOut)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgOut[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_OUTBOX];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_OUT_Message*)pxObj)->ucLineId - 1);
          }
					break;
		case IFX_VMAPI_MSG_OUTBOX_ENTRY:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgOutEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgOutEntry,0,sizeof(uiMsgOutEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgOutEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_OUTBOX_ENTRY];
					   *uiCpeId = *(((uint32 *)uiObj) +
					       ((((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+
						       ((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucIndex - 1) ;

          }
					break;

#endif
		case IFX_VMAPI_VL_STATS:
          {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineStats");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_STATS !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineStats,0,sizeof(uiLineStats)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineStats[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_STATS];
					   *uiCpeId = *(((uint32 *)uiObj) +
						    	((x_IFX_VMAPI_LineStats*)pxObj)->ucLineId - 1);
          }
					break;

	case IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY:
          {
             int i;
		
             sprintf((char8*)acCommand, "%s_CpeId", "MissCallEntry");
	 if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiMissCallEntry,0,sizeof(uiMissCallEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiMissCallEntry[i] =  atoi(pucIdList1[i]);
             }

              uiObj = uiObjCpeIDs[IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY];
              *uiCpeId = *(((uint32 *)uiObj) +
               ((((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE)+
               ((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucIndex - 1);
          }
	  break;

	case  IFX_VMAPI_VS_MISSCALL_REGISTER:
	{
	int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MissCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_MISSCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiMissCallReg,0,sizeof(uiMissCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiMissCallReg[i] =  atoi(pucIdList1[i]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_MISSCALL_REGISTER];
                 *uiCpeId = *(((uint32 *)uiObj) +
                 ((x_IFX_VMAPI_MissCallRegister*)pxObj)->ucLineId - 1);
          }
	
	break;


	 case IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY:
          {
             int i;

             sprintf((char8*)acCommand, "%s_CpeId", "DialCallEntry");
         if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             
		memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiDialCallEntry,0,sizeof(uiDialCallEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiDialCallEntry[i] =  atoi(pucIdList1[i]);
             }

              uiObj = uiObjCpeIDs[IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY];
              *uiCpeId = *(((uint32 *)uiObj) +
               ((((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE)+
               ((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucIndex - 1);
          }
          break;

	case  IFX_VMAPI_VS_DIALCALL_REGISTER:
        {
        int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "DialCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_DIALCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiDialCallReg,0,sizeof(uiDialCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiDialCallReg[i] =  atoi(pucIdList1[i]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_DIALCALL_REGISTER];
                 *uiCpeId = *(((uint32 *)uiObj) +
                 ((x_IFX_VMAPI_DialCallRegister*)pxObj)->ucLineId - 1);
          }

        break;


	case IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY:
          {
             int i;

             sprintf((char8*)acCommand, "%s_CpeId", "RecvCallEntry");
         if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             
		memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiRecvCallEntry,0,sizeof(uiRecvCallEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiRecvCallEntry[i] =  atoi(pucIdList1[i]);
             }

              uiObj = uiObjCpeIDs[IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY];
              *uiCpeId = *(((uint32 *)uiObj) +
               ((((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE)+
               ((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucIndex - 1);
          }
          break;

	case  IFX_VMAPI_VS_RECVCALL_REGISTER:
        {
        int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "RecvCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_RECVCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiRecvCallReg,0,sizeof(uiRecvCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiRecvCallReg[i] =  atoi(pucIdList1[i]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_RECVCALL_REGISTER];
                 *uiCpeId = *(((uint32 *)uiObj) +
                 ((x_IFX_VMAPI_RecvCallRegister*)pxObj)->ucLineId - 1);
          }

        break;

				case	IFX_VMAPI_VS_CONTACT_LIST_ENTRY: 
        {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "ContactEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_CONTACT_LIST_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiContactListEntry,0,sizeof(uiContactListEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiContactListEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VS_CONTACT_LIST_ENTRY];
					   
				*uiCpeId = *(((uint32 *)uiObj) +
               				((((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)+
               				((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex - 1);


			}
			break;
				case	IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY: 
        {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "CommonContactEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_CONTACT_LIST_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiCommonContactListEntry,0,sizeof(uiCommonContactListEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiCommonContactListEntry[i] =  atoi(pucIdList1[i]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY];
					   
				*uiCpeId = *(((uint32 *)uiObj) +
               				((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex - 1 );


			}
			break;

			case        IFX_VMAPI_VS_CONTACT_LIST:
      {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "ContactList");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for  IFX_VMAPI_VS_CONTACT_LIST !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiContactList,0,sizeof(uiContactList));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiContactList[i] =  atoi(pucIdList1[i]);
             }

                                           uiObj = uiObjCpeIDs[IFX_VMAPI_VS_CONTACT_LIST];
                                           
                 		*uiCpeId = *(((uint32 *)uiObj) +
                 				((x_IFX_VMAPI_ContactList*)pxObj)->ucLineId - 1);
               }
     break;

	case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY:
          {
             int i;
		
             sprintf((char8*)acCommand, "%s_CpeId", "PstnMissCallEntry");
	 if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnMissCallEntry,0,sizeof(uiPstnMissCallEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnMissCallEntry[i] =  atoi(pucIdList1[i]);
             }

              uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY];
              *uiCpeId = *(((uint32 *)uiObj) +
               ((((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE)+
               ((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucIndex - 1);
          }
	  break;
	
	case  IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
	{
	int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnMissCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnMissCallReg,0,sizeof(uiPstnMissCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnMissCallReg[i] =  atoi(pucIdList1[i]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER];
                 *uiCpeId = *(((uint32 *)uiObj) +
                 ((x_IFX_VMAPI_MissCallRegister*)pxObj)->ucLineId - 4);
          }
	
	break;

case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY:
          {
             int i;

             sprintf((char8*)acCommand, "%s_CpeId", "PstnDialCallEntry");
   if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnDialCallEntry,0,sizeof(uiPstnDialCallEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnDialCallEntry[i] =  atoi(pucIdList1[i]);
             }

              uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY];
              *uiCpeId = *(((uint32 *)uiObj) +
               ((((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE)+
               ((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucIndex - 1);
          }
    break;

case  IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
  {
  int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnDialCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnDialCallReg,0,sizeof(uiPstnDialCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnDialCallReg[i] =  atoi(pucIdList1[i]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER];
                 *uiCpeId = *(((uint32 *)uiObj) +
                 ((x_IFX_VMAPI_DialCallRegister*)pxObj)->ucLineId - 4);
          }

  break;
case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY:
          {
             int i;

             sprintf((char8*)acCommand, "%s_CpeId", "PstnRecvCallEntry");
   if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnRecvCallEntry,0,sizeof(uiPstnRecvCallEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnRecvCallEntry[i] =  atoi(pucIdList1[i]);
             }

              uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY];
              *uiCpeId = *(((uint32 *)uiObj) +
               ((((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE)+
               ((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucIndex - 1);
          }
    break;

case  IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
  {
  int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnRecvCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnRecvCallReg,0,sizeof(uiPstnRecvCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnRecvCallReg[i] =  atoi(pucIdList1[i]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER];
                 *uiCpeId = *(((uint32 *)uiObj) +
                 ((x_IFX_VMAPI_RecvCallRegister*)pxObj)->ucLineId - 4);
          }

  break;
case  IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY:
        {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnContactEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                           "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY !!");
               return iRet;
             }

             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnContactListEntry,0,sizeof(uiPstnContactListEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnContactListEntry[i] =  atoi(pucIdList1[i]);
             }

             uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY];

        *uiCpeId = *(((uint32 *)uiObj) +
                      ((((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)+
                      ((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex - 1);


      }
      break;
 case        IFX_VMAPI_VS_PSTN_CONTACT_LIST:
      {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnContactList");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for  IFX_VMAPI_VS_PSTN_CONTACT_LIST !!");
               return iRet;
             }

             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnContactList,0,sizeof(uiPstnContactList));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnContactList[i] =  atoi(pucIdList1[i]);
             }

                        uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_CONTACT_LIST];

                    *uiCpeId = *(((uint32 *)uiObj) +
                        ((x_IFX_VMAPI_ContactList*)pxObj)->ucLineId - 4);
               }
     break;

	default:
				/* Not a valid object */
				return IFX_VMAPI_FAIL;
	}
	return IFX_VMAPI_SUCCESS;
}
#endif
/******************************************************************************
*  Function Name  : IFX_VMAPI_Update_CpeId_opt
*  Description    : API to update the cpeId of an object in the table.
*  									This API sets should be called on successful ADD operation 
*  									with the cpeId received from the IFX_VMAPI_Get_NextCpeId.
*  									And, called after successful DELETE operation with cpeId
*  									input as 0 (resetting in the table).
*  Input Values   : ucObjType - any of the values in IFX_VMAPI_OBJ
*  									pxObj - structure representing the object
*  									uiCpeId - integer cpeId
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
PUBLIC int32 IFX_VMAPI_Update_CpeId_opt(IN char8 *pcCommand, 
																 	      IN char8 ucIndex,
																	      IN uint32 uiCpeId)
{
	/* Checks like valid profile id, valid line id should be taken care 
	 * by the caller */
  int32 iRet,i=0,iCompact=0;
  char8 *pcTemp,*pcNext,*pcStart;
  uint32 uiInFlag=0, uiOutFlag;
  char8 acInBuf[IFX_MAX_BUFF_LEN] = {0};
  char8 NVArray[MAX_FILELINE_LEN + IFX_MAX_BUFF_LEN] = {0};
  if((uiCpeId ==0)){
    if((strcmp(pcCommand,"AddrEntry_CpeId")==0)||
       (strcmp(pcCommand,"CallBlockEntry_CpeId")==0)||
       (strcmp(pcCommand,"NumPlanRules_CpeId")==0)||
       (strcmp(pcCommand,"MsgInEntry_CpeId")==0)||
       (strcmp(pcCommand,"MsgOutEntry_CpeId")==0)||
       (strcmp(pcCommand,"MissCallEntry_CpeId")==0)||
       (strcmp(pcCommand,"DialCallEntry_CpeId")==0)||
       (strcmp(pcCommand,"RecvCallEntry_CpeId")==0)||
       (strcmp(pcCommand,"ContactEntry_CpeId")==0)||
       (strcmp(pcCommand,"PstnMissCallEntry_CpeId")==0)||
       (strcmp(pcCommand,"PstnDialCallEntry_CpeId")==0)||
       (strcmp(pcCommand,"PstnRecvCallEntry_CpeId")==0)||
       (strcmp(pcCommand,"PstnContactEntry_CpeId")==0)||
			 (strcmp(pcCommand,"CommonContactEntry_CpeId")==0)){
      iCompact=1;
    }
  }
  /* Get the Data from rc.conf */
  if((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                pcCommand, uiInFlag, &uiOutFlag, acInBuf)) != IFX_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,pcCommand);
    return iRet;   
  }
  /* Manupulate the CPEID */
  pcTemp=pcStart=acInBuf;
  /* Here there are 2 options 1. Update the CpeId 2. Remove a CPE ID and append a 0 in the end*/
  while(i<(ucIndex-1)){
    pcTemp = strchr(pcTemp,',');
    if(pcTemp==NULL){
	    return IFX_VMAPI_FAIL;
    }
    pcTemp++;
    i++;
  }
  pcNext=strchr(pcTemp,',');
  if(iCompact != 1){
    if((pcTemp==pcStart)&&(pcNext!=NULL)){
      /* Update the first CPE ID */
      sprintf(NVArray,"%s=\"%d%s\"\n",pcCommand,uiCpeId,pcNext);
    }
    else if((pcTemp!=pcStart)&&(pcNext!=NULL)){
      /* update a CPEID in the middle */
      *pcTemp = '\0';
      sprintf(NVArray,"%s=\"%s%d%s\"\n",pcCommand,pcStart,uiCpeId,pcNext);
    }
    else if(pcNext==NULL){
      /* Update the last CPE ID */
      *pcTemp = '\0';
      sprintf(NVArray,"%s=\"%s%d\"\n",pcCommand,pcStart,uiCpeId);
    }
  }
  else{
    if((pcTemp==pcStart)&&(pcNext!=NULL)){
      /* Update the first CPE ID */
      sprintf(NVArray,"%s=\"%s,%d\"\n",pcCommand,pcNext+1,uiCpeId);
    }
    else if((pcTemp!=pcStart)&&(pcNext!=NULL)){
      /* update a CPEID in the middle */
      *pcTemp = '\0';
      sprintf(NVArray,"%s=\"%s%s,%d\"\n",pcCommand,pcStart,pcNext+1,uiCpeId);
    }
    else if(pcNext==NULL){
      *pcTemp = '\0';
      sprintf(NVArray,"%s=\"%s%d\"\n",pcCommand,pcStart,uiCpeId);
    }
  }
  /* Set the value back to rc.conf */
	if(strlen(NVArray)){
  	if((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,NVArray);
    return iRet;   
  	}
	}
	return iRet;
}

#if 0
/******************************************************************************
*  Function Name  : IFX_VMAPI_Update_CpeId
*  Description    : API to update the cpeId of an object in the table.
*  									This API sets should be called on successful ADD operation 
*  									with the cpeId received from the IFX_VMAPI_Get_NextCpeId.
*  									And, called after successful DELETE operation with cpeId
*  									input as 0 (resetting in the table).
*  Input Values   : ucObjType - any of the values in IFX_VMAPI_OBJ
*  									pxObj - structure representing the object
*  									uiCpeId - integer cpeId
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
PUBLIC int32 IFX_VMAPI_Update_CpeId(IN uchar8 ucObjType, 
																 	 IN VOID *pxObj,
																	 IN uint32 uiCpeId)
{
	uint32 uiObj;

	/* Checks like valid profile id, valid line id should be taken care 
	 * by the caller */

	/* Check for valid object */
	if (ucObjType >= IFX_VMAPI_MAX_OBJ) {
		return IFX_VMAPI_FAIL;
	}

	switch(ucObjType)
	{
   case	IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY: 
            {
             int32 d, x;
             sprintf((char8*)acCommand, "%s_CpeId", "AddrEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiAddrEntry,0,sizeof(uiAddrEntry)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiAddrEntry[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY];
					     *(((uint32 *)uiObj) +
						      ((x_IFX_VMAPI_AddressBookEntry*)pxObj)->ucIndex - 1) = uiCpeId;
	
						 if (uiCpeId == 0)
					   {
					     for (x=((x_IFX_VMAPI_AddressBookEntry*)pxObj)->ucIndex;x<ucNoOfIds;x++)
						     uiAddrEntry[x-1] = atoi(pucIdList1[x]) ;
						     uiAddrEntry[x-1] = 0;
					   }
          
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiAddrEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY !!");
               return iRet;   
             }
            }

					break;
   case	IFX_VMAPI_VS_CALL_BLOCK_ENTRY: 
            {
             int32 d, x;
             sprintf((char8*)acCommand, "%s_CpeId", "CallBlockEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_CALL_BLOCK_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiCallBlockEntry,0,sizeof(uiCallBlockEntry)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiCallBlockEntry[d] =  atoi(pucIdList1[d]); 
             }
					
 					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_CALL_BLOCK_ENTRY];
					     *(((uint32 *)uiObj) +
						      ((x_IFX_VMAPI_CallBlockEntry*)pxObj)->ucIndex - 1) = uiCpeId;
	
						 if (uiCpeId == 0)
					   {
					     for (x=((x_IFX_VMAPI_CallBlockEntry*)pxObj)->ucIndex;x<ucNoOfIds;x++)
						     uiCallBlockEntry[x-1] = atoi(pucIdList1[x]) ;
						     uiCallBlockEntry[x-1] = 0;
					   }
						 
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiCallBlockEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VS_CALL_BLOCK_ENTRY !!");
               return iRet;   
             }
            }

					break;
   case	IFX_VMAPI_VS_NUM_PLAN_RULES: 
            {
             int32 d, x;
             sprintf((char8*)acCommand, "%s_CpeId", "NumPlanRules");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_NUM_PLAN_RULES !!");
               return iRet;   
             }
             memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiNumPlanRule,0,sizeof(uiNumPlanRule)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiNumPlanRule[d] =  atoi(pucIdList1[d]); 
             }
 					   uiObj = uiObjCpeIDs[IFX_VMAPI_VS_NUM_PLAN_RULES];
					   *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_NumPlanRule*)pxObj)->ucIndex - 1) = uiCpeId;
					
						 if (uiCpeId == 0)
					   {
					     for (x=((x_IFX_VMAPI_NumPlanRule*)pxObj)->ucIndex;x<ucNoOfIds;x++)
						     uiNumPlanRule[x-1] = atoi(pucIdList1[x]) ;
						     uiNumPlanRule[x-1] = 0;
					   }
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiNumPlanRule[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VS_NUM_PLAN_RULES !!");
               return iRet;   
             }
            }
					 break;
    case	IFX_VMAPI_PHY_IFACE: 
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "PhysicalInterface");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiVoicePhy,0,sizeof(uiVoicePhy)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiVoicePhy[d] =  atoi(pucIdList1[d]); 
             }
						 
						 uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE];
					     *(((uint32 *)uiObj) +
						     ((x_IFX_VMAPI_VoiceServPhyIf*)pxObj)->ucInterfaceId - 1) = uiCpeId;
					
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiVoicePhy[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_PHY_IFACE !!");
               return iRet;   
             }
            }
			break;
    case	IFX_VMAPI_PHY_IFACE_FXS: 
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "FxsphyInterface");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE_FXS !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiFxs,0,sizeof(uiFxs)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiFxs[d] =  atoi(pucIdList1[d]); 
             }

 					   uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE_FXS];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_FxsPhyIf*)pxObj)->xVoiceServPhyIf.ucInterfaceId - 1) = uiCpeId;
					
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiFxs[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_PHY_IFACE_FXS !!");
               return iRet;   
             }
            }
			break;
    case	IFX_VMAPI_PHY_IFACE_FXO: 
             {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "FxophyInterface");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE_FXO !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiFxo,0,sizeof(uiFxo)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiFxo[d] =  atoi(pucIdList1[d]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE_FXO];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_FxoPhyIf*)pxObj)->xVoiceServPhyIf.ucInterfaceId - 3) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiFxo[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_PHY_IFACE_FXO !!");
               return iRet;   
             }
            }
					break;
    case	IFX_VMAPI_PHY_IFACE_DECT: 
             {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "DectHandset");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_PHY_IFACE_DECT !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiDect,0,sizeof(uiDect)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiDect[d] =  atoi(pucIdList1[d]); 
             }
					   					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_PHY_IFACE_DECT];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_DectHandset*)pxObj)->xVoiceServPhyIf.ucInterfaceId - 4) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiDect[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_PHY_IFACE_DECT !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VOICE_PROFILE:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceProfile");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VOICE_PROFILE !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfile,0,sizeof(uiProfile)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfile[d] =  atoi(pucIdList1[d]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VOICE_PROFILE];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_VoiceProfile*)pxObj)->ucProfileId - 1) = uiCpeId;
						 
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfile[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VOICE_PROFILE !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_ADD_PROFILE:
					break;
		case IFX_VMAPI_DELETE_PROFILE:
					break;
		case IFX_VMAPI_VP_SER_PROVIDER:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "ServiceProvider");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_SER_PROVIDER !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileSerProvider,0,sizeof(uiProfileSerProvider)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileSerProvider[d] =  atoi(pucIdList1[d]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_SER_PROVIDER];
					    *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_ProfileServiceProviderInfo*)pxObj)->ucProfileId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileSerProvider[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_SER_PROVIDER !!");
               return iRet;   
             }
            }

					break;
		case IFX_VMAPI_VP_SIGNALING:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceProfileSignaling");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_SIGNALING !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileSignaling,0,sizeof(uiProfileSignaling)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileSignaling[d] =  atoi(pucIdList1[d]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_SIGNALING];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_ProfileSignaling*)pxObj)->ucProfileId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileSignaling[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_SIGNALING !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VP_EVENT_SUBSCR:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "ProfileEvent");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_EVENT_SUBSCR !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileEventSubscr,0,sizeof(uiProfileEventSubscr)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileEventSubscr[d] =  atoi(pucIdList1[d]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VP_EVENT_SUBSCR];
					    *(((uint32 *)uiObj) +
							  ((x_IFX_VMAPI_ProfileEventSubsTable*)pxObj)->ucProfileId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileEventSubscr[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_EVENT_SUBSCR !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "EventSubscribe");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileEventSubscrEntry,0,sizeof(uiProfileEventSubscrEntry)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileEventSubscrEntry[d] =  atoi(pucIdList1[d]); 
             }
					
	 uiObj = uiObjCpeIDs[IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY];
	    *(((uint32 *)uiObj) +
  ((((x_IFX_VMAPI_EventSubscribe*)pxObj)->ucProfileId - 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+
	    ((x_IFX_VMAPI_EventSubscribe*)pxObj)->ucIndex - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileEventSubscrEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY !!");
               return iRet;   
             }
            }
					break;
  	case IFX_VMAPI_VP_RTP:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "MediaRTPAttributes");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_RTP !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileRTP,0,sizeof(uiProfileRTP)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileRTP[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VP_RTP];
					    *(((uint32 *)uiObj) +
							  ((x_IFX_VMAPI_ProfileMediaRTP*)pxObj)->ucProfileId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileRTP[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_RTP !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VP_RTCP:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "MediaRTCPAttributes");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_RTCP !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileRTCP,0,sizeof(uiProfileRTCP)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileRTCP[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VP_RTCP];
					    *(((uint32 *)uiObj) +
							  ((x_IFX_VMAPI_ProfileMediaRTCP*)pxObj)->ucProfileId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileRTCP[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_RTCP !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VP_FAX:
            {
             int32 d;
             sprintf((char8*)acCommand, "%s_CpeId", "Fax");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VP_FAX !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiProfileFAX,0,sizeof(uiProfileFAX)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiProfileFAX[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VP_FAX];
					    *(((uint32 *)uiObj) +
							  ((x_IFX_VMAPI_FaxT38*)pxObj)->ucProfileId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiProfileFAX[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VP_FAX !!");
               return iRet;   
             }
            }
					break;

		case IFX_VMAPI_VOICE_LINE:
        {
             int32 d,i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLine");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VOICE_LINE !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiVoiceLine,0,sizeof(uiVoiceLine)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiVoiceLine[d] =  atoi(pucIdList1[d]); 
             }
						 
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VOICE_LINE];
					    *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_VoiceLine*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiVoiceLine[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VOICE_LINE !!");
               return iRet;   
             }
            }
      break;
		case IFX_VMAPI_ADD_LINE:
					break;
		case IFX_VMAPI_DELETE_LINE:
					break;
		case IFX_VMAPI_VL_SIGNALING:
          {
             int32 d,i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineSignaling");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_SIGNALING !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiLineSignaling,0,sizeof(uiLineSignaling)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiLineSignaling[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VL_SIGNALING];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_LineSignaling*)pxObj)->ucLineId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineSignaling[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_SIGNALING !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VL_AUTHCFG:
            {
             int32 d ,i;
             sprintf((char8*)acCommand, "%s_CpeId", "AuthCfg");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_AUTHCFG !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiLineAuthCfg,0,sizeof(uiLineAuthCfg)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiLineAuthCfg[d] =  atoi(pucIdList1[d]); 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_AUTHCFG];
					    *(((uint32 *)uiObj) +
						   ((((x_IFX_VMAPI_SipAuthCfg*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_AUTH_INFO)+
							  ((x_IFX_VMAPI_SipAuthCfg*)pxObj)->ucIndex - 1) = uiCpeId;
#if 0	
 					   if (uiCpeId == 0)
					   {
					     for (x=( ((((x_IFX_VMAPI_SipAuthCfg*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_AUTH_INFO)+((x_IFX_VMAPI_SipAuthCfg*)pxObj)->ucIndex);x<ucNoOfIds;x++)
							 {
						     uiLineAuthCfg[x-1] = atoi(pucIdList1[x]);
						     //uiLineAuthCfg[x-1] = pucIdList[x] - '0';
						     //uiLineAuthCfg[x-1] = 0;
							 }
					   }
#endif
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineAuthCfg[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_AUTHCFG !!");
               return iRet;   
             }
            }
					break;
 		case IFX_VMAPI_VL_VOICE_CODEC:
					{
             int32 d,i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineVoiceCodec");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_VOICE_CODEC !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiLineVoiceCodec,0,sizeof(uiLineVoiceCodec)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiLineVoiceCodec[d] =  atoi(pucIdList1[d]); 
             }

						 uiObj = uiObjCpeIDs[IFX_VMAPI_VL_VOICE_CODEC];
					    *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_LineCodec*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineVoiceCodec[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_VOICE_CODEC !!");
               return iRet;   
             }
          }
					break;
		case IFX_VMAPI_VL_CODECLIST:
            {
             int32 d, i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineCodecList");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_CODECLIST !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiLineCodecList,0,sizeof(uiLineCodecList)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiLineCodecList[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VL_CODECLIST];
					    *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_LineCodecList*)pxObj)->ucLineId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineCodecList[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_CODECLIST !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VL_CODECLIST_ENTRY:
         {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "List");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_CODECLIST_ENTRY !!");
               return iRet;   
             }
						 
             memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineCodecListEntry,0,sizeof(uiLineCodecListEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineCodecListEntry[i] =  atoi(pucIdList1[i]) ; 
							 //printf("uiLineCodecListEntry[%d] = %d\n",i, uiLineCodecListEntry[i]);
             }

						 /*printf("ucLineId=%d ucIndex=%d ucNoOfIds=%d\n",
														 ((x_IFX_VMAPI_CodecDesc*)pxObj)->ucLineId,
														 ((x_IFX_VMAPI_CodecDesc*)pxObj)->ucIndex ,ucNoOfIds);	*/
		
					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_CODECLIST_ENTRY];
					    *(((uint32 *)uiObj) +
					     ((((x_IFX_VMAPI_CodecDesc*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_CODECS)+
						    ((x_IFX_VMAPI_CodecDesc*)pxObj)->ucIndex - 1) = uiCpeId;
							
             j=0;
	           memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineCodecListEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
						 	 //printf("string length of PArray: %d after %d round\n",j,i+1);
							 //printf("PArray: %s\n",PArray);
             }
             PArray[j-1] = '\0';

             sprintf(&NVArray[0],"%s=\"%s\"\n",acCommand,PArray);
					   //printf("Before ifx_SetObjData %s\n",NVArray);	
						 
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_CODECLIST_ENTRY !!");
               return iRet;   
             }
            }
					break;
  	case IFX_VMAPI_VL_CALLFEAT:
           {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineCallFeat");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_CALLFEAT !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineCallFeat,0,sizeof(uiLineCallFeat)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineCallFeat[i] =  atoi(pucIdList1[i]) ; 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VL_CALLFEAT];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_LineCallingFeatures*)pxObj)->ucLineId - 1) = uiCpeId;
							
            j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineCallFeat[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(&NVArray[0],"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_CALLFEAT !!");
               return iRet;   
             }
            }
					break;
#ifdef MESSAGE_SUPPORT
		case IFX_VMAPI_MSG_INBOX:
           {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgIn");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX: !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgIn,0,sizeof(uiMsgIn)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgIn[i] =  atoi(pucIdList1[i]) ; 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_INBOX];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_IN_Message*)pxObj)->ucLineId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiMsgIn[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(&NVArray[0],"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_MSG_INBOX !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_MSG_INBOX_ENTRY:
         {
             int32 i,x;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgInEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX_ENTRY !!");
               return iRet;   
             }
						 
             memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgInEntry,0,sizeof(uiMsgInEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgInEntry[i] =  atoi(pucIdList1[i]) ; 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_INBOX_ENTRY];
					    *(((uint32 *)uiObj) +
					     ((((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+
						    ((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucIndex - 1) = uiCpeId;

							/*printf("LineId: %d Index: %d\n",((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucLineId , 
																((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucIndex);*/
						

						 if (uiCpeId == 0)
					   {
					     for (x=(((((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucLineId-1) * IFX_VMAPI_MAX_MSG_IN_ENTRIES) 
										 + ((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucIndex);
									 x<(((x_IFX_VMAPI_IN_MessageEntry*)pxObj)->ucLineId * IFX_VMAPI_MAX_MSG_IN_ENTRIES)-1;x++)
						     uiMsgInEntry[x-1] = atoi(pucIdList1[x]);
						     uiMsgInEntry[x-1] = 0;
					   }

             j=0;
	           memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiMsgInEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
						 	 //printf("string length of PArray: %d after %d round\n",j,i+1);
							 //printf("PArray: %s\n",PArray);
             }
             PArray[j-1] = '\0';

             sprintf(&NVArray,"%s=\"%s\"\n",acCommand,PArray);
					   //printf("Before ifx_SetObjData %s\n",NVArray);	
						 
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_CODECLIST_ENTRY !!");
               return iRet;   
             }
            }
					break;

		case IFX_VMAPI_MSG_OUTBOX:
           {
             int32 d,i;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgOut");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX: !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgIn,0,sizeof(uiMsgIn)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgOut[i] =  atoi(pucIdList1[i]) ; 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_OUTBOX];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_OUT_Message*)pxObj)->ucLineId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiMsgOut[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_MSG_INBOX !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_MSG_OUTBOX_ENTRY:
         {
             int32 i,x;
             sprintf((char8*)acCommand, "%s_CpeId", "MsgOutEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_MSG_INBOX_ENTRY !!");
               return iRet;   
             }
						 
             memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiMsgOutEntry,0,sizeof(uiMsgOutEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiMsgOutEntry[i] =  atoi(pucIdList1[i]) ; 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_MSG_OUTBOX_ENTRY];
					    *(((uint32 *)uiObj) +
					     ((((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+
						    ((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucIndex - 1) = uiCpeId;

							/*printf("LineId: %d Index: %d\n",((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucLineId , 
																((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucIndex);*/
						

						 if (uiCpeId == 0)
					   {
					     for (x=(((((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucLineId-1) * IFX_VMAPI_MAX_MSG_IN_ENTRIES) 
										 + ((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucIndex);
									 x<(((x_IFX_VMAPI_OUT_MessageEntry*)pxObj)->ucLineId * IFX_VMAPI_MAX_MSG_IN_ENTRIES)-1;x++)
						     uiMsgOutEntry[x-1] = atoi(pucIdList1[x]);
						     uiMsgOutEntry[x-1] = 0;
					   }

             j=0;
	           memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiMsgOutEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
						 	 //printf("string length of PArray: %d after %d round\n",j,i+1);
							 //printf("PArray: %s\n",PArray);
             }
             PArray[j-1] = '\0';

             sprintf(&NVArray,"%s=\"%s\"\n",acCommand,PArray);
					   //printf("Before ifx_SetObjData %s\n",NVArray);	
						 
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_CODECLIST_ENTRY !!");
               return iRet;   
             }
            }
					break;


#endif
		case IFX_VMAPI_VL_VOICE_SESSION:
					{
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineSession");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_VOICE_SESSION !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineVoiceSession,0,sizeof(uiLineVoiceSession)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineVoiceSession[i] =  atoi(pucIdList1[i]) ; 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_VOICE_SESSION];
					   *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_LineSession*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineVoiceSession[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_VOICE_SESSION !!");
               return iRet;   
             }
          }
					break;
		case IFX_VMAPI_VL_VOICE_PROCESSING:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "VoiceLineVoiceProcessing");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_VOICE_PROCESSING !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineVoiceProcessing,0,sizeof(uiLineVoiceProcessing)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineVoiceProcessing[i] =  atoi(pucIdList1[i]) ; 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VL_VOICE_PROCESSING];
					    *(((uint32 *)uiObj) +
						    ((x_IFX_VMAPI_LineVoiceProcessing*)pxObj)->ucLineId - 1) = uiCpeId;
							
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineVoiceProcessing[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_VOICE_PROCESSING !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VL_EVENT_SUBSCR:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineSubscription");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_EVENT_SUBSCR !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineSubscr,0,sizeof(uiLineSubscr)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineSubscr[i] =  atoi(pucIdList1[i]) ; 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_EVENT_SUBSCR];
					   *(((uint32 *)uiObj) +
						  ((x_IFX_VMAPI_LineSubscription*)pxObj)->ucLineId - 1) = uiCpeId;
						
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineSubscr[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_EVENT_SUBSCR !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY:
          {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineSubEvent");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineSubscrEntry,0,sizeof(uiLineSubscrEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineSubscrEntry[i] =  atoi(pucIdList1[i]) ; 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY];
					   *(((uint32 *)uiObj) +
					     ((((x_IFX_VMAPI_LineEvents*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+
						     ((x_IFX_VMAPI_LineEvents*)pxObj)->ucIndex - 1) = uiCpeId;
						 
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineSubscrEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';

             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY !!");
               return iRet;   
             }
            }
					break;
		case IFX_VMAPI_VL_STATS:
         {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "LineStats");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VL_STATS !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiLineStats,0,sizeof(uiLineStats)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiLineStats[i] =  atoi(pucIdList1[i]) ; 
             }

					   uiObj = uiObjCpeIDs[IFX_VMAPI_VL_STATS];
					   *(((uint32 *)uiObj) +
						   ((x_IFX_VMAPI_LineStats*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiLineStats[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VL_STATS !!");
               return iRet;   
             }
            }
					break;


	case IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY:
	{
             int32 d, x;

		sprintf((char8*)acCommand, "%s_CpeId", "MissCallEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                       "Error : Could Not Get Data for IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY !!");
               return iRet;
             }
	     memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(&uiMissCallEntry,0,sizeof(uiMissCallEntry));
             for(d=0;d<ucNoOfIds;d++)
             {
               uiMissCallEntry[d] =  atoi(pucIdList1[d]);
             }
             
		 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucIndex - 1) = uiCpeId;
		if (uiCpeId == 0)
                {
                     for (x=(((((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId-1) * IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE)
                                                                                 + ((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucIndex);
                                                                         x<=(((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE )-1;x++)
                                                     uiMissCallEntry[x-1] = atoi(pucIdList1[x]);
                                                     uiMissCallEntry[x-1] = 0;
                                           }


	
            j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiMissCallEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY !!");
               return iRet;
             }
            }

	break;


	case IFX_VMAPI_VS_MISSCALL_REGISTER:
	{
	     int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "MissCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_MISSCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiMissCallReg,0,sizeof(uiMissCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiMissCallReg[i] =  atoi(pucIdList1[i]) ;
             }

                                                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_MISSCALL_REGISTER];
                                            *(((uint32 *)uiObj) +
                                                    ((x_IFX_VMAPI_MissCallRegister*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiMissCallReg[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_MISSCALL_REGISTER !!");
               return iRet;
             }
            }

	break;

	 case IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY:
        {
             int32 d,  x;
                sprintf((char8*)acCommand, "%s_CpeId", "DialCallEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                       "Error : Could Not Get Data for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(&uiDialCallEntry,0,sizeof(uiDialCallEntry));
             for(d=0;d<ucNoOfIds;d++)
             {
               uiDialCallEntry[d] =  atoi(pucIdList1[d]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucIndex - 1) = uiCpeId;
                if (uiCpeId == 0)
                {
                     for (x=(((((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId-1) * IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE)
                                                                                 + ((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucIndex);
                                                                         x<=(((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE )-1;x++)
                                                     uiDialCallEntry[x-1] = atoi(pucIdList1[x]);
                                                     uiDialCallEntry[x-1] = 0;
                                           }



            j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiDialCallEntry[i]);
	strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY !!");
               return iRet;
             }
            }

        break;


        case IFX_VMAPI_VS_DIALCALL_REGISTER:
        {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "DialCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_DIALCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiDialCallReg,0,sizeof(uiDialCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiDialCallReg[i] =  atoi(pucIdList1[i]) ;
             }

                                                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_DIALCALL_REGISTER];
                                            *(((uint32 *)uiObj) +
                                                    ((x_IFX_VMAPI_DialCallRegister*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiDialCallReg[i]);
		 strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_DIALCALL_REGISTER !!");
               return iRet;
             }
            }

        break;

 case IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY:
        {
             int32 d,x;
                sprintf((char8*)acCommand, "%s_CpeId", "RecvCallEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                       "Error : Could Not Get Data for IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY !!");
               return iRet;
             }
             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(&uiRecvCallEntry,0,sizeof(uiRecvCallEntry));
             for(d=0;d<ucNoOfIds;d++)
             {
               uiRecvCallEntry[d] =  atoi(pucIdList1[d]);
             }

                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucIndex - 1) = uiCpeId;
                if (uiCpeId == 0)
                {
                     for (x=(((((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId-1) * IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE)
                                                                                 + ((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucIndex);
                                                                         x<=(((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE )-1;x++)
                                                     uiRecvCallEntry[x-1] = atoi(pucIdList1[x]);
                                                     uiRecvCallEntry[x-1] = 0;
                                           }



            j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiRecvCallEntry[i]);
	strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY !!");
               return iRet;
             }
            }

        break;


        case IFX_VMAPI_VS_RECVCALL_REGISTER:
        {
             int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "RecvCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_RECVCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiRecvCallReg,0,sizeof(uiRecvCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiRecvCallReg[i] =  atoi(pucIdList1[i]) ;
             }

                                                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_RECVCALL_REGISTER];
                                            *(((uint32 *)uiObj) +
                                                    ((x_IFX_VMAPI_RecvCallRegister*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiRecvCallReg[i]);
		 						strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_RECVCALL_REGISTER !!");
               return iRet;
             }
            }

        break;

				case	IFX_VMAPI_VS_CONTACT_LIST_ENTRY: 
            {
             int32  x;
             sprintf((char8*)acCommand, "%s_CpeId", "ContactEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_CONTACT_LIST_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(uiContactListEntry,0,sizeof(uiContactListEntry)); 
	           for(i=0;i<ucNoOfIds;i++)
             { 
               uiContactListEntry[i] =  atoi(pucIdList1[i]); 
             }
					
			  uiObj = uiObjCpeIDs[IFX_VMAPI_VS_CONTACT_LIST_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex - 1) = uiCpeId;
                if (uiCpeId == 0)
                {
                     for (x=(((((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId-1) * IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)
                                                                                 + ((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex);
                                 x<=(((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE )-1;x++)
						     uiContactListEntry[x-1] = atoi(pucIdList1[x]) ;
						     uiContactListEntry[x-1] = 0;
  							} 
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiContactListEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VS_CONTACT_LIST_ENTRY !!");
               return iRet;   
             }
            }
			break;

			case   IFX_VMAPI_VS_CONTACT_LIST:
            {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "ContactList");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for  IFX_VMAPI_VS_CONTACT_LIST !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiContactList,0,sizeof(uiContactList));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiContactList[i] =  atoi(pucIdList1[i]);
             }

                                           uiObj = uiObjCpeIDs[IFX_VMAPI_VS_CONTACT_LIST];
                                            *(((uint32 *)uiObj) +
                                                    ((x_IFX_VMAPI_ContactList*)pxObj)->ucLineId - 1) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiContactList[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_CONTACT_LIST !!");
               return iRet;
             }
	

	}
	break;

	case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY:
	{
             int32 d, x;

		sprintf((char8*)acCommand, "%s_CpeId", "PstnMissCallEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                       "Error : Could Not Get Data for IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY !!");
               return iRet;
             }
	     memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(&uiPstnMissCallEntry,0,sizeof(uiPstnMissCallEntry));
             for(d=0;d<ucNoOfIds;d++)
             {
               uiPstnMissCallEntry[d] =  atoi(pucIdList1[d]);
             }
             
		 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucIndex - 1) = uiCpeId;
		if (uiCpeId == 0)
    {
       for (x=(((((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId-4) * IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE)
                              + ((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucIndex);
          x<=(((x_IFX_VMAPI_MissCallRegEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE )-1;x++)
                                     uiPstnMissCallEntry[x-1] = atoi(pucIdList1[x]);
                                      uiPstnMissCallEntry[x-1] = 0;
    }
         j=0;
         memset(&PArray,0,sizeof(PArray));
         for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnMissCallEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Error : Could Not Set Data for IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY !!");
               return iRet;
             }
            }
	break;


	case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
	{
	     int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnMissCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_MISSCALL_REGISTER !!");
               return iRet;
             }

             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnMissCallReg,0,sizeof(uiPstnMissCallReg));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnMissCallReg[i] =  atoi(pucIdList1[i]) ;
             }

                      uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER];
                      *(((uint32 *)uiObj) +
                       ((x_IFX_VMAPI_MissCallRegister*)pxObj)->ucLineId - 4) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnMissCallReg[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                           "Error : Could Not Set Data for IFX_VMAPI_VS_MISSCALL_REGISTER !!");
               return iRet;
             }
            }

	break;
case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY:
  {
             int32 d, x;

    sprintf((char8*)acCommand, "%s_CpeId", "PstnDialCallEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                       "Error : Could Not Get Data for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY !!");
               return iRet;
             }
       memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(&uiPstnDialCallEntry,0,sizeof(uiPstnDialCallEntry));
             for(d=0;d<ucNoOfIds;d++)
             {
               uiPstnDialCallEntry[d] =  atoi(pucIdList1[d]);
             }

     uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucIndex - 1) = uiCpeId;
    if (uiCpeId == 0)
                {
                     for (x=(((((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId-4) * IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE)
                                                                                 + ((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucIndex);
                                                                         x<=(((x_IFX_VMAPI_DialCallRegEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE )-1;x++)
                                                     uiPstnDialCallEntry[x-1] = atoi(pucIdList1[x]);
                                                     uiPstnDialCallEntry[x-1] = 0;
                                           }



            j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnDialCallEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY !!");
               return iRet;
             }
            }

  break;


  case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
  {
       int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnDialCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_DIALCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnDialCallReg,0,sizeof(uiPstnDialCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnDialCallReg[i] =  atoi(pucIdList1[i]) ;
             }

                                                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER];
                                            *(((uint32 *)uiObj) +
                                                    ((x_IFX_VMAPI_DialCallRegister*)pxObj)->ucLineId - 4) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnDialCallReg[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_DIALCALL_REGISTER !!");
               return iRet;
 	}
        }

  break;

case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY:
  {
             int32 d, x;

    sprintf((char8*)acCommand, "%s_CpeId", "PstnRecvCallEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                       "Error : Could Not Get Data for IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY !!");
               return iRet;
             }
       memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(&uiPstnRecvCallEntry,0,sizeof(uiPstnRecvCallEntry));
             for(d=0;d<ucNoOfIds;d++)
             {
               uiPstnRecvCallEntry[d] =  atoi(pucIdList1[d]);
             }

     uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY];
                          *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId - 4)*IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucIndex - 1) = uiCpeId;
    if (uiCpeId == 0)
                {
                     for (x=(((((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId-4) * IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE)
                                                                                 + ((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucIndex);
                                                                         x<=(((x_IFX_VMAPI_RecvCallRegEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE )-1;x++)
                                                     uiPstnRecvCallEntry[x-1] = atoi(pucIdList1[x]);
                                                     uiPstnRecvCallEntry[x-1] = 0;
                                           }



            j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnRecvCallEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Set Data for IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY !!");
               return iRet;
             }
            }

  break;


  case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
  {
       int32 i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnRecvCallRegister");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                         "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER !!");
               return iRet;
             }

                                                 memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnRecvCallReg,0,sizeof(uiPstnRecvCallReg));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnRecvCallReg[i] =  atoi(pucIdList1[i]) ;
             }

                                                 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER];
                                            *(((uint32 *)uiObj) +
                                                    ((x_IFX_VMAPI_RecvCallRegister*)pxObj)->ucLineId - 4) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnRecvCallReg[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                       "Error : Could Not Set Data for IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER !!");
               return iRet;
 	}
        }

  break;
 
case  IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY:
            {
             int32  x;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnContactEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                           "Error : Could Not Get Data for IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY !!");
               return iRet;
             }

             memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnContactListEntry,0,sizeof(uiPstnContactListEntry));
             for(i=0;i<ucNoOfIds;i++)
             {
               uiPstnContactListEntry[i] =  atoi(pucIdList1[i]);
             }

        			uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY];
                *(((uint32 *)uiObj) +
                ((((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId - 1)*IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)+
                  ((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex - 1) = uiCpeId;
                if (uiCpeId == 0)
                {
              for (x=(((((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId-4) * IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)
              + ((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex);
              x<=(((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucLineId *IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE )-1;x++)
                 uiPstnContactListEntry[x-1] = atoi(pucIdList1[x]) ;
                 uiPstnContactListEntry[x-1] = 0;
                }
             j=0;
						memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnContactListEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                           "Error : Could Not Set Data for IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY !!");
               return iRet;
             }
            }
      break;

      case   IFX_VMAPI_VS_PSTN_CONTACT_LIST:
            {
             int i;
             sprintf((char8*)acCommand, "%s_CpeId", "PstnContactList");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                  "Error : Could Not Get Data for  IFX_VMAPI_VS_PSTN_CONTACT_LIST !!");
               return iRet;
             }

              memset(pucIdList1,0,sizeof(pucIdList1));
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds);
             memset(uiPstnContactList,0,sizeof(uiPstnContactList));
                   for(i=0;i<ucNoOfIds;i++)
             {
               uiContactList[i] =  atoi(pucIdList1[i]);
 						}

                       uiObj = uiObjCpeIDs[IFX_VMAPI_VS_PSTN_CONTACT_LIST];
                       *(((uint32 *)uiObj) +
                      ((x_IFX_VMAPI_ContactList*)pxObj)->ucLineId - 4) = uiCpeId;

             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiPstnContactList[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                      "Error : Could Not Set Data for IFX_VMAPI_VS_PSTN_CONTACT_LIST !!");
               return iRet;
             }


  }
  break;

   case	IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY: 
            {
             int32 d, x;
             sprintf((char8*)acCommand, "%s_CpeId", "CommonContactEntry");
             if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Get Data for IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY !!");
               return iRet;   
             }

						 memset(pucIdList1,0,sizeof(pucIdList1)); 
             ifx_vmapi_ParseCpeId (acInBuf,&pucIdList1[0][0],&ucNoOfIds); 
             memset(&uiCommonContactListEntry,0,sizeof(uiCommonContactListEntry)); 
	           for(d=0;d<ucNoOfIds;d++)
             { 
               uiCommonContactListEntry[d] =  atoi(pucIdList1[d]); 
             }
					
						 uiObj = uiObjCpeIDs[IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY];
					     *(((uint32 *)uiObj) +
						      ((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex - 1) = uiCpeId;
	
						 if (uiCpeId == 0)
					   {
					     for (x=((x_IFX_VMAPI_ContactListEntry*)pxObj)->ucIndex;x<ucNoOfIds;x++)
						     uiCommonContactListEntry[x-1] = atoi(pucIdList1[x]) ;
						     uiCommonContactListEntry[x-1] = 0;
					   }
          
             j=0;
             memset(&PArray,0,sizeof(PArray));
             for(i=0;i<ucNoOfIds;i++)
             {
               sprintf(&PArray[j],"%d",uiCommonContactListEntry[i]);
               strcat(PArray,",");
               j=strlen(PArray);
             }
             PArray[j-1] = '\0';
             sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
             if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
                IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
    	          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					                 "Error : Could Not Set Data for IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY !!");
               return iRet;   
             }
            }
					break;

	default:
		return IFX_VMAPI_FAIL;
	}
	return IFX_VMAPI_SUCCESS;
}

#endif

/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_NewLineId
*  Description    : API to get next LineId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
void IFX_VMAPI_SortTheList(uchar8 a[], int32 N)
{
  int32 i, j;
  uchar8 t;
  for (i = N-1; i >= 0; i--)
  {
    for (j = 1; j <= i; j++)
    {
      if (a[j-1] > a[j])
      {
        t = a[j-1];
        a[j-1] = a[j];
        a[j] = t;
      }
    }
  }

}
/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_NewLineId
*  Description    : API to get next LineId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_Get_NewLineId()
{
  int32 i=0,j=0,flag=1,res=0;
  x_IFX_VMAPI_VoiceService xVS ;
	
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
	}
  for(j=0;j<IFX_VMAPI_MAX_VOICE_LINES;j++)
  {
    i=0;
    while(xVS.ucLineIdList[i] != 0)
    {
      if(xVS.ucLineIdList[i]==j+1)
      {
        flag =0;
        break;
      }
      else
      {
        flag=j+1;
      }
      i++;
    }
    if(flag!=0)
    {
      res=flag;
      break;
    }
    else
      continue;
  }
  return res;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_UpdateLineId
*  Description    : API to get next LineId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/

int32 IFX_VMAPI_Update_NewLineId(uchar8 iLineId)
{

  int32 i=0;
	
  x_IFX_VMAPI_VoiceService xVS ;
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_TR69;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
	}
  while(xVS.ucLineIdList[i] != 0)
  {
   i++;   
  }
  
  xVS.ucLineIdList[i] = iLineId;

  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceService(IFX_OP_MOD,&xVS,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  "Error : Failed Not Set ifx_set_VoiceService !!");
		return IFX_VMAPI_FAIL;
	}

  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Delete_LineId
*  Description    : API to delete the LineId from the VoiceService object.  
*  Input Values   : iLineId - line to be deleted
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 1) The LineId should be deleted from the LineIdList of 
*                   VoiceService Object.
*                   2) It should be removed from the Associated LineIdList of
*                   the corresponding Profile.
*                   3) Update the LineIdList of the associated Endpoints.
******************************************************************************/
int32 IFX_VMAPI_Delete_LineId(uchar8 iLineId)
{
  int32 m=0,n=0;
  int32 z=0,i=0,index=0;
  x_IFX_VMAPI_VoiceService xVS ;
  x_IFX_VMAPI_FxsPhyIf xFXS;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
  x_IFX_VMAPI_DectHandset xDectHand;
#endif
	
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
    return IFX_VMAPI_FAIL ;
	}
  /* Voice Line is deleted, so update the LineIdList */
	while (xVS.ucLineIdList[m] != 0)
	{
		if (xVS.ucLineIdList[m] == iLineId)
		{
		  n=m;
      while(xVS.ucLineIdList[n] != 0)
      {
        xVS.ucLineIdList[n] = xVS.ucLineIdList[n+1];
        n++; 
      }
      break;
    }
      m++;
  }

  m=0;
  /*Updating the VoiceLine Id List of each FXS, after deleting a Line*/
  /* Run it for both the FXS */
	for(index=1;index<=IFX_VMAPI_MAX_FXS_ENDPTS;index++)
	{
    memset(&xFXS,0,sizeof( x_IFX_VMAPI_FxsPhyIf));
	  xFXS.xVoiceServPhyIf.ucInterfaceId = index;
    xFXS.iid.config_owner = IFX_VOIP;
	  if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFXS,0))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Error : GET for FxsPhyInterface failed !!");
      return IFX_VMAPI_FAIL ;
    }
		
		/* If the default VoiceLineId is same as the LineId then delete that 
			   and set it to the next available VoiceLine else set it to 0 */
    i=0;  
		if(xFXS.ucVoiceLineId == iLineId)
		{
			while(xFXS.ucVoiceLineIdList[i] != 0)
			{
				if(xFXS.ucVoiceLineIdList[i] != iLineId)
				{
				  xFXS.ucVoiceLineId = xFXS.ucVoiceLineIdList[i];
				}
				else
				{
					xFXS.ucVoiceLineId = 0;
				}
				i++;
			}
		}

    /* Update the VoiceLineId list  */ 
    i=0;  
	  while (xFXS.ucVoiceLineIdList[i] != 0)
	  {
      /* Check if the corresponding deleted line is already there */
		  if (xFXS.ucVoiceLineIdList[i] == iLineId)
		  {
		    m=i;
        while(xFXS.ucVoiceLineIdList[m] != 0)
        {
         xFXS.ucVoiceLineIdList[m] = xFXS.ucVoiceLineIdList[m+1];
         m++; 
        }
        break;
      }
      i++;
    }
		
 	  if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,
												IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		    "Error : Failed Not Set ifx_set_FxsPhyInterface !!");
      return IFX_VMAPI_FAIL ;
    }  
  }/* For loop for IFX_VMAPI_MAX_FXS_ENDPTS */   

  i=0;
  m=0;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	/*Updating the VoiceLine Id List of each DECT, after deleting a Line*/
  /* Run it for all the DECT Handset */
	for(index=1;index<=IFX_VMAPI_MAX_DECT_ENDPTS;index++)
	{
		/* For DECT Handset */
		memset(&xDectHand,0,sizeof(xDectHand));
    xDectHand.xVoiceServPhyIf.ucInterfaceId = index+3 ;
    xDectHand.iid.config_owner = IFX_VOIP;
	  iRet = ifx_get_DectHandset(&xDectHand,0);
    if (iRet != IFX_VMAPI_SUCCESS)
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Error : GET for DectHandset failed !!");
      return IFX_VMAPI_FAIL ;
    }
    		
		/* If the default VoiceLineId is same as the Line then delete that 
		   and set it to the next available VoiceLine else 0 */
		i=0;
		if(xDectHand.ucVoiceLineId == iLineId)
		{
			while(xDectHand.aucVoiceLineIdList[i] != 0)
			{
				if(xDectHand.aucVoiceLineIdList[i] != iLineId)
				{
				  xDectHand.ucVoiceLineId = xDectHand.aucVoiceLineIdList[i];
				}
				else
				{
					xDectHand.ucVoiceLineId = 0;
				}
				i++;
			}
		}

		i=0;
			
		/* Remove the LineId from the VoiceLineId List */
  	while (xDectHand.aucVoiceLineIdList[i] != 0)
	  {
      /* Check if the corresponding line is already there */
		  if (xDectHand.aucVoiceLineIdList[i] == iLineId)
		  {
		    m=i;
        while(xDectHand.aucVoiceLineIdList[m] != 0)
        {
          xDectHand.aucVoiceLineIdList[m] = xDectHand.aucVoiceLineIdList[m+1];
          m++; 
        }
        break;
      }
      i++;
    }
			
		/* SET the object */
 	  if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		    "Error : Failed to Set ifx_set_DectHandset !!");
      return IFX_VMAPI_FAIL ;
    }  

  }/* For loop for IFX_VMAPI_MAX_DECT_ENDPTS */   
#endif
i=0;	
	/*Updating the AssoLineIds of the Profile, after deleting a Line*/
  while(xVS.ucProfileIdList[i] != 0)
  {
    memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = xVS.ucProfileIdList[i];
    xVoiceProf.iid.config_owner = IFX_VOIP;
 	  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	     "Error : Failed Not Get VoiceProfile !!");
      return IFX_VMAPI_FAIL ;
    }
    m=0;  
 	  while (xVoiceProf.aucAssoLineIds[m] != 0)
	  {
      /* Check if the corresponding deleted line is already there */
		  if (xVoiceProf.aucAssoLineIds[m] == iLineId)
		  {
        xVoiceProf.ucNoOfLines -= 1;
		    z=m;
        while(xVoiceProf.aucAssoLineIds[z] != 0)
        {
         xVoiceProf.aucAssoLineIds[z] = xVoiceProf.aucAssoLineIds[z+1];
         z++; 
        }
        break;
      }
      m++;
    }
    m=0;  
 	  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		    "Error : Failed Not Set VoiceProfile !!");
      return IFX_VMAPI_FAIL ;
    }  
    i++;
    m=0;
  }/* while loop for ucProfileIdList */

  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceService(IFX_OP_MOD,&xVS,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
  {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  "Error : Failed Not Set VoiceService !!");
    return IFX_VMAPI_FAIL ;
  } 
  return IFX_VMAPI_SUCCESS;

}
/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_NewProfileId
*  Description    : API to get next ProfileId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_Get_NewProfileId()
{
  int32 i=0,j=0,flag=1,iNewProfId=0;
  x_IFX_VMAPI_VoiceService xVS ;
	
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
    return IFX_VMAPI_FAIL ;
	}
  for(j=0;j<IFX_VMAPI_MAX_VOICE_PROFILES;j++)
  {
    i=0;
    while(xVS.ucProfileIdList[i] != 0)
    {
      if(xVS.ucProfileIdList[i]==j+1)
      {
        flag =0;
        break;
      }
      else
      {
        flag=j+1;
      }
      i++;
    }
    if(flag!=0)
    {
      iNewProfId=flag;
      break;
    }
    else
      continue;
  }
  return iNewProfId;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Update_NewProfileId
*  Description    : API to get next ProfileId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_Update_NewProfileId(uchar8 iProfileId)
{

  int32 i=0;
  x_IFX_VMAPI_VoiceService xVS ;
	
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_TR69;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
    return IFX_VMAPI_FAIL ;
	}
 
  while(xVS.ucProfileIdList[i] != 0)
  {
   i++;   
  }
  
  xVS.ucProfileIdList[i] = iProfileId;
  xVS.uiNumProfiles ++;

  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceService(IFX_OP_MOD,&xVS,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  "Error : Failed Not Set VoiceService !!");
		return IFX_VMAPI_FAIL;
	}

  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Delete_ProfileId
*  Description    : API to deletethe ProfileId from the VoiceService object.  
*  Input Values   : iProfileId - profile to be deleted
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_Delete_ProfileId(uchar8 iProfileId)
{
  int32 m=0,n=0;
  x_IFX_VMAPI_VoiceService xVS ;
	
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
    return IFX_VMAPI_FAIL ;
	}

  /* Voice Profile is deleted, so update the number of profiles of VoiceService*/
  xVS.uiNumProfiles -= 1;

  /* Voice Profile is deleted, so update the ProfileIdList of VoiceService*/
	while (xVS.ucProfileIdList[m] != 0)
	{
		if (xVS.ucProfileIdList[m] == iProfileId)
		{
		  n=m;
      while(xVS.ucProfileIdList[n] != 0)
      {
        xVS.ucProfileIdList[n] = xVS.ucProfileIdList[n+1];
        n++; 
      }
      break;
    }
      m++;
   }
  /* SET the VoiceService*/
  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceService(IFX_OP_MOD,&xVS,
													IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  "Error : Failed Not Set VoiceService !!");
		return IFX_VMAPI_FAIL;
	}
  return IFX_VMAPI_SUCCESS;

}
/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_LatestProfileId
*  Description    : API to get next LineId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
uchar8 IFX_VMAPI_Get_LatestProfileId()
{
  int32 i=0;
  x_IFX_VMAPI_VoiceService xVS ;
	
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
    return IFX_VMAPI_FAIL ;
	}
  while(xVS.ucProfileIdList[i] != 0)
  {
    i++;
  }
  if(i > 0)
	return xVS.ucProfileIdList[i-1];
	else
		return 0;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_LatestLineId
*  Description    : API to get next LineId of a VMAPI object.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucObjCode - any of the values in IFX_VMAPI_OBJ
*  Output Values  : uiCpeId - integer cpeId
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
uchar8 IFX_VMAPI_Get_LatestLineId()
{
  int32 i=0;
  x_IFX_VMAPI_VoiceService xVS ;
  memset(&xVS,0,sizeof(x_IFX_VMAPI_VoiceService));
	xVS.iid.cpeId.Id = 1;
	xVS.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVS,0))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   "Error : GET for Voice Service failed !!");
    return IFX_VMAPI_FAIL ;
	}
  while(xVS.ucLineIdList[i] != 0)
  {
    i++;
  }
  if(i > 0)
		return xVS.ucLineIdList[i-1];
	else
    return 0;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Get_LinePcpeId 
*  Description    : API to get the Parent CpeId of from the given Voice LineId.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucLineId - VoiceLine Id
*  Output Values  : pucPcpeId - pointer to the PcpeId storage
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
uchar8 IFX_VMAPI_Get_LinePcpeId(IN uchar8 ucLineId, OUT uchar8 *pucPcpeId)
{
  x_IFX_VMAPI_VoiceLine xVL ;
  memset(&xVL,0,sizeof(x_IFX_VMAPI_VoiceLine));
	xVL.ucLineId = ucLineId;
	xVL.iid.config_owner = IFX_VOIP;
  if(ifx_get_VoiceLine(&xVL,0) != IFX_VMAPI_SUCCESS)
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  "Error : Failed Not Get VoiceLine !!");
		return IFX_VMAPI_FAIL;
	}
	else
	{
		*pucPcpeId = xVL.ucProfileId;
	}

	return IFX_VMAPI_SUCCESS;
}


/******************************************************************************
*  Function Name  : IFX_VMAPI_ReplaceCpeId 
*  Description    : API to get the Parent CpeId of from the given Voice LineId.  
*  									This should be called to get the cpeId allocated by the
*  									MAPI "after" a "successful" add operation.
*  Input Values   : ucLineId - VoiceLine Id
*  Output Values  : pucPcpeId - pointer to the PcpeId storage
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
uchar8 IFX_VMAPI_ReplaceCpeId(IN char8* pcPrefix,
															IN uint32 uiCpeId)
{
  uint32 uiOutF = 0;
  uint32 uiInF = 0;
  char8 acBuf[IFX_MAX_BUFF_LEN] = {0};
  char8 acCmd[MAX_FILELINE_LEN] = {0};
  char8 pucList[200][5];
  uchar8 ucIdCnt;
  uint32 uiEntry[87];
  //uint32 uiEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_CODECS];
  char8 ucArr[300]={0};
  char8 NVArr[300]={0};
  int32 i=0;
  int32 index=0;
	int32 j;
 
	sprintf((char8*)acCmd, "%s_CpeId", pcPrefix);
  if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
     acCmd, uiInF, &uiOutF, acBuf)) != IFX_SUCCESS)  {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		    "Error :  Could Not Get Data !!");
    return IFX_VMAPI_FAIL;   
  }
  memset(pucList,0,sizeof(pucList)); 
  ifx_vmapi_ParseCpeId (acBuf,&pucList[0][0],&ucIdCnt); 
  memset(uiEntry,0,sizeof(uiEntry)); 
	for(i=0;i<ucIdCnt;i++)
  { 
    uiEntry[i] =  atoi(pucList[i]);
		if(uiEntry[i] == uiCpeId )
		{
			 uiEntry[i] = 0; 
			 index = i;
		}
  }

	j =0;
	if(strcmp(pcPrefix,"NumPlanRules") == 0)
	{
		for (j=index;j<ucIdCnt-1;j++)
		{
	  	uiEntry[j] = atoi(pucList[j+1]) ;
		}
	}

  j=0;
  memset(&ucArr,0,sizeof(ucArr));
  for(i=0;i<ucIdCnt;i++)
  {
    sprintf(&ucArr[j],"%d",uiEntry[i]);
    strcat(ucArr,",");
    j=strlen(ucArr);
  }
	if(j)  
		ucArr[j-1] = '\0';
  sprintf(NVArr,"%s=\"%s\"\n",acCmd,ucArr);
	//printf("[%s  %d] NVArr = %s\n",__FUNCTION__, __LINE__, NVArr);
  if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
          IFX_F_MODIFY, 1, (char8*)NVArr)) != IFX_SUCCESS)  {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Error :  Could Not Get Data !!");
      return IFX_VMAPI_FAIL;;   
  }

	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_GetProfileIdFromCpeId
*  Description    : API to get the ProfileId for a given CpeId.  
*  Input Values   : uiCpeId  - CpeId
*  Output Values  : ucProfileId - Profile Id
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_GetProfileIdFromCpeId(uint32 uiCpeId, uchar8 *ucProfileId)
{
  uint32 uiOutF = 0;
  uint32 uiInF = 0;
  char8 acBuf[IFX_MAX_BUFF_LEN] = {0};
	char8 pucList[200][5];
  uchar8 ucIdCnt;
  uint32 uiEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_CODECS];
  int32 i=0;
  iRet = IFX_VMAPI_FAIL;
 
  if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
      "VoiceProfile_CpeId", uiInF, &uiOutF, acBuf)) != IFX_SUCCESS)  {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		       "Error :  Could Not Get Data !!");
         return iRet;   
  }
  memset(pucList,0,sizeof(pucList)); 
  ifx_vmapi_ParseCpeId (acBuf,&pucList[0][0],&ucIdCnt); 
	//printf("[%s  %d] acBuf %s and ucIdCnt =%d CpeId =%d\n",
		//			 __FUNCTION__, __LINE__, acBuf,ucIdCnt,uiCpeId);
  memset(uiEntry,0,sizeof(uiEntry)); 
	for(i=0;i<ucIdCnt;i++)
  { 
	  uiEntry[i] = atoi(pucList[i]) ;
		if(uiEntry[i] == uiCpeId )
		{
		  *ucProfileId = i+1; 
			break;
		}
  }
  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_GetLineIdFromCpeId
*  Description    : API to get the ProfileId for a given CpeId.  
*  Input Values   : uiCpeId  - CpeId
*  Output Values  : ucProfileId - Profile Id
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_GetLineIdFromCpeId(uint32 uiCpeId, uchar8 *ucLineId)
{
  uint32 uiOutF = 0;
  uint32 uiInF = 0;
  char8 acBuf[IFX_MAX_BUFF_LEN] = {0};
	char8 pucList[200][5];
  uchar8 ucIdCnt;
  uint32 uiEntry[IFX_MAX_VOICE_LINES * IFX_VMAPI_MAX_CODECS];
  int32 i=0;
  iRet = IFX_VMAPI_FAIL;
 
  if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, 
														"Map_Info",
														"VoiceLine_CpeId", 
														uiInF, &uiOutF, acBuf)) != IFX_SUCCESS)  {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Error :  Could Not Get Data !!");
       return iRet;   
  }
  memset(pucList,0,sizeof(pucList)); 
  ifx_vmapi_ParseCpeId (acBuf,&pucList[0][0],&ucIdCnt); 
	//printf("[%s  %d] acBuf %s and ucIdCnt =%d CpeId =%d\n",
	//				 __FUNCTION__, __LINE__, acBuf,ucIdCnt,uiCpeId);
  memset(uiEntry,0,sizeof(uiEntry)); 
	for(i=0;i<ucIdCnt;i++)
  { 
	  uiEntry[i] = atoi(pucList[i]) ;
		if(uiEntry[i] == uiCpeId )
		{
		  *ucLineId = i+1; 
			break;
		}
  }
  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_AssociateLineIdwithProfileId
*  Description    : API to get the ProfileId for a given CpeId.  
*  Input Values   : uiCpeId  - CpeId
*  Output Values  : ucProfileId - Profile Id
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 
IFX_VMAPI_AssociateLineIdwithProfileId(uchar8 ucProfileId, uchar8 ucLineId)
{

	int32 flag1=0,count1=0,x=0;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;

  /* If no error,Assigning Line Id to the AssoLineIds of profile */
  memset(&xVoiceProf,0,sizeof(xVoiceProf));
  xVoiceProf.ucProfileId = ucProfileId;
  xVoiceProf.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
  {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		    "Error :  Could Not Get Data !!");
    return IFX_VMAPI_FAIL;   
  }

  /* Checking if Line is already associated in the VoiceProfile*/
  while(xVoiceProf.aucAssoLineIds[x] != 0)
  { 
    if(xVoiceProf.aucAssoLineIds[x] == ucLineId)
    {
      flag1 = 1;
			return IFX_VMAPI_SUCCESS ; /* No need to set the VoiceProfile */
    } 
		count1++;
    x++;
  } 

  /* If not associated then assign it to the AssoLineIds of the profile */
  if(flag1 == 0)
  {
    xVoiceProf.aucAssoLineIds[count1] = ucLineId;
    xVoiceProf.ucNoOfLines+=1;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  	  "Error :  Could Not Get Data !!");
    	return IFX_VMAPI_FAIL;   
    }
  } 
  return IFX_VMAPI_SUCCESS;

}
 
