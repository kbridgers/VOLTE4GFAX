/**************************************************************************
 **   FILE NAME       : ifx_vmapi.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Voice Management API definitions
 **   SRC VERSION     : V0.1
 **   DATE            : 05-04-2007
 **   AUTHOR          : Purnendu
 **   DESCRIPTION     : This file contains the Voice Management API function
 **                      definitions.
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_vmapi_port.h"
#include "ifx_list.h"
#include "ifx_debug.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_bintxt.h"
#include "ifx_vmapi_obj_param_tbl.h"
#include "ifx_vmapi_mapi_int.h"
#include "ifx_vmapi_cpeid.h"
#include "ifx_vmapi_api.h"

#ifdef HOST_SUPPORT
#ifdef SYSTEM_CONF_FILE
#undef SYSTEM_CONF_FILE
#define SYSTEM_CONF_FILE "/tmp/rc.conf"
#endif
#endif

#define printf(...)
extern
char8 IFX_VMAPI_Default_VoiceService(
                IN_OUT x_IFX_VMAPI_VoiceService *pxVoiceService);
extern 
char8 IFX_VMAPI_Default_VoiceProfile(
                IN_OUT x_IFX_VMAPI_VoiceProfile *pxVoiceProfile);
extern
char8 IFX_VMAPI_Default_ProfileSignaling(
		IN_OUT x_IFX_VMAPI_ProfileSignaling *pxProfileSig);
extern
char8 IFX_VMAPI_Default_ProfileMediaRtp(
		IN_OUT x_IFX_VMAPI_ProfileMediaRTP *pxProfMed);
extern
char8 IFX_VMAPI_Default_ProfileEvents(
                IN_OUT x_IFX_VMAPI_EventSubscribe *pxEvent);
extern
char8 IFX_VMAPI_Default_CallingFeature(
		IN_OUT x_IFX_VMAPI_LineCallingFeatures *pxCallFeat);
extern
char8 IFX_VMAPI_Default_LineEvents(
                IN_OUT x_IFX_VMAPI_LineEvents *pxLineEvent);
extern
char8 IFX_VMAPI_Default_Misc(IN x_IFX_VMAPI_Misc *pxMisc);
extern
char8 IFX_VMAPI_Default_VoiceLine(
		IN_OUT  x_IFX_VMAPI_VoiceLine  *pxVoiceLine);
extern
char8 IFX_VMAPI_Default_LineCodecDesc(
                IN_OUT x_IFX_VMAPI_CodecDesc *pxCodecDesc);


FILE *fp; 
FILE *numF;
//static uint32 mycount=0;

int
ifx_ParseCallBlockList (uchar8 * ucSrc, uchar8 * ucDestList,uchar8 * iLength);

int
ifx_ParseCallBlockListDevice (char8 * ucSrc, char8 * ucDestList,uchar8 * iLength); 

int32 LTQ_set_DectObject(IN uint32  uiOperation,
                      IN_OUT  void *pvDectObject,
                      IN uint32 uiObjectType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag);

int32 LTQ_set_VoipSystemObject(IN uint32  uiOperation,
                      IN_OUT  void *pvSysObject,
                      IN uint32 uiObjectType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag);

int32 LTQ_set_VoipProfileObject(IN uint32  uiOperation,
                      IN_OUT  void *pvProfObject,
                      IN uint32 uiObjectType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag);


int32 LTQ_get_ActionInfo(IN uint32 uiOperation,OUT uint32 *uiInFlag);

int32 LTQ_set_VoiceLineObject(IN uint32  uiOperation,
                      IN_OUT  void *pvVLObject,
                      IN uint32 uiObjectType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag);

#define CHECK_ACS_SESSION_OWNER_COMBINATION(ConfigOwner) 
  /*IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, \
					 "CHECK_ACS_SESSION_OWNER_COMBINATION Not implemented..................\n");*/

//Global varibale. It is used in all get/st functions
x_IFX_VMAPI_NameValueList g_xNVList; 

/******************************************************************************
*  Function Name  : IFX_VMAPI_Print_NameVal
*  Description    : This function is used to print the name-value pair
*  Input Values   :  pxNVList - list of name-value pairs
*                    unNoOfNVPairs - total number of name-value pairs
*  Output Values  : 
*  Return Value   :
*  Notes          : This is an internal function used by the vmapi get apis.
*                    It prints the name-value pair
******************************************************************************/
VOID IFX_VMAPI_Print_NameVal(IFX_NAME_VALUE_PAIR *pxNVList, 
														 uint16 unNoOfNVPairs)
{
  int32 uiIdx; 

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_NO_NV_PAIRS,
			   unNoOfNVPairs);
	if (!pxNVList) {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, "NULL list");
		return;
	}
  for (uiIdx=0; uiIdx<unNoOfNVPairs; uiIdx++) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_NV_PAIRS,
						uiIdx,pxNVList[uiIdx].fieldname, pxNVList[uiIdx].value);
  }
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "-------------------Leaving-------------------");

  return;
}

/***********************************************************************/
STATIC VOID
ifx_get_NVPairsFromString(IN uchar8 *pcStr,
                          OUT x_IFX_VMAPI_NameValueList *pxNVList)
{
  int32 iNVPair=0;
  uchar8 *pcStrEnd, *pcStrBgn;
  
  pcStrEnd = pcStrBgn = pcStr;
  while((pcStrEnd = (uchar8*)IFX_VMAPI_STRSTR(pcStrBgn, "=")) != NULL) {
    IFX_VMAPI_STRNCPY(pxNVList->axNameValue[iNVPair].fieldname, pcStrBgn, 
                          pcStrEnd - pcStrBgn);
    pxNVList->axNameValue[iNVPair].fieldname[pcStrEnd - pcStrBgn] = '\0';
    pcStrBgn = ++pcStrEnd;
    pcStrEnd = (uchar8*)IFX_VMAPI_STRSTR(pcStrBgn, "\n");
    IFX_VMAPI_STRNCPY(pxNVList->axNameValue[iNVPair].value, pcStrBgn+1,
                (pcStrEnd-1) - pcStrBgn); /* +1 and -1 to ignore \" */
    pxNVList->axNameValue[iNVPair].value[pcStrEnd-1 - (pcStrBgn+1)] = '\0';
    pcStrBgn = ++pcStrEnd;
    ++iNVPair;
  }
  pxNVList->unNoOfNVPairs = iNVPair;

  return;
}

#ifdef DECT_PART
/******************************************************************************
*  Function Name  : IFX_VMAPI_GetNVPairsForObject
*  Description    : This function is used to get an object from the config file
*                    object provided.
*  Input Values   : uiObjCode - object code of reqd object.
*                    uiInstance - object instance id.
*                    uiInFlag - Input flags
*  Output Values  : pvObj - pointer to the output object.
*  Return Value   : IFX_VMAPI_SUCCESS, on successfully getting name-value pairs.
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : This is an internal function used by the vmapi get apis.
*                    It frames name-value pairs by getting the name-values from
*                    the config file and then converts them into the object 
*                    structure.
******************************************************************************/
int32 IFX_VMAPI_GetNVPairsForObject_V1(OUT VOID *pvObj,
                     OUT x_IFX_VMAPI_NameValueList *pxNVList,
                     IN uint32 uiObjCode,
                     IN uchar8  *pcPrefix,
                     IN uint32 uiInFlag)
{
  int32 iRet;
  char8 *s=NULL;


  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_PREFIX,
           pcPrefix);
  pxNVList->unNoOfNVPairs  = 0;
  iRet = ifx_GetCfgObject(DECT_RC_CONF_FILE,
                    IFX_VMAPI_GET_OBJ_NAME(uiObjCode),
                    (char8*)pcPrefix,
                    uiInFlag, &s);
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GET_STRING,
                  s,IFX_VMAPI_GET_OBJ_NAME(uiObjCode));
  if (iRet == IFX_VMAPI_SUCCESS) {
    ifx_get_NVPairsFromString((uchar8*)s, pxNVList);
    /*
    IFX_VMAPI_FORM_ARRAY_FVP_FROM_CFG_BUG(s, &pxNVList->unNoOfNVPairs,
                          pxNVList->axNameValue);
    IFX_VMAPI_PRINT_NAMEVAL(pxNVList->axNameValue, pxNVList->unNoOfNVPairs);
    */
    }
  IFX_VMAPI_FREE(s);
return iRet;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_GetObjectFromCpeid_V1
*  Description    : This function is used to get a vmapi object. It calls the
*										relevant management API to get name-value pairs from the
*										input cpeId and forms the vmapi object out of it.
*  Input Values   :	uiObjectId - object code
*										pIid - IFX_ID
*										uiInFlag - input flags
*  Output Values  : pvObj - output object
*  Return Value   : IFX_VMAPI_SUCCESS on success, IFX_VMAPI_FAIL on failure.
*  Notes          : 
******************************************************************************/
int32 IFX_VMAPI_GetObjectFromCpeid_V1(IN uint32 uiObjectId,
                          IN  IFX_ID *pIid,
                          IN_OUT VOID *pvObj,
                          IN uint32 uiInFlag
                          )
{
  uchar8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN + IFX_VMAPI_MAX_INT_LEN];
  uint32 uiNameValIdx=0;
  int32 iRet = IFX_VMAPI_FAIL;
  int32 iInstanceIndex = -1;
  /* lock */
  IFX_VMAPI_LOCK(uiLock);
  if (pIid) {
    IFX_VMAPI_STRCPY(pIid->cpeId.secName,
                   IFX_VMAPI_GET_OBJ_NAME(uiObjectId) );

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_SEC_CPEID,
              pIid->cpeId.secName,pIid->cpeId.Id);
    if (ifx_get_index_from_cpe_id(DECT_RC_CONF_FILE,
           &pIid->cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid");
       IFX_VMAPI_UNLOCK(uiLock);
return iRet;
    }

    IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_%d_",
                    (char8*)IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),
                    iInstanceIndex );
  }
  else {
    IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_",
                    (char8*)IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId));
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_PREFIX,
           acPrefix);

  if ((iRet = IFX_VMAPI_GetNVPairsForObject_V1((VOID*)pvObj, &g_xNVList,
              uiObjectId, acPrefix, uiInFlag) ) == IFX_VMAPI_SUCCESS) { 
IFX_VMAPI_PRINT_NAMEVAL(g_xNVList.axNameValue, g_xNVList.unNoOfNVPairs);
   iRet = IFX_VMAPI_GetObjFromNameValueList(uiObjectId,
              (VOID*)pvObj, &g_xNVList, &uiNameValIdx, acPrefix);
  } else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "ifx_GetCfgObject returned failure\n");
  }

  /* unlock */
  IFX_VMAPI_UNLOCK(uiLock);

  return iRet;

}
#endif
/******************************************************************************
*  Function Name  : IFX_VMAPI_GetNVPairsForObject
*  Description    : This function is used to get an object from the config file
*                    object provided.
*  Input Values   : uiObjCode - object code of reqd object.
*                    uiInstance - object instance id.
*                    uiInFlag - Input flags
*  Output Values  : pvObj - pointer to the output object.
*  Return Value   : IFX_VMAPI_SUCCESS, on successfully getting name-value pairs.
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : This is an internal function used by the vmapi get apis.
*                    It frames name-value pairs by getting the name-values from
*                    the config file and then converts them into the object 
*                    structure.
******************************************************************************/
int32 IFX_VMAPI_GetNVPairsForObject(OUT VOID *pvObj,
                     OUT x_IFX_VMAPI_NameValueList *pxNVList,
                     IN uint32 uiObjCode,
                     IN uchar8  *pcPrefix,
                     IN uint32 uiInFlag)
{
  int32 iRet;
  char8 *s=NULL;


  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_PREFIX,
					 pcPrefix);
  pxNVList->unNoOfNVPairs  = 0;
  iRet = ifx_GetCfgObject(SYSTEM_CONF_FILE,
                    IFX_VMAPI_GET_OBJ_NAME(uiObjCode),
                    (char8*)pcPrefix,
                    uiInFlag, &s);
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GET_STRING, 
									s,IFX_VMAPI_GET_OBJ_NAME(uiObjCode));
  if (iRet == IFX_VMAPI_SUCCESS) {
    ifx_get_NVPairsFromString((uchar8*)s, pxNVList);
		/*
    IFX_VMAPI_FORM_ARRAY_FVP_FROM_CFG_BUG(s, &pxNVList->unNoOfNVPairs,
                          pxNVList->axNameValue);
    IFX_VMAPI_PRINT_NAMEVAL(pxNVList->axNameValue, pxNVList->unNoOfNVPairs);
		*/
		}
  IFX_VMAPI_FREE(s);
return iRet;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_GetObjectFromCpeid
*  Description    : This function is used to get a vmapi object. It calls the
*										relevant management API to get name-value pairs from the
*										input cpeId and forms the vmapi object out of it.
*  Input Values   :	uiObjectId - object code
*										pIid - IFX_ID
*										uiInFlag - input flags
*  Output Values  : pvObj - output object
*  Return Value   : IFX_VMAPI_SUCCESS on success, IFX_VMAPI_FAIL on failure.
*  Notes          : 
******************************************************************************/
int32 IFX_VMAPI_GetObjectFromCpeid(IN uint32 uiObjectId,
                          IN  IFX_ID *pIid,
                          IN_OUT VOID *pvObj,
                          IN uint32 uiInFlag
                          )
{
  uchar8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN + IFX_VMAPI_MAX_INT_LEN];
  uint32 uiNameValIdx=0;
  int32 iRet = IFX_VMAPI_FAIL;
  int32 iInstanceIndex = -1;
  /* lock */
  IFX_VMAPI_LOCK(uiLock);
  if (pIid) {
    IFX_VMAPI_STRCPY(pIid->cpeId.secName,
                   IFX_VMAPI_GET_OBJ_NAME(uiObjectId) );

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_SEC_CPEID,
              pIid->cpeId.secName,pIid->cpeId.Id);
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
           &pIid->cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid");
       IFX_VMAPI_UNLOCK(uiLock);
return iRet;
    }

    IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_%d_",
                    (char8*)IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),
                    iInstanceIndex );
  }
  else {
    IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_",
                    (char8*)IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId));
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_PREFIX,
           acPrefix);

  if ((iRet = IFX_VMAPI_GetNVPairsForObject((VOID*)pvObj, &g_xNVList,
              uiObjectId, acPrefix, uiInFlag) ) == IFX_VMAPI_SUCCESS) { 
IFX_VMAPI_PRINT_NAMEVAL(g_xNVList.axNameValue, g_xNVList.unNoOfNVPairs);
   iRet = IFX_VMAPI_GetObjFromNameValueList(uiObjectId,
              (VOID*)pvObj, &g_xNVList, &uiNameValIdx, acPrefix);
  } else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "ifx_GetCfgObject returned failure\n");
  }

  /* unlock */
  IFX_VMAPI_UNLOCK(uiLock);

  return iRet;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_SetBitMapEntry_opt
*  Description          :   This Function Sets the AddrBookBitMap value in rc.conf
*  Input Values         :   BitMap pattern, BitMap value 
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/
uchar8 IFX_VMAPI_SetBitMapEntry_opt(char8 *pcString, uint32 uiBitMap)
{
  int32 iRet;        
  uchar8 NVPair[50]={0};

  sprintf((char8*)NVPair,"%s=\"%d\"\n",pcString,uiBitMap);
  if((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
           IFX_F_MODIFY, 1, (char8*)NVPair)) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "SET Data failed AddrBookBitMap\n");
  }
  return iRet;
}
/*****************************************************************************
*  Function Name        :   IFX_VMAPI_GetBitMapEntry_opt
*  Description          :   This Function Get the BitMap value from rc.conf
*  Input Values         :   BitMap pattern  
*  Output Values        :   BitMap pattern value
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/
uint32 IFX_VMAPI_GetBitMapEntry_opt(char8 *pcString , uint32 *uiBitMap)
{
  int32 iRet=IFX_VMAPI_SUCCESS;
  uint32 uiOutF = 0;
  uint32 uiInF = 0;
  char8 acBuf[IFX_MAX_BUFF_LEN] = {0};

  if((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
         pcString, uiInF, &uiOutF, acBuf)) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "GET Data failed AddrBookBit Map\n");
    return iRet;
  }
  *uiBitMap = atoi(acBuf);
  return iRet;
}


#if 0
/******************************************************************************
*  Function Name  : ifx_update_EntryId
*  Description    : This function is used to update the entry id of a given list
*                   in the global pool.
*  Input Values   : ucList - List Id
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS on success, IFX_VMAPI_FAIL on failure.
*  Notes          :
******************************************************************************/

int32 ifx_update_EntryId(uchar8 ucList)
{
 x_IFX_VMAPI_VoiceService xVoiceServ;
 int32 j=0;
	uint32 uiEntryId=0;

    /* Get the number of lines from the VoiceService LineIdList */
    memset(&xVoiceServ,0,sizeof(xVoiceServ));
    xVoiceServ.iid.config_owner = IFX_VOIP;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceServ,0))
    {
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                        "Error : Could Not Get Voice Service \n");
    }

  switch(ucList)
  {
    case IFX_VMAPI_VS_MISSCALL_REGISTER:
      {
        x_IFX_VMAPI_MissCallRegister xMissCallReg;
        x_IFX_VMAPI_MissCallRegEntry *pxTemp;

	/* Get the position of the last created LineId from the LineIdList */
    	while(xVoiceServ.ucLineIdList[j] != 0)
    	{  
        	/* Get the full list of MissCallRegEntry  */
        	//xMissCallReg.iid.cpeId.Id = 1;
        	memset(&xMissCallReg,0,sizeof(x_IFX_VMAPI_MissCallRegister));	
		xMissCallReg.ucLineId =xVoiceServ.ucLineIdList[j]; 
		xMissCallReg.ucIndex = 0;
        	xMissCallReg.iid.config_owner = IFX_VOIP;
        	if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xMissCallReg,0))
        	{
          		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		"Error : Could Not Get Miss CallReg in \n");
        	}

        	pxTemp = xMissCallReg.pxCallRegEntries;
        	while(pxTemp !=NULL)
        	{
          		uiEntryId |= (1<<(pxTemp->uiEntryId-1));
          		__ifx_list_GetNext((void *)&pxTemp);
        	}
	 	ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
	  j++;
       }
	 IFX_VMAPI_SetBitMapEntry_opt("MissCallBitMap",uiEntryId);
      }
      break;
    case IFX_VMAPI_VS_RECVCALL_REGISTER:
    {
        x_IFX_VMAPI_RecvCallRegister xRecvCallReg;
        x_IFX_VMAPI_RecvCallRegEntry *pxTemp;
	 while(xVoiceServ.ucLineIdList[j] != 0)
        {
        	memset(&xRecvCallReg,0,sizeof(x_IFX_VMAPI_RecvCallRegister));	
                xRecvCallReg.ucLineId =xVoiceServ.ucLineIdList[j]; 
        	xRecvCallReg.iid.config_owner = IFX_VOIP;
        	if(IFX_VMAPI_SUCCESS != ifx_get_RecvCallReg(&xRecvCallReg,0))
        	{
          		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		"Error : Could Not Get Recv CallReg in \n");
        	}

        	pxTemp = xRecvCallReg.pxCallRegEntries;
        	while(pxTemp !=NULL)
        	{
          		pxTemp->uiEntryId -=(IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_PSTN_LINE);
          		uiEntryId |= (1<<(pxTemp->uiEntryId-1));
          		__ifx_list_GetNext((void *)&pxTemp);
        	}
		ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
		j++;
	}        
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_RECVCALL_REGISTER,uiRecvEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("RecvCallBitMap",uiEntryId);
    }
      break;
    case IFX_VMAPI_VS_DIALCALL_REGISTER:
      {
        x_IFX_VMAPI_DialCallRegister xDialCallReg;
        x_IFX_VMAPI_DialCallRegEntry *pxTemp;
	 while(xVoiceServ.ucLineIdList[j] != 0)
        {
        	memset(&xDialCallReg,0,sizeof(x_IFX_VMAPI_DialCallRegister));	
        	xDialCallReg.ucLineId = xVoiceServ.ucLineIdList[j];
        	xDialCallReg.iid.config_owner = IFX_VOIP;
        	if(IFX_VMAPI_SUCCESS != ifx_get_DialCallReg(&xDialCallReg,0))
        	{
          		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		"Error : Could Not Get Dial CallReg in \n");
        	}

        	pxTemp = xDialCallReg.pxCallRegEntries;
        	while(pxTemp !=NULL)
        	{
          		 pxTemp->uiEntryId -=(2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_PSTN_LINE);
							uiEntryId |= (1<<(pxTemp->uiEntryId-1));
          		__ifx_list_GetNext((void *)&pxTemp);
        	}
        ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
	   j++;
	}
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_DIALCALL_REGISTER,uiDialEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("DialCallBitMap",uiEntryId);
     }
     break;

    case IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY:
      {
        x_IFX_VMAPI_AddressBook xAddrBook;
        x_IFX_VMAPI_AddressBookEntry *pxTemp;

        /* Get the full list of AddressBook */
        xAddrBook.iid.cpeId.Id = 1;
        xAddrBook.iid.pcpeId.Id = 1;
        xAddrBook.iid.config_owner = IFX_VOIP;
        if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,0))
        {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Error : Could Not Get Address Book \n");
        }

        pxTemp = xAddrBook.pxAddressBook;
        while(pxTemp !=NULL)
        {
          uiEntryId |= (1<<(pxTemp->uiEntryId-1));
          __ifx_list_GetNext((void *)&pxTemp);
        }
        ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,uiAddrEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("AddrBookBitMap",uiEntryId);

      }
      break;
case IFX_VMAPI_VS_CONTACT_LIST:
      {

	x_IFX_VMAPI_ContactList xContactList;
        x_IFX_VMAPI_ContactListEntry *pxTemp;

        /* Get the position of the last created LineId from the LineIdList */
        while(xVoiceServ.ucLineIdList[j] != 0)
        {
                /* Get the full list of ContactListEntry  */
                //xContactList.iid.cpeId.Id = 1;
                memset(&xContactList,0,sizeof(x_IFX_VMAPI_ContactList));
                xContactList.ucLineId =xVoiceServ.ucLineIdList[j];
                xContactList.iid.config_owner = IFX_WEB;
                if(IFX_VMAPI_SUCCESS != ifx_get_ContactList(&xContactList,0))
                {
                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                        "Error : Could Not Get Miss CallReg in \n");
                }

                pxTemp = xContactList.pxContactEntries;
                while(pxTemp !=NULL)
                {
                        uiEntryId |= (1<<(pxTemp->uiEntryId-1));
                        __ifx_list_GetNext((void *)&pxTemp);
                }
         	ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
          j++;
       }
         //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_CONTACT_LIST,uiContactEntryId);
         IFX_VMAPI_SetBitMapEntry_opt("ContactListBitMap",uiEntryId);
      }
      break;

    case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
      {
        x_IFX_VMAPI_MissCallRegister xMissCallReg;
        x_IFX_VMAPI_MissCallRegEntry *pxTemp;

        	memset(&xMissCallReg,0,sizeof(x_IFX_VMAPI_MissCallRegister));	
					xMissCallReg.ucLineId=4; 
					xMissCallReg.ucIndex = 0;
        	xMissCallReg.iid.config_owner = IFX_VOIP;
        	if(IFX_VMAPI_SUCCESS != ifx_get_PstnMissCallReg(&xMissCallReg,0))
        	{
          		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		"Error : Could Not Get Pstn Miss CallReg in \n");
        	}

        	pxTemp = xMissCallReg.pxCallRegEntries;
        	while(pxTemp !=NULL)
        	{
        			pxTemp->uiEntryId -= (IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES);
          		uiEntryId |= (1<<(pxTemp->uiEntryId-1));
          		__ifx_list_GetNext((void *)&pxTemp);
        	}
	 			ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
	 			IFX_VMAPI_SetBitMapEntry_opt("PstnMissCallBitMap",uiEntryId);
      }
			break;
	
			case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
      {
        x_IFX_VMAPI_DialCallRegister xDialCallReg;
        x_IFX_VMAPI_DialCallRegEntry *pxTemp;

          memset(&xDialCallReg,0,sizeof(x_IFX_VMAPI_DialCallRegister));
          xDialCallReg.ucLineId=4;
          xDialCallReg.ucIndex = 0;
          xDialCallReg.iid.config_owner = IFX_VOIP;
          if(IFX_VMAPI_SUCCESS != ifx_get_PstnDialCallReg(&xDialCallReg,0))
          {
              IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                  "Error : Could Not Get Pstn Dial CallReg in \n");
          }

          pxTemp = xDialCallReg.pxCallRegEntries;
          while(pxTemp !=NULL)
          {
       pxTemp->uiEntryId -= ((2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE);
              uiEntryId |= (1<<(pxTemp->uiEntryId-1));
              __ifx_list_GetNext((void *)&pxTemp);
          }
        ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,uiDialEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("PstnDialCallBitMap",uiEntryId);
      }
      break;

		case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
      {
        x_IFX_VMAPI_RecvCallRegister xRecvCallReg;
        x_IFX_VMAPI_RecvCallRegEntry *pxTemp;

          memset(&xRecvCallReg,0,sizeof(x_IFX_VMAPI_RecvCallRegister));
          xRecvCallReg.ucLineId=4;
          xRecvCallReg.ucIndex = 0;
          xRecvCallReg.iid.config_owner = IFX_VOIP;
          if(IFX_VMAPI_SUCCESS != ifx_get_PstnRecvCallReg(&xRecvCallReg,0))
          {
              IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                  "Error : Could Not Get Pstn Recv CallReg in \n");
          }

          pxTemp = xRecvCallReg.pxCallRegEntries;
          while(pxTemp !=NULL)
          {
        pxTemp->uiEntryId -= ((3*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+(2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE));
              uiEntryId |= (1<<(pxTemp->uiEntryId-1));
              __ifx_list_GetNext((void *)&pxTemp);
          }
        ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,uiRecvEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("PstnRecvCallBitMap",uiEntryId);
      }
      break;
  
			case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
      {

  			x_IFX_VMAPI_ContactList xContactList;
        x_IFX_VMAPI_ContactListEntry *pxTemp;

                memset(&xContactList,0,sizeof(x_IFX_VMAPI_ContactList));
                xContactList.ucLineId =4;
                xContactList.iid.config_owner = IFX_WEB;
                if(IFX_VMAPI_SUCCESS != ifx_get_PstnContactList(&xContactList,0))
                {
                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                        "Error : Could Not Get Miss CallReg in \n");
                }

                pxTemp = xContactList.pxContactEntries;
                while(pxTemp !=NULL)
                {
												pxTemp->uiEntryId-=(IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES);
                        uiEntryId |= (1<<(pxTemp->uiEntryId-1));
                        __ifx_list_GetNext((void *)&pxTemp);
                }
         ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
         //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_CONTACT_LIST,uiPstnContactEntryId);
         IFX_VMAPI_SetBitMapEntry_opt("PstnContactListBitMap",uiEntryId);
      }
      break;
			case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
      {

  			x_IFX_VMAPI_ContactList xContactList;
        x_IFX_VMAPI_ContactListEntry *pxTemp;

                memset(&xContactList,0,sizeof(x_IFX_VMAPI_ContactList));
                xContactList.ucLineId =4;
                xContactList.iid.config_owner = IFX_WEB;
                if(IFX_VMAPI_SUCCESS != ifx_get_CommonContactList(&xContactList,0))
                {
                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                        "Error : Could Not Get Miss CallReg in \n");
                }

                pxTemp = xContactList.pxContactEntries;
                while(pxTemp !=NULL)
                {
											pxTemp->uiEntryId-=((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);	
      			            uiEntryId |= (1<<(pxTemp->uiEntryId-1));
                        __ifx_list_GetNext((void *)&pxTemp);
                }
         ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
         //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
         IFX_VMAPI_SetBitMapEntry_opt("CommonContactListBitMap",uiEntryId);
      }
      break;

		
  default:
      return IFX_VMAPI_FAIL;

  }
ifx_vmapi_freeObjectList(&xVoiceServ, IFX_VMAPI_VOICE_SERVICE);
  return IFX_VMAPI_SUCCESS;
}
#endif

/******************************************************************************
*  Function Name  : ifx_get_EntryId
*  Description    : This function is used to get the entry id of a given list
*                   from the global pool.
*  Input Values   : ucList - List Id
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS on success, IFX_VMAPI_FAIL on failure.
*  Notes          :
******************************************************************************/

int32 ifx_get_EntryId(uchar8 ucList, uint32 *puiEntryId)
{
  *puiEntryId =1;
uint32 uiEntryId = 0;
  switch(ucList)
  {
    case IFX_VMAPI_VS_MISSCALL_REGISTER:
      {
	IFX_VMAPI_GetBitMapEntry_opt("MissCallBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
	IFX_VMAPI_SetBitMapEntry_opt("MissCallBitMap",uiEntryId);
      }
      break;
    case IFX_VMAPI_VS_RECVCALL_REGISTER:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_RECVCALL_REGISTER,&uiRecvEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("RecvCallBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
				//Starts from 20 
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += (IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_PSTN_LINE);
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_RECVCALL_REGISTER,uiRecvEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("RecvCallBitMap",uiEntryId);
      }
      break;

    case IFX_VMAPI_VS_DIALCALL_REGISTER:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_DIALCALL_REGISTER,&uiDialEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("DialCallBitMap",&uiEntryId);
	while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += (2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_PSTN_LINE);
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_DIALCALL_REGISTER,uiDialEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("DialCallBitMap",uiEntryId);
      }
      break;
    case IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,&uiAddrEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("AddrBookBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,uiAddrEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("AddrBookBitMap",uiEntryId);
      }
			break;

	case IFX_VMAPI_VS_CONTACT_LIST:
      {
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_CONTACT_LIST,&uiContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("ContactListBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += 15;
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_CONTACT_LIST,uiContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("ContactListBitMap",uiEntryId);
      }
			break;
	
    case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER,&uiPstnMissEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("PstnMissCallBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += (IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES);
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER,uiPstnMissEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("PstnMissCallBitMap",uiEntryId);
      }
      break;
	
	case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
      {
  //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,&uiPstnDialEntryId);
  IFX_VMAPI_GetBitMapEntry_opt("PstnDialCallBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += (2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE;
  //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,uiPstnDialEntryId);
  IFX_VMAPI_SetBitMapEntry_opt("PstnDialCallBitMap",uiEntryId);
      }
      break;


		case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
      {
  			//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,&uiPstnRecvEntryId);
  			IFX_VMAPI_GetBitMapEntry_opt("PstnRecvCallBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += (3*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+(2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE);
  //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,uiPstnRecvEntryId);
  IFX_VMAPI_SetBitMapEntry_opt("PstnRecvCallBitMap",uiEntryId);
      }
      break;

	case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
      {
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_CONTACT_LIST,&uiPstnContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("PstnContactListBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += (IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_CONTACT_LIST,uiPstnContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("PstnContactListBitMap",uiEntryId);
      }
      break;
	
case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
      {
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,&uiCommonContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("CommonContactListBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        *puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("CommonContactListBitMap",uiEntryId);
      }
      break;
#ifdef DECT_SENSORS_SUPPORT
		case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
			{
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,&uiCommonContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("MotionSensorBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("MotionSensorBitMap",uiEntryId);
      }
		break;

		case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
		//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,&uiCommonContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("MotionSensorAlaramBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("MotionSensorAlaramBitMap",uiEntryId);

		break;
		
		case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
			//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,&uiCommonContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("SmokeSensorBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("SmokeSensorBitMap",uiEntryId);
		break;
		
		case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
			 //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,&uiCommonContactEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("SmokeSensorAlaramBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("SmokeSensorAlaramBitMap",uiEntryId);
		break;
		
		case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
			IFX_VMAPI_GetBitMapEntry_opt("PowerSensorBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("PowerSensorBitMap",uiEntryId);
		break;
		
		case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
			IFX_VMAPI_GetBitMapEntry_opt("PowerSensorReadBitMap",&uiEntryId);
        while((uiEntryId & (1<<(*puiEntryId-1))) !=0){
          (*puiEntryId)++;

          if(*puiEntryId == 32){
            *puiEntryId=0;
            return -1;
          }
        }
        uiEntryId |= (1<<(*puiEntryId-1)) ;
        //*puiEntryId += ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uiCommonContactEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("PowerSensorReadBitMap",uiEntryId);
		break;
#endif 
   default:
      return IFX_VMAPI_FAIL;
		}
  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_free_EntryId
*  Description    : This function is used to free the entry id of a given list
*                   from the global pool.
*  Input Values   : ucList - List Id
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS on success, IFX_VMAPI_FAIL on failure.
*  Notes          :
******************************************************************************/

int32 ifx_free_EntryId(uchar8 ucList, uint32 uiEntryId)
{
  uint32 uiTempId=0;
	uint32 uinEntryId=0;
	
  switch(ucList)
  {
    case IFX_VMAPI_VS_MISSCALL_REGISTER:
      {
	IFX_VMAPI_GetBitMapEntry_opt("MissCallBitMap",&uinEntryId);
        if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiEntryId-1));
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_MISSCALL_REGISTER,uinEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("MissCallBitMap",uinEntryId);
      }
      break;
    case IFX_VMAPI_VS_RECVCALL_REGISTER:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_RECVCALL_REGISTER,&uiRecvEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("RecvCallBitMap",&uinEntryId);
        if(uiEntryId !=0) uiTempId = uiEntryId-(IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_PSTN_LINE);
        if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_RECVCALL_REGISTER,uiRecvEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("RecvCallBitMap",uinEntryId);
      }
      break;
    case IFX_VMAPI_VS_DIALCALL_REGISTER:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_DIALCALL_REGISTER,&uiDialEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("DialCallBitMap",&uinEntryId);
        if(uiEntryId !=0) uiTempId = uiEntryId-(IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_PSTN_LINE*2);
        if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_DIALCALL_REGISTER,uiDialEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("DialCallBitMap",uinEntryId);
      }
      break;

    case IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,&uinEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("AddrBookBitMap",&uinEntryId);
        if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiEntryId-1));
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,uiAddrEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("AddrBookBitMap",uinEntryId);
      }
      break;

		case IFX_VMAPI_VS_CONTACT_LIST:
      {
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_CONTACT_LIST,&uinEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("ContactListBitMap",&uinEntryId);
        if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiEntryId-1));
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_CONTACT_LIST,uinEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("ContactListBitMap",uinEntryId);
      }
      break;

    case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
      {
	//IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER,&uinEntryId);
	IFX_VMAPI_GetBitMapEntry_opt("PstnMissCallBitMap",&uinEntryId);
		if(uiEntryId !=0) uiTempId=uiEntryId-(IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES);       
 if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
	//IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER,uinEntryId);
	IFX_VMAPI_SetBitMapEntry_opt("PstnMissCallBitMap",uinEntryId);
      }
			break;

		case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
      {
  //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,&uinEntryId);
  IFX_VMAPI_GetBitMapEntry_opt("PstnDialCallBitMap",&uinEntryId);
        if(uiEntryId !=0) uiTempId = uiEntryId-(2*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE;
       
 if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
  //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,uinEntryId);
  IFX_VMAPI_SetBitMapEntry_opt("PstnDialCallBitMap",uinEntryId);
      }
			break;

case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
      {
  //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,&uinEntryId);
  IFX_VMAPI_GetBitMapEntry_opt("PstnRecvCallBitMap",&uinEntryId);
        if(uiEntryId !=0) uiTempId = uiEntryId-(3*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+(IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE*2);
        if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
  //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,uinEntryId);
  IFX_VMAPI_SetBitMapEntry_opt("PstnRecvCallBitMap",uinEntryId);
      }
		break;

			case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
      {
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_PSTN_CONTACT_LIST,&uinEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("PstnContactListBitMap",&uinEntryId);
if(uiEntryId !=0) uiTempId = uiEntryId- (IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES);        
if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_PSTN_CONTACT_LIST,uinEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("PstnContactListBitMap",uinEntryId);
      }
      break;	
			case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
      {
        //IFX_VMAPI_GetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,&uinEntryId);
        IFX_VMAPI_GetBitMapEntry_opt("CommonContactListBitMap",&uinEntryId);
if(uiEntryId !=0) uiTempId = uiEntryId - ((IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE * IFX_VMAPI_MAX_VOICE_LINES)+IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE);        
if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiTempId-1));
        //IFX_VMAPI_SetBitMapEntry(IFX_VMAPI_VS_COMMON_CONTACT_LIST,uinEntryId);
        IFX_VMAPI_SetBitMapEntry_opt("CommonContactListBitMap",uinEntryId);
      }
      break;	
#ifdef DECT_SENSORS_SUPPORT
		case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
			{
        IFX_VMAPI_GetBitMapEntry_opt("MotionSensorBitMap",&uinEntryId);
				if(uiEntryId == 0) uinEntryId=0;
        uinEntryId &= ~(1<<(uiEntryId-1)) ;
        IFX_VMAPI_SetBitMapEntry_opt("MotionSensorBitMap",uinEntryId);
      }
		break;

		case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
        IFX_VMAPI_GetBitMapEntry_opt("MotionSensorAlaramBitMap",&uinEntryId);
    		if(uiEntryId == 0) uinEntryId=0;
		    uinEntryId &= ~(1<<(uiEntryId-1)) ;
        IFX_VMAPI_SetBitMapEntry_opt("MotionSensorAlaramBitMap",uinEntryId);
		break;
		
		case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
        IFX_VMAPI_GetBitMapEntry_opt("SmokeSensorBitMap",&uinEntryId);
       if(uiEntryId == 0) uinEntryId = 0;
        uinEntryId &= ~(1<<(uiEntryId-1)) ;
        IFX_VMAPI_SetBitMapEntry_opt("SmokeSensorBitMap",uinEntryId);
		break;
		
		case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
        IFX_VMAPI_GetBitMapEntry_opt("SmokeSensorAlaramBitMap",&uinEntryId);
        if(uiEntryId == 0) uinEntryId =0;
        uinEntryId &= ~(1<<(uiEntryId-1)) ;
        IFX_VMAPI_SetBitMapEntry_opt("SmokeSensorAlaramBitMap",uinEntryId);
		break;
		
		case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
			IFX_VMAPI_GetBitMapEntry_opt("PowerSensorBitMap",&uinEntryId);
        if(uiEntryId == 0) uinEntryId =0;
        uinEntryId &= ~(1<<(uiEntryId-1)) ;
        IFX_VMAPI_SetBitMapEntry_opt("PowerSensorBitMap",uinEntryId);
		break;
		
		case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
			IFX_VMAPI_GetBitMapEntry_opt("PowerSensorReadBitMap",&uinEntryId);
       if(uiEntryId == 0) uinEntryId = 0;
        uinEntryId &= ~(1<<(uiEntryId-1)) ;
        IFX_VMAPI_SetBitMapEntry_opt("PowerSensorReadBitMap",uinEntryId);
		break;
#endif
    default:
      return IFX_VMAPI_FAIL;
  }
  return IFX_VMAPI_SUCCESS;
}
 


/******************************************************************************
*  Function Name  : ifx_get_IfEntryMatch
*  Description    : Check If the entry matches with the other entries
*  Input Values   : pvCallRegList -- the entry list
*                   pvCallEntry -- the call entry
*                   unObjCode -- Dial/Miss/Recv
*                   uiEntryIndex -- Entry index
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_IfEntryMatch(IN VOID *pvCallRegList,
                         IN VOID *pvCallEntry,
                         IN uint16 unObjCode
                         )
{
  char8 acStringToMatch[IFX_VMAPI_MAX_USER_NAME_LEN + IFX_VMAPI_MAX_DOMAIN_NAME_LEN] = {0};
  char8 acString[IFX_VMAPI_MAX_USER_NAME_LEN + IFX_VMAPI_MAX_DOMAIN_NAME_LEN] = {0};

  
  if(unObjCode == IFX_VMAPI_VS_MISSCALL_REGISTER)
        {
          	x_IFX_VMAPI_MissCallRegEntry *pxTemp ;
		x_IFX_VMAPI_MissCallRegEntry *pxMissCallEntry;
                x_IFX_VMAPI_MissCallRegister *pxMissCallReg;
                pxMissCallReg = (x_IFX_VMAPI_MissCallRegister *)pvCallRegList;
                pxMissCallEntry = (x_IFX_VMAPI_MissCallRegEntry *)pvCallEntry;

    sprintf(&acStringToMatch[0],"%s@%s",pxMissCallEntry->xAddress.acUserName,
                                                                        pxMissCallEntry->xAddress.acDestAddr);
	pxTemp= pxMissCallReg ->pxCallRegEntries;

	while(pxTemp != NULL)
	{
	
    		sprintf(&acString[0],"%s@%s",pxTemp->xAddress.acUserName,
                                                                        pxTemp->xAddress.acDestAddr);
          	//printf("acString=[%s] acStringToMatch =[%s]\n",acString,acStringToMatch);
    		if((pxMissCallEntry->ucLineId == pxTemp->ucLineId)
      			&&(!(IFX_VMAPI_STRCMP(acString,acStringToMatch))))
                	{
      				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                	   "Matched String Found!!!! \n");
					//Update the entry......   
                			pxTemp->iid.config_owner = IFX_VOIP;
                			pxTemp->ucNoOfCalls+=1;
         				if(IFX_VMAPI_SUCCESS != ifx_set_MissCallRegEntry(IFX_OP_MOD,pxTemp,0))
          				{
                				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         			"Error : Could Not Modify the  Last Miss CallReg Entry \n");
                        			return IFX_VMAPI_FAIL;
          				}
				return IFX_VMAPI_SUCCESS;
                	}
			__ifx_list_GetNext((void *)&pxTemp);
	}
                return IFX_VMAPI_FAIL;
  }


  if(unObjCode == IFX_VMAPI_VS_RECVCALL_REGISTER)
        {
		x_IFX_VMAPI_RecvCallRegEntry *pxTemp ;
                x_IFX_VMAPI_RecvCallRegEntry *pxRecvCallEntry;
                x_IFX_VMAPI_RecvCallRegister *pxRecvCallReg;
                pxRecvCallReg = (x_IFX_VMAPI_RecvCallRegister *)pvCallRegList;
                pxRecvCallEntry = (x_IFX_VMAPI_RecvCallRegEntry *)pvCallEntry;
                                                                        
    sprintf(&acStringToMatch[0],"%s@%s",pxRecvCallEntry->xAddress.acUserName,
                                                                        pxRecvCallEntry->xAddress.acDestAddr);
        pxTemp= pxRecvCallReg ->pxCallRegEntries;

	while(pxTemp != NULL)
	{
	
    		sprintf(&acString[0],"%s@%s",pxTemp->xAddress.acUserName,
                                                                        pxTemp->xAddress.acDestAddr);
    		if((pxRecvCallEntry->ucLineId == pxTemp->ucLineId)
      			&&(!(IFX_VMAPI_STRCMP(acString,acStringToMatch))))
                	{
      				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                	   "Matched String Found!!!! \n");
                  			//Update the entry......   
                                        pxTemp->iid.config_owner = IFX_VOIP;
                                        pxTemp->ucNoOfCalls+=1;
                                        if(IFX_VMAPI_SUCCESS != ifx_set_RecvCallRegEntry(IFX_OP_MOD,pxTemp,0))
                                        {       
                                                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                "Error : Could Not Modify the  Last Recv CallReg Entry \n");
                                                return IFX_VMAPI_FAIL;
                                        }

				return IFX_VMAPI_SUCCESS;
                	}
			__ifx_list_GetNext((void *)&pxTemp);
	}
                return IFX_VMAPI_FAIL;
  }
        if(unObjCode == IFX_VMAPI_VS_DIALCALL_REGISTER)
        {

		x_IFX_VMAPI_DialCallRegEntry *pxTemp ;
                x_IFX_VMAPI_DialCallRegEntry *pxDialCallEntry;
                x_IFX_VMAPI_DialCallRegister *pxDialCallReg;
                pxDialCallReg = (x_IFX_VMAPI_DialCallRegister *)pvCallRegList;
                pxDialCallEntry = (x_IFX_VMAPI_DialCallRegEntry *)pvCallEntry;
                                                                        
    		sprintf(&acStringToMatch[0],"%s@%s",pxDialCallEntry->xAddress.acUserName,
                                                                        pxDialCallEntry->xAddress.acDestAddr);
        pxTemp= pxDialCallReg ->pxCallRegEntries;
	while(pxTemp != NULL)
	{
	
    		sprintf(&acString[0],"%s@%s",pxTemp->xAddress.acUserName,
                                                                        pxTemp->xAddress.acDestAddr);
          	//printf("acString=[%s] acStringToMatch =[%s]\n",acString,acStringToMatch);
    		if((pxDialCallEntry->ucLineId == pxTemp->ucLineId)
      			&&(!(IFX_VMAPI_STRCMP(acString,acStringToMatch))))
                	{
      				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                	   "Matched String Found!!!! \n");
                  			//Update the entry......   
                                        pxTemp->iid.config_owner = IFX_VOIP;
                                        pxTemp->ucNoOfCalls+=1;
                                        if(IFX_VMAPI_SUCCESS != ifx_set_DialCallRegEntry(IFX_OP_MOD,pxTemp,0))
                                        {
                                                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                "Error : Could Not Modify the  Last Dial CallReg Entry \n");
                                                return IFX_VMAPI_FAIL;
                                        }

				return IFX_VMAPI_SUCCESS;
                	}
			__ifx_list_GetNext((void *)&pxTemp);
	}
                return IFX_VMAPI_FAIL;
  }
        return IFX_VMAPI_SUCCESS;
}






/******************************************************************************
*  Function Name  : ifx_get_IfMatchLastEntry
*  Description    : Check If the entry matches with the last entry.
*  Input Values   : pvCallRegList -- the entry list
*                   pvCallEntry -- the call entry
*                   unObjCode -- Dial/Miss/Recv
*                   uiEndIndex -- End index
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 
ifx_get_IfMatchLastEntry(IN VOID *pvCallRegList,
                         IN VOID *pvCallEntry,
							           IN uint16 unObjCode,
                         IN uint32 uiEndIndex)
{
  char8 acStringToMatch[IFX_VMAPI_MAX_USER_NAME_LEN + IFX_VMAPI_MAX_DOMAIN_NAME_LEN] = {0}; 
  char8 acString[IFX_VMAPI_MAX_USER_NAME_LEN + IFX_VMAPI_MAX_DOMAIN_NAME_LEN] = {0}; 

  if(uiEndIndex == 0)
    return IFX_VMAPI_FAIL;
    x_IFX_VMAPI_CallRegEntry *pxTemp2 = (x_IFX_VMAPI_CallRegEntry *)uiEndIndex;
    x_IFX_VMAPI_CallRegEntry *pxCallEntry;
    pxCallEntry = (x_IFX_VMAPI_CallRegEntry *)pvCallEntry;

    sprintf(&acStringToMatch[0],"%s@%s",pxCallEntry->xAddress.acUserName,
                    pxCallEntry->xAddress.acDestAddr);
    sprintf(&acString[0],"%s@%s",pxTemp2->xAddress.acUserName,
                    pxTemp2->xAddress.acDestAddr);
    //printf("acString=[%s] acStringToMatch =[%s]\n",acString,acStringToMatch);
    if((pxCallEntry->ucLineId == pxTemp2->ucLineId)
      &&(!(IFX_VMAPI_STRCMP(acString,acStringToMatch))))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Matched String Found!!!! \n");
      return IFX_VMAPI_SUCCESS;
    }
    return IFX_VMAPI_FAIL;
	
}

/******************************************************************************
*  Function Name  : ifx_get_StartEndIndex
*  Description    : Check If the entry exists.
*  Input Values   : pvCallRegList -- the entry list
*                   pvCallEntry -- the call entry
*                   unObjCode -- Dial/Miss/Recv
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 
ifx_get_StartEndIndex(IN VOID *pvList,
                      IN uint16 unObjCode,
                      uchar8 ucLineId,
                      uint32 *puiIndex,
                      uint32 *puiEndIndex,
                      uchar8 *pucNoOfEntries)
{
  int32 i=0;
  int32 j=1;
  void *pvTempIndex=NULL;
  void *pxTemp=NULL;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

  *puiIndex=0;
  *puiEndIndex=0;
  *pucNoOfEntries =0;

	switch(unObjCode) {

	case IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY:
	{
	  x_IFX_VMAPI_AddressBook *pxAddrBook = (x_IFX_VMAPI_AddressBook *)pvList;
    pxTemp = pxAddrBook->pxAddressBook;
  
		while(pxTemp !=NULL)
    {
      if(ucLineId == ((x_IFX_VMAPI_AddressBookEntry *)pxTemp)->ucLineId)
      {
        if (i == 0)
        {
          *puiIndex = (uint32)pxTemp;
        }
        *puiEndIndex=(uint32)pxTemp;
        i++;
      }
      pvTempIndex = pxTemp;
      __ifx_list_GetNext((void *)&pxTemp);
      j++;
    }
  }
	break;
	case IFX_VMAPI_VS_MISSCALL_REGISTER:
	case IFX_VMAPI_VS_RECVCALL_REGISTER:
	case IFX_VMAPI_VS_DIALCALL_REGISTER:
	case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
	case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
	case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
	{
		x_IFX_VMAPI_MissCallRegister *pxMissCallReg = (x_IFX_VMAPI_MissCallRegister *)pvList;
    pxTemp = pxMissCallReg->pxCallRegEntries;
 
    while(pxTemp !=NULL)
    {
      if(ucLineId == ((x_IFX_VMAPI_MissCallRegEntry *)pxTemp)->ucLineId)
      {
        if (i == 0)
        {
          *puiIndex = (uint32)pxTemp;
        }
        *puiEndIndex=(uint32)pxTemp;
        i++;
      }
      pvTempIndex = pxTemp;
      __ifx_list_GetNext((void *)&pxTemp);
      j++;
    }
  }

    }
  if(*puiIndex == 0){
    *puiIndex = *puiEndIndex=(uint32)pvTempIndex;
  }
   
  *pucNoOfEntries = i;
  return IFX_VMAPI_SUCCESS;
}


/******************************************************************************
*  Function Name  : ifx_get_VoiceSevice
*  Description    : Get api to get VoiceService object.
*  Input Values   :  pxVoiceService - Pointer to VoiceService object
*                    uiInFlag - Input flags
*  Output Values  : pxVoiceService - pointer to VoiceService object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceService (IN_OUT x_IFX_VMAPI_VoiceService  *pxVoiceService,
                   IN uint32 uiInFlag)
{

  int32 index=0,i=0; 
  uchar8 pucProfileIdList[20][20];
  uchar8 pucLineIdList[20][20];
  char8  pucDeviceList[20][20];

  uchar8 ucNoOfProfiles;
  uchar8 ucNoOfLines;
  uchar8 ucDevice =0;

  //uchar8  pProfileIdString[20];
  //char8  pLineIdString[20];
  //char8  pDeviceList[200]={0};

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			     "Entereing Function\n");
	pxVoiceService->iid.cpeId.Id = 1;
	pxVoiceService->iid.pcpeId.Id = 1;

  memset(pucProfileIdList,0,sizeof(pucProfileIdList)); 
  //memset(pProfileIdString,0,sizeof(pProfileIdString)); 

  memset(pucLineIdList,0,sizeof(pucLineIdList)); 
  //memset(pLineIdString,0,sizeof(pLineIdString)); 

  memset(pucDeviceList,0,sizeof(pucDeviceList)); 
  //memset(pDeviceList,0,sizeof(pDeviceList)); 

  if ( IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VOICE_SERVICE,
                                       &pxVoiceService->iid,
                                       pxVoiceService,
                                       uiInFlag) == IFX_VMAPI_SUCCESS )
  {
		/* Parse the ProfileId list */
		//strcpy(pProfileIdString,pxVoiceService->ucProfileIdList);
    ifx_ParseCallBlockList (pxVoiceService->ucProfileIdList,&pucProfileIdList[0][0],
                            &ucNoOfProfiles); 

    memset(pxVoiceService->ucProfileIdList,0,sizeof(pxVoiceService->ucProfileIdList)); 
		for(index=0;index<ucNoOfProfiles;index++)
    { 
			pxVoiceService->ucProfileIdList[index] = atoi((char8*)pucProfileIdList[index]); 
		}
 
		/* Parse the LineId list */
		//strcpy(pLineIdString,pxVoiceService->ucLineIdList);
    ifx_ParseCallBlockList (pxVoiceService->ucLineIdList,&pucLineIdList[0][0],
                            &ucNoOfLines); 

    memset(pxVoiceService->ucLineIdList,0,sizeof(pxVoiceService->ucLineIdList)); 
		for(index=0;index<ucNoOfLines;index++)
    { 
			pxVoiceService->ucLineIdList[index] = atoi((char8*)pucLineIdList[index]); 
		}
 		
		/* Parse the DeviceId list */	
		//strcpy(pDeviceList,pxVoiceService->acDeviceList);
    ifx_ParseCallBlockListDevice (&pxVoiceService->acDeviceList[0][0],&pucDeviceList[0][0],
                             &ucDevice); 

    memset(pxVoiceService->acDeviceList,0,sizeof(pxVoiceService->acDeviceList)); 
		for(i=0;i<ucDevice;i++)
    { 
		  strcpy(pxVoiceService->acDeviceList[i],(pucDeviceList[i]));
		}
  }
	else {
		return IFX_VMAPI_FAIL;
	}
	
  return IFX_VMAPI_SUCCESS;

}

/******************************************************************************
*  Function Name  : ifx_set_VoiceService
*  Description    : Set api to set VoiceService object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxVoiceService - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_VoiceService(IN uint32 uiOperation,
                    IN x_IFX_VMAPI_VoiceService *pxVoiceService,
                    IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxVoiceService);
  CHECK_ACS_SESSION_OWNER_COMBINATION(pxVoiceService->iid.config_owner);
	pxVoiceService->iid.cpeId.Id = 1;
	pxVoiceService->iid.pcpeId.Id = 1;
	if((snprintf(pxVoiceService->iid.pcpeId.secName,
							sizeof(pxVoiceService->iid.pcpeId.secName), "%s", "Service"))>
									sizeof(pxVoiceService->iid.pcpeId.secName))
	{
   	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				 "Info : String is truncated!!!!!.");
	}
return   LTQ_set_VoiceLineObject(uiOperation,
                            pxVoiceService,
                            IFX_VMAPI_MAX_OBJ,
                            IFX_VMAPI_OBJ_VOICE_SERVICE,
                            uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_get_VoiceCaps
*  Description    : Get api to get VoiceCapabilities object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxVoiceCaps - Pointer to VoiceCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceCaps(
                    OUT x_IFX_VMAPI_VoiceCapabilities *pxVoiceCaps,
                    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				           "Entereing Function");
				
  /* Object Id IFX_VMAPI_OBJ_VOICE_CAPABS */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VOICE_CAPABS,
                                       &pxVoiceCaps->iid,
                                       pxVoiceCaps,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_get_VoiceSipCaps
*  Description    : Get api to get VoiceSipCapabilities object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceSipCaps - Pointer to VoiceSipCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceSipCaps(
                    OUT x_IFX_VMAPI_VoiceSipCapabilities *pxVoiceSipCaps,
                    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		           "Entereing Function");

  return IFX_VMAPI_SUCCESS;
  /* Object id IFX_VMAPI_OBJ_SIP_CAPABS */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_SIP_CAPABS,
                                       &pxVoiceSipCaps->iid,
                                       pxVoiceSipCaps,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_VoiceCodecCaps
*  Description    : Get api to get VoiceCodecCapabilities object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceCodecCaps - Pointer to VoiceCodecCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceCodecCaps(
                    OUT x_IFX_VMAPI_VoiceCodecCapabilities *pxVoiceCodecCaps,
                    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
  /* Object Id IFX_VMAPI_OBJ_CODEC_CAPABS */
  pxVoiceCodecCaps->iid.cpeId.Id = 1;
  pxVoiceCodecCaps->iid.pcpeId.Id = 1;
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CODEC_CAPABS,
                                       &pxVoiceCodecCaps->iid,
                                       pxVoiceCodecCaps,
                                       uiInFlag);  
}

/******************************************************************************
*  Function Name  : ifx_set_VoiceCodecCaps
*  Description    : Set api to set Voice Codec Capabilities object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxVoiceCodecCaps - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_VoiceCodecCaps(IN uint32 uiOperation,
                         		IN x_IFX_VMAPI_VoiceCodecCapabilities *pxVoiceCodecCaps,
                         		IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		           "Entereing Function");

	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxVoiceCodecCaps);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxVoiceCodecCaps->iid.config_owner);
	sprintf(pxVoiceCodecCaps->iid.pcpeId.secName, "%s", "VoiceService");
	pxVoiceCodecCaps->iid.cpeId.Id = 1;
	pxVoiceCodecCaps->iid.pcpeId.Id = 1;
	return	 LTQ_set_VoiceLineObject(uiOperation,
																	pxVoiceCodecCaps,
																	IFX_VMAPI_MAX_OBJ,
																	IFX_VMAPI_OBJ_CODEC_CAPABS,
																	uiInFlag);
}
#if 1
/******************************************************************************
*  Function Name  : ifx_get_VoiceCodecCapsEntry
*  Description    : Get api to get VoiceCodecCapabilities object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceCodecCaps - Pointer to VoiceCodecCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceCodecCapsEntry(
                    OUT x_IFX_VMAPI_CodecDesc *pxVCCapsEntry,
                    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
				
  /* Object Id IFX_VMAPI_OBJ_CODEC_CAPABS_ENTRY */
  pxVCCapsEntry->iid.pcpeId.Id = 1;
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CODEC_CAPABS_ENTRY,
                                       &pxVCCapsEntry->iid,
                                       pxVCCapsEntry,
                                       uiInFlag);  
}
#endif


#if 1
/******************************************************************************
*  Function Name  : ifx_set_VoiceCodecCapsEntry
*  Description    : Set api to get Codec Capabilities Entry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxVCCapsEntry - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_VoiceCodecCapsEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CodecDesc *pxVCCapsEntry,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxVCCapsEntry);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxVCCapsEntry->iid.config_owner);
	sprintf(pxVCCapsEntry->iid.pcpeId.secName, "%s", IFX_VMAPI_OBJ_NAME_VOICE_CAPABS);
	pxVCCapsEntry->iid.pcpeId.Id = 1;
	return   LTQ_set_VoiceLineObject(uiOperation,
																	pxVCCapsEntry,
																	IFX_VMAPI_MAX_OBJ,
																	IFX_VMAPI_OBJ_CODEC_CAPABS_ENTRY,
																	uiInFlag);
}
#endif

#if 0
/******************************************************************************
*  Function Name  : ifx_set_VoicePhyInterface
*  Description    : Set api to set VoiceServPhyIf object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxVoiceServPhyIf - Pointer to the VoiceServPhyIf 
*										object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_VoicePhyInterface(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_VoiceServPhyIf *pxVoiceIf,
                            IN uint32 uiInFlag)
{
  x_IFX_VMAPI_NameValueList xNVList;
  uint32 uiNvIdx = 0;
  uchar8 buf[5000];
  int32 ret;
  uint32 uiChangedCount;
  char8  sbuf[MAX_FILELINE_LEN];
  IFX_NAME_VALUE_PAIR *pxChangedNVList = NULL;

  /* Do simple validation of pointer such as NULL */
  IFX_VALIDATE_PTR(pxVoiceIf);

	/***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	   "Operation is IFX_OP_DEL - Not Supported\n");
		return IFX_VMAPI_FAIL;
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Operation is IFX_OP_MODIFY\n");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	   "Operation is IFX_OP_ADD -- Not supported\n");
		return IFX_VMAPI_FAIL;
	}
  else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  	 "Error : Operation Is Not Supported\n");
		return IFX_VMAPI_FAIL;
  }

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxVoiceIf->iid.config_owner);
  /*********** Prolog Block ***********/
  if (uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
  }
  else {
    return IFX_VMAPI_FAIL;
  }
  /**************** Validation Block *****************/
  /* For Operations other than DELETE do the verification of input params */
  if(IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    /* Do simple validation of flags such as less than 0 */
    IFX_VALIDATE_FLAGS(uiInFlag);
  }
  /***********************************/
  sprintf(pxVoiceIf->iid.cpeId.secName, "%s",
                        IFX_VMAPI_OBJ_NAME_PHY_IFACE);
  /* Fill in the CPEID for MODIFY Operation */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag)) {
  }
  
  /**************** Name Value Formation as per RC.CONF ********************/
  xNVList.unNoOfNVPairs = 0;
	IFX_VMAPI_SPRINTF((char8*)buf, "%s_", IFX_VMAPI_OBJ_PREF_PHY_IFACE);

  IFX_VMAPI_LOCK(uiLock); 

  if (IFX_VMAPI_GetNameValueListFromObj(IFX_VMAPI_OBJ_PHY_IFACE, 
          (void *)pxVoiceIf, 
					NULL, &xNVList, &uiNvIdx, buf) != IFX_VMAPI_SUCCESS) {
			goto EndLabel;
}
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				 "Name Value List******\n");
  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
  /******** ACL Checking block - MUST for MODIFY/DELETE operations **********/
  if(IFX_ADD_F_NOT_SET(uiInFlag)) {
    if ((ret = IFX_VMAPI_CheckACLRet(&pxVoiceIf->iid, 
                xNVList.unNoOfNVPairs, xNVList.axNameValue,
                &uiChangedCount, &pxChangedNVList, 
                uiInFlag)) != IFX_SUCCESS) {
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
					"** IFX_VMAPI_CheckACLRet returns failure\n");
      goto err_hdlr;
    }  
  }
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					 "Modified Name Value List******\n");
  IFX_VMAPI_PRINT_NAMEVAL(pxChangedNVList, uiChangedCount);
  if (IFX_MODIFY_F_SET(uiInFlag)) {
    if ((ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, uiChangedCount, pxChangedNVList) 
                                            != IFX_SUCCESS)) {
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "** IFX_VMAPI_FORM_CFG_BUF returns failure\n");
      goto err_hdlr;
    }
  }
  else {
    if ((ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, 
									xNVList.axNameValue)) != IFX_SUCCESS) {
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "** IFX_VMAPI_FORM_CFG_BUF returns failure\n");
      goto err_hdlr;
    }
  }
  
	/************** System Config File Update Block ****************/
  snprintf(sbuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(sbuf);

  /* Backup rc.conf before proceeding with configuration */
  ret = IFX_VMAPI_CheckPointRet(uiInFlag, SYSTEM_CONF_FILE, CHKPOINT_FILE);
  if (ret != IFX_SUCCESS) {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "** IFX_VMAPI_CheckPointRet returns failure\n");
    goto err_hdlr;
  }
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Calling ifx_SetObjData\n");
  ret = ifx_SetObjData(SYSTEM_CONF_FILE, IFX_VMAPI_OBJ_NAME_PHY_IFACE,
												uiInFlag, 1, (char8*)buf);
  /* Convert the name-value pairs into buffer expected by set */
  if (ret != IFX_SUCCESS) {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "** ifx_SetObjData returns failure\n");
    /* Restore the conf file with backup conf file */
    ret = IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag);
		if (ret != IFX_VMAPI_SUCCESS) {
	  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "** IFX_VMAPI_RollbackCfg returns failure\n");
		}
    goto err_hdlr;
  }

err_hdlr:
  IFX_VMAPI_FREE(pxChangedNVList);
  IFX_VMAPI_UNLOCK(uiLock); 
  return ret;
}
#endif


/******************************************************************************
*  Function Name  : ifx_get_SystemT38
*  Description    : Get api to get Voice System T38 object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxSystemT38 - pointer to T38 object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_SystemT38(OUT x_IFX_VMAPI_T38Cfg *pxSystemT38,
                           IN uint32 uiInFlag)
{
	pxSystemT38->iid.cpeId.Id = 1;
	pxSystemT38->iid.pcpeId.Id = 1;
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_T38 */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_T38,
                                       &pxSystemT38->iid,
                                       pxSystemT38,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_SystemT38
*  Description    : Set api to set Voice System T38 object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxSystemT38 - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_SystemT38 (IN uint32 uiOperation,
                         IN x_IFX_VMAPI_T38Cfg *pxSystemT38,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
			/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxSystemT38);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxSystemT38->iid.config_owner);
	sprintf(pxSystemT38->iid.pcpeId.secName, "%s", "T38");
	return LTQ_set_VoipSystemObject(uiOperation,
																	pxSystemT38,
																	IFX_VMAPI_MAX_OBJ,
																	IFX_VMAPI_OBJ_T38,
																	uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_VoiceProfile
*  Description    : Get api to get VoiceProfile object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceProfile - pointer to VoiceProfile object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceProfile(OUT x_IFX_VMAPI_VoiceProfile *pxVoiceProfile,
                           IN uint32 uiInFlag)
{
  int32 index=0; 
  uchar8 pucAssocLineId[20][20]={{0}};
  uchar8 ucNoOfAssoLines;
  //char8  pAssocLineIdString[20] = {'\0'};
  uint32 iCpeId;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			     "Entereing Function\n");
	 
	if(pxVoiceProfile->iid.config_owner != IFX_TR69) {
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,pxVoiceProfile,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",pxVoiceProfile->ucProfileId,&iCpeId);
    pxVoiceProfile->iid.cpeId.Id = iCpeId;
    pxVoiceProfile->iid.pcpeId.Id = 1; /*Child of Voice Service (CpeId = 1)*/
	}

  if( IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VOICE_PROFILE,
                                       &pxVoiceProfile->iid,
                                       pxVoiceProfile,
                                       uiInFlag) == IFX_VMAPI_SUCCESS)
  {
		//strcpy(pAssocLineIdString,pxVoiceProfile->aucAssoLineIds);
    ifx_ParseCallBlockList (pxVoiceProfile->aucAssoLineIds,&pucAssocLineId[0][0],
                            &ucNoOfAssoLines); 

    memset(pxVoiceProfile->aucAssoLineIds,0,sizeof(pxVoiceProfile->aucAssoLineIds));
    for(index=0;index<ucNoOfAssoLines;index++)
    { 
      pxVoiceProfile->aucAssoLineIds[index] = atoi((char8 *)pucAssocLineId[index]);
    }
    return IFX_VMAPI_SUCCESS;
      
  };
  return IFX_VMAPI_FAIL;

}

/******************************************************************************
*  Function Name  : ifx_set_VoiceProfile
*  Description    : Set api to set VoiceProfile object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxVoiceProfile - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_VoiceProfile (IN uint32 uiOperation,
                            IN x_IFX_VMAPI_VoiceProfile *pxVoiceProfile,
                            IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxVoiceProfile);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxVoiceProfile->iid.config_owner);
	sprintf(pxVoiceProfile -> iid.pcpeId.secName, "%s", "VoiceService");
	return LTQ_set_VoipProfileObject(uiOperation,
																		pxVoiceProfile,
																		IFX_VMAPI_VOICE_PROFILE,
																		IFX_VMAPI_OBJ_VOICE_PROFILE,
																		uiInFlag);  
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileSignaling
*  Description    : Get api to get ProfileSignaling object.
*  Input Values   :
*                   uiInFlag - Input flags
*  Output Values  : pxProfileSignaling - pointer to ProfileSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ProfileSignaling(
                  OUT x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling,
                  IN uint32 uiInFlag)
{ 

  uint32 iCpeId,iCpeIdProf;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
									           "Entereing Function");

	if(pxProfileSignaling->iid.config_owner != IFX_TR69) {
					
    /* Assign the ProfileId of the ProfileSignaling object to VoiceProfile object */
    xVoiceProf.ucProfileId = pxProfileSignaling->ucProfileId;
    /* Get the CpeId of the Parent Object VoiceProfile */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,&xVoiceProf,&iCpeIdProf);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",xVoiceProf.ucProfileId,&iCpeIdProf);

	  sprintf(pxProfileSignaling->iid.pcpeId.secName, "%s", "VoiceProfile");
	  pxProfileSignaling->iid.pcpeId.Id = iCpeIdProf;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_SIGNALING,pxProfileSignaling,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfileSignaling_CpeId",pxProfileSignaling->ucProfileId,&iCpeId);
    pxProfileSignaling->iid.cpeId.Id = iCpeId;
	}

  /* Object Id IFX_VMAPI_OBJ_VP_SIGNALING */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VP_SIGNALING,
                                       &pxProfileSignaling->iid,
                                       pxProfileSignaling,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_ProfileSignaling
*  Description    : Set api to set ProfileSignaling object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxProfileSignaling - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_ProfileSignaling(IN uint32 uiOperation,
                    IN x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling,
                    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxProfileSignaling);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxProfileSignaling->iid.config_owner);
	sprintf(pxProfileSignaling -> iid.pcpeId.secName, "%s", "VoiceProfile");
	return LTQ_set_VoipProfileObject(uiOperation,
																	pxProfileSignaling,
																	IFX_VMAPI_VP_SIGNALING,
																	IFX_VMAPI_OBJ_VP_SIGNALING,
																	uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_ProfileServiceProviderInfo
*  Description    : Get api to get ProfileServiceProviderInfo object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxServProviderInfo - pointer to ProfileServiceProviderInfo 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ProfileServiceProviderInfo(
              OUT x_IFX_VMAPI_ProfileServiceProviderInfo *pxServProviderInfo,
              IN uint32 uiInFlag)
{

  uint32 iCpeId,iCpeIdProf;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		           "Entereing Function");
	
	if(pxServProviderInfo->iid.config_owner != IFX_TR69) { 
    /* Assign the ProfileId of the ServiceProvider object to VoiceProfile object */
    xVoiceProf.ucProfileId = pxServProviderInfo->ucProfileId;
    /* Get the CpeId of the Parent Object VoiceProfile */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,&xVoiceProf,&iCpeIdProf);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",xVoiceProf.ucProfileId,&iCpeIdProf);

	  sprintf(pxServProviderInfo->iid.pcpeId.secName, "%s", "VoiceProfile");
	  pxServProviderInfo->iid.pcpeId.Id = iCpeIdProf;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_SER_PROVIDER,pxServProviderInfo,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("ServiceProvider_CpeId",pxServProviderInfo->ucProfileId,&iCpeId);
    pxServProviderInfo->iid.cpeId.Id = iCpeId;
	}

  /* Object Id IFX_VMAPI_OBJ_SER_PROVIDER */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_SER_PROVIDER,
                                       &pxServProviderInfo->iid,
                                       pxServProviderInfo,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_all_ProfileServiceProviderInfo
*  Description    : Get api to get all ProfileServiceProviderInfo objects.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : puiNumEntries - Number of objects received.
*                   ppxServiceProviderInfo - pointer to ProfileServiceProviderInfo
*                   objects. Number of objects is given by puiNumEntries.
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
#if 0
int32 ifx_get_all_ProfileServiceProviderInfo(
              OUT uint32 *puiNumEntries, 
              OUT x_IFX_VMAPI_ProfileServiceProviderInfo **ppxServProviderInfo,
              IN uint32 uiInFlag)
{
  uchar8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN]="0";
  x_IFX_VMAPI_NameValueList *pxNVList;
  uint32 uiNameValIdx=0;
  uint32 uiInstanceId = 0;
  uint32 outFlag = 0;
  char8 acInBuf[MAX_FILELINE_LEN];
  char8 acCommand[MAX_FILELINE_LEN];
  int32 iRet;
  uint32 uiObjectId = IFX_VMAPI_OBJ_SER_PROVIDER;
  int32 uiErrCode;
  int i;
  x_IFX_VMAPI_ProfileServiceProviderInfo *ppxServProvInfo;

  *puiNumEntries = 0;
   /* lock */
  IFX_VMAPI_LOCK(uiLock);

  /* Get the count of total number of service provider info objects */
  /*MAKE_SECTION_COUNT_TAG(IFX_VMAPI_GET_OBJ_NAME(uiObjectId), acCommand);*/
  IFX_VMAPI_SPRINTF((char8*)acCommand, "%s_Count",IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  
  if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
    acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,(char8*)__FUNCTION__,
				 "Error : Could Not Get Count Of Objects (ln:%d)\n",__LINE__);
    IFX_VMAPI_UNLOCK(uiLock); 
    return iRet;   
  }
  
  *puiNumEntries = atoi(acInBuf); 

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,(char8*)__FUNCTION__,
	 "DEBUG :: Total Number of ServiceProviderInfo Objects :%d\n",*puiNumEntries );
   
  /* Alocate count of x_IFX_VMAPI_ProfileServiceProviderInfo  */
  pxNVList = (x_IFX_VMAPI_NameValueList*)
              IFX_VMAPI_MALLOC(sizeof(x_IFX_VMAPI_NameValueList));
  if (pxNVList == NULL) {
    IFX_VMAPI_UNLOCK(uiLock);
    return IFX_VMAPI_FAIL;
  }

#ifdef LIST
  for(i=0;i<(*puiNumEntries);i++)
  {
  printf("Entered LIST\n");
    __ifx_list_add_to_tail(
                (void **)ppxServProviderInfo,
                (void **)&ppxServProvInfo,
                sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo),
                &uiErrCode);
  }
#else

  *ppxServProviderInfo = (x_IFX_VMAPI_ProfileServiceProviderInfo *)
                          IFX_VMAPI_MALLOC((*puiNumEntries)* 
                          sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo));
#endif
  
  if (ppxServProviderInfo == NULL) {
    IFX_VMAPI_FREE(pxNVList);
    IFX_VMAPI_UNLOCK(uiLock);
    return IFX_VMAPI_FAIL;
  }

  iRet = IFX_VMAPI_SUCCESS;

  while (uiInstanceId < *puiNumEntries) {
  
    IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_%d_",
        IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),
        uiInstanceId + 1);
    pxNVList->unNoOfNVPairs = 0;

    if ((iRet = IFX_VMAPI_GetNVPairsForObject(
                (VOID*)(*ppxServProviderInfo+uiInstanceId),
                pxNVList, uiObjectId, acPrefix, 
                uiInFlag  )) == IFX_VMAPI_SUCCESS ) {
      
      uiNameValIdx = 0;
      iRet = IFX_VMAPI_GetObjFromNameValueList(uiObjectId, 
                (VOID*)(*ppxServProviderInfo+uiInstanceId), pxNVList, 
                &uiNameValIdx, acPrefix );
      
    }else {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,(char8*)__FUNCTION__,
				 "Error : Failed To Get %s object. ifx_GetCfgObject returned failure (ln:%d)\n",
          acPrefix,__LINE__);
      iRet = IFX_VMAPI_FAIL;
      break;
    }
    (*ppxServProviderInfo+uiInstanceId)->ucProfileId = ++uiInstanceId;
  }
  
  /* unlock */
  IFX_VMAPI_UNLOCK(uiLock);

  /* If objects are not obtained, free allocated memory */
  if (iRet != IFX_VMAPI_SUCCESS ) {
    IFX_VMAPI_FREE(*ppxServProviderInfo);
    *ppxServProviderInfo = 0;
    *puiNumEntries = 0;
  }
  
  IFX_VMAPI_FREE(pxNVList);
  return iRet;
}
#endif
/*****************************************************************************
*  Function Name  : ifx_set_ProfileServiceProviderInfo
*  Description    : Set api to set ProfileServiceProviderInfo object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxServProviderInfo - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ProfileServiceProviderInfo(IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileServiceProviderInfo *pxServProviderInfo, 
              IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
						"Entering Function \n");

	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxServProviderInfo);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxServProviderInfo->iid.config_owner);

	sprintf(pxServProviderInfo->iid.pcpeId.secName, "%s", "VoiceProfile");
	return LTQ_set_VoipProfileObject(uiOperation,
													pxServProviderInfo,
													IFX_VMAPI_VP_SER_PROVIDER,
													IFX_VMAPI_OBJ_SER_PROVIDER,
													uiInFlag);
	
}

#ifdef IIP
/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaSecurity
*  Description    : Get api to get ProfileMediaSecurity object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileMediaSecurity - Pointer to ProfileMediaSecurity
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ProfileMediaSecurity(
                  OUT x_IFX_VMAPI_ProfileMediaSecurity *pxProfileMediaSecurity,
                  IN uint32 uiInFlag )
{
  /* Object id IFX_VMAPI_OBJ_VP_MEDIA_SEC */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VP_MEDIA_SEC,
                                      &pxProfileMediaSecurity->iid,
                                      pxProfileMediaSecurity,
                                      uiInFlag);
 
}

/******************************************************************************
*  Function Name  : ifx_set_ProfileMediaSecurity
*  Description    : Set api to set ProfileMediaSecurity object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxProfileMediaSecurity - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ProfileMediaSecurity(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileMediaSecurity *pxProfileMediaSecurity, 
              IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,(char8*)__FUNCTION__,
	"Entering Function :: %s\n",(char8*)__FUNCTION__);

	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxProfileMediaSecurity);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxProfileMediaSecurity->iid.config_owner);

	return LTQ_set_VoipProfileObject(uiOperation,
																		pxProfileMediaSecurity,
																		IFX_VMAPI_MAX_OBJ,
																		IFX_VMAPI_OBJ_VP_MEDIA_SEC,
																		uiInFlag);
}
#endif /* ifdef IIP */


/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaRTP
*  Description    : Get api to get ProfileMediaRTP object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileMediaRTP - Pointert to ProfileMediaRTP object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ProfileMediaRTP ( 
                    OUT x_IFX_VMAPI_ProfileMediaRTP *pxProfileMediaRTP ,
                    IN uint32 uiInFlag)
{
  uint32 iCpeId, iCpeIdProf;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						           "Entereing Function");
	
	if(pxProfileMediaRTP->iid.config_owner != IFX_TR69) {
					
    /* Assign the ProfileId of the ProfileMediaRTP object to VoiceProfile object */
    xVoiceProf.ucProfileId = pxProfileMediaRTP->ucProfileId;
    /* Get the CpeId of the Parent Object VoiceProfile */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,&xVoiceProf,&iCpeIdProf);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",xVoiceProf.ucProfileId,&iCpeIdProf);
	  sprintf(pxProfileMediaRTP->iid.pcpeId.secName, "%s", "VoiceProfile");
	  pxProfileMediaRTP->iid.pcpeId.Id = iCpeIdProf;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_RTP,pxProfileMediaRTP,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("MediaRTPAttributes_CpeId",pxProfileMediaRTP->ucProfileId,&iCpeId);
    pxProfileMediaRTP->iid.cpeId.Id = iCpeId;
    //printf("Receiced CpeId: %d for Profile %d\n",iCpeId,pxProfileMediaRTP->ucProfileId);
	}

  /* Object Id IFX_VMAPI_OBJ_RTP */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_RTP,
                                       &pxProfileMediaRTP->iid,
                                       pxProfileMediaRTP,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_ProfileMediaRTP
*  Description    : Set api to set ProfileMediaRTP object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxProfileMediaRTP - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ProfileMediaRTP(IN uint32 uiOperation,
								              IN x_IFX_VMAPI_ProfileMediaRTP *pxProfileMediaRTP , 
								              IN uint32 uiInFlag)

{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxProfileMediaRTP);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxProfileMediaRTP->iid.config_owner);
	sprintf(pxProfileMediaRTP->iid.pcpeId.secName, "%s", "VoiceProfile");
	return LTQ_set_VoipProfileObject(uiOperation,
																	pxProfileMediaRTP ,
																	IFX_VMAPI_VP_RTP,
																	IFX_VMAPI_OBJ_RTP,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaRTCP
*  Description    : Get api to get ProfileMediaRTCP object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileMediaRTP - Pointert to ProfileMediaRTCP object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ProfileMediaRTCP ( 
                    OUT x_IFX_VMAPI_ProfileMediaRTCP *pxProfileMediaRTCP ,
                    IN uint32 uiInFlag)
{
  uint32 iCpeId, iCpeIdProf;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxProfileMediaRTCP->iid.config_owner != IFX_TR69) {
					
    /* Assign the ProfileId of the RTCP object to VoiceProfile object */
    xVoiceProf.ucProfileId = pxProfileMediaRTCP->ucProfileId;
    /* Get the CpeId of the Parent Object LineSignaling */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,&xVoiceProf,&iCpeIdProf);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",xVoiceProf.ucProfileId,&iCpeIdProf);
	  sprintf(pxProfileMediaRTCP->iid.pcpeId.secName, "%s", "VoiceProfile");
	  pxProfileMediaRTCP->iid.pcpeId.Id = iCpeIdProf;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_RTCP,pxProfileMediaRTCP,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("MediaRTCPAttributes_CpeId",pxProfileMediaRTCP->ucProfileId,&iCpeId);
    pxProfileMediaRTCP->iid.cpeId.Id = iCpeId;
    //printf("Receiced CpeId: %d for Profile %d\n",iCpeId,pxProfileMediaRTCP->ucProfileId);
	}

  /* Object Id IFX_VMAPI_OBJ_RTP */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_RTCP,
                                       &pxProfileMediaRTCP->iid,
                                       pxProfileMediaRTCP,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_ProfileMediaRTCP
*  Description    : Set api to set ProfileMediaRTCP object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxProfileMediaRTCP - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ProfileMediaRTCP(IN uint32 uiOperation,
									              IN x_IFX_VMAPI_ProfileMediaRTCP *pxProfileMediaRTCP, 
									              IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxProfileMediaRTCP);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxProfileMediaRTCP->iid.config_owner);
	sprintf(pxProfileMediaRTCP->iid.pcpeId.secName, "%s", "MediaRTPAttributes");
	return LTQ_set_VoipProfileObject(uiOperation,
																	pxProfileMediaRTCP ,
																	IFX_VMAPI_VP_RTCP,
																	IFX_VMAPI_OBJ_RTCP,
																	uiInFlag);
}

/**********************************************************/
int
ifx_ParseCallBlockList (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength) 
{
  int32 index = 0, i = 0, j = 0;
  while (ucSrc[index] != '\0')
    
  {
    if (ucSrc[index] != ',')
      
    {
      *(ucDestList + (i * 20) + j) = ucSrc[index];
      j++;
    }
    
    else
      
    {
      *(ucDestList + (i * 20) + j) = '\0';
      i++;
      j = 0;
    }
    index++;
  }
  *iLength = i + 1;
  return 0;
}

int
ifx_ParseCallBlockListDevice (char8 * ucSrc, char8 * ucDestList,
                              uchar8 * iLength) 
{
	int32 index = 0, i = 0, j = 0;
  while (ucSrc[index] != '\0')
    
  {
    if (ucSrc[index] != ',')
      
    {
      *(ucDestList + (i * 20) + j) = ucSrc[index];
      j++;
    }
    
    else
      
    {
      *(ucDestList + (i * 20) + j) = '\0';
      i++;
      j = 0;
    }
    index++;
  }
  *iLength = i + 1;
  return 0;
}


/*********************************************************************/


/******************************************************************************
*  Function Name  : ifx_get_VoiceLine
*  Description    : Get api to get VoiceLine object.
*  Input Values   :  pxVoiceLine - Pointer to VoiceLine object
*                    uiInFlag - Input flags
*  Output Values  : pxVoiceLine - pointer to ProfileSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoiceLine (IN_OUT x_IFX_VMAPI_VoiceLine  *pxVoiceLine,
                   IN uint32 uiInFlag)
{
  IFX_ID iid;
  int32 index=0; 
  uchar8 pucPhyendptsList[20][20];
  uchar8 ucNoOfPhyendpts;
  uint32 iCpeId;
  uchar8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN + IFX_VMAPI_MAX_INT_LEN +6];
  int32 iRet = IFX_VMAPI_FAIL;
  int32 iInstanceIndex = -1;
  int32 ret = IFX_VMAPI_FAIL; /* return value */
  uint32 outF = 0;
  uint32 uiInF = 0;
  char8 acOutVal[IFX_MAX_BUFF_LEN] = {0};
	uchar8 ucLine;
	uchar8 ucProf;
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Entering Function\n");

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
	if(pxVoiceLine->iid.config_owner != IFX_TR69) {/* WEB Users*/
    /* Get the CPE Id of the corresponding LineId and assign it */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,pxVoiceLine,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxVoiceLine->ucLineId,&iCpeId);
    pxVoiceLine->iid.cpeId.Id = iCpeId;
	  sprintf(pxVoiceLine->iid.pcpeId.secName, "%s", "VoiceProfile");
    memset(&iid,0,sizeof(iid));    
    IFX_VMAPI_STRCPY(pxVoiceLine->iid.cpeId.secName,
										IFX_VMAPI_GET_OBJ_NAME(IFX_VMAPI_OBJ_VOICE_LINE));
    iid = pxVoiceLine->iid;

    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE, 
									&iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
         IFX_VMAPI_UNLOCK(uiLock);
         return ret;  
    }

    /* lock */
    IFX_VMAPI_LOCK(uiLock);
	 
    IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_%d_%s",
                      (char8*)IFX_VMAPI_GET_OBJ_PREFIX(IFX_VMAPI_OBJ_VOICE_LINE),
                      iInstanceIndex,"pcpeId");
  
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_PREFIX,acPrefix);

    if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, 
															IFX_VMAPI_GET_OBJ_NAME(IFX_VMAPI_OBJ_VOICE_LINE),
															(char8*)acPrefix, uiInF, &outF, acOutVal)) != IFX_SUCCESS)  {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			       	 "Error : Could Not Get Object VoiceLine\n");
          IFX_VMAPI_UNLOCK(uiLock); 
        return iRet;   
    }

	  pxVoiceLine->iid.pcpeId.Id = atoi(acOutVal);
	} /* IFX_WEB */
	else  { /*IFX_TR69*/
    IFX_VMAPI_GetLineIdFromCpeId(pxVoiceLine->iid.cpeId.Id, &ucLine);
	  pxVoiceLine->ucLineId = ucLine;
	}

	//memset(&pPhyendptsString[0] ,0,sizeof(pPhyendptsString));
	memset(&pucPhyendptsList[0][0] ,0,sizeof(pucPhyendptsList));
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VOICE_LINE,
                                       &pxVoiceLine->iid,
                                       pxVoiceLine,
                                       uiInFlag) == IFX_VMAPI_SUCCESS)
  {
		IFX_VMAPI_GetProfileIdFromCpeId(pxVoiceLine->iid.pcpeId.Id, &ucProf);
		pxVoiceLine->ucProfileId = ucProf;
		//strcpy(pPhyendptsString,pxVoiceLine->ucAssocVoiceInterface);
    ifx_ParseCallBlockList (pxVoiceLine->ucAssocVoiceInterface,&pucPhyendptsList[0][0],
                            &ucNoOfPhyendpts); 

    memset(pxVoiceLine->ucAssocVoiceInterface,0,sizeof(pxVoiceLine->ucAssocVoiceInterface));
		for(index=0;index<ucNoOfPhyendpts;index++)
    { 
//Ifndef DECT_SUPPORT
#if !defined(DECT_SUPPORT) && !defined(CVOIP_SUPPORT)
			if (index > 1)
				break;
#endif
			pxVoiceLine->ucAssocVoiceInterface[index] = atoi((char8 *)pucPhyendptsList[index]); 
		}
    return IFX_VMAPI_SUCCESS;
  }
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_VoiceLine
*  Description    : Set api to set VoiceLine object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxVoiceLine - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_VoiceLine (IN uint32 uiOperation,
                 			  IN  x_IFX_VMAPI_VoiceLine  *pxVoiceLine,
                    		IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxVoiceLine);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxVoiceLine->iid.config_owner);
	sprintf(pxVoiceLine->iid.pcpeId.secName, "%s", "VoiceProfile");
	return LTQ_set_VoiceLineObject(uiOperation,
																pxVoiceLine,
																IFX_VMAPI_VOICE_LINE,
																IFX_VMAPI_OBJ_VOICE_LINE,
																uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_NumPlanRule
*  Description    : Get api to get NumPlanRule object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxNumRule - pointer to NumPlanRule 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_NumPlanRule(
              IN_OUT x_IFX_VMAPI_NumPlanRule *pxNumRule,
              IN uint32 uiFlags)
{

  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	 		 	"Entering Function \n");
	if(pxNumRule->iid.config_owner != IFX_TR69) {
  	/* Get the CPE Id of the corresponding NumberingPlanRule and assign it */
  	//IFX_VMAPI_Get_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES,pxNumRule,&iCpeId);
  	IFX_VMAPI_Get_CpeId_opt("NumPlanRules_CpeId",pxNumRule->ucIndex,&iCpeId);
  	pxNumRule->iid.cpeId.Id = iCpeId;
  	pxNumRule->iid.pcpeId.Id = 1;
	}

  /* Object Id IFX_VMAPI_OBJ_NUMPLAN_RULE */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_NUMPLAN_RULE,
                                       &pxNumRule->iid,
                                       pxNumRule,
                                       uiFlags);
}

/******************************************************************************
*  Function Name  : ifx_set_NumPlanRule
*  Description    : Set api to get NumPlanRule object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxNumRule - Pointer to the object to be set
*  Output Values  : pxNumRule - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_NumPlanRule(IN uint32  uiOperation,
                   			  IN  x_IFX_VMAPI_NumPlanRule *pxNumRule,
		                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxNumRule);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxNumRule->iid.config_owner);
	sprintf(pxNumRule->iid.pcpeId.secName, "%s", "NumPlan");
	return LTQ_set_VoipSystemObject(uiOperation,
																	pxNumRule,
																	IFX_VMAPI_VS_NUM_PLAN_RULES,
																	IFX_VMAPI_OBJ_NUMPLAN_RULE,
																	uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_NumPlan
*  Description    : Get api to get Numbering Plan object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxNumPlan - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_NumPlan (IN_OUT  x_IFX_VMAPI_NumPlan  *pxNumPlan,
                       IN   uint32  uiInFlag)
{ 
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	pxNumPlan->iid.cpeId.Id = 1;
	pxNumPlan->iid.pcpeId.Id = 1;
  pxNumPlan->pxNumPlanRules = NULL;
  /* Object idIFX_VMAPI_OBJ_NUMPLAN   */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_NUMPLAN,
                                       &pxNumPlan->iid,
                                       pxNumPlan,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_NumPlan
*  Description    : Set api to get Numbering Plan object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxNumPlan - Pointer to the object to be set
*  Output Values  : pxNumPlan - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_NumPlan(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_NumPlan *pxNumPlan,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxNumPlan);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxNumPlan->iid.config_owner);
	sprintf(pxNumPlan->iid.pcpeId.secName, "%s", "VoiceService");
	return LTQ_set_VoipSystemObject(uiOperation,
																	pxNumPlan,
																	IFX_VMAPI_VS_NUM_PLAN,
																	IFX_VMAPI_OBJ_NUMPLAN,
																	uiInFlag);
}
/******************************************************************************
*  Function Name  : ifx_get_AddrBook
*  Description    : Get api to get Address Book object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAddrBook - pointer to AddrBook object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_AddrBook (IN_OUT  x_IFX_VMAPI_AddressBook  *pxAddrBook,
                       IN   uint32  uiInFlag)
{
  x_IFX_VMAPI_AddressBook  xAddrBook,*pxTemp;
  x_IFX_VMAPI_AddressBookEntry *pxIn, *pxOut;
  int32 i;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");
  if(uiInFlag == IFX_VMAPI_OP_NOMALLOC){
    memset(&xAddrBook,0,sizeof(x_IFX_VMAPI_AddressBook));
    pxTemp = &xAddrBook;
  }
  else{
    pxTemp = pxAddrBook;
  }
  pxTemp->iid.cpeId.Id = 1;
  pxTemp->iid.pcpeId.Id = 1;
  pxTemp->pxAddressBook=NULL;
  /* Object idIFX_VMAPI_OBJ_ADDRBOOK   */
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_ADDRBOOK,
                                       &pxTemp->iid,
                                       pxTemp,
                                       0) == IFX_VMAPI_FAIL){
    return IFX_VMAPI_FAIL;
  }
  /* TODO: Optimize later */
  /* Copy the list */
  printf("\n pxTemp->ucNoOfAddBookEntries:%d\n",pxTemp->ucNoOfAddBookEntries);
  printf("\n pxAddrBook->ucNoOfAddBookEntries:%d\n",pxAddrBook->ucNoOfAddBookEntries);
 if(uiInFlag == IFX_VMAPI_OP_NOMALLOC){
    i=1;
      pxIn = pxTemp->pxAddressBook;
      pxOut = pxAddrBook->pxAddressBook;
    while(i<=pxTemp->ucNoOfAddBookEntries){
      if((pxIn!=NULL)&&(pxOut !=NULL)){
        printf("Copying %d %s\n",i,pxOut->xAddress.acDisplayName);
        memcpy(pxOut,pxIn,sizeof(x_IFX_VMAPI_AddressBookEntry));
        pxOut->ucIndex = i;
        __ifx_list_GetNext((void *)&pxIn);
        __ifx_list_GetNext((void *)&pxOut);
      }
      i++;
    }
    pxAddrBook->ucNoOfAddBookEntries = pxTemp->ucNoOfAddBookEntries;
    ifx_vmapi_freeObjectList(pxTemp,IFX_VMAPI_VS_ADDRESS_BOOK);
  }
  return IFX_VMAPI_SUCCESS;

}



/******************************************************************************
*  Function Name  : ifx_set_AddrBook
*  Description    : Set api to set Address Book object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxAddrBook - Pointer to the object to be set
*  Output Values  : pxAddrBook - pointer to AddrBook object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/


int32 ifx_set_AddrBook(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_AddressBook *pxAddrBook,
                      IN uint32  uiInFlag)
{
  IFX_ID iid;
  int32 iInstanceIndex = -1 ;

  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */

  uint32 uiNvIdx = 0;
  int32 iRet;                                
  uchar8 buf[5000]; /* buffer used to hold config data */
  x_IFX_VMAPI_AddressBookEntry *pxTemp;                                                                                         
  //x_IFX_VMAPI_AddressBook xOldAddrBook;
  uint32 uiObjectId = IFX_VMAPI_OBJ_ADDRBOOK; //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "<ifx_set_AddrBook>Entering Function \n");

  printf("\n <ifx_set_AddrBook>Entering function. \n");
  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxAddrBook);

  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
 uiInFlag |= IFX_F_DELETE;
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Operation is IFX_OP_DEL - Not Supported");
            //return IFX_VMAPI_FAIL;
  }
  else if(uiOperation == IFX_OP_MOD) {
          uiInFlag |= IFX_F_MODIFY;
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Operation is IFX_OP_MODIFY");
  }
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
          uiInFlag |= IFX_F_INT_ADD;
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Operation is IFX_OP_ADD -- Not supported");
              printf("Operation is IFX_OP_ADD -- Not supported");
          return IFX_VMAPI_FAIL;
  }
  else {
     IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Operation Is Not Supported");
          return IFX_VMAPI_FAIL;
  }


  CHECK_ACS_SESSION_OWNER_COMBINATION(pxAddrBook->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }


  memset(&iid,0,sizeof(iid));

  pxAddrBook->iid.cpeId.Id = 1;
  pxAddrBook->iid.pcpeId.Id = 1;

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));

  IFX_VMAPI_LOCK(uiLock);
 if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxAddrBook,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List \n");
  printf("\n <ifx_set_AddrBook>Error : Could Not Get NV List. \n");
     goto EndLabel;
  }

  pxTemp = pxAddrBook->pxAddressBook;
  pxAddrBook->ucNoOfAddBookEntries = 0;
  while(pxTemp !=NULL)
  {
#if 0
    pxTemp->iid.cpeId.Id =pxAddrBook->ucNoOfAddBookEntries+1;
    pxTemp->iid.config_owner = pxAddrBook->iid.config_owner;
  printf("\n <ifx_set_AddrBook>Invoking ifx_set_AddrEntry. \n");
    ifx_set_AddrEntry(IFX_OP_MOD,pxTemp,0);
#endif
    pxAddrBook->ucNoOfAddBookEntries++;
    __ifx_list_GetNext((void *)&pxTemp);
  }
  printf("\n <ifx_set_AddrBook>Address Book Entries:%d\n",pxAddrBook->ucNoOfAddBookEntries);

  /* Normally Delete operation is not permitted on System Object
     This is a special case from Web user. It will delete all the
     contents of its entry list. */
  if(IFX_DELETE_F_SET(uiInFlag) ) {

    char8 s[] = "AddrEntry_Count";
    char8 pcCont[25] = {0};
    uint32 outFlag = 0;
    uint32 uiInFlag = 0;
    char8 acInBuf[IFX_MAX_BUFF_LEN] = {0};
    char8 acCommand[MAX_FILELINE_LEN] = {0};
    uchar8 pucIdList1[100][5];
    uchar8 ucNoOfIds;
    char8 PArray[200]={0};
    char8 NVArray[220]={0};
    uint32 uiAddrEntry[IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES];
    int32 d, j;
printf("\n <ifx_set_AddrBook>Delete Flag Set\n");
    sprintf((char8*)pcCont,"%s=\"%d\"\n",s,0);
    if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE,
                    "AddrEntry",
                    IFX_F_DEFAULT,
                    1,
                    (char8*)pcCont)) != IFX_SUCCESS)  {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could not SET the AddrEntry  \n");
  printf("\n <ifx_set_AddrBook>Could not set AddrEntry\n");
    }
#if 1

    sprintf((char8*)acCommand, "%s_CpeId", "AddrEntry");
    if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info",
         acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Error : Could Not Get Data for IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY !!");
      return iRet;
    }

    memset(pucIdList1,0,sizeof(pucIdList1));
    ifx_vmapi_ParseCpeId ((char8*)acInBuf,(char8 *)&pucIdList1[0][0],&ucNoOfIds);
    memset(&uiAddrEntry,0,sizeof(uiAddrEntry));
    for(d=0;d<ucNoOfIds;d++)
    {
      uiAddrEntry[d] =  0;
    }
    j=0;
    d=0;
    memset(&PArray,0,sizeof(PArray));
    for(d=0;d<ucNoOfIds;d++)
    {
      sprintf(&PArray[j],"%d",uiAddrEntry[d]);
      strcat(PArray,",");
      j=strlen(PArray);
    }
		if(j > 0)
	    PArray[j-1] = '\0';

    sprintf(NVArray,"%s=\"%s\"\n",acCommand,PArray);
 if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info",
        IFX_F_MODIFY, 1, (char8*)NVArray)) != IFX_SUCCESS)  {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Error : Could Not Set Data for IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY !!");
  printf("\n <ifx_set_AddrBook>Error : Could Not Set Data for IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY !!\n");
      return iRet;
    }
  //ifx_update_EntryId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY);


  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
    if (IFX_MODIFY_F_SET(uiInFlag)||(IFX_DELETE_F_SET(uiInFlag))) {
      if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_VS_ADDRESS_BOOK) == IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending The Notification\n");
	printf("Sending The notification\n");
        if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                        (IFX_VMAPI_VS_ADDRESS_BOOK,
                        NULL,NULL))
        {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Error : IFX_VMAPI_SendNotifyForRegObject for OP  failed!!! \n");
					printf("Error : IFX_VMAPI_SendNotifyForRegObject for %d  failed!!! \n",uiObjectId);
          ret = IFX_VMAPI_FAIL;
          goto EndLabel;
        }

    }
    }
  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */


#endif
    return IFX_VMAPI_SUCCESS;
  }


#if 0
  /*** Send Notification -> Not required anymore as contact list is maintained seperately ***/

  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
    if (IFX_MODIFY_F_SET(uiInFlag)||(IFX_DELETE_F_SET(uiInFlag))) {
      if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_VS_ADDRESS_BOOK) == IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending The Notification\n");
	printf("Sending The notification\n");
        if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                        (IFX_VMAPI_VS_ADDRESS_BOOK,
                        NULL,NULL))
        {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");
          ret = IFX_VMAPI_FAIL;
          goto EndLabel;
        }

    }
    }
  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */

  //ifx_vmapi_freeObjectList(&xOldAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
#endif

  IFX_VMAPI_STRCPY(pxAddrBook->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    iid =pxAddrBook->iid;
 if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {

       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid \n");
  printf("\n <ifx_set_AddrBook>Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }
  }
   /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
    /* TODO :: allocate new id and assign to iid */
    //uiInstanceId = new instance id or -1;
  }


  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : ifx_get_conf_index_and_nv_pairs failed\n");
  printf("\n <ifx_set_AddrBook>Error : ifx_get_conf_index_and_nv_pairs failed\n");
    IFX_VMAPI_UNLOCK(uiLock);
    return ret;
  }

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
#if 0
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names\n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
 }
  }
#endif

  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    /* compare fvp array from structure with fvp array from file and build changed fvp */
    if((ret=ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList)) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
  printf("\n <ifx_set_AddrBook>Error : Could Not Get Changed Field Names\n");
        goto EndLabel;
    }
  }


  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List \n");
  printf("\n <ifx_set_AddrBook>Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
  printf("\n <ifx_set_AddrBook>Info : There Are No Changed Fields Or No Fields To Be Added. \n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT
/* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  /* Backup rc.conf before proceeding with configuration */
  if ((ret = IFX_VMAPI_CheckPointRet((uiInFlag |!(IFX_F_DONT_CHECKPOINT)),
       SYSTEM_CONF_FILE, CHKPOINT_FILE)) == IFX_SUCCESS) { /* Backup taken */
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      }
#endif
      goto EndLabel;
    } else {
      /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Warning : ifx_CompactCfgSection failed \n");
          }
        }

        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " Cannot write to the flash\n");
 printf("\n <ifx_set_AddrBook>Cannot write to the flash \n");
        }
#endif

        /*** NOTIFICATION BLOCK ***/
        /* Notification is not implemented for this version */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Info : Notification is not required for non TR104 object\n");
    }
  } /* Backup taken */


EndLabel:
  /* Free all memory allocated in this function.... */
  printf("\n <ifx_set_AddrBook>Leaving Function,ret=%d\n",ret);
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function :\n");
  printf("\n <ifx_set_AddrBook>Leaving Function,ret=%d\n",ret);
  return ret;

}

/******************************************************************************
*  Function Name  : ifx_get_AddrEntry
*  Description    : Get api to get AddrEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAddrEntry - pointer to Addr Book object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_AddrEntry (IN_OUT x_IFX_VMAPI_AddressBookEntry  *pxAddrEntry,
                       IN   uint32  uiInFlag)
{ 
  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
   /* Get the CPE Id of the corresponding AddressBook Entry and assign it */
   //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,pxAddrEntry,&iCpeId);
   IFX_VMAPI_Get_CpeId_opt("AddrEntry_CpeId",pxAddrEntry->ucIndex,&iCpeId);
   pxAddrEntry->iid.cpeId.Id = iCpeId;
   pxAddrEntry->iid.pcpeId.Id = 1;


  /* Object id IFX_VMAPI_OBJ_ADDRBOOK_ENTRY   */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_ADDRBOOK_ENTRY,
                                       &pxAddrEntry->iid,
                                       pxAddrEntry,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_Addrentry
*  Description    : Set api to get Addrentry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxAddrEntry - Pointer to the object to be set
*  Output Values  : pxAddrEntry - pointer to Addrentry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_AddrEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_AddressBookEntry *pxAddrEntry,
                      IN uint32  uiInFlag)
{
  //IFX_ID iid;
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ;

  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */

  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
  uint32 iCpeId;

  uint32 uiObjectId = IFX_VMAPI_OBJ_ADDRBOOK_ENTRY; //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */

  x_IFX_VMAPI_AddressBook xAddrBook;
  memset(&xAddrBook,0,sizeof(x_IFX_VMAPI_AddressBook));

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");
  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxAddrEntry);


  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Operation is IFX_OP_DEL\n");
  }
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Operation is IFX_OP_MODIFY\n");
  }
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Operation is IFX_OP_ADD\n");
    printf("\n OPERATION IS : <ifx_set_AddrEntry>Add a new Entry.\n");
  }
 else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
  }


  CHECK_ACS_SESSION_OWNER_COMBINATION(pxAddrEntry->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }


  memset(&iid,0,sizeof(iid));
  memset(&piid,0,sizeof(piid));
  IFX_VMAPI_STRCPY(pxAddrEntry->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {

   // IFX_VMAPI_Get_CpeId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,pxAddrEntry,&iCpeId);
   IFX_VMAPI_Get_CpeId_opt("AddrEntry_CpeId",pxAddrEntry->ucIndex,&iCpeId);
    pxAddrEntry->iid.cpeId.Id = iCpeId;
    
		
  }

  sprintf(pxAddrEntry->iid.pcpeId.secName, "%s", "AddrBook");
  pxAddrEntry->iid.pcpeId.Id = 1;
  iid =pxAddrEntry->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    iid = pxAddrEntry->iid;
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {

       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }
  }

 piid.cpeId.Id = iid.pcpeId.Id;
  sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);

  /* Add a New Entry */
  if (IFX_INT_ADD_F_SET(uiInFlag)) {
    uint32 uiIndex=0;
    uint32 uiEndIndex=0;
    int32 uiErr=0;
    uchar8 ucNoOfEntries=0;
    x_IFX_VMAPI_AddressBookEntry *pxLocal; //to hold the new node
    x_IFX_VMAPI_AddressBookEntry *pxTemp;

    printf("\n <ifx_set_AddrEntry>Add a new Entry.\n");

    /* Get the full list of AddressBook */
    xAddrBook.iid.cpeId.Id = 1;
    xAddrBook.iid.pcpeId.Id = 1;
    xAddrBook.iid.config_owner = IFX_VOIP;
    if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,0))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Miss CallReg in \n");
      printf("\n <ifx_set_AddrEntry>ifx_get_AddrBook failed.\n");
    }

    ifx_get_StartEndIndex((VOID *)&xAddrBook,
                   IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,
                   pxAddrEntry->ucLineId,
                   &uiIndex,&uiEndIndex,&ucNoOfEntries);

    /*fp = fopen("/flash/addrentry.txt" , "a");
    fprintf(fp,"Start %d End: %d\n",uiIndex,uiEndIndex);
    fclose(fp);*/

	printf("Written to local file /flash/addentry.txt");

    pxTemp = (x_IFX_VMAPI_AddressBookEntry *)uiEndIndex;
    if(xAddrBook.ucNoOfAddBookEntries == IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES) {
        printf("\n Maximum Entries Allowed reached.\n");
        goto EndLabel;
#if 1
          ifx_free_EntryId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,
                ((x_IFX_VMAPI_AddressBookEntry *)uiIndex)->uiEntryId);
          __ifx_list_del((void *)&xAddrBook.pxAddressBook,(void *)uiIndex);
#endif
    }

if(pxAddrEntry->uiEntryId == 0) pxAddrEntry->uiEntryId=1;
    if(pxTemp != NULL)
      __ifx_list_GetNext((void *)&pxTemp);

    /* Allocates a memory of x_IFX_VMAPI_MissCallRegEntry type and add to the linked list */
    __ifx_list_createNadd(
                      (void *)&xAddrBook.pxAddressBook, //Head Ptr
                      (void*)&pxLocal,    // New Node
                      (void*) uiEndIndex,  //Prev Node
                      (void*) pxTemp,     //Next Node
                      sizeof(x_IFX_VMAPI_AddressBookEntry), //size
                      &uiErr);

#if 0
      if(ucNoOfEntries != IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES)
         uiFlag = 1;
    }
    else
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Same entry found \n");
    printf("\n <ifx_set_AddrEntry>Same Entry found.Failed!\n");
      ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
      return IFX_VMAPI_FAIL;
      //pxLocal = pxTemp;
    }
#endif
    ifx_get_EntryId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY,&pxAddrEntry->uiEntryId);
    /*fp = fopen("/flash/addrentry.txt" , "a");
    fprintf(fp,"Contact EntryId %d\n",pxAddrEntry->uiEntryId);
    fclose(fp);*/

    printf("\n <ifx_set_AddrEntry>Entry Id for new entry:%d\n",pxAddrEntry->uiEntryId);

    /* Copy the content in the new location */
   if(pxLocal != NULL) 
		memcpy(pxLocal,pxAddrEntry,sizeof(x_IFX_VMAPI_AddressBookEntry));

      /* Increase the count and SET the Object */
    xAddrBook.ucNoOfAddBookEntries++;

    if(IFX_VMAPI_SUCCESS != ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Set Address Book \n");
      goto EndLabel;
 }

    ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);

  }/* IFX_INT_ADD_F_SET */



  /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
    if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
    /*if (ifx_get_IID(&iid, "AddressType") != IFX_SUCCESS) */
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Failed to get the iid !!\n\n");
    printf("\n <ifx_set_AddrEntry>Failed to get iid!!\n");
      IFX_VMAPI_UNLOCK(uiLock);
      return IFX_VMAPI_FAIL;
    }
    pxAddrEntry->iid = iid;

    /* increment the next cpe id for this object */
    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
                IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));

  IFX_VMAPI_LOCK(uiLock);

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxAddrEntry,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List\n");
    printf("\n <ifx_set_AddrEntry>Error: Could not get NV list!\n");
     goto EndLabel;
 }

 if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : ifx_get_conf_index_and_nv_pairs failed \n");
    printf("\n <ifx_set_AddrEntry>Error : ifx_get_conf_index_and_nv_pairs failed.\n");
    IFX_VMAPI_UNLOCK(uiLock);
  	 goto EndLabel;

	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
#if 0
  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
    printf("\n <ifx_set_AddrEntry>Error : Could Not Get Changed Field Names.\n");
       IFX_VMAPI_UNLOCK(uiLock);
			 goto EndLabel;
    }
  }
#endif

 if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    /* compare fvp array from structure with fvp array from file and build changed fvp */
    if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
    printf("\n <ifx_set_AddrEntry>Error : Could Not Get Changed Field Names.\n");
  			 goto EndLabel;
    }

 }


  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  /* Backup rc.conf before proceeding with configuration */
  if ((ret = IFX_VMAPI_CheckPointRet((uiInFlag |!(IFX_F_DONT_CHECKPOINT)),
       SYSTEM_CONF_FILE, CHKPOINT_FILE)) == IFX_SUCCESS) { /* Backup taken */
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Warning : Could Not Roll Back Config File \n");
      }
#endif
      goto EndLabel;
    } else {
      /* Config file is updated */
       /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Warning : ifx_CompactCfgSection failed \n");
          }
        }

        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " Cannot write to the flash\n");
          printf("\n <ifx_set_AddrEntry>Cannot write to the flash.\n");
        }
#endif

        /*** NOTIFICATION BLOCK ***/
        /* Notification is not implemented for this version */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Info : Notification is not implemented for this version\n");
    }
  } /* Backup taken */

  if (IFX_INT_ADD_F_SET(uiInFlag)) {
     //fprintf(fp,"<SET>CPEID =%d for ucIndex =%d",pxAddrEntry->iid.cpeId.Id,pxAddrEntry->ucIndex);
     //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY, pxAddrEntry,pxAddrEntry->iid.cpeId.Id);
     IFX_VMAPI_Update_CpeId_opt("AddrEntry_CpeId", pxAddrEntry->ucIndex,pxAddrEntry->iid.cpeId.Id);
  }

  if (IFX_DELETE_F_SET(uiInFlag)) {
 /* Update the CpeId corresponding to that index entry */
    //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY, pxAddrEntry,0);
    IFX_VMAPI_Update_CpeId_opt("AddrEntry_CpeId", pxAddrEntry->ucIndex,0);
	//ifx_update_EntryId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY);
	ifx_free_EntryId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY, pxAddrEntry->uiEntryId);	
}
#if 0
  /* Need to update addr book only in case of add operation */
  if (IFX_INT_ADD_F_SET(uiInFlag)) {
    xAddrBook.ucNoOfAddBookEntries++;
    printf("\n <ifx_set_AddrEntry>Address Book Entries:%d\n",xAddrBook.ucNoOfAddBookEntries);
    if(IFX_VMAPI_SUCCESS != ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,0))
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Error : Could Not Set Miss CallReg - Number of Miss Entries \n");
    }
    ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY);
  }
#endif
  ret=IFX_VMAPI_SUCCESS;


EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function \n");
    printf("\n <ifx_set_AddrEntry>Leaving function,ret:%d\n",ret);
  return ret;

}

/******************************************************************************
*  Function Name  : ifx_set_DelIfEntryExist
*  Description    : Check If the entry exists.
*  Input Values   : pvCallRegList -- the entry list
*                   pvCallEntry -- the call entry
*                   unObjCode -- Dial/Miss/Recv
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DelIfEntryExist(IN VOID *pvCallRegList,
                              IN VOID *pvCallEntry,
							                IN uint16 unObjCode)
{
  char8 acStringToMatch[IFX_VMAPI_MAX_USER_NAME_LEN + IFX_VMAPI_MAX_DOMAIN_NAME_LEN] = {0}; 
  char8 acString[IFX_VMAPI_MAX_USER_NAME_LEN + IFX_VMAPI_MAX_DOMAIN_NAME_LEN] = {0}; 
	int32 iCount =0;

	if(unObjCode == IFX_VMAPI_OBJ_CALLREGISTER_DIAL)
	{
	  x_IFX_VMAPI_DialCallRegEntry *pxTemp1;
	  x_IFX_VMAPI_DialCallRegEntry *pxDialCallEntry;
		x_IFX_VMAPI_DialCallRegister *pxDialCallReg;
		pxDialCallReg = (x_IFX_VMAPI_DialCallRegister *)pvCallRegList;
		pxDialCallEntry = (x_IFX_VMAPI_DialCallRegEntry *)pvCallEntry;

    sprintf(&acStringToMatch[0],"%s@%s",pxDialCallEntry->xAddress.acUserName,
		  							pxDialCallEntry->xAddress.acDestAddr);
    
		pxTemp1 = pxDialCallReg->pxCallRegEntries;
    while(pxTemp1 !=NULL)
    {
		  iCount ++;
      sprintf(&acString[0],"%s@%s",pxTemp1->xAddress.acUserName,
			  							pxTemp1->xAddress.acDestAddr);
	    //printf("acString=[%s] acStringToMatch =[%s]\n",acString,acStringToMatch);
		  if(!(IFX_VMAPI_STRCMP(acString , acStringToMatch)))
		  {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			       	   "Matched String Found!!!! \n");
				//printf("Matched String Found!!!!!\n");
        __ifx_list_del((void *)&pxDialCallReg->pxCallRegEntries,(void *)pxTemp1);
				return IFX_VMAPI_SUCCESS;
		  }
      __ifx_list_GetNext((void *)&pxTemp1);
    } 
		return IFX_VMAPI_FAIL;
  }
  if(unObjCode == IFX_VMAPI_OBJ_CALLREGISTER_MISS)
	{
	  x_IFX_VMAPI_MissCallRegEntry *pxTemp2;
	  x_IFX_VMAPI_MissCallRegEntry *pxMissCallEntry;
		x_IFX_VMAPI_MissCallRegister *pxMissCallReg;
		pxMissCallReg = (x_IFX_VMAPI_MissCallRegister *)pvCallRegList;
		pxMissCallEntry = (x_IFX_VMAPI_MissCallRegEntry *)pvCallEntry;
		
    sprintf(&acStringToMatch[0],"%s@%s",pxMissCallEntry->xAddress.acUserName,
		  							pxMissCallEntry->xAddress.acDestAddr);
    pxTemp2 = pxMissCallReg->pxCallRegEntries;
    while(pxTemp2 !=NULL)
    {
		  iCount ++;
      sprintf(&acString[0],"%s@%s",pxTemp2->xAddress.acUserName,
			  							pxTemp2->xAddress.acDestAddr);
	    //printf("acString=[%s] acStringToMatch =[%s]\n",acString,acStringToMatch);
		  if(!(IFX_VMAPI_STRCMP(acString , acStringToMatch)))
		  {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			       	   "Matched String Found!!!! \n");
        __ifx_list_del((void *)&pxMissCallReg->pxCallRegEntries,(void *)pxTemp2);
				return IFX_VMAPI_SUCCESS;
		  }
      __ifx_list_GetNext((void *)&pxTemp2);
    } 
		return IFX_VMAPI_FAIL;
  }
  if(unObjCode == IFX_VMAPI_OBJ_CALLREGISTER_RECV)
	{
	  x_IFX_VMAPI_RecvCallRegEntry *pxTemp3;
	  x_IFX_VMAPI_RecvCallRegEntry *pxRecvCallEntry;
		x_IFX_VMAPI_RecvCallRegister *pxRecvCallReg;
		pxRecvCallReg = (x_IFX_VMAPI_RecvCallRegister *)pvCallRegList;
		pxRecvCallEntry = (x_IFX_VMAPI_RecvCallRegEntry *)pvCallEntry;
		
    sprintf(&acStringToMatch[0],"%s@%s",pxRecvCallEntry->xAddress.acUserName,
		  							pxRecvCallEntry->xAddress.acDestAddr);
    pxTemp3 = pxRecvCallReg->pxCallRegEntries;
    while(pxTemp3 !=NULL)
    {
		  iCount ++;
      sprintf(&acString[0],"%s@%s",pxTemp3->xAddress.acUserName,
			  							pxTemp3->xAddress.acDestAddr);
		  if(!(IFX_VMAPI_STRCMP(acString , acStringToMatch)))
		  {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			       	   "Matched String Found!!!! \n");
        __ifx_list_del((void *)&pxRecvCallReg->pxCallRegEntries,(void *)pxTemp3);
				return IFX_VMAPI_SUCCESS;
		  }
      __ifx_list_GetNext((void *)&pxTemp3);
    } 
		return IFX_VMAPI_FAIL;
  }
	return IFX_VMAPI_SUCCESS;
}


/******************************************************************************
*  Function Name  : ifx_get_DialCallReg
*  Description    : Get api to get Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDialCallReg - pointer to Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_DialCallReg (IN_OUT  x_IFX_VMAPI_DialCallRegister  *pxDialCallReg,
                       IN   uint32  uiInFlag)
{
	uint32 uiObjectId =IFX_VMAPI_OBJ_CALLREGISTER_DIAL , uiListType=IFX_VMAPI_VS_DIALCALL_REGISTER;

  if(pxDialCallReg->ucLineId == IFX_VMAPI_PSTN_LINE){
        uiObjectId =IFX_VMAPI_OBJ_PSTN_CALLREGISTER_DIAL;
        uiListType=IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER;
  }

  pxDialCallReg->pxCallRegEntries=NULL;
  /* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  LTQ_get_CallRegister(pxDialCallReg,
                                     uiListType,
                                     uiObjectId,
                                     uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_DialCallReg
*  Description    : Set api to set Dialed Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallReg - Pointer to the object to be set
*  Output Values  : pxMissCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DialCallReg(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_DialCallRegister *pxDialCallReg,
                      IN uint32  uiInFlag)
{
	uint32 uiListType=IFX_VMAPI_VS_DIALCALL_REGISTER;
	uint32 uiObjectId=IFX_VMAPI_OBJ_CALLREGISTER_DIAL;
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxDialCallReg);

	if(pxDialCallReg->ucLineId == IFX_VMAPI_PSTN_LINE){
				uiListType=IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER;
				uiObjectId=IFX_VMAPI_OBJ_PSTN_CALLREGISTER_DIAL;
	}
	return LTQ_set_CallRegister(uiOperation,
															pxDialCallReg,
          	                  uiListType,
            	                uiObjectId,
              	              uiInFlag);
}
  

/******************************************************************************
*  Function Name  : ifx_get_MissCallReg
*  Description    : Get api to get Missed Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallReg - pointer to Missed Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_MissCallReg (IN_OUT  x_IFX_VMAPI_MissCallRegister  *pxMissCallReg,
		                       IN   uint32  uiInFlag)
{
	uint32 uiObjectId =IFX_VMAPI_OBJ_CALLREGISTER_MISS , uiListType=IFX_VMAPI_VS_MISSCALL_REGISTER;

	if(pxMissCallReg->ucLineId == IFX_VMAPI_PSTN_LINE){
			uiObjectId =IFX_VMAPI_OBJ_PSTN_CALLREGISTER_MISS;
			uiListType=IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER;
	}

	pxMissCallReg->pxCallRegEntries=NULL;
	/* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  LTQ_get_CallRegister(pxMissCallReg,
															 uiListType,
															 uiObjectId,
                               uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_set_MissCallReg
*  Description    : Set api to set Missed Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallReg - Pointer to the object to be set
*  Output Values  : pxMissCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_MissCallReg(IN uint32  uiOperation,
		                      IN  x_IFX_VMAPI_MissCallRegister *pxMissCallReg,
    		                  IN uint32  uiInFlag)
{
	uint32 uiListType=IFX_VMAPI_VS_MISSCALL_REGISTER;
	uint32 uiObjectId=IFX_VMAPI_OBJ_CALLREGISTER_MISS;
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxMissCallReg);
	if(pxMissCallReg->ucLineId == IFX_VMAPI_PSTN_LINE){
					uiListType=IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER;
					uiObjectId=IFX_VMAPI_OBJ_PSTN_CALLREGISTER_MISS;
	}
	return LTQ_set_CallRegister(uiOperation,
															pxMissCallReg,
															uiListType,
															uiObjectId,
															uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_MissCallRegEntry
*  Description    : Get api to get MissCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallRegEtr - pointer to MissCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_MissCallRegEntry (IN_OUT x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,
					                      IN   uint32  uiInFlag)
{ 

	if(pxMissCallRegEtr->ucLineId == IFX_VMAPI_PSTN_LINE){
			return ifx_get_PstnMissCallRegEntry(pxMissCallRegEtr,uiInFlag);
	}

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					"Entering Function \n");
	/* Object id IFX_VMAPI_OBJ_CALLREG_MISSENTRY */
	return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CALLREG_MISSENTRY,
																		 &pxMissCallRegEtr->iid,
																		 pxMissCallRegEtr,
                                     uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_MissCallRegEntry
*  Description    : Set api to get MissCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallRegEtr - Pointer to the object to be set
*  Output Values  : pxMissCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_MissCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_MissCallRegEntry *pxMissCallRegEtr,
                      IN uint32  uiInFlag)
{
	uint32 uiObjectType = IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY;     
	uint32 uiObjectId = IFX_VMAPI_OBJ_CALLREG_MISSENTRY;
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxMissCallRegEtr);

	if(pxMissCallRegEtr->ucLineId == IFX_VMAPI_PSTN_LINE){
			uiObjectType = IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY;
			uiObjectId = IFX_VMAPI_OBJ_PSTN_CALLREG_MISSENTRY;
	}
	return LTQ_set_CallRegisterEntry(uiOperation,
																	pxMissCallRegEtr,
																	uiObjectType,
			                            uiObjectId,
				                          uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_RecvCallReg
*  Description    : Get api to get Recieved Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxRecvCallReg - pointer to Received Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_RecvCallReg (IN_OUT  x_IFX_VMAPI_RecvCallRegister  *pxRecvCallReg,
					                 IN   uint32  uiInFlag)
{
	uint32 uiObjectId =IFX_VMAPI_OBJ_CALLREGISTER_RECV , uiListType=IFX_VMAPI_VS_RECVCALL_REGISTER;

	if(pxRecvCallReg->ucLineId == IFX_VMAPI_PSTN_LINE){
				uiObjectId =IFX_VMAPI_OBJ_PSTN_CALLREGISTER_RECV;
				uiListType=IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER;
	}

	pxRecvCallReg->pxCallRegEntries=NULL;
	/* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  LTQ_get_CallRegister(pxRecvCallReg,
															 uiListType,
															 uiObjectId,
															 uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_set_RecvCallReg
*  Description    : Set api to set Missed Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallReg - Pointer to the object to be set
*  Output Values  : pxMissCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_RecvCallReg(IN uint32  uiOperation,
			                    IN  x_IFX_VMAPI_RecvCallRegister *pxRecvCallReg,
					                IN uint32  uiInFlag)
{
	uint32 uiListType=IFX_VMAPI_VS_RECVCALL_REGISTER;
	uint32 uiObjectId=IFX_VMAPI_OBJ_CALLREGISTER_RECV;
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxRecvCallReg);

	if(pxRecvCallReg->ucLineId == IFX_VMAPI_PSTN_LINE){
		 uiListType=IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER;
		 uiObjectId=IFX_VMAPI_OBJ_PSTN_CALLREGISTER_RECV;
	}
	return LTQ_set_CallRegister(uiOperation,
															pxRecvCallReg,
															uiListType,
															uiObjectId,
															uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_RecvCallRegEntry
*  Description    : Get api to get RecvCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxRecvCallRegEtr - pointer to RecvCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_RecvCallRegEntry (IN_OUT x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,
						                     IN   uint32  uiInFlag)
{
	if(pxRecvCallRegEtr->ucLineId == IFX_VMAPI_PSTN_LINE){
			return ifx_get_PstnRecvCallRegEntry(pxRecvCallRegEtr,uiInFlag);
	}

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					"Entering Function \n");
	/* Object id IFX_VMAPI_OBJ_CALLREG_RECVENTRY */
	return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CALLREG_RECVENTRY,
																			 &pxRecvCallRegEtr->iid,
																			 pxRecvCallRegEtr,
																			 uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_RecvCallRegEntry
*  Description    : Set api to get RecvCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxRecvCallRegEtr - Pointer to the object to be set
*  Output Values  : pxRecvCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_RecvCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_RecvCallRegEntry *pxRecvCallRegEtr,
                      IN uint32  uiInFlag)
{
uint32 uiObjectType = IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY;     
uint32 uiObjectId = IFX_VMAPI_OBJ_CALLREG_RECVENTRY;
  if(pxRecvCallRegEtr->ucLineId == IFX_VMAPI_PSTN_LINE){
    uiObjectType = IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY;
    uiObjectId = IFX_VMAPI_OBJ_PSTN_CALLREG_RECVENTRY;
  }
  return LTQ_set_CallRegisterEntry(uiOperation,
                                  pxRecvCallRegEtr,
                                  uiObjectType,
                                  uiObjectId,
                                  uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_LineSubscription
*  Description    : Get api to get Line Subscription object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineSub - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineSubscription (IN_OUT  x_IFX_VMAPI_LineSubscription  *pxLineSub,
                       IN   uint32  uiInFlag)
{ 

  uint32 iCpeId, iCpeIdLine;
  x_IFX_VMAPI_VoiceLine xVoiceLine;
  
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxLineSub->iid.config_owner != IFX_TR69) {
					
		memset(&xVoiceLine,0,sizeof(xVoiceLine));
    /* Assign the LineId of the  LineSubscription object to VoiceLine object */
    xVoiceLine.ucLineId = pxLineSub->ucLineId;
    /* Get the CpeId of the Parent Object VoiceLine */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine,&iCpeIdLine);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",xVoiceLine.ucLineId,&iCpeIdLine);
	  sprintf(pxLineSub->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxLineSub->iid.pcpeId.Id = iCpeIdLine;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VL_EVENT_SUBSCR,pxLineSub,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("LineSubscription_CpeId",pxLineSub->ucLineId,&iCpeId);
    //printf("[%s %d]CpeId is : %d",__FUNCTION__, __LINE__, iCpeId);
    pxLineSub->iid.cpeId.Id = iCpeId;
	}
	
  pxLineSub->pxLineEvents=NULL;

 /* Object id IFX_VMAPI_OBJ_LINESUB   */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_LINESUB,
                                       &pxLineSub->iid,
                                       pxLineSub,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_set_LineSubscription
*  Description    : Set api to get LineSubscription object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineSubscr - Pointer to the object to be set
*  Output Values  : pxLineSubscr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineSubscription(IN uint32  uiOperation,
				                      IN  x_IFX_VMAPI_LineSubscription *pxLineSubscr,
								              IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxLineSubscr);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineSubscr->iid.config_owner);
	sprintf(pxLineSubscr->iid.pcpeId.secName, "%s", "VoiceLine");
	return LTQ_set_VoiceLineObject(uiOperation,
																	pxLineSubscr,
																	IFX_VMAPI_MAX_OBJ,
																	IFX_VMAPI_OBJ_LINESUB,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_LineEvents
*  Description    : Get api to get Line Subscription object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineEvents - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineEvents (IN_OUT  x_IFX_VMAPI_LineEvents  *pxLineEvents,
													 IN   uint32  uiInFlag)
{ 
	uint32 iCpeId;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		"Entering Function \n");

	if(pxLineEvents->iid.config_owner != IFX_TR69) {
		//IFX_VMAPI_Get_CpeId(IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY,pxLineEvents,&iCpeId);
		IFX_VMAPI_Get_CpeId_opt("LineSubEvent_CpeId",(((pxLineEvents->ucLineId- 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxLineEvents->ucIndex),&iCpeId);
		pxLineEvents->iid.cpeId.Id = iCpeId;
	}

			/* Object id IFX_VMAPI_OBJ_LINEEVENTS */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_LINEEVENTS,
                                       &pxLineEvents->iid,
                                       pxLineEvents,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_LineEvents
*  Description    : Set api to set LineEvents object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineEvents - Pointer to the object to be set
*  Output Values  : pxLineEvents - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineEvents(IN uint32  uiOperation,
		                    IN  x_IFX_VMAPI_LineEvents *pxLineEvents,
			                  IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxLineEvents);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineEvents->iid.config_owner);

	sprintf(pxLineEvents->iid.pcpeId.secName, "%s", "VoiceLineSignaling");

	return LTQ_set_VoiceLineObject(uiOperation,
																pxLineEvents,
																IFX_VMAPI_MAX_OBJ, /*IFX_VMAPI_VL_LINEEVENTS,*/
																IFX_VMAPI_OBJ_LINEEVENTS,
																uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_AuthCfg
*  Description    : Get api to get AuthCfg object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAuthCfg - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_AuthCfg (IN_OUT  x_IFX_VMAPI_SipAuthCfg  *pxAuthCfg,
                       IN   uint32  uiInFlag)
{ 
	uint32 iCpeId;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Entering Function \n");

	if(pxAuthCfg->iid.config_owner != IFX_TR69) {
		/* Get the CPE Id of the corresponding AuthCfg and assign it */
		IFX_VMAPI_Get_CpeId_opt("AuthCfg_CpeId",(((pxAuthCfg->ucLineId-1)*IFX_VMAPI_MAX_AUTH_INFO)+pxAuthCfg->ucIndex),&iCpeId);
		pxAuthCfg->iid.cpeId.Id = iCpeId;
	}

	/* Object idIFX_VMAPI_OBJ_AUTHCFG */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_AUTHCFG,
                                       &pxAuthCfg->iid,
                                       pxAuthCfg,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_AuthCfg
*  Description    : Set api to get AuthCfg object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxAuthCfg - Pointer to the object to be set
*  Output Values  : pxAuthCfg - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_AuthCfg(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_SipAuthCfg *pxAuthCfg,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxAuthCfg);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxAuthCfg->iid.config_owner);
	sprintf(pxAuthCfg->iid.pcpeId.secName, "%s", "VoiceLine");
	return LTQ_set_VoiceLineObject(uiOperation,
																	pxAuthCfg,
																	IFX_VMAPI_VL_AUTHCFG, /*IFX_VMAPI_VL_LINEEVENTS,*/
																	IFX_VMAPI_OBJ_AUTHCFG,
																	uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_EventSubscribe
*  Description    : Get api to get EventSubscribe object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxEventSub - pointer to EventSubscribe object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_EventSubscribe (IN_OUT x_IFX_VMAPI_EventSubscribe  *pxEventSub,
				                       IN   uint32  uiInFlag)
{ 
  uint32 iCpeId;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxEventSub->iid.config_owner != IFX_TR69) {
					
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY,pxEventSub,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("EventSubscribe_CpeId",(((pxEventSub->ucProfileId - 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxEventSub->ucIndex),&iCpeId);
    pxEventSub->iid.cpeId.Id = iCpeId;
	}

  /* Object id IFX_VMAPI_OBJ_PROFEVENT_SUBSCR  */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PROFEVENT_SUBSCR,
                                       &pxEventSub->iid,
                                       pxEventSub,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_EventSubscribe
*  Description    : Set api to get EventSubscribe object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxEventSub - Pointer to the object to be set
*  Output Values  : pxEventSub - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_EventSubscribe(IN uint32  uiOperation,
							               IN  x_IFX_VMAPI_EventSubscribe *pxEventSub,
											       IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
						 "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxEventSub);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxEventSub->iid.config_owner);
	sprintf(pxEventSub->iid.pcpeId.secName, "%s", "VoiceProfileSignaling");
	printf("	ifx_set_EventSubscribe Entry \n");
	return LTQ_set_VoipProfileObject(uiOperation,
																		pxEventSub,
																		IFX_VMAPI_VP_EVENT_SUBSCR,
																		IFX_VMAPI_OBJ_PROFEVENT_SUBSCR,
																		uiInFlag);
}
/******************************************************************************
*  Function Name  : ifx_get_DialCallRegEntry
*  Description    : Get api to get CallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDialCallRegEtr - pointer to CallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_DialCallRegEntry (IN_OUT x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,
					                      IN   uint32  uiInFlag)
{

	if(pxDialCallRegEtr->ucLineId == IFX_VMAPI_PSTN_LINE){
      return ifx_get_PstnDialCallRegEntry(pxDialCallRegEtr,uiInFlag);
    }

 
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
  /* Object id  IFX_VMAPI_OBJ_CALLREG_DIALENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CALLREG_DIALENTRY,
                                       &pxDialCallRegEtr->iid,
                                       pxDialCallRegEtr,
                                       uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_set_DialCallRegEntry
*  Description    : Set api to get CallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDialCallRegEtr - Pointer to the object to be set
*  Output Values  : pxDialCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DialCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_DialCallRegEntry *pxDialCallRegEtr,
                      IN uint32  uiInFlag)
{
uint32 uiObjectType = IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY; 
uint32 uiObjectId = IFX_VMAPI_OBJ_CALLREG_DIALENTRY;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	if(pxDialCallRegEtr->ucLineId == IFX_VMAPI_PSTN_LINE){
		  uiObjectType = IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY;
			uiObjectId = IFX_VMAPI_OBJ_PSTN_CALLREG_DIALENTRY;
	}
	return LTQ_set_CallRegisterEntry(uiOperation,
																	pxDialCallRegEtr,
																	uiObjectType,
																	uiObjectId,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_Misc
*  Description    : Get api to get Miscellaneous object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMisc - pointer to Miscellaneous object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Misc (IN_OUT  x_IFX_VMAPI_Misc  *pxMisc,
                       IN   uint32  uiInFlag)
{ 
  
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	pxMisc->iid.cpeId.Id = 1;
	pxMisc->iid.pcpeId.Id = 1;

  /* Object idIFX_VMAPI_OBJ_MISC   */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_MISC,
                                       &pxMisc->iid,
                                       pxMisc,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_set_Misc
*  Description    : Set api to get Misc object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMisc - Pointer to the object to be set
*  Output Values  : pxMisc - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Misc(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_Misc *pxMisc,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxMisc);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxMisc->iid.config_owner);
	sprintf(pxMisc->iid.pcpeId.secName, "%s", "VoiceService");
	return LTQ_set_VoipSystemObject(uiOperation,
																	pxMisc,
																	IFX_VMAPI_VS_MISC,
																	IFX_VMAPI_OBJ_MISC,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_VoicePhyInterface
*  Description    : Get api to get VoiceServPhyIf object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxVoiceServPhyIf - Pointer to the VoiceServPhyIf object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_VoicePhyInterface(IN_OUT x_IFX_VMAPI_VoiceServPhyIf *pxVoiceIf,
                                 IN uint32 uiInFlag)
{
  uchar8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN +IFX_VMAPI_MAX_INT_LEN];
  uint32 uiNameValIdx=0;
  int32 iRet = IFX_VMAPI_FAIL;
  /* lock */
  IFX_VMAPI_LOCK(uiLock);
	
	IFX_VMAPI_STRCPY((char8*)acPrefix,
                   IFX_VMAPI_GET_OBJ_NAME(IFX_VMAPI_OBJ_PHY_IFACE));
	 
  IFX_VMAPI_SPRINTF((char8*)acPrefix, "%s_%d_",
                    (char8*)IFX_VMAPI_GET_OBJ_PREFIX(IFX_VMAPI_OBJ_PHY_IFACE),
                    pxVoiceIf->ucInterfaceId -1);
  
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_PREFIX,
					 acPrefix);
  /* Get the corresponding Name-Value pair from conf file */ 
  if ((iRet = IFX_VMAPI_GetNVPairsForObject(pxVoiceIf, &g_xNVList,
              IFX_VMAPI_OBJ_PHY_IFACE, acPrefix, 0) ) == IFX_VMAPI_SUCCESS) {
    IFX_VMAPI_PRINT_NAMEVAL(g_xNVList.axNameValue, g_xNVList.unNoOfNVPairs);
		/* Fill the structure with the Name-Value pair values */
    iRet = IFX_VMAPI_GetObjFromNameValueList(IFX_VMAPI_OBJ_PHY_IFACE, 
              pxVoiceIf, &g_xNVList, &uiNameValIdx, acPrefix);
  } else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "ifx_GetCfgObject returned failure\n");
  }

  /* unlock */
  IFX_VMAPI_UNLOCK(uiLock);
  return iRet;

}


/******************************************************************************
*  Function Name  : ifx_get_FxoPhyIf
*  Description    : Get api to get FXO object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxFxoPhyIf - pointer to FXO object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_FxoPhyInterface (IN_OUT  x_IFX_VMAPI_FxoPhyIf  *pxFxoPhyIf,
                       IN   uint32  uiInFlag)
{ 
  int32 index=0; 
  uchar8 pucFxoendptsList[20][20] = {{0}};
  uchar8 ucNoOfFxoendpts;
  //char8  pFxoendptsString[20];
  uint32 iCpeId;

  //IFX_VMAPI_Get_CpeId(IFX_VMAPI_PHY_IFACE_FXO,pxFxoPhyIf,&iCpeId);
  /* TODO: Replace with MAX FXS instead of 2 */
  IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",(pxFxoPhyIf->xVoiceServPhyIf.ucInterfaceId-2),&iCpeId);
  pxFxoPhyIf->iid.cpeId.Id = iCpeId;
  pxFxoPhyIf->iid.pcpeId.Id = 1;


  if ( IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_FXOPHYINT,
                                       &pxFxoPhyIf->iid,
                                       pxFxoPhyIf,
                                       uiInFlag) == IFX_VMAPI_SUCCESS)
  {	
    memset(&pucFxoendptsList,0,sizeof(pucFxoendptsList));
   //	strcpy(pFxoendptsString,pxFxoPhyIf->ucInterfaceIdList);
    ifx_ParseCallBlockList (pxFxoPhyIf->ucInterfaceIdList,&pucFxoendptsList[0][0],
                              &ucNoOfFxoendpts); 

    memset(pxFxoPhyIf->ucInterfaceIdList,0,sizeof(pxFxoPhyIf->ucInterfaceIdList));
		for(index=0;index<ucNoOfFxoendpts;index++)
		{
//#ifndef DECT_SUPPORT
#if !defined(DECT_SUPPORT) && !defined(CVOIP_SUPPORT)
			if (index > 1)
				break;
#endif
      pxFxoPhyIf->ucInterfaceIdList[index] = atoi((char8 *)pucFxoendptsList[index]);
    }
    return IFX_VMAPI_SUCCESS;
  }
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_FxoPhyInterface
*  Description    : Set api to get FxoPhyInterface object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxFxoPhyIf - Pointer to the object to be set
*  Output Values  : pxFxoPhyIf - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_FxoPhyInterface(IN uint32  uiOperation,
															IN  x_IFX_VMAPI_FxoPhyIf *pxFxoPhyIf,
															IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxFxoPhyIf);

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxFxoPhyIf->iid.config_owner);
  sprintf(pxFxoPhyIf->iid.pcpeId.secName, "%s", "VoiceService");

	return LTQ_set_VoiceLineObject(uiOperation,
		                              pxFxoPhyIf,
			                            IFX_VMAPI_PHY_IFACE_FXO,
				                          IFX_VMAPI_OBJ_FXOPHYINT,
						                      uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_FxsPhyIf
*  Description    : Get api to get FXS object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxFxsPhyIf - pointer to FXS object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_FxsPhyInterface (IN_OUT  x_IFX_VMAPI_FxsPhyIf  *pxFxsPhyIf,
					                      IN   uint32  uiInFlag)
{ 
  int32 index=0; 
  uchar8 pucFxsendptsList[20][20];
  uchar8 ucNoOfFxsendpts;
  //char8  pFxsendptsString[20];
  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
   
  /* Get the CPE Id of the corresponding LineId and assign it */
  //IFX_VMAPI_Get_CpeId(IFX_VMAPI_PHY_IFACE_FXS,pxFxsPhyIf,&iCpeId);
  IFX_VMAPI_Get_CpeId_opt("FxsphyInterface_CpeId",pxFxsPhyIf->xVoiceServPhyIf.ucInterfaceId,&iCpeId);
  pxFxsPhyIf->iid.cpeId.Id = iCpeId;
  pxFxsPhyIf->iid.pcpeId.Id = 1;
   
  /* Object id IFX_VMAPI_OBJ_FXSPHYINT   */
  if( IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_FXSPHYINT,
                                       &pxFxsPhyIf->iid,
                                       pxFxsPhyIf,
                                       uiInFlag) == IFX_VMAPI_SUCCESS) 
  {

    memset(&pucFxsendptsList,0,sizeof(pucFxsendptsList));
    //strcpy(pFxsendptsString,pxFxsPhyIf->ucVoiceLineIdList);
    ifx_ParseCallBlockList (pxFxsPhyIf->ucVoiceLineIdList,&pucFxsendptsList[0][0],
                              &ucNoOfFxsendpts); 
  
    memset(pxFxsPhyIf->ucVoiceLineIdList,0,sizeof(pxFxsPhyIf->ucVoiceLineIdList));
		for(index=0;index<ucNoOfFxsendpts;index++)
    { 
      pxFxsPhyIf->ucVoiceLineIdList[index] = atoi((char8 *)pucFxsendptsList[index]);
    }
    return IFX_VMAPI_SUCCESS;
  }
  return IFX_VMAPI_FAIL;
}


/******************************************************************************
*  Function Name  : ifx_set_FxsPhyInterface
*  Description    : Set api to get FxsPhyInterface object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxFxsPhyIf - Pointer to the object to be set
*  Output Values  : pxFxsPhyIf - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_FxsPhyInterface(IN uint32  uiOperation,
									            IN  x_IFX_VMAPI_FxsPhyIf *pxFxsPhyIf,
													    IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxFxsPhyIf);
   
  CHECK_ACS_SESSION_OWNER_COMBINATION(pxFxsPhyIf->iid.config_owner);
  sprintf(pxFxsPhyIf->iid.pcpeId.secName, "%s", "VoiceService");

	return LTQ_set_VoiceLineObject(uiOperation,
																	pxFxsPhyIf,
																	IFX_VMAPI_PHY_IFACE_FXS,
																	IFX_VMAPI_OBJ_FXSPHYINT,
																	uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_DbgSettings
*  Description    : Get api to get Debug Type object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDbgSet - pointer to Debug Type object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_DbgSettings (IN_OUT  x_IFX_VMAPI_SystemDebugSettings  *pxDbgSet,
                       IN   uint32  uiInFlag)
{ 
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	
  pxDbgSet->iid.cpeId.Id = 1;
	pxDbgSet->iid.pcpeId.Id = 1;
  /* Object id IFX_VMAPI_OBJ_DBG_SET   */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DBG_SET,
                                       &pxDbgSet->iid,
                                       pxDbgSet,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_set_DbgSettings
*  Description    : Set api to set Debug settings object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDbgSet - Pointer to the object to be set
*  Output Values  : pxDbgSet - pointer to Debug object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DbgSettings(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_SystemDebugSettings *pxDbgSet,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxDbgSet);
	
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxDbgSet->iid.config_owner);
	sprintf(pxDbgSet->iid.pcpeId.secName, "%s", "VoiceService");

	return LTQ_set_VoipSystemObject(uiOperation,
																	pxDbgSet,
																	IFX_VMAPI_VS_DEBUG_SET,
																	IFX_VMAPI_OBJ_DBG_SET,
																	uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_get_Version
*  Description    : Get api to get Version object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxVer - pointer to Version object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Version (IN_OUT  x_IFX_VMAPI_SystemVersionRegister  *pxVer,
                       IN   uint32  uiInFlag)
{

  pxVer->iid.cpeId.Id = 1;
  pxVer->iid.pcpeId.Id = 1;
  /* Object id IFX_VMAPI_OBJ_VER_REG   */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VER_REG,
                                       &pxVer->iid,
                                       pxVer,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_get_ProfileEventSubsTable
*  Description    : Get api to get ProfileEventSubsTable object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileEventSubsTable - pointer to ProfileEventSubsTable 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ProfileEventSubsTable(
              IN_OUT x_IFX_VMAPI_ProfileEventSubsTable *pxProfileEventSubsTable,
              IN uint32 uiFlags)
{
  /* Object Id IFX_VMAPI_OBJ_PROFEVENT */
  uint32 iCpeId, iCpeIdProf;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxProfileEventSubsTable->iid.config_owner != IFX_TR69) {
					
    x_IFX_VMAPI_VoiceProfile xVoiceProf;
    /* Assign the ProfileId of the ProfileEventSubstable object to VoiceProfile object */
    xVoiceProf.ucProfileId = pxProfileEventSubsTable->ucProfileId;
    /* Get the CpeId of the Parent Object VoiceProfile */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,&xVoiceProf,&iCpeIdProf);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",xVoiceProf.ucProfileId,&iCpeIdProf);

	  sprintf(pxProfileEventSubsTable->iid.pcpeId.secName, "%s", "VoiceProfile");
	  pxProfileEventSubsTable->iid.pcpeId.Id = iCpeIdProf;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_EVENT_SUBSCR,pxProfileEventSubsTable,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("ProfileEvent_CpeId",pxProfileEventSubsTable->ucProfileId,&iCpeId);
    pxProfileEventSubsTable->iid.cpeId.Id = iCpeId;
	}
	
  pxProfileEventSubsTable->pxEventSubscribe=NULL;

  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PROFEVENT,
                                       &pxProfileEventSubsTable->iid,
                                       pxProfileEventSubsTable,
                                       uiFlags);
}

/******************************************************************************
*  Function Name  : ifx_set_ProfileEventSubsTable
*  Description    : Set api to get ProfileEventSubsTable object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxProfileEventSubsTable - Pointer to the object to be set
*  Output Values  : pxProfileEventSubsTable - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ProfileEventSubsTable(IN uint32  uiOperation,
							                      IN  x_IFX_VMAPI_ProfileEventSubsTable *pxProfileEventSubsTable,
														        IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxProfileEventSubsTable);
	
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxProfileEventSubsTable->iid.config_owner);
	sprintf(pxProfileEventSubsTable->iid.pcpeId.secName, "%s", "VoiceProfile");

	return LTQ_set_VoipProfileObject(uiOperation,
																		pxProfileEventSubsTable,
																		IFX_VMAPI_VP_EVENT_SUBSCR,
																		IFX_VMAPI_OBJ_PROFEVENT,
																		uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_CallBlock
*  Description    : Get api to get Call Block object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCallBlk - pointer to Call Block 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CallBlock(
              IN_OUT x_IFX_VMAPI_CallBlock *pxCallBlk,
              IN uint32 uiFlags)
{
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	pxCallBlk->iid.cpeId.Id = 1;
	pxCallBlk->iid.pcpeId.Id = 1;
  pxCallBlk->pxCallBlockList=NULL;
 /* Object Id IFX_VMAPI_OBJ_CALLBK */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CALLBK,
                                       &pxCallBlk->iid,
                                       pxCallBlk,
                                       uiFlags);
}

/******************************************************************************
*  Function Name  : ifx_set_CallBlock
*  Description    : Set api to get CallBlock object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxCallBlk - Pointer to the object to be set
*  Output Values  : pxCallBlk - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CallBlock(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CallBlock *pxCallBlk,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	IFX_VALIDATE_PTR(pxCallBlk);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxCallBlk->iid.config_owner);
	
	pxCallBlk->iid.cpeId.Id = 1;
	pxCallBlk->iid.pcpeId.Id = 1;
	return LTQ_set_VoipSystemObject( uiOperation,
																	pxCallBlk,
																	IFX_VMAPI_VS_CALL_BLOCK,
																	IFX_VMAPI_OBJ_CALLBK,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_CallBlockEntry
*  Description    : Get api to get Call Block object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCallBlk - pointer to Call Block 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CallBlockEntry(
              IN_OUT x_IFX_VMAPI_CallBlockEntry *pxCallBlkEntry,
              IN uint32 uiFlags)
{
  uint32 iCpeId;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function\n");
   /* Get the CPE Id of the corresponding AuthCfg and assign it */
   //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VS_CALL_BLOCK_ENTRY,pxCallBlkEntry,&iCpeId);
   IFX_VMAPI_Get_CpeId_opt("CallBlockEntry_CpeId",pxCallBlkEntry->ucIndex,&iCpeId);
   pxCallBlkEntry->iid.cpeId.Id = iCpeId;
   pxCallBlkEntry->iid.pcpeId.Id = 1;


 /* Object Id IFX_VMAPI_OBJ_CALLBK_ENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CALLBK_ENTRY,
                                       &pxCallBlkEntry->iid,
                                       pxCallBlkEntry,
                                       uiFlags);
}

/******************************************************************************
*  Function Name  : ifx_set_CallBlockEntry
*  Description    : Set api to get CallBlock object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxCallBlkEntry - Pointer to the object to be set
*  Output Values  : pxCallBlkEntry - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CallBlockEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CallBlockEntry *pxCallBlkEntry,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxCallBlkEntry);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxCallBlkEntry->iid.config_owner);
	sprintf(pxCallBlkEntry->iid.pcpeId.secName, "%s", "CallBlock");

	return LTQ_set_VoipSystemObject(uiOperation,
																	pxCallBlkEntry,
																	IFX_VMAPI_VS_CALL_BLOCK_ENTRY,
																	IFX_VMAPI_OBJ_CALLBK_ENTRY,  
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_LineSignaling
*  Description    : Get api to get LineSignaling object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineSignaling - pointer to LineSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineSignaling (IN_OUT  x_IFX_VMAPI_LineSignaling  *pxLineSignaling,
                       IN   uint32  uiInFlag)
{
  
  uint32 uiCpeId, uiCpeIdLine;
	uchar8 ucProfCpeId =0,ucLine=0;
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxLineSignaling->iid.config_owner != IFX_TR69) {//Web users
					
    /* Get the CpeId of the Parent Object VoiceLine */
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxLineSignaling->ucLineId,&uiCpeIdLine);

	  sprintf(pxLineSignaling->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxLineSignaling->iid.pcpeId.Id = uiCpeIdLine;
    IFX_VMAPI_Get_CpeId_opt("VoiceLineSignaling_CpeId",pxLineSignaling->ucLineId,&uiCpeId);
    pxLineSignaling->iid.cpeId.Id = uiCpeId;
    IFX_VMAPI_Get_LinePcpeId(pxLineSignaling->ucLineId, &ucProfCpeId);
	}
  else{//TR69
    IFX_VMAPI_GetLineIdFromCpeId(pxLineSignaling->iid.pcpeId.Id, &ucLine);
	  pxLineSignaling->ucLineId = ucLine;
    
    IFX_VMAPI_Get_LinePcpeId(pxLineSignaling->ucLineId, &ucProfCpeId);
  }
	
  pxLineSignaling->pxAuthCfg = NULL;

  /* Object id IFX_VMAPI_OBJ_VL_SIGNALING   */
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VL_SIGNALING,
                                       &pxLineSignaling->iid,
                                       pxLineSignaling,
                                       uiInFlag)==IFX_VMAPI_SUCCESS)
	{
		pxLineSignaling->ucProfileId = ucProfCpeId;
		return IFX_VMAPI_SUCCESS;
	}
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_LineSignaling
*  Description    : Set api to set LineSignaling object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineSignaling - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineSignaling(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_LineSignaling *pxLineSignaling,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
							/* Validate the paramters :: make sure that pointers and flags are proper */
              IFX_VALIDATE_PTR(pxLineSignaling);
              CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineSignaling->iid.config_owner);
							sprintf(pxLineSignaling->iid.pcpeId.secName, "%s", "VoiceLine");
	return LTQ_set_VoiceLineObject(uiOperation,
						                     pxLineSignaling,
												         IFX_VMAPI_VL_SIGNALING,
						                     IFX_VMAPI_OBJ_VL_SIGNALING,
												         uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_LineCallingFeatures
*  Description    : Get api to get LineCallingFeatures object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineCallingFeatures - pointer to LineCallingFeatures 
*                    object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineCallingFeatures(
                IN_OUT x_IFX_VMAPI_LineCallingFeatures *pxLineCallingFeatures,
                IN uint32  uiInFlag)
{
 
  /* Object Id IFX_VMAPI_OBJ_VL_CALLFEAT */
  uint32 uiCpeId,uiCpeIdLine;
	uchar8 ucProfCpeId=0;
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function\n");

	if(pxLineCallingFeatures->iid.config_owner != IFX_TR69) {
					
    /* Get the CpeId of the Parent Object VoiceLine */
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxLineCallingFeatures->ucLineId,&uiCpeIdLine);

	  sprintf(pxLineCallingFeatures->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxLineCallingFeatures->iid.pcpeId.Id = uiCpeIdLine;
	
    IFX_VMAPI_Get_CpeId_opt("VoiceLineCallFeat_CpeId",pxLineCallingFeatures->ucLineId,&uiCpeId);
    pxLineCallingFeatures->iid.cpeId.Id = uiCpeId;
    IFX_VMAPI_Get_LinePcpeId(pxLineCallingFeatures->ucLineId, &ucProfCpeId);
	}

	
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VL_CALLFEAT,
                                   &pxLineCallingFeatures->iid,
                                   pxLineCallingFeatures,
                                   uiInFlag)== IFX_VMAPI_SUCCESS)
	{
		pxLineCallingFeatures->ucProfileId = ucProfCpeId;
		return IFX_VMAPI_SUCCESS;
	}
  return IFX_VMAPI_FAIL;  

}

/******************************************************************************
*  Function Name  : ifx_set_LineCallingFeatures
*  Description    : Set api to set Line Calling features, like call waiting, 
*                   DND, etc...
*  Input Values   : uiOperation - Gives Operation to be performed
*                   pxLineCallingFeatures- Pointer to the 
*                       x_IFX_VMAPI_LineCallingFeatures object to be set
*                   uiInFlag - Input flags
*  Output Values  : None
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_set_LineCallingFeatures(IN  uint32 uiOperation,
                       IN x_IFX_VMAPI_LineCallingFeatures  *pxLineCallingFeatures,
                       IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
		IFX_VALIDATE_PTR(pxLineCallingFeatures);
		
		CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineCallingFeatures->iid.config_owner);
		sprintf(pxLineCallingFeatures->iid.pcpeId.secName, "%s", "VoiceLine");
		return LTQ_set_VoiceLineObject(uiOperation,
																		pxLineCallingFeatures,
																		IFX_VMAPI_VL_CALLFEAT,
																		IFX_VMAPI_OBJ_VL_CALLFEAT,
																		uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_LineVoiceSession
*  Description    : Get api to get LineVoiceSession object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineVoiceSession - pointer to LineVoiceSession object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineVoiceSession(IN_OUT  x_IFX_VMAPI_LineSession  *pxLineVoiceSession,
                      IN uint32  uiInFlag)
{
  uint32 iCpeId, iCpeIdLine;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");

	if(pxLineVoiceSession->iid.config_owner != IFX_TR69) {
    /* Get the CpeId of the Parent Object VoiceLine */
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxLineVoiceSession->ucLineId,&iCpeIdLine);

	  sprintf(pxLineVoiceSession->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxLineVoiceSession->iid.pcpeId.Id = iCpeIdLine;
    IFX_VMAPI_Get_CpeId_opt("VoiceLineSession_CpeId",pxLineVoiceSession->ucLineId,&iCpeId);
    printf("CpeId is : %d", iCpeId);
    pxLineVoiceSession->iid.cpeId.Id = iCpeId;
	}

  /* Object Code IFX_VMAPI_OBJ_VL_VOICE_SESSION */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VL_VOICE_SESSION,
                                        &pxLineVoiceSession->iid,
                                        pxLineVoiceSession,
                                        uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_LineVoiceSession
*  Description    : Set api to set LineVoiceSession object
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineVoiceSession - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineVoiceSession (IN  uint32  uiOperation,
                   IN  x_IFX_VMAPI_LineSession  *pxLineVoiceSession,
                   IN  uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxLineVoiceSession);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineVoiceSession->iid.config_owner);
	sprintf(pxLineVoiceSession->iid.pcpeId.secName, "%s", "VoiceLine");
	
	return LTQ_set_VoiceLineObject(uiOperation,
																pxLineVoiceSession,
																IFX_VMAPI_VL_VOICE_SESSION,
																IFX_VMAPI_OBJ_VL_VOICE_SESSION,
																uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_LineVoiceProcessing
*  Description    : Get api to get ProfileSignaling object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineVoiceProcessing - pointer to LineVoiceProcessing
*                    object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineVoiceProcessing(
            IN_OUT  x_IFX_VMAPI_LineVoiceProcessing  *pxLineVoiceProcessing,
             IN uint32  uiInFlag)
{
  uint32 iCpeId, iCpeIdLine;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");

	if(pxLineVoiceProcessing->iid.config_owner != IFX_TR69) {
	
    /* Get the CpeId of the Parent Object VoiceLine */
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxLineVoiceProcessing->ucLineId,&iCpeIdLine);
	  sprintf(pxLineVoiceProcessing->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxLineVoiceProcessing->iid.pcpeId.Id = iCpeIdLine;
    IFX_VMAPI_Get_CpeId_opt("VoiceLineVoiceProcessing_CpeId",pxLineVoiceProcessing->ucLineId,&iCpeId);
    pxLineVoiceProcessing->iid.cpeId.Id = iCpeId;
	}

  /* Object Id IFX_VMAPI_OBJ_VL_VOICE_PROCESSING */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VL_VOICE_PROCESSING,
                                       &pxLineVoiceProcessing->iid,
                                       pxLineVoiceProcessing,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_set_LineVoiceProcessing
*  Description    : Set api to set LineVoiceProcessing object
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineVoiceProcessing - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineVoiceProcessing (IN  uint32  uiOperation,
                   IN  x_IFX_VMAPI_LineVoiceProcessing  *pxLineVoiceProcessing,
                   IN  uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxLineVoiceProcessing);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineVoiceProcessing->iid.config_owner);
	sprintf(pxLineVoiceProcessing->iid.pcpeId.secName, "%s", "VoiceLine");

	return LTQ_set_VoiceLineObject(uiOperation,
																	pxLineVoiceProcessing,
																	IFX_VMAPI_VL_VOICE_PROCESSING,
																	IFX_VMAPI_OBJ_VL_VOICE_PROCESSING,
																	uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_LineVoiceCodec
*  Description    : Get api to get LineVoiceCodec object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineVoiceCodec - pointer to LineVoiceCodec object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineVoiceCodec(IN_OUT  x_IFX_VMAPI_LineCodec  *pxLineVoiceCodec,
                       IN uint32  uiInFlag)
{
  uint32 iCpeId, iCpeIdLine;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");

	if(pxLineVoiceCodec->iid.config_owner != IFX_TR69) {
    /* Get the CpeId of the Parent Object VoiceLine */
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxLineVoiceCodec->ucLineId,&iCpeIdLine);

	  sprintf(pxLineVoiceCodec->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxLineVoiceCodec->iid.pcpeId.Id = iCpeIdLine;
    IFX_VMAPI_Get_CpeId_opt("VoiceLineVoiceCodec_CpeId",pxLineVoiceCodec->ucLineId,&iCpeId);
    pxLineVoiceCodec->iid.cpeId.Id = iCpeId;
	}

  /* Object Id IFX_VMAPI_OBJ_VL_VOICE_CODEC */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VL_VOICE_CODEC,
                                       &pxLineVoiceCodec->iid,
                                       pxLineVoiceCodec,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_LineVoiceCodec
*  Description    : Set api to set LineVoiceCodec object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineVoiceCodec - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineVoiceCodec (IN  uint32  uiOperation,
                         IN  x_IFX_VMAPI_LineCodec  *pxLineVoiceCodec,
                         IN  uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxLineVoiceCodec);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineVoiceCodec->iid.config_owner);
	
	sprintf(pxLineVoiceCodec->iid.pcpeId.secName, "%s", "VoiceLineVoiceCodec");
	return LTQ_set_VoiceLineObject(uiOperation,
																	pxLineVoiceCodec,
						                      IFX_VMAPI_VL_VOICE_CODEC,
												          IFX_VMAPI_OBJ_VL_VOICE_CODEC,
																  uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_LineCodecList_All
*  Description    : Get api to get LineCodecList objects for a given profile.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCodecList - pointer to LineCodecList objects. 
*                   uiInFlag - Input flags
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineCodecList_All(IN_OUT x_IFX_VMAPI_LineCodecList *pxCodecList,
                            IN uint32 uiInFlag)
{
  uint32 iCpeId,iCpeIdLine;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");
	if(pxCodecList->iid.config_owner != IFX_TR69) {
					
    /* Get the CpeId of the Parent Object VoiceLine */
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxCodecList->ucLineId,&iCpeIdLine);

	  sprintf(pxCodecList->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxCodecList->iid.pcpeId.Id = iCpeIdLine;
    IFX_VMAPI_Get_CpeId_opt("LineCodecList_CpeId",pxCodecList->ucLineId,&iCpeId);
    pxCodecList->iid.cpeId.Id = iCpeId;
	}
	
  pxCodecList->pxCodecList = NULL;

  /* Object Id IFX_VMAPI_OBJ_VL_CODECLIST */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_VL_CODECLIST,
                                       &pxCodecList->iid,
                                       pxCodecList,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_LineCodecList
*  Description    : Get api to get LineCodecList objects for a given profile.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCodecList - pointer to LineCodecList objects. 
*                   uiInFlag - Input flags
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineCodecList(IN_OUT x_IFX_VMAPI_LineCodecList *pxCodecList,
                            IN uint32 uiInFlag)
{
	x_IFX_VMAPI_LineCodecList xLCList;
  x_IFX_VMAPI_CodecDesc *pxTemp;
  x_IFX_VMAPI_CodecDesc *pxCurr,*pxPrev;
  x_IFX_VMAPI_CodecDesc *pxLocal;
	int32 uiErr;
	
	memset(&xLCList,0,sizeof(xLCList));

	if(pxCodecList->iid.config_owner != IFX_TR69) {
		xLCList.ucLineId = pxCodecList->ucLineId;
	}
	else
	{
		xLCList.iid.cpeId.Id = pxCodecList->iid.cpeId.Id;
		xLCList.iid.pcpeId.Id = pxCodecList->iid.pcpeId.Id;
	}

	xLCList.iid.config_owner = IFX_VOIP;
	if(IFX_VMAPI_SUCCESS != ifx_get_LineCodecList_All(&xLCList,IFX_F_DEFAULT))
	{
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				"Failed to get the full Line Codec List !!\n\n");
		return IFX_VMAPI_FAIL;
	}

	pxCodecList->uiNumCodecs = xLCList.uiNumCodecs;
	pxCodecList->uiPrefG723Codec = xLCList.uiPrefG723Codec;

	pxTemp = xLCList.pxCodecList;
	while(pxTemp !=NULL)
  {
		if(pxTemp->bEnable == IFX_TRUE)
		{			
			pxPrev=NULL;
			pxCurr= pxCodecList->pxCodecList;
			if(pxCurr==NULL){
    		__ifx_list_add_to_tail((void *)&pxCodecList->pxCodecList,
       		                     (void *)&pxLocal,
         		                   sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
			  /* Copy the content in the new location */
					if(pxLocal != NULL)
				  memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
			}
			else{
			  while(pxCurr != NULL)
			  {
				  if(pxCurr->ucPriority > pxTemp->ucPriority)
				  {
						if(pxPrev == NULL){
					    /* Allocates a memory of x_IFX_VMAPI_CodecDesc type and add to the linked list */
      		    __ifx_list_add_first((void *)&pxCodecList->pxCodecList,
        		                       (void *)&pxLocal,
          		                     sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
					    /* Copy the content in the new location */
					if(pxLocal != NULL)
					    memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
						}
			      else{
					    /* Allocates a memory of x_IFX_VMAPI_CodecDesc type and add to the linked list */
      		    __ifx_list_add_front((void *)&pxPrev,
        		                       (void *)&pxLocal,
          		                     sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
					    /* Copy the content in the new location */
					    if(pxLocal != NULL)
							memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
						}
						break;
				  }
				  else{
				    pxPrev = pxCurr;				
					  __ifx_list_GetNext((void *)&pxCurr);
         		if(pxCurr==NULL){
    		      __ifx_list_add_to_tail((void *)&pxCodecList->pxCodecList,
       		                           (void *)&pxLocal,
         		                         sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
			        /* Copy the content in the new location */
					    if(pxLocal != NULL)
			        memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
			      }
				  }
			  }
			}
		}
    __ifx_list_GetNext((void *)&pxTemp);
  }
	ifx_vmapi_freeObjectList(&xLCList,IFX_VMAPI_VL_CODECLIST);	
	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_set_LineCodecList
*  Description    : Set api to set LineCodecList object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxCodecList - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineCodecList(IN uint32  uiOperation,
                       IN  x_IFX_VMAPI_LineCodecList *pxCodecList,
                       IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");

/* Validate the paramters :: make sure that pointers and flags are proper */
		IFX_VALIDATE_PTR(pxCodecList);
		CHECK_ACS_SESSION_OWNER_COMBINATION(pxCodecList->iid.config_owner);
		
		sprintf(pxCodecList->iid.pcpeId.secName, "%s", "VoiceLine");
		return LTQ_set_VoiceLineObject(uiOperation,
								                   pxCodecList,
															     IFX_VMAPI_VL_CODECLIST,
							                     IFX_VMAPI_OBJ_VL_CODECLIST,
												 	         uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_CodecDesc
*  Description    : Get api to get CodecDesc objects for a given profile.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCodecList - pointer to CodecDesc objects. 
*                   uiInFlag - Input flags
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CodecDesc(IN_OUT x_IFX_VMAPI_CodecDesc *pxCodecDesc,
                            IN uint32 uiInFlag)
{
  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");

	if(pxCodecDesc->iid.config_owner != IFX_TR69) {
    IFX_VMAPI_Get_CpeId_opt("List_CpeId",(((pxCodecDesc->ucLineId-1)*IFX_VMAPI_MAX_CODECS)+pxCodecDesc->ucIndex),&iCpeId);
    pxCodecDesc->iid.cpeId.Id = iCpeId;
	}

  /* Object Id IFX_VMAPI_OBJ_CODEC_DESC */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_CODEC_DESC,
                                       &pxCodecDesc->iid,
                                       pxCodecDesc,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_CodecDesc
*  Description    : Set api to set CodecDesc object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxCodecDesc - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CodecDesc(IN uint32  uiOperation,
                       IN  x_IFX_VMAPI_CodecDesc *pxCodecDesc,
                       IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");

/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxCodecDesc);

	CHECK_ACS_SESSION_OWNER_COMBINATION(pxCodecDesc->iid.config_owner);
	
	sprintf(pxCodecDesc->iid.pcpeId.secName, "%s", "VoiceLineVoiceCodec");
	return LTQ_set_VoiceLineObject(uiOperation,
						                     pxCodecDesc,
												         IFX_VMAPI_VL_CODECLIST_ENTRY,
						                     IFX_VMAPI_OBJ_CODEC_DESC,
												         uiInFlag);
}



/*********************************************************/

/******************************************************************************
*  Function Name  : ifx_get_all_ProfileRspMapTable
*  Description    : Get api to get ProfileSignaling object.
*  Input Values   :
*                    uiInFlag - Input flags
*  Output Values  : pxProfileSignaling - pointer to ProfileSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_all_ProfileRspMapTable(
              OUT uint32 *puiNumEntries, 
              OUT x_IFX_VMAPI_ProfileRspMapTable **ppxProfileRspMapTable,
               IN uint32 uiInFlag)
{

  return IFX_VMAPI_SUCCESS;
}

int32 ifx_set_ProfileRspMapTable(
              IN uint32 uiOperation, 
              IN x_IFX_VMAPI_ProfileRspMapTable *pxProfileRspMapTable,
              IN uint32 uiInFlag)
{

  return IFX_VMAPI_SUCCESS;
}

/*********************************************************/

/*********************************************************/


/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaFax
*  Description    : Get api to get Fax T38 object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxFax - pointer to Fax object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_get_ProfileMediaFaxT38(IN x_IFX_VMAPI_FaxT38 *pxFax, 
               						 IN uint32 uiInFlag)
{
  uint32 iCpeId,iCpeIdProf;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxFax->iid.config_owner != IFX_TR69) {
  
		/* Assign the ProfileId of the ProfileMediaFax object to VoiceProfile object */
    xVoiceProf.ucProfileId = pxFax->ucProfileId;
    /* Get the CpeId of the Parent Object VoiceProfile */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE,&xVoiceProf,&iCpeIdProf);
    IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",xVoiceProf.ucProfileId,&iCpeIdProf);

	  sprintf(pxFax->iid.pcpeId.secName, "%s", "VoiceProfile");
	  pxFax->iid.pcpeId.Id = iCpeIdProf;

    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_FAX,pxFax,&iCpeId);
    IFX_VMAPI_Get_CpeId_opt("Fax_CpeId",pxFax->ucProfileId,&iCpeId);
    pxFax->iid.cpeId.Id = iCpeId;
    printf("Received CpeId: %d for Profile %d\n",iCpeId,pxFax->ucProfileId);
	}
 
  /* Object Id IFX_VMAPI_OBJ_FAX */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_FAX,
                                       &pxFax->iid,
                                       pxFax,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_ProfileMediaFax
*  Description    : Set api to set VoiceProfile object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxFax- Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ProfileMediaFaxT38(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_FaxT38 *pxFax,
                            IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxFax);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxFax->iid.config_owner);
	sprintf(pxFax->iid.pcpeId.secName, "%s", "VoiceProfile");
	return LTQ_set_VoipProfileObject(uiOperation,
                                   pxFax ,
                                   IFX_VMAPI_VP_FAX,
                                   IFX_VMAPI_OBJ_FAX,
                                   uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_DectInterface
*  Description    : Get api to get VoiceProfile object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxDectInf - pointer to Dect Interface object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_DectInterface(IN_OUT x_IFX_VMAPI_DectSystem *pxDectInf,
                           IN uint32 uiInFlag)
{
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Entering Function \n");

	pxDectInf->iid.cpeId.Id = 1;
	pxDectInf->iid.pcpeId.Id = 1;
  /* Object Id IFX_VMAPI_OBJ_DECT */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT,
                                       &pxDectInf->iid,
                                       pxDectInf,
                                       uiInFlag);
}

//#ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
/******************************************************************************
*  Function Name  : ifx_set_DectInterface
*  Description    : Set api to set VoiceProfile object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDectInf - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DectInterface(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_DectSystem *pxDectInf,
                            IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxDectInf);
	sprintf(pxDectInf->iid.pcpeId.secName, "%s", "Dect");

	return LTQ_set_DectObject(uiOperation,
			                      pxDectInf,
				                    IFX_VMAPI_DECT_SYSTEM,
					                  IFX_VMAPI_OBJ_DECT,
						                uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_DectHandset
*  Description    : Get api to get Dect Handset object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxDectHand - pointer to Dect Handset object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_DectHandset(IN_OUT x_IFX_VMAPI_DectHandset *pxDectHand,
                           IN uint32 uiInFlag)
{
  int32 index=0; 
  uchar8 pucDectLineIdList[20][20];
  uchar8 ucNoOfDectLineId;
  //char8  pDectLineIdString[20];
  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Entering Function \n");
	if(pxDectHand->iid.config_owner != IFX_TR69)  {
  	//IFX_VMAPI_Get_CpeId(IFX_VMAPI_PHY_IFACE_DECT,pxDectHand,&iCpeId);
  	IFX_VMAPI_Get_CpeId_opt("DectHandset_CpeId",(pxDectHand->xVoiceServPhyIf.ucInterfaceId-3),&iCpeId);
  	pxDectHand->iid.cpeId.Id = iCpeId;
  	pxDectHand->iid.pcpeId.Id = 1;
	}
	
  /* Object Id IFX_VMAPI_OBJ_VOICE_PROFILE */
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_HANDSET,
                                       &pxDectHand->iid,
                                       pxDectHand,
                                       uiInFlag)==IFX_VMAPI_SUCCESS)
  {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		   	"GET SUCCESS \n");

    memset(&pucDectLineIdList,0,sizeof(pucDectLineIdList));
    //strcpy(pDectLineIdString,pxDectHand->aucVoiceLineIdList);
    ifx_ParseCallBlockList (pxDectHand->aucVoiceLineIdList,&pucDectLineIdList[0][0],
                              &ucNoOfDectLineId); 
  
    memset(pxDectHand->aucVoiceLineIdList,0,sizeof(pxDectHand->aucVoiceLineIdList));
		for(index=0;index<ucNoOfDectLineId;index++)
    { 
      pxDectHand->aucVoiceLineIdList[index] = atoi((char8 *)pucDectLineIdList[index]);
    }
    return IFX_VMAPI_SUCCESS;
  }
  return IFX_VMAPI_FAIL;

}

/******************************************************************************
*  Function Name  : ifx_set_DectHandset
*  Description    : Set api to set DectHandset object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDectHand - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DectHandset(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_DectHandset *pxDectHand,
                            IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the pointer... */
	IFX_VALIDATE_PTR(pxDectHand);
	sprintf(pxDectHand->iid.pcpeId.secName, "%s", "Dect");

	return LTQ_set_DectObject(uiOperation,
		                        pxDectHand,
			                      IFX_VMAPI_PHY_IFACE_DECT,
				                    IFX_VMAPI_OBJ_DECT_HANDSET,
					                  uiInFlag);

}
#endif

/******************************************************************************
*  Function Name  : ifx_get_LineStats
*  Description    : Get api to get Line Statistics object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineStats - pointer to VoiceProfile object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_LineStats(IN_OUT  x_IFX_VMAPI_LineStats  *pxLineStats,
                  			IN uint32  uiInFlag)
{
	uint32 iCpeId, iCpeIdLine;
  x_IFX_VMAPI_VoiceLine xVoiceLine;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxLineStats->iid.config_owner != IFX_TR69) {
  /* Assign the LineId of the AuthCfg object to LineSignaling object */
		memset(&xVoiceLine,0,sizeof(xVoiceLine));
  	xVoiceLine.ucLineId = pxLineStats->ucLineId;
  	/* Get the CpeId of the Parent Object LineSignaling */
  	//IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine,&iCpeIdLine);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",xVoiceLine.ucLineId,&iCpeIdLine);

		sprintf(pxLineStats->iid.pcpeId.secName, "%s", "VoiceLine");
		pxLineStats->iid.pcpeId.Id = iCpeIdLine;
  	//IFX_VMAPI_Get_CpeId(IFX_VMAPI_VL_STATS,pxLineStats,&iCpeId);
  	IFX_VMAPI_Get_CpeId_opt("LineStats_CpeId",pxLineStats->ucLineId,&iCpeId);
  	pxLineStats->iid.cpeId.Id = iCpeId;
	}
	
  /* Object Id IFX_VMAPI_OBJ_LINE_STATS */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_LINE_STATS,
                                       &pxLineStats->iid,
                                       pxLineStats,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_LineStats
*  Description    : Set api to set Line Statistics object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineStats - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_LineStats(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_LineStats *pxLineStats,
                          IN uint32 uiInFlag)
{
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxLineStats);
	CHECK_ACS_SESSION_OWNER_COMBINATION(pxLineStats->iid.config_owner);
	
	sprintf(pxLineStats->iid.pcpeId.secName, "%s", "VoiceLine");
	return LTQ_set_VoiceLineObject(uiOperation,
																 pxLineStats,
																 IFX_VMAPI_VL_STATS,
																 IFX_VMAPI_OBJ_LINE_STATS,
																uiInFlag);

}

#ifdef LTAM
/******************************************************************************
*  Function Name  : ifx_get_PhyInterfaceTest
*  Description    : Get api to get Physical Interface Test object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxPhyIntTest - pointer to the object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PhyInterfaceTest(OUT x_IFX_VMAPI_VoiceServPhyIfTest *pxPhyIntTest,
                           IN uint32 uiInFlag)
{
	pxPhyIntTest->iid.cpeId.Id = 1;
	pxPhyIntTest->iid.pcpeId.Id = 1;
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_PHY_INT_TEST */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PHY_INT_TEST,
                                       &pxPhyIntTest->iid,
                                       pxPhyIntTest,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_PhyInterfaceTest
*  Description    : Set api to set GR909 Test config parameters.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxPhyIntTest - Pointer to the Physical Interface Test
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PhyInterfaceTest (IN uint32 uiOperation,
                         IN x_IFX_VMAPI_VoiceServPhyIfTest *pxPhyIntTest,
                         IN uint32 uiInFlag)
{
  IFX_ID iid;
  int32 iInstanceIndex = -1 ; 
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  uint32 uiObjectId = IFX_VMAPI_OBJ_PHY_INT_TEST; //this Object id.
  int32 ret = IFX_VMAPI_FAIL; /* return value */

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxPhyIntTest);
   
  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Operation is IFX_OP_DEL - Not Supported");
		    return IFX_VMAPI_FAIL;
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Operation is IFX_OP_MODIFY");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     "Operation is IFX_OP_ADD -- Not supported");
		return IFX_VMAPI_FAIL;
	}
  else {
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Operation Is Not Supported");
		return IFX_VMAPI_FAIL;
  }

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxPhyIntTest->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  
  IFX_VMAPI_LOCK(uiLock); 

  memset(&iid,0,sizeof(iid));    

	pxPhyIntTest->iid.cpeId.Id = 1;
	pxPhyIntTest->iid.pcpeId.Id = 1;

  IFX_VMAPI_STRCPY(pxPhyIntTest->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	sprintf(pxPhyIntTest->iid.pcpeId.secName, "%s", "PhyIntTest");
  iid = pxPhyIntTest->iid;
  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid\n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  } 

  /*** ID ALLOCATION BLOCK  ***/
  if (IFX_INT_ADD_F_SET(uiInFlag)) {
		if (ifx_get_IID(&iid, "TestType") != IFX_SUCCESS) {
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxPhyIntTest->iid = iid;
		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  }

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxPhyIntTest, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List \n");
		goto EndLabel;  
}

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 "Error : ifx_get_conf_index_and_nv_pairs failed \n");
		goto EndLabel;
  }
  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
#if 0
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						 "Error : Could Not Get Changed Field Names \n");
		goto EndLabel;   
 }
  }
#endif
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
		/* compare fvp array from structure with fvp array from file and build changed fvp */
		if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
						
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
				goto EndLabel;
			}
	}
  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, xNVList.axNameValue);
    pxList = &xNVList.axNameValue[0];
  }
  if (!uiChangedNvCount) {
   	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				 "Info : There Are No Changed/New-Object Fields To Be Added.\n");
	    goto EndLabel;  
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

  if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf)) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, 
												uiInFlag|!(IFX_F_DONT_CHECKPOINT) )) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Warning : Could Not Roll Back Config File \n");
      }
#endif
			goto EndLabel;
  }

  /*** Send Notification  ***/
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
    if (IFX_MODIFY_F_SET(uiInFlag)) { 
      if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_PHY_INT_TEST) == IFX_VMAPI_SUCCESS)
	    {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Sending The Notification\n");
        IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_PHY_INT_TEST,(void *)pxPhyIntTest,(void *)pxPhyIntTest);
	    }
	  }
	}/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */


  /* Update rc.conf for Indices Compaction for Add/Del op */
  if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                              IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                              uiInFlag) != IFX_SUCCESS) {
       /*  Now can not do anything...just continue */
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Warning : ifx_CompactCfgSection failed \n");
    }
  }

  /*** DEVICE CONFIGURATION BLOCK ***/
  /* Device configuration is not needed for this object */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
			 IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
  if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						 " Cannot write to the flash\n");
	}
#endif
	
  /*** NOTIFICATION BLOCK ***/
	if (IFX_VMAPI_CheckNSendNotification(&pxPhyIntTest->iid,
			(uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL)	? 0 : uiChangedNvCount,
			(uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL)	? NULL : pxList,
			 uiInFlag) != IFX_SUCCESS) {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 "Info : Notification is Failing\n");
		goto EndLabel;	
	}

	/*** EPILOG BLOCK ****/
	if (uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL) {
		if (IFX_VMAPI_UpdateMapNAttr(&pxPhyIntTest->iid,
				(uiOperation == IFX_OP_ADD) ? 0 : uiChangedNvCount,
				(uiOperation == IFX_OP_ADD) ? NULL : pxList, uiInFlag) !=  IFX_SUCCESS) {
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		"Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		}
	}

EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function\n");
  return ret;
}

/******************************************************************************
*  Function Name  : ifx_get_PhyInterfaceTestResult
*  Description    : Get api to get Physical Interface Test Result object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxPhyIntTestRes - pointer to the object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PhyInterfaceTestResult(OUT x_IFX_VMAPI_VoiceServTestResult *pxPhyIntTestRes,
                           IN uint32 uiInFlag)
{
	pxPhyIntTestRes->iid.cpeId.Id = 1;
	pxPhyIntTestRes->iid.pcpeId.Id = 1;
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_PHY_INT_TEST */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PHY_INT_TEST_RES,
                                       &pxPhyIntTestRes->iid,
                                       pxPhyIntTestRes,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_PhyInterfaceTestResult
*  Description    : Set api to set Physical Interface Test Result object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxPhyIntTestRes - Pointer to the Physical Interface Test
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PhyInterfaceTestResult (IN uint32 uiOperation,
                         IN x_IFX_VMAPI_VoiceServTestResult *pxPhyIntTestRes,
                         IN uint32 uiInFlag)
{
  IFX_ID iid;
  int32 iInstanceIndex = -1 ; 
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  uint32 uiObjectId = IFX_VMAPI_OBJ_PHY_INT_TEST_RES; //this Object id.
  int32 ret = IFX_VMAPI_FAIL; /* return value */

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxPhyIntTestRes);
   
  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Operation is IFX_OP_DEL - Not Supported");
		    return IFX_VMAPI_FAIL;
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Operation is IFX_OP_MODIFY");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     "Operation is IFX_OP_ADD -- Not supported");
		return IFX_VMAPI_FAIL;
	}
  else {
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Operation Is Not Supported");
		return IFX_VMAPI_FAIL;
  }

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxPhyIntTestRes->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  
  IFX_VMAPI_LOCK(uiLock); 

  memset(&iid,0,sizeof(iid));    

	pxPhyIntTestRes->iid.cpeId.Id = 1;
	pxPhyIntTestRes->iid.pcpeId.Id = 1;

  IFX_VMAPI_STRCPY(pxPhyIntTestRes->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	sprintf(pxPhyIntTestRes->iid.pcpeId.secName, "%s", "PhyIntTest");
  iid = pxPhyIntTestRes->iid;
  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid\n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  } 

  /*** ID ALLOCATION BLOCK  ***/
  if (IFX_INT_ADD_F_SET(uiInFlag)) {
		if (ifx_get_IID(&iid, "TestType") != IFX_SUCCESS) {
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxPhyIntTestRes->iid = iid;
		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  }

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxPhyIntTestRes, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List \n");
		goto EndLabel;  
}

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 "Error : ifx_get_conf_index_and_nv_pairs failed \n");
  	goto EndLabel;
	}
  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
#if 0
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						 "Error : Could Not Get Changed Field Names \n");
    	goto EndLabel;
		}
  }
#endif
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
		/* compare fvp array from structure with fvp array from file and build changed fvp */
		if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
						
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
				goto EndLabel;
			}
	}
  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, xNVList.axNameValue);
    pxList = &xNVList.axNameValue[0];
  }
  if (!uiChangedNvCount) {
   	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				 "Info : There Are No Changed/New-Object Fields To Be Added.\n");
	    goto EndLabel;  
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT 
	/* TODO: */
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  /* Backup rc.conf before proceeding with configuration */
  if ((ret = IFX_VMAPI_CheckPointRet((uiInFlag |!(IFX_F_DONT_CHECKPOINT)), 
       SYSTEM_CONF_FILE, CHKPOINT_FILE)) != IFX_SUCCESS) { /* Backup taken */
    goto EndLabel;
	}

  if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf)) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, 
												uiInFlag|!(IFX_F_DONT_CHECKPOINT) )) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Warning : Could Not Roll Back Config File \n");
      }
#endif
			goto EndLabel;
  }


  /* Update rc.conf for Indices Compaction for Add/Del op */
  if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                              IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                              uiInFlag) != IFX_SUCCESS) {
       /*  Now can not do anything...just continue */
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Warning : ifx_CompactCfgSection failed \n");
    }
  }

  /*** DEVICE CONFIGURATION BLOCK ***/
  /* Device configuration is not needed for this object */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
			 IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
  if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						 " Cannot write to the flash\n");
	}
#endif
	
  /*** NOTIFICATION BLOCK ***/
	if (IFX_VMAPI_CheckNSendNotification(&pxPhyIntTestRes->iid,
			(uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL)	? 0 : uiChangedNvCount,
			(uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL)	? NULL : pxList,
			 uiInFlag) != IFX_SUCCESS) {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 "Info : Notification is Failing\n");
		goto EndLabel;	
	}

	/*** EPILOG BLOCK ****/
	if (uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL) {
		if (IFX_VMAPI_UpdateMapNAttr(&pxPhyIntTestRes->iid,
				(uiOperation == IFX_OP_ADD) ? 0 : uiChangedNvCount,
				(uiOperation == IFX_OP_ADD) ? NULL : pxList, uiInFlag) !=  IFX_SUCCESS) {
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		"Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		}
	}

EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function\n");
  return ret;
}

#endif /* LTAM */

#if 1
/******************************************************************************
*  Function Name  : ifx_set_Tbr6Test
*  Description    : Set api to set TBR6 Test.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    ucStartStopTest - Start or Stop Test
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Tbr6Test (IN uint32 uiOperation,
                         IN uchar8 ucStartStopTest,
												 IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Entering Function \n");

  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Operation is IFX_OP_DEL - Not Supported");
		    return IFX_VMAPI_FAIL;
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Operation is IFX_OP_MODIFY");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     "Operation is IFX_OP_ADD -- Not supported");
		return IFX_VMAPI_FAIL;
	}
  else {
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Operation Is Not Supported");
		return IFX_VMAPI_FAIL;
  }


	

	if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  	if (IFX_MODIFY_F_SET(uiInFlag)) { 
//#ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
    	if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_TBR6_TEST) == IFX_VMAPI_SUCCESS) {
      	if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_TBR6_TEST) == IFX_VMAPI_SUCCESS)
	      {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Sending The Notification\n");
          IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_TBR6_TEST,(void *)&ucStartStopTest,NULL);
	      }
	    } /* IFX_VMAPI_IsObjectRegistered */
#endif
	  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
	}


  
  return IFX_VMAPI_SUCCESS;
}




#endif



#ifdef MESSAGE_SUPPORT
/******************************************************************************
*  Function Name  : ifx_get_MsgInbox
*  Description    : Api to get Message Inbox object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgIn- pointer to Message Inbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_MsgInbox (IN_OUT x_IFX_VMAPI_IN_Message  *pxMsgIn,
                        IN uint32 uiInFlag)
{
	int32 iRet=IFX_VMAPI_SUCCESS;
  uint32 uiCpeId,uiCpeIdLine;
	uchar8 ucProfCpeId=0;
  pxMsgIn->pxMsgEntries=NULL;
  
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	
	if(pxMsgIn->iid.config_owner != IFX_TR69) {
					
    x_IFX_VMAPI_VoiceLine xVoiceLine;
		memset(&xVoiceLine,0,sizeof(xVoiceLine));
    /* Assign the LineId of the Message Inbox object to VoiceLine object */
    xVoiceLine.ucLineId = pxMsgIn->ucLineId;
    /* Get the CpeId of the Parent Object VoiceLine */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine,&uiCpeIdLine);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",xVoiceLine.ucLineId,&iCpeIdLine);

	  sprintf(pxMsgIn->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxMsgIn->iid.pcpeId.Id = uiCpeIdLine;
	
    IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX,pxMsgIn,&uiCpeId);
    pxMsgIn->iid.cpeId.Id = uiCpeId;
    IFX_VMAPI_Get_LinePcpeId(pxMsgIn->ucLineId, &ucProfCpeId);
	}

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Get the whole Inbox \n");
  /* Object Id IFX_VMAPI_OBJ_MESSAGE_IN */
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_MESSAGE_IN,
                               &pxMsgIn->iid,
                               pxMsgIn,
                               uiInFlag)== IFX_VMAPI_SUCCESS)
	{
		pxMsgIn->ucProfileId = ucProfCpeId;
		return IFX_VMAPI_SUCCESS;
	}
	return IFX_VMAPI_FAIL;

}

/******************************************************************************
*  Function Name  : ifx_get_MsgInboxEntry
*  Description    : Get api to get Message Inbox Entry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAuthCfg - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_MsgInboxEntry (IN_OUT x_IFX_VMAPI_IN_MessageEntry *pxMsgInEntry,
                       			 IN uint32  uiInFlag)
{ 
  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxMsgInEntry->iid.config_owner != IFX_TR69) {
		pxMsgInEntry->ucIndex = (pxMsgInEntry->uiMsgHdl) & 0xFF;
		printf("<ifx_get_MsgInboxEntry>Index is %d\n",pxMsgInEntry->ucIndex);
    /* Get the CPE Id of the corresponding MsgInboxEntry and assign it */
    IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX_ENTRY,pxMsgInEntry,&iCpeId);
    pxMsgInEntry->iid.cpeId.Id = iCpeId;
	}

  /* Object id IFX_VMAPI_OBJ_MESSAGE_IN_ENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_MESSAGE_IN_ENTRY,
                                       &pxMsgInEntry->iid,
                                       pxMsgInEntry,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_MsgInbox
*  Description    : Set api to set LineSignaling object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxMsgIn - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_MsgInbox(IN uint32  uiOperation,
                    IN x_IFX_VMAPI_IN_Message* pxMsgIn,
                    IN uint32  uiInFlag)
{
	IFX_ID	iid, piid;
  int32 iInstanceIndex = -1 ; 
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdLine; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8  acSysCmdBuf[256];
  x_IFX_VMAPI_IN_MessageEntry *pxTemp;
  x_IFX_VMAPI_IN_Message xOldMsgIn;
	uchar8 ucLine;
  
  uint32 uiObjectId = IFX_VMAPI_OBJ_MESSAGE_IN; //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxMsgIn);
   
  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_DEL\n");
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_MODIFY\n");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_ADD\n");
	}
  else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Error : Operation Is Not Supported\n");
		return IFX_VMAPI_FAIL;
  }


  CHECK_ACS_SESSION_OWNER_COMBINATION(pxMsgIn->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

  //memset(&iid,0,sizeof(iid));    
	memset(&iid, 0x00, sizeof(iid));
	memset(&piid, 0x00, sizeof(piid));
	
  IFX_VMAPI_STRCPY(pxMsgIn->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	sprintf(pxMsgIn->iid.pcpeId.secName, "%s", "VoiceLine");

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxMsgIn->iid.config_owner == IFX_TR69)  {

    IFX_VMAPI_GetLineIdFromCpeId(pxMsgIn->iid.pcpeId.Id, &ucLine);
	  pxMsgIn->ucLineId = ucLine;
	}
  
	if ((pxMsgIn->iid.config_owner == IFX_WEB)||(pxMsgIn->iid.config_owner == IFX_VOIP))  {

		x_IFX_VMAPI_VoiceLine xVoiceLine;
    /* Assign the LineId of the MessageInbox object to the VoiceLine object */
    xVoiceLine.ucLineId = pxMsgIn->ucLineId;
    /* Get the CpeId of the Parent Object VoiceLine */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine,&iCpeIdLine);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",xVoiceLine.ucLineId,&iCpeIdLine);
	  pxMsgIn->iid.pcpeId.Id = iCpeIdLine;
	  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
		{
      IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX,pxMsgIn,&iCpeId);
      pxMsgIn->iid.cpeId.Id = iCpeId;
		}
  }

  iid = pxMsgIn->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    iid = pxMsgIn->iid;
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  }
	
  /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
	if (ifx_get_IID(&iid, NULL) != IFX_SUCCESS) {
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxMsgIn->iid = iid;
		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  IFX_VMAPI_LOCK(uiLock); 
  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxMsgIn, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List \n");
		goto EndLabel;  
}
  
  if(IFX_MODIFY_F_SET(uiInFlag) ) {

		/*GET the old MessageInbox parameter values */
		memset(&xOldMsgIn,0,sizeof(x_IFX_VMAPI_IN_Message));
	  xOldMsgIn.ucLineId = pxMsgIn->ucLineId;
	  //xOldLineSig.iid.pcpeId.Id = pxLineSignaling->iid.pcpeId.Id;
    xOldMsgIn.iid.config_owner = IFX_VOIP;//pxLineSignaling->iid.config_owner;
    if(ifx_get_MsgInbox(&xOldMsgIn,0)!=IFX_VMAPI_SUCCESS)
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Error : Get Failed For Line Signaling");
			goto EndLabel;
    }
#if 0
    /* Set should happen for AuthCfg list */
    pxTemp = pxMsgIn->pxMsgEntries;
    //pxTemp = xOldLineSig.pxAuthCfg;
    pxMsgIn->ucNoOfEntries = 0;
    while(pxTemp !=NULL)
    {
      pxTemp->ucLineId = pxMsgIn->ucLineId;
      //pxTemp->iid.cpeId.Id =pxLineSignaling->ucNoOfSipAuthCfg+1;
			//printf("\n====cPeId=%d pcpeId=%d======\n",pxTemp->iid.cpeId.Id,pxTemp->iid.pcpeId.Id);
      pxTemp->iid.config_owner = pxMsgIn->iid.config_owner;
      ifx_set_MsgInboxEntry(IFX_OP_MOD,pxTemp,0);
      pxMsgIn->ucNoOfEntries++;
      __ifx_list_GetNext((void **)&pxTemp);
    }
#endif
  }

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : ifx_get_conf_index_and_nv_pairs failed \n");
		goto EndLabel;  
}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
                                        
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
    	goto EndLabel;
		}
  }
  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 				"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
	  /* Check If the Object is Registered or not */
    if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_MSG_INBOX) == IFX_VMAPI_SUCCESS)
	  {
		  /*GET the old MessageInbox parameter values */
		  memset(&xOldMsgIn,0,sizeof(x_IFX_VMAPI_IN_Message));
	    xOldMsgIn.ucLineId = pxMsgIn->ucLineId;
	    xOldMsgIn.iid.pcpeId.Id = pxMsgIn->iid.pcpeId.Id;
      xOldMsgIn.iid.config_owner = IFX_VOIP;
      if(ifx_get_MsgInbox(&xOldMsgIn,0)!=IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Error : Get Failed For Line Signaling");
      }

  	  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	    "Object is Registered\n ");
	  }
	  else
	  {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Error : Object Not Registered\n");
	  }
	}
	}/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */


  /* Backup rc.conf before proceeding with configuration */
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      } 
#endif
			goto EndLabel;
    } else {
       
			  /*** Send Notification  ***/
        if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
          if (IFX_MODIFY_F_SET(uiInFlag)) { 
            if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_MSG_INBOX) == IFX_VMAPI_SUCCESS)
	          {
              IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Sending The Notification\n");
              IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_MSG_INBOX,(void *)&xOldMsgIn,(void *)pxMsgIn);
	          }
	        }
	      }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */

        /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							 "Warning : ifx_CompactCfgSection failed \n");
          }
        }

				if (IFX_INT_ADD_F_SET(uiInFlag)) {
           //IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_INBOX, pxMsgIn,pxMsgIn->iid.cpeId.Id);
           IFX_VMAPI_Update_CpeId_opt("MsgIn_CpeId", pxMsgIn->ucLineId,pxMsgIn->iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
           /* Update the CpeId corresponding to the Line Id */
           //IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_INBOX, pxMsgIn,0);
           IFX_VMAPI_Update_CpeId_opt("MsgIn_CpeId", pxMsgIn->ucLineId,0);
        }
				
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			  			 " Cannot write to the flash\n");
	      }
#endif
			 

				if (IFX_MODIFY_F_SET(uiInFlag)) { 
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgIn->iid,uiChangedNvCount,
				          									pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		             "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
        }

	      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgIn->iid,uiChangedNvCount,
					       									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
 		
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgIn->iid,uiChangedNvCount,
					        								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
	      }

        if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgIn->iid,uiChangedNvCount,
					       								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }

          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgIn->iid,uiChangedNvCount,
					     									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
        } 

    }

  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function \n");
  return ret;
}

/******************************************************************************
*  Function Name  : ifx_set_MsgInboxEntry
*  Description    : Set api to set Message Inbox Entrty object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxMsgInEntry - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_MsgInboxEntry(IN uint32 uiOperation,
                      IN x_IFX_VMAPI_IN_MessageEntry *pxMsgInEntry,
                      IN uint32  uiInFlag)
{
  IFX_ID iid;
  int32 iInstanceIndex = -1 ; 
  
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdCodec; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8  acSysCmdBuf[256];
	uchar8 ucLine;
  
	x_IFX_VMAPI_IN_Message xMsgIn ;
	uint32 uiMsgHdl =0;

  uint32 uiObjectId = IFX_VMAPI_OBJ_MESSAGE_IN_ENTRY; //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxMsgInEntry);
   
  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_DEL\n");
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_MODIFY\n");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_ADD\n");
	}
  else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Error : Operation Is Not Supported\n");
		return IFX_VMAPI_FAIL;
  }

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxMsgInEntry->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

	/* Create MsgHdl for the new message */
	if(IFX_INT_ADD_F_SET(uiInFlag) ) 
	{
		memset(&xMsgIn,0,sizeof(xMsgIn));
		xMsgIn.ucLineId = pxMsgInEntry->ucLineId ;
		xMsgIn.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != ifx_get_MsgInbox(&xMsgIn,0))
		{
	  	return IFX_FAILURE;
		}
		pxMsgInEntry->ucIndex = xMsgIn.ucNoOfEntries+1;
		ifx_vmapi_freeObjectList(&xMsgIn, IFX_VMAPI_MSG_INBOX);
		/* Create a new Handle */
		uiMsgHdl = pxMsgInEntry->ucIndex;
		uiMsgHdl = uiMsgHdl | (pxMsgInEntry->ucLineId)<<8;
		uiMsgHdl = uiMsgHdl | IFX_VMAPI_MSG_IN<<16; /* For Inbox entry */

		pxMsgInEntry->uiMsgHdl = uiMsgHdl;
		printf("uiMsgHdl = %d\n",uiMsgHdl);
	}
	/* Extract the index from the MsgHdl */
	if(IFX_DELETE_F_SET(uiInFlag) ) 
	{
		pxMsgInEntry->ucIndex = (pxMsgInEntry->uiMsgHdl) & 0xFF;
		printf("MsgIndex for Delete: %d\n",pxMsgInEntry->ucIndex);
	}

	/* Delete All the entries if MsgIndex is 0.
	   Firstly delete all the entries of Message In Entry table.
	   Then change the number of entries of the parent object(MsgIn)
		 as 0 and the list as NULL. Set the object. */
  if((IFX_DELETE_F_SET(uiInFlag)) && (pxMsgInEntry->ucIndex == 0) ) 
	{
		x_IFX_VMAPI_IN_Message xMsgIn;
		int32 i=0;
    char8 s[] = "MsgInEntry_Count";
    char8 pcCont[20] = {0};
    sprintf(&pcCont[0],"%s=\"%d\"\n",s,0);
	
		memset(&xMsgIn,0,sizeof(xMsgIn));
  	xMsgIn.ucLineId = pxMsgInEntry->ucLineId;
  	xMsgIn.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgInbox(&xMsgIn,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}
		ifx_vmapi_freeObjectList(&xMsgIn, IFX_VMAPI_MSG_INBOX);

		for(i=0;i<xMsgIn.ucNoOfEntries;i++)
		{
			pxMsgInEntry->ucIndex = 1;
    	//IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_INBOX_ENTRY, pxMsgInEntry,0);
    	IFX_VMAPI_Update_CpeId_opt("MsgInEntry_CpeId",
                                 (((pxMsgInEntry->ucLineId-1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+pxMsgInEntry->ucIndex),0);
		}
		xMsgIn.pxMsgEntries = NULL;
		xMsgIn.ucNoOfEntries = 0;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgInbox(IFX_OP_MOD,&xMsgIn,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}

    if (ifx_SetObjData(SYSTEM_CONF_FILE,
                    "MsgInEntry",
                    IFX_F_DEFAULT,
                    1,
                    (char8*)pcCont) != IFX_SUCCESS)  {
						
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			   "Error : Could not SET the MsgInEntry  \n");
		}
		
    return IFX_VMAPI_SUCCESS;
	}

  memset(&iid,0,sizeof(iid));   

  /* Configuring the CpeId */
  IFX_VMAPI_STRCPY(pxMsgInEntry->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	sprintf(pxMsgInEntry->iid.pcpeId.secName, "%s", "MsgIn");

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxMsgInEntry->iid.config_owner == IFX_TR69)  {

    IFX_VMAPI_GetLineIdFromCpeId(pxMsgInEntry->iid.pcpeId.Id, &ucLine);
	  pxMsgInEntry->ucLineId = ucLine;
		//printf("[%s %d] lineId %d\n",__FUNCTION__, __LINE__, ucLine);
	}
  
	if((pxMsgInEntry->iid.config_owner == IFX_WEB)||(pxMsgInEntry->iid.config_owner == IFX_VOIP))  {
	
		/*  Configuring the parent */
    x_IFX_VMAPI_IN_Message xMsgIn = {'\0'};
    /* Assign the LineId of the MsgInboxEntry object to MsgInbox object */
    xMsgIn.ucLineId = pxMsgInEntry->ucLineId;
    /* Get the CpeId of the Parent Object LineCodecList */
    IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX,&xMsgIn,&iCpeIdCodec);
	  pxMsgInEntry->iid.pcpeId.Id = iCpeIdCodec;
		//printf("[%s %d] PCpeId %d\n",__FUNCTION__, __LINE__, iCpeIdCodec);

	  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
		{
      IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX_ENTRY,pxMsgInEntry,&iCpeId);
      pxMsgInEntry->iid.cpeId.Id = iCpeId;
		}
		
  }
  
  iid =pxMsgInEntry->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    iid = pxMsgInEntry->iid;
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  } 
  /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
    if (ifx_get_IID(&iid, "MsgHdl") != IFX_SUCCESS) {
      	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  			"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxMsgInEntry->iid = iid;

		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  }
  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  
  IFX_VMAPI_LOCK(uiLock); 

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxMsgInEntry, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get NV List \n");
  	goto EndLabel;
	}

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : ifx_get_conf_index_and_nv_pairs failed \n");
		goto EndLabel;  
}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
                                        
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get Changed Field Names \n");
    		goto EndLabel;
		}
  }
  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 					"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
							
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Warning : Could Not Roll Back Config File \n");
      } 
#endif
			goto EndLabel;
    } else {
      /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 								"Warning : ifx_CompactCfgSection failed \n");
          }
        }

				/* Update the CpeId of that entry of the line */
        if (IFX_INT_ADD_F_SET(uiInFlag)) {
           /*IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_INBOX_ENTRY, 
													 pxMsgInEntry,pxMsgInEntry->iid.cpeId.Id);*/
           IFX_VMAPI_Update_CpeId_opt("MsgInEntry_CpeId", 
													            (((pxMsgInEntry->ucLineId-1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+pxMsgInEntry->ucIndex),
                                      pxMsgInEntry->iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
					if((pxMsgInEntry->iid.config_owner == IFX_WEB)||(pxMsgInEntry->iid.config_owner == IFX_VOIP))
		      {
            /* Update the CpeId corresponding to the Line Id */
            //IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_INBOX_ENTRY, pxMsgInEntry,0);
            IFX_VMAPI_Update_CpeId_opt("MsgInEntry_CpeId",(((pxMsgInEntry->ucLineId-1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+pxMsgInEntry->ucIndex),0);
          }
	        else
	        {
						if(IFX_VMAPI_ReplaceCpeId("MsgInEntry" , 
																	pxMsgInEntry->iid.cpeId.Id) !=IFX_VMAPI_SUCCESS)
						{
							//printf("[%s %d] Failed to Replace\n",__FUNCTION__, __LINE__);
						}
						else
						{
							printf("REPLACING SUCCESSFUL\n");
						}
	        }

        }
				
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			  			 " Cannot write to the flash\n");
	      }
#endif
 	

				if (IFX_MODIFY_F_SET(uiInFlag)) { 
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgInEntry->iid,uiChangedNvCount,
				          									pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		             "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
        }

	      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgInEntry->iid,uiChangedNvCount,
					       									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
 		
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgInEntry->iid,uiChangedNvCount,
					        								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
	      }

        if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgInEntry->iid,uiChangedNvCount,
					       								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }

          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgInEntry->iid,uiChangedNvCount,
					     									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
        } 
				
    }
  
  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "Leaving Function \n");
  return ret;
}

/******************************************************************************
*  Function Name  : ifx_get_MsgOutbox
*  Description    : Api to get Message Outbox object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgOut- pointer to Message Inbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_MsgOutbox (IN_OUT x_IFX_VMAPI_OUT_Message  *pxMsgOut,
                        IN uint32 uiInFlag)
{
	int32 iRet=IFX_VMAPI_SUCCESS;
  uint32 uiCpeId,uiCpeIdLine;
	uchar8 ucProfCpeId=0;
  pxMsgOut->pxMsgEntries=NULL;
  
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	
	if(pxMsgOut->iid.config_owner != IFX_TR69) {
					
    x_IFX_VMAPI_VoiceLine xVoiceLine;
		memset(&xVoiceLine,0,sizeof(xVoiceLine));
    /* Assign the LineId of the Message Inbox object to VoiceLine object */
    xVoiceLine.ucLineId = pxMsgOut->ucLineId;
    /* Get the CpeId of the Parent Object VoiceLine */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine,&uiCpeIdLine);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",xVoiceLine.ucLineId,&iCpeIdLine);

	  sprintf(pxMsgOut->iid.pcpeId.secName, "%s", "VoiceLine");
	  pxMsgOut->iid.pcpeId.Id = uiCpeIdLine;
	
    IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX,pxMsgOut,&uiCpeId);
    pxMsgOut->iid.cpeId.Id = uiCpeId;
    IFX_VMAPI_Get_LinePcpeId(pxMsgOut->ucLineId, &ucProfCpeId);
	}

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Get the whole Outbox \n");
  /* Object Id IFX_VMAPI_OBJ_MESSAGE_OUT */
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_MESSAGE_OUT,
                               &pxMsgOut->iid,
                               pxMsgOut,
                               uiInFlag)== IFX_VMAPI_SUCCESS)
	{
		pxMsgOut->ucProfileId = ucProfCpeId;
		return IFX_VMAPI_SUCCESS;
	}
	return IFX_VMAPI_FAIL;

}

/******************************************************************************
*  Function Name  : ifx_get_MsgOutboxEntry
*  Description    : Get api to get Message Outbox Entry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgOutEntry - pointer to Message Outbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_MsgOutboxEntry (IN_OUT x_IFX_VMAPI_IN_MessageEntry *pxMsgOutEntry,
                       			 IN uint32  uiInFlag)
{ 
  uint32 iCpeId;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	if(pxMsgOutEntry->iid.config_owner != IFX_TR69) {
		pxMsgOutEntry->ucIndex = (pxMsgOutEntry->uiMsgHdl) & 0xFF;
		printf("Index is %d\n",pxMsgOutEntry->ucIndex);
    /* Get the CPE Id of the corresponding MsgInboxEntry and assign it */
    IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_INBOX_ENTRY,pxMsgOutEntry,&iCpeId);
    pxMsgOutEntry->iid.cpeId.Id = iCpeId;
	}

  /* Object id IFX_VMAPI_OBJ_MESSAGE_OUT_ENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_MESSAGE_OUT_ENTRY,
                                       &pxMsgOutEntry->iid,
                                       pxMsgOutEntry,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_set_MsgOutbox
*  Description    : Set api to set MessageOutbox object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxMsgOut - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_MsgOutbox(IN uint32  uiOperation,
                    IN x_IFX_VMAPI_OUT_Message* pxMsgOut,
                    IN uint32  uiInFlag)
{
	IFX_ID	iid, piid;
  int32 iInstanceIndex = -1 ; 
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdLine; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8  acSysCmdBuf[256];
  x_IFX_VMAPI_OUT_MessageEntry *pxTemp;
  x_IFX_VMAPI_OUT_Message xOldMsgOut;
	uchar8 ucLine;
  
  uint32 uiObjectId = IFX_VMAPI_OBJ_MESSAGE_OUT; //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxMsgOut);
   
  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_DEL\n");
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_MODIFY\n");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_ADD\n");
	}
  else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Error : Operation Is Not Supported\n");
		return IFX_VMAPI_FAIL;
  }


  CHECK_ACS_SESSION_OWNER_COMBINATION(pxMsgOut->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

  //memset(&iid,0,sizeof(iid));    
	memset(&iid, 0x00, sizeof(iid));
	memset(&piid, 0x00, sizeof(piid));
	
  IFX_VMAPI_STRCPY(pxMsgOut->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	sprintf(pxMsgOut->iid.pcpeId.secName, "%s", "VoiceLine");

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxMsgOut->iid.config_owner == IFX_TR69)  {

    IFX_VMAPI_GetLineIdFromCpeId(pxMsgOut->iid.pcpeId.Id, &ucLine);
	  pxMsgOut->ucLineId = ucLine;
	}
  
	if ((pxMsgOut->iid.config_owner == IFX_WEB)||(pxMsgOut->iid.config_owner == IFX_VOIP))  {

		x_IFX_VMAPI_VoiceLine xVoiceLine;
    /* Assign the LineId of the MessageInbox object to the VoiceLine object */
    xVoiceLine.ucLineId = pxMsgOut->ucLineId;
    /* Get the CpeId of the Parent Object VoiceLine */
    //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine,&iCpeIdLine);
    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",xVoiceLine.ucLineId,&iCpeIdLine);
	  pxMsgOut->iid.pcpeId.Id = iCpeIdLine;
	  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
		{
      IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_OUTBOX,pxMsgOut,&iCpeId);
      pxMsgOut->iid.cpeId.Id = iCpeId;
		}
  }

  iid = pxMsgOut->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    iid = pxMsgOut->iid;
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  }
	
  /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
	if (ifx_get_IID(&iid, NULL) != IFX_SUCCESS) {
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxMsgOut->iid = iid;
		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  IFX_VMAPI_LOCK(uiLock); 
  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxMsgOut, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List \n");
		goto EndLabel;  
}
  
  if(IFX_MODIFY_F_SET(uiInFlag) ) {

		/*GET the old MessageInbox parameter values */
		memset(&xOldMsgOut,0,sizeof(x_IFX_VMAPI_OUT_Message));
	  xOldMsgOut.ucLineId = pxMsgOut->ucLineId;
	  //xOldLineSig.iid.pcpeId.Id = pxLineSignaling->iid.pcpeId.Id;
    xOldMsgOut.iid.config_owner = IFX_VOIP;
    if(ifx_get_MsgOutbox(&xOldMsgOut,0)!=IFX_VMAPI_SUCCESS)
    {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Error : Get Failed For Line Signaling");
    	goto EndLabel;
		}
#if 0
    /* Set should happen for AuthCfg list */
    pxTemp = pxMsgOut->pxMsgEntries;
    //pxTemp = xOldLineSig.pxAuthCfg;
    pxMsgOut->ucNoOfEntries = 0;
    while(pxTemp !=NULL)
    {
      pxTemp->ucLineId = pxMsgOut->ucLineId;
      //pxTemp->iid.cpeId.Id =pxLineSignaling->ucNoOfSipAuthCfg+1;
			//printf("\n====cPeId=%d pcpeId=%d======\n",pxTemp->iid.cpeId.Id,pxTemp->iid.pcpeId.Id);
      pxTemp->iid.config_owner = pxMsgOut->iid.config_owner;
      ifx_set_MsgOutboxEntry(IFX_OP_MOD,pxTemp,0);
      pxMsgOut->ucNoOfEntries++;
      __ifx_list_GetNext((void **)&pxTemp);
    }
#endif
  }

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : ifx_get_conf_index_and_nv_pairs failed \n");
		goto EndLabel;  
}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
                                        
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
    goto EndLabel;
		}
  }
  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 				"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
	  /* Check If the Object is Registered or not */
    if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_MSG_OUTBOX) == IFX_VMAPI_SUCCESS)
	  {
		  /*GET the old MessageOutbox parameter values */
		  memset(&xOldMsgOut,0,sizeof(x_IFX_VMAPI_OUT_Message));
	    xOldMsgOut.ucLineId = pxMsgOut->ucLineId;
	    xOldMsgOut.iid.pcpeId.Id = pxMsgOut->iid.pcpeId.Id;
      xOldMsgOut.iid.config_owner = IFX_VOIP;
      if(ifx_get_MsgOutbox(&xOldMsgOut,0)!=IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Error : Get Failed For Line Signaling");
      }

  	  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	    "Object is Registered\n ");
	  }
	  else
	  {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Error : Object Not Registered\n");
	  }
	}
	}/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */


  /* Backup rc.conf before proceeding with configuration */
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      } 
#endif
			goto EndLabel;
    } else {
       
			  /*** Send Notification  ***/
        if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
          if (IFX_MODIFY_F_SET(uiInFlag)) { 
            if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_MSG_OUTBOX) == IFX_VMAPI_SUCCESS)
	          {
              IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Sending The Notification\n");
              IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_MSG_OUTBOX,(void *)&xOldMsgOut,(void *)pxMsgOut);
	          }
	        }
	      }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */

        /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							 "Warning : ifx_CompactCfgSection failed \n");
          }
        }

				if (IFX_INT_ADD_F_SET(uiInFlag)) {
           //IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_OUTBOX, pxMsgOut,pxMsgOut->iid.cpeId.Id);
           IFX_VMAPI_Update_CpeId_opt("MsgOut_CpeId", pxMsgOut->ucLineId,pxMsgOut->iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
           /* Update the CpeId corresponding to the Line Id */
           //IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_OUTBOX, pxMsgOut,0);
           IFX_VMAPI_Update_CpeId_opt("MsgOut_CpeId", pxMsgOut->ucLineId,0);
        }
				
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			  			 " Cannot write to the flash\n");
	      }
#endif
			 

				if (IFX_MODIFY_F_SET(uiInFlag)) { 
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgOut->iid,uiChangedNvCount,
				          									pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		             "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
        }

	      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgOut->iid,uiChangedNvCount,
					       									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
 		
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgOut->iid,uiChangedNvCount,
					        								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
	      }

        if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgOut->iid,uiChangedNvCount,
					       								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }

          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgOut->iid,uiChangedNvCount,
					     									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
        } 

    }

  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function \n");
  return ret;
}

/******************************************************************************
*  Function Name  : ifx_set_MsgOutboxEntry
*  Description    : Set api to set CodecDesc object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxMsgOutEntry - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_MsgOutboxEntry(IN uint32 uiOperation,
                      IN x_IFX_VMAPI_OUT_MessageEntry *pxMsgOutEntry,
                      IN uint32  uiInFlag)
{
  IFX_ID iid;
  int32 iInstanceIndex = -1 ; 
  
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdCodec; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8  acSysCmdBuf[256];
	uchar8 ucLine;
  
	x_IFX_VMAPI_OUT_Message xMsgOut ;
	uint32 uiMsgHdl =0;

  uint32 uiObjectId = IFX_VMAPI_OBJ_MESSAGE_OUT_ENTRY; //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxMsgOutEntry);
   
  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_DEL\n");
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_MODIFY\n");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 	"Operation is IFX_OP_ADD\n");
	}
  else {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Error : Operation Is Not Supported\n");
		return IFX_VMAPI_FAIL;
  }

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxMsgOutEntry->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

	if(IFX_INT_ADD_F_SET(uiInFlag) ) 
	{
		memset(&xMsgOut,0,sizeof(xMsgOut));
		xMsgOut.ucLineId = pxMsgOutEntry->ucLineId ;
		xMsgOut.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != ifx_get_MsgOutbox(&xMsgOut,0))
		{
	    return IFX_FAILURE;
		}
		pxMsgOutEntry->ucIndex = xMsgOut.ucNoOfEntries+1;
		ifx_vmapi_freeObjectList(&xMsgOut, IFX_VMAPI_MSG_OUTBOX);
		/* Create a new Handle */
		uiMsgHdl = pxMsgOutEntry->ucIndex;
		uiMsgHdl = uiMsgHdl | (pxMsgOutEntry->ucLineId)<<8;
		uiMsgHdl = uiMsgHdl | IFX_VMAPI_MSG_OUT<<16;

		pxMsgOutEntry->uiMsgHdl = uiMsgHdl;
		printf("uiMsgHdl = %d\n",uiMsgHdl);
	}

	if(IFX_DELETE_F_SET(uiInFlag) ) 
	{
		pxMsgOutEntry->ucIndex = (pxMsgOutEntry->uiMsgHdl) & 0xFF;
	}

	/* Delete All the entries if MsgOutdex is 0.
	   Firstly delete all the entries of Message In Entry table.
	   Then change the number of entries of the parent object(MsgOut)
		 as 0 and the list as NULL. Set the object. */
  if((IFX_DELETE_F_SET(uiInFlag)) && (pxMsgOutEntry->ucIndex == 0) ) 
	{
		x_IFX_VMAPI_IN_Message xMsgOut;
		int32 i=0;
    char8 s[] = "MsgOutEntry_Count";
    char8 pcCont[20] = {0};
    sprintf(&pcCont[0],"%s=\"%d\"\n",s,0);
	
		memset(&xMsgOut,0,sizeof(xMsgOut));
  	xMsgOut.ucLineId = pxMsgOutEntry->ucLineId;
  	xMsgOut.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgOutbox(&xMsgOut,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgOutbox FAILED\n");
			return IFX_FAILURE;
		}
		ifx_vmapi_freeObjectList(&xMsgOut, IFX_VMAPI_MSG_INBOX);

		for(i=0;i<xMsgOut.ucNoOfEntries;i++)
		{
			pxMsgOutEntry->ucIndex = 1;
			//IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_OUTBOX_ENTRY, pxMsgOutEntry,0);
    	IFX_VMAPI_Update_CpeId_opt("MsgOutEntry_CpeId",
                                 (((pxMsgOutEntry->ucLineId-1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+pxMsgOutEntry->ucIndex),0);
		}
		xMsgOut.pxMsgEntries = NULL;
		xMsgOut.ucNoOfEntries = 0;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgOutbox(IFX_OP_MOD,&xMsgOut,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgOutbox FAILED\n");
			return IFX_FAILURE;
		}

    if (ifx_SetObjData(SYSTEM_CONF_FILE,
                    "MsgOutEntry",
                    IFX_F_DEFAULT,
                    1,
                    (char8*)pcCont) != IFX_SUCCESS)  {
						
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			   "Error : Could not SET the MsgOutEntry  \n");
		}
		
    return IFX_VMAPI_SUCCESS;
	}

  memset(&iid,0,sizeof(iid));   

  /* Configuring the CpeId */
  IFX_VMAPI_STRCPY(pxMsgOutEntry->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	sprintf(pxMsgOutEntry->iid.pcpeId.secName, "%s", "MsgOut");

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxMsgOutEntry->iid.config_owner == IFX_TR69)  {

    IFX_VMAPI_GetLineIdFromCpeId(pxMsgOutEntry->iid.pcpeId.Id, &ucLine);
	  pxMsgOutEntry->ucLineId = ucLine;
		//printf("[%s %d] lineId %d\n",__FUNCTION__, __LINE__, ucLine);
	}
  
	if((pxMsgOutEntry->iid.config_owner == IFX_WEB)||(pxMsgOutEntry->iid.config_owner == IFX_VOIP))  {
	
		/*  Configuring the parent */
    x_IFX_VMAPI_OUT_Message xMsgOut = {'\0'};
    /* Assign the LineId of the MsgOutboxEntry object to MsgOutbox object */
    xMsgOut.ucLineId = pxMsgOutEntry->ucLineId;
    /* Get the CpeId of the Parent Object LineCodecList */
    IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_OUTBOX,&xMsgOut,&iCpeIdCodec);
	  pxMsgOutEntry->iid.pcpeId.Id = iCpeIdCodec;
		//printf("[%s %d] PCpeId %d\n",__FUNCTION__, __LINE__, iCpeIdCodec);

	  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
		{
      IFX_VMAPI_Get_CpeId(IFX_VMAPI_MSG_OUTBOX_ENTRY,pxMsgOutEntry,&iCpeId);
      pxMsgOutEntry->iid.cpeId.Id = iCpeId;
		}
		
  }
  
  iid =pxMsgOutEntry->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    iid = pxMsgOutEntry->iid;
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  } 
  /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
    if (ifx_get_IID(&iid, "MsgHdl") != IFX_SUCCESS) {
      	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		  			"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxMsgOutEntry->iid = iid;

		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  
  IFX_VMAPI_LOCK(uiLock); 

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxMsgOutEntry, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get NV List \n");
		goto EndLabel;  
}

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : ifx_get_conf_index_and_nv_pairs failed \n");
	goto EndLabel;  
}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    if (IFX_VMAPI_CheckACLRet(&iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
                                        
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get Changed Field Names \n");
    	goto EndLabel;
		}
  }
  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 					"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
							
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Warning : Could Not Roll Back Config File \n");
      } 
#endif
			goto EndLabel;
    } else {
      /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 								"Warning : ifx_CompactCfgSection failed \n");
          }
        }

				/* Update the CpeId of that entry of the line */
        if (IFX_INT_ADD_F_SET(uiInFlag)) {
           /*IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_OUTBOX_ENTRY, 
													 pxMsgOutEntry,pxMsgOutEntry->iid.cpeId.Id);*/
           IFX_VMAPI_Update_CpeId_opt("MsgOutEntry_CpeId", 
													            (((pxMsgOutEntry->ucLineId-1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+pxMsgOutEntry->ucIndex),
                                      pxMsgOutEntry->iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
					if((pxMsgOutEntry->iid.config_owner == IFX_WEB)||(pxMsgOutEntry->iid.config_owner == IFX_VOIP))
		      {
            /* Update the CpeId corresponding to the Line Id */
            //IFX_VMAPI_Update_CpeId(IFX_VMAPI_MSG_OUTBOX_ENTRY, pxMsgOutEntry,0);
            IFX_VMAPI_Update_CpeId_opt("MsgOutEntry_CpeId",(((pxMsgOutEntry->ucLineId-1)*IFX_VMAPI_MAX_MSG_IN_ENTRIES)+pxMsgOutEntry->ucIndex),0);
          }
	        else
	        {
						if(IFX_VMAPI_ReplaceCpeId("MsgOutEntry" , 
																	pxMsgOutEntry->iid.cpeId.Id) !=IFX_VMAPI_SUCCESS)
						{
							//printf("[%s %d] Failed to Replace\n",__FUNCTION__, __LINE__);
						}
						else
						{
							printf("REPLACING SUCCESSFUL\n");
						}
	        }

        }
				
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			  			 " Cannot write to the flash\n");
	      }
#endif
 	

				if (IFX_MODIFY_F_SET(uiInFlag)) { 
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgOutEntry->iid,uiChangedNvCount,
				          									pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		             "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
        }

	      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgOutEntry->iid,uiChangedNvCount,
					       									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
 		
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgOutEntry->iid,uiChangedNvCount,
					        								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
	      }

        if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(&pxMsgOutEntry->iid,uiChangedNvCount,
					       								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }

          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(&pxMsgOutEntry->iid,uiChangedNvCount,
					     									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
        } 
				
    }
  
  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "Leaving Function \n");
  return ret;
}

/******************************************************************************
*  Function Name  : ifx_vmapi_getMsg
*  Description    : Get the message entry depends on the type of MsgBox.
*  Input Values   : ucLineId - LineId
*                   uiMsgHdl - Message handle
*                   pucMsg - Pointer to the message buffer
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_vmapi_getMsg( IN uchar8 ucLineId,
            			IN uint32 uiMsgHdl,
									IN_OUT x_IFX_VMAPI_MessageEntry* pxMsgEntry)
{
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");
	pxMsgEntry->uiMsgHdl = uiMsgHdl;
	pxMsgEntry->ucLineId = ucLineId;
	if(uiMsgHdl >> 16 == IFX_VMAPI_MSG_IN) {
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgInboxEntry(pxMsgEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		//printf("<ifx_vmapi_getMsg> Msg is %s\n",xMsgInEntry.acMsg);
		//strcpy(pucMsg,xMsgInEntry.acMsg);
	}
	else if (uiMsgHdl >> 16 == IFX_VMAPI_MSG_OUT) {
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgOutboxEntry(pxMsgEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgOutboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		//printf("<ifx_vmapi_getMsg> Msg is %s\n",xMsgOutEntry.acMsg);
		//strcpy(pucMsg,xMsgOutEntry.acMsg);
	}	
	else {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			       "Error : Wrong Message Box Type !!! \n");
	}	
	return IFX_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_vmapi_storeMsg
*  Description    : Store the message entry depends on the type of MsgBox.
*  Input Values   : ucLineId - LineId
*                   uiMsgHdl - Message handle
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_vmapi_storeMsg( IN uchar8 ucLineId,
									IN e_IFX_VMAPI_MsgBox eMsgBox,
            			IN x_IFX_VMAPI_MessageEntry *pxMsgEntry)
{
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");
	if(eMsgBox == IFX_VMAPI_MSG_IN) {
  	x_IFX_VMAPI_IN_Message xMsgIn ;

		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgInboxEntry(IFX_OP_ADD,pxMsgEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgInboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		memset(&xMsgIn,0,sizeof(xMsgIn));
  	xMsgIn.ucLineId = ucLineId;
  	xMsgIn.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgInbox(&xMsgIn,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}
		ifx_vmapi_freeObjectList(&xMsgIn, IFX_VMAPI_MSG_INBOX);

		xMsgIn.ucNoOfEntries++;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgInbox(IFX_OP_MOD,&xMsgIn,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}

	}
	else if (eMsgBox == IFX_VMAPI_MSG_OUT) {
  	x_IFX_VMAPI_OUT_Message xMsgOut ;

		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgOutboxEntry(IFX_OP_ADD,pxMsgEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgOutboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		memset(&xMsgOut,0,sizeof(xMsgOut));
  	xMsgOut.ucLineId = ucLineId;
  	xMsgOut.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgOutbox(&xMsgOut,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}
		ifx_vmapi_freeObjectList(&xMsgOut, IFX_VMAPI_MSG_OUTBOX);

		xMsgOut.ucNoOfEntries++;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgOutbox(IFX_OP_MOD,&xMsgOut,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgOutbox FAILED\n");
			return IFX_FAILURE;
		}

	}
	else {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			       "Error : Wrong Message Box Type !!! \n");
	}	
		
	return IFX_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_vmapi_delMsg
*  Description    : Delete the message entry depends on the type of MsgBox.
*  Input Values   : ucLineId - LineId
*                   uiMsgHdl - Message handle
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_vmapi_delMsg( IN uchar8 ucLineId,
            			IN uint32 uiMsgHdl)
{
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");
	if(uiMsgHdl >> 16 == IFX_VMAPI_MSG_IN) {
		x_IFX_VMAPI_IN_MessageEntry xMsgInEntry;
  	x_IFX_VMAPI_IN_Message xMsgIn ;

  	memset(&xMsgInEntry,0,sizeof(xMsgInEntry));
		xMsgInEntry.ucLineId = ucLineId ;
  	xMsgInEntry.iid.config_owner = IFX_VOIP;
		xMsgInEntry.uiMsgHdl = uiMsgHdl;

		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgInboxEntry(IFX_OP_DEL,&xMsgInEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgInboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		memset(&xMsgIn,0,sizeof(xMsgIn));
  	xMsgIn.ucLineId = ucLineId;
  	xMsgIn.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgInbox(&xMsgIn,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}
		ifx_vmapi_freeObjectList(&xMsgIn, IFX_VMAPI_MSG_INBOX);

		/* There is no message in the table. Just return */
		if(xMsgIn.ucNoOfEntries == 0)
		{
			return IFX_VMAPI_SUCCESS;
		}
		/* One message is delted. SO update the MsgInbox entry. */
		xMsgIn.ucNoOfEntries--;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgInbox(IFX_OP_MOD,&xMsgIn,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}

	}
	else if (uiMsgHdl >> 16 == IFX_VMAPI_MSG_OUT) {
		x_IFX_VMAPI_OUT_MessageEntry xMsgOutEntry;
  	x_IFX_VMAPI_OUT_Message xMsgOut ;

  	memset(&xMsgOutEntry,0,sizeof(xMsgOutEntry));
		xMsgOutEntry.ucLineId = ucLineId ;
  	xMsgOutEntry.iid.config_owner = IFX_VOIP;
		xMsgOutEntry.uiMsgHdl = uiMsgHdl;

		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgOutboxEntry(IFX_OP_DEL,&xMsgOutEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgOutboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		memset(&xMsgOut,0,sizeof(xMsgOut));
  	xMsgOut.ucLineId = ucLineId;
  	xMsgOut.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgOutbox(&xMsgOut,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInbox FAILED\n");
			return IFX_FAILURE;
		}
		ifx_vmapi_freeObjectList(&xMsgOut, IFX_VMAPI_MSG_OUTBOX);

		/* There is no message in the table. Just return */
		if(xMsgOut.ucNoOfEntries == 0)
		{
			return IFX_VMAPI_SUCCESS;
		}
		/* One message is delted. SO update the MsgOutbox entry. */
		xMsgOut.ucNoOfEntries--;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgOutbox(IFX_OP_MOD,&xMsgOut,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgOutbox FAILED\n");
			return IFX_FAILURE;
		}

	}
	else {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			       "Error : Wrong Message Box Type !!! \n");
	}	
		
	return IFX_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_vmapi_setMsgAsRead
*  Description    : Set the message entry as Read.
*  Input Values   : ucLineId - LineId
*                   uiMsgHdl - Message handle
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_vmapi_setMsgAsRead(IN uchar8 ucLineId,
            					 IN uint32 uiMsgHdl)
{
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");
	if(uiMsgHdl >> 16 == IFX_VMAPI_MSG_IN) {
		x_IFX_VMAPI_IN_MessageEntry xMsgInEntry;
  	memset(&xMsgInEntry,0,sizeof(xMsgInEntry));
		xMsgInEntry.ucLineId = ucLineId ;
  	xMsgInEntry.iid.config_owner = IFX_VOIP;
		xMsgInEntry.uiMsgHdl = uiMsgHdl;
		
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgInboxEntry(&xMsgInEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgInboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		xMsgInEntry.bReadFlg = IFX_TRUE;
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgInboxEntry(IFX_OP_MOD,&xMsgInEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgInboxEntry FAILED\n");
			return IFX_FAILURE;
		}
	}
	else if (uiMsgHdl >> 16 == IFX_VMAPI_MSG_OUT) {
		x_IFX_VMAPI_OUT_MessageEntry xMsgOutEntry;
  	memset(&xMsgOutEntry,0,sizeof(xMsgOutEntry));
		xMsgOutEntry.ucLineId = ucLineId ;
  	xMsgOutEntry.iid.config_owner = IFX_VOIP;
		xMsgOutEntry.uiMsgHdl = uiMsgHdl;

		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgOutboxEntry(&xMsgOutEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_get_MsgOutboxEntry FAILED\n");
			return IFX_FAILURE;
		}
		xMsgOutEntry.bReadFlg = IFX_TRUE;


		if( IFX_VMAPI_SUCCESS != 
				ifx_set_MsgOutboxEntry(IFX_OP_MOD,&xMsgOutEntry,0))
		{
  		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 	       "Error : ifx_set_MsgOutboxEntry FAILED\n");
			return IFX_FAILURE;
		}
	}
	else {
  	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			       "Error : Wrong Message Box Type !!! \n");
	}	
		
	return IFX_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_vmapi_getMsg
*  Description    : Get the message entry depends on the type of MsgBox.
*  Input Values   : ucLineId - LineId
*                   uiMsgHdl - Message handle
*                   pucMsg - Pointer to the message buffer
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32
ifx_vmapi_getUnReadMsg(IN uchar8 ucLineId,
											 OUT uchar8* pucCount)
{
	int32 iRet = IFX_VMAPI_FAIL;
	x_IFX_VMAPI_IN_Message xMsgIn ={'\0'};
  x_IFX_VMAPI_IN_MessageEntry *pxTemp;

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 			"Entering Function \n");
	memset(&xMsgIn,0,sizeof(xMsgIn));
  xMsgIn.ucLineId = ucLineId;
  xMsgIn.iid.config_owner = IFX_VOIP;
  iRet = ifx_get_MsgInbox(&xMsgIn,0);

	if ( iRet == IFX_VMAPI_SUCCESS ) {
		(*pucCount) =0;
    printf("Count: %d\n",xMsgIn.ucNoOfEntries);
    pxTemp = xMsgIn.pxMsgEntries;
    while (pxTemp !=NULL) {
			if(pxTemp->bReadFlg == IFX_TRUE) {
				++(*pucCount);
			}
      __ifx_list_GetNext((void *)&pxTemp);
    }
	}
  ifx_vmapi_freeObjectList(&xMsgIn, IFX_VMAPI_MSG_INBOX);
	return IFX_VMAPI_SUCCESS;
}

#endif /* MESSAGE_SUPPORT */

//#ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
/******************************************************************************
*  Function Name  : ifx_set_DectDiagnostics
*  Description    : Set to DECT Diagnostics mode.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    ucStartStopTest - Start or Stop Test
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_DectDiagnostics (IN uint32 uiOperation,
                           IN uchar8 ucStartStopTest,									   IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			 "Entering Function \n");

  /***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
    uiInFlag |= IFX_F_DELETE;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Operation is IFX_OP_DEL - Not Supported");
		    return IFX_VMAPI_FAIL;
	}
  else if(uiOperation == IFX_OP_MOD) {
    uiInFlag |= IFX_F_MODIFY;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		     "Operation is IFX_OP_MODIFY");
	}
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    uiInFlag |= IFX_F_INT_ADD;
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     "Operation is IFX_OP_ADD -- Not supported");
		return IFX_VMAPI_FAIL;
	}
  else {
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Operation Is Not Supported");
		return IFX_VMAPI_FAIL;
  }


	if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  	if (IFX_MODIFY_F_SET(uiInFlag)) { 
    	if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_DECT_DIAGNOSTICS) == IFX_VMAPI_SUCCESS) {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Sending The Notification\n");
          IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_DECT_DIAGNOSTICS,
                           (void *)&ucStartStopTest,NULL);
		return IFX_VMAPI_SUCCESS;				   
	    } /* IFX_VMAPI_IsObjectRegistered */
	  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
	}
  
  return IFX_VMAPI_FAIL;
}


/******************************************************************************
*  Function Name  : ifx_get_TransPower
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_TransPower(OUT x_IFX_VMAPI_TransmitPowerParam *pxTransPower,
                           IN uint32 uiInFlag)
{
  pxTransPower->iid.cpeId.Id = 1;
  pxTransPower->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");

#ifdef DECT_PART
if(uiInFlag)
  /* Object Id IFX_VMAPI_OBJ_DECT_TRANS_POWER */
  return IFX_VMAPI_GetObjectFromCpeid_V1(IFX_VMAPI_OBJ_DECT_TRANS_POWER,
                                       &pxTransPower->iid,
                                       pxTransPower,
                                       0);
else
#endif  
	/* Object Id IFX_VMAPI_OBJ_DECT_TRANS_POWER */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_TRANS_POWER,
                                       &pxTransPower->iid,
                                       pxTransPower,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_TransPowerToModem
*  Description    : Set api to set Voice System RF Mode object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxRfmode - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 
ifx_set_TransPowerToModem(IN uchar8 ucStartStopTest,
            IN x_IFX_VMAPI_TransmitPowerParam *pxTransParam)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_TRANS_POWER_TEST) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");
    if(ucStartStopTest == 1) /* GET */{
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_TRANS_POWER_TEST,
	                              NULL,
								  NULL);
	}else if(ucStartStopTest == 2) /* SET */{
	
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_TRANS_POWER_TEST,
	                              NULL,
								  (void *) pxTransParam);
	
	}
	
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_TransPower
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_TransPower (IN uint32 uiOperation,
                         IN x_IFX_VMAPI_TransmitPowerParam *pxTransPower,
                         IN uint32 uiInFlag)
{
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxTransPower);
	sprintf(pxTransPower->iid.pcpeId.secName, "%s", "TransPower");

	return LTQ_set_DectObject(uiOperation,
														pxTransPower,
														IFX_VMAPI_TRANS_POWER_TEST,
														IFX_VMAPI_OBJ_DECT_TRANS_POWER,
														uiInFlag);
}

/*Copied here RF Mode-FROM Block*/

/******************************************************************************
*  Function Name  : ifx_get_rfmode
*  Description    : Get api to get Voice System RF Mode object
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxRfmode - pointer to RF mode object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_rfmode(OUT x_IFX_VMAPI_RFMode *pxRfmode,
                           IN uint32 uiInFlag)
{
  pxRfmode->iid.cpeId.Id = 1;
  pxRfmode->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_RF_MODE */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_RF_MODE,
                                       &pxRfmode->iid,
                                       pxRfmode,
                                       uiInFlag); 
}

/******************************************************************************
*  Function Name  : ifx_set_rfmodeToModem
*  Description    : Set api to set Voice System RF Mode object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxRfmode - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_rfmodeToModem(IN uchar8 ucStartStopTest,IN x_IFX_VMAPI_RFMode *pxRfmode)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_RF_MODE_TEST) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");
		 
    if(ucStartStopTest == 1) /* GET */{
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_RF_MODE_TEST,
	                              NULL,
								  NULL);
								  
	}else if(ucStartStopTest == 2) /* SET */{

    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_RF_MODE_TEST,
	                              NULL,
								  (void *) pxRfmode);

	 }
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_rfmode
*  Description    : Set api to set Voice System RF Mode object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxRfmode - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_rfmode(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_RFMode *pxRfmode,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxRfmode);
	sprintf(pxRfmode->iid.pcpeId.secName, "%s", "TransPower");

	return LTQ_set_DectObject(uiOperation,
		                        pxRfmode,
				                    IFX_VMAPI_RF_MODE_TEST,
					                  IFX_VMAPI_OBJ_DECT_RF_MODE,
						                uiInFlag);
}




/******************************************************************************
*  Function Name  : ifx_get_TransPower
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Rfpi(OUT x_IFX_VMAPI_DectRfpi *pxRfpi,
                           IN uint32 uiInFlag)
{
  pxRfpi->iid.cpeId.Id = 1;
  pxRfpi->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_TRANS_POWER */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_RFPI,
                                       &pxRfpi->iid,
                                       pxRfpi,
                                       uiInFlag); 
}

/******************************************************************************
*  Function Name  : ifx_set_XramToModem
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 
ifx_set_RfpiToModem(IN uchar8 ucStartStopTest,
            IN x_IFX_VMAPI_DectRfpi *pxRfpi)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_RFPI_TEST) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");
    if(ucStartStopTest == 1) /* GET */{
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_RFPI_TEST,
	                              NULL,
								  NULL);
	}else if(ucStartStopTest == 2) /* SET */{
	
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_RFPI_TEST,
	                              NULL,
								  (void *) pxRfpi);
	
	}
	
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_Rfpi
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Rfpi(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectRfpi *pxRfpi,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxRfpi);
	sprintf(pxRfpi->iid.pcpeId.secName, "%s", "Rfpi");

	return LTQ_set_DectObject(uiOperation,
		                        pxRfpi,
				                    IFX_VMAPI_RFPI_TEST,
					                  IFX_VMAPI_OBJ_DECT_RFPI,
						                uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_Xram
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Xram(OUT x_IFX_VMAPI_DectXRAM *pxXram,
                           IN uint32 uiInFlag)
{
  pxXram->iid.cpeId.Id = 1;
  pxXram->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_TRANS_POWER */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_XRAM,
                                       &pxXram->iid,
                                       pxXram,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_XramToModem
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 
ifx_set_XramToModem(IN uchar8 ucStartStopTest,
            IN x_IFX_VMAPI_DectXRAM *pxXram)
{


  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_XRAM_TEST) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");
  IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_XRAM_TEST,
	                                 (void *)&ucStartStopTest,
			     					               (void *) pxXram);
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_Xram
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Xram(IN uint32 uiOperation,
                   IN x_IFX_VMAPI_DectXRAM *pxXram,
                   IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxXram);
	sprintf(pxXram->iid.pcpeId.secName, "%s", "Xram");

	return LTQ_set_DectObject(uiOperation,
		                        pxXram,
														IFX_VMAPI_XRAM_TEST,
				                    IFX_VMAPI_OBJ_DECT_XRAM,
					                  uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_CtrySet
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CtrySet(OUT x_IFX_VMAPI_DectCountrySettings *pxCtryset,
                           IN uint32 uiInFlag)
{
  pxCtryset->iid.cpeId.Id = 1;
  pxCtryset->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_TRANS_POWER */
  if(IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_COUNTRY_SETTINGS,
                                       &pxCtryset->iid,
                                       pxCtryset,
                                       uiInFlag) == IFX_VMAPI_SUCCESS)
  {
    /*fp = fopen("/flash/log.txt","a");
    fprintf(fp," <ifx_get_CtrySet>VMAPI log:Ctryset  Value %d %d \n",
	         pxCtryset->ucFreqTxOffset,pxCtryset->ucFreqRxOffset);
    fclose(fp);*/

    return IFX_VMAPI_SUCCESS;
  }
  return IFX_VMAPI_FAIL;
 
}

/******************************************************************************
*  Function Name  : ifx_set_CtrySetToModem
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CtrySetToModem(IN uchar8 ucStartStopTest,
                            IN x_IFX_VMAPI_DectCountrySettings *pxCtryset)
{
  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_COUNTRY_SETTINGS_TEST) == IFX_VMAPI_SUCCESS) {
     IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "<ifx_set_CtrySetToModem>Sending The Notification\n");
		  
   if(ucStartStopTest == 1) /* GET */{

      IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_COUNTRY_SETTINGS_TEST,NULL,NULL);

    }else if(ucStartStopTest == 2) /* SET */{

      IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_COUNTRY_SETTINGS_TEST,NULL,(void *)pxCtryset);
     }

   return IFX_VMAPI_SUCCESS;
   } /* IFX_VMAPI_IsObjectRegistered */
   return IFX_VMAPI_FAIL;

}

/******************************************************************************
*  Function Name  : ifx_set_CtrySet
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CtrySet(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectCountrySettings *pxCtryset,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxCtryset);
	sprintf(pxCtryset->iid.pcpeId.secName, "%s", "CountrySettings");
	
	return LTQ_set_DectObject(uiOperation,
		                        pxCtryset,
			                      IFX_VMAPI_COUNTRY_SETTINGS_TEST,
				                    IFX_VMAPI_OBJ_DECT_COUNTRY_SETTINGS,
					                  uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_TransPower
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Bmcparam(OUT x_IFX_VMAPI_DectBMCParams *pxBmcparam,
                           IN uint32 uiInFlag)
{
  pxBmcparam->iid.cpeId.Id = 1;
  pxBmcparam->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_TRANS_POWER */
#ifdef DECT_PART
if(uiInFlag)
	return IFX_VMAPI_GetObjectFromCpeid_V1(IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS,
                                       &pxBmcparam->iid,
                                       pxBmcparam,
                                       0);
else
#endif
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS,
                                       &pxBmcparam->iid,
                                       pxBmcparam,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_BmcparamToModem
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_BmcparamToModem(IN uchar8 ucStartStopTest,IN x_IFX_VMAPI_DectBMCParams *pxBmcparam)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_BMC_REG_PARAMS_TEST) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");
    if(ucStartStopTest == 1) /* GET */{
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_BMC_REG_PARAMS_TEST,
	                              NULL,
								  NULL);
	}else if(ucStartStopTest == 2) /* SET */{
	
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_BMC_REG_PARAMS_TEST,
	                              NULL,
								  (void *) pxBmcparam);
	}
	
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}

/******************************************************************************
*  Function Name  : ifx_set_Bmcparam
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Bmcparam(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectBMCParams *pxBmcparam,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxBmcparam);
	sprintf(pxBmcparam->iid.pcpeId.secName, "%s", "BmcParams");

	return LTQ_set_DectObject(uiOperation,
														pxBmcparam,
														IFX_VMAPI_BMC_REG_PARAMS_TEST,
														IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS,
														uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_Osctrim
*  Description    : Get api to get Voice System Osc trim object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxOsctrim - pointer to Osc trim object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Osctrim(OUT x_IFX_VMAPI_DectOscTrimVal *pxOsctrim,
                           IN uint32 uiInFlag)
{
  pxOsctrim->iid.cpeId.Id = 1;
  pxOsctrim->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entereing Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_OSC_TRIM */
#ifdef DECT_PART
if(uiInFlag)
  return IFX_VMAPI_GetObjectFromCpeid_V1(IFX_VMAPI_OBJ_DECT_OSC_TRIM,
                                       &pxOsctrim->iid,
                                       pxOsctrim,
                                       0); 
else
#endif
return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_OSC_TRIM,
                                       &pxOsctrim->iid,
                                       pxOsctrim,
                                       uiInFlag);
}


int32 ifx_set_OsctrimToModem(IN uchar8 ucStartStopTest,IN x_IFX_VMAPI_DectOscTrimVal *pxOsctrim)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_OSC_TRIM_TEST) == IFX_VMAPI_SUCCESS) {
     IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Sending The Notification\n");


    if(ucStartStopTest == 1) /* GET */{

      IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_OSC_TRIM_TEST,
	                                   NULL,
									   NULL);
									   
	}else if(ucStartStopTest == 2) /* SET */{
	
    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_OSC_TRIM_TEST,
	                                 NULL,
									 (void *)pxOsctrim);
	}
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;   

}

		 

/******************************************************************************
*  Function Name  : ifx_set_Osctrim
*  Description    : Set api to set Voice System Osc trim object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxOsctrim - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Osctrim(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectOscTrimVal *pxOsctrim,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxOsctrim);
	sprintf(pxOsctrim->iid.pcpeId.secName, "%s", "Osctrim");

	return LTQ_set_DectObject(uiOperation,
														pxOsctrim,
														IFX_VMAPI_OSC_TRIM_TEST,
														IFX_VMAPI_OBJ_DECT_OSC_TRIM,
														uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_get_Gfsk
*  Description    : Get api to get Voice System Osc trim object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxOsctrim - pointer to Osc trim object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_Gfsk(OUT x_IFX_VMAPI_DectGFSKVal *pxGfsk,
                           IN uint32 uiInFlag)
{
  pxGfsk->iid.cpeId.Id = 1;
  pxGfsk->iid.pcpeId.Id = 1;
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
	           "Entering Function");
 
  /* Object Id IFX_VMAPI_OBJ_DECT_GFSK */
#ifdef DECT_PART
if(uiInFlag)
  return IFX_VMAPI_GetObjectFromCpeid_V1(IFX_VMAPI_OBJ_DECT_GFSK,
                                       &pxGfsk->iid,
                                       pxGfsk,
                                       0);
else
#endif  
return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_DECT_GFSK,
                                       &pxGfsk->iid,
                                       pxGfsk,
                                       uiInFlag);
 
}


int32 ifx_set_GfskToModem(IN uchar8 ucStartStopTest,IN x_IFX_VMAPI_DectGFSKVal *pxGfsk)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_GFSK_TEST) == IFX_VMAPI_SUCCESS) {
     IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Sending The Notification\n");

    if(ucStartStopTest == 1) /* GET */{

      IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_GFSK_TEST,
	                                   NULL,
									   NULL);
									   
	}else if(ucStartStopTest == 2) /* SET */{
	
      IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_GFSK_TEST,
	                                   NULL,
									   (void *)pxGfsk);
	}
	return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;   

}

#ifdef CVOIP_SUPPORT
int32
ifx_set_DectInterfaceToModem(IN x_IFX_VMAPI_DectSystem *pxDectInf)
{

  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_DECT_SYSTEM) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");

    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_DECT_SYSTEM,
                                NULL,
                  (void *) pxDectInf);

  return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}
#endif

/******************************************************************************
*  Function Name  : ifx_set_Osctrim
*  Description    : Set api to set Voice System Osc trim object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxOsctrim - Pointer to the object to be set
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_Gfsk(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectGFSKVal *pxGfsk,
                         IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	/* Validate the paramters :: make sure that pointers and flags are proper */
	IFX_VALIDATE_PTR(pxGfsk);
	sprintf(pxGfsk->iid.pcpeId.secName, "%s", "Gfsk");

	return LTQ_set_DectObject(uiOperation,
		                        pxGfsk,
			                      IFX_VMAPI_GFSK_TEST,
				                    IFX_VMAPI_OBJ_DECT_GFSK,
					                  uiInFlag);
}
#endif


/******************************************************************************
*  Function Name  : IFX_VMAPI_Init
*  Description    : Initialize VMAPI.
*  Input Values   : 
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 IFX_VMAPI_Init()
{
  char8 cErr;
	x_IFX_VMAPI_SystemDebugSettings xDbgSet;
	if(ifx_get_DbgSettings(&xDbgSet,0) != IFX_VMAPI_SUCCESS)
	{
	  return IFX_VMAPI_FAIL;
	}
	else {
    IFX_VMAPI_DbgInit(xDbgSet.xVmapiDbg.ucDbgLvl,
										 xDbgSet.xVmapiDbg.ucDbgType, 
										 &cErr);
	}
	
  /*ifx_update_EntryId(IFX_VMAPI_VS_MISSCALL_REGISTER);
  ifx_update_EntryId(IFX_VMAPI_VS_RECVCALL_REGISTER);
  ifx_update_EntryId(IFX_VMAPI_VS_DIALCALL_REGISTER);
  ifx_update_EntryId(IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY);
  ifx_update_EntryId(IFX_VMAPI_VS_CONTACT_LIST);
  ifx_update_EntryId(IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER);
  ifx_update_EntryId(IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER);
  ifx_update_EntryId(IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER);
  ifx_update_EntryId(IFX_VMAPI_VS_PSTN_CONTACT_LIST);
  ifx_update_EntryId(IFX_VMAPI_VS_COMMON_CONTACT_LIST);*/
	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetDebug
*  Description    : Initialize VMAPI.
*  Input Values   : 
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 IFX_VMAPI_SetDebug(uchar8 ucType , uchar8 ucLevel)
{
 	IFX_DBG_Set("VMAPI",ucVMAPIModuleId,ucType,ucLevel);
	
	return IFX_VMAPI_SUCCESS;
}



/******************************************************************
*  Function Name:  ifx_vmapi_freeObjectList
*  Description  :
*  Input Values :
*  Return Value :
*  Notes        :
*********************************************************************/
void
ifx_vmapi_freeObjectList(IN VOID *pxVoid,IN uchar8 ucObjType)
{
	/* Check for valid object */
	if (ucObjType >= IFX_VMAPI_MAX_OBJ) {
		return ;
	}
  switch(ucObjType)
	{

		/* Voice Codec Capabs */
		case IFX_VMAPI_CODEC_CAPABS:
      {
				x_IFX_VMAPI_VoiceCodecCapabilities *pxVoiceCodecCaps =
                       (x_IFX_VMAPI_VoiceCodecCapabilities*) pxVoid;
  
        while(pxVoiceCodecCaps->pxCodecList != NULL){
          __ifx_list_del((void**)&pxVoiceCodecCaps->pxCodecList,
                    (void *)pxVoiceCodecCaps->pxCodecList);
        }
      }
      break;

     /* Voice System Address Book */
		case IFX_VMAPI_VS_ADDRESS_BOOK:
      {
        x_IFX_VMAPI_AddressBook *pxAddrBook = 
                       (x_IFX_VMAPI_AddressBook*) pxVoid;
  
        while(pxAddrBook->pxAddressBook != NULL){
          __ifx_list_del((void**)&pxAddrBook->pxAddressBook,
                    (void *)pxAddrBook->pxAddressBook);
        }
      }
      break;
			/* Call Block Entry */
    case IFX_VMAPI_VS_CALL_BLOCK:
      {
        x_IFX_VMAPI_CallBlock *pxCallBlock = 
                       (x_IFX_VMAPI_CallBlock*) pxVoid;
  
        while(pxCallBlock->pxCallBlockList != NULL){
          __ifx_list_del((void**)&pxCallBlock->pxCallBlockList,
                    (void *)pxCallBlock->pxCallBlockList);
        }
      }
      break;
			/* Numbering Plan */
    case IFX_VMAPI_VS_NUM_PLAN:
      {
				x_IFX_VMAPI_NumPlan *pxNumPlan = 
                       (x_IFX_VMAPI_NumPlan*) pxVoid;
  
        while(pxNumPlan->pxNumPlanRules != NULL){
          __ifx_list_del((void**)&pxNumPlan->pxNumPlanRules,
                    (void *)pxNumPlan->pxNumPlanRules);
        }
      }
      break;
    case IFX_VMAPI_VS_DIALCALL_REGISTER:
    case IFX_VMAPI_VS_MISSCALL_REGISTER:
    case IFX_VMAPI_VS_RECVCALL_REGISTER:
		case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
    case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
    case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
      {
			printf("Trying to clear the memory of : %d \n",ucObjType);
        x_IFX_VMAPI_DialCallRegister *pxDialCall = 
                       (x_IFX_VMAPI_DialCallRegister*) pxVoid;
  
        while(pxDialCall->pxCallRegEntries != NULL){
          __ifx_list_del((void**)&pxDialCall->pxCallRegEntries,
                    (void *)pxDialCall->pxCallRegEntries);
        }
      }
      break;
     /* Voice Profile related */
    case IFX_VMAPI_VP_EVENT_SUBSCR:
      {
				printf("Trying to free the IFX_VMAPI_VP_EVENT_SUBSCR....\n");	
        x_IFX_VMAPI_ProfileEventSubsTable *pxEveSubsTbl = 
                       (x_IFX_VMAPI_ProfileEventSubsTable*) pxVoid;
  
        while(pxEveSubsTbl->pxEventSubscribe != NULL){
          __ifx_list_del((void**)&pxEveSubsTbl->pxEventSubscribe,
                    (void *)pxEveSubsTbl->pxEventSubscribe);
        }
      }
      break;
     /* Voice Line related */
    case IFX_VMAPI_VL_SIGNALING:
      {
			 x_IFX_VMAPI_LineSignaling *pxLineSig = 
                       (x_IFX_VMAPI_LineSignaling*) pxVoid; 
  
        while(pxLineSig->pxAuthCfg != NULL){
          __ifx_list_del((void**)&pxLineSig->pxAuthCfg,
                  (void *)pxLineSig->pxAuthCfg);
        }
      }
      break;

		case IFX_VMAPI_VL_EVENT_SUBSCR:
      {
        x_IFX_VMAPI_LineSubscription *pxLineSubs = 
                       (x_IFX_VMAPI_LineSubscription*) pxVoid;
  
        while(pxLineSubs->pxLineEvents != NULL){
          __ifx_list_del((void**)&pxLineSubs->pxLineEvents,
                    (void *)pxLineSubs->pxLineEvents);
        }
      }
      break;
    case IFX_VMAPI_VL_CODECLIST:
      {
        x_IFX_VMAPI_LineCodecList *pxLineCodec = 
                       (x_IFX_VMAPI_LineCodecList*) pxVoid;
  
        while(pxLineCodec->pxCodecList != NULL){
          __ifx_list_del((void**)&pxLineCodec->pxCodecList,
                    (void *)pxLineCodec->pxCodecList);
        }
      }
      break;
     /* Physical Interface related */
//#ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
    case IFX_VMAPI_DECT_SYSTEM:
      {
        x_IFX_VMAPI_DectSystem *pxDect = 
                       (x_IFX_VMAPI_DectSystem*) pxVoid;
  
        while(pxDect->pxHandsetTbl != NULL){
          __ifx_list_del((void**)&pxDect->pxHandsetTbl,
                    (void *)pxDect->pxHandsetTbl);
        }
        while(pxDect->pxCodecList != NULL){
          __ifx_list_del((void**)&pxDect->pxCodecList,
                    (void *)pxDect->pxCodecList);
        }
      }
#endif //DECT_SUPPORT
#ifdef MESSAGE_SUPPORT
			/* Message Inbox */
		case IFX_VMAPI_MSG_INBOX:
      {
        x_IFX_VMAPI_IN_Message *pxMsgIn = 
                       (x_IFX_VMAPI_IN_Message*) pxVoid;
  
        while(pxMsgIn->pxMsgEntries != NULL){
          __ifx_list_del((void**)&pxMsgIn->pxMsgEntries,
                    (void *)pxMsgIn->pxMsgEntries);
        }
      }
      break;
			/* Message Outbox */
		case IFX_VMAPI_MSG_OUTBOX:
      {
        x_IFX_VMAPI_OUT_Message *pxMsgOut = 
                       (x_IFX_VMAPI_OUT_Message*) pxVoid;
  
        while(pxMsgOut->pxMsgEntries != NULL){
          __ifx_list_del((void**)&pxMsgOut->pxMsgEntries,
                    (void *)pxMsgOut->pxMsgEntries);
        }
      }
      break;
#endif /* MESSAGE_SUPPORT */
case IFX_VMAPI_VS_CONTACT_LIST:
case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
      {
        x_IFX_VMAPI_ContactList *pxContactList =
                       (x_IFX_VMAPI_ContactList*) pxVoid;

        while(pxContactList->pxContactEntries != NULL){
          __ifx_list_del((void**)&pxContactList->pxContactEntries,
                    (void *)pxContactList->pxContactEntries);
        }
      }
      break;

      break;
		default:
				/* Not a valid object */
				return ;
	}

}
/******************************************************************************
*  Function Name  : ifx_get_ContactList
*  Description    : Get api to get Contact list Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ContactList (IN_OUT  x_IFX_VMAPI_ContactList  *pxContactList,
                       IN   uint32  uiInFlag)
{
	uint32 uiListType = IFX_VMAPI_VS_CONTACT_LIST;
	uint32 uiObjectId = IFX_VMAPI_OBJ_CONTACT_LIST;
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	if(pxContactList->ucLineId == IFX_VMAPI_PSTN_LINE){
			uiListType = IFX_VMAPI_VS_PSTN_CONTACT_LIST;	
			uiObjectId = IFX_VMAPI_OBJ_PSTN_CONTACT_LIST;	
	}
	
	return  LTQ_get_ContactList (pxContactList,
																		uiListType,
																		uiObjectId,
   																	uiInFlag);

}

/******************************************************************************
*  Function Name  : ifx_get_IfContactMatch
*  Description    : Check If the Contact entry matches with the other entries
*  Input Values   : pvContactList -- the entry list
*                   pvContactEntry -- the call entry
*                   unObjCode -- Dial/Miss/Recv
*                   uiEntryIndex -- Entry index
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_IfContactMatch(IN VOID *pvContactList,
                         IN VOID *pvContactEntry,
                         IN uint16 unObjCode
                         )
{
char8 acLastNameToMatch[IFX_VMAPI_MAX_USER_NAME_LEN*2+2] = {0};
  char8 acLastNameString[IFX_VMAPI_MAX_USER_NAME_LEN*2+2] = {0};

  if(unObjCode == IFX_VMAPI_VS_CONTACT_LIST || unObjCode == IFX_VMAPI_VS_COMMON_CONTACT_LIST )
        {
                x_IFX_VMAPI_ContactListEntry *pxTemp ;
                x_IFX_VMAPI_ContactListEntry *pxContactlEntry;
                x_IFX_VMAPI_ContactList *pxContactList;
                pxContactList = (x_IFX_VMAPI_ContactList *)pvContactList;
                pxContactlEntry = (x_IFX_VMAPI_ContactListEntry *)pvContactEntry;

    sprintf(acLastNameToMatch,"%s@%s",pxContactlEntry->xAddress.acUserFirstName,pxContactlEntry->xAddress.acUserLastName);
        pxTemp=pxContactList->pxContactEntries;

        while(pxTemp != NULL)
        {
                sprintf(acLastNameString,"%s@%s",pxTemp->xAddress.acUserFirstName,pxTemp->xAddress.acUserLastName);
        if((pxContactlEntry->ucLineId == pxTemp->ucLineId) && (pxTemp->iid.cpeId.Id != pxContactlEntry->iid.cpeId.Id)){
                  if(!(IFX_VMAPI_STRCMP(acLastNameString,acLastNameToMatch))){
                               return IFX_VMAPI_SUCCESS;
                        }
         }
                        __ifx_list_GetNext((void *)&pxTemp);
      	}
                return IFX_VMAPI_FAIL;
  	}

                return IFX_VMAPI_FAIL;

}
		

/******************************************************************************
*  Function Name  : ifx_get_IfCommonContactMatch
*  Description    : Check If the Contact entry matches with the Common contact entries
*  Input Values   : pvContactList -- the entry list
*                   pvContactEntry -- the call entry
*                   unObjCode -- Dial/Miss/Recv
*                   uiEntryIndex -- Entry index
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CommonContactMatchs(IN VOID *pvContactEntry){
  	char8 acLastNameToMatch[IFX_VMAPI_MAX_USER_NAME_LEN*2+2] = {0};
  	char8 acLastNameString[IFX_VMAPI_MAX_USER_NAME_LEN*2+2] = {0};
		x_IFX_VMAPI_ContactListEntry *pxTemp ;
    x_IFX_VMAPI_ContactListEntry *pxContactlEntry;
		x_IFX_VMAPI_ContactList xContactList;
    pxContactlEntry = (x_IFX_VMAPI_ContactListEntry *)pvContactEntry;
    sprintf(acLastNameToMatch,"%s@%s",pxContactlEntry->xAddress.acUserFirstName,pxContactlEntry->xAddress.acUserLastName);

	//Check for existence in common contact list.     
						memset(&xContactList,0,sizeof(xContactList));
						xContactList.iid.config_owner = IFX_VOIP;
    				if( ifx_get_CommonContactList(&xContactList,0) != IFX_VMAPI_SUCCESS){
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Error : Could Not Get Contact List \n");
										return IFX_VMAPI_FAIL;
						}
						
						if(!xContactList.ucNoOfEntries)
										return IFX_VMAPI_FAIL;

     				pxTemp= xContactList.pxContactEntries;
        		while(pxTemp != NULL)
        		{
								if(pxTemp->iid.cpeId.Id != pxContactlEntry->iid.cpeId.Id){
          		  	sprintf(acLastNameString,"%s@%s",pxTemp->xAddress.acUserFirstName,pxTemp->xAddress.acUserLastName);
            			if(!(IFX_VMAPI_STRCMP(acLastNameString,acLastNameToMatch))){
        							ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
                  	            return IFX_VMAPI_SUCCESS;
          		  	}
								}
                        __ifx_list_GetNext((void *)&pxTemp);
		 		 		}
        		ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
return IFX_VMAPI_FAIL;
           
}

/******************************************************************************
*  Function Name  : ifx_set_ContactList
*  Description    : Set api to set contact list object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactList - Pointer to the object to be set
*  Output Values  : pxContactList - pointer to contactlist object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ContactList(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactList *pxContactList,
                      IN uint32  uiInFlag)
{
	uint32 uiListType = IFX_VMAPI_VS_CONTACT_LIST;
	uint32 uiObjectId = IFX_VMAPI_OBJ_CONTACT_LIST;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
											 "Entereing Function");
	 if(pxContactList->ucLineId == IFX_VMAPI_PSTN_LINE){
			uiListType = IFX_VMAPI_VS_PSTN_CONTACT_LIST;
			uiObjectId = IFX_VMAPI_OBJ_PSTN_CONTACT_LIST;
		}
	return LTQ_set_ContactList(uiOperation,
																pxContactList,
																uiListType,
																uiObjectId,
																uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_ContactListEntry
*  Description    : Get api to get ContactListEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_ContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry  *pxContactListEtr,
                       IN   uint32  uiInFlag)
{ 
	uint32 uiObjectType = IFX_VMAPI_VS_CONTACT_LIST_ENTRY;	
	uint32 uiObjectId = IFX_VMAPI_OBJ_CONTACT_LIST_ENTRY;	
	if(pxContactListEtr-> ucLineId == IFX_VMAPI_PSTN_LINE){
			uiObjectType= IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY;
			uiObjectId= IFX_VMAPI_OBJ_PSTN_CONTACT_LIST_ENTRY;
		}
	
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	return LTQ_get_ContactListEntry(pxContactListEtr,
																	uiObjectType,
																	uiObjectId,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_set_ContactListEntry
*  Description    : Set api to get ContactListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactListEtr - Pointer to the object to be set
*  Output Values  : pxContactListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_ContactListEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                      IN uint32  uiInFlag)
{
	uint32 uiObjectType = IFX_VMAPI_VS_CONTACT_LIST_ENTRY;
	uint32 uiObjectId = IFX_VMAPI_OBJ_CONTACT_LIST_ENTRY;
	 if(pxContactListEtr-> ucLineId == IFX_VMAPI_PSTN_LINE){
			 uiObjectType = IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY;
			 uiObjectId = IFX_VMAPI_OBJ_PSTN_CONTACT_LIST_ENTRY;
   }

	return  LTQ_set_ContactListEntry(uiOperation,
																		pxContactListEtr,
																		uiObjectType,
																		uiObjectId,
																		uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_PstnMissCallReg
*  Description    : Set api to set Missed Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallReg - Pointer to the object to be set
*  Output Values  : pxMissCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnMissCallReg(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_MissCallRegister *pxMissCallReg,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");

	return LTQ_set_CallRegister(uiOperation,
                            pxMissCallReg,
                            IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER,
                            IFX_VMAPI_OBJ_PSTN_CALLREGISTER_MISS,
                            uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_PstnMissCallReg
*  Description    : Get api to get Missed Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallReg - pointer to Missed Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnMissCallReg (IN_OUT  x_IFX_VMAPI_MissCallRegister  *pxMissCallReg,
                       IN   uint32  uiInFlag)
{
	pxMissCallReg->pxCallRegEntries=NULL;
 
	/* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  LTQ_get_CallRegister(pxMissCallReg,
                               IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER,
                               IFX_VMAPI_OBJ_PSTN_CALLREGISTER_MISS,
                               uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_PstnMissCallRegEntry
*  Description    : Get api to get MissCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallRegEtr - pointer to MissCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnMissCallRegEntry (IN_OUT x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,
                       IN   uint32  uiInFlag)
{ 
  
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
/* Object id IFX_VMAPI_OBJ_CALLREG_MISSENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PSTN_CALLREG_MISSENTRY,
                                       &pxMissCallRegEtr->iid,
                                       pxMissCallRegEtr,
                                       uiInFlag);

}




/******************************************************************************
*  Function Name  : ifx_set_PstnMissCallRegEntry
*  Description    : Set api to get MissCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallRegEtr - Pointer to the object to be set
*  Output Values  : pxMissCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnMissCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_MissCallRegEntry *pxMissCallRegEtr,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	return LTQ_set_CallRegisterEntry(uiOperation,
                                  pxMissCallRegEtr,
                                  IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY,
                                  IFX_VMAPI_OBJ_PSTN_CALLREG_MISSENTRY,
                                  uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_set_PstnDialCallReg
*  Description    : Set api to set Dialed Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDialCallReg - Pointer to the object to be set
*  Output Values  : pxDialCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnDialCallReg(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_DialCallRegister *pxDialCallReg,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	return LTQ_set_CallRegister(uiOperation,
                            pxDialCallReg,
                            IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,
                            IFX_VMAPI_OBJ_PSTN_CALLREGISTER_DIAL,
                            uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_PstnDialCallReg
*  Description    : Get api to get Dialed Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDialCallReg - pointer to Dialed Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnDialCallReg (IN_OUT  x_IFX_VMAPI_DialCallRegister  *pxDialCallReg,
                       IN   uint32  uiInFlag)
{
	pxDialCallReg->pxCallRegEntries=NULL;
  /* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  LTQ_get_CallRegister(pxDialCallReg,
                                     IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER,
                                     IFX_VMAPI_OBJ_PSTN_CALLREGISTER_DIAL,
                                     uiInFlag);

}



/******************************************************************************
*  Function Name  : ifx_get_PstnDialCallRegEntry
*  Description    : Get api to get DialCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDialCallRegEtr - pointer to DialCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnDialCallRegEntry (IN_OUT x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,
                       IN   uint32  uiInFlag)
{ 
  
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
/* Object id IFX_VMAPI_OBJ_CALLREG_DIALENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PSTN_CALLREG_DIALENTRY,
                                       &pxDialCallRegEtr->iid,
                                       pxDialCallRegEtr,
                                       uiInFlag);

}




/******************************************************************************
*  Function Name  : ifx_set_PstnDialCallRegEntry
*  Description    : Set api to get DialCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDialCallRegEtr - Pointer to the object to be set
*  Output Values  : pxDialCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnDialCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_DialCallRegEntry *pxDialCallRegEtr,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	return LTQ_set_CallRegisterEntry(uiOperation,
                                  pxDialCallRegEtr,
                                  IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY,
                                  IFX_VMAPI_OBJ_PSTN_CALLREG_DIALENTRY,
                                  uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_set_PstnRecvCallReg
*  Description    : Set api to set Recved Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxRecvCallReg - Pointer to the object to be set
*  Output Values  : pxRecvCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnRecvCallReg(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_RecvCallRegister *pxRecvCallReg,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	return LTQ_set_CallRegister(uiOperation,
                            pxRecvCallReg,
                            IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,
                            IFX_VMAPI_OBJ_PSTN_CALLREGISTER_RECV,
                            uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_get_PstnRecvCallReg
*  Description    : Get api to get Recved Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxRecvCallReg - pointer to Recved Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnRecvCallReg (IN_OUT  x_IFX_VMAPI_RecvCallRegister  *pxRecvCallReg,
                       IN   uint32  uiInFlag)
{
  pxRecvCallReg->pxCallRegEntries=NULL;
  /* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  LTQ_get_CallRegister(pxRecvCallReg,
                                     IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER,
                                     IFX_VMAPI_OBJ_PSTN_CALLREGISTER_RECV,
                                     uiInFlag);

}



/******************************************************************************
*  Function Name  : ifx_get_PstnRecvCallRegEntry
*  Description    : Get api to get RecvCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxRecvCallRegEtr - pointer to RecvCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnRecvCallRegEntry (IN_OUT x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,
                       IN   uint32  uiInFlag)
{ 
  
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
/* Object id IFX_VMAPI_OBJ_CALLREG_RECVENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PSTN_CALLREG_RECVENTRY,
                                       &pxRecvCallRegEtr->iid,
                                       pxRecvCallRegEtr,
                                       uiInFlag);

}




/******************************************************************************
*  Function Name  : ifx_set_PstnRecvCallRegEntry
*  Description    : Set api to get RecvCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxRecvCallRegEtr - Pointer to the object to be set
*  Output Values  : pxRecvCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnRecvCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_RecvCallRegEntry *pxRecvCallRegEtr,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	return LTQ_set_CallRegisterEntry(uiOperation,
                                  pxRecvCallRegEtr,
                                  IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY,
                                  IFX_VMAPI_OBJ_PSTN_CALLREG_RECVENTRY,
                                  uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_get_PstnContactList
*  Description    : Get api to get Contact list Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnContactList (IN_OUT  x_IFX_VMAPI_ContactList  *pxContactList,
                       IN   uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");

	return LTQ_get_ContactList (pxContactList,
                              IFX_VMAPI_VS_PSTN_CONTACT_LIST,
                              IFX_VMAPI_OBJ_PSTN_CONTACT_LIST,
                              uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_set_PstnContactList
*  Description    : Set api to set contact list object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactList - Pointer to the object to be set
*  Output Values  : pxContactList - pointer to contactlist object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnContactList(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactList *pxContactList,
                      IN uint32  uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");

	return LTQ_set_ContactList(uiOperation,
                            pxContactList,
                            IFX_VMAPI_VS_PSTN_CONTACT_LIST,
                            IFX_VMAPI_OBJ_PSTN_CONTACT_LIST,
                            uiInFlag);

}



/******************************************************************************
*  Function Name  : ifx_get_PstnContactListEntry
*  Description    : Get api to get ContactListEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_PstnContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry  *pxContactListEtr,
                       IN   uint32  uiInFlag)
{ 
  
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
/* Object id IFX_VMAPI_OBJ_CONTACT_LIST_ENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_PSTN_CONTACT_LIST_ENTRY,
                                       &pxContactListEtr->iid,
                                       pxContactListEtr,
                                       uiInFlag);

}


/******************************************************************************
*  Function Name  : ifx_set_PstnContactListEntry
*  Description    : Set api to get ContactListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactListEtr - Pointer to the object to be set
*  Output Values  : pxContactListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_PstnContactListEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                      IN uint32  uiInFlag)
{

return  LTQ_set_ContactListEntry(uiOperation,
																	pxContactListEtr,
																	IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY,
																	IFX_VMAPI_OBJ_PSTN_CONTACT_LIST_ENTRY,
																	uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_CommonContactList
*  Description    : Get api to get Contact list Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CommonContactList (IN_OUT  x_IFX_VMAPI_ContactList  *pxContactList,
                       IN   uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

	return	LTQ_get_ContactList (pxContactList,
                               IFX_VMAPI_VS_COMMON_CONTACT_LIST,
                               IFX_VMAPI_OBJ_COMMON_CONTACT_LIST,
                               uiInFlag);
}



/******************************************************************************
*  Function Name  : ifx_set_CommonContactList
*  Description    : Set api to set contact list object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactList - Pointer to the object to be set
*  Output Values  : pxContactList - pointer to contactlist object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CommonContactList(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactList *pxContactList,
                      IN uint32  uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
					           "Entereing Function");
	
	return LTQ_set_ContactList(uiOperation,
                            pxContactList,
                            IFX_VMAPI_VS_COMMON_CONTACT_LIST,
                            IFX_VMAPI_OBJ_COMMON_CONTACT_LIST,
                            uiInFlag);

}




/******************************************************************************
*  Function Name  : ifx_get_CommonContactListEntry
*  Description    : Get api to get CommonContactListEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_CommonContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry  *pxContactListEtr,
                       IN   uint32  uiInFlag)
{ 
	

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

  return IFX_VMAPI_GetObjectFromCpeid(IFX_VMAPI_OBJ_COMMON_CONTACT_LIST_ENTRY,
                                       &pxContactListEtr->iid,
                                       pxContactListEtr,
                                       uiInFlag);

}



/******************************************************************************
*  Function Name  : ifx_set_CommonContactListEntry
*  Description    : Set api to get ContactListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactListEtr - Pointer to the object to be set
*  Output Values  : pxContactListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_set_CommonContactListEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                      IN uint32  uiInFlag)
{
	return  LTQ_set_ContactListEntry(uiOperation,
							                    pxContactListEtr,
									                IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY,
													        IFX_VMAPI_OBJ_COMMON_CONTACT_LIST_ENTRY,
																	uiInFlag);
}


/******************************************************************************
*  Function Name  : ifx_delete_All_ListEntries 
*  Description    : To Delte All Entries in a List 
*  Input Values   :  uiObjectId - Object ID 
*                     pucLineId- LineId
*                     pcDelParent-Parent Delete flag 
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/


int32 ifx_delete_All_ListEntries(IN uint32 puiObjectId,IN uchar8 pucLine){
int32 iCount=0;
switch(puiObjectId){
	case IFX_VMAPI_VS_MISSCALL_REGISTER:
	{
			x_IFX_VMAPI_MissCallRegister xMissCallReg;
			x_IFX_VMAPI_MissCallRegEntry *xMissCallEntry;
			//delete the entry's if they any.....
    memset(&xMissCallReg,0,sizeof(xMissCallReg));
    xMissCallReg.iid.config_owner = IFX_VOIP;
    xMissCallReg.ucLineId = pucLine;
    if (ifx_get_MissCallReg(&xMissCallReg,0) != IFX_VMAPI_SUCCESS)
     return IFX_VMAPI_FAIL;
    if(xMissCallReg.ucNoOfEntries > 0) {
        xMissCallEntry = xMissCallReg.pxCallRegEntries;
        while(xMissCallEntry != NULL && iCount < xMissCallReg.ucNoOfEntries - 1)
        {
                xMissCallEntry->ucIndex=1;
                xMissCallEntry->iid.config_owner = IFX_WEB;
               if(ifx_set_MissCallRegEntry(IFX_OP_DEL,xMissCallEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)!= IFX_VMAPI_SUCCESS)
                         {
                            ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
     												return IFX_VMAPI_FAIL;
                        }
                iCount++;
                 __ifx_list_GetNext((void *)&xMissCallEntry);
        }
			 if(xMissCallEntry != NULL ){
        xMissCallEntry->ucIndex=1;
        xMissCallEntry->iid.config_owner = IFX_WEB;
        if(ifx_set_MissCallRegEntry(IFX_OP_DEL,xMissCallEntry,0)!= IFX_VMAPI_SUCCESS)
         {
             ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
     				 return IFX_VMAPI_FAIL;
          }
				}
  			ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
			}
}
break;
	case IFX_VMAPI_VS_DIALCALL_REGISTER:
	{
		x_IFX_VMAPI_DialCallRegister xDialCallReg;
		x_IFX_VMAPI_DialCallRegEntry *xDialCallEntry;
		//delete the entry's if they any.....
    memset(&xDialCallReg,0,sizeof(xDialCallReg));
    xDialCallReg.iid.config_owner = IFX_VOIP;
    xDialCallReg.ucLineId = pucLine;
    if (ifx_get_DialCallReg(&xDialCallReg,0) != IFX_VMAPI_SUCCESS)
     return IFX_VMAPI_FAIL;
    if(xDialCallReg.ucNoOfEntries > 0) {
        xDialCallEntry = xDialCallReg.pxCallRegEntries;
        while(xDialCallEntry != NULL && iCount < xDialCallReg.ucNoOfEntries - 1 )
        {
                xDialCallEntry->ucIndex=1;
                xDialCallEntry->iid.config_owner = IFX_VOIP;
               if(ifx_set_DialCallRegEntry(IFX_OP_DEL,xDialCallEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)!= IFX_VMAPI_SUCCESS)
                 {
											ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
											return IFX_VMAPI_FAIL;
                 }
                iCount++;
                 __ifx_list_GetNext((void *)&xDialCallEntry);
        }
				if(xDialCallEntry != NULL){
        	xDialCallEntry->ucIndex=1;
        	xDialCallEntry->iid.config_owner = IFX_VOIP;
       		 if(ifx_set_DialCallRegEntry(IFX_OP_DEL,xDialCallEntry,0)!= IFX_VMAPI_SUCCESS)
         {
                     ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
                    return IFX_VMAPI_FAIL;
          }
			}
  		ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
      }


}
break;
case IFX_VMAPI_VS_RECVCALL_REGISTER:
{
x_IFX_VMAPI_RecvCallRegister xRecvCallReg;
x_IFX_VMAPI_RecvCallRegEntry *xRecvCallEntry;
//delete the entry's if they any.....
    memset(&xRecvCallReg,0,sizeof(xRecvCallReg));
    xRecvCallReg.iid.config_owner = IFX_VOIP;
    xRecvCallReg.ucLineId = pucLine;
    if (ifx_get_RecvCallReg(&xRecvCallReg,0) != IFX_VMAPI_SUCCESS)
     return IFX_VMAPI_FAIL;
    if(xRecvCallReg.ucNoOfEntries > 0) {
        xRecvCallEntry = xRecvCallReg.pxCallRegEntries;
        while(xRecvCallEntry !=NULL && iCount < xRecvCallReg.ucNoOfEntries - 1)
        {
                xRecvCallEntry->ucIndex=1;
                xRecvCallEntry->iid.config_owner = IFX_VOIP;
               if(ifx_set_RecvCallRegEntry(IFX_OP_DEL,xRecvCallEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)!= IFX_VMAPI_SUCCESS)
                         {
														ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
														return IFX_VMAPI_FAIL;
                        }
                iCount++;
                 __ifx_list_GetNext((void *)&xRecvCallEntry);
        }
        if(xRecvCallEntry != NULL){
				xRecvCallEntry->ucIndex=1;
        xRecvCallEntry->iid.config_owner = IFX_VOIP;
        if(ifx_set_RecvCallRegEntry(IFX_OP_DEL,xRecvCallEntry,0)!= IFX_VMAPI_SUCCESS)
         {
							 ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
							return IFX_VMAPI_FAIL;
         }
				}
  			ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
      }

}
break;
case IFX_VMAPI_VS_CONTACT_LIST :
{
x_IFX_VMAPI_ContactList xContactList;
x_IFX_VMAPI_ContactListEntry *xContactListEntry;
//delete the entry's if they any.....
    memset(&xContactList,0,sizeof(xContactList));
    xContactList.iid.config_owner = IFX_VOIP;
    xContactList.ucLineId = pucLine;
    if (ifx_get_ContactList(&xContactList,0) != IFX_VMAPI_SUCCESS)
        return IFX_VMAPI_FAIL;
    if( xContactList.ucNoOfEntries > 0 ){
        xContactListEntry = xContactList.pxContactEntries;
        while(xContactListEntry != NULL && iCount < xContactList.ucNoOfEntries-1){
            xContactListEntry->iid.config_owner = IFX_VOIP;
            xContactListEntry->ucIndex=1;
           if( ifx_set_ContactListEntry(IFX_OP_DEL,xContactListEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)!= IFX_VMAPI_SUCCESS){
							ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
              return IFX_VMAPI_FAIL;
          }
            __ifx_list_GetNext((void *)&xContactListEntry);
            iCount++;
          }
					if(xContactListEntry != NULL){
            xContactListEntry->iid.config_owner = IFX_VOIP;
            xContactListEntry->ucIndex=1;
            if( ifx_set_ContactListEntry(IFX_OP_DEL,xContactListEntry,0) != IFX_VMAPI_SUCCESS){
							ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
							return IFX_VMAPI_FAIL;
						}
					}
				ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
      }
}
break;

case IFX_VMAPI_VS_COMMON_CONTACT_LIST :
{
x_IFX_VMAPI_ContactList xContactList;
x_IFX_VMAPI_ContactListEntry *xContactListEntry;
//delete the entry's if they any.....
    memset(&xContactList,0,sizeof(xContactList));
    xContactList.iid.config_owner = IFX_VOIP;
    xContactList.ucLineId = pucLine;
    if (ifx_get_CommonContactList(&xContactList,0) != IFX_VMAPI_SUCCESS)
        return IFX_VMAPI_FAIL;
    if( xContactList.ucNoOfEntries > 0 ){
        xContactListEntry = xContactList.pxContactEntries;
        while(xContactListEntry != NULL && iCount < xContactList.ucNoOfEntries-1){
            xContactListEntry->iid.config_owner = IFX_VOIP;
            xContactListEntry->ucIndex=1;
            if(ifx_set_CommonContactListEntry(IFX_OP_DEL,xContactListEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)!= IFX_VMAPI_SUCCESS){
            	ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
							  return IFX_VMAPI_FAIL;
							}
            __ifx_list_GetNext((void *)&xContactListEntry);
            iCount++;
          }
      		if(xContactListEntry != NULL){  
			    	xContactListEntry->iid.config_owner = IFX_VOIP;
            xContactListEntry->ucIndex=1;
            if(ifx_set_CommonContactListEntry(IFX_OP_DEL,xContactListEntry,0) != IFX_VMAPI_SUCCESS){
        				ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST); 
				     		return IFX_VMAPI_FAIL;
						}
				}
			
			ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
      }
}
break;
default:
		return IFX_VMAPI_FAIL;
}

return IFX_VMAPI_SUCCESS;
}

// API to get List Action Info
int32 LTQ_get_ActionInfo(IN uint32 uiOperation,OUT uint32 *uiInFlag){
/***  PROLOG BLOCK   ***/
  if (uiOperation == IFX_OP_DEL ) {
   	*uiInFlag |= IFX_F_DELETE;
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Operation is IFX_OP_DEL\n");
  }
  else if(uiOperation == IFX_OP_MOD) {
    *uiInFlag |= IFX_F_MODIFY;
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Operation is IFX_OP_MODIFY\n");
  }
  else if(uiOperation == IFX_OP_ADD && IFX_MODIFY_F_NOT_SET(*uiInFlag)) {
    *uiInFlag |= IFX_F_INT_ADD;
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Operation is IFX_OP_ADD\n");
  }
  else {
    return IFX_VMAPI_FAIL;
  }

return IFX_VMAPI_SUCCESS;

}

#ifdef DECT_SENSORS_SUPPORT
uint32 LTQ_get_ObjectId(uint32 uiObjType){
uint32 uiObjectId = 0;
	switch(uiObjType){
			case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY: /*!< Motion sensor List Entry */
							uiObjectId = IFX_VMAPI_OBJ_MOTION_SENSOR_ENTRY;
			break;
			case IFX_VMAPI_VS_MOTION_SENSOR_LIST: /*!< Motion sensor List */
							uiObjectId = IFX_VMAPI_OBJ_MOTION_SENSOR_LIST;
			break;

			case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY: /*!< Smoke sensor List Entry */
							uiObjectId = IFX_VMAPI_OBJ_SMOKE_SENSOR_ENTRY;
			break;
			case IFX_VMAPI_VS_SMOKE_SENSOR_LIST: /*!< Somke Sensor List  */
							uiObjectId = IFX_VMAPI_OBJ_SMOKE_SENSOR_LIST;
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_ENTRY: /*!< Power sensor List Entry */
							uiObjectId = IFX_VMAPI_OBJ_POWER_SENSOR_ENTRY;
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_LIST: /*!< Power sensor List  */
							uiObjectId = IFX_VMAPI_OBJ_POWER_SENSOR_LIST;
			break;

			case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY: /*!< Smoke sensor Alaram List Entry */
							uiObjectId = IFX_VMAPI_OBJ_SMOKE_SENSOR_ALARAM_ENTRY;
			break;

			case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST: /*!< Smoke sensor Alaram List  */
							uiObjectId = IFX_VMAPI_OBJ_SMOKE_SENSOR_ALARAM_LIST;
			break;

			case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY: /*!< Motion sensor Alaram List Entry */
							uiObjectId = IFX_VMAPI_OBJ_MOTION_SENSOR_ALARAM_ENTRY;
			break;

			case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST: /*!<  Motion sensor Alaram List  */
							uiObjectId = IFX_VMAPI_OBJ_MOTION_SENSOR_ALARAM_LIST;
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY: /*!< Power sensor read List Entry */
							uiObjectId = IFX_VMAPI_OBJ_POWER_SENSOR_READ_ENTRY;
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST: /*!<  Power sensor read List  */
							uiObjectId = IFX_VMAPI_OBJ_POWER_SENSOR_READ_LIST;
			break;
			
	}

return uiObjectId;
}

/******************************************************************************
*  Function Name  : LTQ_get_SensorListEntry
*  Description    : Get api to get SensorListEntry object.
*  Input Values   : uiInFlag - Input flags
*		    uiSensorType - Sensor Type			
*  Output Values  : pxSensorListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_SensorEntry (IN_OUT void  *pvSensorEtr, 
											 IN uint32 uiSensorType,
                       IN   uint32  uiInFlag)
{
	uint32 uiObjectId = LTQ_get_ObjectId(uiSensorType);
	IFX_ID *iid;
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		      "Entering Function \n");
	switch(uiSensorType){
			case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
			case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
						iid = &((x_LTQ_VMAPI_SensorList_Entry*)pvSensorEtr)->iid;	
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
						iid = &((x_LTQ_VMAPI_PowerSensor_Entry*)pvSensorEtr)->iid;
			break;
	
			default:
						return IFX_VMAPI_FAIL;

	}

	return IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
                                       iid,
                                       pvSensorEtr,
                                       uiInFlag);
}

/******************************************************************************
*  Function Name  : ifx_get_SensorList
*  Description    : Get api to get Senor List.
*  Input Values   : uiInFlag - Input flags, uiObjType - Sensor type (motion/smoke)
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_SensorList (IN_OUT  void *pvSensorList,
											 IN uint32 uiSensorListType,
                       IN   uint32  uiInFlag)
{
	uint32 uiObjectId = LTQ_get_ObjectId(uiSensorListType);
	IFX_ID *iid;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			      "Entering Function \n");
  switch(uiSensorListType){

		case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
		case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
				   iid=&((x_LTQ_SensorList*)pvSensorList)->iid;
		break;

		case IFX_VMAPI_VS_POWER_SENSOR_LIST:
				  iid=&((x_LTQ_VMAPI_PowerSensor_List*)pvSensorList)->iid;
		break;

		default:
					return IFX_VMAPI_FAIL;
  }
  if(iid->config_owner != IFX_TR69) {
		    iid -> pcpeId.Id = 1;
		    iid -> cpeId.Id = 1;
  	}
	
	return  IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
				         	                     iid,
			                 	            	 pvSensorList,
		                             	     uiInFlag);
}

/******************************************************************************
*  Function Name  : LTQ_get_SensorAlaramEntry
*  Description    : Get api to get Sensor Alaram List Entry.
*  Input Values   : uiInFlag - Input flags
*       uiSensorType - Sensor Type      
*  Output Values  : pxSensorAlaramEtr - pointer to Sensor Alaram List object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_SensorAlaramEntry (IN_OUT void  *pvSensorRead,
                       IN uint32 uiSensorReadType,
                       IN   uint32  uiInFlag)
{
	uint32 uiObjectId = LTQ_get_ObjectId(uiSensorReadType);
	IFX_ID *iid;
	
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");
	switch(uiSensorReadType){

			case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
			case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
					   iid=&((x_LTQ_SensorAlaram_Entry*)pvSensorRead)->iid;
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
					  iid=&((x_LTQ_VMAPI_PowerSensor_ReadEntry*)pvSensorRead)->iid;
			break;

			default:
						return IFX_VMAPI_FAIL;
			
	}

	return IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
                                       iid,
                                       pvSensorRead,
                                       uiInFlag);

}



/******************************************************************************
*  Function Name  : ifx_get_SensorAlaramList
*  Description    : Get api to get Senor List.
*  Input Values   : uiInFlag - Input flags, uiObjType - Sensor type (motion/smoke)
*  Output Values  : pxSensorAlaramList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_SensorAlaramList (IN_OUT  void  *pvSensorReadList,
                       IN uint32 uiSensorListType,
                       IN   uint32  uiInFlag)
{
uint32 uiObjectId = LTQ_get_ObjectId(uiSensorListType);
IFX_ID *iid;
uint32 uiSensorId,iCpeIdSensor;
char8 acChildSection[100]="\0",acParentSection[100]="\0";
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");
	switch(uiSensorListType){
		
				case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST:
				{
					iid=&((x_LTQ_VMAPI_SensorAlaram_List*)pvSensorReadList)->iid;
					uiSensorId=((x_LTQ_VMAPI_SensorAlaram_List*)pvSensorReadList)->uiSensorId;
				}
				break;

				case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:
				{
						iid=&((x_LTQ_VMAPI_SensorAlaram_List*)pvSensorReadList)->iid;
		      	uiSensorId=((x_LTQ_VMAPI_SensorAlaram_List*)pvSensorReadList)->uiSensorId;
			 	}
				break;

				case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:
				{
						iid=&((x_LTQ_VMAPI_PowerSensor_ReadList*)pvSensorReadList)->iid;
		      	uiSensorId=((x_LTQ_VMAPI_PowerSensor_ReadList*)pvSensorReadList)->uiSensorId;
			 	}
				break;

				default:
						return IFX_VMAPI_FAIL;
	}
	sprintf(acChildSection,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId + 1));
	sprintf(acParentSection,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	IFX_VMAPI_Get_CpeId_opt(acChildSection,uiSensorId,&iCpeIdSensor);
  iid->pcpeId.Id = iCpeIdSensor;
  IFX_VMAPI_Get_CpeId_opt(acParentSection,uiSensorId,&iCpeIdSensor);
  iid->cpeId.Id = iCpeIdSensor;
	return  IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
		                                   iid,
			                                 pvSensorReadList,
				                               uiInFlag);
}


/******************************************************************************
*  Function Name  : LTQ_set_SensorList
*  Description    : Set api to set Sensor list object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxSensorList - Pointer to the object to be set
								     uiSensorListType - Object/sensor type id	
*  Output Values  : pxSenosrList - pointer to Sensorlist object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_SensorList(IN uint32  uiOperation,
                      IN  void *pvSensorList,
											IN uint32 uiSensorListType,
                      IN uint32  uiInFlag)
{
 IFX_ID iid, piid;
 int32 iInstanceIndex = -1 ;
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8 bufName[50]; /* buffer used to hold config data */
	x_LTQ_VMAPI_SensorList *pxSensorList = NULL;
	x_LTQ_VMAPI_PowerSensor_List *pxPowerSensorList = NULL;
  x_LTQ_VMAPI_SensorList xOldSensorList={{{{0}}}};
  x_LTQ_VMAPI_PowerSensor_List xOldPowerSensorList={{{{0}}}};

  int32 ret = IFX_VMAPI_FAIL; /* return value */
  uint32 uiObjectId = LTQ_get_ObjectId(uiSensorListType);

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");


  /***  PROLOG BLOCK   ***/
	if(	LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
			  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
				 "Error : Operation Is Not Supported\n");
				return IFX_VMAPI_FAIL;
	}

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */

  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }
  memset(&iid,0,sizeof(iid));
	
//this is for cpeid updation in case of delete n new add
  IFX_VMAPI_STRCPY(bufName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  IFX_VMAPI_STRCAT(bufName,
                  "_CpeId");


		switch(uiSensorListType){
						
						case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
						case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
							pxSensorList = (x_LTQ_VMAPI_SensorList *)pvSensorList;
							  /* Validate the paramters :: make sure that pointers and flags are proper */
							  IFX_VALIDATE_PTR(pxSensorList);
							  CHECK_ACS_SESSION_OWNER_COMBINATION(pxSensorList->iid.config_owner);

									IFX_VMAPI_STRCPY(pxSensorList->iid.cpeId.secName,
                									  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

							  /* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
						     CpeId is already passed to it. */
							  {
									    pxSensorList->iid.pcpeId.Id = 1;
									    pxSensorList->iid.cpeId.Id = 1;
							  }
							  iid = pxSensorList ->iid;
						break;

						case IFX_VMAPI_VS_POWER_SENSOR_LIST:
									pxPowerSensorList = (x_LTQ_VMAPI_PowerSensor_List *)pvSensorList;
                /* Validate the paramters :: make sure that pointers and flags are proper */
                IFX_VALIDATE_PTR(pxPowerSensorList);
                CHECK_ACS_SESSION_OWNER_COMBINATION(pxPowerSensorList->iid.config_owner);

                  IFX_VMAPI_STRCPY(pxPowerSensorList->iid.cpeId.secName,
                                    IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

                /* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
                 CpeId is already passed to it. */
                {
                      pxPowerSensorList->iid.pcpeId.Id = 1;
                      pxPowerSensorList->iid.cpeId.Id = 1;
                }
                iid = pxPowerSensorList ->iid;

						break;

		}

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }

  }


/*** ID ALLOCATION BLOCK  ***/
  if(IFX_INT_ADD_F_SET(uiInFlag))  {
    //uiInstanceId = new instance id or -1;
  		memset(&piid,0,sizeof(piid));
		  piid.cpeId.Id = iid.pcpeId.Id;
		  sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
    if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
      return IFX_VMAPI_FAIL;
    }
		  pxSensorList->iid = iid;
    /* increment the next cpe id for object */
    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
                IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  }

	if(IFX_MODIFY_F_SET(uiInFlag) ) {
			x_LTQ_VMAPI_SensorList_Entry *pxTemp;
		  x_LTQ_VMAPI_PowerSensor_Entry *pxPowTemp;
			switch(uiSensorListType){
						case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
						case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
							     memset(&xOldSensorList,0,sizeof(x_LTQ_VMAPI_SensorList));
							     memcpy(&xOldSensorList,pxSensorList,sizeof(x_LTQ_VMAPI_SensorList));

									  pxSensorList->pxSensorEntries=NULL;
								    if(LTQ_get_SensorList((void*)pxSensorList ,uiSensorListType,IFX_F_DEFAULT) != IFX_SUCCESS){
													      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
											          "Failed to get the Sensor List !!\n\n");
														     return IFX_VMAPI_FAIL;
    								}
										//Count updatation from the rc.conf(child insertion)
									    pxSensorList->ucNoOfEntries= 0;
									    pxTemp=pxSensorList->pxSensorEntries;
									    while(pxTemp !=NULL)
									    {
											        pxSensorList->ucNoOfEntries++;
												      __ifx_list_GetNext((void *)&pxTemp);
									    }
											pxSensorList ->  bAllPowerOn = xOldSensorList.bAllPowerOn;
											pxSensorList ->  bToneAlaram = xOldSensorList.bToneAlaram;
											IFX_VMAPI_STRCPY(pxSensorList->ucPresetNum,xOldSensorList.ucPresetNum);	
							break;

						case IFX_VMAPI_VS_POWER_SENSOR_LIST:
									memset(&xOldPowerSensorList,0,sizeof(x_LTQ_VMAPI_PowerSensor_List));
                   memcpy(&xOldPowerSensorList,pxPowerSensorList,sizeof(x_LTQ_VMAPI_PowerSensor_List));

                    pxPowerSensorList->pxSensorEntries=NULL;
                    if(LTQ_get_SensorList((void*)pxPowerSensorList ,uiSensorListType,IFX_F_DEFAULT) != IFX_SUCCESS){
                                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                "Failed to get the Sensor List !!\n\n");
                                 return IFX_VMAPI_FAIL;
                    }
                    //Count updatation from the rc.conf(child insertion)
                      pxPowerSensorList->ucNoOfEntries= 0;
                      pxPowTemp=pxPowerSensorList->pxSensorEntries;
                      while(pxPowTemp !=NULL)
                      {
                              pxPowerSensorList->ucNoOfEntries++;
                              __ifx_list_GetNext((void *)&pxPowTemp);
                      }
											pxPowerSensorList ->  bAllPowerOn = xOldPowerSensorList.bAllPowerOn;
						break;
		}
}
  IFX_VMAPI_LOCK(uiLock);
/* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pvSensorList,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List\n");
    goto EndLabel;

  }

  /*** NOTIFICATION BLOCK ***/
#ifndef LIST_ACCESS
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  if(IFX_MODIFY_F_SET(uiInFlag)/*||IFX_DELETE_F_SET(uiInFlag)||IFX_INT_ADD_F_SET(uiInFlag)*/) {

      if(IFX_VMAPI_IsObjectRegistered(uiSensorListType) == IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending The Notification\n");

			switch(uiSensorListType){
						case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
						case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
      			      if(pxSensorList->pxSensorEntries == NULL){
            			       xOldSensorList.pxSensorEntries = NULL;
                	}

				        if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                                (uiSensorListType,(void *)&xOldSensorList,(void *)pxSensorList))
                                {
        						                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                        "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");

                                        ret = IFX_VMAPI_FAIL;
                    								    goto EndLabel;
                                }
						break;
								
						case IFX_VMAPI_VS_POWER_SENSOR_LIST:
      			      if(pxPowerSensorList->pxSensorEntries == NULL){
            			       xOldPowerSensorList.pxSensorEntries = NULL;
                	}

				        if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                                (uiSensorListType,(void *)&xOldPowerSensorList,(void *)pxPowerSensorList))
                                {
        						                IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                        "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");

                                        ret = IFX_VMAPI_FAIL;
                    								    goto EndLabel;
                                }
					break;
				}
    	}
 }
  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
#endif


	if (ifx_get_conf_index_and_nv_pairs(&iid,
		              iInstanceIndex,
			            IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
				          xNVList.unNoOfNVPairs,
					        xNVList.axNameValue,
						      uiInFlag) != IFX_SUCCESS) {

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : ifx_get_conf_index_and_nv_pairs failed \n");
    goto EndLabel;

	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
		  /* compare fvp array from structure with fvp array from file and build changed fvp */
			if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],
				                         xNVList.unNoOfNVPairs,xNVList.axNameValue,
					                       &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
        goto EndLabel;

			}
  }
/*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  /* Backup rc.conf before proceeding with configuration */
  if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      }
#endif
      goto EndLabel;
    } else {
        /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Warning : ifx_CompactCfgSection failed \n");
          }
        }

  if (IFX_INT_ADD_F_SET(uiInFlag)) {
						IFX_VMAPI_Update_CpeId_opt(bufName, 1,iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
           /* Update the CpeId corresponding to the Line Id */
           IFX_VMAPI_Update_CpeId_opt(bufName, 1,0);
        }
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " Cannot write to the flash\n");
        }
#endif
}


EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
      IFX_VMAPI_FREE(pxChangedNvList);
  }
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function \n");
  return ret;

}

/******************************************************************************
*  Function Name  : LTQ_set_SensorEntry
*  Description    : Set api to get SesorListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*		    uiObjType - Sensor Type 
*                   pxSensorListEtr - Pointer to the object to be set
*  Output Values  : pxSensorListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_SensorEntry(IN uint32  uiOperation,
                      IN  void *pvSensorListEtr,
								      IN  uint32 uiSensorType,
                      IN uint32  uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ;

  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */

  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8 bufName[50]; /* buffer used to hold config data */
//These 2 variables are used during the add or delete operation in order to set cpeid entry
	uint32 ucIndex=0;

	
  int32 ret = IFX_VMAPI_FAIL; /* return value */
	x_LTQ_VMAPI_SensorList_Entry *pxSensorListEtr = NULL;
	x_LTQ_VMAPI_PowerSensor_Entry *pxPowerSensorListEtr =NULL; 
  x_LTQ_VMAPI_SensorList xOldSensorList={{{{0}}}};
  x_LTQ_VMAPI_PowerSensor_List xOldPowerSensorList={{{{0}}}};
  uint32 uiObjectId = LTQ_get_ObjectId(uiSensorType); //this Object id.

  /***  PROLOG BLOCK   ***/
	if(	LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
	}

	/*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }
  
	memset(&iid,0,sizeof(iid));
	/* Validate the paramters :: make sure that pointers and flags are proper */
	switch(uiSensorType){  
		
			case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
			case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
							pxSensorListEtr = (x_LTQ_VMAPI_SensorList_Entry *)pvSensorListEtr;
							IFX_VALIDATE_PTR(pxSensorListEtr);
							CHECK_ACS_SESSION_OWNER_COMBINATION(pxSensorListEtr->iid.config_owner);
							//Get the section Name.....
							IFX_VMAPI_STRCPY(pxSensorListEtr->iid.cpeId.secName,
													IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
							//Get the parent section name 
							IFX_VMAPI_STRCPY(pxSensorListEtr->iid.pcpeId.secName,
													IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
							//Get the Parent CPEId for child
							pxSensorListEtr->iid.pcpeId.Id = 1;
							ucIndex=pxSensorListEtr->ucIndex;
							iid = pxSensorListEtr->iid;
			break;

			case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
							pxPowerSensorListEtr =(x_LTQ_VMAPI_PowerSensor_Entry *)pvSensorListEtr;	
							IFX_VALIDATE_PTR(pxPowerSensorListEtr);
							CHECK_ACS_SESSION_OWNER_COMBINATION(pxPowerSensorListEtr->iid.config_owner);
							//Get the section Name.....
							IFX_VMAPI_STRCPY(pxPowerSensorListEtr->iid.cpeId.secName,
													IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
							//Get the parent section name 
							IFX_VMAPI_STRCPY(pxPowerSensorListEtr->iid.pcpeId.secName,
													IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
							//Get the Parent CPEId for child
							pxPowerSensorListEtr->iid.pcpeId.Id = 1;
							iid = pxPowerSensorListEtr->iid;
							ucIndex=pxPowerSensorListEtr->ucIndex;
			break;
	}
  

//this is for cpeid updation in case of delete n add
	IFX_VMAPI_STRCPY(bufName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	IFX_VMAPI_STRCAT(bufName,
                  "_CpeId");
  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
      return ret;
    }
 }


  /*** ID ALLOCATION BLOCK  ***/

// keeping the old parent object back up to  send notification..... only case of add/delete sensor
	if((IFX_INT_ADD_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag)) && !(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) ) {
		  switch(uiSensorType){            
							case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
							case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
										memset(&xOldSensorList,0,sizeof(xOldSensorList));
										xOldSensorList.iid.config_owner = IFX_WEB;
										if(IFX_VMAPI_SUCCESS != LTQ_get_SensorList((void*)&xOldSensorList,uiSensorType - 1,0)){
																IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Get SensorList failed\n");
																return IFX_VMAPI_FAIL;
										}
							break;

						case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
									memset(&xOldPowerSensorList,0,sizeof(xOldPowerSensorList));
									xOldPowerSensorList.iid.config_owner = IFX_WEB;
									if(IFX_VMAPI_SUCCESS != LTQ_get_SensorList((void*)&xOldPowerSensorList,uiSensorType - 1,0)){
																		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Get SensorList failed\n");
																		printf("<LTQ_set_SensorEntry> Exit 3 \n");
																		return IFX_VMAPI_FAIL;
								 }
						break;
		}
	}
//Generate the cpeid,entryid, and index in the case of ADD operation
	if  (IFX_INT_ADD_F_SET(uiInFlag))  {
				piid.cpeId.Id = iid.pcpeId.Id;
				sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
				x_LTQ_VMAPI_SensorList xSensorList;
				x_LTQ_VMAPI_PowerSensor_List xPowerSensorList;
				if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
								IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
								"Failed to get the iid !!\n\n");
								IFX_VMAPI_UNLOCK(uiLock);
					      return IFX_VMAPI_FAIL;
				}
    /* increment the next cpe id for the object */
		    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
					           IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	switch(uiSensorType){
					case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
					case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
								memset(&xSensorList,0,sizeof(xSensorList));
								xSensorList.iid.config_owner = IFX_WEB;
								if(IFX_VMAPI_SUCCESS != LTQ_get_SensorList((void *)&xSensorList,uiSensorType - 1,0)){
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
												"Failed to get the List entry Reg\n\n");
										return IFX_VMAPI_FAIL;
								}
								pxSensorListEtr->iid = iid;
								pxSensorListEtr->ucIndex=xSensorList.ucNoOfEntries+1;
								ifx_vmapi_freeObjectList(&xSensorList,uiSensorType - 1);
					break;
		
					case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
								memset(&xPowerSensorList,0,sizeof(xPowerSensorList));
								xPowerSensorList.iid.config_owner = IFX_WEB;
								if(IFX_VMAPI_SUCCESS != LTQ_get_SensorList((void *)&xPowerSensorList,uiSensorType - 1,0)){
								IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
										"Failed to get the List entry Reg\n\n");
										 return IFX_VMAPI_FAIL;
								}
								pxPowerSensorListEtr->iid = iid;
								pxPowerSensorListEtr->ucIndex=ucIndex=xPowerSensorList.ucNoOfEntries+1;
								ifx_vmapi_freeObjectList(&xPowerSensorList,uiSensorType - 1);
					break;
		}

	}
  IFX_VMAPI_LOCK(uiLock);
/* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvSensorListEtr,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List \n");
    goto EndLabel;

}

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {

									IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
											 "Error : ifx_get_conf_index_and_nv_pairs failed in \n");
									goto EndLabel;

	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    /* compare fvp array from structure with fvp array from file and build changed fvp */
    if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
        goto EndLabel;

      }
  }


  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File\n");
      }
#endif
      goto EndLabel;
    } else {
      /* Config file is updated */
       /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,IFX_VMAPI_GET_OBJ_NAME(uiObjectId), uiInFlag) != IFX_SUCCESS) {
								/*  Now can not do anything...just continue */
								IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Warning : ifx_CompactCfgSection failed \n");
          }
        }
	 if (IFX_INT_ADD_F_SET(uiInFlag)) {
     /* Update the CpeId corresponding to the Line Id */
    		IFX_VMAPI_Update_CpeId_opt(bufName,ucIndex,iid.cpeId.Id);
     }

      if ((IFX_DELETE_F_SET(uiInFlag)) ) {
        if(iid.config_owner == IFX_WEB || iid.config_owner == IFX_VOIP)
        {
            /* Update the CpeId corresponding to the Line Id */
                IFX_VMAPI_Update_CpeId_opt(bufName,ucIndex,0);
        }
      }
  // Updatating the parent and sending notification in case of add/delete.....
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) && ( IFX_INT_ADD_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) ) {
			switch(uiSensorType){
							
							case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
							case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
										if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_SensorList(IFX_OP_MOD,(void*)&xOldSensorList,uiSensorType - 1,0))){
																    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
																		goto EndLabel;
										}
							break;

							case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
										if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_SensorList(IFX_OP_MOD,(void*)&xOldPowerSensorList,uiSensorType - 1,0))){
																    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
                        goto EndLabel;
										}
							break;
			}
	}

        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, " Cannot write to the flash\n");
        }
#endif

}

EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function :\n");
  return ret;

}

/******************************************************************************
*  Function Name  : LTQ_set_SensorAlaramEntry
*  Description    : Set api to set Sensor Alaram list Entry
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxAlaramEtr - Pointer to the object to be set
*  Output Values  : pxAlaramEtr - pointer to Alaram entry
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_SensorAlaramEntry(IN uint32  uiOperation,
										          IN  /*x_LTQ_SensorAlaram_Entry*/ void *pvReadEtr,
															IN uint32 uiSensorType,
															IN uint32  uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ;

  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */

  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
  uchar8 bufName[50]; /* buffer used to hold config data */
  char8 acSecBuf[50]; /* buffer used to hold config data */
  
  int32 ret = IFX_VMAPI_FAIL; /* return value */
  uint32  iCpeIdReg;
	x_LTQ_VMAPI_SensorAlaram_Entry *pxAlaramEtr = NULL;
  x_LTQ_VMAPI_SensorAlaram_List xOldAlaramList={{{{0}}}};
  
	x_LTQ_VMAPI_PowerSensor_ReadEntry *pxReadEtr = NULL;
  x_LTQ_VMAPI_PowerSensor_ReadList xOldReadList={{{{0}}}};

	uint32 uiObjectId = LTQ_get_ObjectId(uiSensorType); //this Object id.

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entering Function \n");
  
  /***  PROLOG BLOCK   ***/
	if(	LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
	}
	
	/*** VALIDATION BLOCK ***/
	/* For operation other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
						IFX_VALIDATE_FLAGS(uiInFlag);
  }
  memset(&iid,0,sizeof(iid));
	switch(uiSensorType){
				 case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
				 case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
							 pxAlaramEtr = (x_LTQ_VMAPI_SensorAlaram_Entry *)pvReadEtr;
							/* Validate the paramters :: make sure that pointers and flags are proper */
							IFX_VALIDATE_PTR(pxAlaramEtr);
							CHECK_ACS_SESSION_OWNER_COMBINATION(pxAlaramEtr->iid.config_owner);

							IFX_VMAPI_STRCPY(pxAlaramEtr->iid.cpeId.secName,
													IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

							//this is for cpeid updation in case of delete n add
						  IFX_VMAPI_STRCPY(bufName,
					                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

						  IFX_VMAPI_STRCAT(bufName,
			      		            "_CpeId");

				 			IFX_VMAPI_STRCPY(pxAlaramEtr->iid.pcpeId.secName,
							                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
							sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
		    			IFX_VMAPI_Get_CpeId_opt(/*"MotionSensorAlaramList_CpeId"*/acSecBuf,pxAlaramEtr -> uiSensorId,&iCpeIdReg);
		    			pxAlaramEtr->iid.pcpeId.Id = iCpeIdReg;
  						iid = pxAlaramEtr->iid;
					break;
	
					case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
								pxReadEtr = (x_LTQ_VMAPI_PowerSensor_ReadEntry *)pvReadEtr;
								 /* Validate the paramters :: make sure that pointers and flags are proper */
								IFX_VALIDATE_PTR(pxReadEtr);
		            CHECK_ACS_SESSION_OWNER_COMBINATION(pxReadEtr->iid.config_owner);

				        IFX_VMAPI_STRCPY(pxReadEtr->iid.cpeId.secName,
                        IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
                IFX_VMAPI_STRCPY(pxReadEtr->iid.pcpeId.secName,
                                IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
					        sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
                  IFX_VMAPI_Get_CpeId_opt(/*"MotionSensorAlaramList_CpeId"*/acSecBuf,pxReadEtr -> uiSensorId,&iCpeIdReg);
                  pxReadEtr->iid.pcpeId.Id = iCpeIdReg;
                  iid = pxReadEtr->iid;	
				 break;
		}

/* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
						IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid \n");
						goto EndLabel;
    }
  }



  /*** ID ALLOCATION BLOCK  ***/

// keeping the old parent object back up to  send notification.....
         if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
						switch(uiSensorType){
				       case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
				       case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
           		      memset(&xOldAlaramList,0,sizeof(xOldAlaramList));
           		      xOldAlaramList.uiSensorId = pxAlaramEtr->uiSensorId ;
               		  xOldAlaramList.iid.config_owner = IFX_WEB;
				            if(IFX_VMAPI_SUCCESS != LTQ_get_SensorAlaramList((void *)&xOldAlaramList,uiSensorType -1,0)){
         				             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Get Sensor List failed\n");
               					     return IFX_VMAPI_FAIL;
				            }
							break;  

							case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
					 				memset(&xOldReadList,0,sizeof(xOldReadList));
                  xOldReadList.uiSensorId = pxReadEtr->uiSensorId ;
                  xOldReadList.iid.config_owner = IFX_WEB;
									if(IFX_VMAPI_SUCCESS != LTQ_get_SensorAlaramList((void *)&xOldReadList,uiSensorType -1,0)){
												 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Get Sensor List failed\n");
												 return IFX_VMAPI_FAIL;
								 }	
							break;
					}			
			}

	if  (IFX_INT_ADD_F_SET(uiInFlag))  {
				piid.cpeId.Id = iid.pcpeId.Id;
			  sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
				x_LTQ_VMAPI_SensorAlaram_List xSensorAlaramList;
				x_LTQ_VMAPI_PowerSensor_ReadList xSensorReadList;
			  if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
					  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						  "Failed to get the iid !!\n\n");
						IFX_VMAPI_UNLOCK(uiLock);
						return IFX_VMAPI_FAIL;
				}
				switch(uiSensorType){
				      case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
				      case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
								    pxAlaramEtr->iid = iid;
								    ifx_get_EntryId(uiSensorType, &pxAlaramEtr->uiEntryId);
									  memset(&xSensorAlaramList,0,sizeof(xSensorAlaramList));
						        xSensorAlaramList.uiSensorId = pxAlaramEtr->uiSensorId;
						        xSensorAlaramList.iid.config_owner = IFX_WEB;
						        if(IFX_VMAPI_SUCCESS != LTQ_get_SensorAlaramList((void *)&xSensorAlaramList,uiSensorType -1,0)){
									        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							            "Failed to get the List entry Reg\n\n");
					                return IFX_VMAPI_FAIL;
						        }
									  pxAlaramEtr->ucIndex=xSensorAlaramList.ucNoOfEntries+1;
									  ifx_vmapi_freeObjectList(&xSensorAlaramList, uiSensorType -1);
						break;

					 	case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY :
									pxReadEtr->iid = iid;
                  ifx_get_EntryId(uiSensorType, &pxReadEtr->uiEntryId);
                  memset(&xSensorReadList,0,sizeof(xSensorReadList));
                  xSensorReadList.uiSensorId = pxReadEtr->uiSensorId;
                  xSensorReadList.iid.config_owner = IFX_WEB;
                  if(IFX_VMAPI_SUCCESS != LTQ_get_SensorAlaramList((void *)&xSensorReadList,uiSensorType -1,0)){
                       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Failed to get the List entry Reg\n\n");
                       return IFX_VMAPI_FAIL;
                  }
                  pxReadEtr->ucIndex=xSensorReadList.ucNoOfEntries+1;
                  ifx_vmapi_freeObjectList(&xSensorReadList, uiSensorType -1);
						break;
 			 }

   /* increment the next cpe id for this object */
	    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
           					     IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	}
  IFX_VMAPI_LOCK(uiLock);
 /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvReadEtr,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List \n");
    goto EndLabel;
	}

	if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : ifx_get_conf_index_and_nv_pairs failed in \n");
    goto EndLabel;
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
 if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    /* compare fvp array from structure with fvp array from file and build changed fvp */
    if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
        goto EndLabel;
    }
  }


  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File\n");
      }
#endif
      goto EndLabel;
    } else {
      /* Config file is updated */
       /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,IFX_VMAPI_GET_OBJ_NAME(uiObjectId), uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Warning : ifx_CompactCfgSection failed \n");
          }
        }
	if (IFX_INT_ADD_F_SET(uiInFlag)) {
	
     /* Update the CpeId corresponding to the Alaram List */
			switch(uiSensorType){
						case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY: 
									IFX_VMAPI_Update_CpeId_opt("SmokeSensorAlaramEntry_CpeId",
																			(((pxAlaramEtr->uiSensorId-1)*5)+pxAlaramEtr->ucIndex),
																			pxAlaramEtr->iid.cpeId.Id);
						break;
					
						case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:	
									 IFX_VMAPI_Update_CpeId_opt("MotionSensorAlaramEntry_CpeId",
										          (((pxAlaramEtr->uiSensorId-1)*5)+pxAlaramEtr->ucIndex),
											        pxAlaramEtr->iid.cpeId.Id);
						break;

						case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:	
									IFX_VMAPI_Update_CpeId_opt("PowerSensorReadEntry_CpeId",
                            (((pxReadEtr->uiSensorId-1)*10)+pxReadEtr->ucIndex),
											          pxReadEtr->iid.cpeId.Id);
						break;
     }
	}
      if ((IFX_DELETE_F_SET(uiInFlag)) ) {
            /* Update the CpeId corresponding to the Line Id */
				switch(uiSensorType){
					      case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
									    ifx_free_EntryId(uiSensorType, pxAlaramEtr->uiEntryId);
									    IFX_VMAPI_Update_CpeId_opt("SmokeSensorAlaramEntry_CpeId",
                           (((pxAlaramEtr->uiSensorId-1)*5)+pxAlaramEtr->ucIndex),
                            0);
								break;

								case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
			                ifx_free_EntryId(uiSensorType, pxAlaramEtr->uiEntryId);
										  IFX_VMAPI_Update_CpeId_opt("MotionSensorAlaramEntry_CpeId",
											        (((pxAlaramEtr->uiSensorId-1)*5)+pxAlaramEtr->ucIndex),
												      0);
								break;
			
								case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:	
												 ifx_free_EntryId(uiSensorType, pxReadEtr->uiEntryId);
												 IFX_VMAPI_Update_CpeId_opt("PowerSensorReadEntry_CpeId",
																		(((pxReadEtr->uiSensorId-1)*10)+pxReadEtr->ucIndex),
																		0);
								break;
        }
      }
// Updatating the parent and sending notification.....

		switch(uiSensorType){
			       case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
			       case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
 										if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

												if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_SensorAlaramList(IFX_OP_MOD,(void *)&xOldAlaramList,uiSensorType - 1,0))){
               									 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
				                        goto EndLabel;
         								}
						        }else{
           			            memset(&xOldAlaramList,0,sizeof(xOldAlaramList));
                  		      xOldAlaramList.uiSensorId = pxAlaramEtr->uiSensorId ;
                      		  xOldAlaramList.iid.config_owner = IFX_WEB;
										 	     if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_SensorAlaramList(IFX_OP_MOD,(void *)&xOldAlaramList,uiSensorType - 1 ,
																																										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))){
	                      				    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
							                      goto EndLabel;
					          		  }

  								}
							break;
				      
							case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
										if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

                              if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_SensorAlaramList(IFX_OP_MOD,(void *)&xOldReadList,uiSensorType - 1,0))){
                                     IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
                                     goto EndLabel;
                              }
                    }else{
	                          memset(&xOldReadList,0,sizeof(xOldReadList));
                            xOldReadList.uiSensorId = pxReadEtr->uiSensorId ;
                            xOldReadList.iid.config_owner = IFX_WEB;
			                     if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_SensorAlaramList(IFX_OP_MOD,(void *)&xOldReadList,uiSensorType - 1 ,
																																							IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))){
																				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
		                                    goto EndLabel;
                            }
												}
							break;
					}

   /*** DEVICE CONFIGURATION BLOCK ***/
   /* Device configuration is not needed for this object */
   IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
    if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, " Cannot write to the flash\n");
    }
#endif

}
EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function :\n");
  return ret;

}


/******************************************************************************
*  Function Name  : LTQ_set_SensorAlaramList
*  Description    : Set api to set Sensor Alaram List object
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxAlaramList - Pointer to the object to be set
*  Output Values  : pxAlramList - pointer to contactlist object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_SensorAlaramList(IN uint32  uiOperation,
                      IN  void *pvReadList,
		      						IN uint32 uiSensorType,
                      IN uint32  uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ;

  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeIdSensor=0;
  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
	char8 acSecBuf[100]; //this is to store the section Name
  x_LTQ_VMAPI_SensorAlaram_Entry *pxTemp;
  x_LTQ_VMAPI_SensorAlaram_List *pxAlaramList=NULL;
  x_LTQ_VMAPI_SensorAlaram_List xOldAlaramtList={{{{0}}}};

  x_LTQ_VMAPI_PowerSensor_ReadEntry *pxPowTemp;
  x_LTQ_VMAPI_PowerSensor_ReadList *pxReadList=NULL;
  x_LTQ_VMAPI_PowerSensor_ReadList xOldReadList={{{{0}}}};

  uint32 uiObjectId = LTQ_get_ObjectId(uiSensorType); //this Object id.

  int32 ret = IFX_VMAPI_FAIL; /* return value */

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");


  /***  PROLOG BLOCK   ***/
	if(	LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
	}
 
  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */

  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }
  memset(&iid,0,sizeof(iid));


	switch(uiSensorType){

			case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST:
			case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:  
				 	pxAlaramList =(x_LTQ_VMAPI_SensorAlaram_List *)pvReadList;  
						/* Validate the paramters :: make sure that pointers and flags are proper */
		  		IFX_VALIDATE_PTR(pxAlaramList);

		  	  CHECK_ACS_SESSION_OWNER_COMBINATION(pxAlaramList->iid.config_owner);
					IFX_VMAPI_STRCPY(pxAlaramList->iid.cpeId.secName,
								          IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

					sprintf(pxAlaramList->iid.pcpeId.secName, "%s",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 2));
					sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
					IFX_VMAPI_Get_CpeId_opt(/*"MotionSensorEntry_CpeId"*/acSecBuf,pxAlaramList->uiSensorId,&iCpeIdSensor);
		 	   	pxAlaramList->iid.pcpeId.Id = iCpeIdSensor;
					if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
							sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
						  IFX_VMAPI_Get_CpeId_opt(/*"MotionSensorAlaramList_CpeId"*/acSecBuf,pxAlaramList->uiSensorId,&iCpeIdSensor);
			 	   		pxAlaramList->iid.cpeId.Id = iCpeIdSensor;
					}
  				iid = pxAlaramList ->iid;
		break;

		case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:
          pxReadList =(x_LTQ_VMAPI_PowerSensor_ReadList *)pvReadList;
            /* Validate the paramters :: make sure that pointers and flags are proper */
            IFX_VALIDATE_PTR(pxReadList);

          	CHECK_ACS_SESSION_OWNER_COMBINATION(pxReadList->iid.config_owner);

            IFX_VMAPI_STRCPY(pxReadList->iid.cpeId.secName,
                          IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

            sprintf(pxReadList->iid.pcpeId.secName, "%s",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 2));
            sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
            IFX_VMAPI_Get_CpeId_opt(/*"MotionSensorEntry_CpeId"*/acSecBuf,pxReadList->uiSensorId,&iCpeIdSensor);
            pxReadList->iid.pcpeId.Id = iCpeIdSensor;
            if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
              sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
              IFX_VMAPI_Get_CpeId_opt(/*"MotionSensorAlaramList_CpeId"*/acSecBuf,pxReadList->uiSensorId,&iCpeIdSensor);
              pxReadList->iid.cpeId.Id = iCpeIdSensor;
          }
          iid = pxReadList ->iid;
    break;
	}

/* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {

       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }

  }

  memset(&piid,0,sizeof(piid));
  piid.cpeId.Id = iid.pcpeId.Id;
  sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
/*** ID ALLOCATION BLOCK  ***/
  if(IFX_INT_ADD_F_SET(uiInFlag))  {
    if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
      return IFX_VMAPI_FAIL;
    }
	switch(uiSensorType){
				case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST:
				case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:  
  							pxAlaramList->iid = iid;
				break;

				case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:  
  							pxReadList->iid = iid;
				break;	

  }
    /* increment the next cpe id for this object */
    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
                IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
}

if(IFX_MODIFY_F_SET(uiInFlag) ) {

	switch(uiSensorType){
				case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST:
				case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:  
 						    memset(&xOldAlaramtList,0,sizeof(x_LTQ_VMAPI_SensorAlaram_List));
						    memcpy(&xOldAlaramtList,pxAlaramList,sizeof(x_LTQ_VMAPI_SensorAlaram_List));

						    pxAlaramList->pxAlaramEntries=NULL;
						    if(LTQ_get_SensorAlaramList((void *)pxAlaramList, uiSensorType, IFX_F_DEFAULT) != IFX_SUCCESS){
									      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							          "Failed to get the Alaram Reg !!\n\n");
									  			printf("Failed to get the Alaram Reg !!EXIT-1\n");
											    return IFX_VMAPI_FAIL;
						    }

						    pxAlaramList->ucNoOfEntries= 0;
						    pxTemp=pxAlaramList->pxAlaramEntries;
						    while(pxTemp !=NULL)
						    {
							        pxAlaramList->ucNoOfEntries++;
							      __ifx_list_GetNext((void *)&pxTemp);
						    }
				break;
				
				case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:  
								memset(&xOldReadList,0,sizeof(x_LTQ_VMAPI_PowerSensor_ReadList));
                memcpy(&xOldReadList,pxReadList,sizeof(x_LTQ_VMAPI_PowerSensor_ReadList));

                pxReadList->pxPowEntries=NULL;
                if(LTQ_get_SensorAlaramList((void *)pxReadList, uiSensorType, IFX_F_DEFAULT) != IFX_SUCCESS){
                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                        "Failed to get the Alaram Reg !!\n\n");
                          return IFX_VMAPI_FAIL;
                }

                pxReadList->ucNoOfEntries= 0;
                pxPowTemp=pxReadList->pxPowEntries;
                while(pxPowTemp !=NULL)
                {
                      pxReadList->ucNoOfEntries++;
                    __ifx_list_GetNext((void *)&pxPowTemp);
                }
	
			break;	
	}	
}
 IFX_VMAPI_LOCK(uiLock);

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvReadList,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List\n");
    goto EndLabel;
  }

  /*** NOTIFICATION BLOCK ***/
#ifndef LIST_ACCESS
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  if(IFX_MODIFY_F_SET(uiInFlag)/*||IFX_DELETE_F_SET(uiInFlag)||IFX_INT_ADD_F_SET(uiInFlag)*/) {

      if(IFX_VMAPI_IsObjectRegistered(uiSensorType) == IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending The Notification\n");
					switch(uiSensorType){
									case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST:
									case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:  
								      if(pxAlaramList->pxAlaramEntries == NULL){
			             	     xOldAlaramtList.pxAlaramEntries = NULL;
      						    }

											if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
														                    (uiSensorType,(void *)&xOldAlaramtList,(void *)pxAlaramList)){
													  
																					IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                    "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");
																					ret = IFX_VMAPI_FAIL;
																					goto EndLabel;
            		       }
										break;

										case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:
													if(pxReadList->pxPowEntries == NULL){
                                 xOldReadList.pxPowEntries = NULL;
                              }

                        if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                                              (uiSensorType,(void *)&xOldReadList,(void *)pxReadList)){
                                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                        "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");
                                        ret = IFX_VMAPI_FAIL;
                                    goto EndLabel;
                        }

									break;
 					}
			}
		}/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */

	}
#endif

	if (ifx_get_conf_index_and_nv_pairs(&iid,
											              iInstanceIndex,
										                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
										                xNVList.unNoOfNVPairs,
										                xNVList.axNameValue,
										                uiInFlag) != IFX_SUCCESS) {

																		  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																								"Error : ifx_get_conf_index_and_nv_pairs failed \n");
																	    goto EndLabel;
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
    /* compare fvp array from structure with fvp array from file and build changed fvp */
    if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
        goto EndLabel;
      }
  }

 /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
 /* Backup rc.conf before proceeding with configuration */
  if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      }
#endif
      goto EndLabel;
    } else {
        /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Warning : ifx_CompactCfgSection failed \n");
          }
        }

  if (IFX_INT_ADD_F_SET(uiInFlag)) {
					sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
          switch(uiSensorType){
								case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST: 
								case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:
											IFX_VMAPI_Update_CpeId_opt(/*"MotionSensorAlaramList_CpeId"*/acSecBuf, pxAlaramList->uiSensorId,pxAlaramList->iid.cpeId.Id);
								break;
					
								case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:
											IFX_VMAPI_Update_CpeId_opt(/*"SmokeSensorAlaramList_CpeId"*/acSecBuf, pxReadList->uiSensorId,pxReadList->iid.cpeId.Id);	
								break;
					}
	}
	
	if (IFX_DELETE_F_SET(uiInFlag)) {
					sprintf(acSecBuf,"%s_CpeId",IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
          switch(uiSensorType){
									case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST: 
									case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:
												IFX_VMAPI_Update_CpeId_opt(/*"MotionSensorAlaramList_CpeId"*/acSecBuf, pxAlaramList->uiSensorId,0);
									break;
						
									case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:
												IFX_VMAPI_Update_CpeId_opt(/*"SmokeSensorAlaramList_CpeId"*/acSecBuf, pxReadList->uiSensorId,0);	
									break;
					}
  }
        /*** DEVICE CONFIGURATION BLOCK ***/
  /* Device configuration is not needed for this object */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " Cannot write to the flash\n");
        }
#endif
}


EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
      IFX_VMAPI_FREE(pxChangedNvList);
  }
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function \n");
  return ret;

}


#endif

/******************************************************************************
*  Function Name  : LTQ_get_ContactList
*  Description    : Get api to get Contact list Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_ContactList (IN_OUT  /*x_IFX_VMAPI_ContactList*/ void  *pxContactList,
															 uint32 uiListType,
															 uint32 uiObjectId,
                       IN   uint32  uiInFlag)
{
 uint32 iCpeId, iCpeIdLine;
 IFX_ID iid;
 uchar8 ucLineId = 1;
		
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function \n");
	printf("######################< LTQ_get_ContactList > : Enterig with object id : %d & type %d\n",uiObjectId,uiListType);

	iid = ((x_IFX_VMAPI_ContactList*)pxContactList)->iid;
	ucLineId = ((x_IFX_VMAPI_ContactList*)pxContactList)->ucLineId;
  if(iid.config_owner != IFX_TR69) {
			switch(uiListType) {
					case IFX_VMAPI_VS_CONTACT_LIST:
								IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",ucLineId,&iCpeIdLine);
								iid.pcpeId.Id = iCpeIdLine;
								IFX_VMAPI_Get_CpeId_opt("ContactList_CpeId",ucLineId,&iCpeId);
								iid.cpeId.Id = iCpeId;
					break;

					case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
								IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",1,&iCpeIdLine);
								iid.pcpeId.Id = iCpeIdLine;
								IFX_VMAPI_Get_CpeId_opt("PstnContactList_CpeId",1,&iCpeId);
								iid.cpeId.Id = iCpeId;
					break;

					case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
								iid.pcpeId.Id = 1;
								iid.cpeId.Id = 1;
					break;
				
				default :
					return IFX_VMAPI_FAIL;
			}
	}
	return  IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
		                                   &iid,
			                                 pxContactList,
				                               uiInFlag);

}


/******************************************************************************
*  Function Name  : LTQ_set_ContactList_opt
*  Description    : Set api to set contact list object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactList - Pointer to the object to be set
*  Output Values  : pxContactList - pointer to contactlist object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_ContactList(IN uint32  uiOperation,
                      IN_OUT  void /*x_IFX_VMAPI_ContactList*/ *pvContactList,
											IN uint32 uiListType,
											IN uint32 uiObjectId,
                      IN uint32  uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ; 
  
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdLine; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000];
	char8 acCpeidSecName[100]; /* buffer used to hold config data */
  x_IFX_VMAPI_ContactListEntry *pxTemp;
  uchar8 ucLine;
	x_IFX_VMAPI_ContactList xOldContactList={{{{0}}}};
	x_IFX_VMAPI_ContactList *pxContactList = (x_IFX_VMAPI_ContactList*)pvContactList; 

  int32 ret = IFX_VMAPI_FAIL; /* return value */

 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");

/***  PROLOG BLOCK   ***/
  if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
  }
   
/* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxContactList);

  CHECK_ACS_SESSION_OWNER_COMBINATION(pxContactList->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */

  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }
  memset(&iid,0,sizeof(iid));    

	IFX_VMAPI_STRCPY(pxContactList->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	sprintf(acCpeidSecName,"%s_CpeId", IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxContactList->iid.config_owner == IFX_TR69)  {
	
			IFX_VMAPI_GetLineIdFromCpeId(pxContactList->iid.pcpeId.Id, &ucLine);
		  pxContactList->ucLineId = ucLine;
	}else{
		//Get the corresponding parent section name and cpeid's of parent....	
    /* Get the CpeId of the Parent Object LineSubscription */
   	switch(uiListType){
			case IFX_VMAPI_VS_CONTACT_LIST:
						sprintf(pxContactList->iid.pcpeId.secName, "%s", "VoiceLine");
					  IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxContactList->ucLineId,&iCpeIdLine);
					  pxContactList->iid.pcpeId.Id = iCpeIdLine;
	  				if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
						      IFX_VMAPI_Get_CpeId_opt(acCpeidSecName,pxContactList->ucLineId,&iCpeId);
					      pxContactList->iid.cpeId.Id = iCpeId;
						}
			break;
			case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
						sprintf(pxContactList->iid.pcpeId.secName, "%s", "FxophyInterface");
						IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",1,&iCpeIdLine);
						pxContactList->iid.pcpeId.Id = iCpeIdLine;
	  				if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
			          IFX_VMAPI_Get_CpeId_opt(acCpeidSecName,1,&iCpeId);
      			    pxContactList->iid.cpeId.Id = iCpeId;
						}
			break;

			case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
            iid.pcpeId.Id = 1;
						if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
								pxContactList->iid.cpeId.Id = 1;
						}
			break;
		}
	}

  iid = pxContactList ->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }

  }

/*** ID ALLOCATION BLOCK  ***/
  if(IFX_INT_ADD_F_SET(uiInFlag))  {
  		memset(&piid,0,sizeof(piid));    
			piid.cpeId.Id = iid.pcpeId.Id;
			sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
	  if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
			return IFX_VMAPI_FAIL;
		}
		pxContactList->iid = iid;
		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  }
  

	if(IFX_MODIFY_F_SET(uiInFlag) ) {
   
     memset(&xOldContactList,0,sizeof(x_IFX_VMAPI_ContactList));
     memcpy(&xOldContactList,pxContactList,sizeof(x_IFX_VMAPI_ContactList));
	
    pxContactList->pxContactEntries=NULL; 
    if(LTQ_get_ContactList(pxContactList ,uiListType,uiObjectId, IFX_F_DEFAULT) != IFX_SUCCESS){
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Failed to get the Contact List !!\n\n");
			return IFX_VMAPI_FAIL;
  	}

    pxContactList->ucNoOfEntries= 0;
    pxTemp=pxContactList->pxContactEntries;
    while(pxTemp !=NULL)
    {
        pxContactList->ucNoOfEntries++;
      __ifx_list_GetNext((void *)&pxTemp);
    }

	}
  IFX_VMAPI_LOCK(uiLock); 

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvContactList, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List\n");
		goto EndLabel;
  }

	/*** NOTIFICATION BLOCK ***/
#ifndef LIST_ACCESS
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
  if(IFX_MODIFY_F_SET(uiInFlag)/*||IFX_DELETE_F_SET(uiInFlag)||IFX_INT_ADD_F_SET(uiInFlag)*/) {
                       
      if(IFX_VMAPI_IsObjectRegistered(uiListType) == IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending The Notification\n");
                if(pxContactList->pxContactEntries == NULL){
                   xOldContactList.pxContactEntries = NULL;
                }
                 
        if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                               (uiListType,(void *)&xOldContactList,(void *)pxContactList))
			                         {
                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                                        "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");
					                        ret = IFX_VMAPI_FAIL;
                        goto EndLabel;
                     }

			}
    }
  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
#endif


	if (ifx_get_conf_index_and_nv_pairs(&iid,
					          iInstanceIndex,
							      IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
									  xNVList.unNoOfNVPairs,
										xNVList.axNameValue,
										uiInFlag) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : ifx_get_conf_index_and_nv_pairs failed \n");
		goto EndLabel;  
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
			/* compare fvp array from structure with fvp array from file and build changed fvp */
			if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
						
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
				goto EndLabel;
			}
	}

  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 				"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
 
  /* Backup rc.conf before proceeding with configuration */
  if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      } 
#endif
			goto EndLabel;
    } else {
        /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							 "Warning : ifx_CompactCfgSection failed \n");
          }
        }

	if (IFX_INT_ADD_F_SET(uiInFlag)) {
           IFX_VMAPI_Update_CpeId_opt(acCpeidSecName, pxContactList->ucLineId,pxContactList->iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
           /* Update the CpeId corresponding to the Line Id */
           IFX_VMAPI_Update_CpeId_opt(acCpeidSecName, pxContactList->ucLineId, 0);
        }
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			      	 " Cannot write to the flash\n");
	      }
#endif
	}

  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
	  	IFX_VMAPI_FREE(pxChangedNvList);
	}
//	if(xOldContactList.pxContactEntries)
	//	ifx_vmapi_freeObjectList(&xOldContactList,IFX_VMAPI_VS_CONTACT_LIST);	
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function \n");
  return ret;

}



/******************************************************************************
*  Function Name  : LTQ_get_ContactListEntry
*  Description    : Get api to get ContactListEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_ContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
											 IN   uint32 uiObjectType,
											 IN 	uint32 uiObjectId,
                       IN   uint32  uiInFlag)
{ 

	printf("###################LTQ_get_ContactListEntry : %d & %d \n",uiObjectType,uiObjectId);

/* Object id IFX_VMAPI_OBJ_CONTACT_LIST_ENTRY */
  return IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
                                       &pxContactListEtr->iid,
                                       pxContactListEtr,
                                       uiInFlag);

}

/******************************************************************************
*  Function Name  : LTQ_set_ContactListEntry
*  Description    : Set api to set ContactListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactListEtr - Pointer to the object to be set
*  Output Values  : pxContactListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_ContactListEntry(IN uint32  uiOperation,
                      IN  void /*x_IFX_VMAPI_ContactListEntry*/ *pvContactListEtr,
											IN uint32 uiObjectType,
											IN uint32 uiObjectId,
                      IN uint32  uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ; 
  
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8 acParentCpeidList[50]; /* buffer used to hold config data */
  char8 acCpeidListEntry[50]; /* buffer used to hold config data */


  int32 ret = IFX_VMAPI_FAIL; /* return value */
	uint32  iCpeIdReg;
	uchar8 ucLineId=1; 
  x_IFX_VMAPI_ContactList xOldContactList={{{{0}}}};
	x_IFX_VMAPI_ContactList xContactList;
 x_IFX_VMAPI_ContactListEntry *pxContactListEtr = (x_IFX_VMAPI_ContactListEntry*)pvContactListEtr;

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxContactListEtr);
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entering Function \n");

  
  /***  PROLOG BLOCK   ***/
  if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
  }

 
   CHECK_ACS_SESSION_OWNER_COMBINATION(pxContactListEtr->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

  memset(&iid,0,sizeof(iid));    

  IFX_VMAPI_STRCPY(pxContactListEtr->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	sprintf(pxContactListEtr->iid.pcpeId.secName, "%s",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
	sprintf(acParentCpeidList, "%s_CpeId",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
	sprintf(acCpeidListEntry, "%s_CpeId",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

  /* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxContactListEtr->iid.config_owner == IFX_TR69)  {
    IFX_VMAPI_GetLineIdFromCpeId(pxContactListEtr->iid.pcpeId.Id, &ucLineId);
	  pxContactListEtr->ucLineId = ucLineId;
	}else{
    /* Get the CpeId of the Parent Object Contact List */
					switch(uiObjectType){
									case IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY:
									case IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY:
											    IFX_VMAPI_Get_CpeId_opt(acParentCpeidList,1,&iCpeIdReg);
													ucLineId=1;
									break;
			
								  default:  
													IFX_VMAPI_Get_CpeId_opt(acParentCpeidList,pxContactListEtr->ucLineId,&iCpeIdReg);
													ucLineId=pxContactListEtr->ucLineId;
									break;
				}
    				pxContactListEtr->iid.pcpeId.Id = iCpeIdReg;
  }

  iid = pxContactListEtr->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
    goto EndLabel;
			}
  }


	
  /*** ID ALLOCATION BLOCK  ***/

//Checking for existince of the same record and max record reach.... 

	if  (pxContactListEtr->iid.config_owner != IFX_WEB && (IFX_INT_ADD_F_SET(uiInFlag) || IFX_MODIFY_F_SET(uiInFlag)))  {
			// Get the full list of ContactListEntry 
			memset(&xContactList,0,sizeof(xContactList));
			xContactList.ucLineId = pxContactListEtr->ucLineId;    
			xContactList.iid.config_owner = IFX_WEB;
		  if( (ret = LTQ_get_ContactList(&xContactList,uiObjectType - 1,uiObjectId - 1, 0) != IFX_VMAPI_SUCCESS)){
								IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Error : Could Not Get Contact List \n");
								goto EndLabel;	
			}

		if(IFX_INT_ADD_F_SET(uiInFlag) &&  (xContactList.ucNoOfEntries == IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE) ){
						ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
						ret = IFX_VMAPI_FAIL;
						goto EndLabel;
		}else if(ifx_get_CommonContactMatchs((VOID *)pxContactListEtr) != IFX_VMAPI_SUCCESS){
						if(xContactList.ucNoOfEntries > 0 &&  ifx_get_IfContactMatch((VOID *)&xContactList,(VOID *)pxContactListEtr,uiObjectType - 1 ) == IFX_VMAPI_SUCCESS ){
										ret = IFX_VMAPI_FAIL;
										ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
										goto EndLabel;	
						}
					}else{
										ret = IFX_VMAPI_FAIL;
										ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
										goto EndLabel;	
				}
	}


// keeping the old parent object back up to  send notification.....
   if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
					    memset(&xOldContactList,0,sizeof(xOldContactList));
              xOldContactList.ucLineId = pxContactListEtr->ucLineId ;
              xOldContactList.iid.config_owner = IFX_WEB;
              if(IFX_VMAPI_SUCCESS != (ret = LTQ_get_ContactList(&xOldContactList,uiObjectType - 1,uiObjectId - 1, 0))){
                       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Get ContactList failed\n");
											goto EndLabel;	
             }
	}


  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
  		x_IFX_VMAPI_ContactList xContactList; 
		  piid.cpeId.Id = iid.pcpeId.Id;
	  	sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
				//if (ifx_get_IID(&iid, NULL) != IFX_SUCCESS) {
				if ((ret = ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid)) != IFX_SUCCESS) {    
						IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
								"Failed to get the iid !!\n\n");
							IFX_VMAPI_UNLOCK(uiLock);
											goto EndLabel;	
				}

				pxContactListEtr->iid = iid;
				ifx_get_EntryId(uiObjectType - 1, &pxContactListEtr->uiEntryId);	
				/* increment the next cpe id for this object */
				ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
												 IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

			memset(&xContactList,0,sizeof(xContactList));
			xContactList.ucLineId = pxContactListEtr->ucLineId;
			xContactList.iid.config_owner = IFX_WEB;
			if(IFX_VMAPI_SUCCESS != (ret = LTQ_get_ContactList(&xContactList,uiObjectType - 1,uiObjectId-1 , 0))){
					IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							"Failed to get the List entry Reg\n\n");
					ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
					goto EndLabel;	
			}
			pxContactListEtr->ucIndex=xContactList.ucNoOfEntries+1;
			ifx_vmapi_freeObjectList(&xContactList, IFX_VMAPI_VS_CONTACT_LIST);
  }

    
  IFX_VMAPI_LOCK(uiLock); 
 /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
 
  if ( (ret = IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxContactListEtr, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL )) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List \n");
		goto EndLabel;  
	}

  if (( ret = ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag)) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : ifx_get_conf_index_and_nv_pairs failed in \n");
		goto EndLabel; 
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
		/* compare fvp array from structure with fvp array from file and build changed fvp */
		if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
						
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
				goto EndLabel;	
		}
	}

  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 				"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
 
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File\n");
      } 
#endif
			goto EndLabel;
    } else {
      /* Config file is updated */
       /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,IFX_VMAPI_GET_OBJ_NAME(uiObjectId), uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Warning : ifx_CompactCfgSection failed \n");
          }
        }


	if (IFX_INT_ADD_F_SET(uiInFlag)) {
		 /* Update the CpeId corresponding to the Line Id */	
	   //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_CONTACT_LIST_ENTRY, pxContactListEtr,pxContactListEtr->iid.cpeId.Id);
	   IFX_VMAPI_Update_CpeId_opt(acCpeidListEntry, 
                            (((ucLineId-1)*IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)+pxContactListEtr->ucIndex),
                            pxContactListEtr->iid.cpeId.Id);
        }

      if ((IFX_DELETE_F_SET(uiInFlag)) ) {
	      	if(pxContactListEtr->iid.config_owner == IFX_WEB || pxContactListEtr->iid.config_owner == IFX_VOIP)
	      	{
       			/* Update the CpeId corresponding to the Line Id */
            //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_CONTACT_LIST_ENTRY, pxContactListEtr,0);
            IFX_VMAPI_Update_CpeId_opt(acCpeidListEntry,(((ucLineId-1)*IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE)+pxContactListEtr->ucIndex),0);
								ifx_free_EntryId(IFX_VMAPI_VS_CONTACT_LIST, pxContactListEtr->uiEntryId);
          }
	        else
	        {
            		if(IFX_VMAPI_ReplaceCpeId(IFX_VMAPI_GET_OBJ_NAME(uiObjectId) , pxContactListEtr->iid.cpeId.Id) !=IFX_VMAPI_SUCCESS)
								{
										printf("[%s %d] Failed to Replace\n",__FUNCTION__, __LINE__);
								}
	        }
      }
	// Updatating the parent and sending notification.....
	 if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
                
	if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_ContactList(IFX_OP_MOD,&xOldContactList,uiObjectType - 1,uiObjectId - 1, 0))){
              		     IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
			           				goto EndLabel;
				}
   }else{
						memset(&xOldContactList,0,sizeof(xOldContactList));
						xOldContactList.ucLineId = pxContactListEtr->ucLineId ;
						xOldContactList.iid.config_owner = IFX_WEB;
						if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_ContactList(IFX_OP_MOD,&xOldContactList,uiObjectType - 1,
																										uiObjectId - 1,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))){
	                        	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
				          					goto EndLabel;
    	
						}
	}

        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, " Cannot write to the flash\n");
	      }
#endif

} 
  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
	
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function :\n");
  return ret;

}


/******************************************************************************
*  Function Name  : LTQ_get_CallRegister
*  Description    : Get api to get Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallReg - pointer to Missed Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_CallRegister (IN_OUT  x_IFX_VMAPI_CallRegister *pxCallReg,
											IN uint32 uiListType,
											IN uint32 uiObjectId,
                      IN uint32  uiInFlag)
{
	IFX_ID iid;
	uint32 iCpeId, iCpeIdLine;
 	char8 acCpeidList[50];
 
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	printf("###################### LTQ_get_CallRegister with %d & %d \n",uiListType,uiObjectId);
  uchar8 ucLineId = pxCallReg->ucLineId;
  iid = pxCallReg->iid;

//	if(uiListType == IFX_VMAPI_VS_DIALCALL_REGISTER)

  sprintf(acCpeidList, "%s_CpeId",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	printf("<LTQ_get_CallRegister> %s\n",acCpeidList);

  if(iid.config_owner != IFX_TR69) {
			switch(uiListType) {
					case IFX_VMAPI_VS_DIALCALL_REGISTER:
					case IFX_VMAPI_VS_MISSCALL_REGISTER:
					case IFX_VMAPI_VS_RECVCALL_REGISTER:
								IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",ucLineId,&iCpeIdLine);
								iid.pcpeId.Id = iCpeIdLine;
								IFX_VMAPI_Get_CpeId_opt(acCpeidList, ucLineId, &iCpeId);
								iid.cpeId.Id = iCpeId;
					break;

					case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
					case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
					case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
								IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",1,&iCpeIdLine);
								iid.pcpeId.Id = iCpeIdLine;
								IFX_VMAPI_Get_CpeId_opt(acCpeidList,1,&iCpeId);
								iid.cpeId.Id = iCpeId;
					break;

					default :
								return IFX_VMAPI_FAIL;
			}
	}	
  /* Object Id IFX_VMAPI_OBJ_CALLREGISTER */
	return  IFX_VMAPI_GetObjectFromCpeid(uiObjectId,
																			 &iid,
																			 pxCallReg,
																			 uiInFlag);
}




/******************************************************************************
*  Function Name  : LTQ_set_CallRegister
*  Description    : Set api to set Call Register object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxCallReg - Pointer to the object to be set
*  Output Values  : pxCallReg - pointer to CallReg object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_CallRegister(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CallRegister *pxCallReg,
                      IN uint32  uiListType,
											IN uint32 uiObjectId,
											IN uint32 uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ; 
  boolean bFree=1;  
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdLine; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8 acCpeidSecName[50];
  uchar8 ucLineId = 1;
	x_IFX_VMAPI_CallRegEntry *pxTemp;
	x_IFX_VMAPI_CallRegister xOldCallReg={{{{0}}}};
  int32 ret = IFX_VMAPI_FAIL; /* return value */

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function \n");
	printf("LTQ_set_CallRegister : %d with %d \n",uiListType,uiObjectId);
  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxCallReg);
	
	/***  PROLOG BLOCK   ***/
  if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
  		    "Error : Operation Is Not Supported\n");
			goto EndLabel;
  }

  /*** VALIDATION BLOCK ***/
  CHECK_ACS_SESSION_OWNER_COMBINATION(pxCallReg->iid.config_owner);

  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }
  memset(&iid,0,sizeof(iid));    

	IFX_VMAPI_STRCPY(pxCallReg->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	sprintf(acCpeidSecName,"%s_CpeId", IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxCallReg->iid.config_owner == IFX_TR69)  {
    IFX_VMAPI_GetLineIdFromCpeId(pxCallReg->iid.pcpeId.Id, &ucLineId);
	  pxCallReg->ucLineId = ucLineId;
	}
  
  if((pxCallReg->iid.config_owner == IFX_WEB)||(pxCallReg->iid.config_owner == IFX_VOIP))  {
		//Get the corresponding parent section name and cpeid's of parent.... 
    /* Get the CpeId of the Parent Object LineSubscription */
				switch(uiListType){
						case IFX_VMAPI_VS_DIALCALL_REGISTER:
						case IFX_VMAPI_VS_MISSCALL_REGISTER:
						case IFX_VMAPI_VS_RECVCALL_REGISTER:
									sprintf(pxCallReg->iid.pcpeId.secName, "%s", "VoiceLine");
									IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxCallReg->ucLineId,&iCpeIdLine);
									pxCallReg->iid.pcpeId.Id = iCpeIdLine;
									if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
												IFX_VMAPI_Get_CpeId_opt(acCpeidSecName,pxCallReg->ucLineId,&iCpeId);
											pxCallReg->iid.cpeId.Id = iCpeId;
								}
								ucLineId=pxCallReg->ucLineId;
					break;

						case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
						case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
						case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
									sprintf(pxCallReg->iid.pcpeId.secName, "%s", "FxophyInterface");
									IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",1,&iCpeIdLine);
									pxCallReg->iid.pcpeId.Id = iCpeIdLine;
								if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
										IFX_VMAPI_Get_CpeId_opt(acCpeidSecName,1,&iCpeId);
										pxCallReg->iid.cpeId.Id = iCpeId;
								}
							ucLineId=1;
						break;
			}					
	}
  iid = pxCallReg ->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
	      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
				ret=IFX_VMAPI_FAIL;
				goto EndLabel;
    }

  }

/*** ID ALLOCATION BLOCK  ***/
  if(IFX_INT_ADD_F_SET(uiInFlag))  {
  				memset(&piid,0,sizeof(piid));    
					piid.cpeId.Id = iid.pcpeId.Id;
					sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
	  if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						"Failed to get the iid !!\n\n");
				IFX_VMAPI_UNLOCK(uiLock);
					ret =  IFX_VMAPI_FAIL;
    			goto EndLabel;
		}
		pxCallReg->iid = iid;
		/* increment the next cpe id for this object */
		ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
								IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  }
  
//Keep the old list back for notification purpose
	if(IFX_MODIFY_F_SET(uiInFlag) ) {
			memset(&xOldCallReg,0,sizeof(x_IFX_VMAPI_CallRegister));
			memcpy(&xOldCallReg,pxCallReg,sizeof(x_IFX_VMAPI_CallRegister));
			
				pxCallReg->pxCallRegEntries=NULL; 
				if(LTQ_get_CallRegister(pxCallReg ,uiListType,uiObjectId , IFX_F_DEFAULT) != IFX_SUCCESS){
					IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							"Failed to get the Call Reg !!\n\n");
					ret =  IFX_VMAPI_FAIL;
    			goto EndLabel;
				}

				pxCallReg->ucNoOfEntries= 0;
				pxTemp=pxCallReg->pxCallRegEntries;
				while(pxTemp !=NULL)
				{
						pxCallReg->ucNoOfEntries++;
					__ifx_list_GetNext((void *)&pxTemp);
				}
	}
  IFX_VMAPI_LOCK(uiLock); 

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxCallReg, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List\n");
    IFX_VMAPI_UNLOCK(uiLock);
    goto EndLabel;
  }

	/*** NOTIFICATION BLOCK ***/
#ifndef LIST_ACCESS
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
			if(IFX_MODIFY_F_SET(uiInFlag)/*||IFX_DELETE_F_SET(uiInFlag)||IFX_INT_ADD_F_SET(uiInFlag)*/) {
														//printf("<Set_MisClReg> Checking for Ntfn 2\n");
					if(xOldCallReg.iid.config_owner == IFX_WEB||pxCallReg->ucNoOfEntries==0){
						bFree=0;
					  if (xOldCallReg.pxCallRegEntries != NULL){
								ifx_vmapi_freeObjectList(&xOldCallReg, uiListType);
						}
						if(pxCallReg->pxCallRegEntries != NULL)
							ifx_vmapi_freeObjectList(pxCallReg, uiListType);
					}
					if(IFX_VMAPI_IsObjectRegistered(uiListType) == IFX_VMAPI_SUCCESS)
					{
						IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
										"Sending The Notification\n");
  					/*	if (pxCallReg->pxCallRegEntries != NULL){
								ifx_vmapi_freeObjectList(&xOldCallReg, uiListType);
							}*/
										 //printf("<Set_MisClReg> Sending for Ntfn\n");
						if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
																		(uiListType,(void *)&xOldCallReg,(void *)pxCallReg))
														{
																 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																												"Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");
																 ret = IFX_VMAPI_FAIL;
																		goto EndLabel;
														 }
															bFree=0;

				}
			}
  } /* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
#endif


	if (ifx_get_conf_index_and_nv_pairs(&iid,
								               iInstanceIndex,
															IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
							                xNVList.unNoOfNVPairs,
														  xNVList.axNameValue,
															uiInFlag) != IFX_SUCCESS) {
                       
					    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
														"Error : ifx_get_conf_index_and_nv_pairs failed \n");
								    IFX_VMAPI_UNLOCK(uiLock);
									 goto EndLabel;
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
		/* compare fvp array from structure with fvp array from file and build changed fvp */
		if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
						
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
    		    IFX_VMAPI_UNLOCK(uiLock);
					 goto EndLabel;

		}
	}

  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 				"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
 
  /* Backup rc.conf before proceeding with configuration */
  if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      } 
#endif
			goto EndLabel;
    } else {
        /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							 "Warning : ifx_CompactCfgSection failed \n");
          }
        }

	if (IFX_INT_ADD_F_SET(uiInFlag)) {
           IFX_VMAPI_Update_CpeId_opt(acCpeidSecName, ucLineId,pxCallReg->iid.cpeId.Id);
        }

        if (IFX_DELETE_F_SET(uiInFlag)) {
           IFX_VMAPI_Update_CpeId_opt(acCpeidSecName, ucLineId, 0);
        }
        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			      	 " Cannot write to the flash\n");
	      }
#endif
}

  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
	  	IFX_VMAPI_FREE(pxChangedNvList);
	}
	if(bFree){
  	if (xOldCallReg.pxCallRegEntries != NULL){
			ifx_vmapi_freeObjectList(&xOldCallReg, uiListType);
		}
		if(pxCallReg->pxCallRegEntries != NULL)
			ifx_vmapi_freeObjectList(pxCallReg, uiListType);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function \n");
  return ret;
}


/******************************************************************************
*  Function Name  : LTQ_set_CallRegisterEntry
*  Description    : Set api to get MissCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallRegEtr - Pointer to the object to be set
*  Output Values  : pxMissCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_CallRegisterEntry(IN uint32  uiOperation,
																IN  x_IFX_VMAPI_CallRegEntry *pxCallRegEtr,
																IN uint32  uiObjectType,
																IN uint32  uiObjectId,
																IN uint32  uiInFlag)
{
  IFX_ID iid, piid;
  int32 iInstanceIndex = -1 ; 
  
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
  int32 ret = IFX_VMAPI_FAIL; /* return value */
	uint32  iCpeIdReg;
	uchar8 ucLineId; 
  x_IFX_VMAPI_CallRegister xOldCallReg={{{{0}}}};
	char8 acParentCpeidList[50]; /* buffer used to hold config data */
  char8 acCpeidListEntry[50]; /* buffer used to hold config data */

  /* Validate the paramters :: make sure that pointers and flags are proper */
  IFX_VALIDATE_PTR(pxCallRegEtr);
	
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entering Function \n");


	/***  PROLOG BLOCK   ***/
	if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
	}

   CHECK_ACS_SESSION_OWNER_COMBINATION(pxCallRegEtr->iid.config_owner);

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag)&& IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

  memset(&iid,0,sizeof(iid));    

  IFX_VMAPI_STRCPY(pxCallRegEtr->iid.cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	
	sprintf(pxCallRegEtr->iid.pcpeId.secName, "%s", IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	sprintf(acParentCpeidList, "%s_CpeId",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId - 1));
  sprintf(acCpeidListEntry, "%s_CpeId",  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));


  /* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(pxCallRegEtr->iid.config_owner == IFX_TR69)  {
    IFX_VMAPI_GetLineIdFromCpeId(pxCallRegEtr->iid.pcpeId.Id, &ucLineId);
	  pxCallRegEtr->ucLineId = ucLineId;
	}else{
	
    	/* Get the CpeId of the Parent Object LineSubscription */
			if(pxCallRegEtr->ucLineId != IFX_VMAPI_PSTN_LINE ){
	      IFX_VMAPI_Get_CpeId_opt(acParentCpeidList,pxCallRegEtr->ucLineId,&iCpeIdReg);
				ucLineId = pxCallRegEtr->ucLineId;	
			}
			else{
	      IFX_VMAPI_Get_CpeId_opt(acParentCpeidList, 1 ,&iCpeIdReg);
				ucLineId = 1;	
			}
    	pxCallRegEtr->iid.pcpeId.Id = iCpeIdReg;
  }

  iid = pxCallRegEtr->iid;

  /* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid.cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;  
    }
  }


  piid.cpeId.Id = iid.pcpeId.Id;
  sprintf(piid.cpeId.secName, "%s", iid.pcpeId.secName);
	
  /*** ID ALLOCATION BLOCK  ***/

//Checking for existince of the same record and max record reach.... 

	if  (IFX_INT_ADD_F_SET(uiInFlag))  {
			uint32 uiIndex=0;
			uint32 uiEndIndex=0;
			uchar8 ucNoOfEntries=0;
			x_IFX_VMAPI_CallRegEntry *pxTemp;
			x_IFX_VMAPI_CallRegister xCallReg;

			// Get the full list of MissCallRegEntry 
			memset(&xCallReg,0,sizeof(xCallReg));
			xCallReg.ucLineId = pxCallRegEtr->ucLineId;    
			xCallReg.iid.config_owner = IFX_VOIP;
			xCallReg.pxCallRegEntries = NULL;
		  if( (ret = LTQ_get_CallRegister(&xCallReg,uiObjectType - 1, uiObjectId - 1 , 0)) != IFX_VMAPI_SUCCESS){
				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
														 "Error : Could Not Get Miss CallReg in \n");
					goto EndLabel;
			}

			if(xCallReg.ucNoOfEntries > 0 ){

				//Check to see last entry matchs to the latest entry....
					ifx_get_StartEndIndex((VOID *)&xCallReg,uiObjectType - 1,
							xCallReg.pxCallRegEntries->ucLineId,&uiIndex,&uiEndIndex,&ucNoOfEntries);

					if((ret = ifx_get_IfMatchLastEntry((VOID *)&xCallReg, (VOID *)pxCallRegEtr,uiObjectType - 1,uiEndIndex) ) == IFX_VMAPI_SUCCESS)
					{
							//Update the last entry......   
							pxTemp = (x_IFX_VMAPI_CallRegEntry *)uiEndIndex;
							pxTemp->ucLineId=pxCallRegEtr->ucLineId;
							pxTemp->iid.config_owner = pxCallRegEtr->iid.config_owner;
							strcpy(pxTemp->acCallTime,pxCallRegEtr->acCallTime); 
							strcpy(pxTemp->acCallTime,pxCallRegEtr->acCallTime); 
							strcpy(pxTemp->xAddress.acDisplayName,pxCallRegEtr->xAddress.acDisplayName); 
              pxTemp->ucNoOfCalls+=1;
              pxTemp->bStatus = 1;
              if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_CallRegisterEntry(IFX_OP_MOD,pxTemp,uiObjectType, uiObjectId , 0)))
               {
                      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                                "Error : Could Not Modify the  Last Miss CallReg Entry \n");
              				goto EndLabel;
              }
							if( xCallReg.ucNoOfEntries > 0 || xCallReg.pxCallRegEntries != NULL)
										ifx_vmapi_freeObjectList(&xCallReg, uiObjectType - 1);
							return IFX_VMAPI_SUCCESS;
					}else if(xCallReg.ucNoOfEntries == IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE ){
										pxTemp= (x_IFX_VMAPI_CallRegEntry *)uiIndex;
									if(pxTemp != NULL) {
										pxTemp->ucIndex=1;
										pxTemp->ucLineId=pxCallRegEtr->ucLineId;
										pxTemp->iid.config_owner = pxCallRegEtr->iid.config_owner;
										if(IFX_VMAPI_SUCCESS != (ret = LTQ_set_CallRegisterEntry(IFX_OP_DEL,pxTemp, uiObjectType, uiObjectId , 0)))
										{
														IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																			"Error : Could Not Delete First CallReg Entry \n");
			              				goto EndLabel;
										}	
										if( xCallReg.ucNoOfEntries > 0 || xCallReg.pxCallRegEntries != NULL)
												ifx_vmapi_freeObjectList(&xCallReg, uiObjectType - 1);
								}else {
											printf("###################Unable to delete the 1st entry... !\n");
											ret=IFX_VMAPI_FAILURE;
              				goto EndLabel;
									}
					}
    }
	}


// keeping the old parent object back up to  send notification.....
  if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				memset(&xOldCallReg,0,sizeof(xOldCallReg));
				xOldCallReg.ucLineId = pxCallRegEtr->ucLineId ;
				xOldCallReg.iid.config_owner = IFX_VOIP;
				if(IFX_VMAPI_SUCCESS != (ret = LTQ_get_CallRegister(&xOldCallReg,uiObjectType - 1, uiObjectId - 1,0))){
						IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Get CallReg failed\n");
						goto EndLabel;
				}
	}


  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
		  x_IFX_VMAPI_CallRegister xCallReg; 
			if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {    
							IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
														"Failed to get the iid !!\n\n");
				      IFX_VMAPI_UNLOCK(uiLock);
				      ret = IFX_VMAPI_FAIL;
							goto EndLabel;
			}
			pxCallRegEtr->iid = iid;
			pxCallRegEtr->bStatus = 1;
			pxCallRegEtr->ucNoOfCalls = 1;	
			ifx_get_EntryId(uiObjectType - 1, &pxCallRegEtr->uiEntryId);	
			/* increment the next cpe id for this object */
	    ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
      IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

			memset(&xCallReg,0,sizeof(xCallReg));
      xCallReg.ucLineId = pxCallRegEtr->ucLineId;
      xCallReg.iid.config_owner = IFX_VOIP;
      if(IFX_VMAPI_SUCCESS != LTQ_get_CallRegister(&xCallReg,uiObjectType - 1, uiObjectId - 1 ,0)){
				    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
									"Failed to get the Miss Call Reg\n\n");
							ifx_vmapi_freeObjectList(&xCallReg, uiObjectType - 1);
							goto EndLabel;
			}
			pxCallRegEtr->ucIndex=xCallReg.ucNoOfEntries+1;
			ifx_vmapi_freeObjectList(&xCallReg, uiObjectType - 1);
  }

  /* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));
  
  IFX_VMAPI_LOCK(uiLock); 

  if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         (VOID*)pxCallRegEtr, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Error : Could Not Get NV List \n");
     goto EndLabel;
  }

  if (ifx_get_conf_index_and_nv_pairs(&iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
                       
			    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							 "Error : ifx_get_conf_index_and_nv_pairs failed in \n");
			    IFX_VMAPI_UNLOCK(uiLock);
			  	goto EndLabel;
  }

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
	
	if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {
		/* compare fvp array from structure with fvp array from file and build changed fvp */
		if(ifx_cmp_and_return_changed_fvp(&iid.cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
						
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Error : Could Not Get Changed Field Names \n");
				 goto EndLabel;
		}
	}

  
  /*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
  
  if (IFX_MODIFY_F_SET(uiInFlag)) { 
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
 				"Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
 
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File\n");
      } 
#endif
			goto EndLabel;
    } else {
      /* Config file is updated */
       /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,IFX_VMAPI_GET_OBJ_NAME(uiObjectId), uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Warning : ifx_CompactCfgSection failed \n");
          }
        }


	if (IFX_INT_ADD_F_SET(uiInFlag)) {
		 /* Update the CpeId corresponding to the Line Id */	
	   IFX_VMAPI_Update_CpeId_opt(acCpeidListEntry, (((ucLineId-1)*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE)+pxCallRegEtr->ucIndex),pxCallRegEtr->iid.cpeId.Id);
  }
  if ((IFX_DELETE_F_SET(uiInFlag)) ) {
			if((pxCallRegEtr->iid.config_owner == IFX_WEB)||(pxCallRegEtr->iid.config_owner == IFX_VOIP))
	    {
       		/* Update the CpeId corresponding to the Line Id */
          IFX_VMAPI_Update_CpeId_opt(acCpeidListEntry,(((ucLineId-1)*IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE)+pxCallRegEtr->ucIndex),0);
					ifx_free_EntryId(uiObjectType - 1, pxCallRegEtr->uiEntryId);
       }
	     else
	     {
					if(IFX_VMAPI_ReplaceCpeId(IFX_VMAPI_GET_OBJ_NAME(uiObjectId) , pxCallRegEtr->iid.cpeId.Id) !=IFX_VMAPI_SUCCESS)
					{
								printf("[%s %d] Failed to Replace\n",__FUNCTION__, __LINE__);
					}			
	      }
  }
	// Updatating the parent and sending notification.....
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
		  if((ret = LTQ_set_CallRegister(IFX_OP_MOD,&xOldCallReg,uiObjectType - 1,uiObjectId - 1,0)) != IFX_VMAPI_SUCCESS){
              IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
       				goto EndLabel;
			}
  }else{
					memset(&xOldCallReg,0,sizeof(xOldCallReg));
					xOldCallReg.ucLineId = pxCallRegEtr->ucLineId ;
					xOldCallReg.iid.config_owner = pxCallRegEtr->iid.config_owner;
					if((ret = LTQ_set_CallRegister(IFX_OP_MOD,&xOldCallReg,uiObjectType - 1,uiObjectId - 1,
																IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) != IFX_VMAPI_SUCCESS ){
                        	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error : Update failed\n");
                					goto EndLabel;
					}
	}

	/*** DEVICE CONFIGURATION BLOCK ***/
	/* Device configuration is not needed for this object */
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
	if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
			IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, " Cannot write to the flash\n");
	}
#endif

} 
  
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
#if 0
	if ( xOldCallReg.pxCallRegEntries != NULL )
		ifx_vmapi_freeObjectList(&xOldCallReg, uiObjectType - 1);
#endif

  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function :\n");
  return ret;
}

//#/ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
/******************************************************************************
*  Function Name  : LTQ_set_DectObject
*  Description    : Set api to set various dect related objects
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDectObject - Pointer to the object to be set
*  Output Values  : pxDectObject - pointer to dect related object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_DectObject(IN uint32  uiOperation,
													IN_OUT  void *pvDectObject,
													IN uint32 uiObjectType,
													IN uint32 uiObjectId,
													IN uint32  uiInFlag)
{
  IFX_ID *iid = NULL;
  int32 iInstanceIndex = -1 ;
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
 	IFX_NAME_VALUE_PAIR *pxList=NULL;
	int32  uiChangedNvCount=-1; /* number of changed NVPs */
  uint32 uiNvIdx = 0;
  uchar8 buf[5000];
 	uchar8 bLoging = 1; 
  int32 ret = IFX_VMAPI_FAIL; /* return value */
	char8 acIIDSec[25]="NsxSize";
	uint32 iCpeId = 0;
	/* Void pointer which hold the values for notification */
	void * xOldObj = NULL; // Void pointer to hold old rc.conf object values

	printf("#########LTQ_set_DectObject : with object id %d & type : %d \n",uiObjectId,uiObjectType);
	
	//TPC Parameter
	x_IFX_VMAPI_TransmitPowerParam *pxTransPower= NULL;//(x_IFX_VMAPI_TransmitPowerParam *)pvDectObject;
	x_IFX_VMAPI_TransmitPowerParam xOldTP = {{{{0}}}};

	//BMC Parameter related
	x_IFX_VMAPI_DectBMCParams xOldBmcparam = {{{{0}}}};
	x_IFX_VMAPI_DectBMCParams *pxBmcparam = NULL;

	//OSCT obj related
	x_IFX_VMAPI_DectOscTrimVal xOldOsctrim = {{{{0}}}};
	x_IFX_VMAPI_DectOscTrimVal *pxOsctrim = NULL;

	//gfsk obj related
	x_IFX_VMAPI_DectGFSKVal xOldGfsk = {{{{0}}}};
	x_IFX_VMAPI_DectGFSKVal *pxGfsk = NULL;

	//Country setting related
	x_IFX_VMAPI_DectCountrySettings xOldCtryset = {{{{0}}}};
	x_IFX_VMAPI_DectCountrySettings *pxCtryset = NULL;


	//rfpi reltaed
	x_IFX_VMAPI_DectRfpi xOldRfpi = {{{{0}}}};
	x_IFX_VMAPI_DectRfpi *pxRfpi = NULL;

	//rfmode related
	x_IFX_VMAPI_RFMode xOldRfMode = {{{{0}}}};
	x_IFX_VMAPI_RFMode *pxRfMode =NULL; 

	//xRAM related
	x_IFX_VMAPI_DectXRAM *pxXram = NULL;
	x_IFX_VMAPI_DectXRAM xOldXram = {{{{0}}}};

	//Dect Interface related
	x_IFX_VMAPI_DectSystem *pxDectInf = NULL;
	x_IFX_VMAPI_DectSystem xOldDect = {{{{0}}}};

	//Dect Handset Related
	x_IFX_VMAPI_DectHandset xOldHandset;
	x_IFX_VMAPI_DectHandset *pxDectHand = NULL;
	
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					"Entering Function \n");

/**********************************************************************************************
					SECTION : 1 -> OPERATION AND FLAG VERIFICATION 
**********************************************************************************************/
/***  PROLOG BLOCK   ***/

	if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
		   IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
								 "Error : Operation Is Not Supported\n");
		   return IFX_VMAPI_FAIL;
	}
 

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }


/**********************************************************************************************
        SECTION : 2 -> POINTER CONVERTION, CPEID,ENTRY ID , PARENT CPEID IDENTIFICATION 
**********************************************************************************************/
	switch(uiObjectId){
				case IFX_VMAPI_OBJ_DECT_TRANS_POWER:
								pxTransPower= (x_IFX_VMAPI_TransmitPowerParam *)pvDectObject;
								iid= &(pxTransPower->iid);
				break;

				case IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS:
								pxBmcparam = (x_IFX_VMAPI_DectBMCParams *)pvDectObject;
								iid= &(pxBmcparam->iid);
				break;

				case IFX_VMAPI_OBJ_DECT_GFSK:
							pxGfsk =	(x_IFX_VMAPI_DectGFSKVal *)pvDectObject ;
							iid= &(pxGfsk->iid);
				break;

				case IFX_VMAPI_OBJ_DECT_OSC_TRIM:
							pxOsctrim = (x_IFX_VMAPI_DectOscTrimVal *)pvDectObject;
							iid= &(pxOsctrim->iid);
				break;
					
				case IFX_VMAPI_OBJ_DECT_COUNTRY_SETTINGS:
							pxCtryset = (x_IFX_VMAPI_DectCountrySettings *)pvDectObject;
							iid= &(pxCtryset->iid);
				break;	

				case IFX_VMAPI_OBJ_DECT_RFPI:
							pxRfpi=(x_IFX_VMAPI_DectRfpi *)pvDectObject;
							iid= &(pxRfpi->iid);
				break;

				case IFX_VMAPI_OBJ_DECT_RF_MODE:
							pxRfMode = (x_IFX_VMAPI_RFMode *)pvDectObject;
							iid= &(pxRfMode->iid);
				break;
						
				case IFX_VMAPI_OBJ_DECT_XRAM:
							pxXram  = (x_IFX_VMAPI_DectXRAM *)pvDectObject;
							iid= &(pxXram->iid);
				break;
				case IFX_VMAPI_OBJ_DECT:
							pxDectInf=(x_IFX_VMAPI_DectSystem *)pvDectObject;
							iid= &(pxDectInf->iid);
							strcpy(acIIDSec,"RFPI");
							bLoging = 0;
				break;
					
				case IFX_VMAPI_OBJ_DECT_HANDSET:
							pxDectHand = (x_IFX_VMAPI_DectHandset *)pvDectObject;
							iid= &(pxDectHand->iid);
							strcpy(acIIDSec,"IPEI");
							bLoging = 0;
							if(IFX_MODIFY_F_SET(uiInFlag))
							{
								 int32 i=0,j=0;
								 char8 XArray[2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES+1]={'\0'};
								 while(pxDectHand->aucVoiceLineIdList[i] != 0)
								{
									 sprintf(&XArray[j],"%d",pxDectHand->aucVoiceLineIdList[i]);
									 strcat(XArray,",");
									 j = strlen(XArray);
									 i++;
								}
								 strcpy((char8 *)pxDectHand->aucVoiceLineIdList,XArray);
							IFX_VMAPI_Get_CpeId_opt("DectHandset_CpeId",(pxDectHand->xVoiceServPhyIf.ucInterfaceId-3),&iCpeId);
							pxDectHand->iid.cpeId.Id = iCpeId;
							pxDectHand->iid.pcpeId.Id = 1;
							}	
				break;
				
				default:
							return IFX_FAILURE;
		}
				
		CHECK_ACS_SESSION_OWNER_COMBINATION(iid->config_owner);

		if(uiObjectId != IFX_VMAPI_OBJ_DECT_HANDSET){
						iid->cpeId.Id = 1;
						iid->pcpeId.Id = 1;
		}

		IFX_VMAPI_STRCPY(iid->cpeId.secName,
										  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

/**********************************************************************************************
        SECTION : 3 -> INSTANCE INDEX FINDING (MODIFY/DELETE) / CPEID GENERATION (ADD)
**********************************************************************************************/
/* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid->cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get INDEX From cpeid\n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }

  }

  /*** ID ALLOCATION BLOCK  ***/
  if (IFX_INT_ADD_F_SET(uiInFlag)) {
    if (ifx_get_IID(iid, acIIDSec) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Failed to get the iid !!\n\n");
      IFX_VMAPI_UNLOCK(uiLock);
      return IFX_VMAPI_FAIL;
    }
    
		/* increment the next cpe id for this object */
    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
                IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
  }

/**********************************************************************************************
                SECTION : 4 -> MODIFY PARENT IF ANY, GENERATE NAME VALUE TABLE 
**********************************************************************************************/
	 if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                        pvDectObject ,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       "Error : Could Not Get NV List \n");
    goto EndLabel;
	}


  if (ifx_get_conf_index_and_nv_pairs(iid,
                iInstanceIndex,
                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
                xNVList.unNoOfNVPairs,
                xNVList.axNameValue,
                uiInFlag) != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
     "Error : ifx_get_conf_index_and_nv_pairs failed \n");
    goto EndLabel;
	}

  if (IFX_INT_ADD_F_NOT_SET(uiInFlag) ) {

    /* compare fvp array from structure with fvp array from file and build changed fvp */
    if(ifx_cmp_and_return_changed_fvp(&iid->cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {

        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Could Not Get Changed Field Names \n");
        goto EndLabel;
    }
  }

/**********************************************************************************************
                SECTION : 5 -> CHECKING FOR NUMBER OF MODIFIED FIELDS 
**********************************************************************************************/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
    pxList = pxChangedNvList;
  }
  else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, xNVList.axNameValue);
    pxList = &xNVList.axNameValue[0];
  }
  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Info : There Are No Changed/New-Object Fields To Be Added.\n");
      goto EndLabel;
  }

  if (ret != IFX_SUCCESS) {

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Error : Could Not Form Buffer From NV List \n");
    goto EndLabel;
  }
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

/**********************************************************************************************
                SECTION : 6 -> CONSTRUCTION OF OLD OBJECT FROM  RC.CONF 
**********************************************************************************************/

#if 1
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
    if (IFX_MODIFY_F_SET(uiInFlag)) {
      /* Check If the Object is Registered or not */
      if(IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS)
      {
        /*GET the old Transmit Power Measurement parameter values */
				switch(uiObjectId){
					case IFX_VMAPI_OBJ_DECT_TRANS_POWER:	
									memset(&xOldTP,0,sizeof(x_IFX_VMAPI_TransmitPowerParam));
									xOldTP.iid.config_owner = IFX_VOIP;
									if(ifx_get_TransPower(&xOldTP,0)!=IFX_VMAPI_SUCCESS)
									{
											IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
										 "Error : Get Failed For Transmit Power Measurement");
									}
									xOldObj=&xOldTP;
							break;

							case IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS:
										/*GET the old Transmit Power Measurement parameter values */
										memset(&xOldBmcparam,0,sizeof(x_IFX_VMAPI_DectBMCParams));
										xOldBmcparam.iid.config_owner = IFX_VOIP;
										if(ifx_get_Bmcparam(&xOldBmcparam,0)!=IFX_VMAPI_SUCCESS)
										{
													IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													 "Error : Get Failed For Transmit Power Measurement");
										}
										xOldObj=&xOldBmcparam;
							break;

							case IFX_VMAPI_OBJ_DECT_OSC_TRIM:
										/*GET the old Transmit Power Measurement parameter values */
										memset(&xOldOsctrim,0,sizeof(x_IFX_VMAPI_DectOscTrimVal));
										xOldOsctrim.iid.config_owner = IFX_VOIP;
										if(ifx_get_Osctrim(&xOldOsctrim,0)!=IFX_VMAPI_SUCCESS)
										{
											IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													 "Error : Get Failed For Transmit Power Measurement");
										}
										xOldObj=&xOldOsctrim;
							break;			
							case IFX_VMAPI_OBJ_DECT_GFSK:
										/*GET the old Transmit Power Measurement parameter values */
										memset(&xOldGfsk,0,sizeof(x_IFX_VMAPI_DectGFSKVal));
										xOldGfsk.iid.config_owner = IFX_VOIP;
										if(ifx_get_Gfsk(&xOldGfsk,0)!=IFX_VMAPI_SUCCESS)
										{
											IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													 "Error : Get Failed For GFSK");
										}
												xOldObj=&xOldGfsk;
						break;
						case IFX_VMAPI_OBJ_DECT_COUNTRY_SETTINGS:
									memset(&xOldCtryset,0,sizeof(x_IFX_VMAPI_DectCountrySettings));
									xOldCtryset.iid.config_owner = IFX_VOIP;
									if(ifx_get_CtrySet(&xOldCtryset,0)!=IFX_VMAPI_SUCCESS)
									{
											IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
										 "Error : Get Failed For Transmit Power Measurement");
									}
									xOldObj=&xOldCtryset;
						break;

						case IFX_VMAPI_OBJ_DECT_RFPI:
								/*GET the old Transmit Power Measurement parameter values */
									memset(&xOldRfpi,0,sizeof(x_IFX_VMAPI_DectRfpi));
									xOldRfpi.iid.config_owner = IFX_VOIP;
									if(ifx_get_Rfpi(&xOldRfpi,0)!=IFX_VMAPI_SUCCESS)
									{
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
												 "Error : Get Failed For Transmit Power Measurement");
									}
									xOldObj=&xOldRfpi;
						break;

						case IFX_VMAPI_OBJ_DECT_RF_MODE:
									memset(&xOldRfMode,0,sizeof(x_IFX_VMAPI_RFMode));
									xOldRfMode.iid.config_owner = IFX_VOIP;
									if(ifx_get_rfmode(&xOldRfMode,0)!=IFX_VMAPI_SUCCESS)
									{
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
									 "Error : Get Failed For RF MODE");
									}
									xOldObj=&xOldRfMode;
						break;
						case IFX_VMAPI_OBJ_DECT_XRAM:
									memset(&xOldXram,0,sizeof(x_IFX_VMAPI_DectXRAM));
									xOldXram.iid.config_owner = IFX_VOIP;
									if(ifx_get_Xram(&xOldXram,0)!=IFX_VMAPI_SUCCESS)
									{
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
									 "Error : Get Failed For XRAM");
									}

									xOldObj=&xOldXram;
						break;
						case IFX_VMAPI_OBJ_DECT:	
									memset(&xOldDect,0,sizeof(x_IFX_VMAPI_DectSystem));
									xOldDect.iid.config_owner = IFX_VOIP;
									if(ifx_get_DectInterface(&xOldDect,0)!=IFX_VMAPI_SUCCESS)
									{
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
												 "Error : Get Failed For Dect Handset");
									}
									xOldObj=&xOldDect;
						break;

						case IFX_VMAPI_OBJ_DECT_HANDSET:
									/*GET the old DectHandset parameter values */
									memset(&xOldHandset,0,sizeof(x_IFX_VMAPI_DectHandset));
									xOldHandset.xVoiceServPhyIf.ucInterfaceId = pxDectHand->xVoiceServPhyIf.ucInterfaceId;
									//xOldHandset.iid.pcpeId.Id = pxLineSignaling->iid.pcpeId.Id;
									xOldHandset.iid.config_owner = IFX_VOIP;
									if(ifx_get_DectHandset(&xOldHandset,0)!=IFX_VMAPI_SUCCESS)
									{
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
												 "Error : Get Failed For Dect Handset");
									}
									xOldObj=&xOldHandset;
						break;
						default:
									xOldObj=NULL;
						break;
			}
				 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Object is Registered\n ");
    }
    else
    {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Error : Object Not Registered\n");
    }
   }
  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
#endif
/**********************************************************************************************
                SECTION : 7 -> ROLL BACK SUPPORT, WRITING NEW VALUES into RC.CONF 
**********************************************************************************************/
#ifdef ROLLBACK_SUPPORT 
  /* TODO: */
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  /* Backup rc.conf before proceeding with configuration */
  if ((ret = IFX_VMAPI_CheckPointRet((uiInFlag |!(IFX_F_DONT_CHECKPOINT)),
       SYSTEM_CONF_FILE, CHKPOINT_FILE)) != IFX_SUCCESS) { /* Backup taken */
    goto EndLabel;
  }
	if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf)) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE,uiInFlag|!(IFX_F_DONT_CHECKPOINT) )) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      }
#endif

		 goto EndLabel;
	}

#ifdef DECT_PART
/**********************************************************************************************
                SECTION :  -> WRITING DATA INTO DECT PARTITION  
**********************************************************************************************/
if(!(uiInFlag & IFX_VMAPI_DO_NOT_WRITE_TO_DECT_PART) ){
switch(uiObjectId){
case IFX_VMAPI_OBJ_DECT_GFSK:
case IFX_VMAPI_OBJ_DECT_OSC_TRIM:
case IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS:
case IFX_VMAPI_OBJ_DECT_TRANS_POWER:

/**********************************************************************************************
                SECTION : -> ROLL BACK SUPPORT, WRITING NEW VALUES into RC.CONF 
**********************************************************************************************/
#ifdef ROLLBACK_SUPPORT 
  /* TODO: */
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(DECT_RC_CHKPOINT_FILE2) + 6, "rm -f %s", DECT_RC_CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif

  /* Backup rc.conf before proceeding with configuration */
  if ((ret = IFX_VMAPI_CheckPointRet((uiInFlag |!(IFX_F_DONT_CHECKPOINT)),
       DECT_RC_CONF_FILE, DECT_RC_CHKPOINT_FILE)) != IFX_SUCCESS) { /* Backup taken */
  		// Do nothing....
		}else if (ifx_SetObjData(DECT_RC_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf) != IFX_SUCCESS) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Error : Error While Writting To Dect config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(DECT_RC_CONF_FILE, DECT_RC_CHKPOINT_FILE,uiInFlag|!(IFX_F_DONT_CHECKPOINT) )) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "Warning : Could Not Roll Back Config File \n");
      }
#endif

	}else {
			//Save the dect configuration into the dect flash config.. call the system command.
			system("/etc/rc.d/backup_dect_config");
	}
break;
}
}
#endif

/**********************************************************************************************
                SECTION : 9 -> NOTIFICATION
**********************************************************************************************/
  /*** Send Notification  ***/
  if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
    if (IFX_MODIFY_F_SET(uiInFlag)) {
      if(IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS)
      {
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending The Notification\n");
        IFX_VMAPI_SendNotifyForRegObject(uiObjectType,
                        xOldObj,pvDectObject);
      }
    }
  }/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */

/* Update rc.conf for Indices Compaction for Add/Del op */
  if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
    if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                              IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                              uiInFlag) != IFX_SUCCESS) {
       /*  Now can not do anything...just continue */
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         "Warning : ifx_CompactCfgSection failed \n");
    }
  }

  /*** DEVICE CONFIGURATION BLOCK ***/
  /* Device configuration is not needed for this object */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
  if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             " Cannot write to the flash\n");
  }
#endif

  /*** NOTIFICATION BLOCK ***/
	if( bLoging ) {
		 if (IFX_VMAPI_CheckNSendNotification(iid,
				  (uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL)  ? 0 : uiChangedNvCount,
		      (uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL)  ? NULL : pxList,
		       uiInFlag) != IFX_SUCCESS) {
		    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				 "Info : Notification is Failing\n");
		    goto EndLabel;
	  }

 /*** EPILOG BLOCK ****/
  if (uiOperation == IFX_OP_ADD || uiOperation == IFX_OP_DEL) {
    if (IFX_VMAPI_UpdateMapNAttr(iid,
        (uiOperation == IFX_OP_ADD) ? 0 : uiChangedNvCount,
        (uiOperation == IFX_OP_ADD) ? NULL : pxList, uiInFlag) !=  IFX_SUCCESS) {
				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
			}
	}
}
/**********************************************************************************************
                SECTION : 10 -> CLEAN UP
**********************************************************************************************/
EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
	if(xOldDect.pxHandsetTbl != NULL || xOldDect.pxCodecList != NULL)
 			ifx_vmapi_freeObjectList (&xOldDect,IFX_VMAPI_DECT_SYSTEM);
	IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function\n");
  return ret;
}

#endif

/******************************************************************************
*  Function Name  : LTQ_set_VoiceLineObject
*  Description    : Set api to set various Voice Line Related objects
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxVoiceLineObject - Pointer to the object to be set
*  Output Values  : pxDectObject - pointer to dect related object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_VoiceLineObject(IN uint32  uiOperation,
                      IN_OUT  void *pvVLObject,
                      IN uint32 uiObjectType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag)
{
  IFX_ID *iid = NULL,piid;
  int32 iInstanceIndex = -1 ; 
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
	IFX_NAME_VALUE_PAIR *pxList=NULL; 
  uint32  uiChangedNvCount=0; /* number of changed NVPs */
  uint32 iCpeId,iCpeIdLine,iCpeIdSub; 
  uint32 uiNvIdx = 0; 
  uchar8 buf[5000]; /* buffer used to hold config data */
	char8 acCpeidSec[50],acIIDBuf[25]="\0";
	uchar8 ucLine=0;
	void * xOldObj = NULL;
  int32 ret = IFX_VMAPI_FAIL; /* return value */
	char8 bGloging = 1, bVLineNotification = 0;
	printf("#########LTQ_set_VoiceLineObject : with object id %d & type : %d \n",uiObjectId,uiObjectType);
 //Calling feature related object 
 	x_IFX_VMAPI_LineCallingFeatures xOldLineCallingFeatures;
	x_IFX_VMAPI_LineCallingFeatures  *pxLineCallingFeatures = NULL;

	//Signaling feature related objects
	x_IFX_VMAPI_LineSignaling xOldLineSig;
	x_IFX_VMAPI_LineSignaling *pxLineSignaling = NULL;

	//Line Events related
	x_IFX_VMAPI_LineEvents *pxLineEvents = NULL;
	x_IFX_VMAPI_LineEvents xOldLineEvents;

	//Auth config related
	x_IFX_VMAPI_SipAuthCfg *pxAuthCfg = NULL;


	//Line subscrption related...
	x_IFX_VMAPI_LineSubscription *pxLineSubscr = NULL;
	x_IFX_VMAPI_LineSubscription xOldLineSub;

	//Line codec list related
	x_IFX_VMAPI_LineCodecList *pxCodecList = NULL;

	//Line codec Description related
	x_IFX_VMAPI_CodecDesc *pxCodecDesc = NULL;

	//Line codec related
	x_IFX_VMAPI_LineCodec  *pxLineVoiceCodec = NULL;

	//Line voice processing related
	x_IFX_VMAPI_LineVoiceProcessing  *pxLineVoiceProcessing = NULL;

	//Voice Line related
	x_IFX_VMAPI_VoiceLine  *pxVoiceLine = NULL,*pxLineTemp = NULL;
	x_IFX_VMAPI_VoiceLine  xVoiceLine;

	//Line stats related
	x_IFX_VMAPI_LineStats *pxLineStats = NULL;

	//Voice Line sessionr related
	x_IFX_VMAPI_LineSession  *pxLineVoiceSession = NULL;

	//VoiceService related
	x_IFX_VMAPI_VoiceService *pxVoiceService = NULL;

	//Voicecodec capabality related
	x_IFX_VMAPI_VoiceCodecCapabilities *pxVoiceCodecCaps = NULL;

	//Voicecode cap entry related
	x_IFX_VMAPI_CodecDesc *pxVCCapsEntry = NULL;

	//FXS interface related
	x_IFX_VMAPI_FxsPhyIf *pxFxsPhyIf = NULL;
	x_IFX_VMAPI_FxsPhyIf xOldFxs;

	//FXO interface related
	x_IFX_VMAPI_FxoPhyIf *pxFxoPhyIf = NULL;
	x_IFX_VMAPI_FxoPhyIf xOldFxo;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 	"Entering Function\n");
/**********************************************************************************************
        SECTION : 1 -> OPERATION AND FLAG VERIFICATION 
**********************************************************************************************/
/***  PROLOG BLOCK   ***/
  if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
  }


  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
		  IFX_VALIDATE_FLAGS(uiInFlag);
  }

/**********************************************************************************************
        SECTION : 2 -> POINTER CONVERTION, CPEID,ENTRY ID , PARENT CPEID IDENTIFICATION 
**********************************************************************************************/

  switch(uiObjectId){
			case IFX_VMAPI_OBJ_VL_CALLFEAT:
							pxLineCallingFeatures = (x_IFX_VMAPI_LineCallingFeatures  *)pvVLObject;
							iid=&(pxLineCallingFeatures->iid);
							strcpy(acCpeidSec,"VoiceLineCallFeat_CpeId");
							strcpy(acIIDBuf,"EnableDnd");
							ucLine = pxLineCallingFeatures->ucLineId;
							iCpeId = iid->cpeId.Id;
			break;
				
			case IFX_VMAPI_OBJ_VL_SIGNALING:
							pxLineSignaling = (x_IFX_VMAPI_LineSignaling *)pvVLObject;
              iid=&(pxLineSignaling->iid);
							strcpy(acCpeidSec,"VoiceLineSignaling_CpeId");
							//strcpy(acIIDBuf,"");
							ucLine = pxLineSignaling->ucLineId;
							iCpeId = iid->cpeId.Id;
			break;

			case IFX_VMAPI_OBJ_LINEEVENTS:
			       pxLineEvents=(x_IFX_VMAPI_LineEvents *)pvVLObject;
             iid=&(pxLineEvents->iid);
							strcpy(acCpeidSec,"LineSubEvent_CpeId");
							strcpy(acIIDBuf,"SubEvt");
							ucLine = pxLineEvents->ucLineId;
							iCpeId = iid->cpeId.Id;
			break;

			case IFX_VMAPI_OBJ_AUTHCFG:
							pxAuthCfg = (x_IFX_VMAPI_SipAuthCfg *)pvVLObject;
              iid=&(pxAuthCfg->iid);
							strcpy(acCpeidSec,"AuthCfg_CpeId");
							//strcpy(acIIDBuf,"SubEvt");
							ucLine = pxAuthCfg->ucLineId;
							iCpeId = iid->cpeId.Id;
							bGloging = 0;
			break;

			case IFX_VMAPI_OBJ_LINESUB:
							pxLineSubscr = (x_IFX_VMAPI_LineSubscription *)pvVLObject;
              iid=&(pxLineSubscr->iid);
              strcpy(acCpeidSec,"LineSubscription_CpeId");
              //strcpy(acIIDBuf,"SubEvt");
              ucLine = pxLineSubscr->ucLineId;
              iCpeId = iid->cpeId.Id;
              bGloging = 0;
			break;

			case IFX_VMAPI_OBJ_VL_CODECLIST:
							pxCodecList = (x_IFX_VMAPI_LineCodecList *)pvVLObject;
              iid=&(pxCodecList->iid);
              strcpy(acCpeidSec,"LineCodecList_CpeId");
              //strcpy(acIIDBuf,"SubEvt");
              ucLine = pxCodecList->ucLineId;
              iCpeId = iid->cpeId.Id;
              bGloging = 0;
		break;	

		case IFX_VMAPI_OBJ_CODEC_DESC:
							pxCodecDesc	=(x_IFX_VMAPI_CodecDesc *)pvVLObject;
              iid=&(pxCodecDesc->iid);
              strcpy(acCpeidSec,"List_CpeId");
              strcpy(acIIDBuf,"SupFrame");
              ucLine = pxCodecDesc->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;
			
		case IFX_VMAPI_OBJ_VL_VOICE_CODEC:
							pxLineVoiceCodec =(x_IFX_VMAPI_LineCodec *)pvVLObject;
              iid=&(pxLineVoiceCodec->iid);
              strcpy(acCpeidSec,"VoiceLineVoiceCodec_CpeId");
              strcpy(acIIDBuf,"SupFrame");
              ucLine = pxLineVoiceCodec->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;
			
		case IFX_VMAPI_OBJ_VL_VOICE_PROCESSING:
							pxLineVoiceProcessing = (x_IFX_VMAPI_LineVoiceProcessing  *)pvVLObject;
              iid=&(pxLineVoiceProcessing->iid);
              sprintf(acCpeidSec,"%s","VoiceLineVoiceProcessing_CpeId");
              sprintf(acIIDBuf,"%s","SupFrame");
              ucLine = pxLineVoiceProcessing->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;
				
		case IFX_VMAPI_OBJ_VOICE_LINE:
							pxVoiceLine =(x_IFX_VMAPI_VoiceLine *)pvVLObject;
              iid=&(pxVoiceLine->iid);
              sprintf(acCpeidSec, "%s", "VoiceProfile_CpeId");
              sprintf(acIIDBuf, "%s", "DirName");
              ucLine = pxVoiceLine->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;			

		case IFX_VMAPI_OBJ_LINE_STATS:
							pxLineStats =(x_IFX_VMAPI_LineStats *)pvVLObject;
              iid=&(pxLineStats->iid);
              sprintf(acCpeidSec, "%s", "LineStats_CpeId");
              //sprintf(acIIDBuf, "%s", "DirName");
              ucLine = pxLineStats->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;	
		case IFX_VMAPI_OBJ_VL_VOICE_SESSION:
							pxLineVoiceSession =(x_IFX_VMAPI_LineSession *)pvVLObject;
              iid=&(pxLineVoiceSession->iid);
              sprintf(acCpeidSec, "%s", "VoiceLineSession_CpeId");
              //sprintf(acIIDBuf, "%s", "DirName");
              ucLine = pxLineVoiceSession->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;	
		case IFX_VMAPI_OBJ_VOICE_SERVICE:
							pxVoiceService =(x_IFX_VMAPI_VoiceService *)pvVLObject;
              iid=&(pxVoiceService->iid);
							sprintf(acCpeidSec, "%s", "VoiceLineSession_CpeId");
              sprintf(acIIDBuf, "%s", "LineIdList");
              iCpeId = iid->cpeId.Id;
		break;
		
		case IFX_VMAPI_OBJ_CODEC_CAPABS:
							pxVoiceCodecCaps =(x_IFX_VMAPI_VoiceCodecCapabilities *)pvVLObject;
              iid=&(pxVoiceCodecCaps->iid);
							sprintf(acCpeidSec, "%s", "VoiceLineSession_CpeId");
              sprintf(acIIDBuf, "%s", "FwSuppCodec");
              iCpeId = iid->cpeId.Id;
		break;
		case	IFX_VMAPI_OBJ_CODEC_CAPABS_ENTRY:
							pxVCCapsEntry =(x_IFX_VMAPI_CodecDesc *)pvVLObject;
              iid=&(pxVCCapsEntry->iid);
							sprintf(acCpeidSec, "%s", "VoiceLineSession_CpeId");
              sprintf(acIIDBuf, "%s", "ID");
              ucLine = pxVCCapsEntry->ucLineId;
              iCpeId = iid->cpeId.Id;
		break;

		case IFX_VMAPI_OBJ_FXSPHYINT:
							 pxFxsPhyIf =(x_IFX_VMAPI_FxsPhyIf *)pvVLObject;
              iid=&(pxFxsPhyIf->iid);
							sprintf(acCpeidSec, "%s", "FxsphyInterface_CpeId");
              sprintf(acIIDBuf, "%s", "ID");
							IFX_VMAPI_Get_CpeId_opt("FxsphyInterface_CpeId",pxFxsPhyIf->xVoiceServPhyIf.ucInterfaceId,&iCpeId);
					    pxFxsPhyIf->iid.cpeId.Id = iCpeId;
							pxFxsPhyIf->iid.pcpeId.Id = 1;
              bGloging = 0;
		break;

		case IFX_VMAPI_OBJ_FXOPHYINT:
               pxFxoPhyIf =(x_IFX_VMAPI_FxoPhyIf *)pvVLObject;
              iid=&(pxFxoPhyIf->iid);
              sprintf(acCpeidSec, "%s", "FxophyInterface_CpeId");
              sprintf(acIIDBuf, "%s", "ID");
              IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",(pxFxoPhyIf->xVoiceServPhyIf.ucInterfaceId-2),&iCpeId);
              pxFxoPhyIf->iid.cpeId.Id = iCpeId;
              pxFxoPhyIf->iid.pcpeId.Id = 1;
              bGloging = 0;
    break;

		default:
				return IFX_VMAPI_FAILURE;

	}
/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
	   CpeId is already passed to it. */
  if(iid->config_owner == IFX_TR69)  {
    if(IFX_VMAPI_OBJ_VOICE_LINE != uiObjectId){
    	IFX_VMAPI_GetLineIdFromCpeId(iid->pcpeId.Id, &ucLine);
	}else{
    	IFX_VMAPI_GetLineIdFromCpeId(iid->cpeId.Id, &ucLine);
	}
		switch(uiObjectId){
			  case IFX_VMAPI_OBJ_VL_CALLFEAT:
	  						pxLineCallingFeatures->ucLineId = ucLine;
				break;
				
				case IFX_VMAPI_OBJ_VL_SIGNALING:
							pxLineSignaling->ucLineId = ucLine;
				break;
			
				case IFX_VMAPI_OBJ_LINEEVENTS:
							pxLineEvents->ucLineId = ucLine;
				break;

				case IFX_VMAPI_OBJ_AUTHCFG:
								pxAuthCfg->ucLineId = ucLine; 
								IFX_VMAPI_Get_CpeId_opt("AuthCfg_CpeId",(((pxAuthCfg->ucLineId-1)*IFX_VMAPI_MAX_AUTH_INFO)+pxAuthCfg->ucIndex),&iCpeId);
						    pxAuthCfg->iid.cpeId.Id = iCpeId;
				break;
				
				case IFX_VMAPI_OBJ_LINESUB:
              pxLineSubscr->ucLineId = ucLine;
				break;
				
				case IFX_VMAPI_OBJ_CODEC_DESC:
							pxCodecDesc->ucLineId = ucLine;
				break;
				
				case IFX_VMAPI_OBJ_VL_VOICE_CODEC:
						pxLineVoiceCodec->ucLineId = ucLine;
				break;
				
				case IFX_VMAPI_OBJ_VL_VOICE_PROCESSING:
              pxLineVoiceProcessing->ucLineId = ucLine;
				break;
				
				case IFX_VMAPI_OBJ_VOICE_LINE:
              pxVoiceLine->ucLineId  = ucLine;
				break;
				
				case IFX_VMAPI_OBJ_LINE_STATS:
              pxLineStats->ucLineId = ucLine;
				break;

				case IFX_VMAPI_OBJ_VL_VOICE_SESSION:
						pxLineVoiceSession->ucLineId =  ucLine;
				break;
		}
	} else 	if((iid -> config_owner == IFX_WEB)||(iid -> config_owner == IFX_VOIP))  {
			switch(uiObjectId) {
		
				/*	case IFX_VMAPI_OBJ_LINESUB:
				case IFX_VMAPI_OBJ_VL_CODECLIST:
			  case IFX_VMAPI_OBJ_VL_VOICE_CODEC:*/
				default :
						    IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",ucLine,&iCpeIdLine);
							  iid->pcpeId.Id = iCpeIdLine;
						  	if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
						  	{
					      		IFX_VMAPI_Get_CpeId_opt(acCpeidSec,ucLine,&iCpeId);
										iid->cpeId.Id = iCpeId;
						  	}
				break;

				case IFX_VMAPI_OBJ_LINEEVENTS:
						IFX_VMAPI_Get_CpeId_opt("LineSubscription_CpeId",ucLine,&iCpeIdSub);
						pxLineEvents->iid.pcpeId.Id = iCpeIdSub;	
						if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
						{
								IFX_VMAPI_Get_CpeId_opt(acCpeidSec,(((pxLineEvents->ucLineId- 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxLineEvents->ucIndex),&iCpeId);
								pxLineEvents->iid.cpeId.Id = iCpeId;
						}
				break;

				case IFX_VMAPI_OBJ_AUTHCFG:
							if (pxAuthCfg->ucIndex){
									IFX_VMAPI_Get_CpeId_opt(acCpeidSec,(((pxAuthCfg->ucLineId-1)*IFX_VMAPI_MAX_AUTH_INFO)+pxAuthCfg->ucIndex),&iCpeId);
							}else{
										iCpeId = 0;
							}
							pxAuthCfg->iid.cpeId.Id = iCpeId;
							//Get the parent cpeid
							IFX_VMAPI_Get_CpeId_opt("VoiceLineSignaling_CpeId",ucLine,&iCpeIdSub);
							pxAuthCfg->iid.pcpeId.Id = iCpeIdSub;
				break;
			
				case IFX_VMAPI_OBJ_CODEC_DESC:
							IFX_VMAPI_Get_CpeId_opt("LineCodecList_CpeId",ucLine,&iCpeIdSub);
							pxCodecDesc->iid.pcpeId.Id = iCpeIdSub;

							if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
							{
									IFX_VMAPI_Get_CpeId_opt(acCpeidSec,(((pxCodecDesc->ucLineId-1)*IFX_VMAPI_MAX_CODECS)+pxCodecDesc->ucIndex),&iCpeId);
									pxCodecDesc->iid.cpeId.Id = iCpeId;
							}
				break;

				case IFX_VMAPI_OBJ_VOICE_LINE:
								printf(">>>>>>>>>>>>>>>> 1 \n");
								IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",pxVoiceLine->ucProfileId,&iCpeIdSub);
								iid->pcpeId.Id = iCpeIdSub;

								if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
										IFX_VMAPI_Get_CpeId_opt("VoiceLine_CpeId",pxVoiceLine->ucLineId,&iCpeId);
										iid->cpeId.Id = iCpeId;
								}
					break;
			
				case IFX_VMAPI_OBJ_FXSPHYINT:
							IFX_VMAPI_Get_CpeId_opt("FxsphyInterface_CpeId",pxFxsPhyIf->xVoiceServPhyIf.ucInterfaceId,&iCpeId);
							pxFxsPhyIf->iid.cpeId.Id = iCpeId;	
				break;
				
				case IFX_VMAPI_OBJ_FXOPHYINT:
							IFX_VMAPI_Get_CpeId_opt("FxophyInterface_CpeId",pxFxoPhyIf->xVoiceServPhyIf.ucInterfaceId-2,&iCpeId);
							pxFxoPhyIf->iid.cpeId.Id = iCpeId;	
				break;
				
				case IFX_VMAPI_OBJ_VOICE_SERVICE:
							printf("IFX_VMAPI_OBJ_VOICE_SERVICE -2 \n");
						iid->cpeId.Id = 1;	
						iid->pcpeId.Id = 1;	
				break;
			}
		}
	IFX_VMAPI_STRCPY(iid->cpeId.secName,
										IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
	/**********************************************************************************************
					SECTION : 3 -> INSTANCE INDEX FINDING (MODIFY/DELETE) / CPEID GENERATION (ADD)
	**********************************************************************************************/
	/* Get Config Index in case of modify/delete operations */
		if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
			if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
					 &iid->cpeId, &iInstanceIndex) != IFX_SUCCESS) {
				 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Error : Could Not Get Index From cpeid \n");
				 IFX_VMAPI_UNLOCK(uiLock);
				 return ret;  
			}
  } 
   /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
	switch(uiObjectId) {
	
			default:
								if (ifx_get_IID(iid, acIIDBuf) != IFX_SUCCESS) {
										IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
										"Failed to get the iid !!\n\n");
										IFX_VMAPI_UNLOCK(uiLock);
										return IFX_VMAPI_FAIL;
							}
			break;

			case IFX_VMAPI_OBJ_AUTHCFG:
			case IFX_VMAPI_OBJ_LINESUB:
			case IFX_VMAPI_OBJ_VL_CODECLIST:
					memset(&piid,0,sizeof(piid));    
					piid.cpeId.Id = iid->pcpeId.Id;
					sprintf(piid.cpeId.secName, "%s", iid->pcpeId.secName);
					if (ifx_get_iid(iid->cpeId.secName, piid.cpeId.secName, &piid, iid) != IFX_SUCCESS) {
							IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							"Failed to get the iid !!\n\n");
							IFX_VMAPI_UNLOCK(uiLock);
							return IFX_VMAPI_FAIL;
					}
			break;
	}
		/* increment the next cpe id for this object */
	ifx_increment_next_cpeId(SYSTEM_CONF_FILE, 
	IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
		switch(uiObjectId) {
				case IFX_VMAPI_OBJ_VL_CALLFEAT :
							IFX_VMAPI_Default_CallingFeature(pxLineCallingFeatures);
				break;
				
				case  IFX_VMAPI_OBJ_CODEC_DESC:
							IFX_VMAPI_Default_LineCodecDesc(pxCodecDesc);
				break;
				
				case IFX_VMAPI_OBJ_VOICE_LINE:
								pxVoiceLine->ucLineId = iid->cpeId.Id ;
								IFX_VMAPI_Default_VoiceLine(pxVoiceLine);
				break;
		}
	}

/**********************************************************************************************
                SECTION : 4 -> MODIFY PARENT IF ANY, GENERATE NAME VALUE TABLE 
**********************************************************************************************/ 

	// Special operation case for VoiceLine
		if (uiOperation == IFX_OP_MOD) {
		switch(uiObjectId) {
					case IFX_VMAPI_OBJ_VOICE_LINE: {
								printf(">>>>>>>>>>>>>>>> VoiceLine modified 2 \n");
							uint32 i=0,j=0;
							char8 XArray[2*IFX_VMAPI_MAX_VOICE_INTERFACES]={'\0'};
							pxLineTemp = (x_IFX_VMAPI_VoiceLine *)malloc(sizeof(x_IFX_VMAPI_VoiceLine));
							if(pxLineTemp == NULL){
											IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
											"Failed to allocate memory !!\n\n");
											return IFX_VMAPI_FAIL;
							}
							else {
											memcpy(pxLineTemp,pxVoiceLine,sizeof(x_IFX_VMAPI_VoiceLine));
							}

						  while(pxVoiceLine->ucAssocVoiceInterface[i] != 0)
					    {
							      sprintf(&XArray[j],"%d",pxVoiceLine->ucAssocVoiceInterface[i]);
							      strcat(XArray,",");
							      j = strlen(XArray);
							      i++;
					    }
						strncpy((char8 *)pxVoiceLine->ucAssocVoiceInterface,XArray,
										 sizeof(pxVoiceLine->ucAssocVoiceInterface));
				}
				break;

		}
	}

	/* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));

  IFX_VMAPI_LOCK(uiLock);

	//Special modification handling in the case of voice line signaling......
	if(IFX_MODIFY_F_SET(uiInFlag) ) {
			switch(uiObjectId) {
					case  IFX_VMAPI_OBJ_VL_SIGNALING :
					{
								x_IFX_VMAPI_SipAuthCfg *pxTemp;
								/* Set should happen for AuthCfg list */
				  		  pxTemp = pxLineSignaling->pxAuthCfg;
								pxLineSignaling->ucNoOfSipAuthCfg = 0;
								while(pxTemp !=NULL)
							 {
									pxTemp->ucLineId = pxLineSignaling->ucLineId;
									pxTemp->iid.config_owner = pxLineSignaling->iid.config_owner;
									ifx_set_AuthCfg(IFX_OP_MOD,pxTemp,0);
									pxLineSignaling->ucNoOfSipAuthCfg++;
									__ifx_list_GetNext((void *)&pxTemp);
								}
					}
				break;
				
				case IFX_VMAPI_OBJ_LINESUB:
				{
							x_IFX_VMAPI_LineEvents *pxTemp;
							memset(&xOldLineSub,0,sizeof(x_IFX_VMAPI_LineSubscription));
							xOldLineSub.ucLineId = pxLineSubscr->ucLineId;
							xOldLineSub.iid.cpeId.Id = pxLineSubscr->iid.cpeId.Id;
							xOldLineSub.iid.pcpeId.Id = pxLineSubscr->iid.pcpeId.Id;
							xOldLineSub.iid.config_owner = IFX_VOIP;
							ifx_get_LineSubscription(&xOldLineSub , IFX_F_DEFAULT);

							//pxTemp = pxLineSubscr->pxLineEvents;
							pxTemp = xOldLineSub.pxLineEvents;
							pxLineSubscr->ucNoOfLineEvents = 0;
							while(pxTemp !=NULL)
							{
									//pxTemp->iid.cpeId.Id =pxLineSubscr->ucNoOfLineEvents+1;
									pxTemp->iid.config_owner = pxLineSubscr->iid.config_owner;
									ifx_set_LineEvents(IFX_OP_MOD,pxTemp,0);
									pxLineSubscr->ucNoOfLineEvents++;
									__ifx_list_GetNext((void *)&pxTemp);
							}
				}	
			break;
			case IFX_VMAPI_OBJ_VL_CODECLIST:
			{
							x_IFX_VMAPI_CodecDesc *pxTemp;
							pxTemp = pxCodecList->pxCodecList;
							pxCodecList->uiNumCodecs = 0;
							while(pxTemp !=NULL)
							{
										//Need to check why he is updating the child objects with out any data....
										//pxTemp->iid.cpeId.Id =pxCodecList->uiNumCodecs+1;
										pxTemp->iid.config_owner = pxCodecList->iid.config_owner;
										ifx_set_CodecDesc(IFX_OP_MOD,pxTemp,0);
										pxCodecList->uiNumCodecs++;
									__ifx_list_GetNext((void *)&pxTemp);
							}
			}
			break;
				
			case IFX_VMAPI_OBJ_VOICE_SERVICE: {
						/*Parse the ProifleId list in comma sepearted string*/
						 int32 i=0,j=0;
						 char8 XArray[IFX_VMAPI_MAX_DEVICE * IFX_VMAPI_MAX_DEV_STR_LEN]={'\0'};
						 while(pxVoiceService->ucProfileIdList[i] != 0)
						 {
								 sprintf(&XArray[j],"%d",pxVoiceService->ucProfileIdList[i]);
								 strcat(XArray,",");
								 j = strlen(XArray);
								 i++;
						 }
						 strncpy((char8 *)pxVoiceService->ucProfileIdList,XArray,
														 sizeof(pxVoiceService->ucProfileIdList));

						 /*Parse the LineId list in comma sepearted string*/
						 i=0;
						 j=0;
						 memset(&XArray,0,sizeof(XArray));
						 while(pxVoiceService->ucLineIdList[i] != 0)
						 {
							 sprintf(&XArray[j],"%d",pxVoiceService->ucLineIdList[i]);
							 strcat(XArray,",");
							 j = strlen(XArray);
							 i++;
						 }
						 strncpy((char8 *)pxVoiceService->ucLineIdList,XArray,
														 sizeof(pxVoiceService->ucLineIdList));

						 i=0;
						 j=0;
						 memset(&XArray,0,sizeof(XArray));
						 while(pxVoiceService->acDeviceList[i][0] != '\0')
						 {
							 sprintf(&XArray[j],"%s",pxVoiceService->acDeviceList[i]);
							 strcat(XArray,",");
							 j = strlen(XArray);
							 i++;
						 }
						 strcpy(pxVoiceService->acDeviceList[0],XArray);
				}
				break;

				case IFX_VMAPI_OBJ_FXSPHYINT: {
							int32 i=0,j=0;
							char8 XArray[2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES+1]={'\0'};
							 while(pxFxsPhyIf->ucVoiceLineIdList[i] != 0)
							{
									 sprintf(&XArray[j],"%d",pxFxsPhyIf->ucVoiceLineIdList[i]);
									 strcat(XArray,",");
									 j = strlen(XArray);
									 i++;
							}
						 strcpy((char8 *)pxFxsPhyIf->ucVoiceLineIdList,XArray);	
				}	
				break;

				case IFX_VMAPI_OBJ_FXOPHYINT: {
							int32 i=0,j=0;
							char8 XArray[2*IFX_VMAPI_MAX_PHY_ENDPTS]={'\0'};
							 memset(XArray,0,2*IFX_VMAPI_MAX_PHY_ENDPTS+2);
							 while(pxFxoPhyIf->ucInterfaceIdList[i] != 0)
							 {
									 sprintf(&XArray[j],"%d",pxFxoPhyIf->ucInterfaceIdList[i]);
									 strcat(XArray,",");
									 j = strlen(XArray);
									 i++;
							 }
						 strcpy((char8 *)pxFxoPhyIf->ucInterfaceIdList,XArray);
				}
				break;
		
		}
	}
	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvVLObject, 
                                         NULL,
                                         &xNVList, 
                                         &uiNvIdx, 
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Could Not Get NV List \n");
    		goto EndLabel;
  }

  if (ifx_get_conf_index_and_nv_pairs(iid,
  											              iInstanceIndex,
											                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
											                xNVList.unNoOfNVPairs,
											                xNVList.axNameValue,
											                uiInFlag) != IFX_SUCCESS) {
                       
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : ifx_get_conf_index_and_nv_pairs failed \n");
		goto EndLabel;  
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag)) {
		switch(uiObjectId) {
					default:
    							if (IFX_VMAPI_CheckACLRet(iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {
                                        
							        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
							 				"Error : Could Not Get Changed Field Names \n");
											goto EndLabel;    
									}
					break;

					case IFX_VMAPI_OBJ_LINESUB:
					case IFX_VMAPI_OBJ_VL_CODECLIST: 
					case IFX_VMAPI_OBJ_CODEC_CAPABS:
					case IFX_VMAPI_OBJ_FXSPHYINT: 
					case IFX_VMAPI_OBJ_FXOPHYINT: 
								if(ifx_cmp_and_return_changed_fvp(&iid->cpeId.secName[0],  
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               (int32 *)&uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
								        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
											 "Error : Could Not Get Changed Field Names \n");
											goto EndLabel;
								}
					break;
					case IFX_VMAPI_OBJ_AUTHCFG:
							//This object doesn;t require any of above 2 checks.... so skipping
							uiObjectId= uiObjectId;
					break;
			}

	}
/**********************************************************************************************
                SECTION : 5 -> CHECKING FOR NUMBER OF MODIFIED FIELDS 
**********************************************************************************************/
/*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) { 
		    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
				pxList = pxChangedNvList;
  }
  else {
		    uiChangedNvCount = xNVList.unNoOfNVPairs;
				ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
		    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
			  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						"Error : Could Not Form Buffer From NV List\n");
						printf(">>>>>>>>Error : Could Not Form Buffer From NV List\n");
				goto EndLabel;
  }
  
  if (!uiChangedNvCount) {
				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
			 printf(">>>>>>>>Info : There Are No Changed Fields Or No Fields To Be Added.\n");
				goto EndLabel;  
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);
/**********************************************************************************************
                SECTION : 6 -> CONSTRUCTION OF OLD OBJECT FROM  RC.CONF 
**********************************************************************************************/
	if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
			//Notification for various voiceLine operations.....
			if(uiObjectId == IFX_VMAPI_OBJ_VOICE_LINE ){
					if(uiOperation == IFX_OP_ADD && IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_ADD_LINE) == IFX_VMAPI_SUCCESS){
								bVLineNotification = 1;
					}else if(uiOperation == IFX_OP_MOD && IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_VOICE_LINE) == IFX_VMAPI_SUCCESS){
								bVLineNotification = 1;
					}else if(uiOperation == IFX_OP_DEL && IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_DELETE_LINE) == IFX_VMAPI_SUCCESS){
								bVLineNotification = 1;
					}
			}		

	if (IFX_MODIFY_F_SET(uiInFlag) || bVLineNotification) {
      /* Check If the Object is Registered or not */
      if(IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS || bVLineNotification)
      {
					switch(uiObjectId){
							case IFX_VMAPI_OBJ_FXSPHYINT: 
										/*GET the old FXS Physical Interface parameter values */
									  memset(&xOldFxs,0,sizeof(x_IFX_VMAPI_FxsPhyIf));
						  	    xOldFxs.xVoiceServPhyIf.ucInterfaceId = pxFxsPhyIf->xVoiceServPhyIf.ucInterfaceId;
								    xOldFxs.iid.pcpeId.Id = 1;
							      xOldFxs.iid.config_owner = IFX_VOIP;
							      if(ifx_get_FxsPhyInterface(&xOldFxs,0)!=IFX_VMAPI_SUCCESS)
							      {
									        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							             "Error : Get Failed For Fxs");
							      }
										 xOldObj = &xOldFxs;
								break;	
								case IFX_VMAPI_OBJ_FXOPHYINT: {
                   	int i=0,j=0;
										char8 XArray[2*IFX_VMAPI_MAX_PHY_ENDPTS]={'\0'};
										 /*GET the old FXS Physical Interface parameter values */
                    memset(&xOldFxo,0,sizeof(x_IFX_VMAPI_FxoPhyIf));
                    xOldFxo.xVoiceServPhyIf.ucInterfaceId = pxFxoPhyIf->xVoiceServPhyIf.ucInterfaceId;
                    xOldFxo.iid.pcpeId.Id = 1;
                    xOldFxo.iid.config_owner = IFX_VOIP;
                    if(ifx_get_FxoPhyInterface(&xOldFxo,0)!=IFX_VMAPI_SUCCESS)
                    {
                          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                           "Error : Get Failed For Fxs");
                    }
						    	 while(xOldFxo.ucInterfaceIdList[i] != 0){
					     		
								       sprintf(&XArray[j],"%d",xOldFxo.ucInterfaceIdList[i]);
								       strcat(XArray,",");
								       j = strlen(XArray);
								       i++;
							     }
							     strcpy((char8 *)xOldFxo.ucInterfaceIdList,XArray);
                     xOldObj = &xOldFxo;
								}
								break;
							
								case IFX_VMAPI_OBJ_VL_CALLFEAT:
											memset(&xOldLineCallingFeatures,0,sizeof(x_IFX_VMAPI_LineCallingFeatures));
											xOldLineCallingFeatures.ucLineId=pxLineCallingFeatures->ucLineId;
											ifx_get_LineCallingFeatures(&xOldLineCallingFeatures,IFX_VMAPI_OP_DEFAULT);
											xOldObj = &xOldLineCallingFeatures;
								break;

								case  IFX_VMAPI_OBJ_VL_SIGNALING:
											/*GET the old LineSignaling parameter values */
											memset(&xOldLineSig,0,sizeof(x_IFX_VMAPI_LineSignaling));
											xOldLineSig.ucLineId = pxLineSignaling->ucLineId;
											xOldLineSig.iid.config_owner = IFX_VOIP;//pxLineSignaling->iid.config_owner;
											if(ifx_get_LineSignaling(&xOldLineSig,0)!=IFX_VMAPI_SUCCESS)
											{
															IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															 "Error : Get Failed For Line Signaling");
											}
										xOldObj = &xOldLineSig;
	              break;
		  					case IFX_VMAPI_OBJ_LINEEVENTS:
											/*GET the old LineSignaling parameter values */
											memset(&xOldLineEvents,0,sizeof(x_IFX_VMAPI_LineEvents));
											xOldLineEvents.ucLineId = pxLineEvents->ucLineId;
											xOldLineEvents.iid.config_owner = IFX_VOIP;//pxLineSignaling->iid.config_owner;
											if(ifx_get_LineEvents(&xOldLineEvents,0)!=IFX_VMAPI_SUCCESS)
											{
															IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															 "Error : Get Failed For Line Signaling");
											}
											xOldObj = &xOldLineEvents;
								break;

							case IFX_VMAPI_OBJ_VOICE_LINE: {
										switch(uiOperation){
													case IFX_OP_ADD:
																	memset(&xVoiceLine,0,sizeof(x_IFX_VMAPI_VoiceLine));
															    xVoiceLine.iid.pcpeId.Id = pxVoiceLine->ucProfileId;
																	uiObjectType = IFX_VMAPI_ADD_LINE;
													break;
															
													case IFX_OP_DEL:
													case IFX_OP_MOD:
																		memset(&xVoiceLine,0,sizeof(x_IFX_VMAPI_VoiceLine));
															      xVoiceLine.ucLineId = pxVoiceLine->ucLineId;
															      xVoiceLine.iid.pcpeId.Id = pxVoiceLine->ucProfileId;
															      xVoiceLine.iid.config_owner = IFX_VOIP;
															      if(ifx_get_VoiceLine(&xVoiceLine,0)==IFX_VMAPI_FAIL)
															      {
																		        printf("GET Failed for VoiceLine\n");
														    	  }
																		if(IFX_OP_DEL == uiOperation)
																			uiObjectType = IFX_VMAPI_DELETE_LINE;
													break;
										}
										xOldObj = &xVoiceLine;
								}
						break;
        }
      }
    }
	}else 
		printf(">>>>>> Notification not requested for %d \n",uiObjectId);
/**********************************************************************************************
                SECTION : 7 -> ROLL BACK SUPPORT, WRITING NEW VALUES into RC.CONF 
**********************************************************************************************/
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
/* Backup rc.conf before proceeding with configuration */
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                         uiInFlag,
                         1,
                         (char8*)buf
                        )) != IFX_SUCCESS) {
      
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 				"Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						 "Warning : Could Not Roll Back Config File\n");
      } 
#endif
		goto EndLabel;
    } else {
/**********************************************************************************************
                SECTION : 8 -> ENTRY ID, CPEID UPDATION 
**********************************************************************************************/
      /* Config file is updated */
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE, 
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId), 
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
 								"Warning : ifx_CompactCfgSection failed \n");
          }
        }

 /* CPEID UPDATION BLOCK */ 
				if (IFX_INT_ADD_F_SET(uiInFlag)) {
						switch(uiObjectId){
									default:
											 IFX_VMAPI_Update_CpeId_opt(acCpeidSec, ucLine,iid->cpeId.Id);
									break;
									case IFX_VMAPI_OBJ_LINEEVENTS:
												IFX_VMAPI_Update_CpeId_opt("LineSubEvent_CpeId",
                                   (((pxLineEvents->ucLineId-1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxLineEvents->ucIndex),
                                   pxLineEvents->iid.cpeId.Id);
									break;
				
									case IFX_VMAPI_OBJ_AUTHCFG:
												IFX_VMAPI_Update_CpeId_opt("AuthCfg_CpeId", 
                                (((pxAuthCfg->ucLineId-1)*IFX_VMAPI_MAX_AUTH_INFO)+pxAuthCfg->ucIndex),
                                pxAuthCfg->iid.cpeId.Id);	
									break;

									case  IFX_VMAPI_OBJ_CODEC_DESC:
							           IFX_VMAPI_Update_CpeId_opt("List_CpeId",
                           (((pxCodecDesc->ucLineId-1)*IFX_VMAPI_MAX_CODECS)+pxCodecDesc->ucIndex),
					                  pxCodecDesc->iid.cpeId.Id);
									break;
									case IFX_VMAPI_OBJ_VOICE_LINE:
												/* Append the new Line Id in VoiceService LineIdList */
										    IFX_VMAPI_Update_NewLineId(IFX_VMAPI_Get_NewLineId());
												/* Assign the Latest Line Id to the new VoiceProfile.
											 This is required to Update the CpeId list */
											  pxVoiceLine->ucLineId = IFX_VMAPI_Get_LatestLineId();
												sprintf(pxVoiceLine->acName,"Line%d",pxVoiceLine->ucLineId);
												pxVoiceLine->ucLineMode = 1;/*Multi Call mode*/
												pxVoiceLine->ucIntrusion = 0;
										    /* Update the CpeId corresponding to the Line Id */
						  	  		IFX_VMAPI_Update_CpeId_opt("VoiceLine_CpeId", 
																				pxVoiceLine->ucLineId,pxVoiceLine->iid.cpeId.Id);	
								break;
					}
				}
        if (IFX_DELETE_F_SET(uiInFlag)) {
           switch(uiObjectId){	
			          default:
       				       IFX_VMAPI_Update_CpeId_opt(acCpeidSec, ucLine,0);
         				break;
				
			          case IFX_VMAPI_OBJ_LINEEVENTS:
												if((pxLineEvents->iid.config_owner == IFX_WEB)||(pxLineEvents->iid.config_owner == IFX_VOIP))
		      							{
																		IFX_VMAPI_Update_CpeId_opt("LineSubEvent_CpeId", 
                    		                  (((pxLineEvents->ucLineId-1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxLineEvents->ucIndex),0);
												}else  {	
			  								          if(IFX_VMAPI_ReplaceCpeId("LineSubEvent" , 
																						pxLineEvents->iid.cpeId.Id) !=IFX_VMAPI_SUCCESS)
																	{
																					printf("[%s %d] Failed to Replace\n",__FUNCTION__, __LINE__);
																	}				
																	else
																	{
																				printf("REPLACING SUCCESSFUL\n");
																	}
				  							}
        				break;

								case IFX_VMAPI_OBJ_AUTHCFG:
											IFX_VMAPI_Update_CpeId_opt("AuthCfg_CpeId", 
                                (((pxAuthCfg->ucLineId-1)*IFX_VMAPI_MAX_AUTH_INFO)+pxAuthCfg->ucIndex),
                                0);
								break;
								
								case  IFX_VMAPI_OBJ_CODEC_DESC:
											if((pxCodecDesc->iid.config_owner == IFX_WEB)||(pxCodecDesc->iid.config_owner == IFX_VOIP))
								      {
								            IFX_VMAPI_Update_CpeId_opt("List_CpeId",(((pxCodecDesc->ucLineId-1)*IFX_VMAPI_MAX_CODECS)+pxCodecDesc->ucIndex),0);
								      }
								      else
								      {
													if(IFX_VMAPI_ReplaceCpeId("List" , 
																	pxCodecDesc->iid.cpeId.Id) !=IFX_VMAPI_SUCCESS)
													{
																		//printf("[%s %d] Failed to Replace\n",__FUNCTION__, __LINE__);
													}
													else
													{
																	printf("REPLACING SUCCESSFUL\n");
													}
	        						}
								break;
								
								case IFX_VMAPI_OBJ_VOICE_LINE:
												IFX_VMAPI_Delete_LineId(pxVoiceLine->ucLineId);
    										IFX_VMAPI_Update_CpeId_opt("VoiceLine_CpeId", pxVoiceLine->ucLineId,0);
								break;
					 }

        }

        /*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
    		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
									       IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			  			 " Cannot write to the flash\n");
   	    }
#endif
/**********************************************************************************************
                SECTION : 9 -> NOTIFICATION
**********************************************************************************************/
				if ( !(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) && (IFX_MODIFY_F_SET(uiInFlag) || bVLineNotification)) { 
						  /*** NOTIFICATION BLOCK ***/
#ifndef LIST_ACCESS
					  if(IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS)
					  {
								  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			                "Sending The Notification\n");
								  if(uiObjectType == IFX_VMAPI_VOICE_LINE ){
													printf(">>>>>>>>>>>>>>>> VoiceLine modified and Sending notification....  \n");
													if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
																		              (uiObjectType,xOldObj,(void *)pxLineTemp))
													{
									    				      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																						"Error : IFX_VMAPI_SendNotifyForRegObject failed for Calling Features!!! \n");
													          ret = IFX_VMAPI_FAIL;
																		goto EndLabel;
													}
									}else {
												if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
																              (uiObjectType,xOldObj,pvVLObject)){
												
																	  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
														            		  "Error : IFX_VMAPI_SendNotifyForRegObject failed for Calling Features!!! \n");
													          ret = IFX_VMAPI_FAIL;
																		goto EndLabel;
											}
							}
    		}
		}
#endif

	if (IFX_MODIFY_F_SET(uiInFlag)) { 
       if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
				          									pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		             "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
        }
	if(bGloging){
	      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(iid,uiChangedNvCount,
					       									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
/*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
					        								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }
	      }

        if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
	        if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
					       								pxList,uiInFlag)!= IFX_SUCCESS) {
  	         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		            "Info : Notification is Failing\n");
		        goto EndLabel;	
	        }

          /*** EPILOG BLOCK ****/
		      if (IFX_VMAPI_UpdateMapNAttr(iid,uiChangedNvCount,
					     									pxList,uiInFlag)!=  IFX_SUCCESS) {
  		       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		 		        "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
		        goto EndLabel;	
		      }
        } 
		}
		if(uiObjectId == IFX_VMAPI_OBJ_VOICE_LINE ) {
		/* Once the Line is added by ACS, LineIdList of the VoiceProfile
				 object has to be updated also. */ 
				if(pxVoiceLine->iid.config_owner == IFX_TR69)  {
					memset(&xVoiceLine,0,sizeof(x_IFX_VMAPI_VoiceLine));
					xVoiceLine.iid.pcpeId.Id = pxVoiceLine->iid.pcpeId.Id;
					xVoiceLine.iid.cpeId.Id = pxVoiceLine->iid.cpeId.Id;
					xVoiceLine.iid.config_owner=IFX_TR69;
					if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT))
					{
						IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
									"Error : Could Not Get VoiceLine\n");
						goto EndLabel;
					}
					if(IFX_VMAPI_SUCCESS != IFX_VMAPI_AssociateLineIdwithProfileId(
																	xVoiceLine.ucProfileId,xVoiceLine.ucLineId))
					{
						IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
									"Error : Association of Line with VoiceProfile Failed.\n");
					}
				}
		}
	}
/**********************************************************************************************
                SECTION : 10 -> CLEAN UP
**********************************************************************************************/
EndLabel:
  /* Free all memory allocated in this function.... */
	if(pxChangedNvList != NULL)
	{
  	IFX_VMAPI_FREE(pxChangedNvList);
	}
	if(pxLineTemp != NULL)	{
  	IFX_VMAPI_FREE(pxLineTemp);
	}

	IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			 "Leaving Function\n");
  return ret;
}



/******************************************************************************
*  Function Name  : LTQ_set_VoipSystemObject
*  Description    : Set api to set various Voice Line Related objects
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxVoiceLineObject - Pointer to the object to be set
*  Output Values  : pxDectObject - pointer to dect related object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_VoipSystemObject(IN uint32  uiOperation,
                      IN_OUT  void *pvSysObject,
                      IN uint32 uiObjectType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag)
{
  IFX_ID *iid = NULL,piid;
  int32 iInstanceIndex = -1 ;
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  IFX_NAME_VALUE_PAIR *pxList=NULL;
  uint32  uiChangedNvCount=0; /* number of changed NVPs */
  uint32 iCpeId;
  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8 acCpeidSec[50],acIIDBuf[25]="\0";
  uchar8 ucLine=0;
  void * xOldObj = NULL;
  int32 ret = IFX_VMAPI_FAIL; /* return value */
  char8 bGloging = 1/*, bVLineNotification = 0*/;
	printf("#########LTQ_set_VoiceSystemObject : with object id %d & type : %d \n",uiObjectId,uiObjectType);

	//System debug setting object
	x_IFX_VMAPI_SystemDebugSettings *pxDbgSet = NULL;
	x_IFX_VMAPI_SystemDebugSettings xOldDbg;

	//Numplan related
	x_IFX_VMAPI_NumPlan *pxNumPlan = NULL;
	x_IFX_VMAPI_NumPlan xOldNumPlan ={{{{0}}}};

	//System T38 object
	x_IFX_VMAPI_T38Cfg *pxSystemT38 = NULL;

	//System Misc Related
	x_IFX_VMAPI_Misc *pxMisc = NULL;
	x_IFX_VMAPI_Misc xOldMisc;

	//Numplan Rule related
	x_IFX_VMAPI_NumPlanRule *pxNumRule = NULL;

	//Call block related
	x_IFX_VMAPI_CallBlock *pxCallBlk = NULL;

	//Call block entry related
	x_IFX_VMAPI_CallBlockEntry *pxCallBlkEntry = NULL;

	 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entering Function\n");
/**********************************************************************************************
        SECTION : 1 -> OPERATION AND FLAG VERIFICATION 
**********************************************************************************************/
/***  PROLOG BLOCK   ***/
  if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
  }


  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

/**********************************************************************************************
        SECTION : 2 -> POINTER CONVERTION, CPEID,ENTRY ID , PARENT CPEID IDENTIFICATION 
**********************************************************************************************/
/* Get parent object, section information */
  switch(uiObjectId){
				case IFX_VMAPI_OBJ_DBG_SET:
						  pxDbgSet = (x_IFX_VMAPI_SystemDebugSettings *)pvSysObject;
              iid=&(pxDbgSet->iid);
							bGloging = 0;
				break;
	
				case IFX_VMAPI_OBJ_NUMPLAN:
							pxNumPlan = (x_IFX_VMAPI_NumPlan *)pvSysObject;
							iid=&(pxNumPlan->iid);
				break;
			
				case IFX_VMAPI_OBJ_T38:
							 pxSystemT38 = (x_IFX_VMAPI_T38Cfg *)pvSysObject;
						   iid=&(pxSystemT38->iid);
							 sprintf(acIIDBuf, "%s", "NsxSize");
							 bGloging = 0;
			 break;
		
				case IFX_VMAPI_OBJ_MISC:
								pxMisc = (x_IFX_VMAPI_Misc *)pvSysObject;
								iid=&(pxMisc->iid);
								//sprintf(acCpeidSec, "%s", "VoiceLineSession_CpeId");
								sprintf(acIIDBuf, "%s", "NsxSize");
								bGloging = 0;
				break;

				case IFX_VMAPI_OBJ_NUMPLAN_RULE:
							/* Special case: Send Notification to the parent object NumPlan if something gets
					   modified in NumPlanRule. This will send the notification once only irrespective
					   of how many NumPlanRule got changed. */
							if((uiInFlag & IFX_VMAPI_SEND_NOTIFY_FORCEFULLY_TO_THIS_OBJ)){
							      if (IFX_MODIFY_F_SET(uiInFlag)) { 
								          if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_VS_NUM_PLAN) == IFX_VMAPI_SUCCESS)
									        {
									            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
												                "Sending The Notification\n");
									            IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_VS_NUM_PLAN,
																															(void *)&xOldNumPlan,(void *)&xOldNumPlan);
													}
										}
									return IFX_VMAPI_SUCCESS;
							}/* Notify flag IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ */
								pxNumRule = (x_IFX_VMAPI_NumPlanRule *)pvSysObject;
								iid=&(pxNumRule->iid);
								sprintf(acCpeidSec, "%s", "NumPlanRules_CpeId");
								sprintf(acIIDBuf, "%s", "Pos2Rem");
								uiObjectType = IFX_VMAPI_VS_NUM_PLAN;
				break;

				case IFX_VMAPI_OBJ_CALLBK:
						    pxCallBlk = (x_IFX_VMAPI_CallBlock *)pvSysObject;
				        iid=&(pxCallBlk->iid);
								bGloging = 0;
				break;

				case IFX_VMAPI_OBJ_CALLBK_ENTRY:
							  pxCallBlkEntry = (x_IFX_VMAPI_CallBlockEntry *)pvSysObject;
				        iid=&(pxCallBlkEntry->iid);
					      sprintf(acCpeidSec, "%s", "CallBlockEntry_CpeId");
								bGloging = 0;
							  //sprintf(acIIDBuf, "%s", "");
				break;
		}


/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
     CpeId is already passed to it. */
	if(iid->config_owner == IFX_TR69)  {
				IFX_VMAPI_GetLineIdFromCpeId(iid->pcpeId.Id, &ucLine);
			  switch(uiObjectId){
				}

	}else if((iid -> config_owner == IFX_WEB)||(iid -> config_owner == IFX_VOIP))  {
			  switch(uiObjectId) {
							case IFX_VMAPI_OBJ_NUMPLAN_RULE:
										pxNumRule->iid.pcpeId.Id = 1;
										if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
													IFX_VMAPI_Get_CpeId_opt("NumPlanRules_CpeId",pxNumRule->ucIndex,&iCpeId);
										    	pxNumRule->iid.cpeId.Id = iCpeId;
										}
							break;

							case IFX_VMAPI_OBJ_CALLBK_ENTRY:
											pxCallBlkEntry->iid.pcpeId.Id = 1;
											if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
						     						IFX_VMAPI_Get_CpeId_opt("CallBlockEntry_CpeId",pxCallBlkEntry->ucIndex,&iCpeId);
												     pxCallBlkEntry->iid.cpeId.Id = iCpeId;
						  				}
							break;
			}
	}

/* getting the section name of object */
		IFX_VMAPI_STRCPY(iid->cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

/**********************************************************************************************
        SECTION : 3 -> INSTANCE INDEX FINDING (MODIFY/DELETE) / CPEID GENERATION (ADD)
**********************************************************************************************/
/* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid->cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }
  }
   /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
				switch(uiObjectId) {
							 default:
												if (ifx_get_IID(iid, acIIDBuf) != IFX_SUCCESS) {
															IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
															"Failed to get the iid !!\n\n");
															IFX_VMAPI_UNLOCK(uiLock);
															return IFX_VMAPI_FAIL;
												}
								break;
						
								case IFX_VMAPI_OBJ_CALLBK_ENTRY:
											memset(&piid,0,sizeof(piid));
											piid.cpeId.Id = iid->pcpeId.Id;
											sprintf(piid.cpeId.secName, "%s", iid->pcpeId.secName);
											if (ifx_get_iid(iid->cpeId.secName, piid.cpeId.secName, &piid, iid) != IFX_SUCCESS) {
													IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																			"Failed to get the iid !!\n\n");
													IFX_VMAPI_UNLOCK(uiLock);
													return IFX_VMAPI_FAIL;
											}				
								break;
				}
			/* increment the next cpe id for this object */
					ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
											IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

	}

/**********************************************************************************************
                SECTION : 4 -> MODIFY PARENT IF ANY, GENERATE NAME VALUE TABLE 
**********************************************************************************************/
/* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));

  IFX_VMAPI_LOCK(uiLock);

/* modification handling of child objects */

	if(IFX_MODIFY_F_SET(uiInFlag) ) {
				switch(uiObjectId) {
							case IFX_VMAPI_OBJ_NUMPLAN: 
							{
										x_IFX_VMAPI_NumPlanRule *pxTemp = NULL;
										pxTemp = pxNumPlan->pxNumPlanRules;
					    			pxNumPlan->ucNoOfNumPlanRules = 0;
										while(pxTemp !=NULL)
								    {
										      pxTemp->ucIndex =pxNumPlan->ucNoOfNumPlanRules+1;
										      pxTemp->iid.config_owner = pxNumPlan->iid.config_owner;
										      ifx_set_NumPlanRule(IFX_OP_MOD,pxTemp,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
													pxNumPlan->ucNoOfNumPlanRules++;
										      __ifx_list_GetNext((void *)&pxTemp);
										}
							}
							break;
			}

	}

	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvSysObject,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Could Not Get NV List \n");
                printf("FAIL POINT 3 for object : %d\n",uiObjectId);
      goto EndLabel;
  }



	if (ifx_get_conf_index_and_nv_pairs(iid,
												              iInstanceIndex,
											                IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
											                xNVList.unNoOfNVPairs,
											                xNVList.axNameValue,
											                uiInFlag) != IFX_SUCCESS) {

				    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
											"Error : ifx_get_conf_index_and_nv_pairs failed \n");
				    goto EndLabel;
	}	

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);

  /*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag)) {
    switch(uiObjectId) {
		       default:
                  if (IFX_VMAPI_CheckACLRet(iid,
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               &uiChangedNvCount,&pxChangedNvList,
                               uiInFlag) != IFX_SUCCESS) {

                      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                      "Error : Could Not Get Changed Field Names \n");
                      goto EndLabel;
                  }
			    break;

				  case IFX_VMAPI_OBJ_DBG_SET:
					case IFX_VMAPI_OBJ_MISC:
					case IFX_VMAPI_OBJ_T38:
					case IFX_VMAPI_OBJ_CALLBK:
					case IFX_VMAPI_OBJ_CALLBK_ENTRY:
						    if(ifx_cmp_and_return_changed_fvp(&iid->cpeId.secName[0],
                               xNVList.unNoOfNVPairs,xNVList.axNameValue,
                               (int32 *)&uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                       "Error : Could Not Get Changed Field Names \n");
                      goto EndLabel;
								}
					break;
		}

  }

/**********************************************************************************************
                SECTION : 5 -> CHECKING FOR NUMBER OF MODIFIED FIELDS 
**********************************************************************************************/
/*** SYSTEM CONFIG FILE UPDATE BLOCK ***/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
				ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
		    pxList = pxChangedNvList;
  }
  else {
		    uiChangedNvCount = xNVList.unNoOfNVPairs;
				ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
		    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
						"Error : Could Not Form Buffer From NV List\n");
		    goto EndLabel;
  }

  if (!uiChangedNvCount) {
				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
				goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

/**********************************************************************************************
                SECTION : 6 -> CONSTRUCTION OF OLD OBJECT FROM  RC.CONF 
**********************************************************************************************/
	if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
			if (IFX_MODIFY_F_SET(uiInFlag)) {
							/* Check If the Object is Registered or not */
				      if(IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS)
							{
				      	  switch(uiObjectId){
													case IFX_VMAPI_OBJ_DBG_SET:
																memset(&xOldDbg,0,sizeof(x_IFX_VMAPI_SystemDebugSettings));
																xOldDbg.iid.pcpeId.Id = 1;
																xOldDbg.iid.config_owner = IFX_VOIP;
																if(ifx_get_DbgSettings(&xOldDbg,0)!=IFX_VMAPI_SUCCESS)
																{
																			IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
																				 "Error : Get Failed For Debug Set");
																}
																xOldObj = &xOldDbg;
													break;
							
													case IFX_VMAPI_OBJ_NUMPLAN_RULE:
													case IFX_VMAPI_OBJ_NUMPLAN: 
																/*GET the old NumPlan parameter values */
																printf("Getting the numplan rule...\n");
																memset(&xOldNumPlan,0,sizeof(x_IFX_VMAPI_NumPlan));
																xOldNumPlan.iid.pcpeId.Id = 1;
																xOldNumPlan.iid.config_owner = IFX_VOIP;
																if(ifx_get_NumPlan(&xOldNumPlan,0)!=IFX_VMAPI_SUCCESS)
																{
																				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
																			 "Error : Get Failed For Numbering plan");
																}
																//xOldNumPlan.pxNumPlanRules = NULL;
																xOldObj = &xOldNumPlan;
												break;
						
												case IFX_VMAPI_OBJ_MISC: 
																memset(&xOldMisc,0,sizeof(x_IFX_VMAPI_Misc));
																xOldMisc.iid.pcpeId.Id = 1;
																xOldMisc.iid.config_owner = IFX_VOIP;
																if(ifx_get_Misc(&xOldMisc,0)!=IFX_VMAPI_SUCCESS)
																{
																				IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
																			 "Error : Get Failed For Debug Set");
																}
																xOldObj = &xOldMisc;
											break;
									}
					}
			}
	}
/**********************************************************************************************
                SECTION : 7 -> ROLL BACK SUPPORT, WRITING NEW VALUES into RC.CONF 
**********************************************************************************************/
/* Backup rc.conf before proceeding with configuration */
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
				                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
							                uiInFlag,
										           1,
													     (char8*)buf
															)) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Warning : Could Not Roll Back Config File\n");
      }
#endif
      goto EndLabel;
    } else {
/**********************************************************************************************
                SECTION : 8 -> ENTRY ID, CPEID UPDATION 
**********************************************************************************************/
      /* Config file is updated */
/* CPEID UPDATION BLOCK */
        if (IFX_INT_ADD_F_SET(uiInFlag)) {
					  switch(uiObjectId){
							 		 case IFX_VMAPI_OBJ_NUMPLAN_RULE:
													IFX_VMAPI_Update_CpeId_opt("NumPlanRules_CpeId", 
																											pxNumRule->ucIndex,pxNumRule->iid.cpeId.Id);
										break;

										case IFX_VMAPI_OBJ_CALLBK_ENTRY:
														IFX_VMAPI_Update_CpeId_opt("CallBlockEntry_CpeId", pxCallBlkEntry->ucIndex,pxCallBlkEntry->iid.cpeId.Id);
										break;
        		}		
      	}
        if (IFX_DELETE_F_SET(uiInFlag)) {
       			 switch(uiObjectId){
                   case IFX_VMAPI_OBJ_NUMPLAN_RULE:
            	    			if((pxNumRule->iid.config_owner == IFX_WEB)||(pxNumRule->iid.config_owner == IFX_VOIP))
		    								{
						         				/* Update the CpeId corresponding to the Line Id */
			       								IFX_VMAPI_Update_CpeId_opt("NumPlanRules_CpeId", pxNumRule->ucIndex,0);
      		  						}	
									      else
									      {
														//printf("CPEID %d\n", pxCodecDesc->iid.cpeId.Id);
									          IFX_VMAPI_ReplaceCpeId("NumPlanRules" , pxNumRule->iid.cpeId.Id);
	      								}
									break;
													
									case IFX_VMAPI_OBJ_CALLBK_ENTRY:
								  			IFX_VMAPI_Update_CpeId_opt("CallBlockEntry_CpeId", pxCallBlkEntry->ucIndex,0);
									break;		
						}
			}

/*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " Cannot write to the flash\n");
        }
#endif
/**********************************************************************************************
                SECTION : 9 -> NOTIFICATION
**********************************************************************************************/
			if (IFX_MODIFY_F_SET(uiInFlag) && IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS) {
				    /*** NOTIFICATION BLOCK ***/
#ifndef LIST_ACCESS
						switch(uiObjectId ){
								
									default:
												if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
																			                (uiObjectType,xOldObj,pvSysObject))
												{
							                  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
															    "Error : IFX_VMAPI_SendNotifyForRegObject failed for Calling Features!!! \n");
								                  ret = IFX_VMAPI_FAIL;
																  goto EndLabel;
												}
								break;

								case IFX_VMAPI_OBJ_NUMPLAN_RULE:
											if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
												        (uiObjectType,(void *)&xOldNumPlan,(void *)&xOldNumPlan))
					            {
												        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																"Error : IFX_VMAPI_SendNotifyForRegObject failed for Calling Features!!! \n");
								                  ret = IFX_VMAPI_FAIL;
																  goto EndLabel;
											}
				      break;

					}

		}
#endif
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Warning : ifx_CompactCfgSection failed \n");
          }
        }

	if(bGloging){

			if (IFX_MODIFY_F_SET(uiInFlag)) {
					 if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
                                    pxList,uiInFlag)!= IFX_SUCCESS) {
							   IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
									   "Info : Notification is Failing\n");
			            goto EndLabel;
				    }
      }
  
      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
          if (IFX_VMAPI_UpdateMapNAttr(iid,uiChangedNvCount,
                                  pxList,uiInFlag)!=  IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
            goto EndLabel;
      }
/*** NOTIFICATION BLOCK ***/
          if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
                                  pxList,uiInFlag)!= IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : Notification is Failing\n");
            goto EndLabel;
          }
     }

     if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
          if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
                                pxList,uiInFlag)!= IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : Notification is Failing\n");
            goto EndLabel;
          }

          /*** EPILOG BLOCK ****/
          if (IFX_VMAPI_UpdateMapNAttr(iid,uiChangedNvCount,
                                pxList,uiInFlag)!=  IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
            goto EndLabel;
          }
     }
		}

  }
/**********************************************************************************************
                SECTION : 10 -> CLEAN UP
**********************************************************************************************/
EndLabel:
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
	if(xOldNumPlan.pxNumPlanRules != NULL)
		ifx_vmapi_freeObjectList(&xOldNumPlan,IFX_VMAPI_VS_NUM_PLAN);
	
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function\n");
  return ret;
}



/******************************************************************************
*  Function Name  : LTQ_set_VoipProfileObject
*  Description    : Set api to set various Voice profile Related objects
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxVoiceLineObject - Pointer to the object to be set
*  Output Values  : pxDectObject - pointer to dect related object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_set_VoipProfileObject(IN uint32  uiOperation,
																IN_OUT  void *pvProfObject,
																IN uint32 uiObjectType,
																IN uint32 uiObjectId,
																IN uint32  uiInFlag)
{
  IFX_ID *iid = NULL,piid;
  int32 iInstanceIndex = -1 ;
  x_IFX_VMAPI_NameValueList xNVList; /* Name value list*/
  IFX_NAME_VALUE_PAIR *pxChangedNvList = 0; /* changed NVP pairs */
  IFX_NAME_VALUE_PAIR *pxList=NULL;
  uint32  uiChangedNvCount=0; /* number of changed NVPs */
  uint32 iCpeIdProf;
  uint32 uiNvIdx = 0;
  uchar8 buf[5000]; /* buffer used to hold config data */
  char8 acCpeidSec[50],acIIDBuf[25]="\0";
  uchar8 ucProf=0;
  void * xOldObj = NULL;
  int32 ret = IFX_VMAPI_FAIL; /* return value */
  char8 bGloging = 1/*, bVLineNotification = 0*/;
  char8	bVProfNotification = 0 ;
	printf("####################LTQ_set_VoipProfileObject with object id %d & object type %d\n",uiObjectId,uiObjectType);	
//Profile media faxT38 related
	x_IFX_VMAPI_FaxT38 *pxFax = NULL;
	
	//RTP related
	x_IFX_VMAPI_ProfileMediaRTP *pxProfileMediaRTP = NULL;
	x_IFX_VMAPI_ProfileMediaRTP xOldMediaRtp;

	//RTCP related
	x_IFX_VMAPI_ProfileMediaRTCP *pxProfileMediaRTCP = NULL;

	//Event related
	x_IFX_VMAPI_ProfileEventSubsTable *pxProfileEventSubsTable = NULL;
	x_IFX_VMAPI_ProfileEventSubsTable xOldProfEvSubsTbl;

	//Profile signaling related
	x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling = NULL;
	x_IFX_VMAPI_ProfileSignaling xOldProfSig;

	//Profile event subscribe entry
	x_IFX_VMAPI_EventSubscribe *pxEventSub = NULL;
	x_IFX_VMAPI_EventSubscribe xOldEvEntry;

	//Voice profile object
	x_IFX_VMAPI_VoiceProfile *pxVoiceProfile = NULL;
	x_IFX_VMAPI_VoiceProfile xVoiceProf;
	x_IFX_VMAPI_VoiceProfile  *pxTempProf = NULL;
	uchar8 aucLocalAssoLineIds[2*IFX_VMAPI_MAX_VOICE_LINES_PER_PROFILE+1];
	memset(aucLocalAssoLineIds,0,sizeof(aucLocalAssoLineIds));

	//Service proivder related
	x_IFX_VMAPI_ProfileServiceProviderInfo *pxServProviderInfo = NULL;

	//Service provider media security related
	#ifdef IIP
	x_IFX_VMAPI_ProfileMediaSecurity *pxProfileMediaSecurity = NULL;
	#endif

	 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					"Entering Function\n");


/**********************************************************************************************
				SECTION : 1 -> OPERATION AND FLAG VERIFICATION 
**********************************************************************************************/

/***  PROLOG BLOCK   ***/
  if( LTQ_get_ActionInfo(uiOperation,&uiInFlag) != IFX_VMAPI_SUCCESS){
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
       "Error : Operation Is Not Supported\n");
    return IFX_VMAPI_FAIL;
  }

  /*** VALIDATION BLOCK ***/
  /* For operation other than DELETE do the verification of input params */
  if (IFX_DELETE_F_NOT_SET(uiInFlag) && IFX_DONT_VALIDATE_F_NOT_SET(uiInFlag)) {
    IFX_VALIDATE_FLAGS(uiInFlag);
  }

/**********************************************************************************************
				SECTION : 2 -> POINTER CONVERTION, CPEID,ENTRY ID , PARENT CPEID IDENTIFICATION 
**********************************************************************************************/
  switch(uiObjectId){
        case IFX_VMAPI_OBJ_FAX:
							pxFax  = (x_IFX_VMAPI_FaxT38 *)pvProfObject;
							iid=&(pxFax->iid);
							sprintf(acCpeidSec, "%s", "Fax_CpeId");
							sprintf(acIIDBuf, "%s", "NsxSize");
							ucProf = pxFax->ucProfileId;
				break;
        case IFX_VMAPI_OBJ_RTP:
							pxProfileMediaRTP  = (x_IFX_VMAPI_ProfileMediaRTP *)pvProfObject;
							iid=&(pxProfileMediaRTP->iid);
							sprintf(acCpeidSec, "%s", "MediaRTPAttributes_CpeId");
							sprintf(acIIDBuf, "%s", "MinRTPPort");
							ucProf = pxProfileMediaRTP->ucProfileId;
				break;
				case IFX_VMAPI_OBJ_RTCP:
							pxProfileMediaRTCP  = (x_IFX_VMAPI_ProfileMediaRTCP *)pvProfObject;
							iid=&(pxProfileMediaRTCP->iid);
							sprintf(acCpeidSec, "%s", "MediaRTCPAttributes_CpeId");
							sprintf(acIIDBuf, "%s", "RTCPName");
							ucProf = pxProfileMediaRTCP->ucProfileId;
				break;

				case IFX_VMAPI_OBJ_PROFEVENT:
							pxProfileEventSubsTable = (x_IFX_VMAPI_ProfileEventSubsTable *)pvProfObject;
							iid=&(pxProfileEventSubsTable->iid);
							sprintf(acCpeidSec, "%s", "ProfileEvent_CpeId");
							sprintf(acIIDBuf, "%s", "RTCPName");
							ucProf = pxProfileEventSubsTable->ucProfileId;
							bGloging = 0;
				break;
					
				case IFX_VMAPI_OBJ_VP_SIGNALING:
							pxProfileSignaling = (x_IFX_VMAPI_ProfileSignaling *)pvProfObject;
							iid=&(pxProfileSignaling->iid);
							sprintf(acCpeidSec, "%s", "VoiceProfileSignaling_CpeId");
							sprintf(acIIDBuf, "%s", "ProxyAddr");
							ucProf = pxProfileSignaling->ucProfileId;
							bGloging = 0;
				break;

				case IFX_VMAPI_OBJ_PROFEVENT_SUBSCR:
							pxEventSub = (x_IFX_VMAPI_EventSubscribe *)pvProfObject;
							iid=&(pxEventSub->iid);
							sprintf(acCpeidSec, "%s", "EventSubscribe_CpeId");
							sprintf(acIIDBuf, "%s", "Event");
							ucProf = pxEventSub->ucProfileId;
							bGloging = 0;
				break;	

				case IFX_VMAPI_OBJ_VOICE_PROFILE:
							pxVoiceProfile = (x_IFX_VMAPI_VoiceProfile *)pvProfObject;
							iid=&(pxVoiceProfile->iid);
							sprintf(acCpeidSec, "%s", "VoiceProfile_CpeId");
							sprintf(acIIDBuf, "%s", "Cuntry");
							ucProf = pxVoiceProfile->ucProfileId;
							//bGloging = 0;
				break;
				case IFX_VMAPI_OBJ_SER_PROVIDER:
							pxServProviderInfo = (x_IFX_VMAPI_ProfileServiceProviderInfo * )pvProfObject;
							iid=&(pxServProviderInfo->iid);
							sprintf(acCpeidSec, "%s", "ServiceProvider_CpeId");
							sprintf(acIIDBuf, "%s", "Phone");
							ucProf = pxServProviderInfo->ucProfileId;
				break;
#ifdef IIP
				case IFX_VMAPI_OBJ_VP_MEDIA_SEC:
							pxProfileMediaSecurity = ( * )pvProfObject;
					    iid=&(pxProfileMediaSecurity->iid);
							sprintf(acCpeidSec, "%s", "ServiceProvider_CpeId");
							sprintf(acIIDBuf, "%s", "Phone");
			        ucProf = pxProfileMediaSecurity->ucProfileId;
					    bGloging = 0;
				break;
#endif
				default:
		            return IFX_VMAPI_FAIL;
	}


/* If the owner is WEB then GET the CpeId from rc.conf. If the owner is TR69 then the 
     CpeId is already passed to it. */
	if(iid->config_owner == IFX_TR69)  {
			IFX_VMAPI_GetProfileIdFromCpeId(iid->pcpeId.Id, &ucProf);
			switch(uiObjectId){
						case IFX_VMAPI_OBJ_FAX:
									pxFax->ucProfileId = ucProf;
						break;
	
						case IFX_VMAPI_OBJ_RTP:
									pxProfileMediaRTP->ucProfileId = ucProf;
						break;	

						case IFX_VMAPI_OBJ_RTCP:
									pxProfileMediaRTCP->ucProfileId = ucProf;
						break;	
	 
						case IFX_VMAPI_OBJ_PROFEVENT:
								 pxProfileEventSubsTable->ucProfileId	= ucProf;	
						break;
	
						case IFX_VMAPI_OBJ_VP_SIGNALING:
									 pxProfileSignaling->ucProfileId = ucProf;
						break;
	
						case IFX_VMAPI_OBJ_PROFEVENT_SUBSCR:	
									pxEventSub->ucProfileId = ucProf;
						break;
		
						case IFX_VMAPI_OBJ_VOICE_PROFILE:
									pxVoiceProfile->ucProfileId = ucProf;
				    break;
						case IFX_VMAPI_OBJ_SER_PROVIDER:
							   pxServProviderInfo->ucProfileId = ucProf;
						break;
			}
	}else if((iid -> config_owner == IFX_WEB)||(iid -> config_owner == IFX_VOIP))  {
	    switch(uiObjectId) {
						case IFX_VMAPI_OBJ_FAX:
						case IFX_VMAPI_OBJ_RTP:
						case IFX_VMAPI_OBJ_RTCP:
						case IFX_VMAPI_OBJ_PROFEVENT:
										IFX_VMAPI_Get_CpeId_opt("VoiceProfile_CpeId",ucProf,&iCpeIdProf);
									  iid->pcpeId.Id = iCpeIdProf;
									if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
									{			
											IFX_VMAPI_Get_CpeId_opt(acCpeidSec,ucProf,&iCpeIdProf);
								     iid->cpeId.Id = iCpeIdProf;
									}
						break;
			
						case IFX_VMAPI_OBJ_PROFEVENT_SUBSCR:
									IFX_VMAPI_Get_CpeId_opt("ProfileEvent_CpeId",pxEventSub->ucProfileId,&iCpeIdProf);
									pxEventSub->iid.pcpeId.Id = iCpeIdProf;
								  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) 
									{
										  //IFX_VMAPI_Get_CpeId(IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY,pxEventSub,&iCpeId);
							      IFX_VMAPI_Get_CpeId_opt("EventSubscribe_CpeId",(((pxEventSub->ucProfileId - 1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxEventSub->ucIndex),&iCpeIdProf);	
							      pxEventSub->iid.cpeId.Id = iCpeIdProf;
									}
						break;	
			}
	}

	/* getting the section name of object */
	IFX_VMAPI_STRCPY(iid->cpeId.secName,
                  IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

/**********************************************************************************************
				SECTION : 3 -> INSTANCE INDEX FINDING (MODIFY/DELETE) / CPEID GENERATION (ADD)
**********************************************************************************************/
/* Get Config Index in case of modify/delete operations */
  if(IFX_MODIFY_F_SET(uiInFlag) || IFX_DELETE_F_SET(uiInFlag) ) {
    if (ifx_get_index_from_cpe_id(SYSTEM_CONF_FILE,
         &iid->cpeId, &iInstanceIndex) != IFX_SUCCESS) {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Could Not Get Index From cpeid \n");
       IFX_VMAPI_UNLOCK(uiLock);
       return ret;
    }
  }
   /*** ID ALLOCATION BLOCK  ***/
  if  (IFX_INT_ADD_F_SET(uiInFlag))  {
			 switch(uiObjectId) {
			
				default:
					    if (ifx_get_IID(iid, acIIDBuf) != IFX_SUCCESS) {
						      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
								    "Failed to get the iid !!\n\n");
										IFX_VMAPI_UNLOCK(uiLock);
		                return IFX_VMAPI_FAIL;
				      }
		    break;
				
				case IFX_VMAPI_OBJ_PROFEVENT:
				      memset(&piid,0,sizeof(piid));
				      piid.cpeId.Id = iid->pcpeId.Id;
				      sprintf(piid.cpeId.secName, "%s", iid->pcpeId.secName);
					    if (ifx_get_iid(iid->cpeId.secName, piid.cpeId.secName, &piid, iid) != IFX_SUCCESS) {
						      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
									          "Failed to get the iid !!\n\n");
							    IFX_VMAPI_UNLOCK(uiLock);
						      return IFX_VMAPI_FAIL;
							}
		    break;
 }
	/* increment the next cpe id for this object */
    ifx_increment_next_cpeId(SYSTEM_CONF_FILE,
                IFX_VMAPI_GET_OBJ_NAME(uiObjectId));

			switch(uiObjectId) {
							case IFX_VMAPI_OBJ_RTP:
										IFX_VMAPI_Default_ProfileMediaRtp(pxProfileMediaRTP);
							break;
			
							case IFX_VMAPI_OBJ_VP_SIGNALING:
										IFX_VMAPI_Default_ProfileSignaling(pxProfileSignaling); 
							break;

							case IFX_VMAPI_OBJ_VOICE_PROFILE:
										pxVoiceProfile->ucProfileId =  iid->cpeId.Id ;
								    IFX_VMAPI_Default_VoiceProfile(pxVoiceProfile);
							break;
		}
	}

/**********************************************************************************************
								SECTION : 4 -> MODIFY PARENT IF ANY, GENERATE NAME VALUE TABLE 
**********************************************************************************************/

/* This section w.r.t VoiceProfile, since we need to perform various other actions depending on add,del and mod */
		switch(uiObjectId){

						case IFX_VMAPI_OBJ_VOICE_PROFILE: {
									if (uiOperation == IFX_OP_MOD) {
										    pxTempProf = (x_IFX_VMAPI_VoiceProfile *)malloc(sizeof(x_IFX_VMAPI_VoiceProfile));
												if(pxTempProf == NULL){
														    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																	"Failed to allocate memory !!\n\n");
																	return IFX_VMAPI_FAIL;
												}
												else {
																		  	memcpy(pxTempProf,pxVoiceProfile,sizeof(x_IFX_VMAPI_VoiceProfile));
												}
									}						
	
								  if (uiOperation == IFX_OP_MOD) {
														int32 i=0,j=0;
												    char8 XArray[2*IFX_VMAPI_MAX_VOICE_LINES_PER_PROFILE+4]={'\0'};
														memcpy(aucLocalAssoLineIds, pxVoiceProfile->aucAssoLineIds, sizeof(pxVoiceProfile->aucAssoLineIds));
												    while(pxVoiceProfile->aucAssoLineIds[i] != 0)
												    {
																sprintf(&XArray[j],"%d",pxVoiceProfile->aucAssoLineIds[i]);
																strcat(XArray,",");
																j = strlen(XArray);
																i++;
														}
											    strncpy((char8 *)pxVoiceProfile->aucAssoLineIds,XArray,
													sizeof(pxVoiceProfile->aucAssoLineIds));
  							}
						break;
				}
		}


/* Get name value pair from the structure */
  memset(&xNVList,0,sizeof(x_IFX_VMAPI_NameValueList));

  IFX_VMAPI_LOCK(uiLock);

	if(IFX_MODIFY_F_SET(uiInFlag) ) {
				switch(uiObjectId){ 
								case IFX_VMAPI_OBJ_PROFEVENT: {   
										 /* Set should happen for EventSubscribe list */
											x_IFX_VMAPI_EventSubscribe *pxTemp;
											pxTemp = pxProfileEventSubsTable->pxEventSubscribe;
										pxProfileEventSubsTable->ucNoOfSubscrElements = 0;
										while(pxTemp !=NULL)
										{
											//printf("cPeId=%d pcpeId=%d\n",pxTemp->iid.cpeId.Id,pxTemp->iid.pcpeId.Id);
											//pxTemp->iid.cpeId.Id =pxProfileEventSubsTable->ucNoOfSubscrElements+1;
											pxTemp->iid.config_owner = pxProfileEventSubsTable->iid.config_owner;
											ifx_set_EventSubscribe(IFX_OP_MOD,pxTemp,0);
											pxProfileEventSubsTable->ucNoOfSubscrElements++;
											__ifx_list_GetNext((void *)&pxTemp);
										}
								}
							break;
			}
	}

	if (IFX_VMAPI_GetNameValueListFromObj(uiObjectId,
                                         pvProfObject,
                                         NULL,
                                         &xNVList,
                                         &uiNvIdx,
                                         NULL ) == IFX_VMAPI_FAIL ) {
    /* This failure may never occur...but still have a check!! */
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Could Not Get NV List \n");
      goto EndLabel;
  }


	if (ifx_get_conf_index_and_nv_pairs(iid,
																			iInstanceIndex,
																			IFX_VMAPI_GET_OBJ_PREFIX(uiObjectId),/*prefix*/
																			xNVList.unNoOfNVPairs,
																			xNVList.axNameValue,
																			uiInFlag) != IFX_SUCCESS) {

    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : ifx_get_conf_index_and_nv_pairs failed \n");
    goto EndLabel;
	}

  IFX_VMAPI_PRINT_NAMEVAL(xNVList.axNameValue, xNVList.unNoOfNVPairs);
/*** ACL CHECKING BLOCK ***/
  if (IFX_INT_ADD_F_NOT_SET(uiInFlag)) {
			  switch(uiObjectId) {
						  default:
									      if (IFX_VMAPI_CheckACLRet(iid,
											             xNVList.unNoOfNVPairs,xNVList.axNameValue,
													         &uiChangedNvCount,&pxChangedNvList,
															     uiInFlag) != IFX_SUCCESS) {

				                      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
								              "Error : Could Not Get Changed Field Names \n");
												      goto EndLabel;
												}		
			        break;

						  case IFX_VMAPI_OBJ_CALLBK_ENTRY:
										  if(ifx_cmp_and_return_changed_fvp(&iid->cpeId.secName[0],
													           xNVList.unNoOfNVPairs,xNVList.axNameValue,
																     (int32 *)&uiChangedNvCount,&pxChangedNvList) != IFX_SUCCESS) {
								                        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																		       "Error : Could Not Get Changed Field Names \n");
									                      goto EndLabel;
											}
			        break;
  		}	

  }

/**********************************************************************************************
								SECTION : 5 -> CHECKING FOR NUMBER OF MODIFIED FIELDS 
**********************************************************************************************/

  if (IFX_MODIFY_F_SET(uiInFlag)) {
				 ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf,uiChangedNvCount, pxChangedNvList);
			    pxList = pxChangedNvList;
  }

 else {
    uiChangedNvCount = xNVList.unNoOfNVPairs;
    ret = IFX_VMAPI_FORM_CFG_BUF((char8*)buf, xNVList.unNoOfNVPairs, &xNVList.axNameValue[0]);
    pxList = &xNVList.axNameValue[0];
  }

  if (ret != IFX_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Could Not Form Buffer From NV List\n");
    goto EndLabel;
  }

  if (!uiChangedNvCount) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Info : There Are No Changed Fields Or No Fields To Be Added.\n");
    goto EndLabel;
  }

  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,buf);

/**********************************************************************************************
								SECTION : 6 -> CONSTRUCTION OF OLD OBJECT FROM  RC.CONF 
**********************************************************************************************/
	if(!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){

		if(uiObjectId == IFX_VMAPI_OBJ_VOICE_PROFILE ){
						if(uiOperation == IFX_OP_ADD && IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_ADD_PROFILE) == IFX_VMAPI_SUCCESS){
				          bVProfNotification = 1;
				    }else if(uiOperation == IFX_OP_MOD && IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_VOICE_PROFILE) == IFX_VMAPI_SUCCESS){
								  bVProfNotification = 1;
			      }else if(uiOperation == IFX_OP_DEL && IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_DELETE_PROFILE) == IFX_VMAPI_SUCCESS){
							    bVProfNotification = 1;
			      }
		}
      /* Check If the Object is Registered or not */
      if(IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS || bVProfNotification)
      {
          switch(uiObjectId){
									case  IFX_VMAPI_OBJ_RTP:
												/*GET the old Misc parameter values */
												memset(&xOldMediaRtp,0,sizeof(x_IFX_VMAPI_ProfileMediaRTP));
												xOldMediaRtp.ucProfileId = pxProfileMediaRTP->ucProfileId;
												xOldMediaRtp.iid.pcpeId.Id = pxProfileMediaRTP->iid.pcpeId.Id;
												xOldMediaRtp.iid.config_owner = IFX_VOIP;
												if(ifx_get_ProfileMediaRTP(&xOldMediaRtp,0)!=IFX_VMAPI_SUCCESS)
												{
															IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															 "Error : Get Failed For Media RTP");
												}	
												xOldObj = &xOldMediaRtp;
								break;
		
								case IFX_VMAPI_OBJ_PROFEVENT:    
												/*GET the old Event Subscribe Table parameter values */
												memset(&xOldProfEvSubsTbl,0,sizeof(x_IFX_VMAPI_ProfileEventSubsTable));
										    xOldProfEvSubsTbl.ucProfileId = pxProfileEventSubsTable->ucProfileId;
										    xOldProfEvSubsTbl.iid.pcpeId.Id = pxProfileEventSubsTable->iid.pcpeId.Id;
									      xOldProfEvSubsTbl.iid.config_owner = IFX_VOIP;
									      if(ifx_get_ProfileEventSubsTable(&xOldProfEvSubsTbl,0)!=IFX_VMAPI_SUCCESS)
									      {
												        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
																	"Error : Get Failed For Debug Set");
												}		
												xOldObj = &xOldProfEvSubsTbl;
								break;
								case IFX_VMAPI_OBJ_VP_SIGNALING:
												memset(&xOldProfSig,0,sizeof(x_IFX_VMAPI_ProfileSignaling));
									      xOldProfSig.ucProfileId = pxProfileSignaling->ucProfileId;
									      xOldProfSig.iid.pcpeId.Id = pxProfileSignaling->iid.pcpeId.Id;
								        xOldProfSig.iid.config_owner = IFX_VOIP;
								        if(ifx_get_ProfileSignaling(&xOldProfSig,0)!=IFX_VMAPI_SUCCESS)
									      {
											        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
																"Error : Get Failed For Profile Signaling");
												}
												xOldObj = &xOldProfSig;
								break;
								case IFX_VMAPI_OBJ_PROFEVENT_SUBSCR:
												memset(&xOldEvEntry,0,sizeof(x_IFX_VMAPI_EventSubscribe));
						    				xOldEvEntry.ucProfileId = pxEventSub->ucProfileId;
										    xOldEvEntry.ucIndex = pxEventSub->ucIndex;
										    xOldEvEntry.iid.pcpeId.Id = pxEventSub->iid.pcpeId.Id;
									      xOldEvEntry.iid.config_owner = IFX_VOIP;
										    if(ifx_get_EventSubscribe(&xOldEvEntry,0)!=IFX_VMAPI_SUCCESS)
											  {
												        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													       "Error : Get Failed For Debug Set");
												}	
												xOldObj = &xOldEvEntry;
								break;

								case IFX_VMAPI_OBJ_VOICE_PROFILE: {
									         switch(uiOperation){
												          case IFX_OP_ADD:
																				memset(&xVoiceProf,0,sizeof(x_IFX_VMAPI_VoiceProfile));
																				uiObjectType = IFX_VMAPI_ADD_PROFILE;
																	break;
													
																	case IFX_OP_DEL:
							                    case IFX_OP_MOD:
																				memset(&xVoiceProf,0,sizeof(x_IFX_VMAPI_VoiceProfile));
																				xVoiceProf.ucProfileId = pxVoiceProfile->ucProfileId;
																        xVoiceProf.iid.pcpeId.Id = 1;
																			  xVoiceProf.iid.config_owner = IFX_VOIP;
																				if(ifx_get_VoiceProfile(&xVoiceProf,0)==IFX_VMAPI_FAIL)
																				{
																						  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																								"Error : GET Failed for VoiceProfile \n");
																				}
																				if(IFX_OP_DEL == uiOperation)
																							uiObjectType = IFX_VMAPI_DELETE_PROFILE;
																break;
													}
													xOldObj = &xVoiceProf;
												}
						}
		}
 }

/**********************************************************************************************
								SECTION : 7 -> ROLL BACK SUPPORT, WRITING NEW VALUES into RC.CONF 
**********************************************************************************************/
/*** SYSTEM CONFIG FILE UPDATE BLOCK ***/
/* Backup rc.conf before proceeding with configuration */
#ifdef ROLLBACK_SUPPORT 
  /* Is deleting tmp file is required ???? */
  snprintf(acSysCmdBuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
  IFX_VMAPI_SYSTEM_CMD(acSysCmdBuf);
#endif
    if ((ret = ifx_SetObjData(SYSTEM_CONF_FILE,
			                        IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
						                   uiInFlag,
									             1,
												       (char8*)buf
																)) != IFX_SUCCESS) {

      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        "Error : Error While Writting To config file\n");
#ifdef ROLLBACK_SUPPORT 
      if (IFX_VMAPI_RollbackCfg(SYSTEM_CONF_FILE, CHKPOINT_FILE, uiInFlag) ) {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Warning : Could Not Roll Back Config File\n");
      }
#endif
      goto EndLabel;
    } else {

/**********************************************************************************************
								SECTION : 8 -> ENTRY ID, CPEID UPDATION 
**********************************************************************************************/
      /* Config file is updated */
/* CPEID UPDATION BLOCK */
        if (IFX_INT_ADD_F_SET(uiInFlag)) {
		            switch(uiObjectId){
				               default:      
																IFX_VMAPI_Update_CpeId_opt(acCpeidSec,ucProf,iid->cpeId.Id);
												break;
												case IFX_VMAPI_OBJ_PROFEVENT_SUBSCR:
																IFX_VMAPI_Update_CpeId_opt("EventSubscribe_CpeId", 
                                      (((pxEventSub->ucProfileId-1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxEventSub->ucIndex),
                                      pxEventSub->iid.cpeId.Id);
												break;

												case IFX_VMAPI_OBJ_VOICE_PROFILE:
																/* Append the new Profile Id in VoiceService ProfileIdList */
																IFX_VMAPI_Update_NewProfileId(IFX_VMAPI_Get_NewProfileId());
														    /* Assign the Latest Profile Id to the new VoiceProfile.This is required to Update the CpeId list */
														    pxVoiceProfile->ucProfileId = IFX_VMAPI_Get_LatestProfileId();
														    /* Update the CpeId corresponding to the Profile Id */
														    //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VOICE_PROFILE, pxVoiceProfile,pxVoiceProfile->iid.cpeId.Id);
																IFX_VMAPI_Update_CpeId_opt("VoiceProfile_CpeId", pxVoiceProfile->ucProfileId,pxVoiceProfile->iid.cpeId.Id);
												break;
							}
        }
        if (IFX_DELETE_F_SET(uiInFlag)) {
                switch(uiObjectId){
								        default:  
																IFX_VMAPI_Update_CpeId_opt(acCpeidSec,ucProf,0);
												break;
										
												case IFX_VMAPI_OBJ_PROFEVENT_SUBSCR:
														if((pxEventSub->iid.config_owner == IFX_WEB)||(pxEventSub->iid.config_owner == IFX_VOIP))
		      									{
										            /* Update the CpeId corresponding to the Line Id */
            												IFX_VMAPI_Update_CpeId_opt("EventSubscribe_CpeId", 
				                            (((pxEventSub->ucProfileId-1)*IFX_VMAPI_MAX_SUBSCR_ELMNTS)+pxEventSub->ucIndex),0);
        									  }
										        else
										        {
													            IFX_VMAPI_ReplaceCpeId("EventSubscribe" , pxEventSub->iid.cpeId.Id);
										        }
												break;	
												case IFX_VMAPI_OBJ_VOICE_PROFILE:
															IFX_VMAPI_Delete_ProfileId(pxVoiceProfile->ucProfileId);
													    /* Update the CpeId corresponding to the Profile Id */
												  	  //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VOICE_PROFILE, pxVoiceProfile,0);
													    IFX_VMAPI_Update_CpeId_opt("VoiceProfile_CpeId", pxVoiceProfile->ucProfileId,0);
												break;
                }
        }

/*** DEVICE CONFIGURATION BLOCK ***/
        /* Device configuration is not needed for this object */
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_DEVICE_CONFIG,
                         IFX_VMAPI_GET_OBJ_NAME(uiObjectId));
#ifdef VMAPI_WRITE_TO_FLASH
        if(IFX_VMAPI_WriteToFlash() != IFX_SUCCESS){
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " Cannot write to the flash\n");
        }
#endif

/**********************************************************************************************
								SECTION : 9 -> NOTIFICATION
**********************************************************************************************/
	 if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ) && (IFX_MODIFY_F_SET(uiInFlag) || bVProfNotification)) {

			if (IFX_VMAPI_IsObjectRegistered(uiObjectType) == IFX_VMAPI_SUCCESS) {
#ifndef LIST_ACCESS
						switch(uiObjectType ){

								    default:
														if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
																										(uiObjectType,xOldObj,pvProfObject))
								            {
																	  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
									                  "Error : IFX_VMAPI_SendNotifyForRegObject failed for Calling Features!!! \n");
																		ret = IFX_VMAPI_FAIL;
									                  goto EndLabel;
														}
							      break;

									case IFX_VMAPI_VOICE_PROFILE:
														if(IFX_VMAPI_SUCCESS != IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_VOICE_PROFILE,
																																		(void *)&xVoiceProf,(void *)pxTempProf))
														{
													    			IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
																		"Error : IFX_VMAPI_SendNotifyForRegObject for OP MOD failed!!! \n");
																		ret = IFX_VMAPI_FAIL;
															    	goto EndLabel;	
														}
									break;
					}
			}
	if(bGloging){

			if (IFX_MODIFY_F_SET(uiInFlag)) {
					 if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
							                          pxList,uiInFlag)!= IFX_SUCCESS) {
								IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
										 "Info : Notification is Failing\n");
		            goto EndLabel;
			      }
      }

      if(uiOperation == IFX_OP_ADD) {
          /*** EPILOG BLOCK ****/
          if (IFX_VMAPI_UpdateMapNAttr(iid,uiChangedNvCount,
                                  pxList,uiInFlag)!=  IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
            goto EndLabel;
          }
/*** NOTIFICATION BLOCK ***/
          if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
                                  pxList,uiInFlag)!= IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : Notification is Failing\n");
            goto EndLabel;
          }
     }

		if(uiOperation == IFX_OP_DEL) {
          /*** NOTIFICATION BLOCK ***/
          if (IFX_VMAPI_CheckNSendNotification(iid,uiChangedNvCount,
                                pxList,uiInFlag)!= IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : Notification is Failing\n");
            goto EndLabel;
          }

          /*** EPILOG BLOCK ****/
          if (IFX_VMAPI_UpdateMapNAttr(iid,uiChangedNvCount,
                                pxList,uiInFlag)!=  IFX_SUCCESS) {
             IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Info : IFX_VMAPI_UpdateMapNAttr is Failing\n");
            goto EndLabel;
          }
    }
  }
	}
#endif
        /* Update rc.conf for Indices Compaction for Add/Del op */
        if (IFX_MODIFY_F_NOT_SET(uiInFlag)) {
           if (ifx_CompactCfgSection(SYSTEM_CONF_FILE,
                                      IFX_VMAPI_GET_OBJ_NAME(uiObjectId),
                                      uiInFlag) != IFX_SUCCESS) {
            /*  Now can not do anything...just continue */
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Warning : ifx_CompactCfgSection failed \n");
          }
        }
}
/**********************************************************************************************
                SECTION : 10 -> CLEAN UP
**********************************************************************************************/
EndLabel:
/*Dont remove this line as its affecting the web functionality*/
	if(aucLocalAssoLineIds[0]!=0)
		memcpy(pxVoiceProfile->aucAssoLineIds, aucLocalAssoLineIds, sizeof(pxVoiceProfile->aucAssoLineIds));	
  /* Free all memory allocated in this function.... */
  if(pxChangedNvList != NULL)
  {
    IFX_VMAPI_FREE(pxChangedNvList);
  }
	/*if(xOldProfEvSubsTbl.pxEventSubscribe != NULL)
		ifx_vmapi_freeObjectList(&xOldProfEvSubsTbl, IFX_VMAPI_VP_EVENT_SUBSCR);*/

	if(pxTempProf != NULL)
	{
  	IFX_VMAPI_FREE(pxTempProf);
	}
  IFX_VMAPI_UNLOCK(uiLock); /* unlok */
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       "Leaving Function\n");
  return ret;
}


/******************************************************************************
*  Function Name  : LTQ_CVoIP_ParamRequest 
*  Description    : This API is used to Send prameter request for CVoIP
*  Input Values   : uiObject - Object need to be requested 
*  Output Values  : -- none -- 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/

#ifdef CVOIP_SUPPORT
// API to send notification for camera application....

int32 LTQ_CVoIP_ParamRequest(uint32 uiObject)
{
  
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entering Function \n");
	if(IFX_VMAPI_SUCCESS !=IFX_VMAPI_SendNotifyForRegObject
                        (uiObject,
                        NULL,NULL))
        {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Error : IFX_VMAPI_SendNotifyForRegObject for OP DEL failed!!! \n");
          return  IFX_VMAPI_FAIL;
        }

	return IFX_VMAPI_SUCCESS;
}

int32
LTQ_Request_XramToModem(IN char8 *ucRamRequest)
{


  if(IFX_VMAPI_IsObjectRegistered(IFX_VMAPI_XRAM_REQUEST) == IFX_VMAPI_SUCCESS) {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Sending The Notification\n");
  IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_XRAM_REQUEST,
                                   NULL,
                                   (void *)ucRamRequest);
  return IFX_VMAPI_SUCCESS;
  } /* IFX_VMAPI_IsObjectRegistered */
  return IFX_VMAPI_FAIL;
}

#endif
