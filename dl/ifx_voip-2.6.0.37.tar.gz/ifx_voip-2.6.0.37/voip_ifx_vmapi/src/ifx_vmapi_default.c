/**************************************************************************
 **   FILE NAME       : ifx_vmapi_cpeid.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Applications requiring cpeId
 **   SRC VERSION     : V0.1
 **   DATE            : 23-04-2007
 **   AUTHOR          : 
 **   DESCRIPTION     : This file defines the mechanism for maintaining
 **											the cpeId for the use of applications reequired
 **											to call the VMAPI IFX_VMAPI* and ifx_set* APIs.
 **   FUNCTIONS       : IFX_VMAPI_Get_CpeId
 **											
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#include <unistd.h>
#include "ifx_vmapi_cpeid.h"

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_VoiceLine
*  Description          :   This Function sets the default VoiceLine parameters
*  Input Values         :   pointer to VoiceLine
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
PUBLIC char8 IFX_VMAPI_Default_VoiceLine(
			IN_OUT  x_IFX_VMAPI_VoiceLine  *pxVoiceLine)
{
  strcpy(pxVoiceLine->acDirName,"NEW");
	sprintf(pxVoiceLine->acName,"Line%d",IFX_VMAPI_Get_NewLineId());
	pxVoiceLine->ucLineMode = 1;/*Multi Call mode*/
	pxVoiceLine->ucIntrusion = 0;
  return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_VoiceService
*  Description          :   This Function sets the default VoiceService parameters
*  Input Values         :   pointer to VoiceService
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
char8 IFX_VMAPI_Default_VoiceService(
		IN_OUT x_IFX_VMAPI_VoiceService *pxVoiceService)
{
  strcpy(&pxVoiceService->acDeviceList[0][0],"/dev/vmmc11,/dev/vmmc12,/dev/vmmc13,/dev/vmmc14,/dev/vmmc10,/dev/dus10" );
  return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_VoiceProfile
*  Description          :   This Function sets the default VoiceProfile parameters
*  Input Values         :   pointer to VoiceProfile
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
char8 IFX_VMAPI_Default_VoiceProfile(
		IN_OUT x_IFX_VMAPI_VoiceProfile *pxVoiceProfile)
{
  /* For STUN server settings */
  pxVoiceProfile->xStunConfig.unStunPort = 3478;

  /* For SIP Protocol parameters */
  pxVoiceProfile->xStunConfig.unNatKeepAliveTime = 30;  

  /* For Voice Media settings */
  pxVoiceProfile->ucDtmfPayloadType = 96;
  return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_ProfileSignaling
*  Description          :   This Function sets the default ProfileSignaling parameters
*  Input Values         :   pointer to VoiceSignaling
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
char8 IFX_VMAPI_Default_ProfileSignaling(
		IN_OUT x_IFX_VMAPI_ProfileSignaling *pxProfileSig)
{
  /* For Server settings */			
  pxProfileSig->bEnableRegistrar = 0; /*Enable*/
  pxProfileSig->bEnableProxy = 0;  /* Enable */
  pxProfileSig->unRegistrarPort = 5060;  
  pxProfileSig->unProxyPort = 5060;  
  pxProfileSig->ucProxyProtocol =IFX_VMAPI_SIG_TRANSPORT_AUTO;  
  pxProfileSig->ucRegistrarProtocol =IFX_VMAPI_SIG_TRANSPORT_AUTO;  
  pxProfileSig->uiRegExpirationTime = 3600;  
  pxProfileSig->bWellKnownSource = 0;  

  /* For SIP Protocol Parameters */
  pxProfileSig->unT1 = 500;  
  pxProfileSig->unTk = 32000;  
  pxProfileSig->unRegRetryTime = 160;  
  pxProfileSig->unDnsQueryTimeOut = 160;  
  pxProfileSig->ucSipDscp = 26;  

  /* For UserAgent  */
  pxProfileSig->ucUAProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP;
  pxProfileSig->bUseCompactHdrs = 0;
  pxProfileSig->ucCohMethod = 0;
  pxProfileSig->unUAPort = 5059 + (pxProfileSig->ucProfileId);
  strcpy(pxProfileSig->acUserAgentHdr,"VoIP GW SubSystem s/w version 1.7");
	
  return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_ProfileMediaRtp
*  Description          :   This Function sets the default ProfileMediaRtp parameters
*  Input Values         :   pointer to ProfileMediaRtp
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
char8 IFX_VMAPI_Default_ProfileMediaRtp(
		IN_OUT x_IFX_VMAPI_ProfileMediaRTP *pxProfMed)
{
  pxProfMed->unMinRtpPort = 5000;
  pxProfMed->unMaxRtpPort = 6000;
  pxProfMed->unMinFaxPort = 3100;
  pxProfMed->unMaxFaxPort = 3200;
  pxProfMed->ucRtpDscp = 46;
  return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_ProfileEvents
*  Description          :   This Function sets the default Profile Events parameters
*  Input Values         :   pointer to the object
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/
char8 IFX_VMAPI_Default_ProfileEvents(
                IN_OUT x_IFX_VMAPI_EventSubscribe *pxEvent)
{
  pxEvent->uiEvent = IFX_VMAPI_VL_SUBS_EVENT_MWI;
  pxEvent->unSubscriptionTime = 100;
  return IFX_VMAPI_SUCCESS;
}


/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_CallingFeature
*  Description          :   This Function sets the default CallingFeature parameters
*  Input Values         :   pointer to CallingFeature
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
char8 IFX_VMAPI_Default_CallingFeature(
		IN_OUT x_IFX_VMAPI_LineCallingFeatures *pxCallFeat)
{
  pxCallFeat->bEnableCid = 1;
  pxCallFeat->bEnableDnd = 0;
  pxCallFeat->bEnableCallWaiting = 1;
  pxCallFeat->bEnableMwiIndication = 0;
  pxCallFeat->bEnableAcb = 0;
  pxCallFeat->ucCfnaRingCount = 3;
  pxCallFeat->bFwdStatus = 0;
  pxCallFeat->xCfuAddress.ucAddrType = 3;
  pxCallFeat->xCfbAddress.ucAddrType = 3;
  pxCallFeat->xCfnaAddress.ucAddrType = 3;
  return IFX_VMAPI_SUCCESS;
}
/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_LineEvents
*  Description          :   This Function sets the default Line Events parameters
*  Input Values         :   pointer to the object
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/
char8 IFX_VMAPI_Default_LineEvents(
                IN_OUT x_IFX_VMAPI_LineEvents *pxLineEvent)
{
  pxLineEvent->uiSubspnEvent = IFX_VMAPI_VL_SUBS_EVENT_MWI;
  pxLineEvent->ucSubspnState = IFX_VMAPI_VL_SUBS_STATE_IDLE;
  return IFX_VMAPI_SUCCESS;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_Misc
*  Description          :   This Function sets the default Miscellaneous parameters
*  Input Values         :   pointer to the Object
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/
char8
IFX_VMAPI_Default_Misc(IN x_IFX_VMAPI_Misc *pxMisc)
{
 
  pxMisc->bAcceptUnSolNotify = IFX_FALSE;
  pxMisc->bEnableUDPRedir = IFX_FALSE;
  pxMisc->bRestoreFactorySettings = IFX_FALSE;
  pxMisc->defaultFaxIface = IFX_FALSE;
  pxMisc->defaultOutbndIface = IFX_PSTN_NUM;
  return IFX_VMAPI_SUCCESS ;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_Default_LineCodecDesc
*  Description          :   This Function sets the default Line Codec parameters
*  Input Values         :   pointer to the object
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/
char8 IFX_VMAPI_Default_LineCodecDesc(
                IN_OUT x_IFX_VMAPI_CodecDesc *pxCodecDesc)
{
  if (pxCodecDesc->unCodecSuppFrameLen == 8)
     pxCodecDesc->unCodecSuppFrameLen = 30;
  else
     pxCodecDesc->unCodecSuppFrameLen = 20;
  return IFX_VMAPI_SUCCESS;
}


#if 0
char8
IFX_VMAPI_Default_NumPlanRule (
								IN_OUT x_IFX_VMAPI_NumPlan  *pxNumPlan)
{

	uint32 uiMainAct;
	/*! Numbering Plan Prefix String */
	char8 acPrefix[IFX_VMAPI_NUM_PLAN_MAX_PREFIX_LEN];
	/*! Minimum Digits for this Prefix */
	uchar8 ucMinDigits4Prefix;
	/*! Maximum Digits for this Prefix */
	uchar8 ucMaxDigits4Prefix;
	/*! Number of digits to be removed */
	uchar8 ucNoOfDigits2bRem;
	/*! Position of digits to be removed */
	uchar8 ucPosDigits2bRem;
	/*! Digits to be insterted */
	char8 cDigits2bIns;
	/*! Position of digits to be inserted */
	uchar8 ucPosDigits2bIns;
	/*! Digits to be replaced */
	char8 cDigits2bRep;
	/*! Position of digits to be replaced */
	uchar8 ucPosDigits2bRep;
	/*! Dial Tone - Required by TR-104 */
	uint32 uiDialTone;
	/* Facility Action Argument*/
	char8 acFacilityArg[5];

				
#define IFX_MAX_NUM_PLAN_TEST 15
x_IFX_VMAPI_NumPlanRule xRules[IFX_MAX_NUM_PLAN_TEST] =
{
	{0,1,IFX_DP_EXTENSION_DIAL,         "100[1-9]"  ,0,0,0,0,0,0,0,0,0,     "IFX_DP_EXTENSION_DIAL"},
	{1,1,IFX_DP_TWO_STAGE_PSTN_DIALING, "0"         ,0,0,1,1,0,0,0,0,0,     "IFX_DP_TWO_STAGE_PSTN_DIALING"},
	{2,1,IFX_DP_LOCAL_PSTN_CALLS,       "0[1-9]"    ,6,8,1,1,0,0,0,0,0,     "IFX_DP_LOCAL_PSTN_CALLS"},
	{3,1,IFX_DP_STD_PSTN_CALLS,         "00[1-9]"   ,7,12,1,1,0,0,0,0,0,    "IFX_DP_STD_PSTN_CALLS"},
	{4,1,IFX_DP_ISD_PSTN_CALLS,         "000[1-9]"  ,7,19,1,1,0,0,0,0,0,    "IFX_DP_ISD_PSTN_CALLS"},
	{5,1,IFX_DP_EMERGENCY_CALLS,        "0[2-9]11"  ,0,0,1,1,0,0,0,0,0,     "IFX_DP_EMERGENCY_CALLS"},
	{6,1,IFX_DP_PSTN_HOOKFLASH,         "*11"       ,0,0,3,1,0,0,0,0,0,     "IFX_DP_PSTN_HOOKFLASH"},
	{7,1,IFX_DP_BLIND_TX,               "*98"       ,3,15,3,1,0,0,0,0,0,     "IFX_DP_BLIND_TX"},
	{8,1,IFX_DP_CONFERENCE,             "#3"        ,0,0,0,0,0,0,0,0,0,     "IFX_DP_CONFERENCE"},
	{9,1,IFX_DP_RESUME_LASTACTV_CALLL,      "#1"    ,0,0,0,0,0,0,0,0,0,     "IFX_DP_RESUME_LASTACTV_CALLL"},
	{10,1,IFX_DP_RESUME_NON_LASTACTV_CALLL, "#2"    ,0,0,0,0,0,0,0,0,0,     "IFX_DP_RESUME_NON_LASTACTV_CALLL"},
	{11,1,IFX_DP_DISCONNECT_LASTACTV_CALLL, "#0"    ,0,0,0,0,0,0,0,0,0,     "IFX_DP_DISCONNECT_LASTACTV_CALLL"},
	{12,1,IFX_DP_EMERGENCY_CALLS, "309945199984"    ,0,0,1,1,0,0,0,0,0,     "IFX_DP_EMERGENCY_CALLS"},
	{13,1,IFX_DP_CALLWAITING_REJECT, "*12"    ,0,0,0,0,0,0,0,0,0,     "IFX_DP_CALLWAITING_REJECT"},
	{14,1,IFX_DP_PSTN_HOOKFLASH, "*11"    ,0,0,0,0,0,0,0,0,0,     "IFX_DP_PSTN_HOOKFLASH"},
};

 return IFX_VMAPI_SUCCESS;
}
#endif



