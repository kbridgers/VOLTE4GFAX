/**************************************************************************
 **   FILE NAME       : ifx_vmapi_mapi_int.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Voice Management to MAPI interface abstraction
 **   SRC VERSION     : V0.1
 **   DATE            : 21-11-2006
 **   AUTHOR          : Prashant
 **   DESCRIPTION     : This file contains the Abstraction functions to the
 **                      to the MAPI library APIs.
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_vmapi_port.h"
#include "ifx_vmapi_common.h"

int32  IFX_VMAPI_CheckACLRet(IFX_ID *pxiid, 
                uint32 unNoOfNVPairs, IFX_NAME_VALUE_PAIR *pxNVList,            
                uint32 *uiChangedCount, IFX_NAME_VALUE_PAIR **pxChangedNVList,
                uint32 uiInFlag)
{
  int32 ret = IFX_SUCCESS;
  
  CHECK_ACL_RET(*pxiid, unNoOfNVPairs, pxNVList,
                *uiChangedCount, *pxChangedNVList, uiInFlag, err_hdlr);
err_hdlr:
  return ret;
}

int32
IFX_VMAPI_CheckPointRet(uint32 uiInFlag, uchar8 *pcConfFile,   
                          char8 *pcChkPointFile)
{
  int32 ret = IFX_SUCCESS;

  CHECKPOINT_RET((int32)uiInFlag, (char8 *)pcConfFile, pcChkPointFile, err_hdlr);

err_hdlr:
  return ret;
}

int32
IFX_VMAPI_RollbackCfg(char8 *pcConfFile, uchar8 *pcChkPointFile,
                      uint32 uiInFlag)
{
  int32 ret = IFX_SUCCESS;
	/* Temporary Fix. Copy the rc.conf.tmp file back to rc.conf */
	//system("cp -f pcChkPointFile pcConfFile");
	
  ROLLBACK_CFG_DB_RET(pcChkPointFile, pcChkPointFile,
                      uiInFlag | IFX_F_INT_DONT_RESTART_SERVICES, err_hdlr);
#ifdef IFX_MAPI_ROLLBACK_SUPPORT
err_hdlr:
#endif
  return ret;
}

int32
IFX_VMAPI_CheckNSendNotification(IN IFX_ID *pxiid,
                                 IN uint32 uiChangedNVCount,
                                 IN IFX_NAME_VALUE_PAIR *pxChangedNVList,
                                 IN uint32 uiInFlag)
{
  int32 ret = IFX_SUCCESS;

	CHECK_N_SEND_NOTIFICATION((*pxiid), uiChangedNVCount, pxChangedNVList, uiInFlag, err_hdlr);
#ifdef TR69_DEFINED
  err_hdlr:
#endif
  return ret;
}

int32
IFX_VMAPI_UpdateMapNAttr(IN IFX_ID *pxiid,
                         IN uint32 uiChangedNVCount,
                         IN IFX_NAME_VALUE_PAIR *pxChangedNVList,
                         IN uint32 uiInFlag)
{
  int32 ret = IFX_SUCCESS;

	UPDATE_ID_MAP_N_ATTRIBUTES(pxiid, uiChangedNVCount, pxChangedNVList, uiInFlag, err_hdlr);
#ifdef TR69_DEFINED
  err_hdlr:
#endif
  return ret;
}


