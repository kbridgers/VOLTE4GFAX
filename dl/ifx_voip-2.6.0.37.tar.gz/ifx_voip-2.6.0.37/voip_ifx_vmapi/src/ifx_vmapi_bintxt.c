/**************************************************************************
 **   FILE NAME       : ifx_vmapi_bintxt.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Voice Management API 
 **   SRC VERSION     : V0.1
 **   DATE            : 20-06-2006
 **   AUTHOR          : Prashant
 **   DESCRIPTION     : This file defines the binary-text and textbinary
 **											mapping fciuntions used by the Voice Management API
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright � 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include <stdio.h>
#include <string.h>
#include "ifx_vmapi_port.h"
#include "ifx_list.h"
#include "ifx_debug.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi_bintxt.h"
#include "ifx_vmapi_obj_param_tbl.h"
#include "ifx_vmapi.h"

extern
int32 IFX_VMAPI_GetNVPairsForObject(OUT VOID *pvObj,
                     OUT x_IFX_VMAPI_NameValueList *pxNVList,
                     IN uint32 uiObjCode,
                     IN uchar8  *pcPrefix,
                     IN uint32 uiInFlag);

//static int32 iDectObj_Cnt=1;
/******************************************************************************
*  Function Name  : IFX_VAMPI_FillCharInBuf
*  Description    : This function is used to convert char type
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillCharInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%d", *(char8*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillUCharInBuf
*  Description    : This function is used to convert unsigned char type 
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillUCharInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%d", *(uchar8*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillShortIntInBuf
*  Description    : This function is used to convert short type
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillShortIntInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%u", *(int16*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillUShortIntInBuf
*  Description    : This function is used to convert unsigned short type
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillUShortIntInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%u", *(uint16*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillIntInBuf
*  Description    : This function is used to convert int type parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillIntInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%d", *(int32*)vValue);
  return;
}

/******************************************************************************
*  Function Name  :	IFX_VAMPI_FillUIntInBuf 
*  Description    : This function is used to convert unsigned int type 
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillUIntInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%u", *(uint32*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillLongInBuf
*  Description    : This function is used to convert long type 
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillLongInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%ld", *(long32*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillULongInBuf
*  Description    : This function is used to convert unsigned long type 
*										parameter to text.
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillULongInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%lu", *(ulong32*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillFloatInBuf
*  Description    : This function is used to convert float type
*										parameter to text
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillFloatInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%f", *(float32*)vValue);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VAMPI_FillStringInBuf
*  Description    : This function is used to convert character string type
*										parameter to text
*  Input Values   : vValue - Binary value to be converted to string.
*  Output Values  : pcBuffer - character buffer holding the converted string.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetNameValueListFromObj function.
******************************************************************************/
STATIC
VOID IFX_VAMPI_FillStringInBuf(OUT char8* pcBuffer, IN CONST VOID* vValue)
{
	IFX_VMAPI_SPRINTF((char8 *) pcBuffer, "%s", (char8*)vValue);
  return;
}

/* Function pointers for the Binary-to-Text conversion of different types of 
 * parameters.
 */
FPtr_SetTxtValue	aSetTextValueFPtr[] = 
{
	IFX_VAMPI_FillCharInBuf,
	IFX_VAMPI_FillUCharInBuf,	
	IFX_VAMPI_FillShortIntInBuf,
	IFX_VAMPI_FillUShortIntInBuf,
	IFX_VAMPI_FillIntInBuf,
	IFX_VAMPI_FillUIntInBuf,
	IFX_VAMPI_FillLongInBuf,
	IFX_VAMPI_FillULongInBuf,
	IFX_VAMPI_FillFloatInBuf,
	IFX_VAMPI_FillFloatInBuf,
	IFX_VAMPI_FillStringInBuf
};

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetCharBinValue
*  Description    : This function is used to set character type field field.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetCharBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(char8*)pBinVal = IFX_VMAPI_ATOI(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetUCharBinValue
*  Description    : This function is used to set the unsigned character type 
*										field in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetUCharBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(uchar8*)pBinVal = IFX_VMAPI_ATOI(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetShortIntBinValue
*  Description    : This function is used to set the short int type 
*										field in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetShortIntBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(int16*)pBinVal = IFX_VMAPI_ATOI(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetUShortIntBinValue
*  Description    : This function is used to set the unsigned short int type
*									 	field in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetUShortIntBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(uint16*)pBinVal = IFX_VMAPI_ATOI(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetIntBinValue
*  Description    : This function is used to set the integer type 
*										field in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetIntBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(int32*)pBinVal = IFX_VMAPI_ATOI(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetUIntBinValue
*  Description    : This function is used to set the unsigned integer type 
*										field in the object
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetUIntBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(uint32*)pBinVal = IFX_VMAPI_ATOI(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetLongBinValue
*  Description    : This function is used to set the long type field
*										in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetLongBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(long32*)pBinVal = IFX_VMAPI_ATOL(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetULongBinValue
*  Description    : This function is used to set the unsigned long type
*										field in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetULongBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(ulong32*)pBinVal = IFX_VMAPI_ATOL(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetFloatBinValue
*  Description    : This function is used to set the float type field
*									  in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetFloatBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	*(float32*)pBinVal = IFX_VMAPI_ATOF(pTxtVal);
  return;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetStrBinValue
*  Description    : This function is used to set the character string type 
*										field in the object.
*  Input Values   : pTxtVal - String to be stored into binary structure fields.
*  Output Values  : pBinVal - Given location contains the binary value.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC
VOID IFX_VMAPI_SetStrBinValue(OUT VOID *pBinVal, IN CONST char8 *pTxtVal)
{
	IFX_VMAPI_STRCPY((char8*)pBinVal, pTxtVal);
  return;
}

/* Function pointers for the Text-to-Binary conversion of different types of 
 * parameters.
 */
FPtr_SetBinValue	aSetBinValueFPtr[] = 
{
	IFX_VMAPI_SetCharBinValue,
	IFX_VMAPI_SetUCharBinValue,
	IFX_VMAPI_SetShortIntBinValue,
	IFX_VMAPI_SetUShortIntBinValue,
	IFX_VMAPI_SetIntBinValue,
	IFX_VMAPI_SetUIntBinValue,
	IFX_VMAPI_SetLongBinValue,
	IFX_VMAPI_SetULongBinValue,
	IFX_VMAPI_SetFloatBinValue,
	IFX_VMAPI_SetFloatBinValue,
	IFX_VMAPI_SetStrBinValue
};


/******************************************************************************
*  Function Name  : IFX_VMAPI_GetNumObjectInstances
*  Description    : This is an internal function used during the text-binary
*										conversions. It is called when data of type object
*										(represented by IFX_VMAPI_PARAM_TYPE_OBJ) is to be
*										converted to text or binary.
*  Input Values   : pvObj - Object pointer
*										unObjCode - Object Id
*										uiParamIdx - Index of the paramter object in param table
*  Output Values  : pxParamTbl - Pointer to paramter table for this object
*										uiNumObjs - Number of object instance (>=1).
*										uiObjSize - Size of each object instance.
*  Return Value   : none.
*  Notes          : This is an internal function used by 
										IFX_VMAPI_GetObjFromNameValueList function.
******************************************************************************/
STATIC uint32
IFX_VMAPI_GetNumObjectInstances(
							IN VOID *pvObj,
							IN uint16 unObjCode,
							IN uint32 uiParamIdx,
					 		OUT uint32 *puiNumObjs,
							OUT uint32 *puiObjSize)
{
	uint32 uiParentObjSize, uiNumParamOfParent, uiNumParam;
  x_IFX_VMAPI_ParamTxtMap *pxParamTbl;
	x_IFX_VMAPI_ParamTxtMap *pxCurObjParamTbl;

	/* Get the Parameter Table */

	if (IFX_VMAPI_GetParamTbl(&pxParamTbl, &uiNumParamOfParent, 
							&uiParentObjSize, unObjCode) == IFX_VMAPI_FAIL) {
		return IFX_VMAPI_FAIL;
	}

	/* for getting object size - puiObjSize */
	if (IFX_VMAPI_GetParamTbl(&pxCurObjParamTbl, &uiNumParam, puiObjSize,
				IFX_VMAPI_GET_PARAM_ID(pxParamTbl, uiParamIdx)) == IFX_VMAPI_FAIL) {
		return IFX_VMAPI_FAIL;
	}

	if (IFX_VMAPI_GET_PARAM_INSTANCES_OFFSET(pxParamTbl, uiParamIdx) > 0) {
		*puiNumObjs = *(uint32 *)((char*)pvObj + 
								IFX_VMAPI_GET_PARAM_INSTANCES_OFFSET(pxParamTbl, uiParamIdx));
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_NAME_AND_INSTANCE,
		      IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx),
          uiParamIdx,*puiNumObjs); 
	}
  else {
		/* (Offset of next Param - Offset of the Base of array object param
			 in the parent object) / (size of an array element) */
		if ((uiParamIdx != uiNumParamOfParent - 1)) {
			*puiNumObjs = (IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl,uiParamIdx+1) -
									IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx)) 
									/ *puiObjSize;
			
		  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_NAME_AND_INSTANCE,
          IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx)
          ,uiParamIdx,*puiNumObjs);

			IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_VMAPI_OBJ_SIZE,
						IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx+1),
						IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx),
						*puiObjSize,
						*puiNumObjs); 
		}
		else {
			*puiNumObjs = (uiParentObjSize - 
					IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx)) / *puiObjSize;
			
		  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_NAME_AND_INSTANCE,
          IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx)
          ,uiParamIdx,*puiNumObjs);
			/* VDBG(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,(char8*)__FUNCTION__,
			" %d %d %d\n", uiParentObjSize,
							IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx),
							*puiNumObjs); */
		}
	}

  return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_GetObjFromNameValueList
*  Description    : This function is used to get the binary object structure
*									  from the input name-value pairs.
*  Input Values   : unObjCode - object code for which binary struture is reqd.
*										pNVList - Pointer to the name-value pairs' list.
*										pcPrefix - prefix included for each parameter name, if any.
*										Else, NULL.
*  Output Values  : pvObj - pointer to the object structure.
*  Return Value   : IFX_VMAPI_SUCCESS, on successfully getting name-value pairs.
*										IFX_VMAPI_FAIL, on failure.
*  Notes          : This is an internal function used by the vmapi get apis.The
*										function calls itself recursively for nested structure 
*										elements. Each name-value pair is converted to binary 
*										structure parameters.
*										uiNameValIdx takes part in the recursive calls.
******************************************************************************/
/*XXX: The logic - each paramter in the parameter table is compared with the
	NV Pairs and the matching value is stores in parameter. If there is an
	invalid NV pair, it is skipped. Absence of a valid NV pair leads to
	failure
*										XXX: If there is cpeid or any other name-value pair not
*										belonging to the object as the starting lines of the
*										object, then they may be skipped by calling the function
*										with the offset uiNameValIdx.
******************************************************************************/
PUBLIC int32
IFX_VMAPI_GetObjFromNameValueList(
									IN uint16 unObjCode,
								  OUT VOID *pvObj,
								  IN x_IFX_VMAPI_NameValueList *pNVList,
									IN_OUT uint32 *uiNameValIdx,
									IN uchar8 *pcPrefix)
{
	x_IFX_VMAPI_ParamTxtMap *pxParamTbl = NULL;
	uint32 /*uiNumPairs,*/ uiParamIdx;
	char8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN]={0};
	/* temporary buffer used for the text-to-binary conversion */
	char8 acTempPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN + IFX_VMAPI_MAX_INT_LEN * 3]={0};
	uchar8 acChildPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN + IFX_VMAPI_MAX_INT_LEN ]={0};
  char8 acPcpeId[IFX_VMAPI_TXT_MAX_PREF_LEN + 20]={0};
  char8 acCpeId[IFX_VMAPI_TXT_MAX_PREF_LEN + 5 + IFX_VMAPI_MAX_INT_LEN]={0};
  char8 acCpeIdTemp[IFX_VMAPI_TXT_MAX_PREF_LEN+IFX_VMAPI_MAX_INT_LEN]={0};
	uint32 uiNumObjs, uiNumParam, uiObjSize, iPrefLen;
  uint32 uiParamType ; /* Parameter type */
  x_IFX_VMAPI_NameValueList *pxNVList1;
  uint32 uiNameValIdx1=0;
  uint32 outFlag = 0;
  uint32 uiInFlag = 0;
  char8 acInBuf[IFX_MAX_BUFF_LEN + MAX_FILELINE_LEN]={0};
  char8 acInBufCpeId[2 * IFX_MAX_BUFF_LEN +MAX_FILELINE_LEN]={0};
  char8 acCommand[MAX_FILELINE_LEN]={0};
  int32 iRet;
  int32 uiErrCode;
  int i,iNumEntries=0;
  void *ppxServProvInfo;
  uint16 unChildObjId =0;
  int32 iDectObj_Cnt=1;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
			"** IFX_VMAPI_GetObjFromNameValueList Entering **\n");

	/* Get the linkage to the Param Table */
	if (IFX_VMAPI_GetParamTbl(&pxParamTbl, &uiNumParam, &uiObjSize, unObjCode)
																						 == IFX_VMAPI_FAIL) {
		return IFX_VMAPI_FAIL;
	}

	if (!pxParamTbl) {
		return IFX_VMAPI_SUCCESS;
	}
	/*IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GET_PARAM_TBL,
										(unsigned)pxParamTbl, uiNumParam);*/ 

  //uiNumPairs = (uint32)pNVList->unNoOfNVPairs;

	if (pcPrefix != NULL) {
		IFX_VMAPI_STRCPY(acPrefix, pcPrefix);
		IFX_VMAPI_STRCPY(acCpeIdTemp, pcPrefix);
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GENERAL,
			"Prefix is received acPrefix =", acPrefix);
	}
	else if(unObjCode){
		IFX_VMAPI_STRCPY(acPrefix, IFX_VMAPI_GET_OBJ_PREFIX(unObjCode));
	}
	iPrefLen = strlen(acPrefix);
	
	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_PARAM_PREFIX_LEN,
					uiNumParam, acPrefix, iPrefLen);

	for (uiParamIdx=0; uiParamIdx<uiNumParam; uiParamIdx++) {
					
    uiParamType = IFX_VMAPI_GET_PARAM_TYPE(pxParamTbl, uiParamIdx);
		if (uiParamType == IFX_VMAPI_PARAM_TYPE_OBJ_LIST) {
						
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJECT_TYPE_LIST,
											 IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));

      /* Get the child Object Id */
      /*if(unObjCode == IFX_VMAPI_OBJ_CODEC_CAPABS)
      {
        unChildObjId = IFX_VMAPI_OBJ_CODEC_DESC;
      }
      else*/ 
			if(unObjCode == IFX_VMAPI_OBJ_DECT)
      {
        unChildObjId = unObjCode + iDectObj_Cnt;
				iDectObj_Cnt+=1;
      }
      else 
      {
        unChildObjId = unObjCode+1;
      }

      /* lock */
      IFX_VMAPI_LOCK(uiLock);

	    IFX_VMAPI_STRCPY(acTempPrefix, IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));

      /*MAKE_SECTION_COUNT_TAG(IFX_VMAPI_GET_OBJ_NAME(uiObjectId), acCommand);*/
      IFX_VMAPI_SPRINTF((char8*)acCommand, "%s_Count", acTempPrefix);
    
      if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, IFX_VMAPI_GET_OBJ_NAME(unChildObjId), 
          acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			       	 "Error : Could Not Get Count Of Objects\n");
          IFX_VMAPI_UNLOCK(uiLock); 
        return iRet;   
      }
  
      iNumEntries = atoi(acInBuf);
 
		  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_PARAM_PREFIX,
			              iNumEntries, acTempPrefix);

      IFX_VMAPI_GetNumObjectInstances(pvObj, unObjCode, uiParamIdx, 
		  																  &uiNumObjs, &uiObjSize);

      pxNVList1 = (x_IFX_VMAPI_NameValueList*)
                IFX_VMAPI_MALLOC(sizeof(x_IFX_VMAPI_NameValueList));
      if (pxNVList1 == NULL) {
        IFX_VMAPI_UNLOCK(uiLock);
        return IFX_VMAPI_FAIL;
      }

      void *pxTmp=NULL;
      for(i=0;i<iNumEntries;i++)
      {
        IFX_VMAPI_SPRINTF((char8*)acCpeId, "%scpeId", acCpeIdTemp);

        if (unObjCode > 0 && (iRet = ifx_GetObjData(SYSTEM_CONF_FILE, IFX_VMAPI_GET_OBJ_NAME(unObjCode),
            acCpeId, uiInFlag, &outFlag, acInBufCpeId)) != IFX_SUCCESS)  {
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "Error : Could Not Get Count Of Objects");
          IFX_VMAPI_UNLOCK(uiLock);
					if(pxNVList1 != NULL)	
		          IFX_VMAPI_FREE(pxNVList1);
					return iRet;
        }
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_CPEID_VAL,
                   acCpeId,atoi(acInBufCpeId));

        IFX_VMAPI_SPRINTF((char8*)acPcpeId, "%s_%d_pcpeId",
              IFX_VMAPI_GET_OBJ_PREFIX(unChildObjId ),i);

        if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, IFX_VMAPI_GET_OBJ_NAME(unChildObjId),
            acPcpeId, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error : Could Not Get Count Of Objects ");
          IFX_VMAPI_UNLOCK(uiLock);
      		IFX_VMAPI_FREE(pxNVList1);
			    return iRet;
        }
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_PCPEID_VAL,
                   acPcpeId,atoi(acInBuf));

        if(atoi(acInBuf)==atoi(acInBufCpeId))
        {
          __ifx_list_add_to_tail(&pxTmp,
                       &ppxServProvInfo,
                       uiObjSize,
                       &uiErrCode);
    
          *((uint32*)(((uchar8*)pvObj)+IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx)))=(uint32)pxTmp;

          IFX_VMAPI_SPRINTF((char8*)acChildPrefix, "%s_%d_",
                 IFX_VMAPI_GET_OBJ_PREFIX(unChildObjId),i + 0);

          pxNVList1->unNoOfNVPairs = 0;

          if ((iRet = IFX_VMAPI_GetNVPairsForObject(
                      ppxServProvInfo,
                      pxNVList1,unChildObjId, acChildPrefix, 
                      uiInFlag  )) == IFX_VMAPI_SUCCESS ) {
      
            uiNameValIdx1 = 0;
            iRet = IFX_VMAPI_GetObjFromNameValueList(unChildObjId, 
                      ppxServProvInfo, pxNVList1, 
                      &uiNameValIdx1, acChildPrefix );
          }else {
            IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				       "Error : GetNVPairsForObject failure for child object");
            iRet = IFX_VMAPI_FAIL;
            break;
          }
        }
      }/* For loop */
#if 0 
  if (ppxServProvInfo == NULL) {
    IFX_VMAPI_FREE(pxNVList1);
    IFX_VMAPI_UNLOCK(uiLock);
    return IFX_VMAPI_FAIL;
  }

  /* unlock */
  IFX_VMAPI_UNLOCK(uiLock);

  /* If objects are not obtained, free allocated memory */
  if (iRet != IFX_VMAPI_SUCCESS ) {
    IFX_VMAPI_FREE(*ppxServProviderInfo);
    *ppxServProviderInfo = 0;
    *puiNumEntries = 0;
  }
#endif
	  ++*uiNameValIdx;
    IFX_VMAPI_FREE(pxNVList1);
    //return iRet;
    }else if ( uiParamType == IFX_VMAPI_PARAM_TYPE_OBJ ) {
        /* parameter is another object, get all parameters of this object */ 
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJECT_TYPE,
				  							 IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));
     	  IFX_VMAPI_SPRINTF(acTempPrefix,"%s%s_",
            acPrefix,IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));
      
        if (IFX_VMAPI_GetObjFromNameValueList( 
                            IFX_VMAPI_GET_PARAM_ID(pxParamTbl, uiParamIdx),
					                  (VOID*) ((uchar8*)pvObj 
                            + IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx)),
					                  pNVList, 
                            uiNameValIdx, 
                            (uchar8*)acTempPrefix ) != IFX_VMAPI_SUCCESS) {
					  return IFX_VMAPI_FAIL;
				}
    }else if (!IFX_VMAPI_STRCMP(&pNVList->axNameValue[*uiNameValIdx].fieldname[iPrefLen],
					          IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx))) {
     
			  /*IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			        "++++INSIDE PARAMETER CONVERSION+++++\n");*/
				if(uiParamType < 12)
			  aSetBinValueFPtr[uiParamType-1]((VOID*)((uchar8*)pvObj 
              + IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx)),
				      pNVList->axNameValue[*uiNameValIdx].value );
			  ++*uiNameValIdx;
		}else {
			IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJ_FROM_NV_MISMATCH,
							&pNVList->axNameValue[*uiNameValIdx].fieldname[iPrefLen]);
			return IFX_VMAPI_FAIL;
		}
	}
	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_GetNameValueListFromObj
*  Description    : This function is used to get the name-value pairs of the
*										object provided.
*  Input Values   : unObjCode - object code for which name-value pairs is reqd.
*										pvObj - pointer to the object structure.
*										pcPrefix - prefix to be included for each parameter name,
*										if any. Else, NULL.
*  Output Values  : pcSectionName - section name of the object, if any.
*										pNVList - Pointer to the name-value pairs' list.
*  Return Value   : IFX_VMAPI_SUCCESS, on successfully getting name-value pairs.
*										IFX_VMAPI_FAIL, on failure.
*  Notes          : This is an internal function used by the vmapi set apis. The
*										function calls itself recursively for nested structure 
*										elements. Each parameter of the structure is converted to
*										name-value pairs attaching a proper prefix to the name.
*										uiNvIdx is the parameter taking part in recursive calls.
******************************************************************************/
PUBLIC int32
IFX_VMAPI_GetNameValueListFromObj(
											IN uint16 unObjCode,
					 						IN  VOID *pvObj,
											OUT uchar8 *pcSectionName,
											OUT x_IFX_VMAPI_NameValueList *pNVList,
											IN_OUT uint32 *uiNvIdx,
											IN uchar8 *pcPrefix)
{
	uint32 uiParamIdx;
	x_IFX_VMAPI_ParamTxtMap *pxParamTbl = NULL;
	uint32 uiOffset;
  uchar8 uiParamType;
	char8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN]={0};
	char8 acTempPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN + 40]={0};
	uint32 uiObjSize, uiNumParam;

	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			"**IFX_VMAPI_GetNameValueListFromObj Entering ");
	/* Get the linkage to the Param Table */
	IFX_VMAPI_GetParamTbl(&pxParamTbl, &uiNumParam, &uiObjSize, unObjCode);
	if (!pxParamTbl) {
		return IFX_VMAPI_FAIL;
	}
	/*IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GET_PARAM_TBL,
										(unsigned)pxParamTbl, uiNumParam);*/ 

	/* Get Section Name of Object */
	if (pcSectionName != NULL && unObjCode) {
		IFX_VMAPI_STRCPY(pcSectionName, IFX_VMAPI_GET_OBJ_NAME(unObjCode));
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GENERAL,
			"pcSectionName",pcSectionName);
	}
	/* Get Prefix of Object */
	if (pcPrefix != NULL) {
		IFX_VMAPI_STRCPY(acPrefix, pcPrefix);
		IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_GENERAL,
			"Prefix is received acPrefix =", acPrefix);
	}

	for (uiParamIdx = 0; uiParamIdx<uiNumParam; ++uiParamIdx, ++*uiNvIdx) {
		/* Copy the value */
 		uiParamType = IFX_VMAPI_GET_PARAM_TYPE(pxParamTbl, uiParamIdx);
		uiOffset = IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx);
    if ( uiParamType == IFX_VMAPI_PARAM_TYPE_OBJ ) {
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_VMAPI_OBJECT_TYPE,
				  							 IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));
      IFX_VMAPI_SPRINTF(acTempPrefix,"%s%s-",
          acPrefix,IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));
      if (IFX_VMAPI_GetNameValueListFromObj(
                    IFX_VMAPI_GET_PARAM_ID(pxParamTbl, uiParamIdx),
					          (VOID*)((uchar8*)pvObj + 
                      IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamIdx)),
				            NULL, pNVList, uiNvIdx, 
                    (uchar8*)acTempPrefix) != IFX_VMAPI_SUCCESS ) {

					return IFX_VMAPI_FAIL;
			} 

    }	else {
			/* Copy the name */
			/* Prefix will be filled by the utility API */
			IFX_VMAPI_STRCPY(pNVList->axNameValue[*uiNvIdx].fieldname, acPrefix);
			IFX_VMAPI_STRCAT(pNVList->axNameValue[*uiNvIdx].fieldname, 
							 				IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamIdx));
		  if ( uiParamType && uiParamType != IFX_VMAPI_PARAM_TYPE_OBJ_LIST) {
					if(uiParamType-1 < 12)	
				  aSetTextValueFPtr[uiParamType-1](pNVList->axNameValue[*uiNvIdx].value,
				     														(VOID*)((uchar8*)pvObj + uiOffset));
      }
		} /* else  */
	} /* for loop */
	pNVList->unNoOfNVPairs = *uiNvIdx;
	--*uiNvIdx;
	return IFX_VMAPI_SUCCESS;
}
