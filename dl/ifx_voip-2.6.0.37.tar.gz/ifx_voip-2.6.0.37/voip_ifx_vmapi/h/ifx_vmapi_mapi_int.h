/**************************************************************************
 **   FILE NAME       : ifx_vmapi_mapi_int.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Voice Management to MAPI interface abstraction
 **   SRC VERSION     : V0.1
 **   DATE            : 21-11-2006
 **   AUTHOR          : Prashant
 **   DESCRIPTION     : This file contains the Abstraction functions to the
 **											to the MAPI library APIs.
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_VMAPI_MAPI_INT_H__
#define __IFX_VMAPI_MAPI_INT_H__

#ifdef __cplusplus
extern	"C" {
#endif

#include "ifx_vmapi_common.h"

#define IFX_VMAPI_CONFIG_WRITE(pcConFile, uiInFlag) \
										ifx_config_write(pcConFile, uiInFlag)

#define IFX_VMAPI_FORM_CFG_BUF(pcBuf, uiChangedCount, pxChangedNVList) \
										form_cfgdb_buf(pcBuf, uiChangedCount, pxChangedNVList)

#define IFX_VMAPI_FORM_ARRAY_FVP_FROM_CFG_BUG(pcBuf, unNoOfPairs, pxNameValue) \
						form_array_fvp_from_cfgdb_buf(pcBuf, unNoOfPairs, pxNameValue)

#define IFX_VMAPI_WriteToFlash() 0 
             //ifx_flash_write()


				
#if 1
int32
IFX_VMAPI_CheckPointRet(uint32 uiInFlag, char8 *pcConfFile, char8 *pcChkPointFile);

int32
IFX_VMAPI_RollbackCfg(char8 *pcConfFile, char8 *pcChkPointFile,uint32 uiInFlag);

int32  IFX_VMAPI_CheckACLRet(IFX_ID *pxiid, 
                uint32 unNoOfNVPairs, IFX_NAME_VALUE_PAIR *pxNVList,            
                uint32 *uiChangedCount, IFX_NAME_VALUE_PAIR **pxChangedNVList,
                uint32 uiInFlag);


int32
IFX_VMAPI_CheckNSendNotification(IN IFX_ID *pxiid,
                                 IN uint32 uiChangedNVCount,
                                 IN IFX_NAME_VALUE_PAIR *pxChangedNVList,
                                 IN uint32 uiInFlag);


int32
IFX_VMAPI_UpdateMapNAttr(IN IFX_ID *pxiid,
                         IN uint32 uiChangedNVCount,
                         IN IFX_NAME_VALUE_PAIR *pxChangedNVList,
                         IN uint32 uiInFlag);

#endif

/*************************************************************************/
#ifdef __cplusplus
}
#endif

#endif /* __IFX_VMAPI_MAPI_INT_H__ */
