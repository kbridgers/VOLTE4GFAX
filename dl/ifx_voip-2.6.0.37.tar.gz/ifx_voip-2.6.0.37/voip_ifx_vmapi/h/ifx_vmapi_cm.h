/*******************************************************************************
 **   FILE NAME       : ifx_vmapi_cm.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Voice Management API definitions
 **   SRC VERSION     : V0.1
 **   DATE            : 05-12-2006
 **   AUTHOR          : Mahipati Deshpande
 **   DESCRIPTION     : This file defines utility functions. These functions
 **                     map TR-104 objects to CM and updates parameters in CM 
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*******************************************************************************/
#ifndef __IFX_VMAPI_CM_H__
#define __IFX_VMAPI_CM_H__

#define IFX_VMAPI_CopyToCmAddrX(cmAddrPtr,vmapiAddrPtr) {  \
    (cmAddrPtr)->ucAddrType = (vmapiAddrPtr)->ucAddrType; \
    IFX_VMAPI_STRCPY((cmAddrPtr)->acDisplayName,(vmapiAddrPtr)->acDisplayName);\
    IFX_VMAPI_STRCPY((cmAddrPtr)->acUserName,(vmapiAddrPtr)->acUserName); \
    IFX_VMAPI_STRCPY((cmAddrPtr)->acCalledAddr,(vmapiAddrPtr)->acDestAddr);\
    (cmAddrPtr)->unPort = (vmapiAddrPtr)->unPort; \
    (cmAddrPtr)->ucAddrProto = (vmapiAddrPtr)->ucAddrProto; \
  }

#define IFX_VMAPI_CopyToCmCodecX(cmCodecPtr,vmapiCodecPtr) {\
    (cmCodecPtr)->uiCodec =  (vmapiCodecPtr)->uiCodecId;  \
    (cmCodecPtr)->ucFrameSize = (vmapiCodecPtr)->unCodecSuppFrameLen;  \
    (cmCodecPtr)->ucDynPT = (vmapiCodecPtr)->ucPayloadType ; \
  }


int32
ifx_set_CM_VoiceLine(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_VoiceLine *pxVoiceLine,
              IN uint32 uiInFlag);

int32
IFX_VMAPI_WriteVoiceLineSignalingToCm(
                IN x_IFX_VMAPI_LineSignaling *pxVoiceLine);

int32
IFX_VMAPI_WriteLineCallingFeaturesToCm(
                IN x_IFX_VMAPI_LineCallingFeatures *pxVoiceLine);

int32
IFX_VMAPI_WriteLineVoiceProcessingToCm(
          IN x_IFX_VMAPI_LineVoiceProcessing *pxLineVoiceProcessing );
int32
IFX_VMAPI_WriteLineCodecToCm(IN x_IFX_VMAPI_LineCodec *pxLineVoiceCodec);

int32
IFX_VMAPI_WriteLineCodecListToCm(IN x_IFX_VMAPI_LineCodecList *pxCodecList);

int32 ifx_set_CM_VoiceProfile(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_VoiceProfile *pxVoiceProfile,
                            IN uint32 uiInFlag);

int32 ifx_set_CM_VoiceProfileSignaling(IN uint32 uiOperation,
                    IN x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling,
                    IN uint32 uiInFlag);


int32 ifx_set_CM_ProfileMediaRTP( 
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileMediaRTP *pxProfileMediaRTP, 
              IN uint32 uiInFlag);

int32 ifx_set_CM_ProfileMediaRTCP( 
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileMediaRTCP *pxProfileMediaRTCP , 
              IN uint32 uiInFlag);

int32 ifx_set_CM_VoiceCaps(IN uint32 uiOperation,
                        IN x_IFX_VMAPI_VoiceCapabilities *pxVoiceCap,
                        IN uint32 uiFlags);

int32 ifx_set_CM_VoicePhyInterface( 
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_VoiceServPhyIf *pxProfileMediaRTCP , 
              IN uint32 uiInFlag);

#endif /*__IFX_VMAPI_CM_H__ */
