/**************************************************************************
 **   FILE NAME       : ifx_vmapi.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Voice Management API 
 **   SRC VERSION     : V0.1
 **   DATE            : 20-06-2006
 **   AUTHOR          : Hari & Karthik, Prashant , Pallav
 **   DESCRIPTION     : This file defines the TR-104 objects currently supported
 **											by the VMAPI.
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_VMAPI_H__
#define __IFX_VMAPI_H__
/*! \file ifx_vmapi.h
    \brief File containing the Constants, related Data structures for VMAPI Objects.
*/
//#define DECT_SENSORS_SUPPORT
#ifdef __cplusplus
extern "C" {
#endif

/*! \brief \ingroup VoIP_LIB_API
        \defgroup MAPI_VOICE MAPI-Voice 
    	\brief This section describes the Management API extensions for Voice.
        MAPI Voice is also referred to as VMAPI (Voice MAPI) in some sections
        of this document.
*/

/*! \brief \ingroup MAPI_VOICE
        \defgroup MAPI_VOICE_OBJ Objects
    	\brief This section describes the MAPI Voice Objects.  The
		MAPI Voice Objects are represented using data structures.
*/
/* @{ */


/*! \brief IFX_TRUE Macro used to represent boolean TRUE condition */
#define IFX_TRUE										1

/*! \brief IFX_FALSE Macro used to represent boolean FALSE condition */
#define IFX_FALSE										0

/*! \brief "Null" string */
#ifndef IFX_NULL
#define IFX_NULL									  "Null"	
#endif


/*! \brief IFX_VMAP_SUCCESS represents success of a VMAPI operation */ 
#define IFX_VMAPI_SUCCESS   0  
/*! \brief IFX_VMAP_SUCCESS represents failure of a VMAPI operation */ 
#define IFX_VMAPI_FAIL     (-1)


/*! \brief IFX_VMAP_OP_ADD is for add operation flag in SET VMAPI call*/ 
#define IFX_VMAPI_OP_ADD   IFX_OP_ADD  
/*! \brief IFX_VMAP_OP_DEL is for delete operation flag in SET VMAPI call*/ 
#define IFX_VMAPI_OP_DEL   IFX_OP_DEL
/*! \brief IFX_VMAP_OP_MOD is for modify operation flag in SET VMAPI call*/ 
#define IFX_VMAPI_OP_MOD   IFX_OP_MOD
/*! \brief IFX_VMAP_OP_DEFAULT is for default operation flag in SET VMAPI call*/ 
#define IFX_VMAPI_OP_DEFAULT   IFX_F_DEFAULT
/*! \brief IFX_VMAP_OP_NOMALLOC is for default operation flag in SET VMAPI call*/ 
#define IFX_VMAPI_OP_NOMALLOC   3



/*! \brief Signaling Protocol */
#define IFX_VMAPI_SIG_PROTOCOL			"SIP"	

/*! \brief Length of the Voice Profile Name*/
#define IFX_VMAPI_VP_NAME_LEN					IFX_VP_NAME_LEN
/*! \brief Max Length of the VoiceProfile Digit Map*/
#define IFX_VMAPI_VP_MAX_DIGIT_MAP_LEN		IFX_MAX_DIGIT_MAP_LEN
/*! \brief Max Length of the Transport Address */
#define IFX_VMAPI_MAX_TRANS_ADDR_LEN		128
/*! \brief Max IP Address length for Line Session*/
#define IFX_VMAPI_MAX_IP_ADDRESS_LEN 		IFX_MAX_IP_ADDRESS_LEN
/*! \brief Max User Name length*/
#define IFX_VMAPI_MAX_USER_NAME_LEN			IFX_MAX_USR_NAME
/*! \brief Max User Password Length */
#define IFX_VMAPI_MAX_USER_PASSWD_LEN		16
/*! \brief Max Phone No Length */
#define IFX_VMAPI_MAX_PHONE_NO_LEN			IFX_MAX_PHONE_NO
/*! \brief Max Length of the Domain Name*/
#define IFX_VMAPI_MAX_DOMAIN_NAME_LEN		128
/*! \brief Max UserAgent Header length*/
#define IFX_VMAPI_MAX_UA_FIELD_LEN			128
/*! \brief Max text length for ResponseMap */
#define IFX_VMAPI_MAX_RSP_MAP_TXT_LEN		IFX_MAX_RSP_MAP_TXT
/*! \brief Max length of the CNAME */
#define IFX_VMAPI_MAX_CNAME_LEN				IFX_MAX_CNAME
/*! \brief max length of the Tone Name*/
#define IFX_VMAPI_MAX_TONE_NAME_LEN			IFX_MAX_TONE_NAME
/*! \brief Max length of the Ring Name */
#define IFX_VMAPI_MAX_RING_NAME_LEN			IFX_MAX_TONE_NAME
/*! \brief Max Master Key length*/
#define IFX_VMAPI_MAX_MASTER_KEY_LEN		IFX_MASTER_KEY_LENGTH
/*! \brief Max Master Salt length*/
#define IFX_VMAPI_MAX_MASTER_SALT_LEN		IFX_MASTER_SALT_LENGTH
/*! \brief Max Version string length*/
#define IFX_VMAPI_MAX_VER_STR_LEN			IFX_MAX_VERSION_STRING
/*! \brief Max length for any TelUri config parameter */
#define IFX_VMAPI_MAX_TEL_CODE_LEN			IFX_TEL_CODE_SIZE
/*! \brief Max length of the Phy Interface description */
#define IFX_VMAPI_MAX_IFACE_DESCR_LEN		128
/*! \brief Max length of the SIP User Name */
#define IFX_VMAPI_MAX_SIP_USR_NAME_LEN 	IFX_MAX_USR_NAME
/*! \brief Max length of the SIP Display Name*/
#define IFX_VMAPI_MAX_SIP_DISP_NAME_LEN 	IFX_MAX_DISP_NAME
/*! \brief Max length of the Time string*/
#define IFX_VMAPI_MAX_TIME_STR_LEN			IFX_TIME_STR_SIZE
/*! \brief Max length of the Dial Code*/
#define IFX_VMAPI_MAX_DIAL_CODE_LEN			IFX_MAX_DIAL_CODE_SIZE
/*! \brief Max number of Address Book entries*/
#define IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES	    10
/*! \brief Max number of Address Book entries per line*/
#define IFX_VMAPI_MAX_ADDR_BOOK_ENTRIES_PER_LINE	    5
/*! \brief Max number of Call Block entries*/
#define IFX_VMAPI_MAX_CALL_BLK_ENTRIES		IFX_MAX_CALLBLOCK_LIST
/*! \brief Max length of the Number plan Prefix */
#define IFX_VMAPI_NUM_PLAN_MAX_PREFIX_LEN	IFX_PLAN_MAX_PREFIX_LEN
/*! \brief Max Numbers of Device  */
#define IFX_VMAPI_MAX_DEVICE     	         7
/*! \brief Max length of the Device String */
#define IFX_VMAPI_MAX_DEV_STR_LEN	         32
#ifdef MESSAGE_SUPPORT
/*! \brief Max size of the Message Body */
#define IFX_VMAPI_MAX_MSG_LEN             160
/*! \brief Max Number of Message Inbox Entries */
#define IFX_VMAPI_MAX_MSG_IN_ENTRIES       20
/*! \brief Max Number of Message Outbox Entries */
#define IFX_VMAPI_MAX_MSG_OUT_ENTRIES      20
#endif 


/*! \brief Max number of Voice Profiles */
#define IFX_VMAPI_MAX_VOICE_PROFILES			IFX_MAX_PROFILES
/*! \brief Min number of Voice Profiles */
#define IFX_VMAPI_MIN_VOICE_PROFILES      1
/*! \brief Max number of Voice Lines */
#define IFX_VMAPI_MAX_VOICE_LINES				  3
/*! \brief Min number of Voice Lines */
#define IFX_VMAPI_MIN_VOICE_LINES				  1
/*! \brief Max number of Voice Lines associated to any Voice Profile */
#define IFX_VMAPI_MAX_VOICE_LINES_PER_PROFILE   5

/*! \brief PSTN Line */
#define IFX_VMAPI_PSTN_LINE              (IFX_VMAPI_MAX_VOICE_LINES + 1)
/*! \brief Common Contacts */
#define IFX_VMAPI_COMMON_CONTACT         (IFX_VMAPI_PSTN_LINE + 1) 

#ifdef LOW_END_IAD
/*! \brief Max number of FXS EndPoints */
#define IFX_VMAPI_MAX_FXS_ENDPTS                 1
/*! \brief Max number of FXO EndPoints */
#define IFX_VMAPI_MAX_FXO_ENDPTS                 0
#else
/*! \brief Max number of FXS EndPoints */
#define IFX_VMAPI_MAX_FXS_ENDPTS                 2
/*! \brief Max number of FXO EndPoints */
#define IFX_VMAPI_MAX_FXO_ENDPTS                 1

#endif
/*! \brief Max number of DECT EndPoints */
#define IFX_VMAPI_MAX_DECT_ENDPTS                6
/*! \brief Max number of Physical Endpoints */
#define IFX_VMAPI_MAX_PHY_ENDPTS			    (IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS +IFX_VMAPI_MAX_DECT_ENDPTS)
/*! \brief Max number of Voice Sessions */
#define IFX_VMAPI_VP_MAX_SESSIONS				IFX_VP_MAX_SESSIONS
/*! \brief Max number of Sessions for any Voice Line*/
#define IFX_VMAPI_MAX_SESSIONS_PER_LINE		    IFX_MAX_SESSIONS_PER_LINE
/*! \brief max number of Subscriber elements*/
#define IFX_VMAPI_MAX_SUBSCR_ELMNTS				IFX_MAX_SUBSCR_ELMNTS
/*! \brief Max number of Response Map elements */
#define IFX_VMAPI_MAX_RSPMAP_ELMNTS				IFX_MAX_RSPMAP_ELMNTS
/*! \brief Max number of Tones*/
#define IFX_VMAPI_MAX_TONES						IFX_MAX_TONES
/*! \brief Max number of Rings*/
#define IFX_VMAPI_MAX_RINGS						IFX_MAX_RINGS
/*! \brief Max number of Master keys */
#define IFX_VMAPI_MAX_MASTER_KEYS				IFX_MAX_MASTER_KEYS
/*! \brief Max number of SIP Authorization Info*/
#define IFX_VMAPI_MAX_AUTH_INFO					  5
/*! \brief max number of Number Plan Rules*/
#define IFX_VMAPI_MAX_NUM_PLAN_RULES			50
/*! \brief max number of Number Plan Rules*/
#define IFX_VMAPI_MAX_NUM_PLAN_RULE_LEN		40	
/*! \brief Max number of Associated Voice Interfaces for any VoiceLine */
#define IFX_VMAPI_MAX_VOICE_INTERFACES (IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS + IFX_VMAPI_MAX_DECT_ENDPTS)
/*! \brief Max number of Call register entries */
#define IFX_VMAPI_MAX_CALL_REG_ENTRIES			15
/*! \brief Max number of Call register entries per line*/
#define IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE			5
/*! \brief Gives the upper limit on the number of codecs */
#define IFX_VMAPI_MAX_CODECS							17
/*! \brief Maximum length of a codec name */ 
#define IFX_VMAPI_MAX_CODEC_NAME_LEN			32
/*! \brief Max number of Call register entries */
#define IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES                  15
/*! \brief Max number of Call register entries per line*/
#define IFX_VMAPI_MAX_MISSCALL_REG_ENTRIES_PER_LINE                 5
/*! \brief Max number of Call register entries */
#define IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES                  15
/*! \brief Max number of Call register entries per line*/
#define IFX_VMAPI_MAX_DIALCALL_REG_ENTRIES_PER_LINE                 5
/*! \brief Max number of Call register entries */
#define IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES                  15
/*! \brief Max number of Call register entries per line*/
#define IFX_VMAPI_MAX_RECVCALL_REG_ENTRIES_PER_LINE                 5
/*! \brief Max number of Associated Interfaces for PSTN Line */
#define IFX_VMAPI_MAX_FXO_INTERFACES 	8
/*! \brief Max number of Contact List entries */
#define IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES      15 
/*! \brief Max number of Contact List entries per line*/
#define IFX_VMAPI_MAX_CONTACT_LIST_ENTRIES_PER_LINE     10
#define IFX_VMAPI_MAX_COMMON_CONTACT_LIST_ENTRIES 10
/*! \brief Max number of PSTN Lines */
#define IFX_VMAPI_MAX_PSTN_LINES				  1
/*! \brief Auto detection through DNS */
#define IFX_VMAPI_SIG_TRANSPORT_AUTO	0 
/*! \brief UDP protocol*/
#define IFX_VMAPI_SIG_TRANSPORT_UDP		1
/*! \brief TCP protocol*/
#define IFX_VMAPI_SIG_TRANSPORT_TCP		2
/*! \brief TLS protocol*/
#define IFX_VMAPI_SIG_TRANSPORT_TLS		3
/*! \brief SCTP protocol*/
#define IFX_VMAPI_SIG_TRANSPORT_SCTP	4


/*! \brief Open */
#define IFX_VMAPI_NAT_TYPE_OPEN			0x00
/*! \brief Full Cone */
#define IFX_VMAPI_NAT_TYPE_FULL			0x01
/*! \brief Restricted Address */
#define IFX_VMAPI_NAT_TYPE_RESTRICT 	0x02
/*! \brief Port Restricted */
#define IFX_VMAPI_NAT_TYPE_PORTREST 	0x03
/*! \brief Symmetric */
#define IFX_VMAPI_NAT_TYPE_SYMM 		0x04
/*! \brief Firewall */
#define IFX_VMAPI_NAT_TYPE_FIREWALL 	0x05
/*! \brief Block */
#define IFX_VMAPI_NAT_TYPE_BLOCK 		0x06
/*! \brief Unknown */
#define IFX_VMAPI_NAT_TYPE_UNKNOWN 		0x07
/*! \brief Hairpin */
#define IFX_VMAPI_NAT_TYPE_HAIRPIN 		0x08
/*! \brief No NAT */
#define IFX_VMAPI_NAT_TYPE_NONAT 		0xFF


/*! \brief None*/
#define IFX_VMAPI_AUTH_METHOD_NONE		0
/*! \brief Digest */
#define IFX_VMAPI_AUTH_METHOD_DIGEST	1



/*! \brief Forwarding Mode */
#define IFX_VMAPI_FW_MODE		0
/*! \brief Gateway Mode */
#define IFX_VMAPI_GW_MODE		1



/*! \brief Event */
#define IFX_VMAPI_EVENT

/*! \brief Busy Tone */
#define IFX_VMAPI_TONE_BUSY				0x00000001
/*! \brief Confirmation Tone */
#define IFX_VMAPI_TONE_CONFIRM			0x00000002
/*! \brief Dial Tone */
#define IFX_VMAPI_TONE_DIAL_1				0x00000004
/*! \brief Message Waiting / Stutter Dial*/
#define IFX_VMAPI_TONE_MSG_WAIT			0x00000008 
/*! \brief OffHookWarning Tone */
#define IFX_VMAPI_TONE_OFF_HOOK_WARN	0x00000010
/*! \brief Ring Back Tone */
#define IFX_VMAPI_TONE_RING_BACK			0x00000020
/*! \brief ReOrder Tone */
#define IFX_VMAPI_TONE_REORDER			0x00000040
/*! \brief CallWaiting1 Tone*/
#define IFX_VMAPI_TONE_CALL_WAIT_1		0x00000080
/*! \brief CallWaiting2 Tone*/
#define IFX_VMAPI_TONE_CALL_WAIT_2		0x00000100
/*! \brief CallWaiting3 Tone*/
#define IFX_VMAPI_TONE_CALL_WAIT_3		0x00000200
/*! \brief CallWaiting4 Tone*/
#define IFX_VMAPI_TONE_CALL_WAIT_4		0x00000400
/*! \brief Alerting Signal Tone */
#define IFX_VMAPI_TONE_ALERT				0x00000800
/*! \brief SpecialDial Tone*/
#define IFX_VMAPI_TONE_SPL_DIAL			0x00001000
/*! \brief SpecialInfo Tone */
#define IFX_VMAPI_TONE_SPL_INFO			0x00002000
/*! \brief Release Tone */
#define IFX_VMAPI_TONE_RELEASE			0x00004000
/*! \brief Congestion Tone */
#define IFX_VMAPI_TONE_CONGEST			0x00008000
/*! \brief Prompt Tone */
#define IFX_VMAPI_TONE_PROMPT				0x00010000
/*! \brief Error Tone */
#define IFX_VMAPI_TONE_ERROR				0x00020000
/*! \brief Second Dial Tone*/
#define IFX_VMAPI_TONE_DIAL_2				0x00040000
/*! \brief UserDefined1 Tone*/
#define IFX_VMAPI_TONE_USR_DEF_1			0x00080000
/*! \brief UserDefined2 Tone*/
#define IFX_VMAPI_TONE_USR_DEF_2			0x00100000
/*! \brief UserDefined3 Tone*/
#define IFX_VMAPI_TONE_USR_DEF_3			0x00200000
/*! \brief UserDefined4 Tone*/
#define IFX_VMAPI_TONE_USR_DEF_4			0x00400000

/*! \brief Busy */
#define IFX_VMAPI_TONE_NAME_BUSY					"Busy"
/*! \brief Confirmation */
#define IFX_VMAPI_TONE_NAME_CONFIRM				"Confirmation"
/*! \brief Dial */
#define IFX_VMAPI_TONE_NAME_DIAL_1				"Dial"
/*! \brief MessageWaiting */
#define IFX_VMAPI_TONE_NAME_MSG_WAIT			"MessageWaiting" 
/*! \brief OffHookWarning */
#define IFX_VMAPI_TONE_NAME_OFF_HOOK_WARN		"OffHookWarning"
/*! \brief RingBack */
#define IFX_VMAPI_TONE_NAME_RING_BACK			"RingBack"
/*! \brief ReOrder */
#define IFX_VMAPI_TONE_NAME_REORDER				"ReOrder"
/*! \brief Callwaiting1 */
#define IFX_VMAPI_TONE_NAME_CALL_WAIT_1		"CallWaiting1"
/*! \brief Callwaiting2 */
#define IFX_VMAPI_TONE_NAME_CALL_WAIT_2		"CallWaiting2"
/*! \brief Callwaiting3 */
#define IFX_VMAPI_TONE_NAME_CALL_WAIT_3		"CallWaiting3"
/*! \brief Callwaiting4 */
#define IFX_VMAPI_TONE_NAME_CALL_WAIT_4		"CallWaiting4"
/*! \brief AlertingSignal */
#define IFX_VMAPI_TONE_NAME_ALERT				"AlertingSignal"
/*! \brief SpecialDial */
#define IFX_VMAPI_TONE_NAME_SPL_DIAL			"SpecialDial"
/*! \brief SpecialInfo */
#define IFX_VMAPI_TONE_NAME_SPL_INFO			"SpecialInfo"
/*! \brief Release */
#define IFX_VMAPI_TONE_NAME_RELEASE				"Release"
/*! \brief Congestion */
#define IFX_VMAPI_TONE_NAME_CONGEST				"Congestion"
/*! \brief Prompt */
#define IFX_VMAPI_TONE_NAME_PROMPT				"Prompt"
/*! \brief Error */
#define IFX_VMAPI_TONE_NAME_ERROR				"Error"
/*! \brief SecondDial */
#define IFX_VMAPI_TONE_NAME_DIAL_2				"SecondDial"
/*! \brief Beep */
#define IFX_VMAPI_TONE_NAME_BEEP					"Beep"
/*! \brief UserDefined1 */
#define IFX_VMAPI_TONE_NAME_USR_DEF_1			"UserDefined1"
/*! \brief UserDefined2 */
#define IFX_VMAPI_TONE_NAME_USR_DEF_2			"UserDefined2"
/*! \brief UserDefined3 */
#define IFX_VMAPI_TONE_NAME_USR_DEF_3			"UserDefined3"
/*! \brief UserDefined4 */
#define IFX_VMAPI_TONE_NAME_USR_DEF_4			"UserDefined4"


/*! \brief T38 version*/
#define IFX_VMAPI_T38_VERSION						1

/*! \brief Local TCF method */
#define IFX_VMAPI_FAX_RATE_MGMT_TCF_LCL		0x01
/*! \brief Transferred/Network TCF method */
#define IFX_VMAPI_FAX_RATE_MGMT_TCF_TRANS	0x02

/* Transferred equivalent to Network (TR-104) */


/*! \brief Fill Bit Removal */
#define IFX_VMAPI_FAX_OPT_FBL					0x0001
/*! \brief MMR Transcoding */
#define IFX_VMAPI_FAX_OPT_TRANS_MMR			0x0002
/*! \brief JBIG Transcoding */
#define IFX_VMAPI_FAX_OPT_TRANS_JBIG		0x0004


/*! \brief Redundancy Method*/
#define IFX_VMAPI_FAX_EC_REDUNDANCY			    0x01
/*! \brief FEC(Forward Error Correction) Method */
#define IFX_VMAPI_FAX_EC_FEC					0x02


/*! \brief NSX Info size */
#define IFX_VMAPI_FAX_MAX_NSX_SIZE				40


/*! \brief UDP connection*/
#define IFX_VMAPI_FAX_CONN_UDP					1
/*! \brief TCP connection */
#define IFX_VMAPI_FAX_CONN_TCP					2
/*! \brief UDP and TCP both but UDP is preferred */
#define IFX_VMAPI_FAX_CONN_UDP_TCP				3
/*! \brief UDP and TCP both but TCP is preferred */
#define IFX_VMAPI_FAX_CONN_TCP_UDP				4
/*! \brief Dynamic */
#define IFX_VMAPI_FAX_CONN_DYN					5

/*! \brief 33600 */
#define IFX_VMAPI_FAX_BIT_RATE_33600			33600
/*! \brief 14400 */
#define IFX_VMAPI_FAX_BIT_RATE_14400			14400
/*! \brief 12000 */
#define IFX_VMAPI_FAX_BIT_RATE_12000			12000
/*! \brief 9600 */
#define IFX_VMAPI_FAX_BIT_RATE_9600				9600
/*! \brief 7200 */
#define IFX_VMAPI_FAX_BIT_RATE_7200				7200
/*! \brief 4800 */
#define IFX_VMAPI_FAX_BIT_RATE_4800				4800
/*! \brief 2400 */	
#define IFX_VMAPI_FAX_BIT_RATE_2400				2400	

/*! \brief Min number of Digits for Numbering Plan */
#define IFX_VMAPI_NUM_PLAN_MIN_DIGITS			IFX_NUM_PLAN_MIN
/*! \brief Max number of Digits for Numbering Plan */
#define IFX_VMAPI_NUM_PLAN_MAX_DIGITS			IFX_NUM_PLAN_MAX
/*! \brief Min number of Prefix Digits for Numbering Plan */
#define IFX_VMAPI_NUM_PLAN_MAX_PREFIX_DIGITS	IFX_NUM_PLAN_MAX_PREFIX

/*! \brief Speed Dial */
#define IFX_VMAPI_NP_MAIN_ACT_SPEED_DIAL		0x00000001
/*! \brief Annonymous Call */
#define IFX_VMAPI_NP_MAIN_ACT_ANONY_CALL		0x00000002
/*! \brief Call Completion on No Reply - Automatic Redial on No Reply */
#define IFX_VMAPI_NP_MAIN_ACT_CCNR				0x00000004
/*! \brief Call Completion to Busy Subscriber - Automatic Callback on Busy destination */
#define IFX_VMAPI_NP_MAIN_ACT_CCBS				0x00000008
/*! \brief Call Forwarding on Busy is activated */
#define IFX_VMAPI_NP_MAIN_ACT_CFB				0x00000010
/*! \brief Call Forwarding on No Answer is activated */
#define IFX_VMAPI_NP_MAIN_ACT_CFNA				0x00000020
/*! \brief Call Forwarding on No Answer Timer is activated */
#define IFX_VMAPI_NP_MAIN_ACT_CFNA_TIMER		0x00000040
/*! \brief Activate Call Forwarding Timed */
#define IFX_VMAPI_NP_MAIN_ACT_CFT				0x00000080
/*! \brief Activate Call Forwarding Unconditional */
#define IFX_VMAPI_NP_MAIN_ACT_CFU				0x00000100
/*! \brief Activate Calling Line Activation Restriction */
#define IFX_VMAPI_NP_MAIN_ACT_CLIR				0x00000200
/*! \brief Activate Call Waiting */
#define IFX_VMAPI_NP_MAIN_ACT_CW					0x00000400
/*! \brief Toggling enabled */
#define IFX_VMAPI_NP_MAIN_ACT_CALL_TOGGLE		0x00000800
/*! \brief Activate Outgoing Call Barring */
#define IFX_VMAPI_NP_MAIN_ACT_OCB				0x00001000
/*! \brief Route the call to a PSTN FXO line */
#define IFX_VMAPI_NP_MAIN_ACT_ROUTE_2_PSTN	0x00002000
/*! \brief set Password */
#define IFX_VMAPI_NP_MAIN_ACT_SET_PASSWD		0x00004000
/*! \brief Select Call Forward */
#define IFX_VMAPI_NP_MAIN_ACT_SEL_CALL_FWD	0x00008000
/*! \brief Activate Selective Call Rejection*/
#define IFX_VMAPI_NP_MAIN_ACT_SCL_CALL_REJ	0x00010000
/*! \brief Activate selective Ringing */
#define IFX_VMAPI_NP_MAIN_ACT_SEL_RING			0x00020000
/*! \brief Send the dial number as a TelUri*/
#define IFX_VMAPI_NP_MAIN_ACT_TEL_URI			0x00040000

/*! \brief Addition */
#define IFX_VMAPI_NP_SUB_ACT_ADD					0x0001
/*! \brief deletion */
#define IFX_VMAPI_NP_SUB_ACT_DELETE				0x0002
/*! \brief Enabling */
#define IFX_VMAPI_NP_SUB_ACT_ENABLE				0x0004
/*! \brief Disabling */
#define IFX_VMAPI_NP_SUB_ACT_DISABLE			0x0008
/*! \brief Querying */
#define IFX_VMAPI_NP_SUB_ACT_QUERY				0x0010

/*! \brief Line Is Disabled. */
#define IFX_VMAPI_VL_STATUS_DISABLED      0
/*! \brief This Indicates That Line Is In Process Of Initialization */
#define IFX_VMAPI_VL_STATUS_INITIALISING  1
/*! \brief Line Is Trying To Register With REGISTRAR */
#define IFX_VMAPI_VL_STATUS_REGISTERING   2
/*! \brief Line Is Unregistering Previous Registration With REGISTRAR */
#define IFX_VMAPI_VL_STATUS_UNREGISTERING 3
/*! \brief Line Is In Bad State.  */
#define IFX_VMAPI_VL_STATUS_ERROR         4
/*! \brief This Status Inidicates Line Is In Process Of Testing */
#define IFX_VMAPI_VL_STATUS_TESTING       5
/*! \brief Line Is In Quiescent State*/
#define IFX_VMAPI_VL_STATUS_QUIESCENT     6
/*! \brief Line Is Up And Running */
#define IFX_VMAPI_VL_STATUS_UP            7

/*! \brief Line Is In Idle State. */
#define IFX_VMAPI_CALL_STATUS_IDLE           0
/*! \brief A Call Is Being Initiated By Line */
#define IFX_VMAPI_CALL_STATUS_CALLING        1
/*! \brief Line Is Ringing. That Is Line Has An Incoming Call */
#define IFX_VMAPI_CALL_STATUS_RINGING        2
/*! \brief Establishing Call. */
#define IFX_VMAPI_CALL_STATUS_CONNECTING     3
/*! \brief Line Is In Call. */
#define IFX_VMAPI_CALL_STATUS_INCALL         4
/*! \brief Call Is In Hold State. */
#define IFX_VMAPI_CALL_STATUS_HOLD           5
/*! \brief Disconnecting A Call */
#define IFX_VMAPI_CALL_STATUS_DISCONNECTING  6
/*! \brief Second Call Is Initiated By Line. */
#define IFX_VMAPI_CALL_STATUS_SEC_CALLING    7
/*! \brief Establising Second Call. */
#define IFX_VMAPI_CALL_STATUS_SEC_CONNECTING 8
/*! \brief Second Call Is Connected. */
#define IFX_VMAPI_CALL_STATUS_SEC_CONNECTED  9
/*! \brief Line Is In Conference. */
#define IFX_VMAPI_CALL_STATUS_IN_CONF        10
/*! \brief Call State Of The Line Is Disabled. */
#define IFX_VMAPI_CALL_STATUS_DISABLED       11 

#ifdef IIP

/*! \brief Room Is Normal. */
#define IFX_VMAPI_ROOM_TYPE_NORMAL      0
/*! \brief Room Is Noisy */
#define IFX_VMAPI_ROOM_TYPE_NOISY       1
/*! \brief Room Generates Echo */
#define IFX_VMAPI_ROOM_TYPE_ECHOIC      2

/*! \brief Volume Level Zero */
#define IFX_VMAPI_VOLUME_LEVEL_0        0
/*! \brief Volume Level One */
#define IFX_VMAPI_VOLUME_LEVEL_1        1
/*! \brief Volume Level Two */
#define IFX_VMAPI_VOLUME_LEVEL_2        2
/*! \brief Volume Level Three */
#define IFX_VMAPI_VOLUME_LEVEL_3        3
/*! \brief Volume Level Four */
#define IFX_VMAPI_VOLUME_LEVEL_4        4
/*! \brief Volume Level Five */
#define IFX_VMAPI_VOLUME_LEVEL_5        5
/*! \brief Volume Level Six */
#define IFX_VMAPI_VOLUME_LEVEL_6        6
/*! \brief Volume Level Seven */
#define IFX_VMAPI_VOLUME_LEVEL_7        7
/*! \brief Volume Level Eight */
#define IFX_VMAPI_VOLUME_LEVEL_8        8
#endif /*! IIP */

/*! \brief Message Waiting Subscription Event */
#define IFX_VMAPI_VL_SUBS_EVENT_MWI       1
/*! \brief Dialog Event Subscription */
#define IFX_VMAPI_VL_SUBS_EVENT_DIALOG    2

/*! \brief No Subscription. Or Subscription Is In Idle State */
#define IFX_VMAPI_VL_SUBS_STATE_IDLE        1
/*! \brief Trying To Subscribe */
#define IFX_VMAPI_VL_SUBS_STATE_SUBSCRIBING 2
/*! \brief Subscribed To An Event */
#define IFX_VMAPI_VL_SUBS_STATE_SUBSCRIBED  3
/*! \brief Subscription Is Pending */
#define IFX_VMAPI_VL_SUBS_STATE_PENDING     4
/*! \brief Subscription Is Active */
#define IFX_VMAPI_VL_SUBS_STATE_ACTIVE      5
/*! \brief Subscription Timed Out */
#define IFX_VMAPI_VL_SUBS_STATE_TIMEOUT     6
/*! \brief Subscription Is Terminated */
#define IFX_VMAPI_VL_SUBS_STATE_TERMINATED  7
/*! \brief Subscription Is Failed Due To Authentication Failure*/
#define IFX_VMAPI_VL_SUBS_STATE_UNAUTH      8


/*! \brief Normal Ring Tone */
#define IFX_VMAPI_RING_NORMAL             0x0001
/*! \brief Ring Tone One */
#define IFX_VMAPI_RING_DISTINCTIVE_1      0x0002
/*! \brief Ring Tone Two */
#define IFX_VMAPI_RING_DISTINCTIVE_2      0x0004
/*! \brief Ring Tone Three */
#define IFX_VMAPI_RING_DISTINCTIVE_3      0x0008
/*! \brief Ring Tone Four */
#define IFX_VMAPI_RING_DISTINCTIVE_4      0x0010
/*! \brief Ring Tone Five */
#define IFX_VMAPI_RING_DISTINCTIVE_5      0x0020


/*! \brief Address Type Is IP Address. */
#define IFX_VMAPI_ADDR_TYPE_IP_ADDR       1
/*! \brief Address Type Is Telepone URL. */
#define IFX_VMAPI_ADDR_TYPE_TEL_NUM       2
/*! \brief Address Type Is SIP URL. */
#define IFX_VMAPI_ADDR_TYPE_SIP_URL       3
/*! \brief Address Type Is Extension Number. */
#define IFX_VMAPI_ADDR_TYPE_EXTN          4


/*! \brief Reset Call Call Registers */
#define IFX_VMAPI_CALL_REG_RESET_ALL      1
/*! \brief Reset Dialed Call Register Only. */
#define IFX_VMAPI_CALL_REG_RESET_DIAL     2
/*! \brief Reset Received Call Register Only. */
#define IFX_VMAPI_CALL_REG_RESET_RECV     3
/*! \brief Reset Missed Call Register Only. */
#define IFX_VMAPI_CALL_REG_RESET_MISS     4


/*! \brief Forward All Calls Unconditional. */
#define IFX_VMAPI_CALL_FWD_UNCONDITIONAL    0x01
/*! \brief Forward Calls Only If Phone Is Busy. */
#define IFX_VMAPI_CALL_FWD_BUSY             0x02
/*! \brief Forward Calls If Not Answered. */
#define IFX_VMAPI_CALL_FWD_ON_NO_ANSWER     0x04
/*! \brief Forward All Calls When DND Is Set. */
#define IFX_VMAPI_CALL_FWD_DND              0x08
/*! \brief Forward Calls To Voice Mail. */
#define IFX_VMAPI_CALL_FWD_VOICE_MAIL       0x10



/*! 
    \brief Enumeration describing the Object Ids to be used for registering for Notification
*/
typedef enum
{
 	IFX_VMAPI_VOICE_SERVICE=0, /*!< Voice Service */
	IFX_VMAPI_CODEC_CAPABS, /*!< Voice Codec Capabilities */
	IFX_VMAPI_VOICE_CAPABS, /*!< Voice Capabilities */
	IFX_VMAPI_SIP_CAPABS, /*!< Voice Sip Capabilities */
	IFX_VMAPI_PHY_IFACE, /*!< Physical Interface */
	IFX_VMAPI_PHY_IFACE_FXS, /*!< FXS Physical Interface */
	IFX_VMAPI_PHY_IFACE_FXO, /*!< FXO Physical Interface */
	IFX_VMAPI_PHY_IFACE_DECT, /*!< DECT Physical Interface */
	IFX_VMAPI_VS_CALL_BLOCK, /*!< Call Block */
	IFX_VMAPI_VS_CALL_BLOCK_ENTRY, /*!< Call Block Entry*/
	IFX_VMAPI_VS_DIALCALL_REGISTER=10, /*!< Dial Call Register */
	IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY, /*!< Dial Call Register Entry*/
	IFX_VMAPI_VS_MISSCALL_REGISTER, /*!< Missed Call Register */
	IFX_VMAPI_VS_MISSCALL_REGISTER_ENTRY, /*!< Missed Call Register Entry*/
	IFX_VMAPI_VS_RECVCALL_REGISTER, /*!< Received Call Register */
	IFX_VMAPI_VS_RECVCALL_REGISTER_ENTRY, /*!< Received Call Register Entry*/
	IFX_VMAPI_VS_ADDRESS_BOOK, /*!< AddressBook */
	IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY, /*!< AddressBook Entry*/
	IFX_VMAPI_VS_DEBUG_SET, /*!< Debug Settings*/
	IFX_VMAPI_VS_NUM_PLAN, /*!< Numbering Plan */
	IFX_VMAPI_VS_NUM_PLAN_RULES=20, /*!< Numbering Plan Rules*/
	IFX_VMAPI_VS_TONE_INFO, /*!< Tone Info */
	IFX_VMAPI_VS_T38, /*!< T38 */
	IFX_VMAPI_VS_MISC, /*!< Miscellaneous */
	IFX_VMAPI_VS_VER, /*!< Version */
	IFX_VMAPI_VOICE_PROFILE, /*!< Voice Profile */
	IFX_VMAPI_ADD_PROFILE, /*!< Add Profile */
	IFX_VMAPI_DELETE_PROFILE, /*!< Delete Profile */
	IFX_VMAPI_VP_SER_PROVIDER, /*!< Service Provider */
	IFX_VMAPI_VP_SIGNALING, /*!< Voice Profile Signaling */
	IFX_VMAPI_VP_EVENT_SUBSCR=30, /*!< Event-Subscription */
	IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY, /*!< Event-Subscription Entry*/
	IFX_VMAPI_VP_RTP, 	/*!< Media RTP */
	IFX_VMAPI_VP_RTCP,  /*!< Media RTCP */
	IFX_VMAPI_VP_FAX,  /*!< Fax */
	IFX_VMAPI_VOICE_LINE, /*!< Voice Line */
	IFX_VMAPI_ADD_LINE, /*!< Add Line */
	IFX_VMAPI_DELETE_LINE, /*!< Delete Line */
	IFX_VMAPI_VL_SIGNALING, /*!< Voice Line Signaling */
	IFX_VMAPI_VL_AUTHCFG, /*!< Auth Config */
	IFX_VMAPI_VL_VOICE_CODEC=40,  /*!< Voice Line Codec */
	IFX_VMAPI_VL_CODECLIST, /*!< Voice Line Codec List */
	IFX_VMAPI_VL_CODECLIST_ENTRY, /*!< Voice Line Codec Description */
	IFX_VMAPI_VL_CALLFEAT,  /*!< Voice Line CallingFeatures */
	IFX_VMAPI_VL_VOICE_SESSION,  /*!< Voice Line Session */
	IFX_VMAPI_VL_VOICE_PROCESSING,  /*!< Voice Line VoiceProcessing */	
	IFX_VMAPI_VL_EVENT_SUBSCR,  /*!< Voice Line Subscription */	
	IFX_VMAPI_VL_EVENT_SUBSCR_ENTRY,  /*!< Voice Line Subscription Event */	
	IFX_VMAPI_VL_STATS,	/*!< Voice Line Statistics */	
	IFX_VMAPI_PHY_INT_TEST, /*!< Physical Interface Test */
	IFX_VMAPI_VS_CONTACT_LIST, /*!< Contact List */              
	IFX_VMAPI_VS_CONTACT_LIST_ENTRY, /*!< Contact List Entry */      
	IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER, /*!< Missed Call Register */
	IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER_ENTRY, /*!< Missed Call Register Entry*/
	IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER, /*!< Missed Call Register */
	IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER_ENTRY, /*!< Missed Call Register Entry*/
	IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER, /*!< Missed Call Register */
	IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER_ENTRY, /*!< Missed Call Register Entry*/
	IFX_VMAPI_VS_PSTN_CONTACT_LIST, /*!< PSTN Contact List */              
	IFX_VMAPI_VS_PSTN_CONTACT_LIST_ENTRY, /*!< PSTN Contact List Entry */      
	IFX_VMAPI_VS_COMMON_CONTACT_LIST, /*!< Common Contact List */              
	IFX_VMAPI_VS_COMMON_CONTACT_LIST_ENTRY, /*!< Common Contact List Entry */      
//#ifdef DECT_SUPPORT	
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	IFX_VMAPI_TBR6_TEST, /*!< TBR6 Test */
	IFX_VMAPI_DECT_SYSTEM, /*!< Dect System */
	IFX_VMAPI_DECT_DIAGNOSTICS, /*!< Dect Diagnostics */
	IFX_VMAPI_TRANS_POWER_TEST, /*!< Transmit Power Measurement Test */
	IFX_VMAPI_RF_MODE_TEST, /*!< RF Mode Test */
  IFX_VMAPI_RFPI_TEST, /*!< RFPI */
  IFX_VMAPI_XRAM_TEST, /*!< XRAM */
	IFX_VMAPI_COUNTRY_SETTINGS_TEST, /*!< DECT Country */
	IFX_VMAPI_BMC_REG_PARAMS_TEST, /*!< DECT BMC */
	IFX_VMAPI_OSC_TRIM_TEST, /*!< DECT Oscillator Trimming */
	IFX_VMAPI_GFSK_TEST, /*!< DECT GFSK */
#endif
#ifdef CVOIP_SUPPORT
	IFX_VMAPI_TBR6_REQUEST, /*!< TBR6 Test */
	IFX_VMAPI_DECT_SYSTEM_REQUEST, /*!< Dect System */
	IFX_VMAPI_DECT_DIAGNOSTICS_REQUEST, /*!< Dect Diagnostics */
	IFX_VMAPI_TRANS_POWER_REQUEST, /*!< Transmit Power Measurement Test */
	IFX_VMAPI_RF_MODE_REQUEST, /*!< RF Mode Test */
  IFX_VMAPI_RFPI_REQUEST, /*!< RFPI */
  IFX_VMAPI_XRAM_REQUEST, /*!< XRAM */
	IFX_VMAPI_XRAM_SFR_REQUEST, /*< XRAM SFR */
	IFX_VMAPI_COUNTRY_SETTINGS_REQUEST, /*!< DECT Country */
	IFX_VMAPI_BMC_REG_PARAMS_REQUEST, /*!< DECT BMC */
	IFX_VMAPI_OSC_TRIM_REQUEST, /*!< DECT Oscillator Trimming */
	IFX_VMAPI_GFSK_REQUEST, /*!< DECT GFSK */
	IFX_VMAPI_CVOIP_SYSTEM_CAPABALITIES,/*!<CVOIP SYSTEM_CAPABALITIES*/
#endif
#ifdef DECT_SENSORS_SUPPORT
IFX_VMAPI_VS_MOTION_SENSOR_LIST, /*!< Motion sensor List */
IFX_VMAPI_VS_MOTION_SENSOR_ENTRY, /*!< Motion sensor List Entry */

IFX_VMAPI_VS_SMOKE_SENSOR_LIST, /*!< Somke Sensor List  */
IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY, /*!< Smoke sensor List Entry */


IFX_VMAPI_VS_POWER_SENSOR_LIST, /*!< Power sensor List  */
IFX_VMAPI_VS_POWER_SENSOR_ENTRY, /*!< Power sensor List Entry */

IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST, /*!< Smoke sensor Alaram List  */
IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY, /*!< Smoke sensor Alaram List Entry */

IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST, /*!<  Motion sensor Alaram List  */
IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY, /*!< Motion sensor Alaram List Entry */

IFX_VMAPI_VS_POWER_SENSOR_READ_LIST, /*!<  Power sensor read List  */
IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY, /*!< Power sensor read List Entry */
#endif
#ifdef MESSAGE_SUPPORT
	IFX_VMAPI_MSG_INBOX,   /*!< Message Inbox */
	IFX_VMAPI_MSG_INBOX_ENTRY, /*!< Message Inbox Entry */
	IFX_VMAPI_MSG_OUTBOX,   /*!< Message Outbox */
	IFX_VMAPI_MSG_OUTBOX_ENTRY, /*!< Message Outbox Entry */
#endif
	IFX_VMAPI_MAX_OBJ /*!< Max Objects */  
} e_IFX_VMAPI_ObjectId;

#define IFX_DUMMY_TZ_CHANGE (IFX_VMAPI_MAX_OBJ+1)

/*! 
    \brief Enumeration describing Call Interface Types
*/
typedef enum
{
  IFX_VMAPI_PSTN_NUM=0, /*!< PSTN */
  IFX_VMAPI_VOIP_NUM=1, /*!< VOIP */
} e_IFX_VMAPI_CallTypes;

/*! 
    \brief Enumeration defining the Call Register Types
*/
typedef enum
{
  IFX_VMAPI_CALLREG_DIAL=0, /*!< Dialed Call */
  IFX_VMAPI_CALLREG_MISS=1, /*!< Missed Call */
  IFX_VMAPI_CALLREG_RECV=2, /*!< Received Call */
} e_IFX_VMAPI_RegCallTypes;

/*! 
    \brief Enumeration defining the Call Types
*/
typedef enum
{
  IFX_PSTN_NUM=0, /*!< PSTN Number */
  IFX_VOIP_NUM=1, /*!< VoIP Number */
  IFX_EXTN_NUM=2, /*!< EXTN Number */
  IFX_DIRECT_IPNUM=3, /*!< IP Address */
} e_IFX_CallTypes;

#ifdef MESSAGE_SUPPORT
/*! 
    \brief Enumeration defining the Message Box Types
*/
typedef enum {
	IFX_VMAPI_MSG_IN=1, /*!< Inbox */
	IFX_VMAPI_MSG_OUT=2, /*!< Outbox */
	IFX_VMAPI_MSG_MAX=3 /*!< Max Types */
}e_IFX_VAMPI_MsgBox;
#endif



/***********************************************************/

/***************Voice Service object***********/

/*! \brief Structure defining Voice Service object.
*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;

	/*! Current number of Voice Profiles in the Voice Service */ 
	uint16 uiNumProfiles;
	/*! Number of Physical Interfaces */ 
	uint16 uiPhyNumOfEntries;
	uchar8 ucProfileIdList[2*IFX_VMAPI_MAX_VOICE_PROFILES+1]; /*!< Profile id list */
	uchar8 ucLineIdList[2*IFX_VMAPI_MAX_VOICE_LINES+1]; /*!< Line id list */
	/*! List of available devices */
	char8 acDeviceList[IFX_VMAPI_MAX_DEVICE][IFX_VMAPI_MAX_DEV_STR_LEN];
	/*!< Associated Country */
	uint32 uiCountrySet; /*!< Takes one of IFX_VMAPI_COUNTRY_ values */
	/*! StartUp Flag*/
	uchar8 ucStartFlag;
}x_IFX_VMAPI_VoiceService;


/******************************************************************/
/******************Capabilities related Objects********************/

/*! \brief Structure defining the SIP protocol specific information supported. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;

/*! \brief Behavior of SIP */
#define IFX_VMAPI_SIP_ROLE							"UserAgent"
/*! \brief SIP Extensions supported */
#define IFX_VMAPI_SIP_EXTNS							"REFER,INFO"
/*! \brief Transport protocols supported */
#define IFX_VMAPI_SIP_TRANSPORT					"TCP,UDP"
/*! \brief SIP URI Scheme */
#define IFX_VMAPI_SIP_URI_SCHEME				"tel"
/*! \brief indication of Event-Subscription support */
#define IFX_VMAPI_SIP_EVENT_SUBSCRIBE		IFX_FALSE
/*! \brief Indication of Response map */
#define IFX_VMAPI_SIP_RESP_MAP					IFX_FALSE
/*! \brief Indication of Authentication Protocol used */
#define IFX_VMAPI_TLS_AUTH_PROTOCOL			IFX_NULL
/*! \brief Size of key used to generate Authentication response */
#define IFX_VMAPI_TLS_AUTH_KEY_SIZE			""
/*! \brief Encryption Protocol used */
#define IFX_VMAPI_TLS_ENCRYP_PROTOCOL		IFX_NULL
/*! \brief Encryption Key used */
#define IFX_VMAPI_TLS_ENCRYP_KEY_SIZE		""
/*! \brief TLS */
#define IFX_VMAPI_TLS_KEY_EXCNG_PROTOCL	IFX_NULL

}x_IFX_VMAPI_VoiceSipCapabilities;




/***********************************************************/
/******************Codec related Objects********************/

/*! \brief Structure that defines a codec. Array of such structures may be used to store the codec list associated with a line/profile.
*/
typedef struct {
/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId; /*!< Associated Voice Profile */
  uchar8 ucLineId;    /*!< Line Id */


	uint32 uiCodecId; /*!< Codec Id representing a codec */

	/*! \brief Codec Id IFX_VMAPI_CODEC_G711_ALAW */
#define IFX_VMAPI_CODEC_G711_ALAW     			0x00000001
	/*! \brief Codec Id IFX_VMAPI_CODEC_G711_ULAW */
#define IFX_VMAPI_CODEC_G711_ULAW     			0x00000002
	/*! \brief Codec Id IFX_VMAPI_CODEC_G729_8 */
#define IFX_VMAPI_CODEC_G729_8        			0x00000004
	/*! \brief Codec Id IFX_VMAPI_CODEC_G729_E */
#define IFX_VMAPI_CODEC_G729_E        			0x00000008
	/*! \brief Codec Id IFX_VMAPI_CODEC_G723 */
#define IFX_VMAPI_CODEC_G723          			0x00000010
	/*! \brief Codec Id IFX_VMAPI_CODEC_G723_5_3 */
#define IFX_VMAPI_CODEC_G723_5_3      			0x00000020
	/*! \brief Codec Id IFX_VMAPI_CODEC_G723_6_3 */
#define IFX_VMAPI_CODEC_G723_6_3      			0x00000040
	/*! \brief Codec Id IFX_VMAPI_CODEC_G728 */
#define IFX_VMAPI_CODEC_G728          			0x00000080
	/*! \brief Codec Id IFX_VMAPI_CODEC_LINEAR_256 */
#define IFX_VMAPI_CODEC_LINEAR_256    			0x00000100
	/*! \brief Codec Id IFX_VMAPI_CODEC_LINEAR_16 */
#define IFX_VMAPI_CODEC_LINEAR_16     			0x00000200
	/*! \brief Codec Id IFX_VMAPI_CODEC_LINEAR_8 */
#define IFX_VMAPI_CODEC_LINEAR_8      			0x00000400
	/*! \brief Codec Id IFX_VMAPI_CODEC_G726_16 */
#define IFX_VMAPI_CODEC_G726_16       			0x00000800
	/*! \brief Codec Id IFX_VMAPI_CODEC_G726_24 */
#define IFX_VMAPI_CODEC_G726_24       			0x00001000
	/*! \brief Codec Id IFX_VMAPI_CODEC_G726_32 */
#define IFX_VMAPI_CODEC_G726_32       			0x00002000
	/*! \brief Codec Id IFX_VMAPI_CODEC_G726_40 */
#define IFX_VMAPI_CODEC_G726_40       			0x00004000
	/*! \brief Codec Id IFX_VMAPI_CODEC_G722_64 */
#define IFX_VMAPI_CODEC_G722_64       			0x00008000
	/*! \brief Codec Id IFX_VMAPI_CODEC_T38 */
#define IFX_VMAPI_CODEC_G722_64_2           			0x00010000
	/*! \brief Codec Id IFX_VMAPI_CODEC_T38_UDP */
#define IFX_VMAPI_CODEC_ILBC       			0x00100000
	/*! \brief Codec Id IFX_VMAPI_CODEC_T38_TCP */
#define IFX_VMAPI_CODEC_T38       			0x00200000
	/*! \brief Codec Id IFX_VMAPI_CODEC_ILBC */
#define IFX_VMAPI_CODEC_T38_UDP  							0x00400000
	/*! \brief Codec Id IFX_VMAPI_CODEC_G722_64_2 */
#define IFX_VMAPI_CODEC_T38_TCP       		0x00800000

	char8 acCodecName[IFX_VMAPI_MAX_CODEC_NAME_LEN];	/*!< Name of codec */

	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G711_ALAW */
#define IFX_VMAPI_CODEC_NAME_G711_ALAW			"G.711ALaw"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G711_ULAW */
#define IFX_VMAPI_CODEC_NAME_G711_ULAW			"G.711ULaw"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G726 */
#define IFX_VMAPI_CODEC_NAME_G726				"G.726"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G729 */
#define IFX_VMAPI_CODEC_NAME_G729				"G.729"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G729a */
#define IFX_VMAPI_CODEC_NAME_G729a				"G.729a"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G729e */
#define IFX_VMAPI_CODEC_NAME_G729e				"G.729e"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G728 */
#define IFX_VMAPI_CODEC_NAME_G728				"G.728"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G723_1 */
#define IFX_VMAPI_CODEC_NAME_G723_1				"G.723.1"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G722 */
#define IFX_VMAPI_CODEC_NAME_G722				"G.722"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G722_1 */
#define IFX_VMAPI_CODEC_NAME_G722_1				"G.722.1"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G722_2 */
#define IFX_VMAPI_CODEC_NAME_G722_2				"G.722.2"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_ILBC */
#define IFX_VMAPI_CODEC_NAME_ILBC				"iLBC"
	/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_T38 */
#define IFX_VMAPI_CODEC_NAME_T38					"T.38"

	uint32 uiBitRate;	/*!< bit rate to be used for this codec description */
	uint16 unCodecSuppFrameLen; /*!< supported frame length */

	/*! \brief Codec Frame Length_5 */
#define IFX_VMAPI_CODEC_FRAME_LEN_5				0x0001
	/*! \brief Codec Frame Length 10 */
#define IFX_VMAPI_CODEC_FRAME_LEN_10			0x0002
	/*! \brief Codec Frame Length 20 */
#define IFX_VMAPI_CODEC_FRAME_LEN_20			0x0004
	/*! \brief Codec Frame Length 30 */
#define IFX_VMAPI_CODEC_FRAME_LEN_30			0x0008	
	/*! \brief Codec Frame Length 40 */
#define IFX_VMAPI_CODEC_FRAME_LEN_40		  0x0010	
	/*! \brief Codec Frame Length 50 */
#define IFX_VMAPI_CODEC_FRAME_LEN_50			0x0020	
	/*! \brief Codec Frame Length 60 */
#define IFX_VMAPI_CODEC_FRAME_LEN_60			0x0040

	bool bSilenceSupp; /*!< enabling silence suppression-IFX_TRUE or IFX_FALSE*/

	/*! \brief Dynamic Payload Type G711u */
#define IFX_VMAPI_PAYLOAD_TYPE_G711U      0
	/*! \brief Dynamic Payload Type G711a */
#define IFX_VMAPI_PAYLOAD_TYPE_G711A      8
	/*! \brief Dynamic Payload Type G722_64 */
#define IFX_VMAPI_PAYLOAD_TYPE_G722_64    9
	/*! \brief Dynamic Payload Type G723 */
#define IFX_VMAPI_PAYLOAD_TYPE_G723       4
	/*! \brief Dynamic Payload Type G729_8 */
#define IFX_VMAPI_PAYLOAD_TYPE_G729_8     18
	/*! \brief Dynamic Payload Type G726_16 */
#define IFX_VMAPI_PAYLOAD_TYPE_G726_16   	100 
	/*! \brief Dynamic Payload Type G726_24 */
#define IFX_VMAPI_PAYLOAD_TYPE_G726_24   	101
	/*! \brief Dynamic Payload Type G726_32 */
#define IFX_VMAPI_PAYLOAD_TYPE_G726_32    102
	/*! \brief Dynamic Payload Type G726_40 */
#define IFX_VMAPI_PAYLOAD_TYPE_G726_40    103
	/*! \brief Dynamic Payload Type for Tx DTMF Events */
#define IFX_VMAPI_PAYLOAD_TYPE_DTMF       96

	uchar8 ucPayloadType; /*!< payload type */
  uchar8 ucIndex; /*!< Index */
	bool bEnable; /*!< enabling codec-IFX_TRUE or IFX_FALSE*/
	uchar8 ucPriority; /*!< Codec Priority \n
											* 1 is the highest and priorities decrease as we 
											* 	continue in the ascending order \n
											* 0 Priority indicates that the codec is disabled */
}x_IFX_VMAPI_CodecDesc;

/*! \brief Structure defining the Voice Codec Capabilities object for the system.*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
  uint32 uiFwSuppCodec;/*!< Firmware Supported Codecs  */
	uint32 uiNumCodecs;	/*!< Number of codecs in Codec List */
	x_IFX_VMAPI_CodecDesc *pxCodecList;/*!< Codec Table */
//	x_IFX_VMAPI_CodecDesc axCodecList[IFX_VMAPI_MAX_CODECS];/*!< Codec Table */
}x_IFX_VMAPI_VoiceCodecCapabilities;


/******************************************************************/
/******************Capabilities related Objects********************/

/*! \brief Structure defining the region-specific Voice Capabilities.
*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	
	/*! Common Capabilities */
/*! \brief Signaling Protocol - SIP */
#define IFX_VMAPI_SIGNALING_PROTOCOL		"SIP/2.0"

  /*! Supported Countries is one of the IFX_VMAPI_COUNTRY_ values */
	uint32 uiSuppCountries;

/*! \brief uiSuppCountries - USA */
#define IFX_VMAPI_COUNTRY_USA					1
/*! \brief uiSuppCountries - GERMANY */
#define IFX_VMAPI_COUNTRY_GERMANY			2
/*! \brief uiSuppCountries - CHINA */
#define IFX_VMAPI_COUNTRY_CHINA				3
/*! \brief uiSuppCountries - TAIWAN */
#define IFX_VMAPI_COUNTRY_TAIWAN			4
/*! \brief uiSuppCountries - INDIA */
#define IFX_VMAPI_COUNTRY_INDIA				5
/*! \brief uiSuppCountries - JAPAN */
#define IFX_VMAPI_COUNTRY_JAPAN				6
/*! \brief Country Name - USA */
#define IFX_VMAPI_COUNTRY_NAME_USA			"US"
/*! \brief Country Name - GERMANY */
#define IFX_VMAPI_COUNTRY_NAME_GERMANY		"DE"
/*! \brief Country Name - CHINA */
#define IFX_VMAPI_COUNTRY_NAME_CHINA		"CN"
/*! \brief Country Name - TAIWAN */
#define IFX_VMAPI_COUNTRY_NAME_TAIWAN		"TW"
/*! \brief Country Name - INDIA */
#define IFX_VMAPI_COUNTRY_NAME_INDIA		"IN"
/*! \brief Country Name - JAPAN */
#define IFX_VMAPI_COUNTRY_NAME_JAPAN		"JP"


/*! \brief RTCP Support */
#define IFX_VMAPI_SUPPORT_RTCP				IFX_FALSE
/*! \brief Even though RTCP is supported, no configuration interface is possible */
#define IFX_VMAPI_RTP_REDUNDANCY				IFX_FALSE
/*! \brief  Support for Diffserv code point */ 
#define IFX_VMAPI_DSCP_COUPLED				IFX_FALSE
/*! \brief  Ethernet tagging (VLAN ID Ethernet Priority) is supported if IFX_TRUE*/
#define IFX_VMAPI_ETH_TAG_COUPLED			IFX_FALSE 	


#ifndef IIP
/*! \brief Support SRTP if IFX_TRUE */
#define IFX_VMAPI_SUPPORT_SRTP				IFX_FALSE
/*! \brief SRTP Key method */
#define IFX_VMAPI_SRTP_KEY_METHOD			IFX_NULL
/*! \brief SRTP Key size */
#define IFX_VMAPI_SRTP_ENC_KEY_SIZE			""
/*! \brief PSTN Switchover */
#define IFX_VMAPI_PSTN_SWITCH_OVER			IFX_TRUE
/*! \brief FAX support */
#define IFX_VMAPI_FAX_T38						IFX_TRUE
/*! \brief  Support of Fax Pass-Through if IFX_TRUE*/
#define IFX_VMAPI_FAX_PASS_THRU				IFX_TRUE
/*! \brief  Support for Modem Pass through if IFX_TRUE*/
#define IFX_VMAPI_MODEM_PASS_THRU			IFX_FALSE
/*! \brief  Support for Tone Generation if IFX_TRUE */
#define IFX_VMAPI_TONE_GENERATION			IFX_TRUE
/*! \brief Indicates whether the Tone.Description and Tone.Pattern tables of \n
	Voice Profile is editable or not */
#define IFX_VMAPI_TONE_DESC_EDIT				IFX_FALSE
/*! \brief  Support for Tone Generation by pattern specification if IFX_TRUE */
#define IFX_VMAPI_PATTERN_TONE_GEN			IFX_FALSE
/*! \brief  Support for Tone Generation by file play back if IFX_TRUE*/
#define IFX_VMAPI_FILE_TONE_GEN				IFX_FALSE
/*! \brief  Comma separated list of Tone file formats supported if IFX_TRUE*/
/* TODO */
#define IFX_VMAPI_TONE_FILE_FORMAT		IFX_FALSE
/*! \brief  Support for Ring Generation if IFX_TRUE */
#define IFX_VMAPI_RING_GENERATION			IFX_TRUE
/*! \brief Indicates whether the Ringer.Description and Ringer.Pattern tables of \n
	Voice Line is editable or not */
#define IFX_VMAPI_RING_DESC_EDIT				IFX_FALSE
/*! \brief  Support for Ring generation by pattern specification*/
#define IFX_VMAPI_PATTERN_RING_GEN			IFX_FALSE
/*! \brief  Support for Ring Generation by file play back */
#define IFX_VMAPI_FILE_RING_GEN				IFX_FALSE
/*! \brief  Comma separated lists of ring file formats supported if IFX_TRUE */
#define IFX_VMAPI_RING_FILE_FORMAT			""
/*! \brief  Support for a configurable digit map string if IFX_TRUE*/
#define IFX_VMAPI_DIGIT_MAP					IFX_FALSE
/*! \brief  Support for a configurable numbering plan if IFX_TRUE*/
#define IFX_VMAPI_NUMBERING_PLAN				IFX_TRUE
/*! \brief  Support for a configurable button map if IFX_TRUE*/
#define IFX_VMAPI_BUTTON_PLAN					IFX_FALSE
/*! \brief  Support for remotely accesible voice port tests if IFX_TRUE*/
#define IFX_VMAPI_VOICE_PORT_TEST			IFX_FALSE
#endif /*! ATA */

#ifdef IIP 
/*! \brief Support SRTP if IFX_TRUE */
#define IFX_VMAPI_SUPPORT_SRTP				IFX_FALSE
/*! \brief SRTP Key method */
#define IFX_VMAPI_SRTP_KEY_METHOD			IFX_NULL
/*! \brief SRTP Key size - */
/* Key size needs to be defined from VoIP SW */
#define IFX_VMAPI_SRTP_ENC_KEY_SIZE			""
/*! \brief PSTN Switchover is FALSE */
#define IFX_VMAPI_PSTN_SWITCH_OVER			IFX_FALSE
/*! \brief No Fax Support */
#define IFX_VMAPI_FAX_T38						IFX_FALSE
/*! \brief  Support of Fax Pass-Through if IFX_TRUE*/
#define IFX_VMAPI_FAX_PASS_THRU				IFX_TRUE
/*! \brief  Support for Modem Pass through if IFX_TRUE*/
#define IFX_VMAPI_MODEM_PASS_THRU			IFX_FALSE
/*! \brief  Support for Tone Generation if IFX_TRUE */
#define IFX_VMAPI_TONE_GENERATION			IFX_TRUE
/*! \brief Indicates whether the Tone.Description and Tone.Pattern tables of \n
	Voice Profile is editable or not */
#define IFX_VMAPI_TONE_DESC_EDIT				IFX_FALSE
/*! \brief  Support for Tone Generation by pattern specification if IFX_TRUE */
#define IFX_VMAPI_PATTERN_TONE_GEN			IFX_FALSE
/*! \brief  Support for Tone Generation by file play back if IFX_TRUE*/
#define IFX_VMAPI_FILE_TONE_GEN				IFX_FALSE
/*! \brief  Comma separated list of Tone file formats supported if IFX_TRUE*/
#define IFX_VMAPI_TONE_FILE_FORMAT			""
/*! \brief  Support for Ring Generation if IFX_TRUE */
#define IFX_VMAPI_RING_GENERATION			IFX_TRUE
/*! \brief Indicates whether the Ringer.Description and Ringer.Pattern tables of \n
	Voice Line is editable or not */
#define IFX_VMAPI_RING_DESC_EDIT				IFX_FALSE
/*! \brief  Support for Ring generation by pattern specification*/
#define IFX_VMAPI_PATTERN_RING_GEN			IFX_FALSE
/*! \brief  Support for Ring Generation by file play back */
#define IFX_VMAPI_FILE_RING_GEN				IFX_FALSE
/*! \brief  Comma separated lists of ring file formats supported if IFX_TRUE */
#define IFX_VMAPI_RING_FILE_FORMAT			""
/*! \brief  Support for a configurable digit map string if IFX_TRUE*/
#define IFX_VMAPI_DIGIT_MAP					IFX_FALSE
/*! \brief  Support for a configurable numbering plan if IFX_TRUE*/
#define IFX_VMAPI_NUMBERING_PLAN				IFX_FALSE
/*! \brief  Support for a configurable button map if IFX_TRUE*/
#define IFX_VMAPI_BUTTON_PLAN					IFX_FALSE
/*! \brief  Support for remotely accesible voice port tests if IFX_TRUE*/
#define IFX_VMAPI_VOICE_PORT_TEST			IFX_FALSE
#endif /*! IIP */

}x_IFX_VMAPI_VoiceCapabilities;


/***********************************************************/
/***************Physical Interface object*******************/

/*! \brief Structure defining a Physical Interfaces for Voice. This is a TR104 Read Only Object*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucPhyPortNum; /*!< Physical ports number */
	
 /*! \brief FXS Port  */
#define IFX_VMAPI_VOICE_PORT_TYPE_FXS						1
/*! \brief FXO Port */
#define IFX_VMAPI_VOICE_PORT_TYPE_FXO						2
/*! \brief Analog FXS Port */
#define IFX_VMAPI_VOICE_PORT_TYPE_DECT					3
/*! \brief Analog FXO Port */
#define IFX_VMAPI_VOICE_PORT_TYPE_ANALOG_FXO		4
/*! \brief ISDN FXS Port */
#define IFX_VMAPI_VOICE_PORT_TYPE_ISDN_FXS			5
/*! \brief ISDN FXO Port */
#define IFX_VMAPI_VOICE_PORT_TYPE_ISDN_FXO			6

	uchar8 ucPortType; /*!< TR-104 requires data about only FXS ports */
	uchar8 ucStatus; /*!< Status */
	uchar8 ucInterfaceId; /*!< Identification of Voice Interface Id */
	char8 acIfDesc[IFX_VMAPI_MAX_IFACE_DESCR_LEN]; /*!< Interface description */    

}x_IFX_VMAPI_VoiceServPhyIf;

/*! \brief Structure defining a FXO Physical Interfaces for Voice. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	
  bool bEnableEchoCancel; /*!<  Enable/Disable Echo Cancellation */
	uchar8 ucEndPtId[12]; /*!< EXTN number valid for FXS,FXO,DECT*/
	uchar8 ucVoiceLineId; /*!<  Default Voice Line Id */	
	char8  acChannelString[IFX_VMAPI_MAX_DEV_STR_LEN]; /*!<  Channel String */
	x_IFX_VMAPI_VoiceServPhyIf   xVoiceServPhyIf; /*!< Physical Interface */
	uchar8 ucInterfaceIdList[2*IFX_VMAPI_MAX_PHY_ENDPTS]; /*!< FXS and DECT interface id list */
	char8 uacSmsScNumber[12]; /*!< SMS-SC number */ 
	uchar8 ucGatewayMode; /*!< GW Mode operation */ 
	char8 uacCallFwdNoAnswer[12]; /*!< Call Forward on No Answer */
/*! \brief State Enabled */
#define IFX_VMAPI_PSTN_LINE_STATE_ENABLED      IFX_VMAPI_VP_STATE_ENABLED
/*! \brief  State Disabled */
#define IFX_VMAPI_PSTN_LINE_STATE_DISABLED     IFX_VMAPI_VP_STATE_DISABLED
/* State Quiescent */
//#define IFX_VMAPI_PSTN_LINE_STATE_QUIESCENT    IFX_VMAPI_VP_STATE_QUIESCENT
  uchar8 ucState; /*!< Line State is one of IFX_VMAPI_PSTN_LINE_STATE_* */
  char8 acName[16]; /*!< Name of  the line */
  uchar8 ucLineMode; /*!< PSTN Line Mode: 0 if single/1 if multi */
  uchar8 ucIntrusion; /*!< PSTN  Line Intrusion: 0 if not allowed/1 if allowed */

}x_IFX_VMAPI_FxoPhyIf;

/*! \brief Structure defining a FXS Physical Interfaces for Voice. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	
  bool bEnableEchoCancel; /*!<  Enable/Disable Echo Cancellation */
	uchar8 ucEndPtId[12]; /*!< EXTN number valid for FXS,FXO,DECT*/
	uchar8 ucVoiceLineId; /*!<  Default Voice Line Id */
	char8  acChannelString[IFX_VMAPI_MAX_DEV_STR_LEN]; /*!<  Channel String */
  x_IFX_VMAPI_VoiceServPhyIf   xVoiceServPhyIf; /*!< Physical Interface */
	bool bSmsCapable; /*!< SMS Capable */ 
	bool bWideBandCapable; /*!< Wideband Capable */ 
	uchar8 ucVoiceLineIdList[2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES+1];/*!< Associated Voice Lines */ 

}x_IFX_VMAPI_FxsPhyIf;

/*! \brief Structure defining all the Subscription Info parameters */
typedef struct
{
/*! \brief IPUI Size */
#define IFX_VMAPI_IPUI_SIZE 5
/*! \brief TPUI Size */
#define IFX_VMAPI_TPUI_SIZE 3
/*! \brief Auth Key Size */
#define IFX_VMAPI_AUTH_KEY_SIZE 16
/*! \brief Cipher Key Size */
#define IFX_VMAPI_CIPHER_KEY_SIZE 8

	bool    bIsRegistered;  /*!< Registered Flag */
	uchar8  aucIPUI[IFX_VMAPI_IPUI_SIZE*3]; /*!< IPUI */ 
	uchar8  aucTPUI[IFX_VMAPI_TPUI_SIZE*3];  /*!<TPUE */
	uchar8  aucAuthKey[IFX_VMAPI_AUTH_KEY_SIZE*3]; /*!< Auth Key */
	uchar8  aucCipherKey[IFX_VMAPI_CIPHER_KEY_SIZE*3]; /*!< Cipher Key */
	uchar8  ucServiceClass; /*!< Service Class */
	uchar8  ucModelId; /*!< Mode Id */
	uint32 uiTermCapab;   /*!<Terminal Capabilities */

}x_IFX_VMAPI_DectSubsInfo;


/*! \brief Structure defining the  DECT Handset. */
typedef struct {

  uchar8 ucIndex; /*!< Index */
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	/*! \brief Max Handset Call Status length */
#define IFX_VMAPI_MAX_HANDSET_CALL_STATUS		22
	/*! Indicates the call state for this handset.. Can be any of the following-
	 *	"Idle" (default value), "Internal Calling", "Internal Call Ringing",
   *	"External Calling", "External Call Ringing", "unreachable". */
	char8 acStatus[IFX_VMAPI_MAX_HANDSET_CALL_STATUS];
	/*! \brief IPEI string length */
#define IFX_VMAPI_IPEI_LEN	5
	/*! International Portable Equipment Identity (IPEI)  - 36 bits long. */
	char8 acIPEI[IFX_VMAPI_IPEI_LEN*3];
	/*! The date and time this DECT handset has been successfully subscribed 
	 *  to the base station. 
	 */
	char8 acSubscriptionTime[2*IFX_VMAPI_MAX_TIME_STR_LEN];
	char8  acChannelString[IFX_VMAPI_MAX_DEV_STR_LEN]; /*!<  Channel String */
	bool bSmsCapable; /*!< SMS Capable */ 
	bool bWideBandCapable; /*!< Wideband Capable */ 
  /*! Subscription Info*/
	x_IFX_VMAPI_DectSubsInfo xSubsInfo;
  x_IFX_VMAPI_VoiceServPhyIf   xVoiceServPhyIf; /*!< Physical Interface */
	uchar8 ucEndPtId[12]; /*!< EXTN number DECT*/
	uchar8 ucEndPtName[16]; /*!< Handset Name*/
	uchar8 bIntercept; 	/*!< Intercept Flag */
	uchar8 ucVoiceLineId; /*!<  Default Voice Line Id */
	/*! Associated Voice Lines */
	uchar8 aucVoiceLineIdList[2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES + 1]; 

}x_IFX_VMAPI_DectHandset;

/*! \brief Structure containing the DECT Codec Descriptions */  
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;

	uint32 uiCodecId; /*!< Codec Id representing a codec, one of IFX_VMAPI_CODEC_* */

/*! \brief Codec Id IFX_VMAPI_CODEC_G711_ALAW */
#define IFX_VMAPI_CODEC_G711_ALAW     			0x00000001
/*! \brief Codec Id IFX_VMAPI_CODEC_G711_ULAW */
#define IFX_VMAPI_CODEC_G711_ULAW     			0x00000002
/*! \brief Codec Id IFX_VMAPI_CODEC_G729_8 */
#define IFX_VMAPI_CODEC_G729_8        			0x00000004
/*! \brief Codec Id IFX_VMAPI_CODEC_G729_E */
#define IFX_VMAPI_CODEC_G729_E        			0x00000008
/*! \brief Codec Id IFX_VMAPI_CODEC_G723 */
#define IFX_VMAPI_CODEC_G723          			0x00000010
/*! \brief Codec Id IFX_VMAPI_CODEC_G723_5_3 */
#define IFX_VMAPI_CODEC_G723_5_3      			0x00000020
/*! \brief Codec Id IFX_VMAPI_CODEC_G723_6_3 */
#define IFX_VMAPI_CODEC_G723_6_3      			0x00000040
/*! \brief Codec Id IFX_VMAPI_CODEC_G728 */
#define IFX_VMAPI_CODEC_G728          			0x00000080
/*! \brief Codec Id IFX_VMAPI_CODEC_G726_16 */
#define IFX_VMAPI_CODEC_G726_16       			0x00000800
/*! \brief Codec Id IFX_VMAPI_CODEC_G726_24 */
#define IFX_VMAPI_CODEC_G726_24       			0x00001000
/*! \brief Codec Id IFX_VMAPI_CODEC_G726_32 */
#define IFX_VMAPI_CODEC_G726_32       			0x00002000
/*! \brief Codec Id IFX_VMAPI_CODEC_G726_40 */
#define IFX_VMAPI_CODEC_G726_40       			0x00004000
/*! \brief Codec Id IFX_VMAPI_CODEC_G722_64 */
#define IFX_VMAPI_CODEC_G722_64       			0x00008000

	char8 acCodecName[IFX_VMAPI_MAX_CODEC_NAME_LEN];	/*!< Name of codec, one of IFX_VMAPI_CODEC_NAME_* */
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G711_ALAW */
#define IFX_VMAPI_CODEC_NAME_G711_ALAW			"G.711ALaw"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G711_ULAW */
#define IFX_VMAPI_CODEC_NAME_G711_ULAW			"G.711ULaw"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G726 */
#define IFX_VMAPI_CODEC_NAME_G726				"G.726"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G729 */
#define IFX_VMAPI_CODEC_NAME_G729				"G.729"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G729a */
#define IFX_VMAPI_CODEC_NAME_G729a				"G.729a"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G729e */
#define IFX_VMAPI_CODEC_NAME_G729e				"G.729e"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G728 */
#define IFX_VMAPI_CODEC_NAME_G728				"G.728"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G723_1 */
#define IFX_VMAPI_CODEC_NAME_G723_1				"G.723.1"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G722 */
#define IFX_VMAPI_CODEC_NAME_G722				"G.722"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G722_1 */
#define IFX_VMAPI_CODEC_NAME_G722_1				"G.722.1"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_G722_2 */
#define IFX_VMAPI_CODEC_NAME_G722_2				"G.722.2"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_ILBC */
#define IFX_VMAPI_CODEC_NAME_ILBC				"iLBC"
/*! \brief Codec Name for IFX_VMAPI_CODEC_NAME_T38 */
#define IFX_VMAPI_CODEC_NAME_T38					"T.38"

	uint16 unCodecSuppFrameLen; /*!< supported frame length, one of IFX_VMAPI_CODEC_FRAME_LEN_* */
/*! \brief Codec Frame Length_5 */
#define IFX_VMAPI_CODEC_FRAME_LEN_5				0x0001
/*! \brief Codec Frame Length 10 */
#define IFX_VMAPI_CODEC_FRAME_LEN_10			0x0002
/*! \brief Codec Frame Length 20 */
#define IFX_VMAPI_CODEC_FRAME_LEN_20			0x0004
/*! \brief Codec Frame Length 30 */
#define IFX_VMAPI_CODEC_FRAME_LEN_30			0x0008	
/*! \brief Codec Frame Length 40 */
#define IFX_VMAPI_CODEC_FRAME_LEN_40		  0x0010	
/*! \brief Codec Frame Length 50 */
#define IFX_VMAPI_CODEC_FRAME_LEN_50			0x0020	
/*! \brief Codec Frame Length 60 */
#define IFX_VMAPI_CODEC_FRAME_LEN_60			0x0040
}x_IFX_VMAPI_DectCodecDesc;


/*! \brief Structure defining the DECT System  */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
	/*! Number of instances in the Handset table. Number of DECT Portable Parts
	 *  (handsets) currently subscribed to the DECT Fixed Part (base station).
	 */
	uint32 uiNumberOfHandsets;
	/*! gives the status of "subscription window" [See PdD-149 for details]. */
	bool bWaitingSubscription;
	/*! DECT Handset table */
	x_IFX_VMAPI_DectHandset	*pxHandsetTbl;

	/*! \brief Authentication Code Size */
  #define IFX_VMAPI_AUTH_CODE_SIZE 9
  
	char8 acAuthCode[IFX_VMAPI_AUTH_CODE_SIZE]; /*!< Authentication Code */

	/*! Set of DECT device strings*/
	char8 acDeviceString[IFX_VMAPI_MAX_DECT_ENDPTS][IFX_VMAPI_MAX_DEV_STR_LEN];
	/*! Encryption Support */
	uchar8 ucEncrytionEnable;
	/*! DNA Support */
	uchar8 ucDnaEnable;
	/*! Clock Master Support */
	uchar8 ucClkMaster;
	/*! No Emission Mode Support */
	uchar8 ucNoEmo;
  uchar8 ucRfEnable;/*Rf on/off*/
	/*! \brief Maximum Basestation name length */
	#define IFX_VMAPI_MAX_BASENAME 18
	/*! Base Name */
	char8 acBaseName[IFX_VMAPI_MAX_BASENAME];
	/*! Number of Dect Codecs */
	uint32 uiDectNumCodecs;
  /*! Codec List*/
	x_IFX_VMAPI_DectCodecDesc *pxCodecList;
}x_IFX_VMAPI_DectSystem;



/*******************************************************************/
/********************** Call Block **************************/

/*! \brief Structure defining the  Call Block Entry. */
typedef struct {
 uchar8 ucIndex; /*!< Index */
 /*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
 char8 acCallBlockNum[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< Telephone Number */
} x_IFX_VMAPI_CallBlockEntry;

/*! \brief Structure defining the Call Block entries. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	bool bCallBar; /*!< Outgoing Call Bar */
	uint32 uiNumCallBlockEntries; /*!< Number of call block list entries */
	/*! Call Block List */
//  x_IFX_VMAPI_CallBlockEntry axCallBlockList[IFX_VMAPI_MAX_CALL_BLK_ENTRIES];
  x_IFX_VMAPI_CallBlockEntry *pxCallBlockList;
}x_IFX_VMAPI_CallBlock;


/********************   Call Register *************************/

/*! \brief  Structure defining the Sip Address  information. */
typedef struct {
	 /*! Address Type - One of IFX_VMAPI_ADDR_TYPE_* values */
   uchar8 ucAddrType;
	 /*! Display Name of the destination */
   char8 acDisplayName[IFX_VMAPI_MAX_SIP_DISP_NAME_LEN];
	 /*! User Name of the destination/Phone Number */
   char8 acUserName[IFX_VMAPI_MAX_USER_NAME_LEN];
   char8 acDestAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN];  /*!<  IP address/FQDN */
	 /*! Port Number on which the destination can be reached */
   uint16 unPort;
	 /*! Protocol to be used by sip for connection establishment */
   uchar8  ucAddrProto;
} x_IFX_VMAPI_Address;

/*! \brief Structure defining the Call Entry  information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId; /*!<  Associated Voice Profile */
  uchar8 ucLineId; /*!<  Line Id */
  uchar8 ucIndex; /*!<  Index */
  /*! Time of Call (Received/Dialed/Missed) */
  char8 acCallTime[IFX_VMAPI_MAX_TIME_STR_LEN];
  /*! Date of Call (Received/Dialed/Missed) */
  char8 acCallDate[IFX_VMAPI_MAX_TIME_STR_LEN];

	e_IFX_CallTypes eCallType; /*!<  Call Type */

  x_IFX_VMAPI_Address xAddress;/*!<  Call Address */
  /*! Status - Read/UnRead */
  uchar8 bStatus;
  /*! Number of times the same call came simultaneously - only for missed call register */
  uchar8 ucNoOfCalls;
  /*! Unique identifier */
  uint32 uiEntryId;
} x_IFX_VMAPI_CallRegEntry;

/*! \brief Structure defining the Dialed Call Register Entry */
typedef x_IFX_VMAPI_CallRegEntry x_IFX_VMAPI_DialCallRegEntry;
/*! \brief Structure defining the Missed Call Register Entry */
typedef x_IFX_VMAPI_CallRegEntry x_IFX_VMAPI_MissCallRegEntry;
/*! \brief Structure defining the Received Call Register Entry */
typedef x_IFX_VMAPI_CallRegEntry x_IFX_VMAPI_RecvCallRegEntry;

/*! \brief Structure defining the call register entries. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId; /*!<  Associated Voice Profile */
  uchar8 ucLineId; /*!<  Line Id */
  uchar8 ucIndex; /*!<  Index */

  uint32 ucNoOfEntries; /*!< Number of Dialed Entries */
	/*! Dialed Entries */
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntries;

}x_IFX_VMAPI_CallRegister;

/*! \brief Structure defining the Dialed Call Register */
typedef x_IFX_VMAPI_CallRegister x_IFX_VMAPI_DialCallRegister;
/*! \brief Structure defining the Missed Call Register */
typedef x_IFX_VMAPI_CallRegister x_IFX_VMAPI_MissCallRegister;
/*! \brief Structure defining the Received Call Register */
typedef x_IFX_VMAPI_CallRegister x_IFX_VMAPI_RecvCallRegister;



/*******************************************************************/
/********************** Address Book Entry**************************/

/*! \brief Structure defining the  AddressBookEntry. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
  uchar8 ucLineId; /*!< Line ID */
  char8 acDialCode[IFX_VMAPI_MAX_DIAL_CODE_LEN]; /*!< Dial Code */
  e_IFX_CallTypes eCallType; /*!< Call Type */
  uint32 uiEntryId; /*!< Unqiue Entry identifier */
  x_IFX_VMAPI_Address xAddress;/*!<  Destination Address */
  uchar8 ucIndex; /*!<  Index */
} x_IFX_VMAPI_AddressBookEntry;

/*! \brief Structure defining the Address book entries. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	/* ADDRESS BOOK */
  uint32 ucNoOfAddBookEntries; /*!< Number of Address Book Entries */
  x_IFX_VMAPI_AddressBookEntry *pxAddressBook; /*!< Array of address book entries */
}x_IFX_VMAPI_AddressBook;


/******************************** Contact-List related object *********************/

/*! \brief  Structure defining the Contact  information. */
typedef struct {

   char8 acUserFirstName[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< User (First) Name of the contact */
   char8 acUserLastName[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< User (Last) Name of the contact */
   char8 acContactNum[IFX_VMAPI_MAX_TRANS_ADDR_LEN];  /*!< Contact Number */
   char8 cContactType;  /*!< Contact Type */
   char8 acContactNumTwo[IFX_VMAPI_MAX_TRANS_ADDR_LEN];  /*!< Secondary Contact Number */
   char8 cContactTypeTwo;  /*!< Secondary Contact Type */
} x_IFX_VMAPI_ContactAddress;


/*! \brief Structure defining the  Contact List Entry. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  
  uchar8 ucProfileId; /*!<  Associated Voice Profile */
  uchar8 ucLineId; /*!< Line ID */
  /*! Unique identifier */
  uint32 uiEntryId;
  /*! Index */
  uchar8 ucIndex;
  x_IFX_VMAPI_ContactAddress xAddress;/*!<  Contact Address Address */
} x_IFX_VMAPI_ContactListEntry;


/*! \brief Structure defining the Contact List entries. */
typedef struct {
        /*! Management ID to contain device specific object ID and TR-104. 
         * Defined by Management API Framework. 
         */
	IFX_ID iid;
  	uchar8 ucProfileId; /*!<  Associated Voice Profile */
  	uchar8 ucLineId; /*!<  Line Id */
        /* CONTACT BOOK */
  	uint32 ucNoOfEntries; /*!< Number of Contact list entires..*/
        /*! Array of ContactList entries */
  x_IFX_VMAPI_ContactListEntry *pxContactEntries;
}x_IFX_VMAPI_ContactList;



/***********************************************************/
/***************Tone related object****************/

/*! \brief Structure defining Tone information. "unF*" are the frequencies
 * of tones and "unG*" are the gains. */
typedef struct {
	/*! Identification for the Tone. Addresses the function of the Tone */
	uint32 uiToneId;
	/*! Tone name */
	char8 acToneName[IFX_VMAPI_MAX_TONE_NAME_LEN];
	/*! Tone Enable or Disable Flag - 
	 * If the Tone is disabled, then the remaining part of the structure
	 * is useless.
	 */
	bool bEnableTone;

	/*! Turn on tone during this phase */
	bool bOn;
	uint16 unF1; /*!< F1 */
	uint16 unF2; /*!< F2 */
	uint16 unF3; /*!< F3 */
	uint16 unF4; /*!< F4 */
	uint16 unModFreq; /*!< Mod Frequency */
	uint16 unG1; /*!< G1 */
	uint16 unG2; /*!< G2 */
	uint16 unG3; /*!< G3 */
	uint16 unG4; /*!< G4 */
	uint16 unModGain; /*!< Mod Gain */
	uint32 uiDuration; /*!< Duration of playing tone */

	/*! Next Tone Id, defined for compatibility with TR-104, un-used
	uint32 uiNextToneId; */
} x_IFX_VMAPI_ToneInfo;

/*! \brief Structure defining the Tone Table. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
/*! Number of tones */
	uchar8 ucNoOfTones;
	/*! Array of tone information */
	x_IFX_VMAPI_ToneInfo axToneInfo[IFX_VMAPI_MAX_TONES];
}x_IFX_VMAPI_ToneTable;


/***********************************************************/
/***************Numbering Plan *********************/

/*! \brief Number Plan Rule */
typedef struct {
	/*! Index */
  uchar8 ucIndex;
  /*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	/*! Main Action */
	uint32 uiMainAct;
	/*! Numbering Plan Prefix String */
	char8 acPrefix[IFX_VMAPI_NUM_PLAN_MAX_PREFIX_LEN];
	/*! Minimum Digits for this Prefix */
	uchar8 ucMinDigits4Prefix;
	/*! Maximum Digits for this Prefix */
	uchar8 ucMaxDigits4Prefix;
	/*! Number of digits to be removed */
	uchar8 ucNoOfDigits2bRem;
	/*! Position of digits to be removed */
	uchar8 ucPosDigits2bRem;
	/*! Digits to be insterted */
	char8 cDigits2bIns;
	/*! Position of digits to be inserted */
	uchar8 ucPosDigits2bIns;
	/*! Digits to be replaced */
	char8 cDigits2bRep;
	/*! Position of digits to be replaced */
	uchar8 ucPosDigits2bRep;
	/*! Dial Tone - Required by TR-104 */
	uint32 uiDialTone;
	/*! Facility Action Argument*/
	char8 acFacilityArg[IFX_VMAPI_MAX_NUM_PLAN_RULE_LEN];
	//char8 acFacilityArg[5];
} x_IFX_VMAPI_NumPlanRule;

/*! \brief Structure defining the Numbering Plan. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
/*! Numbering Plan Min Digits */
	uchar8 ucNumPlanMinDigits;
	/*! Numbering Plan Max Digits */
	uchar8 ucNumPlanMaxDigits;
	/*! Inter-Digit Timer Standard, in secs */
	uchar8 ucInterdigTimerStd;
	/*! Inter-Digit Timer Progressive, in secs */
	uchar8 ucInterdigTimerProg;
	/*! Rules */
	uint32 ucNoOfNumPlanRules;
	/*! Array of Number Plan Rules */
	x_IFX_VMAPI_NumPlanRule *pxNumPlanRules;
}x_IFX_VMAPI_NumPlan;


/***********************************************************/
/***************Miscellaneous Information *********************/
/*! \brief Structure defining the miscellaneous parameters for the VoIP System*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
  bool bAcceptUnSolNotify; /*!< Accept Unsolicited Voice mail notifications */
  bool bEnableUDPRedir; /*!< Enable UDP redirection */
  char8 uacSmsScNumber[12]; /*!< SMS-SC number */ 
  bool bRestoreFactorySettings; /*!< Restore Factory System Defaults */
  uchar8 defaultFaxIface; /*!< Default Fax Interace. Contain the InterfaceId of that Physical Interface */
  uchar8 defaultOutbndIface; /*!< Default Outbound Interface. Takes one of e_IFX_CallTypes value */
	uchar8 ucDialToneDuration; /*!< DialToneDuration in seconds */
	bool bSilenceSupp; /*!< Silence suppression flag */
	uint32 uiSessExpires; /*!< Session expiry time to refresh the session*/
  uchar8 ucFxoEnable;  /*!< Fxo Enable */
}x_IFX_VMAPI_Misc;


/***********************************************************/
/*************** T.38 *********************/

/*! \brief Structure defining the configuration pertaining to T.38 stack.
*/
typedef struct
{	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
  uchar8 ucOldAsn1;  /*!< 0 - Off, 1 - On */
  uchar8 ucNsxSize; /*!< Size of NSX Patch */
  uchar8 ucNsxInfoField[IFX_FA_NSX_MAX_SIZE];/*!< NSX Info */
  uchar8 ucDataWaitTime; /*!< Data Wait time in 10 ms */
	 
 /*! Specifies the packet-level redundancy for highspeed data transmissions
  *  (i.e., T.4 image data). The value MUST be in the range 0 through 3.
  */
  uint16 unUdpHRErrRecPkts;/*!< Udp High Rate Error Recovery Packets */
	 
	/*! Specifies the packet-level redundancy for lowspeed data transmissions
  *  (i.e., T.30 handshaking information). The value MUST be in the range 0
  *  through 5.
  */
  uint16 unUdpLRErrRecPkts;/*!< Udp Low Rate Error Recovery Packets */
	 
  uint16 unUdpPriorFecPkts;/*!< Udp Prior Packets for FEC */
  uint16 unFrameLength;/*!< Framelength */
  uchar8 ucT38Conn;/*!< Preferred T38 Connection */
}x_IFX_VMAPI_T38Cfg;



/***********************************************************/
/*************** GR909 Test *********************/
/*! \brief Structure containing the parameters for GR-909 line testing */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
  uint32 uiHighResist;/*!< High resistor of voltage divider connected to Mohms*/
  uint32 uiLowResist1;/*!< Low resistor of voltage divider in parallel to internal resistor od 1 Mohm*/
  uint32 uiLowResist7500;/*!< Low resistor of voltage divider in parallel to internal resistor of 7500 ohm*/
/*! \brief Hazardous potential test*/
#define IFX_VMAPI_GR909_HAZPOTTEST 1
/*! \brief Resistive fault test */
#define IFX_VMAPI_GR909_RESFAULTTEST 2
/*! \brief Foreign Electro motive test */
#define IFX_VMAPI_GR909_FORELCMOTTEST 3
/*! \brief Receiver offhook test */
#define IFX_VMAPI_GR909_RECOFFHOOKTEST 4
/*! \brief Ring Impedence test */
#define IFX_VMAPI_GR909_RINGIMPTEST 5
  uchar8 ucTestType;/*!< Type of test to be performed*/
   
}x_IFX_VMAPI_GR909;



/***********************************************************/
/*************** Version Information *********************/
/*! \brief Structure defining Software Version Data. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
   char8 acFirmwareVer[IFX_VMAPI_MAX_VER_STR_LEN]; /*!< Firmware Version */
#ifdef IIP
   /*  */
   char8 acHapiVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< Hapi Version */ 
   char8 acJBVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< JB Version */   
   char8 acChipVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< Chip Version */
#endif /*IIP*/
   char8 acDrvVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< Driver Version */
   char8 acAppVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< Voip Application Version */
   char8 acRtpVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< RTP Version */
   char8 acCmVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< CM Version */
   char8 acSipVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< SIP Version */

#ifndef IIP
   char8 acFaxVer[IFX_VMAPI_MAX_VER_STR_LEN];/*!< Fax  Version */
#endif /* ATA */    
}x_IFX_VMAPI_SystemVersionRegister;/*!<  */



/***************Voice System Debug Settings***********/

/*! \brief No Debug */
#define IFX_VMAPI_DBG_LVL_NONE		IFX_DBG_LVL_NONE
/*! \brief Error - Only errors are displayed */
#define IFX_VMAPI_DBG_LVL_ERROR		IFX_DBG_LVL_ERROR
/*! \brief Few debugs are displayed */
#define IFX_VMAPI_DBG_LVL_LOW			IFX_DEBG_LVL_LOW
/*! \brief Normal level of debugs */
#define IFX_VMAPI_DBG_LVL_NORMAL	IFX_DEBG_LVL_NORMAL
/*! \brief Detailed debugs are displayed */
#define IFX_DEBG_LVL_HIGH 				4

/*! \brief None */
#define IFX_VMAPI_DBG_TYPE_NONE			IFX_DBG_NONE
/*! \brief Debugs are displayed on console */
#define IFX_VMAPI_DBG_TYPE_CONSOLE	1
/*! \brief Debugs are logged into a file */
#define IFX_VMAPI_DBG_TYPE_FILE			IFX_DBG_FILE

/*! \brief Structure defining debug-related information. */
typedef struct {
   uchar8 ucDbgLvl; /*!< Debug Level - One of IFX_VMAPI_DBG_LVL_* */
   uchar8 ucDbgType; /*!< Debug Type - One of IFX_VMAPI_DBG_TYPE_* */
}x_IFX_VMAPI_DbgType;

/*! \brief Structure defining Debug Settings. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
   x_IFX_VMAPI_DbgType xCmDbg; /*!< Call Manager Debug */
   x_IFX_VMAPI_DbgType xMmDbg; /*!< Media Manager Debug */
   x_IFX_VMAPI_DbgType xAgentsDbg; /*!< Agents Debug */
   x_IFX_VMAPI_DbgType xRtpDbg; /*!< Rtp Debug */
   x_IFX_VMAPI_DbgType xVmapiDbg; /*!< CM Debug */
   x_IFX_VMAPI_DbgType xSipDbg; /*!< SIP Debug */
#ifndef IIP
   x_IFX_VMAPI_DbgType xFaxDbg; /*!< Fax Debug */
#endif /*ATA*/    
}x_IFX_VMAPI_SystemDebugSettings;



/***********************************************************/
/***************Profile related object****************/

/*! \brief Structure defining Stun Configuration information. */
typedef struct {
	char8 acStunServer[IFX_VMAPI_MAX_TRANS_ADDR_LEN]; /*!< Stun Server Address */
  uint16 unStunPort; /*!< Stun Port */
  char8 acStunUserName[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< Stun Username for exchange of certificates*/
  char8 acStunPassword[IFX_VMAPI_MAX_USER_PASSWD_LEN]; /*!< Stun Password for exchange of Certificates*/
	uint16 unNatKeepAliveTime; /*!< Nat Keep Alive Timer in Seconds */
	/*! NAT Type - NAT Type display is required in the Web 
	 * One of IFX_VMAPI_NAT_TYPE_* Values. */
  int32 iNatType;
}x_IFX_VMAPI_ProfileStunConfig;


/*! \brief Structure defining a Voice Profile. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */

	char8 acProfileName[IFX_VMAPI_VP_NAME_LEN]; /*!< Profile name */
	uint32 uiAssocCountry; /*!< Associated Country */
	uchar8 ucState;	/*!< State of profile, whether active or not */

	/*! The Voice Profile takes one of the following states */
/*! \brief Profile Enabled */
#define IFX_VMAPI_VP_STATE_ENABLED		1
/*! \brief Profile Disabled */
#define IFX_VMAPI_VP_STATE_DISABLED		0
/*! \brief Profile Quiescent */
#define IFX_VMAPI_VP_STATE_QUIESCENT	3

	bool bReset; /*!< IFX_TRUE or IFX_FALSE */
	uchar8 ucNoOfLines; /*!< No. of lines */
	uchar8 aucLines[IFX_VMAPI_MAX_VOICE_LINES_PER_PROFILE+1]; /*!< State of lines */
	uchar8 aucAssoLineIds[2*IFX_VMAPI_MAX_VOICE_LINES_PER_PROFILE+1]; /*!< Associated Lines for that Profile */
	uchar8 ucDtmfPayloadType;/*!< Payload Type for RFC2833 DTMF Event Packets */
	uchar8 ucDtmfMethod; /*!< Method for DTMF digits transmission */

/*! \brief Inband DTMF  */
#define IFX_VMAPI_VP_DTMF_MTHD_INBAND		0x1
/*! \brief RFC 2833 DTMF  */
#define IFX_VMAPI_VP_DTMF_MTHD_RFC2833	0x2
/*! \brief Sip INFO method for DTMF */
#define IFX_VMAPI_VP_DTMF_MTHD_INFO			0x4
/*! \brief No DTMF */
#define IFX_VMAPI_VP_DTMF_MTHD_NONE			0x0
	/*! This parameter is defined for special treatment of digits when the
	 * selected codec is G711.
	 * To switch off the special treatement, DTMF_MTHD_NONE should be used.
	 */
	uchar8 ucG711DtmfMethod;
	/*! Support for configurable digit map string. A IFX_TRUE value indicates
			support for acDigitMap digit map string. By default the value is IFX_FALSE. */
	bool bEnableDigitMap;
	char8 acDigitMap[IFX_VMAPI_VP_MAX_DIGIT_MAP_LEN]; /*!< Digit map string */

	bool bEnableStun; /*!< Flag to Enable or Disable Stun */
	x_IFX_VMAPI_ProfileStunConfig xStunConfig; /*!< Stun configuration */

	/*! Non Voice (Data) Upstream reserved bandwidths */
	uint32 uiDataResUpBandwidth;
	/*! Non Voice (Data) Downstream reserved bandwidths */
	uint32 uiDataResDownBandwidth;
	
	bool bPstnFailOver; /*!< PSTN Failover Enable Flag */

	bool bFaxPassThru; /*!< Fax PassThru Flag */
	bool bModemPassThru; /*!< Modem PassThru Flag */
}x_IFX_VMAPI_VoiceProfile;



/***********************************************************/
/******************Event Notification related Objects*******/

/*! \brief Structure defining the SIP Event-Notification specific informaation. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
		IFX_ID iid;
	uchar8 ucIndex; /*!< Index */
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
  uint32 uiEvent; /*!< Subscription Event - Takes one of IFX_VMAPI_VL_SUBS_EVENT_* values */
	char8 acNotifierAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN];/*!< Notifier IP Address */
	uint16 unNotifierPort; /*!< Notifier Port */
	uchar8 ucNotifierProtocol; /*!< Notifier Protocol */
	uint16 unSubscriptionTime; /*!< Subscription Time */	
}x_IFX_VMAPI_EventSubscribe;

/*! \brief Structure defining an array of SIP Event packages. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
	uchar8 ucNoOfSubscrElements; /*!< Number of Subscriber elements */
	/*! Array of Events subscribed to. */
	x_IFX_VMAPI_EventSubscribe *pxEventSubscribe;
}x_IFX_VMAPI_ProfileEventSubsTable;



/***********************************************************/
/******************Response Map Objects*********************/

/*! \brief Structure defining the SIP response code, reason phrase, and the tone to be played on receiving such message.
*/
typedef struct {
	uint16 unSipRspCode; /*!< Response code of the Sip message */
	char8 acMsg[IFX_VMAPI_MAX_RSP_MAP_TXT_LEN]; /*!< Text Message */
	uint32 uiTone;/*!< Tone to be played for this response */
}x_IFX_VMAPI_RspMap;


/*! \brief Structure defining an array of response-map asscoiated with a profile.*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
	uchar8 ucNoOfRspMapElements; /*!< Number of elements */
	x_IFX_VMAPI_RspMap axRspMap[IFX_VMAPI_MAX_RSPMAP_ELMNTS]; /*!< Array of response maps */
}x_IFX_VMAPI_ProfileRspMapTable;




/***********************************************************/
/******************Service Provider related object**********/

/*! \brief Structure defining the service provider information. */
typedef struct {
  /*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
	char8 acName[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< Name of service provider */
	char8 acUrl[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< URL of service provider */
	char8 acPhone[IFX_VMAPI_MAX_PHONE_NO_LEN]; /*!< Phone name of service provider */
	char8 acEmail[IFX_VMAPI_MAX_USER_NAME_LEN];/*!< e-mail of service provider */
}x_IFX_VMAPI_ProfileServiceProviderInfo;


/***********************************************************/
/***************Signaling Configuration related object *****/

/*! \brief Structure defining the Profile object used for Signaling. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	/* Associated Voice Profile */
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
	bool bEnableProxy; /*!< To be IFX_TRUE for enabling outbound proxy */
	/*! This has to be set to IFX_TRUE for enabling registration during sip
	 signaling. The registrar address is given by acRegistrarAddr. */
	bool bEnableRegistrar; 
   /*! IP address of the Proxy. This block needs to be looked into only if \n
				bEnableProxy == IFX_TRUE */
  char8 acProxyAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN];
  uint16 unProxyPort; /*!< Port on which the proxy can be contacted */
  /*! The protocol to be used for contacting the proxy. It
	 * gives the protocol used for contacting proxy */
  uchar8 ucProxyProtocol;
	/*! This block needs to be looked into only of bEnableRegistrar == IFX_TRUE. */
  char8 acRegistrarAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN];/*!< IP address of the Primary Registrar */  
  uint16 unRegistrarPort; /*!< Port on which the Primary registrar can be contacted */ 
  /*! The protocol to be used for contacting the registrar. It
	 * gives the protocol used for contacting registrar */
  uchar8 ucRegistrarProtocol; 
  char8 acBackupRegAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN];/*!< IP address of the Secondary Registrar */
  uint16 unBackupRegPort; /*!< Port on which the Secondary registrar can be contacted */
  uchar8 ucBackupRegProtocol; /*!< Protocol for secondary Registrar */
  uint32 uiRegExpirationTime; /*!< Time of over which Register request has 
																	to be sent periodically (in secs) */
  uint16 unRegRetryTime; /*!< Registration re-try Timer */
  uchar8 ucRegRetryAttempts; /*!< Registration re-try attempts */

  char8 acUADomain[IFX_VMAPI_MAX_DOMAIN_NAME_LEN];/*!< User Agent Local Domain */
  uint16 unDnsQueryTimeOut;/*!<  DNS Query Time out in Sec */
  uint16 unUAPort; /*!< User Agent incoming call control signaling port */
	uchar8 ucUAProtocol; /*!< User Agent call control signaling protocol */
  char8 acOutboundProxyAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN]; /*!< IP address of the Outbound Proxy */ 
	uint16 unOutboundProxyPort; /*!< Port Number of the Outbound Proxy */ 
  bool bWellKnownSource;/*!< Accept Message only from a well known Source*/
	char8 acOrg[IFX_VMAPI_MAX_USER_NAME_LEN];/*!< Organization */
	/*! Protocol Timer Values */
	uint16 unT1; /*!< Initial SIP Timeout - Timer T1 */
	uint16 unTk; /*!< Max SIP Timeout - Timer Tk */
	/*!< SIP Timer values from T1 to Tk */
	/*! Rest of timers, uneditable in VoIP SW
	 * Retained for TR-104 purposes
	 * When the SET request comes from ACS, just store the values and return
	 * No operation required on the modification of these parameters
	 */	
	uint16 unT2; /*!< T2 timeout value */
	uint16 unT4; /*!< T4 timeout value */
	uint16 unTa; /*!< Ta timeout value */
	uint16 unTb; /*!< Tb timeout value */
	uint16 unTc; /*!< Tc timeout value */
	uint16 unTd; /*!< Td timeout value */
	uint16 unTe; /*!< Te timeout value */
	uint16 unTf; /*!< Tf timeout value */
	uint16 unTg; /*!< Tg timeout value */
	uint16 unTh; /*!< Th timeout value */
	uint16 unTi; /*!< Ti timeout value */
	uint16 unTj; /*!< Tj timeout value */

	/*! Expiration Timer Values */
	uint16 unInvExpires; /*!< Invite expires timer value */
	uint16 unReInvExpires; /*!< ReInvite expires timer value */
	uint16 unRegExpires; /*!< Register request Expires header value (in secs) */
	uint16 unRegMinExpires; /*!< Registration min-expires */

	/*! Inbound Authentication Parameters */
	uchar8 ucInboundAuth; /*!< Takes one of IFX_VMAPI_AUTH_METHOD_* values */
  char8 acInbAuthUserName[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< Authentication Username */
  char8 acInbAuthPassword[IFX_VMAPI_MAX_USER_PASSWD_LEN]; /*!< Authentication Password */

/*! \brief "0.0.0.0" method */
#define IFX_VMAPI_ZERO_ADDR_ONHOLD 	0
/*! \brief RFC 3264 method */
#define IFX_VMAPI_RFC3264_ON_HOLD 	1
	uchar8 ucCohMethod; /*!< Method for the Compact headers */
	bool bUseCompactHdrs;/*!< Usage of Compact Headers */
	char8 acUserAgentHdr[IFX_VMAPI_MAX_UA_FIELD_LEN];/*!< User Agent Header Field */
	bool bAnnounceMethod; /*!< Codec Announcement in SDP */
	
/*! \brief As per priority of the codecs */
#define IFX_VMAPI_CODEC_ANNOUNCE_AS_PER_PRIORITY 			1
/*! \brief Low bit rate codec comes first */
#define IFX_VMAPI_CODEC_ANNOUNCE_LOW_BIT_RATE_FIRST 	2
/*! \brief In random order */
#define IFX_VMAPI_CODEC_ANNOUNCE_RANDOM_ORDER 				3

	uchar8 ucSipDscp; /*!< Diffserv code point to be used for outgoing SIP signaling protocols */
	int32  iSipVlanId; /*!< VLAN ID to be used for outgoing SIP signaling protocols */
	uchar8 ucSipEthPriority; /*!< Ethernet priority code to be used for outgoing SIP signaling protocols */
}x_IFX_VMAPI_ProfileSignaling;


/***********************************************************/
/***************Profile Media Object************************/

#ifdef IIP
/*! \brief Structure defining Media Security information. */
/* Key Managment Parameters for SRTP */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	/*! Associated Voice Profile */
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */

  bool bEnableSrtp; /*!< Enable or Disable the use of SRTP. If RTCP is enabled
												 It also implies the use of SRTCP. */
	
	/*! \brief No keying */
#define IFX_VMAPI_SRTP_KEYING_MTHD_NONE				0
	/*! \brief Proprietary method is used */
#define IFX_VMAPI_SRTP_KEYING_MTHD_PROPRIETARY	1
	/*! \brief Static keying method is used */
#define IFX_VMAPI_SRTP_KEYING_MTHD_STATIC			2
	/*! \brief SDP keying method is used */
#define IFX_VMAPI_SRTP_KEYING_MTHD_SDP				3
	/*! \brief IKE is used */
#define IFX_VMAPI_SRTP_KEYING_MTHD_IKE				4
	/*! \brief MIKEY keying method is used */
#define IFX_VMAPI_SRTP_KEYING_MTHD_MIKEY			5

	uchar8 ucSrtpKeyingMethod; /*!< Takes one of IFX_VMAPI_SRTP_KEYING_MTHD_* */
	
	/*! \brief None */
#define IFX_VMAPI_SRTP_ENC_NONE								0

	/*! \brief AES-CM */
#define IFX_VMAPI_SRTP_ENC_AES_CM							1
	/*! \brief AES-ECB */
#define IFX_VMAPI_SRTP_ENC_AES_ECB						2
	/*! \brief AES-CBC */
#define IFX_VMAPI_SRTP_ENC_AES_CBC						3
	/*! \brief AES-CFB */
#define IFX_VMAPI_SRTP_ENC_AES_CFB						4
	/*! \brief AES-OFB */
#define IFX_VMAPI_SRTP_ENC_AES_OFB						5
	/*! \brief DES-CM */
#define IFX_VMAPI_SRTP_ENC_DES_CM							6
	/*! \brief DES_ECB */
#define IFX_VMAPI_SRTP_ENC_DES_ECB						7
	/*! \brief DES-CBC */
#define IFX_VMAPI_SRTP_ENC_DES_CBC						8
	/*! \brief DES-CFB */
#define IFX_VMAPI_SRTP_ENC_DES_CFB						9
	/*! \brief DES-OFB */
#define IFX_VMAPI_SRTP_ENC_DES_OFB						10

	/*! \brief 3DES-CM */
#define IFX_VMAPI_SRTP_ENC_3DES_CM						11
	/*! \brief 3DES-ECB */
#define IFX_VMAPI_SRTP_ENC_3DES_ECB						12
	/*! \brief 3DES-CBC */
#define IFX_VMAPI_SRTP_ENC_3DES_CBC						13
	/*! \brief 3DES-CFB */
#define IFX_VMAPI_SRTP_ENC_3DES_CFB						14
	/*! \brief 3DES-OFB */
#define IFX_VMAPI_SRTP_ENC_3DES_OFB						15

	uchar8 ucSrtpEnc; /*!< One of the IFX_VMAPI_SRTP_ENC_* values */

	/*! \brief None */
#define IFX_VMAPI_SRTP_AUTH_NONE						0
	/*! \brief HMAC-SHA1 */
#define IFX_VMAPI_SRTP_AUTH_HMAC_SHA1				1

	uchar8 ucSrtpAuth;/*!< SRTP Authentication - One of the IFX_VMAPI_SRTP_* values */
	
	char8 acSrtpMasterKey[IFX_VMAPI_MAX_MASTER_KEY_LEN];/*!< Master Key */
	char8 acSrtpMasterSalt[IFX_VMAPI_MAX_MASTER_SALT_LEN];/*!< Master Salt */
	
	bool bEnableSrtpMkiInd; /*!< Enable SRTP Mki */
	uint16 unSrtpMkiLen; /*!< MKI Len */

	uchar8 ucSrtcpEnc; /*!< One of the IFX_VMAPI_SRTP_ENC_* values  */
	uchar8 ucSrtcpAuth; /*!< SRTCP Authentication - One of the IFX_VMAPI_SRTP_* values  */

	char8 acSrtcpMasterKey[IFX_VMAPI_MAX_MASTER_KEY_LEN];/*!< Master Key */
	char8 acSrtcpMasterSalt[IFX_VMAPI_MAX_MASTER_SALT_LEN];/*!< Master Salt */

	bool bEnableSrtcpMkiInd; /*!< Enable SRTCP Mki */
	uint16 unSrtcpMkiLen; /*!< SRTCP Mki len */
}x_IFX_VMAPI_ProfileMediaSecurity;
#endif /* IIP */

/*! \brief Structure defining profile parameters related to the voice stream sent via RTP.
*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */

	uchar8 ucRtpDscp; /*!< Packet Markings - Diffserv code point used for outgoing RTP packets */
	int32  iRtpVlanId; /*!< Packet Markings -  VLAN ID to be used for outgoing RTP  packets*/
	uchar8 ucRtpEthPriority; /*!< Packet Markings - Ethernet priority code to be used for outgoing RTP packets */
	
	uint16 unMinRtpPort; /*!< Port Range - Min RTP Port */
	uint16 unMaxRtpPort; /*!< Port Range - Max RTP Port */
	uint16 unMinFaxPort; /*!< Port Range - Min FAX Port */
	uint16 unMaxFaxPort; /*!< Port Range - Max FAX Port */

	uchar8 ucJbType; /*!< Jitter Buffer Type will represent 
												Fixed or Adaptive Jitter Buffers [IFX_JB_FIXED,IFX_JB_ADAPTIVE] */
	
	/*! Scaling Factor - 
	 * This shall be any value between 0 and 16
   * Only to be defined for Adaptive JB 
	 */ 
   uchar8 ucScalingFactor;
   uint16 unInitialSize; /*!< Initial size of JB  */
   uint16 unMaxSize; /*!< Max Size of JB */
   uint16 unMinSize; /*!< Min Size of JB */
}x_IFX_VMAPI_ProfileMediaRTP;

/*! \brief Structure defining Profile parameters related to the voice stream sent via RTCP.
*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
	bool bEnableRtcp; /*!< This is applicable only for a VoIP Endpoint. A IFX_TRUE
												 value indicates support for RTCP */
	/*! This is automatically calculated in the SW as per RFC */
	uint32 uiRtcpInterval;/*!< RTCP Interval Time */
  char8 acCName[IFX_VMAPI_MAX_CNAME_LEN];/*!< Local Cname (canonical name) */
}x_IFX_VMAPI_ProfileMediaRTCP;

/*! \brief Structure defining Profile parameters related to the Fax T.38 Media.
*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
	uchar8 ucProfileId; /*!< Profile Id to be used in get-set functionality */
	bool bEnableFax; /*!< Enable or disable the use of T.38. */ 
	/*! Maximum data rate for fax. Enumeration of the
   *  following values: 2400, 4800, 7200, 9600, 12000, 144000, 336000
   */
	uint32 uiBitRateTcp; 
  /*! Maximum data rate for fax. Enumeration of the
   *  following values: 2400, 4800, 7200, 9600, 12000, 144000, 336000
   */
	uint32 uiBitRateUdp; 

	/*! The rate at which high speed data will be sent across the network,
   *  in milliseconds. Enumeration of the following values: 10,20,30,40
   */
	uint32 uiHighSpeedPacketRate;

	/*! The method with which data is handled over the network. Enumeration of:
   *  "Local" and "Network" and of type IFX_VMAPI_FAX_RATE_MGMT_TCF_ */
	uchar8 ucTCFMethodTcp;

  /*! The method with which data is handled over the network. Enumeration of:
   *  "Local" and "Network" and of type IFX_VMAPI_FAX_RATE_MGMT_TCF_ */
	uchar8 ucTCFMethodUdp;

	uint16 unUDPMaxBufferSize;
  /*!< UDP Maximum buffer Size */
  uint16 unUDPMaxDatagramSize;
  /*!< UDP Maximum data-gram Size */
  uchar8 ucUDPErrCorrection;
  /*!< UDP Error Correction */

}x_IFX_VMAPI_FaxT38;



/***********************************************************/
/***************Voice Line object **************************/
/*! \brief Structure defining the Line information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucLineId; /*!<  Line Id */
  uchar8 ucProfileId;  /*!< Associated Voice Profile */
  /*! Associated Voice Interfaces -
  * List of Physical ports the line is associated with
  */
  uchar8 ucAssocVoiceInterface[2*IFX_VMAPI_MAX_VOICE_INTERFACES+1];
	/*! Directory Number associated with the line */
  char8 acDirName[IFX_VMAPI_MAX_USER_NAME_LEN];
	/*! Name of  the line */
  char8 acName[16];

/*! \brief State Enabled */
#define IFX_VMAPI_VL_STATE_ENABLED      IFX_VMAPI_VP_STATE_ENABLED
/*! \brief State Disabled */
#define IFX_VMAPI_VL_STATE_DISABLED     IFX_VMAPI_VP_STATE_DISABLED
/*! \brief State Quiescent */
#define IFX_VMAPI_VL_STATE_QUIESCENT    IFX_VMAPI_VP_STATE_QUIESCENT

  /*! Line State is one of IFX_VMAPI_VL_STATE_* */
  uchar8 ucState;
  /*! Line Status - Takes one of IFX_VMAPI_VL_STATUS_ values */
  uchar8 ucLineStatus;
	/*! Line Call Status - Takes one of IFX_VMAPI_CALL_STATUS_ values */
  uchar8 ucCallStatus;
  uchar8 ucGatewayMode; /*!< GW Mode operation */ 
	/*! Voice Line Mode: 0 if single/1 if multi*/
  uchar8 ucLineMode;
	/*! Voice Line Intrusion: 0 if not allowed/1 if allowed*/
	uchar8 ucIntrusion;
#ifdef IIP
  bool bEnableRingMute; /*!< Ring Mute Flag */
	/*! Ring Volume - Takes one of IFX_VMAPI_VOLUME_LEVEL_ values */
  uchar8 ucRingVolume;
	/*! Room Type - Takes one of IFX_VMAPI_ROOM_TYPE_ values */
  uchar8 ucRoomType;
	/*! Voice Level - Takes one of IFX_VMAPI_VOLUME_LEVEL_ values */
  uchar8 ucVoiceVol;
#endif

}x_IFX_VMAPI_VoiceLine;


/***********************************************************/
/***************Line Signalling  object **************************/

/*! \brief Structure defining the Authentication configuration */
typedef struct {
/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
   IFX_ID iid;
   uchar8 ucProfileId;/*!<  Associated Voice Profile */
   uchar8 ucLineId;  /*!<  Line Id */
   uchar8 ucIndex; /*!<  Index */
   char8 acRealm[IFX_VMAPI_MAX_DOMAIN_NAME_LEN]; /*!< Domain Name or Realm */
	 /*! SIP Authorisation User Name */
   char8 acSipAuthUsrName[IFX_VMAPI_MAX_USER_NAME_LEN];
	 /*! SIP Authorisation Password */
   char8 acSipAuthPasswd[IFX_VMAPI_MAX_USER_PASSWD_LEN];
} x_IFX_VMAPI_SipAuthCfg;

/*! \brief Structure defining the Line Signalling  information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
   IFX_ID iid;
   uchar8 ucProfileId;/*!<  Associated Voice Profile */
   uchar8 ucLineId;  /*!<  Line Id */
	 /*! SIP UserName - Same as Directory Num in TR-104 */
   char8 acSipUserName[IFX_VMAPI_MAX_USER_NAME_LEN];
   char8 acSipDispName[IFX_VMAPI_MAX_SIP_DISP_NAME_LEN];/*!<  SIP Display Name */
   //uchar8 ucNoOfSipAuthCfg; /*!< Number of Sip  Authentication */
   uint32 ucNoOfSipAuthCfg; /*!< Number of Sip  Authentication */
   //x_IFX_VMAPI_SipAuthCfg    axAuthCfg[IFX_VMAPI_MAX_AUTH_INFO]; /*!< Auth Config */
   x_IFX_VMAPI_SipAuthCfg    *pxAuthCfg; /*!< Auth Config */
} x_IFX_VMAPI_LineSignaling;



/*******************************************************************/
/***************Line  Event Subsription  object **************************/

/*! \brief Structure defining the Line Signalling  information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId; /*!<  Associated Voice Profile */
  uchar8 ucLineId; /*!<  Line Id */
  uchar8 ucIndex; /*!<  Index */

	/*! Subscription Event - Takes one of IFX_VMAPI_VL_SUBS_EVENT values */
  uint32 uiSubspnEvent;
	/*! Subscription State - Takes one of IFX_VMAPI_VL_SUBS_STATE values */
  uchar8 ucSubspnState;
	/*! SIP Subscription User Name */
  char8 acSubspnUsrName[IFX_VMAPI_MAX_USER_NAME_LEN];
	/*! SIP Subscription Password */
  char8 acSubspnPasswd[IFX_VMAPI_MAX_USER_PASSWD_LEN];
} x_IFX_VMAPI_LineEvents;

/*! \brief Structure defining the Line Suscription information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId; /*!<  Associated Voice Profile */
  uchar8 ucLineId; /*!<  Line Id */
  /*! Voice Mail requires different User Names for mail storage and retrieval.
       This may not be the case with other events. \n
       For voice mail, the retrieval user name is maintained separately
       The user name inside LineEvents can be used as the storage user name.
   */
  char8 acMwiRetrieveUsrName[IFX_VMAPI_MAX_USER_NAME_LEN];
  uint32 ucNoOfLineEvents; /*!<  Number of on-going subscriptions */
  x_IFX_VMAPI_LineEvents *pxLineEvents; /*!< Line Events */
} x_IFX_VMAPI_LineSubscription;


/*******************************************************************/
/***************Line  Codec List object **************************/

/*! \brief Structure defining the Line Codec List information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId; /*!< Associated Voice Profile */
  uchar8 ucLineId;    /*!< Line Id */
	uint32 uiNumCodecs;	/*!< Number of codecs in Codec List */
//  x_IFX_VMAPI_CodecDesc axCodecList[IFX_VMAPI_MAX_CODECS]; /*!<  Codec Table */
  x_IFX_VMAPI_CodecDesc *pxCodecList; /*!<  Codec Table */
	uint32 uiPrefG723Codec; /*!< Preferred G723 Codec used for transmission */
} x_IFX_VMAPI_LineCodecList;


#ifdef MESSAGE_SUPPORT
/***********************************************************/
/***************MESSAGE object **************************/

/*! \brief Structure defining the Message Inbox configuration */
typedef struct {
/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId;/*!<  Associated Voice Profile */
  uchar8 ucLineId;  /*!<  Line Id */
  uchar8 ucIndex;
  uint32 uiMsgHdl;
  char8 acMsg[IFX_VMAPI_MAX_MSG_LEN]; /*!< Message body */
	/*! From Remote address */
  char8 acUser[IFX_VMAPI_MAX_USER_NAME_LEN];
	/*! Message is already Read */
  bool bReadFlg;;
} x_IFX_VMAPI_MessageEntry;

/*! \brief Structure defining the Inbox message entry */
typedef x_IFX_VMAPI_MessageEntry x_IFX_VMAPI_IN_MessageEntry;
/*! \brief Structure defining the Outbox message entry */
typedef x_IFX_VMAPI_MessageEntry x_IFX_VMAPI_OUT_MessageEntry;

/*! \brief Structure defining the call register entries. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;
  uchar8 ucProfileId;/*!<  Associated Voice Profile */
  uchar8 ucLineId;  /*!<  Line Id */

  uint32 ucNoOfEntries; /*!< Number of Message Entries */
	/*! Dialed Entries */
  x_IFX_VMAPI_MessageEntry *pxMsgEntries;

}x_IFX_VMAPI_Message;

/*! \brief Structure defining the Inbox Message */
typedef x_IFX_VMAPI_Message x_IFX_VMAPI_IN_Message;
/*! \brief Structure defining the Outbox Message */
typedef x_IFX_VMAPI_Message x_IFX_VMAPI_OUT_Message;

#endif /* MESSAGE_SUPPORT */



/*******************************************************************/
/***************  Line Ring  Table  object **************************/

/*! \brief Structure defining the RingInfo  information. \n
Ringing frequency in IFX devices is configured through CRAM coefficients
There will not be any explicit configuration for the ringing frequency.\n
For the ringing, 3 different cadences are supported.
This is to support Distinctive Ringing in future.\n
The VoIP SW will not support more than 3 cadences for ringing.
Ringer On and Off Periods/Duration in millisecs.
The ringing sequence shall be RingOn1, RingOff1, RingOn2, RingOff2, ..
If a particular RingerOn and RingerOff are "0", then that cadence is 
not applicable.\n\n
TR-104 in its pattern definition for the ring, links the On and Off
periods using the NextId. In order to support that (Write access),
some link attributes are introduced below. These are needed for TR-104 alone.  
\n
*/
typedef struct {
/*
	  An Example of a mapping is given below 
	  Ring 		Index		On/Off	Duration 	Next Index
	  Normal	1			On			2s				2
	  			  2			Off		  4s				0
	  DR-1		3			On			1s				4
	  		 	  4			Off		  2s				5
	  			  5			On			1s				6
	  			  6			Off		  3s				0
	 
	  As stored internally 
	 	____________________ 
	  Normal Ring : RingOn1 = 2, RingOff1 = 4:set ts =2
   
	  DR-1 			: RingOn1 = 1,	RingOff1 = 2, RingOn2 = 1, RingOff2 = 3
	 
	  As reported by VMAPI for the NextId Field in TR-104
	  ___________________________________________________
	  Normal Ring	: ucLinkOnOff1 = 2, ucLinkOffOn12 = 0;
	  DR-1			: ucLinkOnOff1 = 4, ucLinkOffOn12 = 5;
	  				  ucLinkOnOff2 = 6, ucLinkOffOn23 = 0;
	  
	  Based on the Index used by TR-104 ACS, the corresponding 
	  "RingOn*" "RingOff*" fields shall be modified
*/
  /*! Identification for the Ring - One of IFX_VMAPI_RING_* values */
	uint32 uiRing;
	char8 acRingName[IFX_VMAPI_MAX_RING_NAME_LEN]; /*!< Ring Name */
	bool bEnableRing; /*!<  Ring Enable or Disable Flag */

	uint16 unRingOn1; /*!<  Ring On 1 */
	uint16 unRingOff1; /*!<  Ring Off 1 */

	uint16 unRingOn2; /*!<  Ring On 2 */
	uint16 unRingOff2; /*!<  Ring Off 2 */

	uint16 unRingOn3; /*!<  Ring On 1 */
	uint16 unRingOff3; /*!<  Ring Off 3 */

	uchar8 ucLinkOnOff1; /*!<  Link On/Off 1 */
	uchar8 ucLinkOffOn12; /*!<  Link On/Off 1 2 */
	uchar8 ucLinkOnOff2; /*!<  Link On/Off 2 */
	uchar8 ucLinkOffOn23; /*!<  Link On/Off 2 3 */
} x_IFX_VMAPI_RingInfo;

/*! \brief Structure defining the LineRingTable information. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
	uchar8 ucProfileId;  /*!<  Associated Voice Profile */
	uchar8 ucLineId;     /*!<  Line Id */
	uchar8 ucNoOfRings;  /*!< NoOfRings */
  /*! Array of ring information */
	x_IFX_VMAPI_RingInfo axRingInfo[IFX_VMAPI_MAX_RINGS];
} x_IFX_VMAPI_LineRingTable;


/*******************************************************************/
/*******************************************************************/
/*****************  Line  Calling  Features ************************/

/*! \brief Structure defining the Line Calling Features. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId;/*!< Associated Voice Profile */
  uchar8 ucLineId;/*!< Line Id */
  bool bEnableCid; /*!< Caller Id Enable/Disable */
  bool bEnableCidName; /*!< Caller Id Name Enable/Disable */
  char8 acCidName[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< Caller Name */
  bool bEnableCallWaiting; /*!< Caller Waiting Enable/Disable */
	/*! Call Wait Status - One of IFX_VMAPI_CALL_STATUS_* values */
  uchar8 ucCallWaitStatus; 
  uchar8 ucMaxConfSessions; /*!< Max Number of Conference Sessions */
	/*! Conference Call Status - One of IFX_VMAPI_CALL_STATUS_* values */
  uchar8 ucConfCallStatus;
  uchar8 ucConfCallSessionCount; /*!< Number of Sessions in Conference*/
  /*! Call Forward Configuration-Takes a combination of 
			"IFX_VMAPI_CALL_FWD_*" values */
  uint16 unCallFwdCfg;
  x_IFX_VMAPI_Address xCfuAddress; /*!<  Call Forward Unconditional Address */
  x_IFX_VMAPI_Address xCfbAddress; /*!<  Call Forward Busy Address */
  x_IFX_VMAPI_Address xCfnaAddress;/*!<  Call Forward No Answer Address */
  uchar8 ucCfnaRingCount; /*!<  CFNA No Ans Ring Count */
  x_IFX_VMAPI_Address  xDndAddress; /*!<  Call Forward on DND Address */
  bool bEnableCallTransfer; /*!<  Call Transfer Enable/Disable */
  bool bEnableMwiIndication; /*!<  Msg Waiting Ind Enable/Disable  */
  bool bIsMsgWaiting;/*!<  Msg Waiting Status */
  bool bEnableAcb;/*!<  Enable/Disable Anonymous Call Block */
  bool bEnableDnd; /*!<  Enable/Disable Do Not Disturb */
  bool bEnableCallRet; /*!<  Enable/Disable Call Return */
  bool bEnableRepeatDial; /*!<  Enable/Disable Automatic Redial */
  bool bFwdStatus; /*!<  Call Forward Status */
	
#ifdef IIP
  bool bExtnDialFlag;  /*!<  Extn Dial TRUE/FALSE  */
  uint16 unPrefixDigit;   /*!<  Extension prefix digit */
  /* TODO x_IFX_VMAPI_FastDial axFastDial[IFX_MAX_FAST_DIAL];*/ /*!<  Fast Dial  */
#endif
#ifdef DELAYED_HOTLINE
  bool bEnableDhl; /*!<  Enable/Disable Delayed Hotline service */
	char8 acDhlNumber[IFX_VMAPI_MAX_USER_NAME_LEN]; /*!< Delayed Hotline Number */
#endif
} x_IFX_VMAPI_LineCallingFeatures;


/*******************************************************************/
/*********************    Line    session  *************************/

/*! \brief Structure defining the  Line  Session. This is a TR104 Read Only Object*/
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
   IFX_ID iid;
   uchar8 ucProfileId; /*!<  Associated Voice Profile */
   uchar8 ucLineId; /*!<  Line Id */
	 /*!  Session Start Time */
   char8 acSessStartTime[IFX_VMAPI_MAX_TIME_STR_LEN];
   uint32 uiSessDuration;   /*!<  Session Duration, so far */
   /*! Destination IP address */
   char8 acDestAddress[IFX_VMAPI_MAX_IP_ADDRESS_LEN];
   /*! Destination Port */
   uint16 unDestPort;
   /*! Local Port */
   uint16 unLocalPort;
} x_IFX_VMAPI_LineSession;


/*******************************************************************/
/******************  Line Voice Processing *************************/
/*! \brief Structure defining the  Line Voice Processing Capabilities. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
   IFX_ID iid;
   uchar8 ucProfileId; /*!<  Associated Voice Profile */
   uchar8 ucLineId;    /*!<  Line Id */
#ifndef IIP
   bool bEnableEchoCancel; /*!<  Enable/Disable Echo Cancellation */
   uchar8 ucTxGain;           /*!<  Transmit Gain in units of 0.1 DB */
   uchar8 ucRxGain;           /*!<  Receive Gain in units of 0.1 DB */
   bool bEchoCancelInUse;  /*!<  Echo Cancellation in use */
   uchar8 ucEchoCancelTail;   /*!<  Tail Length [ms] of Echo cancellation  */
#endif
} x_IFX_VMAPI_LineVoiceProcessing;

/*******************************************************************/
/**********************   Line Codec  **************************/
/*! \brief Structure defining the  Line Codec. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId;  /*!< Associated Voice Profile */
  uchar8 ucLineId;     /*!< Line Id */
  /*! Transmitted Codecs in Session - One of IFX_VMAPI_CODEC_* values */
  uint32 uiTxCodec;
  /*! Recieved Codecs in Session - One of IFX_VMAPI_CODEC_* values */
  uint32 uiRxCodec;
  uint16 unTxBitRate;  /*!< Transmittied  Bit Rate */
  uint16 unRxBitRate;  /*!< Recieved  Bit Rate */
  bool bTxSilenceSupp;  /*!< Transmitted  Silence Suppression */
  bool bRxSilenceSupp;  /*!< Recieved  Silence Suppression */
  uint16 unFrameLen;   /*!<  Tx Packetization Period / Frame Length in [ms] */
} x_IFX_VMAPI_LineCodec;

/*******************************************************************/
/**********************   Line   Stats    **************************/

/*! \brief Structure defining the  Line  Statistics. */
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;
  uchar8 ucProfileId;  /*!<  Associated Voice Profile */
  uchar8 ucLineId;     /*!< Line Id */
  bool bResetStatistics; /*!< Reset Statistics Flag */
  /*! RTCP Statistics */
  uint32 ulPktsSent; /*!<  RTP Packets Sent */
  uint32 ulPktsRcvd; /*!<  RTP Packets Received */
  uint32 ulBytesSent; /*!<  RTP Bytes Sent */
  uint32 ulBytesRcvd; /*!<  RTP Packets Received */
  uint32 ulPktsLost; /*!<  RTP Packets Lost */
  uint32 ulRecvPktLossRate; /*!<  Rcvd Pkt loss rate % */
  uint32 ulFarEndPktLossRate; /*!<  Far end rcvd packet loss rate % */
  uint32 ulRecvInterarrivalJitter; /*!<  Current interarrival jitter in usecs */
  uint32 ulFarEndInterarrivalJitter; /*!<  Far end inter arrival jitter in usecs */
  uint32 ulRoundTripDelay; /*!<  Round trip delay in usecs */
	/*! Average rcvd inter arrival jitter in usec*/
  uint32 ulAvgRecvInterarrivalJitter;
  uint32 ulAvgFarEndInterarrivalJitter;/*!<  Far end average jitter in usecs  */
  uint32 ulAvgRoundTripDelay; /*!<  Average round trip delay in usecs */
  /*! Jitter Buffer Statistics */
  uint32 ulOverrun; /*!<  Total number of times JB has overrun */
  uint32 ulUnderrun; /*!<  Total number of times JB has underrun */
  /*! Call Statistics */
  uint32 ulIncomingCallsRcvd; /*!<  Total number of incoming calls rcvd */
  uint32 ulIncomingCallsAns; /*!<  Total number of incoming calls answered */
	/*! Total number of incoming calls completed signalling */
  uint32 ulIncomingCallsConn;
  uint32 ulIncomingCallsFail; /*!<  Total number of incoming calls failed */
  uint32 ulOutgoingCallsAttempt; /*!<  Total number of outgoing calls attempted */
  uint32 ulOutgoingCallsAns; /*!<  Total number of outgoing calls answered */
	/*!  Total number of outgoing calls completed signalling */
  uint32 ulOutgoingCallsConn;
  uint32 ulOutgoingCallsFail; /*!<  Total number of outgoing calls failed */
  uint32 ulCallsDrop; /*!< Total number of calls dropped without user termination */
  uint32 ulTotalCallTime; /*!< Cumulative call duration [sec] */
  uint32 ulServerDownTime; /*!< The duration when the SIP server was down */
} x_IFX_VMAPI_LineStats;


/*******************************************************************/
/**********************   PhysicalInterfaceTest ********************/

/*! \brief Structure defining the Physical Interface Test object */
#if 0
typedef struct {
	/*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
  IFX_ID iid;

#define IFX_VMAPI_PHYINT_TEST_STATE_LEN		24
	/*! Indicates the current test state.  Enumeration of: "None", "Requested",
	 *	"Complete", "Error_TestNotSupported".
	 */
	char8 acTestState[IFX_VMAPI_PHYINT_TEST_STATE_LEN];
#define IFX_VMAPI_PHYINT_TEST_SELECTOR		64
	/*! Indicates which test to perform.  Enumeration of:"PhoneConnectivityTest",
	 *	Vendor-specific test.
	 */
	char8 TestSelector[IFX_VMAPI_PHYINT_TEST_SELECTOR];
	/*! Indicates whether or not at least one phone associated with this
	 *  physical port is properly connected.  This parameter is applicable 
	 *  only if the Phone¬Connectivity¬Test is supported..
	 */
	bool bPhoneConnectivity;
}x_IFX_VMAPI_PhysicalInterfaceTest;
#endif

/*! \brief Structure defining the VoiceServPhyIfTest object */
typedef struct
{
				/*! Management ID to contain device specific object ID and TR-104. 
				 * Defined by Management API Framework. 
				 */
				IFX_ID iid;
				/*! Physical ports number */
				uchar8 ucPhyPortNum;
				/*! FXS Port */
#define IFX_VMAPI_VOICE_PORT_TYPE_FXS				1
				/*! Identification of Voice Interface Id */
				uchar8 ucPortType; 
				/*! Identification of Voice Interface Id */
				uchar8 ucInterfaceId;
				/*! Hazordous potential test */
#define IFX_VMAPI_VOICE_TEST_TYPE_GR909_HPT				1
				/*! Foreign Electro motive force test */
#define IFX_VMAPI_VOICE_TEST_TYPE_GR909_FEMF				2
				/*! Foreign Resistive faulttest */
#define IFX_VMAPI_VOICE_TEST_TYPE_GR909_RFT		3
				/*! Foreign receiver off hook test */
#define IFX_VMAPI_VOICE_TEST_TYPE_GR909_ROH				4
				/*! Ringer Impedance test */
#define IFX_VMAPI_VOICE_TEST_TYPE_GR909_RIT				5
				/*! GR909 All */
#define IFX_VMAPI_VOICE_TEST_TYPE_GR909_All		6
				/*! Test Type */
				uchar8 ucTestType; 
				/*! If the Test failed */
#define IFX_VMAPI_TEST_STATE_FAILURE 1
				/*! If the Test is successful */
#define IFX_VMAPI_TEST_STATE_SUCCESS 2
				/*! If the Test is in progress */
#define IFX_VMAPI_TEST_STATE_IN_PROGRESS   3
	/*! State of the Test - One of IFX_VMAPI_TEST_STATE_* values */
				uchar8 ucTestState;
} x_IFX_VMAPI_VoiceServPhyIfTest;


/* Voice Physical Interface test result */

/*! \brief Structure containing the GR909 Voltage Test Result */
typedef struct
{
/*! \brief Test Result Failure */
#define IFX_VMAPI_TEST_RESULT_FAIL      1
/*! \brief Test Result Success */
#define IFX_VMAPI_TEST_RESULT_SUCCESS   2
/*! \brief Test Not Executed */
#define IFX_VMAPI_TEST_RESULT_NOT_EXECUTED   3
   /*! Test Result - One of IFX_VMAPI_TEST_RESULT_* values */
   /* Test result Pass/Fail */
   uchar8 ucResult;
   /*! AC ring wire to ground voltage (Vrms) */
   float facr2g;
   /*! AC tip wire to ground voltage (Vrms) */
   float fact2g;
   /*! AC tip wire to ring wire voltage (Vrms) */
   float fact2r;
   /*! DC ring wire to ground voltage (V) */
   float fdcr2g;
   /*! DC tip wire to ground voltage (V) */
   float fdct2g;
   /*! DC tip wire to ring wire voltage (V) */
   float fdct2r;
} x_IFX_VMAPI_VoiceServGR909VoltResult;


/*! \brief Structure containing the GR909 Resistive Fault Test Result */
typedef struct
{
   /*! Test result Pass/Fail */
   uchar8 ucResult;
   /*! ring wire to ground (ohm) */
   float fr2g;
   /*! tip wire to ground (Ohm) */
   float ft2g;
   /*! tip wire to ring wire (Ohm) */
   float ft2r;
} x_IFX_VMAPI_VoiceServGR909RFTResult;

/*! \brief Structure containing the GR909 Receiver Ringer Impedance Test Result */
typedef struct
{
   /*! Test result Pass/Fail */
   uchar8 ucResult;
   /*! RIT value (ohm) */
   float fRit;
} x_IFX_VMAPI_VoiceServGR909RIResult;

/*! \brief Structure containing the GR909 Receiver Off hook Test Result */
typedef struct
{
   /*! Test result Pass/Fail */
   uchar8 ucResult;
   /*! tip wire to ring wire resistance value for low voltage (ohm) */
   float ft2rl;
} x_IFX_VMAPI_VoiceServGR909ROHResult;

/*! \brief Structure containing the GR909 Test Result */
typedef struct
{
   /*! FEMF Test result */
   x_IFX_VMAPI_VoiceServGR909VoltResult   xGr909FEMFVoltResult;
#if 1
   /*! HP test result */
   x_IFX_VMAPI_VoiceServGR909VoltResult   xGr909HPTVoltResult;
   /*! RF result */
   x_IFX_VMAPI_VoiceServGR909RFTResult   xGr909RFTResult;
   /*! Ringer Impedance result */
   x_IFX_VMAPI_VoiceServGR909RIResult  xGr909RIResult;
   /*! Receive Off hook Test result */
   x_IFX_VMAPI_VoiceServGR909ROHResult xGr909ROHResult;
#endif
} x_IFX_VMAPI_VoiceServGR909TestResult;

/*! \brief Structure containing the VoiceServTestResult object */
typedef struct
{
				/*! Management ID to contain device specific object ID and TR-104. 
				 * Defined by Management API Framework. 
				 */
				IFX_ID iid;

   /*! FXS Port */
   #define IFX_VMAPI_VOICE_PORT_TYPE_FXS           1
   /*! Type of port */
   uchar8 ucPortType; 
   /*! Identification of Voice Interface Id */
   uchar8 ucInterfaceId;
   /*! Hazordous potential test */
   #define IFX_VMAPI_VOICE_TEST_TYPE_GR909_HPT           1
   /*! Foreign Electro motive force test */
   #define IFX_VMAPI_VOICE_TEST_TYPE_GR909_FEMF          2
   /*! Foreign Resistive faulttest */
   #define IFX_VMAPI_VOICE_TEST_TYPE_GR909_RFT     3
   /*! Foreign receiver off hook test */
   #define IFX_VMAPI_VOICE_TEST_TYPE_GR909_ROH           4
   /*! Ringer Impedance test */
   #define IFX_VMAPI_VOICE_TEST_TYPE_GR909_RIT           5
   /*! GR909 All */
   #define IFX_VMAPI_VOICE_TEST_TYPE_GR909_All     6
   /*! Test type */
   uchar8 ucTestType; 
   //x_IFX_VMAPI_VoiceServGR909TestResult  xGr909TestResult;

	 /*! FEMF Test result */
   x_IFX_VMAPI_VoiceServGR909VoltResult   xGr909FEMFVoltResult;
#if 1
   /*! HP test result */
   x_IFX_VMAPI_VoiceServGR909VoltResult   xGr909HPTVoltResult;
   /*! RF result */
   x_IFX_VMAPI_VoiceServGR909RFTResult   xGr909RFTResult;
   /*! Ringer Impedance result */
   x_IFX_VMAPI_VoiceServGR909RIResult  xGr909RIResult;
   /*! Receive Off hook Test result */
   x_IFX_VMAPI_VoiceServGR909ROHResult xGr909ROHResult;
#endif
} x_IFX_VMAPI_VoiceServTestResult;


/*! \brief This structure represents Transmit Power Measurement Parameters for Gateway SW
*/
typedef struct
{
  /*! Management ID to contain device specific object ID and TR-104. 
	 * Defined by Management API Framework. 
	 */
	IFX_ID iid;

	uchar8 ucTuneDigitalRef; /*!< Value is calculated based on measurements and initialized from the GW */
	uchar8 ucPABiasRef; /*!<  Value is calculated based on measurements and initialized from the GW*/
	uchar8 ucPowerOffset0;/*!<Max Power -5 dB,10dB,15dB,20dB,25dB Backoff respectively. Initialized from the GW */
	uchar8 ucPowerOffset1;/*!<Max Power -5 dB,10dB,15dB,20dB,25dB Backoff respectively. Initialized from the GW */
	uchar8 ucPowerOffset2;/*!<Max Power -5 dB,10dB,15dB,20dB,25dB Backoff respectively. Initialized from the GW */
	uchar8 ucPowerOffset3;/*!<Max Power -5 dB,10dB,15dB,20dB,25dB Backoff respectively. Initialized from the GW */
	uchar8 ucPowerOffset4;/*!<Max Power -5 dB,10dB,15dB,20dB,25dB Backoff respectively. Initialized from the GW */
	uchar8 ucTD1; /*!< Value is calculated based on measurements and initialized from the GW*/
	uchar8 ucTD2; /*!< Value is calculated based on measurements and initialized from the GW*/
	uchar8 ucTD3; /*!< Value is calculated based on measurements and initialized from the GW*/
	uchar8 ucPA1; /*!< Value is calculated based on measurements and initialized from the GW*/
	uchar8 ucPA2; /*!< Value is calculated based on measurements and initialized from the GW*/
	uchar8 ucPA3; /*!< Value is calculated based on measurements and initialized from the GW*/
	
	/*! SW Power Mode  is one of the IFX_VMAPI_SW_POWERMODE_ values */
	
	uchar8 ucSWPowerMode; /*!<Tx power mode*/
	
	/*! \brief Contant power mode for all channels*/
	#define IFX_VMAPI_SW_POWERMODE_CONTANT 0x00
	/*! \brief Adaptive mode for all channels*/
	#define IFX_VMAPI_SW_POWERMODE_ADAPTIVE 0x01
        /*! \brief User mode for all channels*/
        #define IFX_VMAPI_SW_POWERMODE_USER 0x03
	
	
	/*! \brief Tx power mode for MCEI channel 0: Full Power Mode */
	#define IFX_VMAPI_MCEI_FULLPOWERMODE 0x00
	/**Tx power mode for MCEI channel 0:  5 dB Backoff Mode */
	#define IFX_VMAPI_MCEI_FIVEDB 0x10
	/*! \brief Tx power mode for MCEI channel 0:  10 dB Backoff Mode */
	#define IFX_VMAPI_MCEI_TENDB 0x20
	/*! \brief Tx power mode for MCEI channel 0:  15 dB Backoff Mode */
	#define IFX_VMAPI_MCEI_FIFTEENDB 0x30
	/*! \brief  Tx power mode for MCEI channel 0:  20 dB Backoff Mode */
	#define IFX_VMAPI_MCEI_TWENTYDB 0x40
	/*! \brief  Tx power mode for MCEI channel 0:  25 dB Backoff Mode */
	#define IFX_VMAPI_MCEI_TWENTYFIVEDB 0x50
	/*! \brief Tx power mode for MCEI channel 0:  25 dB Backoff Mode */
	#define IFX_VMAPI_MCEI_THIRTYDB 0x60
	/*! \brief Tx power mode for MCEI channel 0: Minimum Power Mode */
	#define IFX_VMAPI_MCEI_MIN_POWERMODE 0xE0
	/*! \brief  Tx power mode for MCEI channel 0: User Mode */
	#define IFX_VMAPI_MCEI_USERMODE 0xF0
   /*! \brief Tx power mode for MCEI channel 0 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_0; /*!< power mode for MCEI channel 0:*/
	
	/*! \brief Tx power mode for MCEI channel 1 is one of the  IFX_VMAPI_MCEI_values  */
       uchar8 ucTXPOW_1; /*!<Tx power mode for MCEI channel 1:*/
	
	/*! \brief Tx power mode for MCEI channel 2 is one of the  IFX_VMAPI_MCEI_values  */	
	uchar8 ucTXPOW_2; /*!<Tx power mode for MCEI channel 2:*/
	
	/*! \brief Tx power mode for MCEI channel 3 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_3; /*!<Tx power mode for MCEI channel 3:*/

	 /*! \brief Tx power mode for MCEI channel 4 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_4; /*!<Tx power mode for MCEI channel 4:*/
	
	 /*! \brief Tx power mode for MCEI channel 5 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_5; /*!<Tx power mode for MCEI channel 5:*/
	
	/*! \brief Tx power mode for the dummy bearer is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucDBPOW; /*!<Tx power mode for MCEI channel 5:*/
	/*! \brief Tx power mode for the dummy bearer is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTuneDigital; /*!<Tx power mode for MCEI channel 5:*/
	/*! \brief Tx power mode for the dummy bearer is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTxBias; /*!<Tx power mode for MCEI channel 5:*/
} x_IFX_VMAPI_TransmitPowerParam;



/*! \brief Structure containing the RFPI Value */
typedef struct
{
    /*! Management ID to contain device specific object ID and TR-104. 
            * Defined by Management API Framework.
            */
    IFX_ID iid;
    uchar8 ucByte1; /*!< RFPI Byte 1 */
    uchar8 ucByte2; /*!< RFPI Byte 2 */
    uchar8 ucByte3; /*!< RFPI Byte 3 */
    uchar8 ucByte4; /*!< RFPI Byte 4 */
    uchar8 ucByte5; /*!< RFPI Byte 5 */
    uchar8 ucByte6; /*!< RFPI Byte 6 */
} x_IFX_VMAPI_DectRfpi;



/*! \brief Structure containing the RFPI Value */
typedef struct
{
    /*! Management ID to contain device specific object ID and TR-104. 
            * Defined by Management API Framework.
            */
    IFX_ID iid;
    uchar8 ucByte1; /*!< XRAM Byte 1 */
    uchar8 ucByte2; /*!< XRAM Byte 2 */
    uchar8 ucByte3; /*!< XRAM Byte 3 */
    uchar8 ucByte4; /*!< XRAM Byte 4 */
    uchar8 ucByte5; /*!< XRAM Byte 5 */
    uchar8 ucByte6; /*!< XRAM Byte 6 */
    uchar8 ucByte7; /*!< XRAM Byte 7 */
    uchar8 ucByte8; /*!< XRAM Byte 8 */
    uchar8 ucByte9; /*!< XRAM Byte 9 */
} x_IFX_VMAPI_DectXRAM;



/*! \brief Structure defining all the BMC register parameters */
typedef struct
{
    /*! Management ID to contain device specific object ID and TR-104. 
            * Defined by Management API Framework.
            */
    IFX_ID iid;
    
    uchar8 ucDectRSSIFreeLevel; /*!< RSSI Free level value */  
    uchar8 ucDectRSSIBusyLevel; /*!< RSSI Busy level value */ 
    uchar8 ucDectBearerChgLim; /*!< Bearer Change limit for RSSI */
    uchar8 ucDectDefaultAntenna; /*!< Default Antenna Settings */ 
    uchar8 ucDectWOPNSF; /*!< Windows open sync free mode */
    uchar8 ucDectWWSF; /*!< Window width sync-free mode */ 
    uchar8 ucDectCNTUPCtrlReg; /*!< Control Register for DRON */ 
    uchar8 ucDectDelayReg; /*!< Delay Compensation */ 
    uchar8 ucDectHandOverEvalper; /*!< Handover Evaluation Period */
    uchar8 ucDectSYNCMCtrlReg; /*!< General Sync Mode Setting */
    /* Power Control */
    uchar8 ucDectReserved_0; /*!< Direct Biasing to PA1 NTP_BATTMEAS*/
    uchar8 ucDectReserved_1; /*!< Direct Biasing to PA2 NTP_TCORR*/
    uchar8 ucDectReserved_2; /*!< Internal Power Amplifier Mode NTP_ALGO*/
    uchar8 ucDectReserved_3; /*!< Power Amplifier OffsetControl NTP_OFFSET*/
 		uchar8 ucDectReserved_4; /*!<LTQ_BMCCmd_PowerLevel*/
 		uchar8 ucDectReserved_5; /*!<Algorithm*/
}x_IFX_VMAPI_DectBMCParams;    



/*! \brief Structure containing the Osc Trim values */
typedef struct
{
    /*! Management ID to contain device specific object ID and TR-104. 
            * Defined by Management API Framework.
     */
    IFX_ID iid;
    
    uchar8 ucDectOscTrimValHI; /*!< OSC Trim Byte High Value */
    uchar8 ucDectOscTrimValLOW; /*!< OSC Trim Byte Low Value */
	
    /*! \brief P1.0 PIN ON */
    #define IFX_VMAPI_DECT_OSCTRIM_P10_ON   0x01
    /*! \brief P1.0 PIN OFF */
    #define IFX_VMAPI_DECT_OSCTRIM_P10_OFF  0x11
    uchar8 ucDectP10Status; /*!< P10 Status */
}x_IFX_VMAPI_DectOscTrimVal;

/*! \brief Structure containing the GFSK values */
typedef struct
{
    /*! Management ID to contain device specific object ID and TR-104. 
            * Defined by Management API Framework.
     */
    IFX_ID iid;
    
    uchar8 ucDectGFSKHI; /*!< GFSK Byte High Value */
    uchar8 ucDectGFSKLOW; /*!< GFSK Byte Low Value */
}x_IFX_VMAPI_DectGFSKVal;

/*! \brief Structure containing the DECT Country Settings */    
typedef struct
{
    /*! Management ID to contain device specific object ID and TR-104. 
            * Defined by Management API Framework.
            */
    IFX_ID iid;
	/*! \brief Frequency Offset for EU */
    #define FREQ_OFF_EU 0x00
	/*! \brief Frequency Offset for Latin */
    #define FREQ_OFF_LATIN 0x12
	/*! \brief Frequency Offset for US */
    #define FREQ_OFF_US    0x13
   
    uchar8 ucFreqTxOffset; /*!< Frequency Tx offset[EU-0x00, Latin-0x12, US-0x12] */
    uchar8 ucFreqRxOffset; /*!< Frequency Rx offset[EU-0x00, Latin-0x12, US-0x12] */
	/*! \brief Frequency Range for EU */
    #define FREQ_RANGE_EU 0x09
	/*! \brief Frequency Range for Latin */
    #define FREQ_RANGE_LATIN 0x10
	/*! \brief Frequency Range for US */
    #define FREQ_RANGE_US 0x04
    uchar8 ucFreqRan; /*!< Frequency Range[EU-0x09, Latin-0x09, US-0x04] */
//#ifdef CVOIP_SUPPORT
		uchar8 ucEci;
		uchar8 ucChmaskHigh;
		uchar8 ucChmaskLow;
//#endif

} x_IFX_VMAPI_DectCountrySettings;     

/*! \brief Structure containing the RF Mode Settings */  
typedef struct
{
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework.
   */
   IFX_ID iid;
   /*! Tx Test Mode With Burst Signal */
   uchar8 ucTxtestmode; 
   /*! Channel */
   uchar8 ucChannel; 
   /*! Slot */
  uchar8 ucSlot; 
}x_IFX_VMAPI_RFMode;

#ifdef DECT_SENSORS_SUPPORT
/******************************* Sensor related */
/* Sensor related Data Structures */
#define LTQ_MAX_MSG_LENGTH 25
#define LTQ_MAX_TIME_STR_LEN 20
#define LTQ_MAX_SENSOR_NAME_LEN 20
/*! \brief structure defines the Sensor alaram  fields structure */
typedef struct{
  char8 acMessage[LTQ_MAX_MSG_LENGTH]; /*!< Alaram message */
  char8 acAlaramTime[LTQ_MAX_TIME_STR_LEN]; /*!<Alaram time */
}x_LTQ_SensorAlaram;

/*! \brief  Structure defining the Sensor information. */
typedef struct {
   char8 acSensorName[LTQ_MAX_SENSOR_NAME_LEN]; /*!< Name of the Sensor */
   bool bRegStatus; /* !<Sensor Registration status */
   bool bPowerStatus; /* !<Sensor Power status */
   uint32 uiInterval; /* !<Sensor Read Interval */
} x_LTQ_Sensor_Info;

/*! \brief structure defines the  Power plug Power Measurement */
typedef struct{
  uint32 uiParam1; /*!< Read param1 */
  uint32 uiParam2; /*!< Read Param2 */
  uint32 uiParam3; /*!< Read Param3 */
  char8 acMeasureTime[LTQ_MAX_TIME_STR_LEN]; /*!<Measured time */
}x_LTQ_PowerSensor_Read;

/*! \brief structure defines the Sensor alaram information */
typedef struct{
  IFX_ID iid;
  /*! Unique identifier */
  uint32 uiEntryId; /*!<Entry id */
  uint32 uiSensorId; /*!< Sensor id */
  uchar8 ucIndex;
  x_LTQ_SensorAlaram xAlaram;
}x_LTQ_SensorAlaram_Entry;

typedef struct{
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework. 
   */
  IFX_ID iid;
  uint32 uiSensorId; /*!< Sensor id */
  uint32 ucNoOfEntries; /*!< Number of Alaram Entries */
  x_LTQ_SensorAlaram_Entry *pxAlaramEntries; /* !<Alaram entries */
}x_LTQ_SensorAlaram_List;

/*! \brief Structure defining the  Sensor List Entry. */
typedef struct {
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework. 
   */
  IFX_ID iid;
  /*! Unique identifier */
  uint32 uiEntryId;
  uchar8 ucIndex;
	uint32 uiBatteryLevel; /* !<Sensor battery level */
  x_LTQ_Sensor_Info xSensorInfo;/*!<  Sensor Information */
} x_LTQ_SensorList_Entry;

/*! \brief Structure defining the General Settings  for Motion/Smoke sensor list*/
typedef struct {
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework. 
   */
  IFX_ID iid;
  uint32 ucNoOfEntries; /*!< Number of motion/smoke sensor's in a List */
  uchar8 ucPresetNum[LTQ_MAX_SENSOR_NAME_LEN]; /*<!Preset number */
  bool bAllPowerOn;/* !< All sensor power on */
  bool bToneAlaram; /* !<All Sensor tone alaram */
  x_LTQ_SensorList_Entry *pxSensorEntries;
}x_LTQ_SensorList;

typedef x_LTQ_SensorList  x_LTQ_VMAPI_SensorList;
typedef x_LTQ_SensorList_Entry  x_LTQ_VMAPI_SensorList_Entry;
typedef x_LTQ_SensorList x_LTQ_MotionSensorList;
typedef x_LTQ_SensorList x_LTQ_SmokeSensorList;


typedef x_LTQ_SensorAlaram_Entry x_LTQ_VMAPI_SensorAlaram_Entry;
typedef x_LTQ_SensorAlaram_List x_LTQ_VMAPI_SensorAlaram_List;

/* Power Plug device data structures */


/*! \brief structure defines the  Power plug Power Measurement */
typedef struct{
  IFX_ID iid;
  /*! Unique identifier */
  uint32 uiEntryId; /*!<Entry id */
  uint32 uiSensorId; /*!< Sensor id */
  uchar8 ucIndex;
  x_LTQ_PowerSensor_Read xPowerRead;
}x_LTQ_PowerSensor_ReadEntry;

/* Power Plug measurments register/List */

typedef struct{
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework. 
   */
  IFX_ID iid;
  uint32 uiSensorId; /*!< Sensor id */
  uint32 ucNoOfEntries; /*!< Number of Alaram Entries */
  x_LTQ_PowerSensor_ReadEntry *pxPowEntries; /* !<Alaram entries */
}x_LTQ_PowerSensor_ReadList;


/*! \brief Structure defining the  Power Sensor List Entry. */
typedef struct {
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework. 
   */
  IFX_ID iid;
  /*! Unique identifier */
  uint32 uiEntryId;
  uchar8 ucIndex;
  x_LTQ_Sensor_Info xSensorInfo;/*!<  Sensor Information */
} x_LTQ_PowerSensorEntry;

/*! \brief Structure defining the General Settings  for Motion/Smoke sensor list*/
typedef struct {
  /*! Management ID to contain device specific object ID and TR-104. 
   * Defined by Management API Framework. 
   */
  IFX_ID iid;
  bool bAllPowerOn;/* !< All sensor power on */
  uint32 ucNoOfEntries; /*!< Number of motion/smoke sensor's in a List */
  x_LTQ_PowerSensorEntry *pxSensorEntries;
}x_LTQ_PowerSensorList;
typedef x_LTQ_PowerSensorEntry x_LTQ_VMAPI_PowerSensor_Entry;
typedef x_LTQ_PowerSensorList x_LTQ_VMAPI_PowerSensor_List;
typedef x_LTQ_PowerSensor_ReadEntry x_LTQ_VMAPI_PowerSensor_ReadEntry;
typedef x_LTQ_PowerSensor_ReadList x_LTQ_VMAPI_PowerSensor_ReadList;

#endif

/* VMAPI_OBJS doxygen comment ends*/
/* @} */

#ifdef __cplusplus
}
#endif

#endif /* __IFX_VMAPI_H__ */
