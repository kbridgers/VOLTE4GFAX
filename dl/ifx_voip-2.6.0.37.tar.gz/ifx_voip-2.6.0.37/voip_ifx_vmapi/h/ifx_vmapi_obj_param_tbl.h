/**************************************************************************
 **   FILE NAME       : ifx_vmapi_obj_param_tbl.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Voice Management API 
 **   SRC VERSION     : V0.1
 **   DATE            : 20-06-2006
 **   AUTHOR          : Prashant, Pallav
 **   DESCRIPTION     : This file defines the Object and Parameter tables 
 **                     to be used for Binary to Text conversion and vice versa
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright � 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_VMAPI_OBJ_PARAM_TBL_H__
#define __IFX_VMAPI_OBJ_PARAM_TBL_H__

#ifdef __cplusplus
extern "C" {
#endif

/*! \file ifx_vmapi_obj_param_tbl.h
    \brief This file contains the Constants, related Data structures for VMAPI
Object and Parameter Tables for Binary-to-Text and Text-to-Binary conversions.
*/

/** \defgroup VMAPI_OBJ_PARAM_MACROS  Macros used in Object and Parameter Tables
These macros define the object and parameter identifiers. unObjId and unParamCode are set to these macros in the object and parameter tables.\n
"IFX_VMAPI_OBJ_*" - These macros represent the integer object codes. unObjId field is set to these macros in the object table.\n
"IFX_VMAPI_OBJ_NAME_*" - These macros represent the object names. Object names are stored as section names in the configuration files. The acName field in object table stores one of these values.\n
"IFX_VMAPI_OBJ_PREF_*" - These macros represent the object prefixes. Object prefixes are prepended to the object parameters before storing them in the configuration file. The acPrefix field in the object table stores one of these values.\n
"IFX_VMAPI_PARAM_CODE_*" and "IFX_VMAPI_PARAM_NAME_*"
These macros represent the parameter id and parameter names of the object parameters.They are stored in the parameter tables in unParamCode and acName fields
respectively.
\par
See the source code file ifx_vmapi_obj_param_tbl.h for these macro definitions.
*/

/** \ingroup VMAPI_OBJ_PARAM_MACROS Object identifiers - IFX_VMAPI_OBJ_\*
These macros represent the integer object codes. unObjId field is set to these macros in the object table.
*/
/* @{ */
/* Object Codes */
#define IFX_VMAPI_OBJ_VOICE_SYSTEM        1
#define IFX_VMAPI_OBJ_GW_CFG              2
#define IFX_VMAPI_OBJ_VER_REG             3
#define IFX_VMAPI_OBJ_DBG_TYPE            4
#define IFX_VMAPI_OBJ_DBG_SET             5
#define IFX_VMAPI_OBJ_TEL_URI             6
                                        

#define IFX_VMAPI_OBJ_VL_CODECLIST        7
#define IFX_VMAPI_OBJ_CODEC_DESC          8

#define IFX_VMAPI_OBJ_VOICE_CAPABS        9

#define IFX_VMAPI_OBJ_SIP_CAPABS          10

#define IFX_VMAPI_OBJ_SER_PROVIDER        11
                                             
#define IFX_VMAPI_OBJ_VP_SIGNALING        12
                                             
#define IFX_VMAPI_OBJ_VP_MEDIA_SEC        13

#define IFX_VMAPI_OBJ_RTP                 14

#define IFX_VMAPI_OBJ_RTCP                15

#define IFX_VMAPI_OBJ_VOICE_PROFILE       16
#define IFX_VMAPI_OBJ_STUN_CFG            17

#define IFX_VMAPI_OBJ_PHY_IFACE           18

#define IFX_VMAPI_OBJ_VOICE_LINE          19

#define IFX_VMAPI_OBJ_VL_SIGNALING        20
#define IFX_VMAPI_OBJ_AUTHCFG             21

#define IFX_VMAPI_OBJ_CODEC_CAPABS        22
#define IFX_VMAPI_OBJ_CODEC_CAPABS_ENTRY  23

#define IFX_VMAPI_OBJ_VL_CALLFEAT         24
#define IFX_VMAPI_OBJ_ADDR_TYPE           25
#define IFX_VMAPI_OBJ_CALLBLOCK_ENTRY     26

#define IFX_VMAPI_OBJ_VL_VOICE_SESSION    27

#define IFX_VMAPI_OBJ_VL_VOICE_PROCESSING 28

#define IFX_VMAPI_OBJ_VL_VOICE_CODEC      29

#define IFX_VMAPI_OBJ_VOICE_SERVICE				30

#define IFX_VMAPI_OBJ_LINE_STATS					31
#define IFX_VMAPI_OBJ_FAX									32
#define IFX_VMAPI_OBJ_T38									33
#define IFX_VMAPI_OBJ_NUMPLAN							34
#define IFX_VMAPI_OBJ_NUMPLAN_RULE				35

#define IFX_VMAPI_OBJ_ADDRBOOK						36
#define IFX_VMAPI_OBJ_ADDRBOOK_ENTRY			37

#define IFX_VMAPI_OBJ_CALLREGISTER_DIAL		38
#define IFX_VMAPI_OBJ_CALLREG_DIALENTRY		39

#define IFX_VMAPI_OBJ_LINESUB							40
#define IFX_VMAPI_OBJ_LINEEVENTS					41

#define IFX_VMAPI_OBJ_MISC							  42

#define IFX_VMAPI_OBJ_FXOPHYINT					  43
#define IFX_VMAPI_OBJ_FXSPHYINT					  44

#define IFX_VMAPI_OBJ_PROFEVENT					  45
#define IFX_VMAPI_OBJ_PROFEVENT_SUBSCR		46

#define IFX_VMAPI_OBJ_CALLBK					    47
#define IFX_VMAPI_OBJ_CALLBK_ENTRY			  48

#define IFX_VMAPI_OBJ_CALLREGISTER_MISS		49
#define IFX_VMAPI_OBJ_CALLREG_MISSENTRY	  50

#define IFX_VMAPI_OBJ_CALLREGISTER_RECV		51
#define IFX_VMAPI_OBJ_CALLREG_RECVENTRY	  52

#define IFX_VMAPI_OBJ_DECT								53
#define IFX_VMAPI_OBJ_DECT_HANDSET				54
#define IFX_VMAPI_OBJ_DECT_CODEC_DESC     55
#define IFX_VMAPI_OBJ_DECT_SUBSINFO				56

/* Physical Interface GR909 Line Testing Objects */
#define IFX_VMAPI_OBJ_PHY_INT_TEST				57
#define IFX_VMAPI_OBJ_PHY_INT_TEST_RES		58
//#define IFX_VMAPI_OBJ_PHY_INT_GR909_RES		60
#define IFX_VMAPI_OBJ_PHY_INT_GR909_VOLT_RES		59
#define IFX_VMAPI_OBJ_PHY_INT_GR909_RFT_RES		60
#define IFX_VMAPI_OBJ_PHY_INT_GR909_RIT_RES		61
#define IFX_VMAPI_OBJ_PHY_INT_GR909_ROH_RES		62

#define IFX_VMAPI_OBJ_DECT_TRANS_POWER	  63
#define IFX_VMAPI_OBJ_DECT_RF_MODE        64
#define IFX_VMAPI_OBJ_DECT_RFPI           65
#define IFX_VMAPI_OBJ_DECT_COUNTRY_SETTINGS 66
#define IFX_VMAPI_OBJ_DECT_BMC_REG_PARAMS 67
#define IFX_VMAPI_OBJ_DECT_OSC_TRIM       68
#define IFX_VMAPI_OBJ_DECT_GFSK           69
#define IFX_VMAPI_OBJ_DECT_XRAM          70


#define IFX_VMAPI_OBJ_PSTN_CALLREGISTER_MISS		71
#define IFX_VMAPI_OBJ_PSTN_CALLREG_MISSENTRY	  72
 
#define IFX_VMAPI_OBJ_PSTN_CALLREGISTER_DIAL		73
#define IFX_VMAPI_OBJ_PSTN_CALLREG_DIALENTRY	  74

#define IFX_VMAPI_OBJ_PSTN_CALLREGISTER_RECV		75
#define IFX_VMAPI_OBJ_PSTN_CALLREG_RECVENTRY	  76

#define IFX_VMAPI_OBJ_CONTACT_LIST		77
#define IFX_VMAPI_OBJ_CONTACT_LIST_ENTRY	 78
#define IFX_VMAPI_OBJ_CONTACT_ADDR          79

#define IFX_VMAPI_OBJ_PSTN_CONTACT_LIST	80	
#define IFX_VMAPI_OBJ_PSTN_CONTACT_LIST_ENTRY	81 

#define IFX_VMAPI_OBJ_COMMON_CONTACT_LIST	82	
#define IFX_VMAPI_OBJ_COMMON_CONTACT_LIST_ENTRY	83 
#ifdef DECT_SENSORS_SUPPORT


#define IFX_VMAPI_OBJ_MOTION_SENSOR_LIST 84
#define IFX_VMAPI_OBJ_MOTION_SENSOR_ENTRY 85
#define IFX_VMAPI_OBJ_MOTION_SENSOR_ALARAM_LIST 86 
#define IFX_VMAPI_OBJ_MOTION_SENSOR_ALARAM_ENTRY 87 

#define IFX_VMAPI_OBJ_SMOKE_SENSOR_LIST 88
#define IFX_VMAPI_OBJ_SMOKE_SENSOR_ENTRY 89
#define IFX_VMAPI_OBJ_SMOKE_SENSOR_ALARAM_LIST 90 
#define IFX_VMAPI_OBJ_SMOKE_SENSOR_ALARAM_ENTRY 91 

#define IFX_VMAPI_OBJ_POWER_SENSOR_LIST 92
#define IFX_VMAPI_OBJ_POWER_SENSOR_ENTRY 93
#define IFX_VMAPI_OBJ_POWER_SENSOR_READ_LIST 94
#define IFX_VMAPI_OBJ_POWER_SENSOR_READ_ENTRY 95

#define IFX_VMAPI_OBJ_SENSOR_INFO 96 
#define IFX_VMAPI_OBJ_SENSOR_ALARAM_INFO 97 
#define IFX_VMAPI_OBJ_POWER_READ_INFO 98 

#define IFX_VMAPI_OBJ_MESSAGE_IN  99  
#define IFX_VMAPI_OBJ_MESSAGE_IN_ENTRY   100 
#define IFX_VMAPI_OBJ_MESSAGE_OUT 101  
#define IFX_VMAPI_OBJ_MESSAGE_OUT_ENTRY  102 

#define IFX_VMAPI_MAX_OBJECTS           103 

#else
#define IFX_VMAPI_OBJ_MESSAGE_IN	84	
#define IFX_VMAPI_OBJ_MESSAGE_IN_ENTRY	 85 

#define IFX_VMAPI_OBJ_MESSAGE_OUT	86	
#define IFX_VMAPI_OBJ_MESSAGE_OUT_ENTRY	 87 

#define IFX_VMAPI_MAX_OBJECTS         	88	
#endif

/* @} */

/** \ingroup VMAPI_OBJ_PARAM_MACROS Object Names - IFX_VMAPI_OBJ_NAME_\*
These macros represent the object names. Object names are stored as section names in the configuration files. The acName field in object table stores one of these values.
*/
/* @{ */
/*************************************************************/
/*************************************************************/
/* Object Names - Used as Section Names */

#define IFX_VMAPI_OBJ_NAME_VOICE_SERVICE			"VoiceService"
#define IFX_VMAPI_OBJ_NAME_VOICE_SYSTEM       "VoiceSystem"
#define IFX_VMAPI_OBJ_NAME_GW_CFG             "GatewayCfg"
#define IFX_VMAPI_OBJ_NAME_VER_REG            "VersionReg"
#define IFX_VMAPI_OBJ_NAME_DBG_TYPE           "DbgType"
#define IFX_VMAPI_OBJ_NAME_DBG_SET            "DbgSetting"
#define IFX_VMAPI_OBJ_NAME_TEL_URI            "Tel-Uri"

#define IFX_VMAPI_OBJ_NAME_CODEC_CAPABS       "CodecCapabilities"
#define IFX_VMAPI_OBJ_NAME_CODEC_CAPABS_ENTRY "CodCapEntry"


#define IFX_VMAPI_OBJ_NAME_VOICE_CAPABS       "VoiceCapabilities"
#define IFX_VMAPI_OBJ_NAME_SIP_CAPABS         "SipCapabilities"

#define IFX_VMAPI_OBJ_NAME_VP_EVENTTBL        "VoiceProfileEventTBL"  
#define IFX_VMAPI_OBJ_NAME_VP_EVENT           "VoiceProfileEvent"  

#define IFX_VMAPI_OBJ_NAME_VP_RSPMAPTBL       "VoiceProfileRspMapTbl"
#define IFX_VMAPI_OBJ_NAME_VP_RSPMAP          "VoiceProfileRspMap"

#define IFX_VMAPI_OBJ_NAME_SER_PROVIDER       "ServiceProvider"

#define IFX_VMAPI_OBJ_NAME_VP_SIGNALING       "VoiceProfileSignaling"

#define IFX_VMAPI_OBJ_NAME_VP_MEDIA_SEC       "MediaSec"

#define IFX_VMAPI_OBJ_NAME_RTP                "MediaRTPAttributes"

#define IFX_VMAPI_OBJ_NAME_RTCP               "MediaRTCPAttributes"

#define IFX_VMAPI_OBJ_NAME_VOICE_PROFILE      "VoiceProfile"
#define IFX_VMAPI_OBJ_NAME_STUN_CFG           "StunCfg"

#define IFX_VMAPI_OBJ_NAME_PHY_IFACE          "PhysicalInterface"

#define IFX_VMAPI_OBJ_NAME_VOICE_LINE         "VoiceLine"

#define IFX_VMAPI_OBJ_NAME_VL_SIGNALING       "VoiceLineSignaling"
#define IFX_VMAPI_OBJ_NAME_AUTHCFG            "AuthCfg"

#define IFX_VMAPI_OBJ_NAME_VL_CODECLIST       "LineCodecList"
#define IFX_VMAPI_OBJ_NAME_CODEC_DESC		      "List"

#define IFX_VMAPI_OBJ_NAME_VL_CALLFEAT        "VoiceLineCallFeat"
#define IFX_VMAPI_OBJ_NAME_ADDR_TYPE          "AddressType"
#define IFX_VMAPI_OBJ_NAME_CALLBLOCK_ENTRY    "CallBlockEntry"

#define IFX_VMAPI_OBJ_NAME_VL_VOICE_SESSION   "VoiceLineSession"

#define IFX_VMAPI_OBJ_NAME_VL_VOICE_PROCESSING "VoiceLineVoiceProcessing"

#define IFX_VMAPI_OBJ_NAME_VL_VOICE_CODEC      "VoiceLineVoiceCodec"

#define IFX_VMAPI_OBJ_NAME_LINE_STATS					"LineStats"
#define IFX_VMAPI_OBJ_NAME_FAX								"Fax"
#define IFX_VMAPI_OBJ_NAME_T38								"T38"

#define IFX_VMAPI_OBJ_NAME_NUMPLAN						"NumPlan"
#define IFX_VMAPI_OBJ_NAME_NUMPLAN_RULE				"NumPlanRules"

#define IFX_VMAPI_OBJ_NAME_ADDRBOOK						"AddrBook"
#define IFX_VMAPI_OBJ_NAME_ADDRBOOK_ENTRY			"AddrEntry"

#define IFX_VMAPI_OBJ_NAME_CALLREGISTER_DIAL	"DialCallReg"
#define IFX_VMAPI_OBJ_NAME_CALLREG_DIALENTRY	"DialEntry"
#define IFX_VMAPI_OBJ_NAME_LINESUB						"LineSubscription"
#define IFX_VMAPI_OBJ_NAME_LINEEVENTS					"LineSubEvent"

#define IFX_VMAPI_OBJ_NAME_MISC								"Miscellaneous"
#define IFX_VMAPI_OBJ_NAME_FXOPHYINT					"FxophyInterface"
#define IFX_VMAPI_OBJ_NAME_FXSPHYINT					"FxsphyInterface"
#define IFX_VMAPI_OBJ_NAME_PROFEVENT					"ProfileEvent"
#define IFX_VMAPI_OBJ_NAME_PROFEVENT_SUBSCR		"EventSubscribe"
#define IFX_VMAPI_OBJ_NAME_CALLBK							"CallBlock"
#define IFX_VMAPI_OBJ_NAME_CALLBK_ENTRY				"CallBlockEntry"
#define IFX_VMAPI_OBJ_NAME_CALLREGISTER_MISS	"MissCallReg"
#define IFX_VMAPI_OBJ_NAME_CALLREG_MISSENTRY	"MissEntry"

#define IFX_VMAPI_OBJ_NAME_CALLREGISTER_RECV	"RecvCallReg"
#define IFX_VMAPI_OBJ_NAME_CALLREG_RECVENTRY	"RecvEntry"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_TEST				"PhyIntTest"
#define IFX_VMAPI_OBJ_NAME_DECT								"Dect"
#define IFX_VMAPI_OBJ_NAME_DECT_HANDSET				"DectHandset"
#define IFX_VMAPI_OBJ_NAME_DECT_CODEC_DESC		"DectCodec"
#define IFX_VMAPI_OBJ_NAME_DECT_SUBSINFO			"DectSubInfo"


#define IFX_VMAPI_OBJ_NAME_PHY_INT_TEST				"PhyIntTest"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_TEST_RES		"PhyIntTestRes"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_GR909_RES		"GR909Res"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_GR909_VOLT_RES		"VoltRes"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_GR909_RFT_RES		"Rft"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_GR909_RIT_RES		"Rit"
#define IFX_VMAPI_OBJ_NAME_PHY_INT_GR909_ROH_RES		"Roh"


#define IFX_VMAPI_OBJ_NAME_TRANS_POWER	        "TransPower"
#define IFX_VMAPI_OBJ_NAME_RF_MODE              "Rfmode"
#define IFX_VMAPI_OBJ_NAME_RFPI                 "Rfpi"
#define IFX_VMAPI_OBJ_NAME_COUNTRY_SETTINGS     "CtrySet"
#define IFX_VMAPI_OBJ_NAME_BMC_REG_PARAMS       "BmcParams"
#define IFX_VMAPI_OBJ_NAME_OSC_TRIM             "Osctrim"
#define IFX_VMAPI_OBJ_NAME_GFSK                 "Gfsk"
#define IFX_VMAPI_OBJ_NAME_XRAM                 "Xram"

#define IFX_VMAPI_OBJ_NAME_MESSAGE_IN		      "MsgIn"
#define IFX_VMAPI_OBJ_NAME_MESSAGE_IN_ENTRY	  "MsgInEntry"

#define IFX_VMAPI_OBJ_NAME_MESSAGE_OUT		      "MsgOut"
#define IFX_VMAPI_OBJ_NAME_MESSAGE_OUT_ENTRY	  "MsgOutEntry"

#define IFX_VMAPI_OBJ_NAME_CONTACT_LIST             "ContactList" 
#define IFX_VMAPI_OBJ_NAME_CONTACT_LIST_ENTRY       "ContactEntry"   
#define IFX_VMAPI_OBJ_NAME_CONTACT_ADDR        "ContactInfo"

#define IFX_VMAPI_OBJ_NAME_PSTN_CALLREGISTER_MISS	"PstnMissCallReg"
#define IFX_VMAPI_OBJ_NAME_PSTN_CALLREG_MISSENTRY	"PstnMissEntry"

#define IFX_VMAPI_OBJ_NAME_PSTN_CALLREGISTER_DIAL	"PstnDialCallReg"
#define IFX_VMAPI_OBJ_NAME_PSTN_CALLREG_DIALENTRY	"PstnDialEntry"

#define IFX_VMAPI_OBJ_NAME_PSTN_CALLREGISTER_RECV	"PstnRecvCallReg"
#define IFX_VMAPI_OBJ_NAME_PSTN_CALLREG_RECVENTRY	"PstnRecvEntry"

#define IFX_VMAPI_OBJ_NAME_PSTN_CONTACT_LIST             "PstnContactList" 
#define IFX_VMAPI_OBJ_NAME_PSTN_CONTACT_LIST_ENTRY       "PstnContactEntry"   

#define IFX_VMAPI_OBJ_NAME_COMMON_CONTACT_LIST             "CommonContactList" 
#define IFX_VMAPI_OBJ_NAME_COMMON_CONTACT_LIST_ENTRY       "CommonContactEntry"   
/* @} */

/** \ingroup VMAPI_OBJ_PARAM_MACROS Object Prefix - IFX_VMAPI_OBJ_PREF_\*
These macros represent the object prefixes. Object prefixes are prepended to the object parameters before storing them in the configuration file. The acPrefix field in the object table stores one of these values.
*/
/* @{ */
/*************************************************************/
/*************************************************************/
/* Object Prefixes for Parameter Names */

#define IFX_VMAPI_OBJ_PREF_VOICE_SERVICE	IFX_VMAPI_OBJ_NAME_VOICE_SERVICE
#define IFX_VMAPI_OBJ_PREF_VOICE_SYSTEM    "System"
#define IFX_VMAPI_OBJ_PREF_GW_CFG          "GwCfg"
#define IFX_VMAPI_OBJ_PREF_VER_REG        "VerReg"
#define IFX_VMAPI_OBJ_PREF_DBG_TYPE        "DbgType"
#define IFX_VMAPI_OBJ_PREF_DBG_SET        "DbgSetting"
#define IFX_VMAPI_OBJ_PREF_TEL_URI        "TelUri"

#define IFX_VMAPI_OBJ_PREF_CODEC_CAPABS    "CodCap"
#define IFX_VMAPI_OBJ_PREF_CODEC_CAPABS_ENTRY    "CodecEntry"

#define IFX_VMAPI_OBJ_PREF_VOICE_CAPABS    "VoiceCap"

#define IFX_VMAPI_OBJ_PREF_SIP_CAPABS     "SipCap"

#define IFX_VMAPI_OBJ_PREF_VP_EVENTTBL    "ProfEventTbl"  
#define IFX_VMAPI_OBJ_PREF_VP_EVENT       "Event"  

#define IFX_VMAPI_OBJ_PREF_VP_RSPMAPTBL   "ProfRspMapTbl"
#define IFX_VMAPI_OBJ_PREF_VP_RSPMAP      "RspMap"

#define IFX_VMAPI_OBJ_PREF_SER_PROVIDER   "SerProvider"

#define IFX_VMAPI_OBJ_PREF_VP_MEDIA_SEC   "MediaSec"

#define IFX_VMAPI_OBJ_PREF_VP_SIGNALING   "ProfSignal"

#define IFX_VMAPI_OBJ_PREF_VP_FAX         "ProfileFax"

#define IFX_VMAPI_OBJ_PREF_RTP            "RTP"
#define IFX_VMAPI_OBJ_PREF_RTCP           "RTCP"

#define IFX_VMAPI_OBJ_PREF_VOICE_PROFILE  "Profile"
#define IFX_VMAPI_OBJ_PREF_STUN_CFG       "Stun"

#define IFX_VMAPI_OBJ_PREF_PHY_IFACE      "PhysicalInterface"

#define IFX_VMAPI_OBJ_PREF_VOICE_LINE     "Line"

#define IFX_VMAPI_OBJ_PREF_VL_SIGNALING   "LineSignal"
#define IFX_VMAPI_OBJ_PREF_AUTHCFG        "AuthCfg"

#define IFX_VMAPI_OBJ_PREF_VL_CODECLIST   "LineCodec"
#define IFX_VMAPI_OBJ_PREF_CODEC_DESC     "List"

#define IFX_VMAPI_OBJ_PREF_VL_CALLFEAT    "LineCallFeat"
#define IFX_VMAPI_OBJ_PREF_ADDR_TYPE      "AddressType"
#define IFX_VMAPI_OBJ_PREF_CALLBLOCK_ENTRY      "CallBlockEntry"

#define IFX_VMAPI_OBJ_PREF_VL_VOICE_SESSION     "VL_Session"

#define IFX_VMAPI_OBJ_PREF_VL_VOICE_PROCESSING  "VL_Processing"

#define IFX_VMAPI_OBJ_PREF_VL_VOICE_CODEC       "LineVoiceCodec"
#define IFX_VMAPI_OBJ_PREF_LINE_STATS           "LineStats"

#define IFX_VMAPI_OBJ_PREF_VS_T38              "SystemT38"

#define IFX_VMAPI_OBJ_PREF_VS_NUMPLAN						"NumberingPlan"
#define IFX_VMAPI_OBJ_PREF_VS_NUMPLAN_RULE			"NumPlanRules"

#define IFX_VMAPI_OBJ_PREF_VS_ADDRBOOK					"AddressBook"
#define IFX_VMAPI_OBJ_PREF_VS_ADDRBOOK_ENTRY		"AddrEntry"

#define IFX_VMAPI_OBJ_PREF_VS_CALLREGISTER_DIAL	"DialCallReg"
#define IFX_VMAPI_OBJ_PREF_VS_CALLREG_DIALENTRY	"DialEntry"
/* @} */
#define IFX_VMAPI_OBJ_PREF_VL_LINESUB						"LineSub"
#define IFX_VMAPI_OBJ_PREF_VL_LINEEVENTS				"LineSubEvent"

#define IFX_VMAPI_OBJ_PREF_VS_MISC							"Misc"
#define IFX_VMAPI_OBJ_PREF_FXOPHYINT						"FxoPhyInf"
#define IFX_VMAPI_OBJ_PREF_FXSPHYINT						"FxsPhyInf"
#define IFX_VMAPI_OBJ_PREF_PROFEVENT						"ProfEvent"
#define IFX_VMAPI_OBJ_PREF_PROFEVENT_SUBSCR			"EventSubscribe"
#define IFX_VMAPI_OBJ_PREF_CALLBK								"CallBk"
#define IFX_VMAPI_OBJ_PREF_CALLBK_ENTRY					"CallBlockEntry"

#define IFX_VMAPI_OBJ_PREF_CALLREGISTER_MISS		"MissCallReg"
#define IFX_VMAPI_OBJ_PREF_CALLREG_MISSENTRY	  "MissEntry"
#define IFX_VMAPI_OBJ_PREF_CALLREGISTER_RECV		"RecvCallReg"
#define IFX_VMAPI_OBJ_PREF_CALLREG_RECVENTRY	  "RecvEntry"
#define IFX_VMAPI_OBJ_PREF_DECT	                "Dect"
#define IFX_VMAPI_OBJ_PREF_DECT_HANDSET	        "DectHandset"
#define IFX_VMAPI_OBJ_PREF_DECT_CODEC_DESC      "DectCodec"
#define IFX_VMAPI_OBJ_PREF_DECT_SUBSINFO				"DectSubInfo"


#define IFX_VMAPI_OBJ_PREF_PHY_INT_TEST				"PhyIntTest"
#define IFX_VMAPI_OBJ_PREF_PHY_INT_TEST_RES		"TestRes"
#define IFX_VMAPI_OBJ_PREF_PHY_INT_GR909_RES		"GR909Res"
#define IFX_VMAPI_OBJ_PREF_PHY_INT_GR909_VOLT_RES		"VoltRes"
#define IFX_VMAPI_OBJ_PREF_PHY_INT_GR909_RFT_RES		"Rft"
#define IFX_VMAPI_OBJ_PREF_PHY_INT_GR909_RIT_RES		"Rit"
#define IFX_VMAPI_OBJ_PREF_PHY_INT_GR909_ROH_RES		"Roh"


#define IFX_VMAPI_OBJ_PREF_TRANS_POWER	        "TransPower"
#define IFX_VMAPI_OBJ_PREF_RF_MODE              "Rfmode"
#define IFX_VMAPI_OBJ_PREF_RFPI                 "Rfpi"
#define IFX_VMAPI_OBJ_PREF_COUNTRY_SETTINGS     "CtrySet"
#define IFX_VMAPI_OBJ_PREF_BMC_REG_PARAMS       "BmcParams"
#define IFX_VMAPI_OBJ_PREF_OSC_TRIM	            "Osctrim"
#define IFX_VMAPI_OBJ_PREF_GFSK	                "Gfsk"
#define IFX_VMAPI_OBJ_PREF_XRAM                 "Xram"

#define IFX_VMAPI_OBJ_PREF_MESSAGE_IN		      "MsgIn"
#define IFX_VMAPI_OBJ_PREF_MESSAGE_IN_ENTRY	  "MsgInEntry"

#define IFX_VMAPI_OBJ_PREF_MESSAGE_OUT		      "MsgOut"
#define IFX_VMAPI_OBJ_PREF_MESSAGE_OUT_ENTRY	  "MsgOutEntry"

#define IFX_VMAPI_PARAM_CODE_CPE_ID   					0
#define IFX_VMAPI_PARAM_NAME_CPE_ID   					"cpeId"

#define IFX_VMAPI_PARAM_CODE_PCPE_ID  					1
#define IFX_VMAPI_PARAM_NAME_PCPE_ID   					"pcpeId"

#define IFX_VMAPI_OBJ_PREF_CONTACT_LIST             "ContactList" 
#define IFX_VMAPI_OBJ_PREF_CONTACT_LIST_ENTRY       "ContactEntry"
#define IFX_VMAPI_OBJ_PREF_CONTACT_ADDR       "ContactInfo"

#define IFX_VMAPI_OBJ_PREF_PSTN_CALLREGISTER_MISS		"PstnMissCallReg"
#define IFX_VMAPI_OBJ_PREF_PSTN_CALLREG_MISSENTRY	  "PstnMissEntry"


#define IFX_VMAPI_OBJ_PREF_PSTN_CALLREGISTER_DIAL		"PstnDialCallReg"
#define IFX_VMAPI_OBJ_PREF_PSTN_CALLREG_DIALENTRY	  "PstnDialEntry"


#define IFX_VMAPI_OBJ_PREF_PSTN_CALLREGISTER_RECV		"PstnRecvCallReg"
#define IFX_VMAPI_OBJ_PREF_PSTN_CALLREG_RECVENTRY	  "PstnRecvEntry"

#define IFX_VMAPI_OBJ_PREF_PSTN_CONTACT_LIST             "PstnContactList" 
#define IFX_VMAPI_OBJ_PREF_PSTN_CONTACT_LIST_ENTRY       "PstnContactEntry"
#define IFX_VMAPI_OBJ_PREF_COMMON_CONTACT_LIST             "CommonContactList" 
#define IFX_VMAPI_OBJ_PREF_COMMON_CONTACT_LIST_ENTRY       "CommonContactEntry"


#ifdef DECT_SENSORS_SUPPORT
#define IFX_VMAPI_OBJ_NAME_SMOKE_SENSOR_LIST "SmokeSensorList"
#define IFX_VMAPI_OBJ_NAME_SMOKE_SENSOR_ENTRY "SmokeSensorEntry"
#define IFX_VMAPI_OBJ_NAME_SMOKE_SENSOR_ALARAM_LIST "SmokeSensorAlaramList"
#define IFX_VMAPI_OBJ_NAME_SMOKE_SENSOR_ALARAM_ENTRY "SmokeSensorAlaramEntry"

#define IFX_VMAPI_OBJ_NAME_MOTION_SENSOR_LIST "MotionSensorList"
#define IFX_VMAPI_OBJ_NAME_MOTION_SENSOR_ENTRY "MotionSensorEntry"
#define IFX_VMAPI_OBJ_NAME_MOTION_SENSOR_ALARAM_LIST "MotionSensorAlaramList"
#define IFX_VMAPI_OBJ_NAME_MOTION_SENSOR_ALARAM_ENTRY "MotionSensorAlaramEntry"

#define IFX_VMAPI_OBJ_NAME_POWER_SENSOR_LIST "PowerSensorList"
#define IFX_VMAPI_OBJ_NAME_POWER_SENSOR_ENTRY "PowerSensorEntry"
#define IFX_VMAPI_OBJ_NAME_POWER_SENSOR_READ_LIST "PowerSensorReadList"
#define IFX_VMAPI_OBJ_NAME_POWER_SENSOR_READ_ENTRY "PowerSensorReadEntry"

#define IFX_VMAPI_OBJ_PREF_SMOKE_SENSOR_LIST "SmokeSensorList"
#define IFX_VMAPI_OBJ_PREF_SMOKE_SENSOR_ENTRY "SmokeSensorEntry"
#define IFX_VMAPI_OBJ_PREF_SMOKE_SENSOR_ALARAM_LIST "SmokeSensorAlaramList"
#define IFX_VMAPI_OBJ_PREF_SMOKE_SENSOR_ALARAM_ENTRY "SmokeSensorAlaramEntry"

#define IFX_VMAPI_OBJ_PREF_MOTION_SENSOR_LIST "MotionSensorList"
#define IFX_VMAPI_OBJ_PREF_MOTION_SENSOR_ENTRY "MotionSensorEntry"
#define IFX_VMAPI_OBJ_PREF_MOTION_SENSOR_ALARAM_LIST "MotionSensorAlaramList"
#define IFX_VMAPI_OBJ_PREF_MOTION_SENSOR_ALARAM_ENTRY "MotionSensorAlaramEntry"

#define IFX_VMAPI_OBJ_PREF_POWER_SENSOR_LIST "PowerSensorList"
#define IFX_VMAPI_OBJ_PREF_POWER_SENSOR_ENTRY "PowerSensorEntry"
#define IFX_VMAPI_OBJ_PREF_POWER_SENSOR_READ_LIST IFX_VMAPI_OBJ_NAME_POWER_SENSOR_READ_LIST /*"PowReadList"*/
#define IFX_VMAPI_OBJ_PREF_POWER_SENSOR_READ_ENTRY IFX_VMAPI_OBJ_NAME_POWER_SENSOR_READ_ENTRY/*"PowReadEntry"*/

#define IFX_VMAPI_OBJ_NAME_SENSOR_INFO "SensorInfo" 
#define IFX_VMAPI_OBJ_NAME_SENSOR_ALARAM_INFO "SensorAlaram"
#define IFX_VMAPI_OBJ_NAME_POWER_READ_INFO "PowRead"

#define IFX_VMAPI_OBJ_PREF_SENSOR_INFO "SensorInfo" 
#define IFX_VMAPI_OBJ_PREF_SENSOR_ALARAM_INFO "SensorAlaram"
#define IFX_VMAPI_OBJ_PREF_POWER_READ_INFO "PowRead"

#endif

/** \ingroup VMAPI_OBJ_PARAM_MACROS Parametr Id & Parameter Names - IFX_VMAPI_PARAM_CODE_\* and IFX_VMAPI_PARAM_NAME_\*
These macros represent the parameter id and parameter names of the object parameters.They are stored in the parameter tables in unParamCode and acName fields respectively.
*/
/* @{ */
/*************************************************************/
/*************************************************************/
/* Parameter Table Macros 
 * Parameter Tables are maintained separately for each Object
 */
/***********************Voice Service*********************************************/
/* Voice Service */
#define IFX_VMAPI_PARAM_CODE_VS_NUMVOICEPROF    1
#define IFX_VMAPI_PARAM_CODE_VS_NUMPHYENDPTS    2
#define IFX_VMAPI_PARAM_CODE_VS_PROFILEIDLIST   3
#define IFX_VMAPI_PARAM_CODE_VS_LINEIDLIST      4
#define IFX_VMAPI_PARAM_CODE_VS_DEVICELIST      5
#define IFX_VMAPI_PARAM_CODE_VS_COUNTRY         6
#define IFX_VMAPI_PARAM_CODE_VS_STARTFLAG       7
#define IFX_VMAPI_PARAM_NAME_VS_NUMVOICEPROF    "NumVoiceProfile"
#define IFX_VMAPI_PARAM_NAME_VS_NUMPHYENDPTS    "NumPhyendpts"
#define IFX_VMAPI_PARAM_NAME_VS_PROFILEIDLIST   "ProfIdList"
#define IFX_VMAPI_PARAM_NAME_VS_LINEIDLIST      "LineIdList"
#define IFX_VMAPI_PARAM_NAME_VS_DEVICELIST      "DeviceList"
#define IFX_VMAPI_PARAM_NAME_VS_COUNTRY         "Country"
#define IFX_VMAPI_PARAM_NAME_VS_STARTFLAG       "StartFlag"

/***********************Voice System*********************************************/
/* Gateway Mode Configuration  */
#define IFX_VMAPI_PARAM_CODE_GW_MODE            1
#define IFX_VMAPI_PARAM_CODE_GW_EN_PSTN_GW      2
#define IFX_VMAPI_PARAM_CODE_GW_EN_VOIP_GW      3
#define IFX_VMAPI_PARAM_NAME_GW_GW_MODE         "GwMode"
#define IFX_VMAPI_PARAM_NAME_GW_EN_PSTN_GW      "EnablePstnGw"
#define IFX_VMAPI_PARAM_NAME_GW_EN_VOIP_GW      "EnableVoipGw"
#define IFX_VMAPI_PARAM_NAME_GW_GW_SET          "GatewaySet"

/* Version Settings */
#define IFX_VMAPI_PARAM_CODE_VER_FW_VER          1
#ifdef IIP
#define IFX_VMAPI_PARAM_CODE_VER_HAPI_VER        2
#define IFX_VMAPI_PARAM_CODE_VER_JB_VER          3
#define IFX_VMAPI_PARAM_CODE_VER_CHIP_VER        4
#endif
#define IFX_VMAPI_PARAM_CODE_VER_DRV_VER         5
#define IFX_VMAPI_PARAM_CODE_VER_APP_VER         6
#define IFX_VMAPI_PARAM_CODE_VER_RTP_VER         7
#define IFX_VMAPI_PARAM_CODE_VER_VMAPI_VER          8
#define IFX_VMAPI_PARAM_CODE_VER_SIP_VER        9
#ifndef IIP
#define IFX_VMAPI_PARAM_CODE_VER_FAX_VER        10
#endif
#define IFX_VMAPI_PARAM_NAME_VER_VER_SET        "VerSet"
#define IFX_VMAPI_PARAM_NAME_VER_FW_SET         "FirmWSet"
#ifdef IIP
#define IFX_VMAPI_PARAM_NAME_VER_HAPI_VER       "HAPIVer"
#define IFX_VMAPI_PARAM_NAME_VER_JB_VER         "JBVer"
#define IFX_VMAPI_PARAM_NAME_VER_CHIP_VER       "ChipVer"
#endif
#define IFX_VMAPI_PARAM_NAME_VER_DRV_VER        "DrvVer"
#define IFX_VMAPI_PARAM_NAME_VER_APP_VER        "AppVer"  
#define IFX_VMAPI_PARAM_NAME_VER_RTP_VER        "RtpVer"
#define IFX_VMAPI_PARAM_NAME_VER_VMAPI_VER         "VmapiVer"
#define IFX_VMAPI_PARAM_NAME_VER_SIP_VER        "SipVer"
#ifndef IIP
#define IFX_VMAPI_PARAM_NAME_VER_FAX_VER        "FaxVer"
#endif

/* Debug Type */
#define IFX_VMAPI_PARAM_CODE_DBG_LVL         1
#define IFX_VMAPI_PARAM_CODE_DBG_TYPE        2
#define IFX_VMAPI_PARAM_NAME_DBG_LVL   "DbgLvl"
#define IFX_VMAPI_PARAM_NAME_DBG_TYPE  "DbgType"

/* Debug  Settings */
#define IFX_VMAPI_PARAM_CODE_DBGSET_APP   IFX_VMAPI_OBJ_DBG_TYPE
#define IFX_VMAPI_PARAM_CODE_DBGSET_MM   IFX_VMAPI_OBJ_DBG_TYPE
#define IFX_VMAPI_PARAM_CODE_DBGSET_AGENT   IFX_VMAPI_OBJ_DBG_TYPE
#define IFX_VMAPI_PARAM_CODE_DBGSET_RTP   IFX_VMAPI_OBJ_DBG_TYPE
#define IFX_VMAPI_PARAM_CODE_DBGSET_VMAPI    IFX_VMAPI_OBJ_DBG_TYPE
#define IFX_VMAPI_PARAM_CODE_DBGSET_SIP   IFX_VMAPI_OBJ_DBG_TYPE
#ifndef IIP
#define IFX_VMAPI_PARAM_CODE_DBGSET_FAX   IFX_VMAPI_OBJ_DBG_TYPE
#endif
#define IFX_VMAPI_PARAM_NAME_DBGSET_APP   "AppDbgSet"
#define IFX_VMAPI_PARAM_NAME_DBGSET_MM   "MmDbgSet"
#define IFX_VMAPI_PARAM_NAME_DBGSET_AGENT   "AgentDbgSet"
#define IFX_VMAPI_PARAM_NAME_DBGSET_RTP   "RTPDbgSet"
#define IFX_VMAPI_PARAM_NAME_DBGSET_VMAPI    "VmapiDbgSet"
#define IFX_VMAPI_PARAM_NAME_DBGSET_SIP   "SIPDbgSet"
#define IFX_VMAPI_PARAM_NAME_DBGSET_FAX   "FaxDbgSet"

/* Tel Uri */
#define IFX_VMAPI_PARAM_CODE_TEL_COUNT_CODE     1
#define IFX_VMAPI_PARAM_CODE_TEL_INTL_PREFIX    2
#define IFX_VMAPI_PARAM_CODE_TEL_AREA_CODE      3
#define IFX_VMAPI_PARAM_CODE_TEL_STD_PREFIX     4
#define IFX_VMAPI_PARAM_NAME_TEL_TEL_URI        "TelUri"
#define IFX_VMAPI_PARAM_NAME_TEL_COUNT_CODE     "CountryCode"
#define IFX_VMAPI_PARAM_NAME_TEL_INT_PREFIX     "IntlPrefix"
#define IFX_VMAPI_PARAM_NAME_TEL_AREA_CODE      "AreaCode"
#define IFX_VMAPI_PARAM_NAME_TEL_TEL_STD_PREFIX  "StdPrefix"
/* Miscellaneous Parameter Table */
#define IFX_VMAPI_PARAM_CODE_VS_MISC_UNSOLNOTIFY    1
#define IFX_VMAPI_PARAM_CODE_VS_MISC_ENUDP          2
#define IFX_VMAPI_PARAM_CODE_VS_MISC_SMSCNUMBER     3
#define IFX_VMAPI_PARAM_CODE_VS_MISC_RESTOREFACSET  4
#define IFX_VMAPI_PARAM_CODE_VS_MISC_DEFFAXINT      5
#define IFX_VMAPI_PARAM_CODE_VS_MISC_DEFOUTINT      6
#define IFX_VMAPI_PARAM_CODE_VS_MISC_DIALDURA       7
#define IFX_VMAPI_PARAM_CODE_VS_MISC_SILSUPP        8
#define IFX_VMAPI_PARAM_CODE_VS_MISC_SESS_EXPIRE    9
#define IFX_VMAPI_PARAM_CODE_VS_MISC_FXOCTRL		    10

#define IFX_VMAPI_PARAM_NAME_VS_MISC_UNSOLNOTIFY   "UnSolNotify"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_ENUDP         "EnUdp"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_SMSCNUMBER    "SmScNumber"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_RESTOREFACSET "RestoreFacSet"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_DEFFAXINT     "DefFaxInt"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_DEFOUTINT     "DefOutInt"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_DIALDURA      "DialToneDuration"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_SILSUPP       "SilenceSupp"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_SESS_EXPIRE   "SessExpiry"
#define IFX_VMAPI_PARAM_NAME_VS_MISC_FXOCTRL		   "FxoEnable"

/* FXO Parameter Table */
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_ENDPTID      1
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_VOICELINEID  2
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_PHYIFACE    IFX_VMAPI_OBJ_PHY_IFACE
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_INTIDLIST       4
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_SMSCNUMBER      5
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_GATEWAYMODE     6
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_CALLFWDNOANS    7
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_CHANNELSTR      8
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_ECHOCANCEL      9
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_STATE          10
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_LINE_NAME      11
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_LINE_MODE      12
#define IFX_VMAPI_PARAM_CODE_FXOPHYINT_LINE_INTRUSION 13
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_ENDPTID  		 "EndPtID"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_VOICELINEID   "VoiceLineId"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_PHYIFACE      "PhysicalInterface"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_INTIDLIST     "IntIdList"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_SMSCNUMBER    "SmScNumber"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_GATEWAYMODE   "GwMode"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_CALLFWDNOANS  "CallFwdNoAns"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_CHANNELSTR    "ChannelStrFxo"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_ECHOCANCEL    "EchoCancel"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_STATE         "State"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_LINE_NAME     "Name"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_LINE_MODE     "Mode"
#define IFX_VMAPI_PARAM_NAME_FXOPHYINT_LINE_INTRUSION "Intrusion"

/* FXS Parameter Table */
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_ENDPTID      1
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_VOICELINEID  2
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_PHYIFACE    IFX_VMAPI_OBJ_PHY_IFACE
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_SMSCAPABLE       4
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_WIDEBANDCAPABLE      5
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_VOICELINEIDLIST     6
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_CHANNELSTR     7
#define IFX_VMAPI_PARAM_CODE_FXSPHYINT_ECHOCANCEL     8
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_ENDPTID  "EndPtID"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_VOICELINEID    "VoiceLineId"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_PHYIFACE  "PhysicalInterface"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_SMSCAPABLE     "SmsCapable"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_WIDEBANDCAPABLE    "WideBandCapable"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_VOICELINEIDLIST    "VoiceLineIdList"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_CHANNELSTR        "ChannelStrFxs"
#define IFX_VMAPI_PARAM_NAME_FXSPHYINT_ECHOCANCEL        "EchoCancel"

/***********Voice Profile Service Provider********************************/
/* Service Provider Macros */
#define IFX_VMAPI_PARAM_CODE_SERPROVIDER_NAME   1
#define IFX_VMAPI_PARAM_CODE_SERPROVIDER_URL    2
#define IFX_VMAPI_PARAM_CODE_SERPROVIDER_PHONE  3
#define IFX_VMAPI_PARAM_CODE_SERPROVIDER_EMAIL  4
#define IFX_VMAPI_PARAM_NAME_SERPROVIDER_NAME   "Name"
#define IFX_VMAPI_PARAM_NAME_SERPROVIDER_URL    "URL"
#define IFX_VMAPI_PARAM_NAME_SERPROVIDER_PHONE  "Phone"
#define IFX_VMAPI_PARAM_NAME_SERPROVIDER_EMAIL  "e-mail"

/***************************Voice Profile*********************************/
/* Voice Profile Stun Cfg Macros */
#define IFX_VMAPI_PARAM_CODE_STUN_SER       1  
#define IFX_VMAPI_PARAM_CODE_STUN_PORT      2
#define IFX_VMAPI_PARAM_CODE_STUN_USR       3
#define IFX_VMAPI_PARAM_CODE_STUN_PWD       4
#define IFX_VMAPI_PARAM_CODE_STUN_KEEPALIVE 5
#define IFX_VMAPI_PARAM_CODE_STUN_RTCPATTR  6
#define IFX_VMAPI_PARAM_CODE_STUN_NATTYPE   7
#define IFX_VMAPI_PARAM_NAME_STUN_SER       "Server"
#define IFX_VMAPI_PARAM_NAME_STUN_PORT      "Port"
#define IFX_VMAPI_PARAM_NAME_STUN_USR       "Usr"
#define IFX_VMAPI_PARAM_NAME_STUN_PWD       "Passwd"
#define IFX_VMAPI_PARAM_NAME_STUN_KEEPALIVE "KeepAlive"
#define IFX_VMAPI_PARAM_NAME_STUN_RTCPATTR  "rtcp-attr"
#define IFX_VMAPI_PARAM_NAME_STUN_NATTYPE   "NatType"

/* Voice Profile Macros */
#define IFX_VMAPI_PARAM_CODE_VPROF_NAME          1
#define IFX_VMAPI_PARAM_CODE_VPROF_COUNTRY       2
#define IFX_VMAPI_PARAM_CODE_VPROF_STATE         3
#define IFX_VMAPI_PARAM_CODE_VPROF_RESET         4
#define IFX_VMAPI_PARAM_CODE_VPROF_NLINES        5
#define IFX_VMAPI_PARAM_CODE_VPROF_LINES         6
#define IFX_VMAPI_PARAM_CODE_VPROF_ASSOLINEIDS   7
#define IFX_VMAPI_PARAM_CODE_VPROF_DTMFMETH      8
#define IFX_VMAPI_PARAM_CODE_VPROF_G711DTMFMETH  9
#define IFX_VMAPI_PARAM_CODE_VPROF_ENDIGITMAP    10
#define IFX_VMAPI_PARAM_CODE_VPROF_DIGITMAP      11
#define IFX_VMAPI_PARAM_CODE_VPROF_ENSTUN        12
#define IFX_VMAPI_PARAM_CODE_VPROF_STUNCFG       IFX_VMAPI_OBJ_STUN_CFG
#define IFX_VMAPI_PARAM_CODE_VPROF_UPBANDWIDTH   14
#define IFX_VMAPI_PARAM_CODE_VPROF_DWBANDWIDTH   15
#define IFX_VMAPI_PARAM_CODE_VPROF_PSTNFAILOVER  16
#define IFX_VMAPI_PARAM_CODE_VPROF_FAXPASS       17
#define IFX_VMAPI_PARAM_CODE_VPROF_MODEMPASS     18
#define IFX_VMAPI_PARAM_CODE_VPROF_DTMF_PT       19
#define IFX_VMAPI_PARAM_NAME_VPROF_NAME          "Name"
#define IFX_VMAPI_PARAM_NAME_VPROF_COUNTRY       "Country"
#define IFX_VMAPI_PARAM_NAME_VPROF_STATE         "State"  
#define IFX_VMAPI_PARAM_NAME_VPROF_RESET         "Reset"
#define IFX_VMAPI_PARAM_NAME_VPROF_NLINES        "NumLines"
#define IFX_VMAPI_PARAM_NAME_VPROF_LINES         "Line"
#define IFX_VMAPI_PARAM_NAME_VPROF_ASSOLINEIDS   "LineIds"
#define IFX_VMAPI_PARAM_NAME_VPROF_DTMFMETH      "DTMFmeth"
#define IFX_VMAPI_PARAM_NAME_VPROF_G711DTMFMETH  "G711DTMFmeth"
#define IFX_VMAPI_PARAM_NAME_VPROF_ENDIGITMAP    "EnDigMap"
#define IFX_VMAPI_PARAM_NAME_VPROF_DIGITMAP      "DigMap"
#define IFX_VMAPI_PARAM_NAME_VPROF_ENSTUN        "EnStun"
#define IFX_VMAPI_PARAM_NAME_VPROF_STUNCFG       IFX_VMAPI_OBJ_NAME_STUN_CFG
#define IFX_VMAPI_PARAM_NAME_VPROF_UPBANDWIDTH   "UpBand"
#define IFX_VMAPI_PARAM_NAME_VPROF_DWBANDWIDTH   "DwnBand"
#define IFX_VMAPI_PARAM_NAME_VPROF_PSTNFAILOVER  "PSTNFailOver"
#define IFX_VMAPI_PARAM_NAME_VPROF_FAXPASS       "FaxPassThrough"
#define IFX_VMAPI_PARAM_NAME_VPROF_MODEMPASS     "ModemPassThrough"
#define IFX_VMAPI_PARAM_NAME_VPROF_DTMF_PT       "DtmfPt"

/*************************Voice Capabilities**********************************/

/* Voice Capabilities Macros */
#define IFX_VMAPI_PARAM_CODE_VC_SUPP_COUNTRY        1
#define IFX_VMAPI_PARAM_NAME_VC_SUPP_COUNTRY        "SuppCountries"

/*   VoiceLine    */
#define IFX_VMAPI_PARAM_CODE_VL_ASSOCIATEDVOICEINTERFACE  2
#define IFX_VMAPI_PARAM_CODE_VL_DIR_NAME                  3
#define IFX_VMAPI_PARAM_CODE_VL_NAME		                  4
#define IFX_VMAPI_PARAM_CODE_VL_LINE_STATE                5
#define IFX_VMAPI_PARAM_CODE_VL_LINE_STATUS               6
#define IFX_VMAPI_PARAM_CODE_VL_CALL_STATUS               7
#define IFX_VMAPI_PARAM_CODE_VL_EN_RINGMUTE               8
#define IFX_VMAPI_PARAM_CODE_VL_RINGVOLUME                9
#define IFX_VMAPI_PARAM_CODE_VL_ROOMTYPE                  10
#define IFX_VMAPI_PARAM_CODE_VL_VOICEVOLUME               11
#define IFX_VMAPI_PARAM_CODE_VL_GWMODE               			12
#define IFX_VMAPI_PARAM_CODE_VL_MODE                			13
#define IFX_VMAPI_PARAM_CODE_VL_INTRUSION            			14
#define IFX_VMAPI_PARAM_NAME_VL_ASSOCIATEDVOICEINTERFACE  "AssocVoiceInterface"
#define IFX_VMAPI_PARAM_NAME_VL_DIR_NAME                  "DirName"
#define IFX_VMAPI_PARAM_NAME_VL_NAME  		                "Name"
#define IFX_VMAPI_PARAM_NAME_VL_LINE_STATE                "LineState"
#define IFX_VMAPI_PARAM_NAME_VL_LINE_STATUS               "LineStatus"
#define IFX_VMAPI_PARAM_NAME_VL_CALL_STATUS               "CallStatus"
#define IFX_VMAPI_PARAM_NAME_VL_EN_RINGMUTE               "EnRingMute"
#define IFX_VMAPI_PARAM_NAME_VL_RINGVOLUME                "RingVolume"
#define IFX_VMAPI_PARAM_NAME_VL_ROOMTYPE                  "RoomType"
#define IFX_VMAPI_PARAM_NAME_VL_VOICEVOLUME               "VoiceLevel"
#define IFX_VMAPI_PARAM_NAME_VL_GWMODE               			"LGWMode"
#define IFX_VMAPI_PARAM_NAME_VL_MODE                			"Mode"
#define IFX_VMAPI_PARAM_NAME_VL_INTRUSION                			"Intrusion"

/* Line  Signalling  */
#define IFX_VMAPI_PARAM_CODE_LS_USER_NAME                 1
#define IFX_VMAPI_PARAM_CODE_LS_DISPL_NAME                2
#define IFX_VMAPI_PARAM_CODE_LS_NUM_AUTHCFG               3 
#define IFX_VMAPI_PARAM_CODE_LS_XAUTHCFG                  IFX_VMAPI_OBJ_AUTHCFG
#define IFX_VMAPI_PARAM_CODE_LS_EN_REGISTERED             5
#define IFX_VMAPI_PARAM_NAME_LS_USER_NAME                 "UserName"
#define IFX_VMAPI_PARAM_NAME_LS_DISPL_NAME                "DispName"
#define IFX_VMAPI_PARAM_NAME_LS_NUM_AUTHCFG               "NumOfAuthCfg"
#define IFX_VMAPI_PARAM_NAME_LS_XAUTHCFG                  "AuthCfg"
#define IFX_VMAPI_PARAM_NAME_LS_EN_REGISTERED             "Registered"
/* Line  Subscription  */
#define IFX_VMAPI_PARAM_CODE_LS_MSGRETRIEVE_USRNAME       1
#define IFX_VMAPI_PARAM_CODE_LS_NOOFLINEEVENTS             2
#define IFX_VMAPI_PARAM_CODE_LS_LINEEVENTS                IFX_VMAPI_OBJ_LINEEVENTS

#define IFX_VMAPI_PARAM_NAME_LS_MSGRETRIEVE_USRNAME       "MsgRetUsrName"
#define IFX_VMAPI_PARAM_NAME_LS_NOOFLINEEVENTS            "NoOfLineEvents"
#define IFX_VMAPI_PARAM_NAME_LS_LINEEVENTS                "LineSubEvent"


/************************Line Events********************************/
#define IFX_VMAPI_PARAM_CODE_LINEEVENTS_SUBEVENT		1
#define IFX_VMAPI_PARAM_CODE_LINEEVENTS_SUBSTATE  	2
#define IFX_VMAPI_PARAM_CODE_LINEEVENTS_SUBUSRNAME	3
#define IFX_VMAPI_PARAM_CODE_LINEEVENTS_SUBPASSWD 	4
#define IFX_VMAPI_PARAM_NAME_LINEEVENTS_SUBEVENT		"SubEvt"
#define IFX_VMAPI_PARAM_NAME_LINEEVENTS_SUBSTATE	  "SubState"
#define IFX_VMAPI_PARAM_NAME_LINEEVENTS_SUBUSRNAME	"SubUsrName"
#define IFX_VMAPI_PARAM_NAME_LINEEVENTS_SUBPASSWD  	"SubPasswd"
/* Profile  Subscription  */
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_NOOFSUBSCR          1
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_EVENTSUBSCR         IFX_VMAPI_OBJ_PROFEVENT_SUBSCR
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_NOOFSUBSCR       "NoOfSubscr"
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_EVENTSUBSCR      "EventSubscribe"

/************************Profile Events********************************/
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_SUBSCR_EVENT		    1
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_SUBSCR_NOTIFADDR  	2
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_SUBSCR_NOTIFPORT	  3
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_SUBSCR_NOTIFPROTO 	4
#define IFX_VMAPI_PARAM_CODE_PROFEVENT_SUBSCR_SUBSCRTIME 	5
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_SUBSCR_EVENT		    "Event"
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_SUBSCR_NOTIFADDR  	"NotifierAddr"
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_SUBSCR_NOTIFPORT	  "NotifierPort"
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_SUBSCR_NOTIFPROTO 	"NotifierProtocol"
#define IFX_VMAPI_PARAM_NAME_PROFEVENT_SUBSCR_SUBSCRTIME 	"SubscrTime"

/* Call Block  Param Table  */
#define IFX_VMAPI_PARAM_CODE_CALLBK_CALLBAR                1
#define IFX_VMAPI_PARAM_CODE_CALLBK_NUMCALLBKENTRY         2
#define IFX_VMAPI_PARAM_CODE_CALLBK_CALLBKENTRY         IFX_VMAPI_OBJ_CALLBK_ENTRY
#define IFX_VMAPI_PARAM_NAME_CALLBK_CALLBAR      "CallBar"
#define IFX_VMAPI_PARAM_NAME_CALLBK_NUMCALLBKENTRY      "NoOfCallbkEntry"
#define IFX_VMAPI_PARAM_NAME_CALLBK_CALLBKENTRY      "CallBlockEntry"

/************************Call Block Entry Param Table********************************/
#define IFX_VMAPI_PARAM_CODE_CALLBK_ENTRY_CALLBKNUM		    1
#define IFX_VMAPI_PARAM_NAME_CALLBK_ENTRY_CALLBKNUM    "CallbkNum"


/* Line calling Feature */
#define IFX_VMAPI_PARAM_CODE_LC_EN_CID                 1
#define IFX_VMAPI_PARAM_CODE_LC_EN_CID_NAME            2
#define IFX_VMAPI_PARAM_CODE_LC_CID_NAME               3
#define IFX_VMAPI_PARAM_CODE_LC_EN_CALL_WAITING        4
#define IFX_VMAPI_PARAM_CODE_LC_CALL_WAIT_STATUS       5
#define IFX_VMAPI_PARAM_CODE_LC_MAX_CONF_SESSION       6
#define IFX_VMAPI_PARAM_CODE_LC_CONF_CALLSTATUS        7
#define IFX_VMAPI_PARAM_CODE_LC_CONF_CALL_SESSIONCOUNT 8
#define IFX_VMAPI_PARAM_CODE_LC_CALL_FWDCFG            9 
#define IFX_VMAPI_PARAM_CODE_LC_XCFUADDRESS            IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_LC_XCFBADDRESS            IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_LC_XCFNAADDRESS           IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_LC_CFNA_NO_ANSWERRINGCOUNT 13
#define IFX_VMAPI_PARAM_CODE_LC_XDNDADDRESS             IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_LC_EN_CALL_TRANSFER        15
#define IFX_VMAPI_PARAM_CODE_LC_EN_MWI_INDICATION       16
#define IFX_VMAPI_PARAM_CODE_LC_EN_MSGWAITING           17
#define IFX_VMAPI_PARAM_CODE_LC_EN_ANONYMOUS_CALLBLOCK  18
#define IFX_VMAPI_PARAM_CODE_LC_EN_DONOT_DISTURB        19
#define IFX_VMAPI_PARAM_CODE_LC_CALL_RETURN             20
#define IFX_VMAPI_PARAM_CODE_LC_EN_REPEAT_DIAL          21
#define IFX_VMAPI_PARAM_CODE_LC_FWDSTATUS               22
#define IFX_VMAPI_PARAM_CODE_LC_EN_DIALFLAG             23
#define IFX_VMAPI_PARAM_CODE_LC_EN_PREFIX_DIGIT         24
#ifdef DELAYED_HOTLINE
	#define IFX_VMAPI_PARAM_CODE_LC_EN_DHL                25
	#define IFX_VMAPI_PARAM_CODE_LC_DHL_NUMBER            26
#endif
#define IFX_VMAPI_PARAM_NAME_LC_EN_CID                  "EnableCid"
#define IFX_VMAPI_PARAM_NAME_LC_EN_CID_NAME             "EnableCidName"
#define IFX_VMAPI_PARAM_NAME_LC_CID_NAME                "CidName"
#define IFX_VMAPI_PARAM_NAME_LC_EN_CALL_WAITING         "EnableCallWaiting"
#define IFX_VMAPI_PARAM_NAME_LC_CALL_WAIT_STATUS        "CallWaitStatus"
#define IFX_VMAPI_PARAM_NAME_LC_MAX_CONF_SESSION        "MaxConfSessions"
#define IFX_VMAPI_PARAM_NAME_LC_CONF_CALLSTATUS         "ConfCallStatus"
#define IFX_VMAPI_PARAM_NAME_LC_CONF_CALL_SESSIONCOUNT  "ConfCallSessionCount"
#define IFX_VMAPI_PARAM_NAME_LC_CALL_FWDCFG             "CallFwdCfg"
#define IFX_VMAPI_PARAM_NAME_LC_XCFUADDRESS             "CfuAddress"
#define IFX_VMAPI_PARAM_NAME_LC_XCFBADDRESS             "CfbAddress"
#define IFX_VMAPI_PARAM_NAME_LC_XCFNAADDRESS            "CfnaAddress"
#define IFX_VMAPI_PARAM_NAME_LC_CFNA_NO_ANSWERRINGCOUNT "CfnaRingCount"
#define IFX_VMAPI_PARAM_NAME_LC_XDNDADDRESS             "DndAddress"
#define IFX_VMAPI_PARAM_NAME_LC_EN_CALL_TRANSFER        "EnableCallTransfer"
#define IFX_VMAPI_PARAM_NAME_LC_EN_MWI_INDICATION       "EnableMwiIndication"
#define IFX_VMAPI_PARAM_NAME_LC_EN_MSGWAITING           "IsMsgWaiting"
#define IFX_VMAPI_PARAM_NAME_LC_EN_ANONYMOUS_CALLBLOCK  "EnableAcb"
#define IFX_VMAPI_PARAM_NAME_LC_EN_DONOT_DISTURB        "EnableDnd"
#define IFX_VMAPI_PARAM_NAME_LC_CALL_RETURN             "EnableCallRet"
#define IFX_VMAPI_PARAM_NAME_LC_EN_REPEAT_DIAL          "EnableRepeatDial"
#define IFX_VMAPI_PARAM_NAME_LC_FWDSTATUS               "FwdStatus"
#ifdef IIP
#define IFX_VMAPI_PARAM_NAME_LC_EN_DIALFLAG             "ExtnDialFlag"
#define IFX_VMAPI_PARAM_NAME_LC_EN_PREFIX_DIGIT         "unPrefixDigit"
#define IFX_VMAPI_PARAM_NAME_LC_XFASTDIAL               "FastDial"
#endif
#ifdef DELAYED_HOTLINE
	#define IFX_VMAPI_PARAM_NAME_LC_EN_DHL                "EnableDhl"
	#define IFX_VMAPI_PARAM_NAME_LC_DHL_NUMBER            "DhlNumber"
#endif


/* Line Voice Media Voice Processing Parameter Table */
#define IFX_VMAPI_PARAM_CODE_LVP_EN_ECHO_CANCEL        1
#define IFX_VMAPI_PARAM_CODE_LVP_TX_GAIN               2
#define IFX_VMAPI_PARAM_CODE_LVP_RX_GAIN               3
#define IFX_VMAPI_PARAM_CODE_LVP_EN_ECHO_CANCEL_INUSE  4
#define IFX_VMAPI_PARAM_CODE_LVP_ECHO_CANCELTAIL       5
#define IFX_VMAPI_PARAM_NAME_LVP_EN_ECHO_CANCEL        "EnableEchoCancel"
#define IFX_VMAPI_PARAM_NAME_LVP_TX_GAIN               "TransmitGain"
#define IFX_VMAPI_PARAM_NAME_LVP_RX_GAIN               "ReceiveGain"
#define IFX_VMAPI_PARAM_NAME_LVP_EN_ECHO_CANCEL_INUSE  "EchoCancellationInUse"
#define IFX_VMAPI_PARAM_NAME_LVP_ECHO_CANCELTAIL       "EchoCancellationLength"


/* Line Voice Media  Voice  Session  Parameter  Table */
#define IFX_VMAPI_PARAM_CODE_LVS_SESSION_STARTIME    1
#define IFX_VMAPI_PARAM_CODE_LVS_SESSION_DURATION    2
#define IFX_VMAPI_PARAM_CODE_LVS_DEST_ADDRESS        3
#define IFX_VMAPI_PARAM_CODE_LVS_DEST_PORT           4
#define IFX_VMAPI_PARAM_CODE_LVS_LOCAL_PORT          5
#define IFX_VMAPI_PARAM_NAME_LVS_SESSION_STARTIME    "StartTime"
#define IFX_VMAPI_PARAM_NAME_LVS_SESSION_DURATION    "Duration"
#define IFX_VMAPI_PARAM_NAME_LVS_DEST_ADDRESS        "DestAddress"
#define IFX_VMAPI_PARAM_NAME_LVS_DEST_PORT           "DestPort"
#define IFX_VMAPI_PARAM_NAME_LVS_LOCAL_PORT          "LocalPort"


/* Line  Voice  Media  Voice  Codec  Parameter Table */
#define IFX_VMAPI_PARAM_CODE_LVC_TX_CODEC         1
#define IFX_VMAPI_PARAM_CODE_LVC_RX_CODEC         2
#define IFX_VMAPI_PARAM_CODE_LVC_TX_BITRATE       3
#define IFX_VMAPI_PARAM_CODE_LVC_RX_BITRATE       4
#define IFX_VMAPI_PARAM_CODE_LVC_TX_SILENCESUPP   5
#define IFX_VMAPI_PARAM_CODE_LVC_RX_SILENCESUPP   6
#define IFX_VMAPI_PARAM_CODE_LVC_FRAMELENGTH      7
#define IFX_VMAPI_PARAM_CODE_LVC_VOICESESSION     8
#define IFX_VMAPI_PARAM_NAME_LVC_TX_CODEC         "TransmitCodec"
#define IFX_VMAPI_PARAM_NAME_LVC_RX_CODEC         "ReceiveCodec"
#define IFX_VMAPI_PARAM_NAME_LVC_TX_BITRATE       "TransmitBitRate"
#define IFX_VMAPI_PARAM_NAME_LVC_RX_BITRATE       "ReceiveBitRate"
#define IFX_VMAPI_PARAM_NAME_LVC_TX_SILENCESUPP   "TransmitSilenceSupp"
#define IFX_VMAPI_PARAM_NAME_LVC_RX_SILENCESUPP   "ReceiveSilenceSupp"
#define IFX_VMAPI_PARAM_NAME_LVC_FRAMELENGTH      "Framelength"

/******************** Line Codec List *******************************/
#define IFX_VMAPI_PARAM_CODE_LCL_XCODECLIST       IFX_VMAPI_OBJ_CODEC_DESC
#define IFX_VMAPI_PARAM_CODE_LCL_G723_PREF_CODEC        2
#define IFX_VMAPI_PARAM_NAME_LCL_XCODECLIST       "List"
#define IFX_VMAPI_PARAM_NAME_LCL_G723_PREF_CODEC  "G723PrefCodec"




/******************** Line Statistics *******************************/
#define IFX_VMAPI_PARAM_CODE_RESET_STATS	1
#define IFX_VMAPI_PARAM_CODE_PKT_SENT			2
#define IFX_VMAPI_PARAM_CODE_PKT_RCVD			3
#define IFX_VMAPI_PARAM_CODE_BYTES_SENT		4
#define IFX_VMAPI_PARAM_CODE_BYTES_RCVD		5
#define IFX_VMAPI_PARAM_CODE_PKTS_LOST		6
#define IFX_VMAPI_PARAM_CODE_RCV_PKT_LOSS_RATE	7
#define IFX_VMAPI_PARAM_CODE_FAR_END_PKT_LOSS_RATE	8
#define IFX_VMAPI_PARAM_CODE_RCV_INTER_ARRIVAL_JITTER	9
#define IFX_VMAPI_PARAM_CODE_FAR_END_INTER_ARRIVAL_JITTER	10
#define IFX_VMAPI_PARAM_CODE_ROUND_TRIP_DELAY		11
#define IFX_VMAPI_PARAM_CODE_AVG_RCV_INTER_ARRIVAL_JITTER	12
#define IFX_VMAPI_PARAM_CODE_AVG_FAR_END_INTER_ARRIVAL_JITTER 13
#define IFX_VMAPI_PARAM_CODE_AVG_ROUND_TRIP_DELAY	14
#define IFX_VMAPI_PARAM_CODE_OVER_RUN			15	
#define IFX_VMAPI_PARAM_CODE_UNDER_RUN		16
#define IFX_VMAPI_PARAM_CODE_INCOMING_CALLS_RCVD	17
#define IFX_VMAPI_PARAM_CODE_INCOMING_CALLS_ANSWD	18
#define IFX_VMAPI_PARAM_CODE_INCOMING_CALLS_CONN	19
#define IFX_VMAPI_PARAM_CODE_INCOMING_CALLS_FAIL	20
#define IFX_VMAPI_PARAM_CODE_OUTGOING_CALLS_ATTEMPT	21
#define IFX_VMAPI_PARAM_CODE_OUTGOING_CALLS_ANSWD		22
#define IFX_VMAPI_PARAM_CODE_OUTGOING_CALLS_CONN	23
#define IFX_VMAPI_PARAM_CODE_OUTGOING_CALLS_FAIL	24
#define IFX_VMAPI_PARAM_CODE_CALLS_DROP						25
#define IFX_VMAPI_PARAM_CODE_TOTAL_CALL_TIME			26
#define IFX_VMAPI_PARAM_CODE_SRVR_DOWN_TIME				27
#define IFX_VMAPI_PARAM_NAME_RESET_STATS		"RstStats"	
#define IFX_VMAPI_PARAM_NAME_PKT_SENT				"PktSent"
#define IFX_VMAPI_PARAM_NAME_PKT_RCVD				"PktRcvd"
#define IFX_VMAPI_PARAM_NAME_BYTES_SENT			"BytSent"
#define IFX_VMAPI_PARAM_NAME_BYTES_RCVD			"BytRcvd"
#define IFX_VMAPI_PARAM_NAME_PKTS_LOST			"PktLost"
#define IFX_VMAPI_PARAM_NAME_RCV_PKT_LOSS_RATE	"RcvPktLoss"
#define IFX_VMAPI_PARAM_NAME_FAR_END_PKT_LOSS_RATE	"FarEndPktLoss"
#define IFX_VMAPI_PARAM_NAME_RCV_INTER_ARRIVAL_JITTER	"RcvJitter"
#define IFX_VMAPI_PARAM_NAME_FAR_END_INTER_ARRIVAL_JITTER "FarEndJitter"
#define IFX_VMAPI_PARAM_NAME_ROUND_TRIP_DELAY		"RTDelay"
#define IFX_VMAPI_PARAM_NAME_AVG_RCV_INTER_ARRIVAL_JITTER	"AvgRcvJitter"
#define IFX_VMAPI_PARAM_NAME_AVG_FAR_END_INTER_ARRIVAL_JITTER "AvgFarEndJitter"
#define IFX_VMAPI_PARAM_NAME_AVG_ROUND_TRIP_DELAY		"AvgRTDelay"
#define IFX_VMAPI_PARAM_NAME_OVER_RUN				"OverRun"
#define IFX_VMAPI_PARAM_NAME_UNDER_RUN			"UnderRun"
#define IFX_VMAPI_PARAM_NAME_INCOMING_CALLS_RCVD	"IncCallsRcvd"
#define IFX_VMAPI_PARAM_NAME_INCOMING_CALLS_ANSWD	"IncCallsAnswd"
#define IFX_VMAPI_PARAM_NAME_INCOMING_CALLS_CONN	"IncCallsConn"
#define IFX_VMAPI_PARAM_NAME_INCOMING_CALLS_FAIL	"IncCallsFail"
#define IFX_VMAPI_PARAM_NAME_OUTGOING_CALLS_ATTEMPT	"OutCallsAttempt"
#define IFX_VMAPI_PARAM_NAME_OUTGOING_CALLS_ANSWD	"OutCallsAnswd"
#define IFX_VMAPI_PARAM_NAME_OUTGOING_CALLS_CONN	"OutCallsConn"
#define IFX_VMAPI_PARAM_NAME_OUTGOING_CALLS_FAIL	"OutCallsFail"
#define IFX_VMAPI_PARAM_NAME_CALLS_DROP						"CallsDrop"
#define IFX_VMAPI_PARAM_NAME_TOTAL_CALL_TIME			"CallTime"
#define IFX_VMAPI_PARAM_NAME_SRVR_DOWN_TIME				"SrvDownTime"

/******************** Auth Config ******************************************/
#define  IFX_VMAPI_PARAM_CODE_AUTHCFG_REALM       1
#define  IFX_VMAPI_PARAM_CODE_AUTHCFG_USRNAME     2
#define  IFX_VMAPI_PARAM_CODE_AUTHCFG_PASSWD      3
#define  IFX_VMAPI_PARAM_NAME_AUTHCFG_REALM       "Realm"
#define  IFX_VMAPI_PARAM_NAME_AUTHCFG_USRNAME     "UsrName"
#define  IFX_VMAPI_PARAM_NAME_AUTHCFG_PASSWD      "Passwd"

#define  IFX_VMAPI_PARAM_CODE_ADDR_TYPE           1
#define  IFX_VMAPI_PARAM_CODE_ADDR_DISPLAYNAME    2
#define  IFX_VMAPI_PARAM_CODE_ADDR_USERNAME       3
#define  IFX_VMAPI_PARAM_CODE_ADDR_DESTADDR       4
#define  IFX_VMAPI_PARAM_CODE_ADDR_PORT           5
#define  IFX_VMAPI_PARAM_CODE_ADDR_PROTOCOL       6
#define  IFX_VMAPI_PARAM_NAME_ADDR_TYPE           "AddrType"
#define  IFX_VMAPI_PARAM_NAME_ADDR_DISPLAYNAME    "DisplayName"
#define  IFX_VMAPI_PARAM_NAME_ADDR_USERNAME       "UsrName"
#define  IFX_VMAPI_PARAM_NAME_ADDR_DESTADDR       "DestName"
#define  IFX_VMAPI_PARAM_NAME_ADDR_PORT           "Port"
#define  IFX_VMAPI_PARAM_NAME_ADDR_PROTOCOL       "Protocol"

/*************** Codec Description *****************************************/
#define  IFX_VMAPI_PARAM_CODE_CODEC_ID               1
#define  IFX_VMAPI_PARAM_CODE_CODEC_NAME             2
#define  IFX_VMAPI_PARAM_CODE_CODEC_BITRATE          3
#define  IFX_VMAPI_PARAM_CODE_CODEC_SUPPFRAMELENGTH  4
#define  IFX_VMAPI_PARAM_CODE_CODEC_SILENCESUPP      5
#define  IFX_VMAPI_PARAM_CODE_CODEC_PAYLOADTYPE      6
#define  IFX_VMAPI_PARAM_CODE_CODEC_ENABLE			     7
#define  IFX_VMAPI_PARAM_CODE_CODEC_PRIORITY         8
#define  IFX_VMAPI_PARAM_NAME_CODEC_ID               "Id"
#define  IFX_VMAPI_PARAM_NAME_CODEC_NAME             "Name"
#define  IFX_VMAPI_PARAM_NAME_CODEC_BITRATE          "BitRate"
#define  IFX_VMAPI_PARAM_NAME_CODEC_SUPPFRAMELENGTH  "SupFrame"
#define  IFX_VMAPI_PARAM_NAME_CODEC_SILENCESUPP      "SilSup"
#define  IFX_VMAPI_PARAM_NAME_CODEC_PAYLOADTYPE      "PLType"
#define  IFX_VMAPI_PARAM_NAME_CODEC_ENABLE			     "Enable"
#define  IFX_VMAPI_PARAM_NAME_CODEC_PRIORITY         "Prio"

#define  IFX_VMAPI_PARAM_CODE_CALLBLOCK_NUM          1
#define  IFX_VMAPI_PARAM_NAME_CALLBLOCK_NUM          "CallBlockNum"

/********************Voice Codec Capabilities*******************************/
#define IFX_VMAPI_PARAM_CODE_VC_FW_SUPP_CODECS   1
#define IFX_VMAPI_PARAM_CODE_VC_NUMCODECS        2
#define IFX_VMAPI_PARAM_CODE_VC_XCODECLIST       IFX_VMAPI_OBJ_CODEC_CAPABS_ENTRY

#define IFX_VMAPI_PARAM_NAME_VC_FW_SUPP_CODECS   "FwSuppCodecs"
#define IFX_VMAPI_PARAM_NAME_VC_NUMCODECS        "NumCodecs"
#define IFX_VMAPI_PARAM_NAME_VC_XCODECLIST       IFX_VMAPI_OBJ_NAME_CODEC_CAPABS_ENTRY

/* Codec Entries */
#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_ID               1
#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_NAME             2
#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_BITRATE          3
#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_SUPPFRAMELENGTH  4
#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_SILENCESUPP      5
#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_PAYLOADTYPE      6
//#define  IFX_VMAPI_PARAM_CODE_VC_CODEC_PRIORITY         7
#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_ID               "ID"
#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_NAME             "Name"
#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_BITRATE          "BitRate"
#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_SUPPFRAMELENGTH  "SupFrame"
#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_SILENCESUPP      "SilSup"
#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_PAYLOADTYPE      "PLType"
//#define  IFX_VMAPI_PARAM_NAME_VC_CODEC_PRIORITY         "Prio"

/***************************Voice Profile Signaling*************************/
/* Voice Profile Signaling Macros */
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_ENPROXY           1
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_ENREG             2
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_PROXYADDR         3
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_PROXYPORT         4
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_PROXYPROTO        5
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGADDR           6
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGPORT           7
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGPROTO          8
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGEXPIRY         9
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGRETRYTIME      10
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGRETRYATTEMPTS  11
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_DOMAIN            12
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_DNSTIMEOUT        13
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_UAPORT            14
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_UAPROTO           15
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_OUTPROXY          16
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_OUTPROXYPORT      17
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_WELLKNOWNSOURCE   18
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_T1                19
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_T2                20
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_T4                21
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Ta                22
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Tb                23
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Tc                24
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Td                25
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Te                26
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Tf                27
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Tg                28
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Th                29
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Ti                30
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_Tj                31
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_INVEXPIRES        32
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REINVEXPIRES      33  
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGEXPIRES        34
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_REGMINEXPIRES     35
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_INBOUNDAUTH       36
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_INBOUNDAUTHUSR    37
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_INBOUNDAUTHPASSWD 38
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_COHMETH           39
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_COMPACTHDR        40
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_UAHDR             41
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_ACCEPTUNSOLNOTIFY 42
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_ANNOUNCEMETH      43
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_SIPDSCP           44
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_SIPVLANID         45
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_ETHPRIORITY       46
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_ORG					      47
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_BKPREGADDR          48
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_BKPREGPORT          49
#define IFX_VMAPI_PARAM_CODE_VPROFSIG_BKPREGPROTO         50

#define IFX_VMAPI_PARAM_NAME_VPROFSIG_ENPROXY           "EnProxy"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_ENREG             "EnReg"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_PROXYADDR         "ProxyAddr"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_PROXYPORT         "ProxyPort"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_PROXYPROTO        "ProxyProto"          
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGADDR           "RegAddr"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGPORT           "RegPort"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGPROTO          "RegProto"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGEXPIRY         "RegExpiry"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGRETRYTIME      "RegRetryTime"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGRETRYATTEMPTS  "RegRetryAttempts"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_DOMAIN            "Domain"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_DNSTIMEOUT        "DNSTimeout"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_UAPORT            "UAPort"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_UAPROTO           "UAProto"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_OUTPROXY          "OutbProxy"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_OUTPROXYPORT      "OutbProxyPort"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_WELLKNOWNSOURCE   "WellKnownSource"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_T1                "T1"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_T2                "T2"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_T4                "T4"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Ta                "Ta"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Tb                "Tb"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Tc                "Tc"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Td                "Td"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Te                "Te"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Tf                "Tf"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Tg                "Tg"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Th                "Th"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Ti                "Ti"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_Tj                "Tj"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_INVEXPIRES        "InvExp"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REINVEXPIRES      "ReInvExp"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGEXPIRES        "RegExp"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_REGMINEXPIRES     "RegMinExp"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_INBOUNDAUTH       "InboundAuth"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_INBOUNDAUTHUSR    "InbAuthUsr"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_INBOUNDAUTHPASSWD "InbAuthPasswd"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_COHMETH           "COHMeth"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_COMPACTHDR        "CompactHdr"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_UAHDR             "UAHdr"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_ACCEPTUNSOLNOTIFY "AccUnSolNot"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_ANNOUNCEMETH      "AnnounceMeth"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_SIPDSCP           "SipDscp"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_SIPVLANID         "SipVLANId"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_ETHPRIORITY       "EthPriority"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_ORG				        "Org"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_BKPREGADDR          "BackupRegAddr"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_BKPREGPORT          "BackupRegPort"
#define IFX_VMAPI_PARAM_NAME_VPROFSIG_BKPREGPROTO         "BackupRegProto"

/***************************Voice Profile Media*******************************/
#ifdef IIP
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_ENSRTP           1
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTPKEYMETH      2
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTPENC          3
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTPAUTH         4
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTPMASTERKEY    5
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTPMASTERSALT   6
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_ENSRTPMKIIND     7
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTPMKILEN       8
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTCPENC         9
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTCPAUTH        10
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTCPMASTERKEY   11
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTCPMASTERSALT  12
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_ENSRTCPMKIIND    13
#define IFX_VMAPI_PARAM_CODE_VMEDIASEC_SRTCPMKILEN      14

#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_ENSRTP           "EnSRTP"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTPKEYMETH      "SRTPKeyMeth"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTPENC          "SRTPKeyEnc"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTPAUTH         "SRTPAuth"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTPMASTERKEY    "SRTPMasterkey"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTPMASTERSALT   "SRTPMasterSalt"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_ENSRTPMKIIND     "SRTPEnSRTPMkiInd"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTPMKILEN       "SRTPMkiLen"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTCPENC         "SRTCPEnc"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTCPAUTH        "SRTCPAuth"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTCPMASTERKEY   "SRTCPMasterKey"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTCPMASTERSALT  "SRTCPMasterSalt"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_ENSRTCPMKIIND    "EnSRTCPMkiInd"
#define IFX_VMAPI_PARAM_NAME_VMEDIASEC_SRTCPMKILEN      "SRTCPMkiLen"

#endif

/***************************Voice Profile Media RTP*******************************/
/* Voice Profile Media RTP Macros */        
#define IFX_VMAPI_PARAM_CODE_VPRTP_RTPDSCP       1
#define IFX_VMAPI_PARAM_CODE_VPRTP_RTPVLANID     2
#define IFX_VMAPI_PARAM_CODE_VPRTP_ETHPRIORITY   3
#define IFX_VMAPI_PARAM_CODE_VPRTP_MINRTPPORT    4
#define IFX_VMAPI_PARAM_CODE_VPRTP_MAXRTPPORT    5
#define IFX_VMAPI_PARAM_CODE_VPRTP_MINFAXPORT    6
#define IFX_VMAPI_PARAM_CODE_VPRTP_MAXFAXPORT    7
#define IFX_VMAPI_PARAM_CODE_VPRTP_JBTYPE        8
#define IFX_VMAPI_PARAM_CODE_VPRTP_SCALINGFAC    9
#define IFX_VMAPI_PARAM_CODE_VPRTP_INITSIZE      10
#define IFX_VMAPI_PARAM_CODE_VPRTP_MAXSIZE       11
#define IFX_VMAPI_PARAM_CODE_VPRTP_MINSIZE       12
#define IFX_VMAPI_PARAM_NAME_VPRTP_RTPDSCP       "RTPDscp"
#define IFX_VMAPI_PARAM_NAME_VPRTP_RTPVLANID     "RTPVLanId"
#define IFX_VMAPI_PARAM_NAME_VPRTP_ETHPRIORITY   "EthPriority"
#define IFX_VMAPI_PARAM_NAME_VPRTP_MINRTPPORT    "MinRTPPort"
#define IFX_VMAPI_PARAM_NAME_VPRTP_MAXRTPPORT    "MaxRTPPort"
#define IFX_VMAPI_PARAM_NAME_VPRTP_MINFAXPORT    "MinFaxPort"
#define IFX_VMAPI_PARAM_NAME_VPRTP_MAXFAXPORT    "MaxFaxPort"
#define IFX_VMAPI_PARAM_NAME_VPRTP_JBTYPE        "JBType"
#define IFX_VMAPI_PARAM_NAME_VPRTP_SCALINGFAC    "ScalingFac"
#define IFX_VMAPI_PARAM_NAME_VPRTP_INITSIZE      "InitSize"
#define IFX_VMAPI_PARAM_NAME_VPRTP_MAXSIZE       "MaxSize"
#define IFX_VMAPI_PARAM_NAME_VPRTP_MINSIZE       "MinSize"


/***************************Voice Profile Media RTCP*******************************/
/* Voice Profile Media RTCP Macros */        
#define IFX_VMAPI_PARAM_CODE_VPRTCP_ENRTCP       1
#define IFX_VMAPI_PARAM_CODE_VPRTCP_RTCPINT      2
#define IFX_VMAPI_PARAM_CODE_VPRTCP_NAME         3
#define IFX_VMAPI_PARAM_NAME_VPRTCP_ENRTCP       "EnRTCP"
#define IFX_VMAPI_PARAM_NAME_VPRTCP_RTCPINT      "RTCPInt"
#define IFX_VMAPI_PARAM_NAME_VPRTCP_NAME         "RTCPName"

/***************************Voice Profile Fax ***************************/
#define IFX_VMAPI_PARAM_CODE_FAX_ENABLE								1
#define IFX_VMAPI_PARAM_CODE_FAX_BIT_RATE_TCP					2
#define IFX_VMAPI_PARAM_CODE_FAX_BIT_RATE_UDP					3
#define IFX_VMAPI_PARAM_CODE_FAX_HIGH_SPEED_PKT_RATE	4
#define IFX_VMAPI_PARAM_CODE_FAX_TCF_METHOD_TCP				5
#define IFX_VMAPI_PARAM_CODE_FAX_TCF_METHOD_UDP				6
#define IFX_VMAPI_PARAM_CODE_FAX_UDP_MAX_BUF_SIZE			7
#define IFX_VMAPI_PARAM_CODE_FAX_UDP_MAX_DGRAM_SIZE		8
#define IFX_VMAPI_PARAM_CODE_FAX_UDP_ERR_CORRECT			9
#define IFX_VMAPI_PARAM_NAME_FAX_ENABLE								"Enable"
#define IFX_VMAPI_PARAM_NAME_FAX_BIT_RATE_TCP					"BitRateTcp"
#define IFX_VMAPI_PARAM_NAME_FAX_BIT_RATE_UDP					"BitRateUdp"
#define IFX_VMAPI_PARAM_NAME_FAX_HIGH_SPEED_PKT_RATE	"HighSpPktRate"
#define IFX_VMAPI_PARAM_NAME_FAX_TCF_METHOD_TCP				"TCFMethodTcp"
#define IFX_VMAPI_PARAM_NAME_FAX_TCF_METHOD_UDP				"TCFMethodUdp"
#define IFX_VMAPI_PARAM_NAME_FAX_UDP_MAX_BUF_SIZE			"UdpMaxBuf"
#define IFX_VMAPI_PARAM_NAME_FAX_UDP_MAX_DGRAM_SIZE		"UdpMaxDgram"
#define IFX_VMAPI_PARAM_NAME_FAX_UDP_ERR_CORRECT			"UdpErrCorrect"

/***************************Voice System T.38***************************/
#define IFX_VMAPI_PARAM_CODE_T38_OLDASN1							1
#define IFX_VMAPI_PARAM_CODE_T38_NSX_SIZE							2
#define IFX_VMAPI_PARAM_CODE_T38_NSX_INFO_FIELD     	3
#define IFX_VMAPI_PARAM_CODE_T38_DATA_WAIT_TIME   		4
#define IFX_VMAPI_PARAM_CODE_T38_UDP_HIGH_ERR_REC_PKT	5
#define IFX_VMAPI_PARAM_CODE_T38_UDP_LOW_ERR_REC_PKT	6
#define IFX_VMAPI_PARAM_CODE_T38_UDP_PRIOR_FEC_PKT  	7
#define IFX_VMAPI_PARAM_CODE_T38_FRAME_LENGTH       	8
#define IFX_VMAPI_PARAM_CODE_T38_PREF_CONN          	9
#define IFX_VMAPI_PARAM_NAME_T38_OLDASN1							"OldAsn1"
#define IFX_VMAPI_PARAM_NAME_T38_NSX_SIZE							"NsxSize"
#define IFX_VMAPI_PARAM_NAME_T38_NSX_INFO_FIELD     	"NsxInfo"
#define IFX_VMAPI_PARAM_NAME_T38_DATA_WAIT_TIME		    "DataWait"
#define IFX_VMAPI_PARAM_NAME_T38_UDP_HIGH_ERR_REC_PKT	"HighErrRecPkts"
#define IFX_VMAPI_PARAM_NAME_T38_UDP_LOW_ERR_REC_PKT	"LowErrRecPkts"
#define IFX_VMAPI_PARAM_NAME_T38_UDP_PRIOR_FEC_PKT  	"UdpPriorFec"
#define IFX_VMAPI_PARAM_NAME_T38_FRAME_LENGTH       	"FrameLength"
#define IFX_VMAPI_PARAM_NAME_T38_PREF_CONN          	"PrefConn"


/***************************Voice System Numbering Plan***************************/
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_LONG_TIMER					1
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_SHORT_TIMER				2
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NO_NUMPLAN_RULES		3
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES		IFX_VMAPI_OBJ_NUMPLAN_RULE
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_MIN_DGTS						5
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_MAX_DGTS						6

#define IFX_VMAPI_PARAM_NAME_NUMPLAN_LONG_TIMER				"LongTmr"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_SHORT_TIMER			"ShortTmr"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NO_NUMPLAN_RULES		"NoOfRules"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES		"NumPlanRules"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_MIN_DGTS						"MinimumDgts"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_MAX_DGTS						"MaximumDgts"

/************************Numbering Plan Rules********************************/
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_RULE		1
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_PREFIX	2
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_MINLEN	3
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_MAXLEN	4
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_REMDGTS	5
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_POSREM	6
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_DIGINS	7
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_POSINS	8
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_DIGREP	9
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_POSREP	10
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_DIALTONE	11
#define IFX_VMAPI_PARAM_CODE_NUMPLAN_NUMPLANRULES_FACARG	12

#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_RULE		"Rule"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_PREFIX	"Prefix"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_MINLEN	"MinLen"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_MAXLEN	"MaxLen"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_REMDGTS	"RemDgts"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_POSREM	"Pos2Rem"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_DIGINS	"DigIns"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_POSINS	"PosIns"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_DIGREP	"DigRep"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_POSREP	"PosRep"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_DIALTONE	"DialTone"
#define IFX_VMAPI_PARAM_NAME_NUMPLAN_NUMPLANRULES_FACARG	"FacArg"

/*******************************Address Book********************************/
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_NUM_ENTRY		1
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_ADDR_ENTRY  IFX_VMAPI_OBJ_ADDRBOOK_ENTRY 

#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_NUM_ENTRY		"NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_ADDR_ENTRY  "AddrEntry"

/********************************Address Book Entry***************************/
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_ADDR_ENTRY_DIALCODE		1
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_ADDR_ENTRY_CALLTYPE		2
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_ADDR_ENTRY_LINEID		  3
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_ADDR_ENTRY_ENTRYID		4
#define IFX_VMAPI_PARAM_CODE_ADDRBOOK_ADDR_ENTRY_ADDRESS    IFX_VMAPI_OBJ_ADDR_TYPE

#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_ADDR_ENTRY_DIALCODE   "DialCode"
#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_ADDR_ENTRY_CALLTYPE		"CallType"
#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_ADDR_ENTRY_LINEID		  "LineId"
#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_ADDR_ENTRY_ENTRYID		"EntryId"
#define IFX_VMAPI_PARAM_NAME_ADDRBOOK_ADDR_ENTRY_ADDRESS		"AddressType"

/********************************Call Register - Dialled*******************************/
#define IFX_VMAPI_PARAM_CODE_CALLREGISTER_NUM_DIALED		1
#define IFX_VMAPI_PARAM_CODE_CALLREGISTER_ENTRY_DIALED	IFX_VMAPI_OBJ_CALLREG_DIALENTRY

#define IFX_VMAPI_PARAM_NAME_CALLREGISTER_NUM_DIALED		"CallRegNumOfDials"
#define IFX_VMAPI_PARAM_NAME_CALLREGISTER_ENTRY_DIALED	"DialEntry"

/********************************PSTN Call Register - Dialled*******************************/
#define IFX_VMAPI_PARAM_CODE_PSTN_CALLREGISTER_NUM_DIALED		1
#define IFX_VMAPI_PARAM_CODE_PSTN_CALLREGISTER_ENTRY_DIALED	IFX_VMAPI_OBJ_PSTN_CALLREG_DIALENTRY

#define IFX_VMAPI_PARAM_NAME_PSTN_CALLREGISTER_NUM_DIALED		"CallRegNumOfDials"
#define IFX_VMAPI_PARAM_NAME_PSTN_CALLREGISTER_ENTRY_DIALED	"PstnDialEntry"

/************************************Call Register Entry - Dial Entries**********************/
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_TIME		  1
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_DATE	    2
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_CALLTYPE	3
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_ADDR		IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_LINEID	  5
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_STATUS	  6
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_NOOFCALLS	  7
#define IFX_VMAPI_PARAM_CODE_DIALCALLREG_ENTRY_ENTRYID	  8

#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_TIME		"DialEntryTime"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_DATE		"DialEntryDate"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_CALLTYPE		"DialEntryCallType"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_ADDR		"AddressType"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_LINEID	"DialAddrLineId"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_STATUS	  "DialStatus"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_NOOFCALLS	 "DialNoOfCalls"
#define IFX_VMAPI_PARAM_NAME_DIALCALLREG_ENTRY_ENTRYID	 "DialEntryId"

/********************************Call Register - Missed*******************************/
#define IFX_VMAPI_PARAM_CODE_CALLREGISTER_NUM_MISSED		1
#define IFX_VMAPI_PARAM_CODE_CALLREGISTER_ENTRY_MISSED	IFX_VMAPI_OBJ_CALLREG_MISSENTRY

#define IFX_VMAPI_PARAM_NAME_CALLREGISTER_NUM_MISSED		"CallRegNumOfMiss"
#define IFX_VMAPI_PARAM_NAME_CALLREGISTER_ENTRY_MISSED	"MissEntry"

/********************************PSTN-Call Register - Missed*******************************/
#define IFX_VMAPI_PARAM_CODE_PSTN_CALLREGISTER_NUM_MISSED    1
#define IFX_VMAPI_PARAM_CODE_PSTN_CALLREGISTER_ENTRY_MISSED  IFX_VMAPI_OBJ_PSTN_CALLREG_MISSENTRY

#define IFX_VMAPI_PARAM_NAME_PSTN_CALLREGISTER_NUM_MISSED    "CallRegNumOfMiss"
#define IFX_VMAPI_PARAM_NAME_PSTN_CALLREGISTER_ENTRY_MISSED  "PstnMissEntry"


/************************************Call Register Entry - Miss Entries**********************/
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_TIME		  1
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_DATE	    2
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_CALLTYPE	3
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_ADDR		IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_LINEID	  5
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_STATUS	  6
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_NOOFCALLS	  7
#define IFX_VMAPI_PARAM_CODE_MISSCALLREG_ENTRY_ENTRYID	  8

#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_TIME		"MissEntryTime"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_DATE		"MissEntryDate"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_CALLTYPE		"MissEntryCallType"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_ADDR		"AddressType"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_LINEID	"MissAddrLineId"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_STATUS	  "MissStatus"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_NOOFCALLS	  "MissNoOfCalls"
#define IFX_VMAPI_PARAM_NAME_MISSCALLREG_ENTRY_ENTRYID	  "MissEntryId"
/********************************Call Register - Received*******************************/
#define IFX_VMAPI_PARAM_CODE_CALLREGISTER_NUM_RECVD		1
#define IFX_VMAPI_PARAM_CODE_CALLREGISTER_ENTRY_RECVD	IFX_VMAPI_OBJ_CALLREG_RECVENTRY

#define IFX_VMAPI_PARAM_NAME_CALLREGISTER_NUM_RECVD		"CallRegNumOfRecv"
#define IFX_VMAPI_PARAM_NAME_CALLREGISTER_ENTRY_RECVD	"RecvEntry"

/********************************PSTN-Call Register - Received*******************************/
#define IFX_VMAPI_PARAM_CODE_PSTN_CALLREGISTER_NUM_RECVD		1
#define IFX_VMAPI_PARAM_CODE_PSTN_CALLREGISTER_ENTRY_RECVD	IFX_VMAPI_OBJ_PSTN_CALLREG_RECVENTRY

#define IFX_VMAPI_PARAM_NAME_PSTN_CALLREGISTER_NUM_RECVD		"CallRegNumOfRecv"
#define IFX_VMAPI_PARAM_NAME_PSTN_CALLREGISTER_ENTRY_RECVD	"PstnRecvEntry"
/************************************Call Register Entry - Recv Entries**********************/
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_TIME		  1
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_DATE	    2
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_CALLTYPE	3
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_ADDR		IFX_VMAPI_OBJ_ADDR_TYPE
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_LINEID	  5
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_STATUS	  6
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_NOOFCALLS	  7
#define IFX_VMAPI_PARAM_CODE_RECVCALLREG_ENTRY_ENTRYID	  8

#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_TIME		"RecvEntryTime"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_DATE		"RecvEntryDate"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_CALLTYPE		"RecvEntryCallType"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_ADDR		"AddressType"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_LINEID	"RecvAddrLineId"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_STATUS	  "RecvStatus"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_NOOFCALLS	  "RecvNoOfCalls"
#define IFX_VMAPI_PARAM_NAME_RECVCALLREG_ENTRY_ENTRYID	  "RecvEntryId"


/***************************Physical Interface*******************************/
#define IFX_VMAPI_PARAM_CODE_PHY_PORTTYPE        1
#define IFX_VMAPI_PARAM_CODE_PHY_STATUS          2
#define IFX_VMAPI_PARAM_CODE_PHY_INTERFACEID     3
#define IFX_VMAPI_PARAM_CODE_PHY_INTERFACEDESC   4
#define IFX_VMAPI_PARAM_NAME_PHY_PORTTYPE        "PortType"
#define IFX_VMAPI_PARAM_NAME_PHY_STATUS          "Status"
#define IFX_VMAPI_PARAM_NAME_PHY_INTERFACEID     "InterfaceId"
#define IFX_VMAPI_PARAM_NAME_PHY_INTERFACEDESC   "InterfaceDesc"


/********************************* DECT ***************************************/

					/* DECT SubsInfo*/
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_ISREGISTERED		1	
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_IPUI						2
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_TPUI						3
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_AUTHKEY				4
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_CIPHERKEY			5
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_SERVICECLASS		6
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_MODELID				7
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSINFO_TERMCAPAB      8
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_ISREGISTERED		"IsRegistered"				
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_IPUI			  		"IPUI"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_TPUI						"TPUI"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_AUTHKEY				"AuthKey"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_CIPHERKEY			"CipherKey"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_SERVICECLASS		"ServiceClass"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_MODELID				"ModelID"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSINFO_TERMCAPAB			"TermCap"


 
					/* DECT Handset */
#define IFX_VMAPI_PARAM_CODE_DECT_STATUS					1
#define IFX_VMAPI_PARAM_CODE_DECT_IPEI						2
#define IFX_VMAPI_PARAM_CODE_DECT_SUBSCTIME				3
#define IFX_VMAPI_PARAM_CODE_DECT_SMSCAPABLE			4
#define IFX_VMAPI_PARAM_CODE_DECT_WIDEBANDCAPABLE	5
#define IFX_VMAPI_PARAM_CODE_DECT_CHANNELSTR    	6
#define IFX_VMAPI_PARAM_CODE_DECT_DECTSUBSINFO		IFX_VMAPI_OBJ_DECT_SUBSINFO
#define IFX_VMAPI_PARAM_CODE_DECT_PHYIFACE        IFX_VMAPI_OBJ_PHY_IFACE
#define IFX_VMAPI_PARAM_CODE_DECT_ENDPTID					9
#define IFX_VMAPI_PARAM_CODE_DECT_ENDPTNAME				10
#define IFX_VMAPI_PARAM_CODE_DECT_INTERCEPT				11
#define IFX_VMAPI_PARAM_CODE_DECT_VOICELINEID			12
#define IFX_VMAPI_PARAM_CODE_DECT_VOICELINEIDLIST 13
#define IFX_VMAPI_PARAM_NAME_DECT_STATUS					"Status"
#define IFX_VMAPI_PARAM_NAME_DECT_IPEI						"IPEI"
#define IFX_VMAPI_PARAM_NAME_DECT_SUBSCTIME				"SubscTime"
#define IFX_VMAPI_PARAM_NAME_DECT_SMSCAPABLE			"SmsCap"
#define IFX_VMAPI_PARAM_NAME_DECT_WIDEBANDCAPABLE	"WideBandCap"
#define IFX_VMAPI_PARAM_NAME_DECT_CHANNELSTR  		"ChannelStrDect"
#define IFX_VMAPI_PARAM_NAME_DECT_DECTSUBSINFO		"DectSubInfo"
#define IFX_VMAPI_PARAM_NAME_DECT_PHYIFACE        "PhysicalInterface"
#define IFX_VMAPI_PARAM_NAME_DECT_ENDPTID					"EndptId"
#define IFX_VMAPI_PARAM_NAME_DECT_ENDPTNAME				"EndptName"
#define IFX_VMAPI_PARAM_NAME_DECT_INTERCEPT				"Intercept"
#define IFX_VMAPI_PARAM_NAME_DECT_VOICELINEID			"VoiceLineId"
#define IFX_VMAPI_PARAM_NAME_DECT_VOICELINEIDLIST "VoiceLineIdList"

/*************** Dect Codec Description *****************************************/
#define  IFX_VMAPI_PARAM_CODE_DECT_CODEC_ID               1
#define  IFX_VMAPI_PARAM_CODE_DECT_CODEC_NAME             2
#define  IFX_VMAPI_PARAM_CODE_DECT_CODEC_SUPPFRAMELENGTH  3
#define  IFX_VMAPI_PARAM_NAME_DECT_CODEC_ID               "Id"
#define  IFX_VMAPI_PARAM_NAME_DECT_CODEC_NAME             "Name"
#define  IFX_VMAPI_PARAM_NAME_DECT_CODEC_SUPPFRAMELENGTH  "SupFrame"



  /* DECT System */
#define IFX_VMAPI_PARAM_CODE_DECT_NUM_HANDSETS    1
#define IFX_VMAPI_PARAM_CODE_DECT_WAITING_SUBS    2
#define IFX_VMAPI_PARAM_CODE_DECT_HANDSET_TBL			IFX_VMAPI_OBJ_DECT_HANDSET
#define IFX_VMAPI_PARAM_CODE_DECT_AUTH_CODE				4

#define IFX_VMAPI_PARAM_CODE_DECT_DEVICESTRNG			5
#define IFX_VMAPI_PARAM_CODE_DECT_ENCRYPTION			6
#define IFX_VMAPI_PARAM_CODE_DECT_CLOCK_MASTER		7
#define IFX_VMAPI_PARAM_CODE_DECT_NOEMO     			8
#define IFX_VMAPI_PARAM_CODE_DECT_RFCTRL					9
#define IFX_VMAPI_PARAM_CODE_DECT_BASENAME     		10
#define IFX_VMAPI_PARAM_CODE_DECT_NUMCODECS			  11				
#define IFX_VMAPI_PARAM_CODE_DECT_CODECDESC				IFX_VMAPI_OBJ_CODEC_DESC					
#define IFX_VMAPI_PARAM_CODE_DECT_DNA							13	
#define IFX_VMAPI_PARAM_NAME_DECT_NUM_HANDSETS    "NumHandset"
#define IFX_VMAPI_PARAM_NAME_DECT_WAITING_SUBS    "SubscWindow"
#define IFX_VMAPI_PARAM_NAME_DECT_HANDSET_TBL			"DectHandset"
#define IFX_VMAPI_PARAM_NAME_DECT_AUTH_CODE				"AuthCode"

#define IFX_VMAPI_PARAM_NAME_DECT_DEVICESTRNG			"DeviceString"
#define IFX_VMAPI_PARAM_NAME_DECT_ENCRYPTION			"Encrypt"
#define IFX_VMAPI_PARAM_NAME_DECT_CLOCK_MASTER		"ClkMaster"
#define IFX_VMAPI_PARAM_NAME_DECT_NOEMO     			"NoEmo"
#define IFX_VMAPI_PARAM_NAME_DECT_RFCTRL          "RfEnable"
#define IFX_VMAPI_PARAM_NAME_DECT_BASENAME     		"BaseName"

#define IFX_VMAPI_PARAM_NAME_DECT_NUMCODECS				"DectNumCodecs"
#define IFX_VMAPI_PARAM_NAME_DECT_DNA							"Dna"
#define IFX_VMAPI_PARAM_NAME_DECT_CODECDESC				IFX_VMAPI_OBJ_NAME_DECT_CODEC_DESC

/************************************************************************/
#ifdef MESSAGE_SUPPORT
/*************************** MESSAGE **********************/
					/* INBOX */
#define IFX_VMAPI_PARAM_CODE_MESSAGE_NUM_INBOX		1
#define IFX_VMAPI_PARAM_CODE_MESSAGE_ENTRY_INBOX	IFX_VMAPI_OBJ_MESSAGE_IN_ENTRY

#define IFX_VMAPI_PARAM_NAME_MESSAGE_NUM_INBOX		"NumOfMsgIn"
#define IFX_VMAPI_PARAM_NAME_MESSAGE_ENTRY_INBOX	"MsgInEntry"


					/* INBOX Entry */
#define IFX_VMAPI_PARAM_CODE_MSGENTRY_MSGHDL   		1
#define IFX_VMAPI_PARAM_CODE_MSGENTRY_MSGBODY    	2
#define IFX_VMAPI_PARAM_CODE_MSGENTRY_USER       	3
#define IFX_VMAPI_PARAM_CODE_MSGENTRY_READFFLG   	4
#define IFX_VMAPI_PARAM_NAME_MSGENTRY_MSGHDL 		 "MsgHdl"
#define IFX_VMAPI_PARAM_NAME_MSGENTRY_MSGBODY	   "MsgBody"
#define IFX_VMAPI_PARAM_NAME_MSGENTRY_USER	     "MsgUser"
#define IFX_VMAPI_PARAM_NAME_MSGENTRY_READFLG    "ReadFlg"

					/* OUTBOX */
#define IFX_VMAPI_PARAM_CODE_MESSAGE_NUM_OUTBOX		1
#define IFX_VMAPI_PARAM_CODE_MESSAGE_ENTRY_OUTBOX	IFX_VMAPI_OBJ_MESSAGE_OUT_ENTRY

#define IFX_VMAPI_PARAM_NAME_MESSAGE_NUM_OUTBOX		"NumOfMsgOut"
#define IFX_VMAPI_PARAM_NAME_MESSAGE_ENTRY_OUTBOX	"MsgOutEntry"


					/* OUTBOX Entry */
#define IFX_VMAPI_PARAM_CODE_OUT_MSGENTRY_MSGHDL   		1
#define IFX_VMAPI_PARAM_CODE_OUT_MSGENTRY_MSGBODY    	2
#define IFX_VMAPI_PARAM_CODE_OUT_MSGENTRY_USER       	3
#define IFX_VMAPI_PARAM_CODE_OUT_MSGENTRY_READFFLG   	4
#define IFX_VMAPI_PARAM_NAME_OUT_MSGENTRY_MSGHDL 		 "MsgHdlOut"
#define IFX_VMAPI_PARAM_NAME_OUT_MSGENTRY_MSGBODY	   "MsgBodyOut"
#define IFX_VMAPI_PARAM_NAME_OUT_MSGENTRY_USER	     "MsgUserOut"
#define IFX_VMAPI_PARAM_NAME_OUT_MSGENTRY_READFLG    "ReadFlgOut"
 

#endif /* MESSAGE_SUPPORT */

/* TRANSMIT POWER CONTROL */
#define IFX_VMAPI_PARAM_CODE_TP_TUNE_DIGITAL_REF       1
#define IFX_VMAPI_PARAM_CODE_TP_PA_BIAS_REF            2
#define IFX_VMAPI_PARAM_CODE_TP_PWROFFSET_ZERO         3
#define IFX_VMAPI_PARAM_CODE_TP_PWROFFSET_ONE          4
#define IFX_VMAPI_PARAM_CODE_TP_PWROFFSET_TWO          5
#define IFX_VMAPI_PARAM_CODE_TP_PWROFFSET_THREE        6
#define IFX_VMAPI_PARAM_CODE_TP_PWROFFSET_FOUR         7
#define IFX_VMAPI_PARAM_CODE_TP_TD_ONE                 8
#define IFX_VMAPI_PARAM_CODE_TP_TD_TWO                 9
#define IFX_VMAPI_PARAM_CODE_TP_TD_THREE               10
#define IFX_VMAPI_PARAM_CODE_TP_PA_ONE                 11
#define IFX_VMAPI_PARAM_CODE_TP_PA_TWO                 12
#define IFX_VMAPI_PARAM_CODE_TP_PA_THREE               13
#define IFX_VMAPI_PARAM_CODE_TP_SWPWRMODE             14
#define IFX_VMAPI_PARAM_CODE_TP_TXPOW_ZERO            15
#define IFX_VMAPI_PARAM_CODE_TP_TXPOW_ONE             16
#define IFX_VMAPI_PARAM_CODE_TP_TXPOW_TWO             17
#define IFX_VMAPI_PARAM_CODE_TP_TXPOW_THREE           18
#define IFX_VMAPI_PARAM_CODE_TP_TXPOW_FOUR            19
#define IFX_VMAPI_PARAM_CODE_TP_TXPOW_FIVE 	          20
#define IFX_VMAPI_PARAM_CODE_TP_DBPOW	              21
#define IFX_VMAPI_PARAM_CODE_TP_TUNE_DIGITAL	              22
#define IFX_VMAPI_PARAM_CODE_TP_TX_BIAS	              23
#define IFX_VMAPI_PARAM_NAME_TP_TUNE_DIGITAL_REF       "TunDgtRef"
#define IFX_VMAPI_PARAM_NAME_TP_PA_BIAS_REF            "PABiasRef"
#define IFX_VMAPI_PARAM_NAME_TP_PWROFFSET_ZERO         "Pwroffset0"
#define IFX_VMAPI_PARAM_NAME_TP_PWROFFSET_ONE          "Pwroffset1"
#define IFX_VMAPI_PARAM_NAME_TP_PWROFFSET_TWO          "Pwroffset2"
#define IFX_VMAPI_PARAM_NAME_TP_PWROFFSET_THREE        "Pwroffset3"
#define IFX_VMAPI_PARAM_NAME_TP_PWROFFSET_FOUR         "Pwroffset4"
#define IFX_VMAPI_PARAM_NAME_TP_TD_ONE                 "TD1"
#define IFX_VMAPI_PARAM_NAME_TP_TD_TWO                 "TD2"
#define IFX_VMAPI_PARAM_NAME_TP_TD_THREE               "TD3"
#define IFX_VMAPI_PARAM_NAME_TP_PA_ONE                 "PA1"
#define IFX_VMAPI_PARAM_NAME_TP_PA_TWO                 "PA2"
#define IFX_VMAPI_PARAM_NAME_TP_PA_THREE               "PA3"
#define IFX_VMAPI_PARAM_NAME_TP_SWPWRMODE              "SwPwrMde"
#define IFX_VMAPI_PARAM_NAME_TP_TXPOW_ZERO             "Txpow0"
#define IFX_VMAPI_PARAM_NAME_TP_TXPOW_ONE              "Txpow1"
#define IFX_VMAPI_PARAM_NAME_TP_TXPOW_TWO              "Txpow2"
#define IFX_VMAPI_PARAM_NAME_TP_TXPOW_THREE            "Txpow3"
#define IFX_VMAPI_PARAM_NAME_TP_TXPOW_FOUR             "Txpow4"
#define IFX_VMAPI_PARAM_NAME_TP_TXPOW_FIVE 	       "Txpow5"
#define IFX_VMAPI_PARAM_NAME_TP_DBPOW    	       "Dbpow"
#define IFX_VMAPI_PARAM_NAME_TP_TUNE_DIGITAL    	       "TuneDigit"
#define IFX_VMAPI_PARAM_NAME_TP_TX_BIAS    	       "TxBias"

/* RF MODE */
#define IFX_VMAPI_PARAM_CODE_RFM_TEST_MODE              1
#define IFX_VMAPI_PARAM_CODE_RFM_CHANNEL                2
#define IFX_VMAPI_PARAM_CODE_RFM_SLOT                   3
#define IFX_VMAPI_PARAM_NAME_RFM_TEST_MODE              "TstMode"
#define IFX_VMAPI_PARAM_NAME_RFM_CHANNEL                "Channel"
#define IFX_VMAPI_PARAM_NAME_RFM_SLOT                   "Slot"

/*RFPI*/
#define IFX_VMAPI_PARAM_CODE_RFPI_BYTE_ONE              1
#define IFX_VMAPI_PARAM_CODE_RFPI_BYTE_TWO              2
#define IFX_VMAPI_PARAM_CODE_RFPI_BYTE_THREE            3
#define IFX_VMAPI_PARAM_CODE_RFPI_BYTE_FOUR             4
#define IFX_VMAPI_PARAM_CODE_RFPI_BYTE_FIVE             5
#define IFX_VMAPI_PARAM_CODE_RFPI_BYTE_SIX              6
#define IFX_VMAPI_PARAM_NAME_RFPI_BYTE_ONE              "byte1"
#define IFX_VMAPI_PARAM_NAME_RFPI_BYTE_TWO              "byte2"
#define IFX_VMAPI_PARAM_NAME_RFPI_BYTE_THREE            "byte3"
#define IFX_VMAPI_PARAM_NAME_RFPI_BYTE_FOUR             "byte4"
#define IFX_VMAPI_PARAM_NAME_RFPI_BYTE_FIVE             "byte5"
#define IFX_VMAPI_PARAM_NAME_RFPI_BYTE_SIX              "byte6"

/*XRAM*/
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_ONE              1
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_TWO              2
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_THREE            3
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_FOUR             4
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_FIVE             5
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_SIX              6
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_SEVEN            7
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_EIGHT            8
#define IFX_VMAPI_PARAM_CODE_XRAM_BYTE_NINE             9
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_ONE              "byte1"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_TWO              "byte2"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_THREE            "byte3"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_FOUR             "byte4"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_FIVE             "byte5"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_SIX              "byte6"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_SEVEN            "byte7"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_EIGHT            "byte8"
#define IFX_VMAPI_PARAM_NAME_XRAM_BYTE_NINE             "byte9"


#define IFX_VMAPI_PARAM_CODE_COUNTRY_SETTINGS_TX_OFFSET              1
#define IFX_VMAPI_PARAM_CODE_COUNTRY_SETTINGS_RX_OFFSET              2
#define IFX_VMAPI_PARAM_CODE_COUNTRY_SETTINGS_FREQ_RANGE             3
#define IFX_VMAPI_PARAM_CODE_COUNTRY_SETTINGS_ECI				             4 
#define IFX_VMAPI_PARAM_CODE_COUNTRY_SETTINGS_CHMASK_HIGH            5 
#define IFX_VMAPI_PARAM_CODE_COUNTRY_SETTINGS_CHMASK_LOW             6 
#define IFX_VMAPI_PARAM_NAME_COUNTRY_SETTINGS_TX_OFFSET              "Txoffset"
#define IFX_VMAPI_PARAM_NAME_COUNTRY_SETTINGS_RX_OFFSET              "Rxoffset"
#define IFX_VMAPI_PARAM_NAME_COUNTRY_SETTINGS_FREQ_RANGE             "FreqRange"
#define IFX_VMAPI_PARAM_NAME_COUNTRY_SETTINGS_ECI            				 "Eci"
#define IFX_VMAPI_PARAM_NAME_COUNTRY_SETTINGS_CHMASK_HIGH            "MaskHigh"
#define IFX_VMAPI_PARAM_NAME_COUNTRY_SETTINGS_CHMASK_LOW             "MaskLow"


#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RSSI_FREELEVEL      1
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RSSI_BUSYLEVEL      2
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_BEARER_CHANGE_LIMIT 3
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_DEFAULT_ANTENNA     4
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_WOPNSF              5
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_WWSF                6
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_CNTUP_CTRL_REG      7
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_DELAY_REG           8
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_HANDOVER_EVALPER    9
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_SYNCM_CTRL_REG      10
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RESERVED_0          11
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RESERVED_1          12
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RESERVED_2          13
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RESERVED_3          14
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RESERVED_4          15
#define IFX_VMAPI_PARAM_CODE_BMC_REG_PARAMS_RESERVED_5          16
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RSSI_FREELEVEL      "RssiFreeLevel"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RSSI_BUSYLEVEL      "RssiBusyLevel"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_BEARER_CHANGE_LIMIT "BearerChgLimit"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_DEFAULT_ANTENNA     "DefaultAntenna"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_WOPNSF              "WOPNSF"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_WWSF                "WWSF"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_CNTUP_CTRL_REG      "CNTUPCtrlReg"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_DELAY_REG           "DelayReg"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_HANDOVER_EVALPER    "HandOverEvalper"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_SYNCM_CTRL_REG      "SYNCMCtrlReg"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RESERVED_0          "Reserved_0"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RESERVED_1          "Reserved_1"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RESERVED_2          "Reserved_2"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RESERVED_3          "Reserved_3"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RESERVED_4          "Reserved_4"
#define IFX_VMAPI_PARAM_NAME_BMC_REG_PARAMS_RESERVED_5          "Reserved_5"

#define IFX_VMAPI_PARAM_CODE_OSC_TRIM_HIGH       1
#define IFX_VMAPI_PARAM_CODE_OSC_TRIM_LOW        2
#define IFX_VMAPI_PARAM_CODE_OSC_TRIM_P10_STATUS 3
#define IFX_VMAPI_PARAM_NAME_OSC_TRIM_HIGH       "Osctrimhigh"
#define IFX_VMAPI_PARAM_NAME_OSC_TRIM_LOW        "Osctrimlow"
#define IFX_VMAPI_PARAM_NAME_OSC_TRIM_P10_STATUS "P10Status"

#define IFX_VMAPI_PARAM_CODE_GFSK_HIGH       1
#define IFX_VMAPI_PARAM_CODE_GFSK_LOW        2
#define IFX_VMAPI_PARAM_NAME_GFSK_HIGH       "Gfskhigh"
#define IFX_VMAPI_PARAM_NAME_GFSK_LOW        "Gfsklow"


/************************************************************************/
#ifdef LTAM
/***************************Physical Interface Test**********************/
#define IFX_VMAPI_PARAM_CODE_PHYTEST_PORT_NO				1
#define IFX_VMAPI_PARAM_CODE_PHYTEST_PORT_TYP			  2
#define IFX_VMAPI_PARAM_CODE_PHYTEST_INTERFACE_ID		3
#define IFX_VMAPI_PARAM_CODE_PHYTEST_TEST_TYP		    4
#define IFX_VMAPI_PARAM_CODE_PHYTEST_TEST_STATE		    5
#define IFX_VMAPI_PARAM_NAME_PHYTEST_PORT_NO				"PortNum"
#define IFX_VMAPI_PARAM_NAME_PHYTEST_PORT_TYP				"PortType"
#define IFX_VMAPI_PARAM_NAME_PHYTEST_INTERFACE_ID		"IntId"
#define IFX_VMAPI_PARAM_NAME_PHYTEST_TEST_TYP   		"TestType"
#define IFX_VMAPI_PARAM_NAME_PHYTEST_TEST_STATE   		"TestState"

/************************************************************************/

/**********************Physical Interface TestResult**********************/
/* Voltage Test Result */
#define IFX_VMAPI_PARAM_CODE_VOLTRES_STATUS				1
#define IFX_VMAPI_PARAM_CODE_VOLTRES_ACR2G    		2
#define IFX_VMAPI_PARAM_CODE_VOLTRES_ACT2G		    3
#define IFX_VMAPI_PARAM_CODE_VOLTRES_ACT2R		    4
#define IFX_VMAPI_PARAM_CODE_VOLTRES_DCR2G		    5
#define IFX_VMAPI_PARAM_CODE_VOLTRES_DCT2G		    6
#define IFX_VMAPI_PARAM_CODE_VOLTRES_DCT2R		    7
#define IFX_VMAPI_PARAM_NAME_VOLTRES_STATUS				"Status"
#define IFX_VMAPI_PARAM_NAME_VOLTRES_ACR2G    		"Acr2g"
#define IFX_VMAPI_PARAM_NAME_VOLTRES_ACT2G		    "Act2g"
#define IFX_VMAPI_PARAM_NAME_VOLTRES_ACT2R		    "Act2r"
#define IFX_VMAPI_PARAM_NAME_VOLTRES_DCR2G		    "Dcr2g"
#define IFX_VMAPI_PARAM_NAME_VOLTRES_DCT2G		    "Dct2g"
#define IFX_VMAPI_PARAM_NAME_VOLTRES_DCT2R		    "Dct2r"
				
/* RFT(Resistive Fault) Test Result */
#define IFX_VMAPI_PARAM_CODE_RFT_STATUS   				1
#define IFX_VMAPI_PARAM_CODE_RFT_R2G    	      	2
#define IFX_VMAPI_PARAM_CODE_RFT_T2G		   				3
#define IFX_VMAPI_PARAM_CODE_RFT_T2R		          4
#define IFX_VMAPI_PARAM_NAME_RFT_STATUS	    			"Status"
#define IFX_VMAPI_PARAM_NAME_RFT_R2G    	      	"R2g"
#define IFX_VMAPI_PARAM_NAME_RFT_T2G	      	    "T2g"
#define IFX_VMAPI_PARAM_NAME_RFT_T2R		          "T2r"
				
/* RIT(Ringer Impedance) Test Result */
#define IFX_VMAPI_PARAM_CODE_RIT_STATUS   				1
#define IFX_VMAPI_PARAM_CODE_RIT_VALUE   				  2
#define IFX_VMAPI_PARAM_NAME_RIT_STATUS	    			"Status"
#define IFX_VMAPI_PARAM_NAME_RIT_VALUE   	      	"Val"

/* ROH(Receiver Off Hook) Test Result */
#define IFX_VMAPI_PARAM_CODE_ROH_STATUS   				1
#define IFX_VMAPI_PARAM_CODE_ROH_T2RL   				  2
#define IFX_VMAPI_PARAM_NAME_ROH_STATUS	    			"Status"
#define IFX_VMAPI_PARAM_NAME_ROH_T2RL   	      	"T2rl"

#define IFX_VMAPI_PARAM_CODE_PHYRES_PORT_TYP				1
#define IFX_VMAPI_PARAM_CODE_PHYRES_INTERFACE_ID		2
#define IFX_VMAPI_PARAM_CODE_PHYRES_TEST_TYP		    3
#define IFX_VMAPI_PARAM_CODE_GR909RES_FEMF				  IFX_VMAPI_OBJ_PHY_INT_GR909_VOLT_RES
#define IFX_VMAPI_PARAM_CODE_GR909RES_HPT      		  IFX_VMAPI_OBJ_PHY_INT_GR909_VOLT_RES
#define IFX_VMAPI_PARAM_CODE_GR909RES_RFT      		  IFX_VMAPI_OBJ_PHY_INT_GR909_RFT_RES
#define IFX_VMAPI_PARAM_CODE_GR909RES_RIT      		  IFX_VMAPI_OBJ_PHY_INT_GR909_RIT_RES
#define IFX_VMAPI_PARAM_CODE_GR909RES_ROH      		  IFX_VMAPI_OBJ_PHY_INT_GR909_ROH_RES
#define IFX_VMAPI_PARAM_NAME_PHYRES_PORT_TYP				"PortTyp"
#define IFX_VMAPI_PARAM_NAME_PHYRES_INTERFACE_ID		"IntId"
#define IFX_VMAPI_PARAM_Name_PHYRES_TEST_TYP		    "TestType"
#define IFX_VMAPI_PARAM_NAME_GR909RES_FEMF				  "Femf"
#define IFX_VMAPI_PARAM_NAME_GR909RES_HPT      		  "Hpt"
#define IFX_VMAPI_PARAM_NAME_GR909RES_RFT      		  "Rft"
#define IFX_VMAPI_PARAM_NAME_GR909RES_RIT      		  "Rit"
#define IFX_VMAPI_PARAM_NAME_GR909RES_ROH      		  "Roh"

/************************************************************************/
#endif /*LTAM */



/********************************Contact Address *******************************/
#define IFX_VMAPI_PARAM_CODE_CONTACT_ADDR_USER_FIRST_NAME 1
#define IFX_VMAPI_PARAM_CODE_CONTACT_ADDR_USER_LAST_NAME 2
#define IFX_VMAPI_PARAM_CODE_CONTACT_ADDR_NUMBER 3
#define IFX_VMAPI_PARAM_CODE_CONTACT_ADDR_NUMBER_TYPE 4
#define IFX_VMAPI_PARAM_CODE_CONTACT_ADDR_NUMBER_TWO 5
#define IFX_VMAPI_PARAM_CODE_CONTACT_ADDR_NUMBER_TWO_TYPE 6

#define IFX_VMAPI_PARAM_NAME_CONTACT_ADDR_USER_FIRST_NAME "FirstName" 
#define IFX_VMAPI_PARAM_NAME_CONTACT_ADDR_USER_LAST_NAME  "LastName" 
#define IFX_VMAPI_PARAM_NAME_CONTACT_ADDR_NUMBER	   "ContactNum"	 
#define IFX_VMAPI_PARAM_NAME_CONTACT_ADDR_NUMBER_TYPE	   "Num1Type"	 
#define IFX_VMAPI_PARAM_NAME_CONTACT_ADDR_NUMBER_TWO	   "ContactNum2"	 
#define IFX_VMAPI_PARAM_NAME_CONTACT_ADDR_NUMBER_TWO_TYPE	   "Num2Type"	 

/********************************Contact Register *******************************/
#define IFX_VMAPI_PARAM_CODE_CONTACT_LIST_NUM_ENTRY            1
#define IFX_VMAPI_PARAM_CODE_CONTACT_LIST_ENTRY IFX_VMAPI_OBJ_CONTACT_LIST_ENTRY 

#define IFX_VMAPI_PARAM_NAME_CONTACT_LIST_NUM_ENTRY "NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_CONTACT_LIST_ENTRY  "ContactEntry"

/********************************PSTN-Contact Register *******************************/
#define IFX_VMAPI_PARAM_CODE_PSTN_CONTACT_LIST_NUM_ENTRY            1
#define IFX_VMAPI_PARAM_CODE_PSTN_CONTACT_LIST_ENTRY IFX_VMAPI_OBJ_PSTN_CONTACT_LIST_ENTRY 

#define IFX_VMAPI_PARAM_NAME_PSTN_CONTACT_LIST_NUM_ENTRY "NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_PSTN_CONTACT_LIST_ENTRY  "PstnContactEntry"

/********************************Common-Contact Register *******************************/
#define IFX_VMAPI_PARAM_CODE_COMMON_CONTACT_LIST_NUM_ENTRY            1
#define IFX_VMAPI_PARAM_CODE_COMMON_CONTACT_LIST_ENTRY IFX_VMAPI_OBJ_COMMON_CONTACT_LIST_ENTRY 

#define IFX_VMAPI_PARAM_NAME_COMMON_CONTACT_LIST_NUM_ENTRY "NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_COMMON_CONTACT_LIST_ENTRY  "CommonContactEntry"


/********************************Contact list Entry***************************/
#define IFX_VMAPI_PARAM_CODE_CONTACT_ENTRY_ADDR_ENTRY_LINEID          	1 
#define IFX_VMAPI_PARAM_CODE_CONTACT_ENTRY_ADDR_ENTRY_ENTRYID               2 
#define IFX_VMAPI_PARAM_CODE_CONTACT_ENTRY_ADDR_ENTRY_ADDRESS    IFX_VMAPI_OBJ_CONTACT_ADDR

#define IFX_VMAPI_PARAM_NAME_CONTACT_ENTRY_ADDR_ENTRY_LINEID           "LineId"
#define IFX_VMAPI_PARAM_NAME_CONTACT_ENTRY_ADDR_ENTRY_ENTRYID                "EntryId"
#define IFX_VMAPI_PARAM_NAME_CONTACT_ENTRY_ADDR_ENTRY_ADDRESS                "AddressType"


#ifdef DECT_SENSORS_SUPPORT

/** Sensor information structure params */
#define IFX_VMAPI_PARAM_CODE_SENSOR_INFO_NAME 1
#define IFX_VMAPI_PARAM_CODE_SENSOR_INFO_REG_STATUS 2
#define IFX_VMAPI_PARAM_CODE_SENSOR_INFO_POWER_STATUS 3
#define IFX_VMAPI_PARAM_CODE_SENSOR_INFO_INTERVAL 4
#define IFX_VMAPI_PARAM_NAME_SENSOR_INFO_NAME "SenName"
#define IFX_VMAPI_PARAM_NAME_SENSOR_INFO_REG_STATUS "RegStat"
#define IFX_VMAPI_PARAM_NAME_SENSOR_INFO_POWER_STATUS "PowStat"
#define IFX_VMAPI_PARAM_NAME_SENSOR_INFO_INTERVAL "ReadInt"

/*** Sensor Alaram information structure ***/
#define IFX_VMAPI_PARAM_CODE_ALARAM_MSG 1
#define IFX_VMAPI_PARAM_CODE_ALARAM_TIME 2
#define IFX_VMAPI_PARAM_NAME_ALARAM_MSG "AlrmMsg"
#define IFX_VMAPI_PARAM_NAME_ALARAM_TIME "AlrmTime"

/**** Power sensor Read Parameters **/
#define IFX_VMAPI_PARAM_CODE_POWER_PARAM1 1
#define IFX_VMAPI_PARAM_CODE_POWER_PARAM2 2
#define IFX_VMAPI_PARAM_CODE_POWER_PARAM3 3
#define IFX_VMAPI_PARAM_CODE_POWER_READTIME 4

#define IFX_VMAPI_PARAM_NAME_POWER_PARAM1 "PowParam1"
#define IFX_VMAPI_PARAM_NAME_POWER_PARAM2 "PowParam2"
#define IFX_VMAPI_PARAM_NAME_POWER_PARAM3 "PowParam3"
#define IFX_VMAPI_PARAM_NAME_POWER_READTIME "PowReadTime"


/********************************Sensor List Entry***************************/
#define IFX_VMAPI_PARAM_CODE_SENSOR_ENTRY_ENTRYID               1 
#define IFX_VMAPI_PARAM_CODE_SENSOR_ENTRY_BATTERY_LEVEL         2 
#define IFX_VMAPI_PARAM_CODE_SENSOR_ENTRY_SENSOR_INFO  IFX_VMAPI_OBJ_SENSOR_INFO

#define IFX_VMAPI_PARAM_NAME_SENSOR_ENTRY_ENTRYID               "EntryId" 
#define IFX_VMAPI_PARAM_NAME_SENSOR_ENTRY_BATTERY_LEVEL         "BatLevel" 
#define IFX_VMAPI_PARAM_NAME_SENSOR_ENTRY_SENSOR_INFO  IFX_VMAPI_OBJ_NAME_SENSOR_INFO 


/********************************Power Sensor List Entry***************************/
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_ENTRY_ENTRYID               1 
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_ENTRY_SENSOR_INFO    IFX_VMAPI_OBJ_SENSOR_INFO

#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_ENTRY_ENTRYID               "EntryId" 
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_ENTRY_SENSOR_INFO  IFX_VMAPI_OBJ_NAME_SENSOR_INFO 

/********************************Motion Sensor List ************************************/
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_LIST_NUM_ENTRY           1
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_LIST_PRESET_NUM          2
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_LIST_ALL_POWON           3
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_LIST_TONE_ALARAM         4
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_LIST_ENTRY IFX_VMAPI_OBJ_MOTION_SENSOR_ENTRY 

#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_LIST_NUM_ENTRY "NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_LIST_PRESET_NUM "PresetNo" 
#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_LIST_ALL_POWON "AllPowerOn"
#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_LIST_TONE_ALARAM "ToneAlaram" 
#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_LIST_ENTRY IFX_VMAPI_OBJ_NAME_MOTION_SENSOR_ENTRY 

/********************************Smoke Sensor List ************************************/
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_LIST_NUM_ENTRY           1
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_LIST_PRESET_NUM          2
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_LIST_ALL_POWON           3
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_LIST_TONE_ALARAM            4
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_LIST_ENTRY IFX_VMAPI_OBJ_SMOKE_SENSOR_ENTRY 

#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_LIST_NUM_ENTRY "NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_LIST_PRESET_NUM "PresetNo" 
#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_LIST_ALL_POWON "AllPowerOn"
#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_LIST_TONE_ALARAM "ToneAlaram" 
#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_LIST_ENTRY IFX_VMAPI_OBJ_NAME_SMOKE_SENSOR_ENTRY 


/********************************  Power Sensor Register *******************************/
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_LIST_NUM_ENTRY          1
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_LIST_ALL_POWON   				2        
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_LIST_ENTRY IFX_VMAPI_OBJ_POWER_SENSOR_ENTRY 

#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_LIST_NUM_ENTRY "NoOfEntry"
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_LIST_ALL_POWON   "AllPowerOn"        
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_LIST_ENTRY IFX_VMAPI_OBJ_NAME_POWER_SENSOR_ENTRY 

/********************************Sensor Alaram List Entry***************************/
#define IFX_VMAPI_PARAM_CODE_SENSOR_ALARAM_READ_ENTRYID            1
#define IFX_VMAPI_PARAM_CODE_SENSOR_ALARAM_READ_SENSORID           2
#define IFX_VMAPI_PARAM_CODE_SENSOR_ALARAM_READ_ENTRY  IFX_VMAPI_OBJ_SENSOR_ALARAM_INFO          

#define IFX_VMAPI_PARAM_NAME_SENSOR_ALARAM_READ_ENTRYID           "EntryId"  
#define IFX_VMAPI_PARAM_NAME_SENSOR_ALARAM_READ_SENSORID          "SensorId"  
#define IFX_VMAPI_PARAM_NAME_SENSOR_ALARAM_READ_ENTRY        IFX_VMAPI_OBJ_NAME_SENSOR_ALARAM_INFO    

/********************************Motion Sensor Alaram List ***************************/
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_ALARAM_LIST_NUM_ENTRY            1
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_ALARAM_LIST_SENSORID           2
#define IFX_VMAPI_PARAM_CODE_MOTION_SENSOR_ALARAM_LIST_ENTRY  IFX_VMAPI_OBJ_MOTION_SENSOR_ALARAM_ENTRY          

#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_ALARAM_LIST_NUM_ENTRY         "NoOfEntry" 
#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_ALARAM_LIST_SENSORID          "SensorId"  
#define IFX_VMAPI_PARAM_NAME_MOTION_SENSOR_ALARAM_LIST_ENTRY        IFX_VMAPI_OBJ_NAME_MOTION_SENSOR_ALARAM_ENTRY   

/********************************Smoke Sensor Alaram List ***************************/
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_ALARAM_LIST_NUM_ENTRY            1
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_ALARAM_LIST_SENSORID           2
#define IFX_VMAPI_PARAM_CODE_SMOKE_SENSOR_ALARAM_LIST_ENTRY  IFX_VMAPI_OBJ_SMOKE_SENSOR_ALARAM_ENTRY          

#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_ALARAM_LIST_NUM_ENTRY         "NoOfEntry" 
#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_ALARAM_LIST_SENSORID          "SensorId"  
#define IFX_VMAPI_PARAM_NAME_SMOKE_SENSOR_ALARAM_LIST_ENTRY        IFX_VMAPI_OBJ_NAME_SMOKE_SENSOR_ALARAM_ENTRY    


/********************************Power Sensor Read List Entry***************************/
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_READ_ENTRYID            1
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_READ_SENSORID           2
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_READ_ENTRY  IFX_VMAPI_OBJ_POWER_READ_INFO          

#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_READ_ENTRYID           "EntryId"  
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_READ_SENSORID          "SensorId"  
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_READ_ENTRY        IFX_VMAPI_OBJ_NAME_POWER_READ_INFO  

/********************************Power Sensor Read List ***************************/
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_READ_LIST_NUM_ENTRY            1
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_READ_LIST_SENSORID           2
#define IFX_VMAPI_PARAM_CODE_POWER_SENSOR_READ_LIST_ENTRY  IFX_VMAPI_OBJ_POWER_SENSOR_READ_ENTRY          

#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_READ_LIST_NUM_ENTRY        "NoOfEntry" 
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_READ_LIST_SENSORID          "SensorId" 
#define IFX_VMAPI_PARAM_NAME_POWER_SENSOR_READ_LIST_ENTRY        IFX_VMAPI_OBJ_NAME_POWER_SENSOR_READ_ENTRY  

#endif

#define IFX_VMAPI_GET_OBJ_PREFIX(ObjId) axObjTbl[(ObjId)-1].acPrefix
#define IFX_VMAPI_GET_OBJ_NAME(ObjId) axObjTbl[(ObjId)-1].acName

#define IFX_VMAPI_GET_PARAM_NAME(pxParamTbl, uiParamId) \
                            pxParamTbl[uiParamId].acName
#define IFX_VMAPI_GET_PARAM_ID(pxParamTbl, uiParamId) \
                            (pxParamTbl)[uiParamId].unParamCode
#define IFX_VMAPI_GET_PARAM_TYPE(pxParamTbl, uiParamId) \
                            (pxParamTbl)[uiParamId].ucParamType
#define IFX_VMAPI_GET_PARAM_OFFSET(pxParamTbl, uiParamId) \
                            (pxParamTbl)[uiParamId].uiOffset
#define IFX_VMAPI_GET_PARAM_INSTANCES_OFFSET(pxParamTbl, uiParamId) \
                            (pxParamTbl)[uiParamId].uiNumInstanceOffset

int32
IFX_VMAPI_GetParamTbl(OUT x_IFX_VMAPI_ParamTxtMap ** ppParamTbl,
                      OUT  uint32 *uiNumParam,
                      OUT uint32 *uiObjSize,
                        IN uint16 unObjCode);
/* @} */

#ifdef __cplusplus 
}
#endif

#endif /* __IFX_VMAPI_OBJ_PARAM_TBL_H__ */
