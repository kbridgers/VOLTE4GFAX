/**************************************************************************
 **   FILE NAME       : ifx_vmapi_cpeid.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Applications requiring cpeId
 **   SRC VERSION     : V0.1
 **   DATE            : 13-03-2007
 **   AUTHOR          : 
 **   DESCRIPTION     : This file defines the mechanism for maintaining
 **											the cpeId for the use of applications reequired
 **											to call the VMAPI ifx_get* and ifx_set* APIs.
 **   FUNCTIONS       : IFX_VMAPI_Get_CpeId
 **											IFX_VMAPI_Update_CpeId								
 **											IFX_VMAPI_Get_NextCpeId
 **											
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include <stdio.h>
#include <string.h>
#include "ifx_vmapi_port.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi_bintxt.h"
#include "ifx_vmapi_obj_param_tbl.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "stdlib.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "ifx_list.h"



#define IFX_MAX_VOICE_LINES IFX_VMAPI_MAX_VOICE_LINES
#define IFX_MAX_PSTN_LINES IFX_VMAPI_MAX_PSTN_LINES

#define FIFO_NAME "/tmp/my_fifo"

  /* Bitmap that helps in intimating the process about the change*/

  /* Infotype bit map word 1 */
   int32 uiBitMap1;

  /* InfoType bit map word 2 */
   int32 uiBitMap2;



/* Notification related  */
PUBLIC char8 IFX_VMAPI_IsObjectRegistered(IN uchar8 ucInfoType);

PUBLIC char8 IFX_VMAPI_SendNotifyForRegObject(IN uchar8 ucInfoType,
                                           IN void *pvOldObj , IN void *pvNewObj);


/**** CPEID *********/
#if 0
PUBLIC int32 IFX_VMAPI_Get_CpeId(IN uchar8 ucObjType, 
																 IN VOID *pxObj,
																 OUT uint32 *uiCpeId);
PUBLIC int32 IFX_VMAPI_Update_CpeId(IN uchar8 ucObjType, 
																 	 IN VOID *pxObj,
																	 OUT uint32 uiCpeId);
#else
int32 IFX_VMAPI_Get_CpeId_opt(IN char8 *pcCommand, 
															IN uchar8 ucIndex,
														  OUT uint32 *uiCpeId);

PUBLIC int32 IFX_VMAPI_Update_CpeId_opt(IN char8 *pcCommand,
                                        IN char8 ucIndex,
                                        IN uint32 uiCpeId);

#endif
int32 IFX_VMAPI_Get_NextCpeId(IN uint32 uiObjCode,
															OUT uint32 *uiCpeId);


int32 IFX_VMAPI_Get_NewLineId();

int32 IFX_VMAPI_Update_NewLineId(uchar8 iLineId);

int32 IFX_VMAPI_Get_NewProfileId();

int32 IFX_VMAPI_Update_NewProfileId(uchar8 iProfileId);

uchar8 IFX_VMAPI_Get_LatestProfileId();

uchar8 IFX_VMAPI_Get_LatestLineId();

int32 ifx_Parse_CpeId (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength) ;

int
ifx_vmapi_ParseCpeId (char8 * ucSrc, char8 * ucDestList,
                              uchar8 * iLength); 

uchar8 
IFX_VMAPI_Get_LinePcpeId(IN uchar8 ucLineId, OUT uchar8 *pucPcpeId);


uchar8 IFX_VMAPI_ReplaceCpeId(IN char8* pcPrefix,
															IN uint32 uiCpeId);


int32 
IFX_VMAPI_GetProfileIdFromCpeId(uint32 uiCpeId, uchar8 *ucProfileId);


int32 IFX_VMAPI_Delete_ProfileId(uchar8 iProfileId);

int32 IFX_VMAPI_Delete_LineId(uchar8 iLineId);

int32 IFX_VMAPI_GetLineIdFromCpeId(uint32 uiCpeId, uchar8 *ucLineId);

int32 
IFX_VMAPI_AssociateLineIdwithProfileId(uchar8 ucProfileId, uchar8 ucLineId);

uint32 IFX_VMAPI_GetBitMapEntry(uchar8 uiPat , uint32 *uiBitMap);
uchar8 IFX_VMAPI_SetBitMapEntry(uchar8 uiPat, uint32 uiBitMap);
int32 ifx_update_EntryId(uchar8 ucList);
int32 ifx_get_EntryId(uchar8 ucList, uint32 *uiEntryId);
int32 ifx_free_EntryId(uchar8 ucList, uint32 uiEntryId);

/*******************************************************************************/
