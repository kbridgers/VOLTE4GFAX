/**************************************************************************
 **   FILE NAME       : ifx_vmapi_bintext.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Voice Management API 
 **   SRC VERSION     : V0.1
 **   DATE            : 20-06-2006
 **   AUTHOR          : Prashant
 **   DESCRIPTION     : This file defines the textual mapping of the 
 **                     data structures used for the Voice Management API
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright � 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_VMAPI_BINTXT_H__
#define __IFX_VMAPI_BINTXT_H__

/*! \file ifx_vmapi_bintxt.h
    \brief This file contains data structures and Function Prototypes for Binary-to-Text
           and Text-to-Binary conversions.
*/

#ifdef __cpluplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>


/** \defgroup VMAPI_BINTXT Binary-to-Text & Text-to-Binary Conversion
This section contains the constants, data structures and the functions prototypes used for binary-to-text and text-to-binary conversions.
*/

/**************************************/
/** \ingroup VMAPI_BINTXT */
/** \defgroup BIN_TO_TXT_STR_LIMITS Macros defining the limit of string paramters. */

/* @{ */

/*!\define IFX_VMAPI_TXT_MAX_NAME_LEN
   \brief ceiling of the object name length
*/ 
#define IFX_VMAPI_TXT_MAX_NAME_LEN  32

/*!\define IFX_VMAPI_TXT_MAX_PREF_LEN
   \brief ceiling of the object prefix length 
*/ 
#define IFX_VMAPI_TXT_MAX_PREF_LEN  100

#if 1
/*!\define IFX_VMAPI_MAX_NAME_LEN
   \brief ceiling of the name length in name-value pair
*/ 
#define IFX_VMAPI_MAX_NAME_LEN      2000
#endif

/*!\define IFX_VMAPI_MAX_VALUE_LEN
   \brief ceiling of the value length in name-value pair
*/ 
#define IFX_VMAPI_MAX_VALUE_LEN    2000

/*!\define IFX_VMAPI_MAX_NV_PAIRS
   \brief max number of name-value pairs in the name-value list
*/ 
#define IFX_VMAPI_MAX_NV_PAIRS     128

/*!\define IFX_VMAPI_MAX_INT_LEN
   \brief max length of integer used in string
*/ 
#define IFX_VMAPI_MAX_INT_LEN     12

/* @} */
/**************************************/

/**************************************/
/** \ingroup VMAPI_BINTXT */
/** \defgroup BIN_TO_TXT Macros defining the parameter types
Each parameter in the paramters table is of the type of these constants. The algorithm for binary-to-text and text-to-binary conversion acts based on the type of parameters.
*/
/* @{ */

#define IFX_VMAPI_PARAM_TYPE_CHAR         1   /*!< parameter is char */
#define IFX_VMAPI_PARAM_TYPE_UCHAR        2   /*!< parameter is unsigned char */
#define IFX_VMAPI_PARAM_TYPE_SHORT_INT    3    /*!< parameter is short int */  
#define IFX_VMAPI_PARAM_TYPE_USHORT_INT   4   /*!< parameter is unsigned short int */
#define IFX_VMAPI_PARAM_TYPE_INT          5   /*!< parameter is int */
#define IFX_VMAPI_PARAM_TYPE_UINT         6   /*!< parameter is unsigned int */
#define IFX_VMAPI_PARAM_TYPE_LONG         7   /*!< parameter is long */
#define IFX_VMAPI_PARAM_TYPE_ULONG        8   /*!< parameter is unsigned long */
#define IFX_VMAPI_PARAM_TYPE_FLOAT        9   /*!< parameter is float */
#define IFX_VMAPI_PARAM_TYPE_DOUBLE       10  /*!< parameter is double */ 
#define IFX_VMAPI_PARAM_TYPE_STR          11  /*!< parameter is string */
#define IFX_VMAPI_PARAM_TYPE_OBJ          12  /*!< parameter is an object */
#define IFX_VMAPI_PARAM_TYPE_OBJ_LIST     13  /*!< parameter is an object */

/* @} */
/**************************************/


/**************************************/
/** \ingroup VMAPI_BINTXT */
/** \defgroup OBJ_PARAM Object and Parameters
These structures contain information about objects and parameters. Array of such structures form the object and paramter tables. These tables are used during the binary-to-text and text-to-binary conversions.
*/

/* @{ */

/** This structure represents a VMAPI object. It is used for storing information pertaiing to a object.Array of such objects are stored in a table.
*/
typedef struct
{
  uint16 unObjId;  /*!< Object Id */
  char8 acName[IFX_VMAPI_TXT_MAX_NAME_LEN]; /*!< Object Name */
  char8 acPrefix[IFX_VMAPI_TXT_MAX_PREF_LEN];  /*!< Object Prefix */
} x_IFX_VMAPI_ObjTxtMap;


/** This structure represents a VMAPI object. It is used for storing information pertaiing to a object.Array of such objects are stored in a table.
*/
typedef struct
{
  uint16 unParamCode;  /*!< Parameter Id */
  uchar8 ucParamType;  /*!< Paramter Type - can be any one of the IFX_VMAPI_PARAM_TYPE_* macros */
  char8 acName[IFX_VMAPI_TXT_MAX_NAME_LEN]; /*!< Parameter Name */
  uint32 uiOffset; /*!< Integer giving the offset of the parameter in the structure */
  uint32 uiNumInstanceOffset;
} x_IFX_VMAPI_ParamTxtMap;


/* @} */

/**************************************/
/** \ingroup VMAPI_BINTXT */
/** \defgroup NAME_VALUE Name-Value List for holding the Parameters and their Values.
Name-Value List is the output of an operation of VMAPI Get API and input to the VMAPI Set API.
*/
/* @{ */

/** This structure contains a Name-Value pair. */
#if 0 
typedef struct 
{
  char8 fieldname[IFX_VMAPI_MAX_NAME_LEN]; /*!< Parameter Name  */
  char8 value[IFX_VMAPI_MAX_VALUE_LEN]; /*!< Value of the parameter */
} x_IFX_NameValuePair ;
#endif

/** This structure contains list of Name-Value pairs. */
typedef struct
{
  uint16 unNoOfNVPairs;  /*!< Number of Name-Value pairs in the list */
   /*! an array of Name-Value pairs */
  IFX_NAME_VALUE_PAIR axNameValue[IFX_VMAPI_MAX_NV_PAIRS];
} x_IFX_VMAPI_NameValueList;

/* @} */

/* TODO */
EXTERN x_IFX_VMAPI_ObjTxtMap axObjTbl[];

/**************************************/
/** \ingroup VMAPI_BINTXT */
/** \defgroup TXT_TO_BIN Function Pointer prototype for text-binary and binary-text conversion.
Each parameter in the paramters table is of the type of these constants.
*/
/* @{ */

/*! \method    FPtr_SetTxtValue
    \brief     This function pointer defines the prototype for functions converting a VMAPI object parameter to text format.
    \param[out] pcBuffer is the buffer containg the text value of the parameter
    \param[in] Value is the object's parameter to be converted to the text
    \result    void
*/
typedef VOID (*FPtr_SetTxtValue)(OUT char8* pcBuffer, IN CONST VOID *vValue);

/*! \method    FPtr_SetBinValue
    \brief     This function pointer defines the prototype for functions converting
							 text input to the binary object parameter.
    \param[out] pBinVal is the object's parameter containg the output binary value
    \param[in] pTxtValValue is the input text value to be converted
    \result    void
*/
typedef VOID (*FPtr_SetBinValue)(OUT VOID *pBinVal, IN CONST char8* pTxtVal);

/*! \method    IFX_VMAPI_GetNameValueListFromObj
    \brief     This function is used by the VMAPI Get APIs to get the name-value
							 list for an object
    \param[in] unObjCode is the object code
    \param[in] pvObj is the object input
    \param[out] pcSectionName is the section name corresponding to the object
    \param[out] pNVList is the list of name-value pairs
    \param[in,out] uiNvIdx is the next index in the name-value list to be filled
    \param[in] pcPrefix is prefix of the object to be used in name of the parameter,
							 if any.
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAIL
*/
PUBLIC int32
IFX_VMAPI_GetNameValueListFromObj(
                      IN uint16 unObjCode,
                       IN  void *pvObj,
                      OUT uchar8 *pcSectionName,
                      OUT x_IFX_VMAPI_NameValueList *pNVList,
                      IN_OUT  uint32 *uiNvIdx,
                      IN uchar8 *pcPrefix);

/*! \method    IFX_VMAPI_GetObjFromNameValueList
    \brief     This function is used by the VMAPI Set APIs to get an object from
							 name-value list.
    \param[in] unObjCode is the object code
    \param[out] pvObj is the object input
    \param[in] pNVList is the list of name-value pairs
    \param[in,out] uiNvIdx is the next index in the name-value list to be filled
    \param[in] pcPrefix is prefix is the prefix of object, if present, used in name
							 of the parameters.
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAIL
*/
PUBLIC int32
IFX_VMAPI_GetObjFromNameValueList(
                  IN uint16 unObjCode,
                  OUT void *pvObj,
                  IN x_IFX_VMAPI_NameValueList *pNVList,
                  IN_OUT uint32 *uiNvIdx,
                  IN uchar8 *pcPrefix);

/* @} */

/**************************************/
#ifdef __cpluplus
}
#endif

#endif /* __IFX_VMAPI_BINTXT_H__ */
