#include "ifx_vmapi_cpeid.h"

#define VMAPI_INIT                    0
#define VMAPI_TEST_VOICE_CODEC_CAPS		0
#define VMAPI_TEST_VOICE_CAPS					0
#define VMAPI_TEST_VOICE_SIP_CAPS			0
#define VMAPI_TEST_VOICE_PHY_INT			0
#define VMAPI_TEST_VOICE_SERVICE			0
#define VMAPI_TEST_UTILITY_FUNC 			0
#define VMAPI_TEST_PROFILE						0
#define VMAPI_TEST_PROFILE_DEL				0
#define VMAPI_TEST_SERVICE_PROVIDER   0
#define VMAPI_TEST_PROFILE_SIGNALING  0
#define VMAPI_TEST_PROFILE_FAX        0
#define VMAPI_TEST_SYSTEM_T38         0
#define VMAPI_TEST_NUMPLAN						0
#define VMAPI_TEST_NUMRULE						0
#define VMAPI_TEST_ADDRENTRY					0
#define VMAPI_TEST_ADDRBOOK						0
#define VMAPI_TEST_MISSCALLREG_ENTRY  1
#define VMAPI_TEST_MISSCALLREG_ENTRY_GET  0
#define VMAPI_TEST_DIALCALLREG_ENTRY	0
#define VMAPI_TEST_DEL_DIALCALLREG_ENTRY	0
#define VMAPI_TEST_RECVCALLREG_ENTRY_GET  0
#define VMAPI_TEST_CALLREG						0
#define VMAPI_TEST_LINESUB					  0
#define VMAPI_TEST_LINEEVENT					0
#define VMAPI_TEST_MISC   						0
#define VMAPI_TEST_FXO    						0
#define VMAPI_TEST_DECT    						0
#define VMAPI_TEST_DECT_HANDSET				0
#define VMAPI_TEST_FXS    					  0
#define VMAPI_TEST_DBG								0
#define VMAPI_TEST_VERSION						0
#define VMAPI_TEST_PROFEVENT   			  0
#define VMAPI_TEST_EVENTSUB   			  0
#define VMAPI_TEST_CALLBK   					0
#define TEST_VMAPI_CALLBK_ENTRY       0
#define TEST_VMAPI_PROFILE_ADD        0

#define VMAPI_TEST_WEB_PROFILE_SIGNALING  0

#define VMAPI_TEST_MEDIA_SECURITY     0
#define TEST_VOICE_LINE               0
#define TEST_VOICE_LINE_GET           0
#define TEST_VOICE_LINE_ADD           0
#define TEST_VOICE_LINE_DEL           0
#define TEST_VOICE_LINE_ADD_SEND_NOTIFY  0
#define TEST_VOICE_LINE_SIGNALING     0
#define TEST_VOICE_LINE_SIGNALING_DELETE     0
#define TEST_VOICE_LINE_AUTHCFG       0
#define TEST_VL_CALL_FEATURES         0
#define TEST_VOICE_LINE_CODEC         0 
#define TEST_VOICE_LINE_CODEC_LIST    0
#define TEST_VOICE_LINE_CODEC_LIST_ENTRY   0

#if 0
#if VMAPI_TEST_PROFILE
x_IFX_VMAPI_VoiceProfile xVP2;
x_IFX_VMAPI_VoiceProfile xVP1 = {
{{"",1},{"",1}, 1, ""},
1,
"infineon-profile",
91,
1,
0,
3,
"u",
1,
1,
0,
"a",
1,
{"StunServer", 3428, "Infineon", "aaa", 500, 1, 1},
222,
333,
0,
1,
0
};
#endif
#endif

#if 0 //VMAPI_TEST_PROFILE_FAX
x_IFX_VMAPI_FaxT38 xFax2;
x_IFX_VMAPI_FaxT38 xFax1 = {
{{"",1},{"",1}, 1, ""},
1,
1,
4800,
4800,
20,
1,
1,
50,
50,
1
};
#endif

#if VMAPI_TEST_SYSTEM_T38
x_IFX_VMAPI_T38Cfg xT38b;
#if 1
x_IFX_VMAPI_T38Cfg xT38a = {
{{"",1},{"",1}, 1, ""},
1,
2,
"20",
50,
1,
1,
1,
20,
1
};
#endif
#endif

#if 0
#if VMAPI_TEST_VOICE_CODEC_CAPS
x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodecCaps2; 
x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodecCaps1 = {
{{"",2},{"",1}, 1, ""},
123,
2,
{{1, "G723", 180, 24, 1, 1, 7}, 
{2, "G722", 120, 24, 1, 1, 8}},
1,
712,
};
#endif
#endif

#if VMAPI_TEST_VOICE_CAPS
x_IFX_VMAPI_VoiceCapabilities xVoiceCaps2; 
x_IFX_VMAPI_VoiceCapabilities xVoiceCaps1 = {
{{"",1},{"",1}, 1, ""},
191
};
#endif

#if VMAPI_TEST_VOICE_SIP_CAPS
x_IFX_VMAPI_VoiceSipCapabilities xVoiceSipCaps2; 
x_IFX_VMAPI_VoiceSipCapabilities xVoiceSipCaps1= {
{{"",1},{"",1}, 1, ""}
};
#endif

#if VMAPI_TEST_VOICE_PHY_INT1
x_IFX_VMAPI_VoiceServPhyIf xPhy2;
x_IFX_VMAPI_VoiceServPhyIf xPhy1= {
{{"",4},{"",1}, 1, ""},
1,
1,
0,
"interface"
};
#endif

#if VMAPI_TEST_VOICE_SYSTEM
x_IFX_VMAPI_VoiceSystem xVoiceSys2;
x_IFX_VMAPI_VoiceSystem xVoiceSys1= {
{{"",1},{"",1}, 1, ""},
91,
0,
{0, 1, 1},
{"1.1",
#ifdef IIP
"1.0","1.0", "1.0",
#endif
"1.1","1.2", "1.3", "1.4", "1.5", "1.6"
#ifndef ATA
,"2.0"
#endif
},
{{1,1},{1,0},{0,1},{1,0},{0,1}
#ifndef ATA
,{1,1}
#endif
},
{"+91-india", "+91", "080", "+9180"}
};
#endif

FILE *fp;

int main(void)
{
  int32 iRet;
  int32 i=0;
	char8 cRet;

#if VMAPI_INIT
	IFX_VMAPI_Init();
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_DELETE_PROFILE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_DELETE_LINE);
#if 0
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_ADD_PROFILE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VOICE_PROFILE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VOICE_LINE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_ADD_LINE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_DELETE_LINE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VL_SIGNALING);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VS_NUM_PLAN);
#endif
  //IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY);
  //IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VP_SIGNALING);
  //IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VP_EVENT_SUBSCR);
  //IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VP_RTCP);
  //IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VP_RTP);
#if 0
  x_IFX_VMAPI_NumPlanRule xNumRule;
  int32 icpeid;
  memset(&xNumRule,0,sizeof(x_IFX_VMAPI_NumPlanRule));
  xNumRule.ucIndex=1;
  IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES, &xNumRule,1);
  xNumRule.ucIndex=2;
  IFX_VMAPI_Update_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES, &xNumRule,2);
  IFX_VMAPI_Get_CpeId(IFX_VMAPI_VS_NUM_PLAN_RULES, &xNumRule,&icpeid);
  printf("CPEID is %d\n",icpeid);
#endif
#endif


#if VMAPI_WRITE_TO_CM
#if CM_INIT
	if (IFX_VMAPI_CM_INIT()!= IFX_VMAPI_SUCCESS) {
		return IFX_VMAPI_FAIL;
	}
#endif
	if (IFX_VMAPI_CM_MGMT_INIT(0)!= IFX_VMAPI_SUCCESS) {
		return IFX_VMAPI_FAIL;
	}
#endif

  /* Initialize debug module with temporary values */
	IFX_VMAPI_DbgInit(IFX_DBG_TYPE_CONSOLE, IFX_DBG_LVL_HIGH, &cRet);
	IFX_VMAPI_DbgLvlSet(IFX_DBG_TYPE_CONSOLE, IFX_DBG_LVL_HIGH);

  if (cRet != IFX_VMAPI_SUCCESS) {
    return IFX_VMAPI_FAIL;
  }

#if VMAPI_TEST_VOICE_CODEC_CAPS

  x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodec;
  x_IFX_VMAPI_CodecDesc *pxTemp;

  memset(&xVoiceCodec,0,sizeof(xVoiceCodec));

	xVoiceCodec.iid.config_owner = IFX_TR69;
	xVoiceCodec.iid.pcpeId.Id = 1;
	xVoiceCodec.iid.cpeId.Id = 1;

	iRet = ifx_get_VoiceCodecCaps(&xVoiceCodec, 0);


    i =0;
    pxTemp = xVoiceCodec.pxCodecList;
     while (pxTemp !=NULL) {
        printf("CodecList For User %d\n",i+1);
        printf("\tCodecId: %d\n",
              pxTemp->uiCodecId);
        printf("\tCodecName : %s\n",
              pxTemp->acCodecName);

     __ifx_list_GetNext((void **)&pxTemp);

     }


#if 0
	memset(&xVoiceCodecCaps2, 0, sizeof(x_IFX_VMAPI_VoiceCodecCapabilities));
	xVoiceCodecCaps2.iid.config_owner = IFX_TR69;
	xVoiceCodecCaps2.iid.pcpeId.Id = 1;
	xVoiceCodecCaps2.iid.cpeId.Id = 1;
	IFX_VMAPI_STRCPY(xVoiceCodecCaps2.iid.cpeId.secName,
						 IFX_VMAPI_OBJ_NAME_CODEC_CAPABS);
	printf("Calling ifx_get_VoiceCodecCaps\n--------------------\n"); 
	iRet = ifx_get_VoiceCodecCaps(&xVoiceCodecCaps2, 0);
	printf("ifx_get_VoiceCodecCaps returned = %d\n",iRet);
	if (iRet == IFX_VMAPI_SUCCESS) {
		printf("TEST PASS for Voice Codec Capabilities \n");
	}
	else {
		printf("TEST FAIL for Voice Codec Capabilities \n");
	}
#endif


#endif

#if VMAPI_TEST_VOICE_CAPS
	memset(&xVoiceCaps2, 0, sizeof(x_IFX_VMAPI_VoiceCapabilities));
	xVoiceCaps2.iid.config_owner = IFX_TR69;
	IFX_VMAPI_STRCPY(xVoiceCaps2.iid.cpeId.secName,
								 IFX_VMAPI_OBJ_NAME_VOICE_CAPABS);
	xVoiceCaps2.iid.config_owner = IFX_TR69;
	xVoiceCaps2.iid.cpeId.Id = 1;
	xVoiceCaps2.iid.pcpeId.Id = 1;
	printf("Calling ifx_get_VoiceCaps\n--------------------\n"); 
	iRet = ifx_get_VoiceCaps(&xVoiceCaps2, 0);
	printf("ifx_get_VoiceCaps returned = %d\n",iRet);
	if (iRet == IFX_VMAPI_SUCCESS) {
		printf("TEST PASS for Voice Capabilities\n");
	}
	else {
		printf("TEST FAIL for Voice Capabilities\n");
	}
#endif

#if 0 /* VMAPI_TEST_VOICE_SIP_CAPS --- no parameters in this object */
	memset(&xVoiceSipCaps2, 0, sizeof(x_IFX_VMAPI_VoiceSipCapabilities));
	xVoiceSipCaps2.iid.config_owner = IFX_TR69;
	IFX_VMAPI_STRCPY(xVoiceSipCaps2.iid.cpeId.secName,
								 IFX_VMAPI_OBJ_NAME_SIP_CAPABS);
	xVoiceSipCaps2.iid.pcpeId.Id = 1;
	xVoiceSipCaps2.iid.config_owner = IFX_TR69;
	printf("Calling ifx_get_VoiceSipCaps\n--------------------\n"); 
	iRet = ifx_get_VoiceSipCaps(&xVoiceSipCaps2, 0);
	printf("ifx_get_VoiceSipCaps returned = %d\n",iRet);
	if (iRet == IFX_VMAPI_SUCCESS) {
		printf("TEST PASS for Voice Sip Capabilities\n");
	}
	else {
		printf("TEST FAIL for Voice Sip Capabilities\n");
	}
#endif

#if VMAPI_TEST_VOICE_PHY_INT
  x_IFX_VMAPI_VoiceServPhyIf xPhyInt;

  uchar8 ucRet; 
  IFX_VMAPI_DbgInit(1,4,&ucRet);
	
	xPhyInt.iid.config_owner = IFX_WEB;
	xPhyInt.iid.pcpeId.Id = 1;
	xPhyInt. ucInterfaceId = 1;
	printf("Calling ifx_get_VoicePhyInterface\n--------------------\n");
	iRet = ifx_get_VoicePhyInterface(&xPhyInt, 0);
	printf("ifx_get_VoicePhyInterface returned = %d\n",iRet);			
	printf("Interface Port Type is %d\n",xPhyInt.ucPortType);
	printf("Interface Description is %s\n",xPhyInt.acIfDesc);
#if 0
	if (iRet == IFX_VMAPI_SUCCESS) {
		memset(&xPhy2, 0, sizeof(x_IFX_VMAPI_VoiceServPhyIf));
		xPhy2.iid.config_owner = IFX_TR69;
		xPhy2.iid.pcpeId.Id = 1;
		xPhy2.iid.cpeId.Id = 4;
		IFX_VMAPI_STRCPY(xPhy2.iid.cpeId.secName,
											IFX_VMAPI_OBJ_NAME_PHY_IFACE);
		printf("Calling ifx_get_VoicePhyInterface\n--------------------\n"); 
		iRet = ifx_get_VoicePhyInterface(&xPhy2, 0);
		printf("ifx_get_VoicePhyInterface returned = %d\n",iRet);			
		if (iRet == IFX_VMAPI_SUCCESS) {
			if (memcmp((VOID*)&xPhy1, (VOID*)&xPhy2,
							sizeof(x_IFX_VMAPI_VoiceServPhyIf)) == 0) {
				printf("TEST PASS for Voice Phy Interface\n");
			}
			else {
				printf("TEST FAIL for Voice Phy Interface\n");
			}
		}
	}
#endif
#endif

int ifx_ParsePhyendptsList (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength) 
{
  int index = 0, i = 0, j = 0;
  while (ucSrc[index] != '\0')
    
  {
    if (ucSrc[index] != ',')
      
    {
      *(ucDestList + (i * 20) + j) = ucSrc[index];
      j++;
    }
    
    else
      
    {
      *(ucDestList + (i * 20) + j) = '\0';
      i++;
      j = 0;
    }
    index++;
  }
  *iLength = i + 1;
  return 0;
}

#if VMAPI_TEST_UTILITY_FUNC
  
  //printf("--------LINEID %d-----\n",IFX_VMAPI_Get_NewLineId());
  //IFX_VMAPI_Update_NewLineId(IFX_VMAPI_Get_NewLineId());
#if 0 
  uint32 uiCpe;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;

  uint32 outFlag = 0;
  uint32 uiInFlag = 0;
  char8 acInBuf[MAX_FILELINE_LEN];
  char8 acCommand[MAX_FILELINE_LEN];

  int index=0; 
  uchar8 pucProfileIdList[20][20];
  uchar8 ucNoOfProfiles;
  uchar8  pProfileIdString[20];

  sprintf((char8*)acCommand, "%s_CpeId", "VoiceProf");
  if ((iRet = ifx_SetCfgData1(SYSTEM_CONF_FILE, "Map_Info", 
      acCommand, uiInFlag, &outFlag, acInBuf)) != IFX_SUCCESS)  {
         printf("Error : Could Not Get Count Of Objects (ln:%d)\n",__LINE__);
      return iRet;   
  }
  printf("String Is %s\n",acInBuf);
  
  memset(pucProfileIdList,0,sizeof(pucProfileIdList)); 
  memset(pProfileIdString,0,sizeof(pProfileIdString)); 

  strcpy(pProfileIdString,acInBuf);
  ifx_ParseCallBlockList (pProfileIdString,pucProfileIdList,
                           &ucNoOfProfiles); 

  memset(&uiProfile,0,sizeof(uiProfile)); 
	for(index=0;index<ucNoOfProfiles;index++)
  { 
    uiProfile[index] = atoi(pucProfileIdList[index]); 
  }

	memset(&xVoiceProf, 0, sizeof(x_IFX_VMAPI_VoiceProfile));
  xVoiceProf.ucProfileId = 1;
  IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_PROFILE, &xVoiceProf, &uiCpe);
  printf("CPE ID is %d\n",uiCpe);
#endif

	system("cp -f /flash/rc.conf /flash/rc.conf_new");
#endif 




#if VMAPI_TEST_VOICE_SERVICE

  int j=0,k=0;
  x_IFX_VMAPI_VoiceService xVoiceServ;

  memset(&xVoiceServ,0,sizeof(xVoiceServ));
	xVoiceServ.iid.cpeId.Id = 1;
	xVoiceServ.iid.config_owner = IFX_WEB;

	  iRet = ifx_get_VoiceService(&xVoiceServ, 0);
		printf("ifx_get_VoiceService returned = %d\n",iRet);			

while(xVoiceServ.acDeviceList[j][0] != '\0')
{
  printf("Device List %d: %s\n",j,xVoiceServ.acDeviceList[j] );
  j++;
}

printf("Number of device is %d\n",j);

//strcpy(xVoiceServ.acDeviceList[j], "NewDev");
#if 0
j=0;

       while(xVoiceServ.ucProfileIdList[i] != 0)
       {
        sprintf(&XArray[j],"%d",xVoiceServ.ucProfileIdList[i]);
        strcat(XArray,",");
        j = strlen(XArray);
        i++;
       }
      strcpy(xVoiceServ.ucProfileIdList,XArray);
  xVoiceServ.uiNumProfiles = 4;
#endif
i=0;
j=0;

  while(xVoiceServ.ucLineIdList[i] != 0)
  {
    printf("Line List %d: %s\n",j,xVoiceServ.ucLineIdList[i] );
    i++;
  }
	
  xVoiceServ.ucLineIdList[i] = 1;
 // printf("Line List %s\n",xVoiceServ.ucLineIdList );

  iRet = ifx_set_VoiceService(IFX_OP_MOD,&xVoiceServ,0);

#endif

#if TEST_VMAPI_PROFILE_ADD

  uchar8 temp;

  x_IFX_VMAPI_VoiceProfile xVoiceProfile;
  x_IFX_VMAPI_ProfileSignaling xProfSig;

  xVoiceProfile.iid.config_owner = IFX_WEB;
  xVoiceProfile.iid.pcpeId.Id = 1;
	iRet = ifx_set_VoiceProfile(IFX_OP_ADD, &xVoiceProfile, 0);

  temp = IFX_VMAPI_Get_LatestProfileId();

  printf("~~~~~~~~~~~~~latest Profile Id is %d~~~~~~~~~~~~~~~~~~ \n",temp);
  xProfSig.ucProfileId = temp;
  xProfSig.iid.config_owner = IFX_WEB;
  xProfSig.iid.pcpeId.Id = 1;
  printf("~~~~~~~~~~~~~SET~~~~~~~~~~~~~~~~~~ \n");
	iRet = ifx_set_ProfileSignaling(IFX_OP_ADD, &xProfSig, 0);

  printf("~~~~~~~~~~~~~GET~~~~~~~~~~~~~~~~~~ \n");
  iRet = ifx_get_ProfileSignaling(&xProfSig,0);

#endif


#if VMAPI_TEST_PROFILE_DEL
  x_IFX_VMAPI_VoiceProfile xVoiceProfile;
  memset(&xVoiceProfile,0,sizeof(xVoiceProfile));
	xVoiceProfile.iid.config_owner = IFX_WEB;
	xVoiceProfile.ucProfileId = 1;

	iRet = ifx_set_VoiceProfile(IFX_OP_DEL, &xVoiceProfile, 0);
	if (iRet != IFX_VMAPI_SUCCESS) 
		printf("DEL failed for Voice Profile");


#endif
#if VMAPI_TEST_PROFILE


#if 0
	xVP1.iid.config_owner = IFX_TR69;
	xVP1.iid.pcpeId.Id = 1;
	xVP1.iid.cpeId.Id = 1;
	xVP1.ucProfileId = 1;
#endif

  int iRet1;
  x_IFX_VMAPI_VoiceProfile xVoiceProfile;
  x_IFX_VMAPI_VoiceProfile xVoiceProfile1;
  memset(&xVoiceProfile1,0,sizeof(xVoiceProfile1));
	xVoiceProfile1.iid.config_owner = IFX_TR69;
	xVoiceProfile1.ucProfileId = 1;
	xVoiceProfile.iid.pcpeId.Id = 1;

	//iRet = ifx_set_VoiceProfile(IFX_OP_ADD, &xVoiceProfile1, 0);
	if (iRet != IFX_VMAPI_SUCCESS) 
		printf("ADD failed for Voice Profile");

  memset(&xVoiceProfile,0,sizeof(xVoiceProfile));
	xVoiceProfile.iid.config_owner = IFX_TR69;
	xVoiceProfile.ucProfileId = 1;
	//xVoiceProfile.iid.pcpeId.Id = 1;
	iRet1 = ifx_get_VoiceProfile(&xVoiceProfile, 0);

  printf("Country: %d",xVoiceProfile.uiAssocCountry);
  printf("PT: %d",xVoiceProfile.ucDtmfPayloadType);


  xVoiceProfile.uiAssocCountry = 3;
  xVoiceProfile.xStunConfig.unStunPort = 1234;
  xVoiceProfile.ucDtmfMethod = 2;
#if 0
	xVoiceProfile.iid.cpeId.Id = 1;
	
	iRet1 = ifx_get_VoiceProfile(&xVoiceProfile, 0);
		printf("ifx_get_VoiceProfile returned = %d\n",iRet1);			

for(i=0;i<4;i++)
{
printf("AssoLineIds %d:  %d\n",i,xVoiceProfile.aucAssoLineIds[i]);
}

xVoiceProfile.aucAssoLineIds[0]=5;
xVoiceProfile.aucAssoLineIds[1]=7;

	iRet1 = ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProfile, 0);
#endif
	iRet1 = ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProfile, 0);
#if 0
	printf("\n\nProfile Name [before set]=%s\n\n",xVP1.acProfileName);
	iRet = ifx_set_VoiceProfile(IFX_OP_MOD, &xVP1, 0);
	printf("ifx_set_VoiceProfile returned = %d\n",iRet);			

	if (iRet == IFX_VMAPI_SUCCESS) {
		memset(&xVP2, 0, sizeof(x_IFX_VMAPI_VoiceProfile));
		xVP2.iid.config_owner = IFX_TR69;
		xVP2.iid.pcpeId.Id = 1;
		xVP2.iid.cpeId.Id = 1;
		xVP2.ucProfileId = 1;
  	xVP2.iid.config_owner = IFX_TR69;
		IFX_VMAPI_STRCPY(xVP2.iid.cpeId.secName, IFX_VMAPI_OBJ_NAME_VOICE_PROFILE);
		iRet = ifx_get_VoiceProfile(&xVP2, 0);
		printf("ifx_get_VoiceProfile returned = %d\n",iRet);			
		if (iRet == IFX_VMAPI_SUCCESS) {
			if (memcmp((VOID*)&xVP1, (VOID*)&xVP2,
								sizeof(x_IFX_VMAPI_VoiceProfile)) == 0) {
				printf("TEST PASS for Voice Profile\n");
			}
			else {
				printf("TEST FAIL for Voice Profile\n");
			}
		}
	}
}
#endif
  /*printf("Deleting Profile.....\n");
	iRet = ifx_set_VoiceProfile(IFX_OP_DEL, &xVoiceProfile, 0);
	if (iRet == -1)
		printf("Delete Failed!!");*/
#endif

#if VMAPI_TEST_PROFILE_FAX
{
	x_IFX_VMAPI_FaxT38 xFax;
	memset(&xFax, 0, sizeof(x_IFX_VMAPI_FaxT38));
	xFax.ucProfileId = 1;
  iRet = ifx_get_ProfileMediaFaxT38(&xFax, 0);
	printf("\n\nFax BitRate TCP [before set]=%d\n\n",xFax.uiBitRateTcp);
	printf("\n\nFax Error Correction [before set]=%d\n\n",xFax.ucUDPErrCorrection);

	xFax.uiBitRateTcp = 14400;
	xFax.iid.config_owner = IFX_WEB;
	iRet = ifx_set_ProfileMediaFaxT38(IFX_OP_MOD, &xFax, 0);

#if 0
	printf("ifx_set_ProfileMediaFax returned = %d\n",iRet);			

	if (iRet == IFX_VMAPI_SUCCESS) {
		memset(&xFax2, 0, sizeof(x_IFX_VMAPI_FaxT38));
		xFax2.iid.config_owner = IFX_TR69;
		xFax2.iid.pcpeId.Id = 1;
		xFax2.iid.cpeId.Id = 1;
		xFax2.ucProfileId = 0;
		IFX_VMAPI_STRCPY(xFax2.iid.cpeId.secName, IFX_VMAPI_OBJ_NAME_FAX);
		iRet = ifx_get_ProfileMediaFaxT38(&xFax2, 0);
		printf("ifx_get_VoiceProfile returned = %d\n",iRet);			
		if (iRet == IFX_VMAPI_SUCCESS) {
			if (memcmp((VOID*)&xFax1, (VOID*)&xFax2,
								sizeof(x_IFX_VMAPI_FaxT38)) == 0) {
				printf("TEST PASS for Voice Profile\n");
			}
			else {
				printf("TEST FAIL for Voice Profile\n");
			}
		}
	}
#endif
}
#endif

#if VMAPI_TEST_SYSTEM_T38
{
	xT38a.iid.config_owner = IFX_TR69;
	xT38a.iid.pcpeId.Id = 1;
	xT38a.iid.cpeId.Id = 1;

	iRet = ifx_set_SystemT38(IFX_OP_MOD, &xT38a, 0);
	printf("ifx_set_SystemT38 returned = %d\n",iRet);			

	if (iRet == IFX_VMAPI_SUCCESS) {
		memset(&xT38b, 0, sizeof(x_IFX_VMAPI_T38Cfg));
		xT38b.iid.config_owner = IFX_TR69;
		xT38b.iid.pcpeId.Id = 1;
		xT38b.iid.cpeId.Id = 1;
		IFX_VMAPI_STRCPY(xT38b.iid.cpeId.secName, IFX_VMAPI_OBJ_NAME_T38);
		iRet = ifx_get_SystemT38(&xT38b, 0);
		printf("ifx_get_SystemT38 returned = %d\n",iRet);			
		if (iRet == IFX_VMAPI_SUCCESS) {
			if (memcmp((VOID*)&xT38a, (VOID*)&xT38b,
								sizeof(x_IFX_VMAPI_T38Cfg)) == 0) {
				printf("TEST PASS for System T38\n");
			}
			else {
				printf("TEST FAIL for Voice System t38\n");
			}
		}
	}
}
#endif



#if VMAPI_TEST_PROFILE_SIGNALING
  x_IFX_VMAPI_ProfileSignaling xProfileSignaling;
  x_IFX_VMAPI_ProfileSignaling xProfileSigDel;
  x_IFX_VMAPI_ProfileSignaling xTemp;
  
  /*  Register PROFILE SIGNALING for Notification */
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VP_SIGNALING);

	memset(&xProfileSignaling, 0, sizeof(x_IFX_VMAPI_ProfileSignaling));
  xProfileSignaling.ucProfileId = 1;
  xProfileSignaling.iid.config_owner = IFX_WEB;
  iRet = ifx_get_ProfileSignaling(&xProfileSignaling, 0);
	printf("ifx_get_ProfileSignaling returned = %d\n",iRet);

#if 0
  if (iRet == IFX_VMAPI_SUCCESS ) {
  	/*xProfileSignaling.ucProfileId = 1;
    xProfileSignaling.unUAPort = 8888;
    xProfileSignaling.unProxyPort = 9999;
    xProfileSignaling.unInvExpires = 5000;
    strcpy(xProfileSignaling.acProxyAddr,"Infineon.proxy.bangalore.com");
    strcpy(xProfileSignaling.acUserAgentHdr,"Infineon Ver 2.0");*/

    strcpy(xProfileSignaling.acRegistrarAddr,"Infineon.bangalore.com");
		xProfileSignaling.unRegistrarPort = 9090;
    iRet = ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfileSignaling, //0);
						IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);
    printf("ifx_set_ProfileSignaling returned : %d\n",iRet);
  } 
#endif
  xProfileSigDel.ucProfileId = 2;
  xProfileSigDel.iid.config_owner = IFX_WEB;
  iRet = ifx_set_ProfileSignaling(IFX_OP_DEL,&xProfileSigDel,0);// IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
#if 0
    xTemp.ucProfileId =1;
    IFX_VMAPI_Update_CpeId(IFX_VMAPI_VP_SIGNALING, &xTemp, 1);
    iRet = ifx_set_ProfileSignaling(IFX_OP_ADD,&xProfileSignaling, 0);

	memset(&xProfileSignaling, 0, sizeof(x_IFX_VMAPI_ProfileSignaling));
  xProfileSignaling.ucProfileId = 1;
  xProfileSignaling.iid.config_owner = IFX_WEB;
  iRet = ifx_get_ProfileSignaling(&xProfileSignaling, 0);
  
	strcpy(xProfileSignaling.acRegistrarAddr,"blr.Infineo");
	xProfileSignaling.unRegistrarPort = 9090;
  iRet = ifx_set_ProfileSignaling(IFX_OP_MOD,&xProfileSignaling, 0);
#endif
#endif

#if VMAPI_TEST_WEB_PROFILE_SIGNALING
	x_IFX_SipRegistrarCfg xRegCfg;
	xRegCfg.ucFlag = 1;
	IFX_VMAPI_STRCPY(xRegCfg.acRegistrar,	"aaaaa.com");
	xRegCfg.unRegPort = 1111;
	xRegCfg.ucRegProtocol = 1;
	xRegCfg.uiRegExpirationTime =	3421;
	printf("\n\n***ifx_set_Web_ProfileSignaling returns = %d\n",
								ifx_set_Web_ProfileSignaling(&xRegCfg));
#endif

#if VMAPI_TEST_SERVICE_PROVIDER
  x_IFX_VMAPI_ProfileServiceProviderInfo *pServiceProviderInfo = 0;
  x_IFX_VMAPI_ProfileServiceProviderInfo xSerPrvdInf;
  uint32 uiNoOfServerProvider = 0;
  uint32 uiCount;
#if 1
  iRet = ifx_get_all_ProfileServiceProviderInfo(&uiNoOfServerProvider,
                          &pServiceProviderInfo,
                          0);
#else
  //xSerPrvdInf.ucProfileId = 1;
  xSerPrvdInf.iid.cpeId.Id = 1;
  iRet = ifx_get_ProfileServiceProviderInfo(&xSerPrvdInf,0);
  pServiceProviderInfo = & xSerPrvdInf;
  uiNoOfServerProvider = 1;
#endif
  printf("Get * ProfileServiceProviderInfo returned : %d \n", iRet);
  
  if (iRet == IFX_VMAPI_SUCCESS ) {
    
    for (uiCount = 0; uiCount < uiNoOfServerProvider; ++uiCount) {
     
      printf("Service Provider Instance: %d (cpeid:%d)\n",
              uiCount+1,pServiceProviderInfo[uiCount].iid.cpeId.Id);
      printf("Name  : %s\n", pServiceProviderInfo[uiCount].acName);
      printf("URL   : %s\n", pServiceProviderInfo[uiCount].acUrl);
      printf("Phone : %s\n", pServiceProviderInfo[uiCount].acPhone);
      printf("Email : %s\n", pServiceProviderInfo[uiCount].acEmail);
    }
  }
  
  if (iRet == IFX_VMAPI_SUCCESS ) {
    srand(100); 
    xSerPrvdInf.iid.config_owner = IFX_TR69;
    sprintf(xSerPrvdInf.acName,"Random_Name_%d",rand());
    //sprintf(xSerPrvdInf.acUrl,"Infineon.ci.in_%d",rand());
    //sprintf(xSerPrvdInf.acPhone,"%d",rand());
    //sprintf(xSerPrvdInf.acEmail,"myEmail_%d",rand());
    iRet = ifx_set_ProfileServiceProviderInfo(IFX_OP_MOD,&xSerPrvdInf,0);
    printf("ifx_set_ProfileServiceProviderInfo Returned: %d\n",iRet);
  }
  
#endif

#if VMAPI_TEST_MEDIA_SECURITY 
  x_IFX_VMAPI_ProfileMediaSecurity xProfileMediaSecurity;
  //xProfileMediaSecurity.ucProfileId = 6;
  xProfileMediaSecurity.iid.cpeId.Id = 1;
  iRet = ifx_get_ProfileMediaSecurity(&xProfileMediaSecurity,0);
  printf("ifx_get_ProfileMediaSecurity Returned: %d\n",iRet);
  

  if ( iRet == IFX_VMAPI_SUCCESS) {
    xProfileMediaSecurity.iid.config_owner = IFX_TR69;
    
    sprintf(xProfileMediaSecurity.acSrtpMasterKey,"New_Master_%d",rand());
    sprintf(xProfileMediaSecurity.acSrtpMasterSalt,"Not Tata Salt_%d",rand());
    sprintf(xProfileMediaSecurity.acSrtcpMasterKey,"SrtpKey_%d",rand());
    iRet = ifx_set_ProfileMediaSecurity(IFX_OP_MOD,&xProfileMediaSecurity,0);
    printf("ifx_set_ProfileMediaSecurity returned : %d\n",iRet);
  }
#endif
#if VMAPI_TEST_NUMPLAN
  x_IFX_VMAPI_NumPlan xNumPlan;
  x_IFX_VMAPI_NumPlanRule *pxTemp; 

	memset(&xNumPlan,0,sizeof(xNumPlan));
  xNumPlan.iid.cpeId.Id = 1;
  xNumPlan.iid.config_owner = IFX_WEB;
  iRet = ifx_get_NumPlan(&xNumPlan,0);

  printf("ifx_get_NumPlan Returned: %d\n\n",iRet);

  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Inter Digit Timer: %d\n",xNumPlan.ucInterdigTimerStd );
     printf("Progressive Timer: %d\n",xNumPlan.ucInterdigTimerProg);
		 printf("Number of Rules: %d\n",xNumPlan.ucNoOfNumPlanRules);

    i =0;
    pxTemp = xNumPlan.pxNumPlanRules;
     while (pxTemp !=NULL) {
        printf("Min Len - %d\n",pxTemp->ucMinDigits4Prefix);
        printf("\tMax Len : %d\n",
              pxTemp->ucMaxDigits4Prefix);
     __ifx_list_GetNext((void **)&pxTemp);
				
          }
}
    IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VS_NUM_PLAN);
#if 0
     for (i =0 ; i < xNumPlan.ucNoOfNumPlanRules; i++ ) {
        printf("Number of Rules %d\n",i+1);
        printf("\tMin Len: %d\n",
              xNumPlan.axNumPlanRules[i].ucMinDigits4Prefix);
        printf("\tMax Len: %d\n",
              xNumPlan.axNumPlanRules[i].ucMaxDigits4Prefix);

     }
     xNumPlan.axNumPlanRules[0].ucMinDigits4Prefix = 25;
     iRet = ifx_set_NumPlan(IFX_OP_MOD,&xNumPlan,0);
     printf("ifx_set_NumPlan Returned: %d\n\n",iRet);
  }
#endif
#endif

#if VMAPI_TEST_ADDRBOOK
  x_IFX_VMAPI_AddressBook xAddrBook;
#if 0 
  xAddrBook.iid.cpeId.Id = 1;
  xAddrBook.iid.config_owner = IFX_TR69;
  iRet = ifx_get_AddrBook(&xAddrBook,0);

  printf("ifx_get_AddrBook Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Number of Address Book Entries: %d\n",xAddrBook.ucNoOfAddBookEntries);
     for (i =0 ; i < xAddrBook.ucNoOfAddBookEntries; i++ ) {
        printf("Dial Code: %s\n",xAddrBook.axAddressBook[i].acDialCode);
        printf("Call Type: %d\n",xAddrBook.axAddressBook[i].eCallType);
        printf("\tAddress Type: %d\n",
              xAddrBook.axAddressBook[i].xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              xAddrBook.axAddressBook[i].xAddress.acDisplayName);
        printf("\tUsername: %s\n",
              xAddrBook.axAddressBook[i].xAddress.acUserName);
        printf("\tDestination Address: %s\n",
              xAddrBook.axAddressBook[i].xAddress.acDestAddr);
        printf("\tPort: %d\n",
              xAddrBook.axAddressBook[i].xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              xAddrBook.axAddressBook[i].xAddress.ucAddrProto);

     }
//				xAddrBook.ucNoOfAddBookEntries = 5;
     sprintf(xAddrBook.axAddressBook[0].xAddress.acUserName, "NewUser_%d",
            rand());
#if 0
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
#endif
     iRet = ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,0);
     printf("ifx_set_AddrBook Returned: %d\n\n",iRet);
  }
#endif

  x_IFX_VMAPI_AddressBookEntry *pxTemp;
  
  xAddrBook.iid.cpeId.Id = 1;
  xAddrBook.iid.pcpeId.Id = 1;
  xAddrBook.iid.config_owner = IFX_WEB;
  iRet = ifx_get_AddrBook(&xAddrBook,0);

  printf("ifx_get_AddrBook Returned: %d\n\n",iRet);

  xAddrBook.ucNoOfAddBookEntries=3;
#if 1
  if ( iRet == IFX_VMAPI_SUCCESS ) {
    i =0;
    pxTemp = xAddrBook.pxAddressBook;
     while (pxTemp !=NULL) {
        printf("Address Book For User %d\n",i+1);
        printf("\tDial Code : %s\n",
              pxTemp->acDialCode);
        printf("\tDisp Name : %s\n",
              pxTemp->xAddress.acDisplayName);
     __ifx_list_GetNext((void **)&pxTemp);

     }
}
  ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
  
  iRet = ifx_set_AddrBook(IFX_OP_MOD,&xAddrBook,0);
#endif
#endif

#if VMAPI_TEST_MISSCALLREG_ENTRY_GET
	x_IFX_VMAPI_MissCallRegister xMissReg = {'\0'};  
	x_IFX_VMAPI_MissCallRegEntry *pxTemp;  

  printf("========================GET===========\n");
  xMissReg.ucIndex = 0;
  xMissReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_MissCallReg(&xMissReg,0);
  if ( iRet == IFX_VMAPI_SUCCESS ) {
     printf("Number of Miss: %d\n",xMissReg.ucNoOfEntries);
  }
  printf("========================GET OVER===========\n");
  i =0;
    pxTemp = xMissReg.pxCallRegEntries;
     while (pxTemp !=NULL) {
        printf("Miss Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp->acCallTime);
        printf("\tDate : %s\n", pxTemp->acCallDate);
        printf("Call Type: %d\n",pxTemp->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp->xAddress.acDisplayName);
				strcpy(pxTemp->xAddress.acDisplayName , "Temporary");
        printf("\tUsername: %s\n",
              pxTemp->xAddress.acUserName);
 
			 strcpy(pxTemp->xAddress.acUserName , "Temp3");
       printf("\tDestination Address: %s\n",
              pxTemp->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp->xAddress.unPort);
       pxTemp->xAddress.unPort = 5060;
        printf("\tAddress Protocol: %d\n",
              pxTemp->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp);
				
          }

#endif
#if VMAPI_TEST_MISSCALLREG_ENTRY
	x_IFX_VMAPI_MissCallRegEntry xMiss;  
	x_IFX_VMAPI_MissCallRegister xMissReg, xMissReg1;  
	x_IFX_VMAPI_MissCallRegEntry *pxTemp;  
  int k=0;
  memset(&xMiss,0,sizeof(xMiss));
  memset(&xMissReg,0,sizeof(xMissReg));
  
	strcpy(xMiss.acCallDate,"18.07.07");
  xMiss.eCallType =1;
	xMiss.xAddress.ucAddrType = IFX_IP_ADDR;
  strcpy(xMiss.xAddress.acDisplayName,"XXX");
  strcpy(xMiss.xAddress.acUserName,"1");
  strcpy(xMiss.xAddress.acDestAddr,"172.20.22.26");
	
  xMissReg.pxCallRegEntries = &xMiss;

  memset(&xMissReg1,0,sizeof(xMissReg1));
  xMissReg.iid.config_owner = IFX_WEB;
  iRet = ifx_set_MissCallReg(IFX_OP_ADD,&xMissReg,0);
  if (iRet != IFX_VMAPI_SUCCESS)
			printf("Set Failed");
#if 0
  printf("========================GET===========\n");
  xMissReg.ucIndex = 2;
  xMissReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_MissCallReg(&xMissReg,0);
  if ( iRet == IFX_VMAPI_SUCCESS ) {
     printf("Number of Miss: %d\n",xMissReg.ucNoOfEntries);

  printf("========================GET OVER===========\n");
    i =0;
    pxTemp = xMissReg.pxCallRegEntries;
     if (pxTemp !=NULL) {
        printf("Miss Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp->acCallTime);
        printf("\tDate : %s\n", pxTemp->acCallDate);
        printf("Call Type: %d\n",pxTemp->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp->xAddress.acDisplayName);
				strcpy(pxTemp->xAddress.acDisplayName , "Temporary");
        printf("\tUsername: %s\n",
              pxTemp->xAddress.acUserName);
 
			 strcpy(pxTemp->xAddress.acUserName , "Temp3");
       printf("\tDestination Address: %s\n",
              pxTemp->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp->xAddress.unPort);
       pxTemp->xAddress.unPort = 5060;
        printf("\tAddress Protocol: %d\n",
              pxTemp->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp->uiLineId);
				
          }
  printf("========================SET===========\n");
  iRet = ifx_set_MissCallReg(IFX_OP_MOD,&xMissReg,0);
}
#endif
#endif

#if VMAPI_TEST_DEL_DIALCALLREG_ENTRY
	x_IFX_VMAPI_DialCallRegister xDialReg;  
  iRet = ifx_set_DialCallReg(IFX_OP_DEL,&xDialReg,0);
#if 0
  char8 s[] = "DialEntry_Count";
  char8 pcCont[100] = {0};
  char8 PArray[10] = {0};
  sprintf(&PArray[0],"%d",1);
  PArray[1] = '\0';
  sprintf(&pcCont[0],"%s=\"%d\"\n",s,1);
	printf("string is %s\n",pcCont);
	
  /*iRet = ifx_SetCfgObject(SYSTEM_CONF_FILE,
                    IFX_VMAPI_GET_OBJ_NAME(IFX_VMAPI_OBJ_CALLREGISTER_DIAL),
                    (char8*)pcPrefix,
                    0, &s);*/
	printf("ENTERED\n");
  iRet = ifx_SetCfgData1("/flash/rc.conf", //SYSTEM_CONF_FILE,
                    "DialEntry",
                    IFX_F_DEFAULT,
                    1,
                    (char8*)pcCont);
	printf("EXIT\n");
#endif
#endif
#if VMAPI_TEST_DIALCALLREG_ENTRY
	x_IFX_VMAPI_DialCallRegEntry xDial;  
	x_IFX_VMAPI_DialCallRegister xDialReg, xDialReg1;  
	x_IFX_VMAPI_DialCallRegEntry *pxTemp;  
	x_IFX_VMAPI_DialCallRegEntry *pxLocal;  
  int k=0;
	
  memset(&xDial,0,sizeof(xDial));
	strcpy(xDial.xAddress.acUserName,"IFX-Dialed");
	strcpy(xDial.xAddress.acDestAddr,"BLR");
  printf("1\n");
	
  memset(&xDialReg1,0,sizeof(xDialReg1));
  xDialReg1.iid.cpeId.Id = 1;
  xDialReg1.iid.pcpeId.Id = 1;
  xDialReg1.iid.config_owner = IFX_WEB;
  xDialReg1.ucIndex = 0;

	pxLocal = (x_IFX_VMAPI_DialCallRegEntry *) malloc(sizeof(x_IFX_VMAPI_DialCallRegEntry));
	strcpy(pxLocal->xAddress.acUserName,"User");
	strcpy(pxLocal->xAddress.acDestAddr,"1234");
	xDialReg1.pxCallRegEntries = pxLocal;
  iRet = ifx_set_DialCallReg(IFX_OP_ADD,&xDialReg1,0);
  if (iRet != IFX_VMAPI_SUCCESS)
			printf("Set Failed");
  free(pxLocal);
  printf("2\n");
  memset(&xDialReg,0,sizeof(xDialReg));
  xDialReg.ucIndex = 0;
  xDialReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DialCallReg(&xDialReg,0);
  if (iRet != IFX_VMAPI_SUCCESS)
			printf("Get Failed");

  k = ifx_set_DelIfEntryExist(&xDialReg,&xDial);
	printf("Entry is %d\n",k);
#if 0	
  if ( iRet == IFX_VMAPI_SUCCESS ) {
     printf("Number of Dial: %d\n",xDialReg.ucNoOfEntries);

    i =0;
    pxTemp = xDialReg.pxCallRegEntries;
     while (pxTemp !=NULL) {
        printf("Dial Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp->acCallTime);
        printf("\tDate : %s\n", pxTemp->acCallDate);
        printf("Call Type: %d\n",pxTemp->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp->xAddress.acDisplayName);
//				strcpy(pxTemp->xAddress.acDisplayName , "Temporary");
        printf("\tUsername: %s\n",
              pxTemp->xAddress.acUserName);
 
//			 strcpy(pxTemp->xAddress.acUserName , "Temp3");
       printf("\tDestination Address: %s\n",
              pxTemp->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp->xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              pxTemp->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp);
				
          }
  iRet = ifx_set_DialCallReg(IFX_OP_MOD,&xDialReg,0);
  if (iRet != IFX_VMAPI_SUCCESS)
			printf("Set Failed for MOD");
}
#endif


#if 0
	x_IFX_VMAPI_DialCallRegEntry xDial;  
	x_IFX_VMAPI_DialCallRegister xDialReg;  
	x_IFX_VMAPI_DialCallRegEntry *pxTemp;  
  int k=0;
  memset(&xDial,0,sizeof(xDial));
  memset(&xDialReg,0,sizeof(xDialReg));


  xDialReg.ucIndex = 0;
  xDialReg.iid.cpeId.Id = 1;
  xDialReg.iid.pcpeId.Id = 1;
  xDialReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DialCallReg(&xDialReg,0);
  if (iRet != IFX_VMAPI_SUCCESS)
			printf("Get Failed");
  if ( iRet == IFX_VMAPI_SUCCESS ) {
    i =0;
    printf("Number of Dials:  %x %d\n",&xDialReg.ucNoOfDialEntries,xDialReg.ucNoOfDialEntries);
    pxTemp = xDialReg.pxDialEntries;
     while (pxTemp !=NULL) {
        printf("\tTime : %s\n",
              pxTemp->acCallTime);
        printf("\tDate : %s\n", pxTemp->acCallDate);
        printf("Call Type: %d\n",pxTemp->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp->xAddress.acDisplayName);
        printf("\tUsername: %s\n",
              pxTemp->xAddress.acUserName);
        printf("\tDestination Address: %s\n",
              pxTemp->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp->xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              pxTemp->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp);
				
          }
}
	
	for (k=0;k< xDialReg.ucNoOfDialEntries;k++)
	{
  
  xDial.iid.cpeId.Id = k+1;
  xDial.iid.pcpeId.Id = 1;
  xDial.iid.config_owner = IFX_WEB;
  iRet = ifx_set_DialCallRegEntry(IFX_OP_DEL,&xDial,0);
	}
#endif

#endif

#if VMAPI_TEST_RECVCALLREG_ENTRY_GET
	x_IFX_VMAPI_RecvCallRegister xRecvReg = {'\0'};  
	x_IFX_VMAPI_RecvCallRegEntry *pxTemp;  

  printf("========================GET===========\n");
  xRecvReg.ucIndex = 0;
  xRecvReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_RecvCallReg(&xRecvReg,0);
  if ( iRet == IFX_VMAPI_SUCCESS ) {
     printf("Number of Miss: %d\n",xRecvReg.ucNoOfEntries);
  }
  printf("========================GET OVER===========\n");
  i =0;
    pxTemp = xRecvReg.pxCallRegEntries;
     while (pxTemp !=NULL) {
        printf("Miss Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp->acCallTime);
        printf("\tDate : %s\n", pxTemp->acCallDate);
        printf("Call Type: %d\n",pxTemp->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp->xAddress.acDisplayName);
				strcpy(pxTemp->xAddress.acDisplayName , "Temporary");
        printf("\tUsername: %s\n",
              pxTemp->xAddress.acUserName);
 
			 strcpy(pxTemp->xAddress.acUserName , "Temp3");
       printf("\tDestination Address: %s\n",
              pxTemp->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp->xAddress.unPort);
       pxTemp->xAddress.unPort = 5060;
        printf("\tAddress Protocol: %d\n",
              pxTemp->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp);
				
          }

#endif

#if VMAPI_TEST_CALLREG
  x_IFX_VMAPI_DialCallRegister xDialCallReg;
	x_IFX_VMAPI_DialCallRegEntry *pxTemp, *pxTemp1, *pxTemp2;  
	x_IFX_VMAPI_DialCallRegEntry *pxDialEntry;  

  memset(&xDialCallReg,0,sizeof(xDialCallReg));
  xDialCallReg.ucIndex = 0;
  xDialCallReg.iid.cpeId.Id = 1;
  xDialCallReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DialCallReg(&xDialCallReg,0);

  printf("=======ifx_get_DialCallReg Returned: %d===========\n\n",iRet);
 
  if ( iRet == IFX_VMAPI_SUCCESS ) {
     printf("Number of Dials: %d\n",xDialCallReg.ucNoOfDialEntries);

    i =0;
    pxTemp = xDialCallReg.pxDialEntries;
     while (pxTemp !=NULL) {
        printf("Dial Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp->acCallTime);
        printf("\tDate : %s\n", pxTemp->acCallDate);
        printf("Call Type: %d\n",pxTemp->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp->xAddress.acDisplayName);
        printf("\tUsername: %s\n",
              pxTemp->xAddress.acUserName);
        printf("\tDestination Address: %s\n",
              pxTemp->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp->xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              pxTemp->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp);
				
          }
#if 0
    pxTemp1 = xCallReg.pxRecvEntries;
     while (pxTemp1 !=NULL) {
        printf("Recv Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp1->acCallTime);
        printf("\tDate : %s\n", pxTemp1->acCallDate);
        printf("Call Type: %d\n",pxTemp1->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp1->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp1->xAddress.acDisplayName);
        printf("\tUsername: %s\n",
              pxTemp1->xAddress.acUserName);
        printf("\tDestination Address: %s\n",
              pxTemp1->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp1->xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              pxTemp1->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp1->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp1);
				
          }
    pxTemp2 = xCallReg.pxMissEntries;
     while (pxTemp2 !=NULL) {
        printf("Miss Entry - %d\n",i+1);
        printf("\tTime : %s\n",
              pxTemp2->acCallTime);
        printf("\tDate : %s\n", pxTemp2->acCallDate);
        printf("Call Type: %d\n",pxTemp2->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp2->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp2->xAddress.acDisplayName);
        printf("\tUsername: %s\n",
              pxTemp2->xAddress.acUserName);
        printf("\tDestination Address: %s\n",
              pxTemp2->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp2->xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              pxTemp2->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp2->uiLineId);
     __ifx_list_GetNext((void **)&pxTemp2);
				
          }
  
#endif
}

  printf("==============================================");
  xDialCallReg.ucIndex = 1;
  xDialCallReg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DialCallReg(&xDialCallReg,0);
    
  pxTemp1 = xDialCallReg.pxDialEntries;
     //while (pxTemp1 !=NULL) {
        printf("\tTime : %s\n",
              pxTemp1->acCallTime);
        printf("\tDate : %s\n", pxTemp1->acCallDate);
        printf("Call Type: %d\n",pxTemp1->eCallType);
        printf("\tAddress Type: %d\n",
              pxTemp1->xAddress.ucAddrType);
        printf("\tDisplay Name: %s\n",
              pxTemp1->xAddress.acDisplayName);
        printf("\tUsername: %s\n",
              pxTemp1->xAddress.acUserName);
        strcpy(pxTemp1->xAddress.acUserName, "INFX");
        printf("\tDestination Address: %s\n",
              pxTemp1->xAddress.acDestAddr);
        printf("\tPort: %d\n",
              pxTemp1->xAddress.unPort);
        printf("\tAddress Protocol: %d\n",
              pxTemp1->xAddress.ucAddrProto);
				printf("\tLine ID: %d\n",pxTemp1->uiLineId);
     //__ifx_list_GetNext((void **)&pxTemp1);
				
       //   }
#if 0
  printf("===============SET===============================");
  iRet = ifx_set_DialCallReg(IFX_OP_MOD,&xDialCallReg,0);

  printf("===============ADD===============================");
  {
	  x_IFX_VMAPI_DialCallRegEntry *pxNewCallRegEntry;  

    pxNewCallRegEntry = xDialCallReg.pxDialEntries;
    strcpy(pxNewCallRegEntry->acCallDate,"210507");
    iRet = ifx_set_DialCallReg(IFX_OP_ADD,&xDialCallReg,0);


  }
#endif

#endif


#if VMAPI_TEST_LINESUB

  x_IFX_VMAPI_LineSubscription xLineSub;
  x_IFX_VMAPI_LineEvents *pxTemp;

  memset(&xLineSub,0,sizeof(xLineSub));

  xLineSub.iid.cpeId.Id = 1;
  xLineSub.iid.pcpeId.Id = 1;
  xLineSub.iid.config_owner = IFX_TR69;
  iRet = ifx_get_LineSubscription(&xLineSub,0);

  printf("ifx_get_LineSubcription Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Msg Retrieve User Name: %s\n",xLineSub.acMwiRetrieveUsrName );
     printf("No of line events: %d\n",xLineSub.ucNoOfLineEvents);

    i =0;
    pxTemp = xLineSub.pxLineEvents;
     while (pxTemp !=NULL) {
        printf("LineEvents For User %d\n",i+1);
        printf("\tState : %d\n",
              pxTemp->ucSubspnState);
        printf("\tUser Name : %s\n",
              pxTemp->acSubspnUsrName);
     strcpy(pxTemp->acSubspnUsrName,"Mekhala");
     __ifx_list_GetNext(&pxTemp);

     }

     iRet = ifx_set_LineSubscription(IFX_OP_MOD,&xLineSub,0);
     printf("ifx_set_LineSubscription Returned: %d\n\n",iRet);
#if 0
     for (i =0 ; i < xLineSub.ucNoOfLineEvents; i++ ) {
        printf("Number of Events %d\n",i+1);
        printf("\tSubscription Event: %d\n",
              xLineSub.axLineEvents[i].uiSubspnEvent);
        printf("\tSubscription Status: %d\n",
              xLineSub.axLineEvents[i].ucSubspnState);
        printf("\tSubscription UserName: %s\n",
              xLineSub.axLineEvents[i].acSubspnUsrName);
           }
#endif
#if 0
     strcpy(xLineSub.acMwiRetrieveUsrName, "NewUser");
     strcpy(xLineSub.axLineEvents[0].acSubspnUsrName,"NewUser1");
     xLineSub.axLineEvents[0].ucSubspnState= 4;
          
     iRet = ifx_set_LineSubscription(IFX_OP_MOD,&xLineSub,0);
     printf("ifx_set_LineSubscription Returned: %d\n\n",iRet);
#endif
}  

#endif
#if VMAPI_TEST_MISC
  x_IFX_VMAPI_Misc xMisc;
  
  xMisc.iid.cpeId.Id = 1;
  //xMisc.iid.config_owner = IFX_TR69;
  iRet = ifx_get_Misc(&xMisc,0);

  printf("ifx_get_Misc Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Unsolicited Notify: %d\n",xMisc.bAcceptUnSolNotify );
     printf("UDP Redirection: %d\n",xMisc.bEnableUDPRedir);
     printf("SM SC Number: %s\n",xMisc.uacSmsScNumber );
     printf("Restore Factory Settings: %d\n",xMisc.bRestoreFactorySettings );
     printf("Default Fax Interface: %d\n",xMisc.defaultFaxIface );
     printf("Default Outbound Interface: %d\n",xMisc.defaultOutbndIface );

     xMisc.bAcceptUnSolNotify=-1;
     xMisc.bEnableUDPRedir=-1;
     strcpy(xMisc.uacSmsScNumber,"User2" );
     xMisc.bRestoreFactorySettings=0;
  

#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
#endif
     //iRet = ifx_set_Misc(IFX_OP_MOD,&xMisc,IFX_VMAPI_OWNER);
     iRet = ifx_set_Misc(IFX_OP_MOD,&xMisc,0);
     printf("ifx_set_Misc Returned: %d\n\n",iRet);

  }
#endif

#if VMAPI_TEST_FXO
  x_IFX_VMAPI_FxoPhyIf xFxoPhyIf;
  
  memset(&xFxoPhyIf,0,sizeof(xFxoPhyIf));
  xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = 3;
	xFxoPhyIf.iid.config_owner = IFX_WEB;

  iRet = ifx_get_FxoPhyInterface(&xFxoPhyIf,0);

  printf("ifx_get_FxoPhyInterface Returned: %d\n\n",iRet);
  
  for(i=0;i<2;i++)
  {
    printf("Interface Id List %d\n", xFxoPhyIf.ucInterfaceIdList[i]);
  }

xFxoPhyIf.ucInterfaceIdList[0]=10;
xFxoPhyIf.ucInterfaceIdList[1]=4;
strcpy(xFxoPhyIf.uacSmsScNumber,"60087" );
strcpy(xFxoPhyIf.uacCallFwdNoAnswer,"98450" );

  uchar8 PArray[20] = {0};
  int j=0;

  for(i=0;i<2;i++)
  {
    // strcat(PArray,xVoiceLine.ucAssocVoiceInterface[i]);
    sprintf(&PArray[j],"%d",xFxoPhyIf.ucInterfaceIdList[i]);
    strcat(PArray,",");
    j = strlen(PArray);
  }
  strcpy(xFxoPhyIf.ucInterfaceIdList,PArray);

  iRet = ifx_set_FxoPhyInterface(IFX_OP_MOD,&xFxoPhyIf,0);

#if 0
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("End Pt Id: %s\n",xFxo.ucEndPtId );
     printf("VoiceLine Id: %d\n",xFxo.ucVoiceLineId);
     printf("Port Type: %d\n",xFxo.xVoiceServPhyIf.ucPortType );
     printf("Status: %d\n",xFxo.xVoiceServPhyIf.ucStatus );
     printf("Interface Id: %d\n",xFxo.xVoiceServPhyIf.ucInterfaceId );
     printf("Interface Description: %s\n",xFxo.xVoiceServPhyIf.acIfDesc );
     printf("Int Id List: %d\n",xFxo.ucInterfaceIdList );
     printf("SM SC Number: %s\n",xFxo.uacSmsScNumber );
     printf("Gateway Mode: %d\n",xFxo.ucGatewayMode );
     printf("Call Forward No Answer: %s\n",xFxo.uacCallFwdNoAnswer );


     xFxo.ucEndPtId[0] =1;
     xFxo.ucVoiceLineId=0;
     xFxo.xVoiceServPhyIf.ucPortType =2;
     xFxo.xVoiceServPhyIf.ucStatus =0;
     xFxo.xVoiceServPhyIf.ucInterfaceId =1;
     strcpy(xFxo.xVoiceServPhyIf.acIfDesc,"YES" );
     xFxo.ucInterfaceIdList[0] =0;
     strcpy(xFxo.uacSmsScNumber,"60087" );
     xFxo.ucGatewayMode=2;
     strcpy(xFxo.uacCallFwdNoAnswer,"546");
#endif
#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
#endif

     printf("ifx_set_FxoPhyInterface Returned: %d\n\n",iRet);

  
#endif

#if VMAPI_TEST_FXS
  x_IFX_VMAPI_FxsPhyIf xFxs,xFxs1;
  memset(&xFxs,0,sizeof(xFxs));
  int test = 2,m=0,count=0,j=0,n=0; 
  uchar8 PArray[10]={0};

#if 0
  xFxs1.xVoiceServPhyIf.ucInterfaceId = 1;
  IFX_VMAPI_Update_CpeId(IFX_VMAPI_PHY_IFACE_FXS,&xFxs1,1);
  xFxs1.xVoiceServPhyIf.ucInterfaceId = 2;
  IFX_VMAPI_Update_CpeId(IFX_VMAPI_PHY_IFACE_FXS,&xFxs1,2);
#endif

  xFxs.xVoiceServPhyIf.ucInterfaceId = 2;
  xFxs.iid.config_owner = IFX_WEB;
  iRet = ifx_get_FxsPhyInterface(&xFxs,0);

  printf("ifx_get_FxsPhyInterface Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     
     printf("End Pt Id: %s\n",xFxs.ucEndPtId ); 
     printf("VoiceLine Id: %d\n",xFxs.ucVoiceLineId);
     printf("Port Type: %d\n",xFxs.xVoiceServPhyIf.ucPortType );
     printf("Status: %d\n",xFxs.xVoiceServPhyIf.ucStatus );
     printf("Interface Id: %d\n",xFxs.xVoiceServPhyIf.ucInterfaceId );
     printf("Interface Description: %s\n",xFxs.xVoiceServPhyIf.acIfDesc );
     printf("SMS Capable: %d\n",xFxs.bSmsCapable );
     printf("Wide Band Capable: %d\n",xFxs.bWideBandCapable );
}

#if 0
     strcpy(xFxs.ucEndPtId,"543");
     xFxs.ucVoiceLineId=1;
     xFxs.xVoiceServPhyIf.ucPortType =0;
     strcpy(xFxs.xVoiceServPhyIf.acIfDesc,"YES" );

     for(i=0;i<1;i++)
     {
       if(xFxs.xVoiceServPhyIf.ucInterfaceId == test)
       { 
          while(xFxs.ucVoiceLineIdList[n] != 0)
          {
            count++;
          }
            
          xFxs.ucVoiceLineIdList[count] = 1;
          for(m=0;m<=count;m++)
          {
            sprintf(&PArray[j],"%d",xFxs.ucVoiceLineIdList[m]); 
            strcat(PArray,",");
            j=strlen(PArray);
          }
          strcpy(xFxs.ucVoiceLineIdList,PArray); 
       }
    }

     iRet = ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFxs,0);
     printf("ifx_set_FxsPhyInterface Returned: %d\n\n",iRet);
#endif


#endif

#if VMAPI_TEST_DECT

  x_IFX_VMAPI_DectSystem xDect;
  x_IFX_VMAPI_DectHandset *pxTemp;
  memset(&xDect,0,sizeof(xDect));

  xDect.iid.cpeId.Id = 1;
  xDect.iid.pcpeId.Id = 1;
  xDect.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DectInterface(&xDect,0);

  printf("ifx_get_DectInterface Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {
     pxTemp = xDect.pxHandsetTbl;
  
     while (pxTemp != NULL)
     {
     printf("Subscription Type: %d\n",pxTemp->uiSubscriptionTime );
     printf("SMS Capable: %d\n",pxTemp->bSmsCapable );
     printf("Wide Band Capable: %d\n",pxTemp->bWideBandCapable );

     __ifx_list_GetNext((void*)&pxTemp);

     }

}

#if 0
     iRet = ifx_set_DectInterface(IFX_OP_MOD,&xDect,0);
     printf("ifx_set_DectInterface Returned: %d\n\n",iRet);
#endif


#endif

#if VMAPI_TEST_DECT_HANDSET

  x_IFX_VMAPI_DectHandset xDectHand;
  memset(&xDectHand,0,sizeof(xDectHand));

  xDectHand.iid.cpeId.Id = 1;
  xDectHand.iid.pcpeId.Id = 1;
  xDectHand.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DectHandset(&xDectHand,0);

  printf("ifx_get_DectHandset Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Subscription Type: %d\n",xDectHand.uiSubscriptionTime );
     printf("SMS Capable: %d\n",xDectHand.bSmsCapable );
     printf("Wide Band Capable: %d\n",xDectHand.bWideBandCapable );
     printf("IPUI: %s\n",xDectHand.xSubsInfo.aucIPUI );
     printf("Default VoiceLineId: %d\n",xDectHand.ucVoiceLineId );
     printf("Default VoiceLineId: %d\n",xDectHand.xVoiceServPhyIf.ucInterfaceId );
     }


#if 0
     iRet = ifx_set_DectHandset(IFX_OP_MOD,&xDect,0);
     printf("ifx_set_DectHandset Returned: %d\n\n",iRet);
#endif


#endif


#if VMAPI_TEST_DBG
  x_IFX_VMAPI_SystemDebugSettings xDbg;
  char8 cghosh;

  IFX_VMAPI_DbgInit(0,0,&cghosh);

  xDbg.iid.cpeId.Id = 1;
  xDbg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_DbgSettings(&xDbg,IFX_VMAPI_OP_DEFAULT);

  printf("ifx_get_DbgSettings Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("App Dbg Lvl: %d\n",xDbg.xCmDbg.ucDbgLvl );
     printf("App Dbg Type: %d\n",xDbg.xCmDbg.ucDbgType);
     printf("App Dbg Lvl: %d\n",xDbg.xMmDbg.ucDbgLvl );
     printf("App Dbg Type: %d\n",xDbg.xMmDbg.ucDbgType);
     printf("App Dbg Lvl: %d\n",xDbg.xAgentsDbg.ucDbgLvl );
     printf("App Dbg Type: %d\n",xDbg.xAgentsDbg.ucDbgType);
     printf("Rtp Dbg Lvl: %d\n",xDbg.xRtpDbg.ucDbgLvl );
     printf("Rtp Dbg Type: %d\n",xDbg.xRtpDbg.ucDbgType);
     printf("Vmapi Dbg Lvl: %d\n",xDbg.xVmapiDbg.ucDbgLvl );
     printf("Vmapi Dbg Type: %d\n",xDbg.xVmapiDbg.ucDbgType);
     printf("Sip Dbg Lvl: %d\n",xDbg.xSipDbg.ucDbgLvl );
     printf("Sip Dbg Type: %d\n",xDbg.xSipDbg.ucDbgType);
     printf("Fax Dbg Lvl: %d\n",xDbg.xFaxDbg.ucDbgLvl );
     printf("Fax Dbg Type: %d\n",xDbg.xFaxDbg.ucDbgType);

		 xDbg.xVmapiDbg.ucDbgLvl = 4;
		 xDbg.xVmapiDbg.ucDbgType = 1;
#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
#endif
     iRet = ifx_set_DbgSettings(IFX_VMAPI_OP_MOD,&xDbg,0);
     printf("ifx_set_DbgSettings Returned: %d\n\n",iRet);

		 IFX_VMAPI_SetDebug (1,4);
  }
#endif


#if VMAPI_TEST_VERSION
  x_IFX_VMAPI_SystemVersionRegister xVer;
  
  xVer.iid.cpeId.Id = 1;
  xVer.iid.config_owner = IFX_TR69;
  iRet = ifx_get_Version(&xVer,0);

  printf("ifx_get_Version Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Firmware Set: %s\n",xVer.acFirmwareVer);
     printf("Drv Ver: %s\n",xVer.acDrvVer);
     printf("App Ver: %s\n",xVer.acAppVer);
     printf("Rtp Ver: %s\n",xVer.acRtpVer);
     printf("Vmapi Ver: %s\n",xVer.acCmVer);
     printf("Sip Ver: %s\n",xVer.acSipVer);
     printf("Fax Ver: %s\n",xVer.acFaxVer);

#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
     iRet = ifx_set_LineSignaling(IFX_OP_MOD,&xLineSignaling,0);
     printf("ifx_set_LineSignaling Returned: %d\n\n",iRet);
#endif
  }
#endif

#if VMAPI_TEST_PROFEVENT
  x_IFX_VMAPI_ProfileEventSubsTable xProfEvent;
  x_IFX_VMAPI_EventSubscribe *pxTemp;
  memset(&xProfEvent,0,sizeof(xProfEvent)); 
  xProfEvent.iid.cpeId.Id = 1;
  xProfEvent.iid.config_owner = IFX_WEB;
  iRet = ifx_get_ProfileEventSubsTable(&xProfEvent,0);

  printf("ifx_get_ProfileEventSubsTable Returned: %d\n\n",iRet);
#if 1
  if ( iRet == IFX_VMAPI_SUCCESS ) {

          printf("No of Subscriber elements: %d\n",xProfEvent.ucNoOfSubscrElements);
    i =0;
    pxTemp = xProfEvent.pxEventSubscribe;
     while (pxTemp !=NULL) {
        printf("Event Subscription Element - %d\n",i+1);
        printf("\tEvent : %d\n",
              pxTemp->uiEvent);
        printf("\tNotifier Add : %s\n",
              pxTemp->acNotifierAddr);
        printf("\tPort : %d\n",
              pxTemp->unNotifierPort);
        printf("\tProtocol : %d\n",
              pxTemp->ucNotifierProtocol);
        printf("\tSubscription Time : %d\n",
              pxTemp->unSubscriptionTime);
              pxTemp->unSubscriptionTime = 8;
     __ifx_list_GetNext((void **)&pxTemp);

     }
  iRet = ifx_set_ProfileEventSubsTable(IFX_OP_MOD,&xProfEvent,0);
#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
     iRet = ifx_set_LineSignaling(IFX_OP_MOD,&xLineSignaling,0);
     printf("ifx_set_LineSignaling Returned: %d\n\n",iRet);
#endif
  }
#endif

#if 0


  x_IFX_VMAPI_ProfileEventSubsTable xProfEvent;
  
  xProfEvent.iid.cpeId.Id = 1;
  xProfEvent.iid.config_owner = IFX_TR69;
  iRet = ifx_get_ProfileEventSubsTable(&xProfEvent,0);

  printf("ifx_get_ProfileEventSubsTable Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {

          printf("No of Subscriber elements: %d\n",xProfEvent.ucNoOfSubscrElements);

     for (i =0 ; i < xProfEvent.ucNoOfSubscrElements; i++ ) {
        printf("Number of Element %d\n",i+1);
        printf("\tSubscription Event: %d\n",
              xProfEvent.axEventSubscribe[i].uiEvent);
        printf("\tNotifier Address: %s\n",
              xProfEvent.axEventSubscribe[i].acNotifierAddr);
        printf("\tNotifier Port: %d\n",
              xProfEvent.axEventSubscribe[i].unNotifierPort);
        printf("\tNotifier Protocol: %d\n",
              xProfEvent.axEventSubscribe[i].ucNotifierProtocol);
        printf("\tSubscription Time: %d\n",
              xProfEvent.axEventSubscribe[i].unSubscriptionTime);
          }


        strcpy(xProfEvent.axEventSubscribe[0].acNotifierAddr,"xx.yy.zz");
        xProfEvent.axEventSubscribe[0].unNotifierPort=3;
        xProfEvent.axEventSubscribe[0].ucNotifierProtocol=1;
        xProfEvent.axEventSubscribe[0].unSubscriptionTime=30;



#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
#endif

     iRet = ifx_set_ProfileEventSubsTable(IFX_OP_MOD,&xProfEvent,0);
     printf("ifx_set_ProfileEventSubsTable Returned: %d\n\n",iRet);
  }
#endif
#endif

#if VMAPI_TEST_CALLBK

  x_IFX_VMAPI_CallBlock xCallbk;
  x_IFX_VMAPI_CallBlockEntry *pxTemp;

  memset(&xCallbk,0,sizeof(xCallbk));

  xCallbk.iid.cpeId.Id = 1;
  xCallbk.iid.pcpeId.Id = 1;
  xCallbk.iid.config_owner = IFX_TR69;
  iRet = ifx_get_CallBlock(&xCallbk,0);

  printf("ifx_get_CallBlock Returned: %d\n\n",iRet);
  
  if ( iRet == IFX_VMAPI_SUCCESS ) {
      
          printf("Call Bar: %d\n",xCallbk.bCallBar);
          printf("No of Call Block Entries: %d\n",xCallbk.uiNumCallBlockEntries);
    i =0;
    pxTemp = xCallbk.pxCallBlockList;
     while (pxTemp !=NULL) {
        printf("CallBlock num For User %d\n",i+1);
        printf("\tState : %s\n",
              pxTemp->acCallBlockNum);
       strcpy( pxTemp->acCallBlockNum, "3245");
     __ifx_list_GetNext((void **)&pxTemp);

     }

     iRet = ifx_set_CallBlock(IFX_OP_MOD,&xCallbk,0);
     printf("ifx_set_CallBlock Returned: %d\n\n",iRet);
#if 0
     for (i =0 ; i < xCallbk.uiNumCallBlockEntries; i++ ) {
        printf("Number of Entry %d\n",i+1);
        printf("\tCall Block Number: %s\n",
              xCallbk.axCallBlockList[i].acCallBlockNum);
             }

          xCallbk.bCallBar=1;
          //strcpy(xCallbk.axCallBlockList[0].acCallBlockNum,"4907");
          sprintf(xCallbk.axCallBlockList[i].acCallBlockNum,"%s","4907");
#endif

#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());


     iRet = ifx_set_CallBlock(IFX_OP_MOD,&xCallbk,0);
     printf("ifx_set_CallBlock Returned: %d\n\n",iRet);
#endif


  }

#endif

#if TEST_VOICE_LINE_SIGNALING
  x_IFX_VMAPI_LineSignaling xLineSignaling1 ={'\0'};
  
  x_IFX_VMAPI_LineSignaling xLineSignaling = {'\0'};
  x_IFX_VMAPI_LineSignaling xLineSignalingDel = {'\0'};

  x_IFX_VMAPI_SipAuthCfg *pxTemp;

#if 1
 
     //xLineSignaling1.ucLineId = 1;
     //IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_SIGNALING,&xLineSignaling1,1);
  xLineSignaling.ucLineId = 1;
  xLineSignaling.iid.config_owner = IFX_WEB;
  iRet = ifx_get_LineSignaling(&xLineSignaling,0);

  printf("ifx_get_LineSignaling Returned: %d\n\n",iRet);
  printf("<%s> ProfileId : %d\n\n",__FUNCTION__,xLineSignaling.ucProfileId);

  ifx_vmapi_freeObjectList(&xLineSignaling, IFX_VMAPI_VL_SIGNALING);
#if 0
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Count: %d\n",xLineSignaling.ucNoOfSipAuthCfg);
     printf("User Name: %s\n",xLineSignaling.acSipUserName);
  i =0;
    pxTemp = xLineSignaling.pxAuthCfg;
     while (pxTemp !=NULL) {
        printf("Auth Config For User %d\n",i+1);
        printf("\tRealm : %s\n",
              pxTemp->acRealm);
        printf("\tUser Name : %s\n",
              pxTemp->acSipAuthUsrName);
       strcpy( pxTemp->acSipAuthUsrName, "ABC");
       __ifx_list_GetNext(&pxTemp);

     }

     iRet = ifx_set_LineSignaling(IFX_OP_MOD,&xLineSignaling,0);
#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
     xLineSignaling.ucNoOfSipAuthCfg = 4;
     iRet = ifx_set_LineSignaling(IFX_OP_MOD,&xLineSignaling,0);

#endif
   }

     memset(&xLineSignaling,0,sizeof(xLineSignaling));
     memset(&xLineSignaling1,0,sizeof(xLineSignaling1));
     xLineSignaling1.ucLineId = 2;
     IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_SIGNALING,&xLineSignaling1,2);
  xLineSignaling.ucLineId = 2;
//  xLineSignaling.iid.cpeId.Id = 1;
  xLineSignaling.iid.config_owner = IFX_WEB;
  iRet = ifx_get_LineSignaling(&xLineSignaling,0);

  printf("ifx_get_LineSignaling Returned: %d\n\n",iRet);
  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("User Name: %s\n",xLineSignaling.acSipUserName);
  i =0;
    pxTemp = xLineSignaling.pxAuthCfg;
     while (pxTemp !=NULL) {
        printf("Auth Config For User %d\n",i+1);
        printf("\tRealm : %s\n",
              pxTemp->acRealm);
        printf("\tUser Name : %s\n",
              pxTemp->acSipAuthUsrName);
       strcpy( pxTemp->acSipAuthUsrName, "DEF");
     __ifx_list_GetNext(&pxTemp);

     }

     iRet = ifx_set_LineSignaling(IFX_OP_MOD,&xLineSignaling,0);
#if 0
     sprintf(xLineSignaling.axAuthCfg[1].acSipAuthUsrName, "NewUser_%d",
            rand());
     sprintf(xLineSignaling.axAuthCfg[0].acRealm, "Realm_%d",
            rand());
     xLineSignaling.ucNoOfSipAuthCfg = 4;
     iRet = ifx_set_LineSignaling(IFX_OP_MOD,&xLineSignaling,0);

#endif
   }


#endif  
#endif

#if 0 
     xLineSignaling1.ucLineId = 1;
     IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_SIGNALING,&xLineSignaling1,1);
     xLineSignaling1.ucLineId = 2;
     xLineSignaling1.iid.pcpeId.Id = 1;
     xLineSignaling1.iid.config_owner = IFX_WEB;
     xLineSignaling1.pxAuthCfg = NULL;
     iRet = ifx_set_LineSignaling(IFX_OP_ADD,&xLineSignaling1,0);
     printf("ifx_set_LineSignaling Returned: %d\n\n",iRet);
     xLineSignaling.ucLineId = 1;
     xLineSignaling.iid.pcpeId.Id = 1;
     xLineSignaling.iid.config_owner = IFX_WEB;
     printf("User Name:");
     iRet = ifx_get_LineSignaling(&xLineSignaling,0);

     if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("User Name: %s\n",xLineSignaling.acSipUserName);
     i =0;
     pxTemp = xLineSignaling.pxAuthCfg;
     while (pxTemp !=NULL) {
        printf("Auth Config For User %d\n",i+1);
        printf("\tRealm : %s\n",
              pxTemp->acRealm);
        printf("\tUser Name : %s\n",
              pxTemp->acSipAuthUsrName);
       strcpy( pxTemp->acSipAuthUsrName, "ABC");
     __ifx_list_GetNext(&pxTemp);

     }}


     xLineSignalingDel.ucLineId = 1;
     xLineSignalingDel.iid.pcpeId.Id = 1;
     xLineSignalingDel.iid.config_owner = IFX_WEB;
     iRet = ifx_set_LineSignaling(IFX_OP_DEL,&xLineSignalingDel,0);
  
     if(iRet == IFX_VMAPI_SUCCESS)
     printf("Delete successful");
#endif
#endif



#if TEST_VOICE_LINE_SIGNALING_DELETE


    x_IFX_VMAPI_LineSignaling xLineSignaling = {'\0'};
    x_IFX_VMAPI_LineSignaling xLineSignaling1 = {'\0'};
    x_IFX_VMAPI_SipAuthCfg *pxTemp;
    x_IFX_VMAPI_SipAuthCfg xAuthCfg;

     xLineSignaling1.ucLineId = 1;
     IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_SIGNALING,&xLineSignaling1,1);
     xAuthCfg.ucLineId = 1;
     xAuthCfg.ucIndex = 1;
     IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_AUTHCFG,&xAuthCfg,1);
     xAuthCfg.ucLineId = 1;
     xAuthCfg.ucIndex = 2;
     IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_AUTHCFG,&xAuthCfg,2);

     xLineSignaling.ucLineId = 1;
     xLineSignaling.iid.config_owner = IFX_WEB;
     iRet = ifx_get_LineSignaling(&xLineSignaling,0);

      printf("ifx_get_LineSignaling Returned: %d\n\n",iRet);

  if ( iRet == IFX_VMAPI_SUCCESS ) {

     printf("Count: %d\n",xLineSignaling.ucNoOfSipAuthCfg);
     printf("User Name: %s\n",xLineSignaling.acSipUserName);
  i =0;
    pxTemp = xLineSignaling.pxAuthCfg;
     while (pxTemp !=NULL) {
        printf("Auth Config For User %d\n",i+1);
        printf("\tRealm : %s\n",
              pxTemp->acRealm);
        printf("\tUser Name : %s\n",
              pxTemp->acSipAuthUsrName);
       pxTemp->ucLineId = 1;
       pxTemp->ucIndex = i+1;
       ifx_set_AuthCfg(IFX_OP_DEL,pxTemp,0);
       __ifx_list_GetNext(&pxTemp);
       i++;
     }

     iRet = ifx_set_LineSignaling(IFX_OP_DEL,&xLineSignaling,0);
}
#endif

#if VMAPI_TEST_EVENTSUB
  x_IFX_VMAPI_EventSubscribe xEventSub;
  x_IFX_VMAPI_EventSubscribe xEventSub1;
  
  memset(&xEventSub,0,sizeof(xEventSub));

  xEventSub.ucIndex = 1;
  xEventSub.ucProfileId = 1;
  xEventSub.iid.config_owner = IFX_WEB;
  iRet = ifx_get_EventSubscribe(&xEventSub,0);

  printf("ifx_get_EventSubscribe Returned: %d\n\n",iRet);

  printf("Address: %s\n",xEventSub.acNotifierAddr);

  xEventSub.unNotifierPort = 5788;
  strcpy(xEventSub.acNotifierAddr,"10.11.12.13");
  iRet = ifx_set_EventSubscribe(IFX_OP_MOD,&xEventSub,0);
#if 0	
  memset(&xEventSub1,0,sizeof(xEventSub1));
  xEventSub1.iid.pcpeId.Id = 1;
  xEventSub1.iid.config_owner = IFX_WEB;
  iRet = ifx_set_EventSubscribe(IFX_OP_ADD,&xEventSub1,0);
#endif
  printf("ifx_set_EventSubscribe Returned: %d\n\n",iRet);
#endif
	
#if VMAPI_TEST_ADDRENTRY
  x_IFX_VMAPI_AddressBookEntry xAddrEntry;
  x_IFX_VMAPI_AddressBookEntry xAddrEntry1;
  
  memset(&xAddrEntry,0,sizeof(xAddrEntry));
#if 0
  for(i=0;i<2;i++)
  {
    memset(&xAddrEntry1,0,sizeof(xAddrEntry1));

     xAddrEntry1.ucIndex = i+1;
     xAddrEntry1.iid.pcpeId.Id = 1;
     xAddrEntry1.iid.config_owner = IFX_WEB;
     iRet = ifx_set_AddrEntry(IFX_OP_ADD,&xAddrEntry1,0);
     if(iRet != IFX_VMAPI_SUCCESS)
     {
       printf("ADD FAILED");
     }
  }
#endif
  xAddrEntry.ucIndex = 1;
  xAddrEntry.iid.config_owner = IFX_WEB;
  iRet = ifx_get_AddrEntry(&xAddrEntry,0);
  if(iRet != IFX_VMAPI_SUCCESS)
     {
       printf("GET FAILED");
     }

  printf("Dialcode: %s\n",xAddrEntry.acDialCode);

  xAddrEntry.eCallType = 3;
#if 0
     
  iRet = ifx_set_AddrEntry(IFX_OP_MOD,&xAddrEntry,0);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    printf("MOD FAILED");
  }
  memset(&xAddrEntry,0,sizeof(xAddrEntry));
  xAddrEntry.ucIndex = 2;
  xAddrEntry.iid.pcpeId.Id = 1;
  xAddrEntry.iid.config_owner = IFX_WEB;
  strcpy(xAddrEntry.acDialCode,"121");
  iRet = ifx_set_AddrEntry(IFX_OP_MOD,&xAddrEntry,0);
  if(iRet != IFX_VMAPI_SUCCESS)
  {
    printf("MOD FAILED");
  }
#endif
#endif
#if VMAPI_TEST_NUMRULE
  x_IFX_VMAPI_NumPlanRule xNumRule;
  x_IFX_VMAPI_NumPlanRule xNumRule1;
  
  memset(&xNumRule,0,sizeof(xNumRule));
  memset(&xNumRule1,0,sizeof(xNumRule1));

  xNumRule.ucIndex =2;
  xNumRule.iid.config_owner = IFX_WEB;
  iRet = ifx_get_NumPlanRule(&xNumRule,0);

  printf("ifx_get_NumPlanRule Returned: %d\n\n",iRet);

  printf("Min Len: %d\n",xNumRule.ucMinDigits4Prefix);

	printf("GOING TO SET\n");
  xNumRule.ucMaxDigits4Prefix = 15;
     
  iRet = ifx_set_NumPlanRule(IFX_OP_MOD,&xNumRule,0);

#if 0
  xNumRule1.ucIndex = 3;
  xNumRule1.iid.config_owner = IFX_WEB;
  iRet = ifx_set_NumPlanRule(IFX_OP_ADD,&xNumRule1,0);

  printf("ifx_set_NumPlanRule Returned  ADD: %d\n\n",iRet);
  memset(&xNumRule1,0,sizeof(xNumRule1));
  xNumRule1.ucIndex = 2;
  xNumRule1.iid.config_owner = IFX_WEB;
  iRet = ifx_set_NumPlanRule(IFX_OP_DEL,&xNumRule1,0);

  printf("ifx_set_NumPlanRule Returned  DEL: %d\n\n",iRet);
#endif
#endif

#if TEST_VOICE_LINE_AUTHCFG
  x_IFX_VMAPI_SipAuthCfg xAuthCfg;
  x_IFX_VMAPI_SipAuthCfg xAuthCfg1;
  x_IFX_VMAPI_LineSignaling xLineSignaling1;
  
  memset(&xAuthCfg,0,sizeof(xAuthCfg));
  memset(&xAuthCfg1,0,sizeof(xAuthCfg1));

#if 0
  xAuthCfg.iid.cpeId.Id = 1;
  xAuthCfg.iid.pcpeId.Id = 1;
  xAuthCfg.iid.config_owner = IFX_WEB;
  iRet = ifx_get_AuthCfg(&xAuthCfg,0);

  printf("ifx_get_LineAuthCfg Returned: %d\n\n",iRet);

  printf("Username: %s\n",xAuthCfg.acSipAuthUsrName);

     sprintf(xAuthCfg.acSipAuthUsrName, "NewUser_%d",
            rand());
#endif

     xLineSignaling1.ucLineId = 1;
     IFX_VMAPI_Update_CpeId(IFX_VMAPI_VL_SIGNALING,&xLineSignaling1,1);

  xAuthCfg1.ucLineId = 1;
//  xAuthCfg1.iid.pcpeId.Id = 1;
  xAuthCfg1.iid.config_owner = IFX_WEB;
     
     iRet = ifx_set_AuthCfg(IFX_OP_ADD,&xAuthCfg1,0);

  printf("ifx_set_LineAuthCfg Returned: %d\n\n",iRet);
#endif

#if TEST_VMAPI_CALLBK_ENTRY
  x_IFX_VMAPI_CallBlockEntry xCallbkEntry;
  x_IFX_VMAPI_CallBlockEntry xCallbkEntry1;
  
  memset(&xCallbkEntry,0,sizeof(xCallbkEntry));
  memset(&xCallbkEntry1,0,sizeof(xCallbkEntry1));

  xCallbkEntry.iid.cpeId.Id = 1;
  xCallbkEntry.iid.pcpeId.Id = 1;
  xCallbkEntry.iid.config_owner = IFX_WEB;
  iRet = ifx_get_CallBlockEntry(&xCallbkEntry,0);

  printf("ifx_get_CallBlockEntry Returned: %d\n\n",iRet);

  printf("Call Block Number: %s\n",xCallbkEntry.acCallBlockNum);

     strcpy(xCallbkEntry.acCallBlockNum, "9886098860");

     iRet = ifx_set_CallBlockEntry(IFX_OP_MOD,&xCallbkEntry,0);

  xCallbkEntry1.iid.pcpeId.Id = 1;
  xCallbkEntry1.iid.config_owner = IFX_WEB;
     
     iRet = ifx_set_CallBlockEntry(IFX_OP_ADD,&xCallbkEntry1,0);

  printf("ifx_set_CallBlockEntry Returned: %d\n\n",iRet);
#endif

#if VMAPI_TEST_LINEEVENT
  x_IFX_VMAPI_LineEvents xLineEvents;
  x_IFX_VMAPI_LineEvents xLineEvents1;
  
  memset(&xLineEvents,0,sizeof(xLineEvents));
  memset(&xLineEvents1,0,sizeof(xLineEvents1));

  xLineEvents.iid.cpeId.Id = 1;
  xLineEvents.iid.pcpeId.Id = 1;
  xLineEvents.iid.config_owner = IFX_WEB;
  iRet = ifx_get_LineEvents(&xLineEvents,0);

  printf("ifx_get_LineEvents Returned: %d\n\n",iRet);

  printf("Subspn State: %d\n",xLineEvents.ucSubspnState);

   xLineEvents.ucSubspnState = 5;

  xLineEvents1.iid.pcpeId.Id = 1;
  xLineEvents1.iid.config_owner = IFX_WEB;
     
     iRet = ifx_set_LineEvents(IFX_OP_MOD,&xLineEvents,0);
     iRet = ifx_set_LineEvents(IFX_OP_ADD,&xLineEvents1,0);

  printf("ifx_set_CallBlockEntry Returned: %d\n\n",iRet);
#endif


#if TEST_VOICE_LINE

	int iRet1,iRet2;
  uchar8 prof;
  uchar8 XArray[10] = {0};
  uchar8 SelectedProfiles[10] = {0};
  int j=0,k=0,count=0,n=0;

  x_IFX_VMAPI_VoiceLine xVoiceLine;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
  x_IFX_VMAPI_VoiceService xVoiceServ;

      memset(&xVoiceProf,0,sizeof(xVoiceProf)) ;
      memset(&xVoiceServ,0,sizeof(xVoiceServ)) ;
      memset(&xVoiceLine,0,sizeof(xVoiceLine)) ;
  xVoiceLine.iid.cpeId.Id = 1;
  xVoiceLine.ucLineId = 1;
  xVoiceLine.iid.pcpeId.Id = 1;
  xVoiceLine.iid.config_owner = IFX_TR69;

  xVoiceServ.iid.cpeId.Id = 1;
  xVoiceServ.iid.pcpeId.Id = 1;
  xVoiceServ.iid.config_owner = IFX_TR69;
/*  xVoiceProf.iid.cpeId.Id = prof;
  xVoiceProf.iid.pcpeId.Id = 1;
  xVoiceProf.iid.config_owner = IFX_TR69;*/


 iRet2 = ifx_get_VoiceService(&xVoiceServ,0);

while(xVoiceServ.ucProfileIdList != 0)
{ printf("ProfileIdList %d:   %d \n",i,xVoiceServ.ucProfileIdList[i]);}
i=0; 


 iRet = ifx_get_VoiceLine(&xVoiceLine,0);
  printf("ifx_get_VoiceLine Returned: %d\n\n",iRet);

for(i=0;i<xVoiceServ.uiNumProfiles;i++)
{
  prof = xVoiceServ.ucProfileIdList[i];
  xVoiceProf.iid.cpeId.Id = prof;
  xVoiceProf.iid.config_owner = IFX_TR69;
  iRet1 = ifx_get_VoiceProfile(&xVoiceProf,0);
  while(xVoiceProf.aucAssoLineIds[k] != 0)
  {
  count++;
  k++;
  }
  k=0;
  for(k=0;k<=count;k++)
  {
    if (xVoiceProf.aucAssoLineIds[k] == xVoiceLine.ucLineId )
     {
       SelectedProfiles[n] = xVoiceServ.ucProfileIdList[i];
       n++;
     }
  }
count=0;
k=0;
}

for(k=0;k<n;k++)
{
printf("Selected Profiles %d:  %d\n",k,SelectedProfiles[k]);
}


#if 0
while (xVoiceServ.ucProfileIdList[k] != 0)
{
      prof = xVoiceServ.ucProfileIdList[0];
      xVoiceProf.iid.cpeId.Id = prof;
      xVoiceProf.iid.config_owner = IFX_TR69;
      xVoiceProf.iid.pcpeId.Id = 1;
       iRet1 = ifx_get_VoiceProfile(&xVoiceProf,0);
     for(i=0;i<3;i++)
  {
 printf("AssoLineIds:%d\n",xVoiceProf.aucAssoLineIds[i] );
  }
 printf("AssoLineIds:%s\n",xVoiceProf.aucAssoLineIds );
i=0;
       while(xVoiceProf.aucAssoLineIds[i] != 0)
       { count++;
         i++;
       } 
i=0;
       xVoiceProf.aucAssoLineIds[count] = xVoiceLine.ucLineId;
       printf("Line Id Assigned %d:\t %d :\n",count,xVoiceProf.aucAssoLineIds[count]);
     for(i=0;i<=count;i++)
       {
        sprintf(&XArray[j],"%d",xVoiceProf.aucAssoLineIds[i]);
        printf("XArray: %d\n",XArray[j]);
        strcat(XArray,",");
        printf("XArray: %s\n",XArray);
        j = strlen(XArray);
       }
      strcpy(xVoiceProf.aucAssoLineIds,XArray);
      iRet1 = ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0);
      memset(&XArray,0,sizeof(XArray)) ;
      j=0;
      k++;
			i=0;
      count=0;
}
#endif
#if 0
  uchar8 XArray[10] = {0};
  int j=0;
  for(i=0;i<1;i++)
  {
    sprintf(&XArray[j],"%d",xVoiceProf.aucLines[i]);
    printf("XArray: %d\n",XArray[j]);
    strcat(XArray,",");
    printf("XArray: %s\n",XArray);
    j = strlen(XArray);
  }
  strcpy(xVoiceProf.aucLines,XArray);


  iRet1 = ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,0);
#endif
#if 0
  for(i=0;i<4;i++)
  {
    printf("AssocVoiceInterface %d\n", xVoiceLine.ucAssocVoiceInterface[i]);
  }

  xVoiceLine.ucAssocVoiceInterface[1]=8;
  xVoiceLine.ucAssocVoiceInterface[2]=7;

 uchar8 PArray[20] = {0};

  for(i=0;i<4;i++)
  {
    // strcat(PArray,xVoiceLine.ucAssocVoiceInterface[i]);
    sprintf(&PArray[j],"%d",xVoiceLine.ucAssocVoiceInterface[i]);
    strcat(PArray,",");
    j = strlen(PArray);
  }
  strcpy(xVoiceLine.ucAssocVoiceInterface,PArray);


  iRet = ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0);

#endif

#if 0
  if ( iRet == IFX_VMAPI_SUCCESS ) {
	  xVoiceLine.ucState = 0x01 & ~xVoiceLine.ucState ;
    iRet = ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0);
  } 
#endif
#endif

#if TEST_VOICE_LINE_ADD

  x_IFX_VMAPI_VoiceLine xVL;
  x_IFX_VMAPI_VoiceLine xVoiceLine;
	xVoiceLine.iid.pcpeId.Id = 1;
  xVoiceLine.iid.config_owner = IFX_WEB;
  //if(ifx_set_VoiceLine(IFX_OP_ADD,&xVoiceLine,0)==IFX_VMAPI_FAIL)
  //{
		//printf("SET Failed for VoiceLine\n");
  //}
#if 1
	memset(&xVL, 0, sizeof(x_IFX_VMAPI_VoiceLine));
  xVL.ucLineId = 1;
  xVL.iid.config_owner = IFX_WEB;
  iRet = ifx_get_VoiceLine(&xVL,0);
  printf("ifx_get_VoiceLine Returned: %d\n\n",iRet);
  printf("ifx_get_VoiceLine Profile Id: %d\n\n",xVL.ucProfileId);
#endif


#endif

#if TEST_VOICE_LINE_ADD_SEND_NOTIFY
  x_IFX_VMAPI_VoiceLine xVL;
  x_IFX_VMAPI_VoiceLine xVoiceLine;
#if 0
	memset(&xVoiceLine.iid, 0, sizeof(IFX_ID));
  //if ( iRet == IFX_VMAPI_SUCCESS ) 
  {
	  int32 i=0;
    uint32 uiCpe;

    /*  Register VOICE LINE for Notification */
    IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VOICE_LINE);

    /* Add Line */
    while (i++ < 3) {
		  printf("TEST ---------adding object %d\n",i);
  	  xVoiceLine.ucLineId = i+1;
      xVoiceLine.ucState = 0x01 & ~xVoiceLine.ucState ;
      strcpy(xVoiceLine.ucAssocVoiceInterface ,"2,3,4");
#ifdef IIP
      xVoiceLine.bEnableRingMute = 0x01 & ~xVoiceLine.bEnableRingMute ;
#endif
  	  //xVoiceLine.iid.cpeId.Id = 0;
	    xVoiceLine.iid.pcpeId.Id = 1;
  	  xVoiceLine.iid.config_owner = IFX_WEB;
      
      IFX_VMAPI_SendMsgToRegProcess(IFX_VMAPI_VOICE_LINE,(void *)&xVL,(void *)&xVoiceLine);

      iRet = ifx_set_VoiceLine(IFX_OP_ADD,&xVoiceLine,0);
   
      /* Update the CPEID database */ 
      IFX_VMAPI_Update_CpeId(IFX_VMAPI_VOICE_LINE,&xVoiceLine, xVoiceLine.iid.cpeId.Id);
      IFX_VMAPI_Get_CpeId(IFX_VMAPI_VOICE_LINE, &xVoiceLine, &uiCpe);
      printf("<TEST> CPE ID is %d\n",uiCpe);
  
  } 
  } 
#endif
  /*  Register VOICE LINE for Notification */
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VOICE_LINE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_ADD_LINE);
  IFX_VMAPI_IntimateOnChange(IFX_VMAPI_DELETE_LINE);
  //IFX_VMAPI_IntimateOnChange(IFX_VMAPI_VL_AUTHCFG);
#if 0
	/* Add a Voice Line */
	memset(&xVoiceLine, 0, sizeof(x_IFX_VMAPI_VoiceLine));
	xVoiceLine.iid.pcpeId.Id = 1;
  xVoiceLine.iid.config_owner = IFX_WEB;
  iRet = ifx_set_VoiceLine(IFX_OP_ADD,&xVoiceLine,0);
#endif
#endif

#if TEST_VOICE_LINE_DEL
  x_IFX_VMAPI_VoiceLine xVoiceLine;
  /* Delete a Voice Line */
	memset(&xVoiceLine, 0, sizeof(x_IFX_VMAPI_VoiceLine));
  xVoiceLine.ucLineId = 1;
	xVoiceLine.iid.pcpeId.Id = 1;
  xVoiceLine.iid.config_owner = IFX_WEB;
  iRet = ifx_set_VoiceLine(IFX_OP_DEL,&xVoiceLine,0);


#endif
#if TEST_VOICE_LINE_GET
  x_IFX_VMAPI_VoiceLine xVoiceLine;
  /* Delete a Voice Line */
	memset(&xVoiceLine, 0, sizeof(x_IFX_VMAPI_VoiceLine));
  xVoiceLine.ucLineId = 1;
  xVoiceLine.iid.config_owner = IFX_WEB;
  iRet = ifx_get_VoiceLine(&xVoiceLine,0);

	xVoiceLine.ucState = 1;
  iRet = ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0);
	
#endif
	
	
#if TEST_VL_CALL_FEATURES

  x_IFX_VMAPI_LineCallingFeatures xVlCallFeatures;
  x_IFX_VMAPI_LineCallingFeatures xVlCallFeaturesAdd;
	
  xVlCallFeatures.iid.config_owner = IFX_WEB;
  xVlCallFeatures.ucLineId = 1;
  iRet = ifx_get_LineCallingFeatures(&xVlCallFeatures,0);
  printf("ifx_get_LineCallingFeatures Returned: %d \n\n",iRet);
#if 0
  if ( iRet == IFX_VMAPI_SUCCESS ) {

    xVlCallFeatures.bEnableCallWaiting = IFX_TRUE;
    xVlCallFeatures.bFwdStatus = 0;
    if(xVlCallFeatures.bFwdStatus)
      xVlCallFeatures.unCallFwdCfg |=IFX_VMAPI_CALL_FWD_BUSY;
		else
      xVlCallFeatures.unCallFwdCfg &= ~IFX_VMAPI_CALL_FWD_BUSY;

		xVlCallFeatures.xCfuAddress.ucAddrType = 1;
		IFX_VMAPI_STRCPY(xVlCallFeatures.xCfuAddress.acDisplayName, "hello");
		IFX_VMAPI_STRCPY(xVlCallFeatures.xCfuAddress.acUserName, "line1-user");
		IFX_VMAPI_STRCPY(xVlCallFeatures.xCfuAddress.acDestAddr, "172.20.22.11");
		xVlCallFeatures.xCfuAddress.unPort = 5111;
    iRet = ifx_set_LineCallingFeatures(IFX_OP_MOD,&xVlCallFeatures,0);
    printf("ifx_set_LineCallingFeatures Returned: %d\n\n",iRet);
  }
#endif
#if 1
  memset(&xVlCallFeaturesAdd,0,sizeof(xVlCallFeaturesAdd));
  xVlCallFeaturesAdd.ucLineId = 1;
  xVlCallFeaturesAdd.iid.config_owner = IFX_WEB;
  iRet = ifx_set_LineCallingFeatures(IFX_OP_DEL,&xVlCallFeaturesAdd,0);

  if(iRet == IFX_VMAPI_SUCCESS)
  printf("Successfull Del for Call Features");
#endif
#endif

#if TEST_VOICE_LINE_CODEC
  x_IFX_VMAPI_LineCodec xLineCodec;
  xLineCodec.iid.cpeId.Id = 9;
  xLineCodec.iid.config_owner = IFX_TR69;
  
  iRet = ifx_get_LineVoiceCodec(&xLineCodec,0);
  printf("ifx_get_LineVoiceCodec Returned: %d\n\n",iRet);
 
  if (iRet == IFX_VMAPI_SUCCESS ) {
    //xLineCodec.unTxBitRate = ~xLineCodec.unTxBitRate;
    xLineCodec.unFrameLen = (xLineCodec.unFrameLen == 20)?30:20;
    iRet = ifx_set_LineVoiceCodec(IFX_OP_MOD,&xLineCodec,0);
  } 
#endif

#if TEST_VOICE_LINE_CODEC_LIST

  x_IFX_VMAPI_LineCodecList xLineCodecList;
  x_IFX_VMAPI_CodecDesc *pxTemp;

  xLineCodecList.iid.cpeId.Id = 1;
  xLineCodecList.iid.config_owner = IFX_TR69;

  iRet = ifx_get_LineCodecList(&xLineCodecList,0);

  printf("ifx_get_LineCodecList Returned : %d\n",iRet);

  pxTemp = xLineCodecList.pxCodecList;  

  if ( iRet == IFX_VMAPI_SUCCESS ) {
    while( pxTemp != NULL) {
      printf("Codec %d\n",i+1);
      printf("\tCodec Name : %s\n\tCodec Frame Len : %d\n",
            pxTemp->acCodecName,
            pxTemp->unCodecSuppFrameLen);
      strcpy(pxTemp->acCodecName,"Testing"); 
     __ifx_list_GetNext((void **)&pxTemp);
  }
    

    iRet = ifx_set_LineCodecList(IFX_OP_MOD,&xLineCodecList,0);
    printf("ifx_set_LineCodecList Returned : %d\n",iRet);

  }
#endif

#if TEST_VOICE_LINE_CODEC_LIST_ENTRY

    x_IFX_VMAPI_CodecDesc xTemp1 = {'\0'};
    
    xTemp1.ucLineId = 1;
    xTemp1.ucIndex = 1;
//    xTemp1.iid.pcpeId.Id = 1;
    strcpy(xTemp1.acCodecName,"TestAdd"); 

    iRet = ifx_set_CodecDesc(IFX_OP_ADD,&xTemp1,0);
    printf("ifx_set_CodecDesc Add Returned : %d\n",iRet);

#endif

  printf("\n\n********************** Test %s **********************\n\n",
        (iRet == IFX_VMAPI_SUCCESS)?"Passed":"Failed");

#if VMAPI_WRITE_TO_CM
#if CM_INIT
	if (IFX_VMAPI_CM_SHUT()!= IFX_VMAPI_SUCCESS) {
		return IFX_VMAPI_FAIL;
	}
#endif
	if (IFX_VMAPI_CM_MGMT_SHUT() != IFX_VMAPI_SUCCESS) {
		return IFX_VMAPI_FAIL;
	}
#endif
  return 0;
}
