/**************************************************************************
 **   FILE NAME       : ifx_vmapi_cpeid.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Applications requiring cpeId
 **   SRC VERSION     : V0.1
 **   DATE            : 23-04-2007
 **   AUTHOR          : 
 **   DESCRIPTION     : This file defines the mechanism for maintaining
 **											the cpeId for the use of applications reequired
 **											to call the VMAPI ifx_get* and ifx_set* APIs.
 **   FUNCTIONS       : IFX_VMAPI_Get_CpeId
 **											
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#include <stdio.h>
#include <string.h>
#include "ifx_vmapi_port.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi_bintxt.h"
#include "ifx_vmapi_obj_param_tbl.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "ifx_ipc.h"
#include "stdlib.h"
#include "ifx_debug.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


//#define FIFO_NAME "/tmp/my_fifo"
#define FIFO_NAME IFX_IPC_VMAPI_FIFO

int main()
{
  uint32 rdFifoFd;
  //char8 acRdBuf[1000]={0};
  char8 pcErr;
  uchar8 ucFrom , ucTo;
  uint16 unMsgSize;
  uint32 uiRes;
   int16 nBytes = 0;
  char8* acRdBuf;
  uchar8 ucInfo,ucProf,ucLine,ucIndex;
  x_IFX_VMAPI_ProfileServiceProviderInfo *pxVP;
  x_IFX_VMAPI_ProfileServiceProviderInfo *pxVPn;
  x_IFX_VMAPI_VoiceLine *pxVLold;
  x_IFX_VMAPI_VoiceLine *pxVLnew;
	x_IFX_VMAPI_ProfileSignaling *pxProfSigOld;
	x_IFX_VMAPI_ProfileSignaling *pxProfSigNew;
  x_IFX_VMAPI_NumPlan *pxNPOld;
  x_IFX_VMAPI_NumPlan *pxNPNew;
	x_IFX_VMAPI_VoiceProfile *pxVPOld;
	x_IFX_VMAPI_VoiceProfile *pxVPNew;
	x_IFX_VMAPI_LineSignaling *pxVLSignOld;
	x_IFX_VMAPI_LineSignaling *pxVLSignNew;
  x_IFX_VMAPI_EventSubscribe *pxEvEntryOld;
  x_IFX_VMAPI_EventSubscribe *pxEvEntryNew;

  acRdBuf = malloc(5000); 
  memset(acRdBuf,0,sizeof(acRdBuf ));

  //memset(acRdBuf,"\0",sizeof(acRdBuf));
  if(access(FIFO_NAME,F_OK)== -1)
  {
    mkfifo(FIFO_NAME,0777);
  }
  rdFifoFd = open(FIFO_NAME,O_RDONLY);

     //nBytes = read(rdFifoFd,acRdBuf,sizeof(acRdBuf));
     //printf("Recv Msg %s of %d\n",acRdBuf,nBytes);
     //return IFX_CM_SUCCESS;
      if(IFX_IPC_RecvMsg(rdFifoFd,&ucFrom,&ucTo,
                         &unMsgSize,&uiRes,(char8 *)acRdBuf,&pcErr)<0)
      {
         printf("Receiving message from VMAPI failed");
         return IFX_VMAPI_FAIL;
      }
     
		 //printf("===Received Buffer is %s======\n",*acRdBuf);	
      //memset(&xVP,0,sizeof(xVP));
     //sscanf(acRdBuf,"%d%d%d",&ucInfo,&ucProf,&ucLine);
     //printf("Info is %d %d %d\n",ucInfo,ucProf,ucLine);
     ucInfo = *acRdBuf;
     ucProf = *(acRdBuf+1);
     ucLine = *(acRdBuf+2);
     ucIndex = *(acRdBuf+3);
     if (ucInfo == IFX_VMAPI_VP_SER_PROVIDER)
     {
       pxVP = acRdBuf+4;
       pxVPn = acRdBuf+4+sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo );
     }
		 else if (ucInfo == IFX_VMAPI_VP_SIGNALING)
     {
       pxProfSigOld = acRdBuf+4;
       pxProfSigNew = acRdBuf+4+sizeof(x_IFX_VMAPI_ProfileSignaling);
       printf("<FIFOREAD>Registrar addrss  IS %s\n",((x_IFX_VMAPI_ProfileSignaling *)pxProfSigNew)->acRegistrarAddr);
			 
     }
     else if ((ucInfo == IFX_VMAPI_VOICE_LINE) ||(ucInfo == IFX_VMAPI_ADD_LINE) ||(ucInfo == IFX_VMAPI_DELETE_LINE))
     {
       pxVLold = acRdBuf+4;
       printf("<FIFOREAD>OLD LINE STATUS IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLold)->ucLineStatus);
       printf("<FIFOREAD>OLD LINE STATE IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLold)->ucState);
       printf("<FIFOREAD>NEW LINE ASSO ENDPTS IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLold)->ucAssocVoiceInterface[0]);
       printf("<FIFOREAD>NEW LINE ASSO ENDPTS IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLold)->ucAssocVoiceInterface[1]);
       pxVLnew = acRdBuf+4+sizeof(x_IFX_VMAPI_VoiceLine );
       printf("<FIFOREAD>LINE ID IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLnew)->ucLineId);
       printf("<FIFOREAD>NEW LINE STATUS IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLnew)->ucLineStatus);
       printf("<FIFOREAD>NEW LINE STATE IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLnew)->ucState);
       printf("<FIFOREAD>NEW LINE ASSO ENDPTS IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLnew)->ucAssocVoiceInterface[0]);
       printf("<FIFOREAD>NEW LINE ASSO ENDPTS IS %d\n",((x_IFX_VMAPI_VoiceLine *)pxVLnew)->ucAssocVoiceInterface[1]);
     }
		 else if (ucInfo == IFX_VMAPI_VS_NUM_PLAN)
     {
       pxNPOld = acRdBuf+4;
       pxNPNew = acRdBuf+4+sizeof(x_IFX_VMAPI_NumPlan);
       printf("<FIFOREAD>Max Digits is %d\n",((x_IFX_VMAPI_NumPlan *)pxNPNew)->ucNumPlanMaxDigits);
       printf("<FIFOREAD>Max Digits is %d\n",((x_IFX_VMAPI_NumPlan *)pxNPNew)->ucInterdigTimerStd);
			 
     }
     else if ((ucInfo == IFX_VMAPI_VOICE_PROFILE) ||(ucInfo == IFX_VMAPI_ADD_PROFILE) ||(ucInfo == IFX_VMAPI_DELETE_PROFILE))
     {
       pxVPOld = acRdBuf+4;
       printf("<FIFOREAD>OLD ASSOLINES IS %d\n",((x_IFX_VMAPI_VoiceProfile *)pxVPOld)->aucAssoLineIds[0]);
       printf("<FIFOREAD>OLD ASSOLINES IS %d\n",((x_IFX_VMAPI_VoiceProfile *)pxVPOld)->aucAssoLineIds[1]);
       pxVPNew = acRdBuf+4+sizeof(x_IFX_VMAPI_VoiceProfile);
       printf("<FIFOREAD>NEW ASSOLINES IS %d\n",((x_IFX_VMAPI_VoiceProfile *)pxVPNew)->aucAssoLineIds[0]);
       printf("<FIFOREAD>NEW ASSOLINES IS %d\n",((x_IFX_VMAPI_VoiceProfile *)pxVPNew)->aucAssoLineIds[1]);
       printf("<FIFOREAD>PROFILE ID IS %d\n",((x_IFX_VMAPI_VoiceProfile *)pxVPNew)->ucProfileId);
		 }
		 else if (ucInfo == IFX_VMAPI_VL_SIGNALING)
     {
       pxVLSignOld = acRdBuf+4;
       pxVLSignNew = acRdBuf+4+sizeof(x_IFX_VMAPI_LineSignaling);
       printf("<FIFOREAD> New Username is %s\n",((x_IFX_VMAPI_LineSignaling *)pxVLSignNew)->acSipUserName);
			 
     }
     else if (ucInfo == IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY)
     {
       pxEvEntryOld = acRdBuf+4;
       pxEvEntryNew = acRdBuf+4+sizeof(x_IFX_VMAPI_EventSubscribe);
       printf("<FIFOREAD>Notifier address is  %s\n",((x_IFX_VMAPI_EventSubscribe *)pxEvEntryNew)->acNotifierAddr);
       printf("<FIFOREAD>Notifier Port is %d\n",((x_IFX_VMAPI_EventSubscribe *)pxEvEntryNew)->unNotifierPort);
			 
     }
     free(acRdBuf);
  return IFX_VMAPI_SUCCESS;
}
