/*****************************************************************************
**   FILE NAME       : ifx_rtpapp_app.h
**   PROJECT         : RTP/RTCP
**   MODULES         : Session Management Module.
**   SRC VERSION     : V1.0
**   DATE            : 10-05-2006
**   AUTHOR          : Deepak Shrivastava.
**   DESCRIPTION     : This file contains data structure of session management.
**                     
**   FUNCTIONS       :
**   COMPILER        :
**   REFERENCE       : RTP-RTCP desgin dcoument, Coding guide lines
**   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 München, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_RTPAPP_APP_H__
#define __IFX_RTPAPP_APP_H__


/*Rtp Pool*/
typedef struct
{
  uint32 uiSessId;/* From Rtp Stack*/
  int16 nVoiceFd;/*Voice FD*/
  uint32 uiCallId; /*!< Call Id for the sessioni given by callmgr*/
  char8 szCoderDeviceName[IFX_CMGR_MAX_DEVICE_NAME_LEN];
}x_IFX_RTPAPP_SessInfo;


EXTERN x_IFX_RTPAPP_SessInfo *pxRtpAppHeadNode;

int8 IFX_RTPAPP_EventNotifier(uint32 uiCallId, e_IFX_ReasonCode eReasonCode);

/*RTPAPP APi's*/

int32 IFX_RTPAPP_AppInit(uchar8 ucDbgLvl,uchar8 ucDbgType,uint32 uiInternalPort);

int32 IFX_RTPAPP_AppMain(uchar8 ucDbgLvl,uchar8 ucDbgType,uint32 uiInternalPort);

int8 IFX_RTPAPP_DbgInit();


/*List Operations*/
void IFX_RTPAPP_ListInit();

void IFX_RTPAPP_InsertList(x_IFX_RTPAPP_SessInfo **pxRtpAppSessInfo);

void IFX_RTPAPP_deleteList(uint32 uiSessId);

void IFX_RTPAPP_SearchList(uint32 uiSessId,x_IFX_RTPAPP_SessInfo **pxRtpAppNode);




/* Rtp Pkt READ/WRITE API's*/
int32 IFX_RTPAPP_RtpPktArrived (IN uint32 uiSessionId, IN void *pvUserData, 
                                   IN char8 *pcSrcPkt, IN int16 unSrcPktLen);

int32 IFX_RTPAPP_ProcessRTPPacket( x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo);


/*Memory Alloc For RTP/RTCP Pkts*/
int32 IFX_RTPAPP_AllocMemForRtpPkt(IN uint32 uiSessionId, IN void *pvUserData,
                                OUT char8 **pcBuff);

int32 IFX_RTPAPP_AllocMemForRtcpPkt(IN uint32 uiSessionId, IN void *pvUserData,
                                OUT char8 **pcBuff);

/*RTP APP Operation APi's*/

int8 IFX_RTPAPP_OpenConnection(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo);

int8  IFX_RTPAPP_ModifySession( IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo);

int8 IFX_RTPAPP_CloseSession(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo);

/* Failure Cases*/
int32 IFX_RTPAPP_InactivityTimeout(IN uint32 uiSessionId, IN void *pvUserData);

int32 IFX_RTPAPP_SsrcCollision(IN uint32 uiSessionId, IN void *pvUserData);

int32 IFX_RTPAPP_ByeArrived(IN uint32 uiSessionId, IN void *pvUserData,
						                OUT char8 *pcSrcPkt, OUT uint16 unSrcPktLen);


/*FD Related API's*/
int8 IFX_RTPAPP_SendMsgToFifo(IN int16 nFifoFd,
					                    IN char *pcFifoMsg,
							                IN int16 nMsgLen);

int32 IFX_RTPAPP_AddFDToSelect(void *pvUserData,int32 iRtpFd,
							   int32 iRtcpFd,int32 iIntRtpSock);

int32 IFX_RTPAPP_RemoveFDFromSelect(void *pvUserData,int32 iRtpFd,
									int32 iRtcpFd,int32 iIntRtpSock);


#endif/*__IFX_RTPAPP_APP_H__*/




















