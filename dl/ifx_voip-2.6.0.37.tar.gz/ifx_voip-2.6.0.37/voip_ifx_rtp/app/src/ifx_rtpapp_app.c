/**************************************************************************
 **   FILE NAME       : IFX_RTPAPP_App.c
 **   PROJECT         : Rtp Application
 **   MODULES         : Rtp Application  Module.
 **   SRC VERSION     : V0.1
 **   DATE            :26-04-2006.
 **   AUTHOR          :Voip Lib Team.
 **   DESCRIPTION     :RTP Application.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines.
 **
 **   COPYRIGHT       : Copyright © 2004
 **                     Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
/*Common Files*/
#include <sys/times.h>
#include <sched.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include "ifx_common_defs.h"

/*Stack Files*/
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include"ifx_rtpapp_app.h"
#include"IFX_RTP_Agent.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include "ifx_os.h"
#include "ifx_list.h"
#include "ifx_rtp_db.h"
/* Global Variables */
STATIC int16 v_nRtpAppFifoFd,v_nRtpAgentFifoFd;
STATIC fd_set v_ReaddSelectFd;
STATIC char8 vacRtpBuff[500],vacRtcpBuff[3000];
uchar8 vcRtpAppModId;
x_IFX_RTPAPP_SessInfo *vpxRtpAppHeadNode;

EXTERN char8** vppcArgv; //This is to set application title
/*****************************************************************************
*  Function Name   :IFX_RTPAPP_ListInit 
*  Description     : 
*  Input Values    : 
*  Output Values   : 
*  Return Value    : 
*  Notes           :
****************************************************************************/
void IFX_RTPAPP_ListInit()
{
 
  vpxRtpAppHeadNode=NULL;
  
}
/*****************************************************************************
*  Function Name   :IFX_RTPAPP_InsertList
*  Description     :
*  Input Values    :
*  Output Values   :
*  Return Value    :
*  Notes           :
****************************************************************************/

void IFX_RTPAPP_InsertList(x_IFX_RTPAPP_SessInfo **pxRtpAppSessInfo)
{
  int32 uiErrorCode =0;
   __ifx_list_add_front((void **)&vpxRtpAppHeadNode,( void **)pxRtpAppSessInfo,
                        sizeof(x_IFX_RTPAPP_SessInfo),&uiErrorCode);

}
/*****************************************************************************
*  Function Name   :IFX_RTPAPP_deleteList
*  Description     :
*  Input Values    :
*  Output Values   :
*  Return Value    :
*  Notes           :
****************************************************************************/
void IFX_RTPAPP_deleteList(uint32 uiSessId)
{
  x_IFX_RTPAPP_SessInfo *pxTmpPtr = (x_IFX_RTPAPP_SessInfo *)uiSessId;
  __ifx_list_del((void **)&vpxRtpAppHeadNode,(void *)pxTmpPtr);
  return;
}
/*****************************************************************************
*  Function Name   :IFX_RTPAPP_SearchList
*  Description     :
*  Input Values    :
*  Output Values   :
*  Return Value    :
*  Notes           :
****************************************************************************/
void IFX_RTPAPP_SearchList(uint32 iCallId,x_IFX_RTPAPP_SessInfo **pxRtpAppNode)
{
  x_IFX_RTPAPP_SessInfo *pxTmpPtr = vpxRtpAppHeadNode;
  while(pxTmpPtr != NULL)
  {
    if(pxTmpPtr->uiCallId == iCallId)
    {
       *pxRtpAppNode = pxTmpPtr;
       return;
    }
    __ifx_list_GetNext((void **)&pxTmpPtr);
  }
  *pxRtpAppNode = NULL;
  return;
}
/******************************************************************************
 *  Function Name   : IFX_RTPAPP_EventNotifier
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int8 IFX_RTPAPP_EventNotifier(uint32 uiCallId, e_IFX_ReasonCode eReasonCode)
{
  x_IFX_RTP_AGENT_App2Agent xAppInfo ={0};
  xAppInfo.uiCallId = uiCallId;
  xAppInfo.eErrCode = eReasonCode;

   return IFX_RTPAPP_SendMsgToFifo(v_nRtpAgentFifoFd,(char*)&xAppInfo,
	                                sizeof(x_IFX_RTP_AGENT_App2Agent));

}
/******************************************************************************
 *  Function Name   : IFX_RTPAPP_AppInit
 *  Description     : This Function is responsible of Initializing the RTP Application.  
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_RTPAPP_AppInit(uchar8 ucDbgLvl,uchar8 ucDbgType,uint32 uiInternalPort)
{
   
   pid_t nPid;
   struct sched_param p;

   /* Create the new process for RTP/RTCP module */
   nPid = fork();
   if( nPid == -1 )
   {
      return IFX_FAILURE;
   }
   if( nPid == 0 )
   {
       //strcpy(argv[0],IFX_IPC_APP_NAME_RTP);
			memset(*vppcArgv,0,strlen(*vppcArgv));
			strcpy(*vppcArgv, IFX_IPC_APP_NAME_RTP);
      if( ( p.sched_priority = sched_get_priority_max( SCHED_FIFO ) ) == -1 )
      {
         return IFX_FAILURE;
      }
			p.sched_priority = 90;
      if( sched_setscheduler( 0,SCHED_FIFO,&p ) < 0 )
      {
         return IFX_FAILURE;
      }
      IFX_RTPAPP_AppMain(ucDbgLvl,ucDbgType,uiInternalPort);
   }
   return nPid;
}
/******************************************************************
 * *  Function Name  :  IFX_RTP_DbgInit
 * *  Description      :  this function is responsible for initializing
 * *                 the debug module
 * *  Input Values      :  void
 * *  Output Values  :  void
 * *  Return Value      :  void
 * *  Notes       :
 * *********************************************************************/
int8 IFX_RTPApp_DbgInit(uchar8 ucDbgLvl,uchar8 ucDbgType)
{
   int8 cRet = IFX_SUCCESS;

   IFX_DBG_Init(IFX_IPC_APP_NAME_RTPAPP,ucDbgType,
                ucDbgLvl, &vcRtpAppModId, &cRet);
   
	 if (cRet != IFX_SUCCESS)
   {
	   return IFX_FAILURE;
	 }

   return IFX_RTP_StackCfg(ucDbgLvl,ucDbgType);

}
/******************************************************************************
 *  Function Name   : IFX_RTPAPP_AppMain
 *  Description     : This Function is responsible of process messages recieved from
                      Fifo.  
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_RTPAPP_AppMain(uchar8 ucDbgLvl,uchar8 ucDbgType,uint32 uiInternalPort)
{
   int8 cRet = IFX_SUCCESS, cStackMode;
   int32 iNoOfFds=0;
   fd_set xTemp1FdSet;
   int16 nBufSize=0;
   x_IFX_RTP_SyncCallBks xSyncCallBks={0};
#ifdef FIREWALL_DRILL
	 char8 acCommand[256]="";
#endif

   /*initialize the list*/
   IFX_RTPAPP_ListInit();

   cRet = IFX_RTPApp_DbgInit(ucDbgLvl,ucDbgType);
   if (cRet != IFX_SUCCESS)
   {
      return cRet;
   }
   /* Create RTP Fifo */ 
   umask( 0 );
   if(access( IFX_IPC_RTP_APP_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_RTP_APP_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_RTP_APP_FIFO");
         return cRet;
      }
   }
   if((v_nRtpAppFifoFd = IFX_OS_OpenFifo( (uchar8 *)IFX_IPC_RTP_APP_FIFO,O_RDWR)) 
	   == -1 )
   {
      IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
	       "<AppMain> IFX_IPC_RTP_APP_FIFO");
      return cRet;
   }

   if(access( IFX_IPC_RTP_AGENT_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_RTP_AGENT_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_RTP_AGENT_FIFO");
         return cRet;
      }
   }
   if((v_nRtpAgentFifoFd = IFX_OS_OpenFifo( (uchar8 *)IFX_IPC_RTP_AGENT_FIFO,O_RDWR))
     == -1 )
   {
      IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
             "<AppMain> IFX_IPC_RTP_AGENT_FIFO");
      return cRet;
   }

   
   IFX_OS_FdZero( &v_ReaddSelectFd );

   /* parent is waiting , resume parent process*/
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		    " <AppMain>Init success");
   IFX_OS_FdSet( v_nRtpAppFifoFd,&v_ReaddSelectFd );


   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
            "RTP FIFO fd ",v_nRtpAppFifoFd);

   memset(&xSyncCallBks,0,sizeof( x_IFX_RTP_SyncCallBks)); 
   xSyncCallBks.pfnAddFDToSelect=IFX_RTPAPP_AddFDToSelect;
   xSyncCallBks.pfnRemoveFDFromSelect= IFX_RTPAPP_RemoveFDFromSelect;
   cStackMode = IFX_RTP_SYNC_MODE;

#ifdef FIREWALL_DRILL
	 sprintf(acCommand,"/etc/rc.d/port_drill intport udp %d",uiInternalPort);
   system(acCommand);
#endif
   cRet = IFX_RTP_Init(cStackMode,&xSyncCallBks,uiInternalPort);
   if( cRet == IFX_FAILURE )
   {
      IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<AppMain> Error RtpInit" );
      return cRet;
   }
   while( 1 )
   {
     /* Check if HAPI Voice Fd is set */
#ifndef UDP_REDIRECT
     x_IFX_RTPAPP_SessInfo *pxTmpPtr = vpxRtpAppHeadNode;
#endif
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		"<AppMain> Select Block");
     memcpy(&xTemp1FdSet,&v_ReaddSelectFd,sizeof(fd_set));
     iNoOfFds = select( FD_SETSIZE,&xTemp1FdSet,NULL,NULL,NULL );
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		"<AppMain> Select UnBlock");
     if( iNoOfFds < 0 )
     {
         if( errno == EINTR )
         {
            continue;
         }
         continue;
     }
     if( iNoOfFds == 0 )
     {
         continue;
     }
#ifndef UDP_REDIRECT
     while(pxTmpPtr != NULL)
	   {
       if(IFX_OS_FdIsSet(pxTmpPtr->nVoiceFd,&xTemp1FdSet ))
       {
         iNoOfFds--;
         IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "<AppMain> RTP Packet from DSP" );
         
         IFX_RTPAPP_ProcessRTPPacket(pxTmpPtr);
       }

        __ifx_list_GetNext((void **)&pxTmpPtr);
	   }
#endif  
#if 1
		if (iNoOfFds){
       IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<AppMain> Pkt from Network");
       IFX_RTP_SyncRecvPkt(&xTemp1FdSet,&iNoOfFds);
	  }
#endif
     /* Check for msgs in the RTP  Fifo */
		if (iNoOfFds){
     if( IFX_OS_FdIsSet( v_nRtpAppFifoFd,&xTemp1FdSet ))
     {
	     x_IFX_RTP_AGENT_Agent2App xAgentInfo;
       IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                "<AppMain> Message from FIFO");
       iNoOfFds--;
 	     nBufSize = IFX_OS_ReadFifo( v_nRtpAppFifoFd,( char8 * )&xAgentInfo,
                                   sizeof( x_IFX_RTP_AGENT_Agent2App ) );
       if( nBufSize < 0 )
       {
         IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_READ_ERR,
			            "<AppMain>  RTP Fifo" );
       }
       switch(xAgentInfo.eAction)
	     {
		     case IFX_RTP_AGENT_START_SESSION:
            IFX_RTPAPP_OpenConnection(&xAgentInfo.xAgentInfo);
			      break;
         case IFX_RTP_AGENT_STOP_SESSION:
            IFX_RTPAPP_CloseSession(&xAgentInfo.xAgentInfo);
            IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                     "Returned from CloseSession");
			      break;
		     case IFX_RTP_AGENT_MODIFY_SESSION:
			      IFX_RTPAPP_ModifySession(&xAgentInfo.xAgentInfo);
		        break;
				 case IFX_RTP_AGENT_MODIFY_CFG:
			      IFX_DBG_Set(IFX_IPC_APP_NAME_RTPAPP,vcRtpAppModId,xAgentInfo.ucDbgType,
						             xAgentInfo.ucDbgLvl);
			      IFX_RTP_StackCfg(xAgentInfo.ucDbgLvl,xAgentInfo.ucDbgType);     			
						break;
						
		   }
       
     }/*if RTP fd set */
		}
#if 0
	 else{
       IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<AppMain> Pkt from Network");
       IFX_RTP_SyncRecvPkt(&xTemp1FdSet,&iNoOfFds);
            iNoOfFds=0;
	  }
#endif
   } /* while(1) end */
   IFX_RTP_RtpShut();
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
   			"<AppMain> Terminated successfully" );
   return IFX_SUCCESS;
   
}

/******************************************************************
 * *  Function Name  :  IFX_RTPAPP_ProcessRTPPacket
 * *  Description      :  this function is responsible for initializing
 * *                 the debug module
 * *  Input Values      :  void
 * *  Output Values  :  void
 * *  Return Value      :  void
 * *  Notes       :
 * *********************************************************************/
int32 IFX_RTPAPP_ProcessRTPPacket( x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo)
{
  int16 nPktLen=0;
  int32 iRetVal=IFX_SUCCESS;
  char8 pcBuffer[IFX_RTP_MAX_BUFF_SIZE];
  
  nPktLen = read(pxRtpAppSessInfo->nVoiceFd,
                 pcBuffer,IFX_RTP_MAX_BUFF_SIZE);
  if( nPktLen <= 0 )
  {
    IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "<ProcessRTPPacket> Read from device failure" );
    return iRetVal;
  }
  iRetVal=IFX_RTP_SessSendRawPkt(pxRtpAppSessInfo->uiSessId,pcBuffer,nPktLen);
  if(iRetVal<0)
  { 
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
              "<ProcessRTPPacket>Send raw packet failed"); 
  }
  return iRetVal;      
}

/******************************************************************
 * *  Function Name  :  IFX_RTPAPP_RtpPktArrived
 * *  Description      :  this function is responsible for initializing
 * *                 the debug module
 * *  Input Values      :  void
 * *  Output Values  :  void
 * *  Return Value      :  void
 * *  Notes       :
 * *********************************************************************/
int32 IFX_RTPAPP_RtpPktArrived (IN uint32 uiSessionId, IN void *pvUserData, 
                                IN char8 *pcSrcPkt, IN int16 unSrcPktLen)
{
  int32 iRetVal=IFX_SUCCESS;
  x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo = (x_IFX_RTPAPP_SessInfo *) pvUserData;

  iRetVal = write(pxRtpAppSessInfo->nVoiceFd,
			       pcSrcPkt,unSrcPktLen);
  if(iRetVal<0)
  { 
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                     "<RtpPktArrived>Device write failed"); 
  }
  //free(pcSrcPkt); not required since we take memory from global array-radvajesh
  return iRetVal;
}
/******************************************************************
 * *  Function Name  :  IFX_RTPAPP_AllocMemForRtpPkt
 * *  Description      :  this function is responsible for initializing
 * *                 the debug module
 * *  Input Values      :  void
 * *  Output Values  :  void
 * *  Return Value      :  void
 * *  Notes       :
 * *********************************************************************/
int32 IFX_RTPAPP_AllocMemForRtpPkt(IN uint32 uiSessionId, IN void *pvUserData,
                                OUT char8 **pcBuff)
{
  int32 iRetVal=IFX_SUCCESS;
  *pcBuff=vacRtpBuff;
  if(*pcBuff==NULL)
  {
    IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                     "<AllocMemForRtpPkt>Memory allocaton failed"); 
    iRetVal=IFX_FAILURE;
  }
  return iRetVal;
}
/******************************************************************
 * *  Function Name  :  IFX_RTPAPP_AllocMemForRtcpPkt
 * *  Description      :  this function is responsible for initializing
 * *                 the debug module
 * *  Input Values      :  void
 * *  Output Values  :  void
 * *  Return Value      :  void
 * *  Notes       :
 * *********************************************************************/
int32 IFX_RTPAPP_AllocMemForRtcpPkt(IN uint32 uiSessionId, IN void *pvUserData,
                                OUT char8 **pcBuff)
{
  int32 iRetVal=IFX_SUCCESS;
  *pcBuff=vacRtcpBuff;
  if(*pcBuff==NULL)
  {
    IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                     "<AllocMemForRtcpPkt>Memory allocaton failed"); 
    iRetVal=IFX_FAILURE;
  }
  return iRetVal;
}



/******************************************************************
*  Function Name  :  IFX_RTP_OpenConnection
*  Description    :  This function opens new connection per session
*  Input Values   :  pxSsMsg
*  Output Values  :  None
*  Return Value   :  IFX_SUCCESS/IFX_FAILUREURE
*  Notes          :
*********************************************************************/
int8 IFX_RTPAPP_OpenConnection(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo)
{

  x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo=NULL;
  uchar8 ucErr = 0;
  int8 cRet=IFX_SUCCESS;
  x_IFX_RTP_CallBks xCallBks={0};
  uint32 unOption=0xFF;
#ifdef QOS_SUPPORT
	char acCommand[512] = "";
	uchar8 ucQosEnabled = 0;
#endif
#ifdef FIREWALL_DRILL
	uchar8 ucFirewall = 0;
#endif 
  xCallBks.pfnAllocMemForRtpPkt=IFX_RTPAPP_AllocMemForRtpPkt;
  xCallBks.pfnAllocMemForRtcpPkt=IFX_RTPAPP_AllocMemForRtcpPkt;
  xCallBks.pfnRtpPktArrived=IFX_RTPAPP_RtpPktArrived;
  xCallBks.pfnInactivityTimeout=IFX_RTPAPP_InactivityTimeout;
  xCallBks.pfnSsrcCollision=IFX_RTPAPP_SsrcCollision;
  xCallBks.pfnByeArrived = IFX_RTPAPP_ByeArrived;
  /* app data creation */
  IFX_RTPAPP_InsertList(&pxRtpAppSessInfo);
  if(pxRtpAppSessInfo == NULL){
    ucErr = 1;
		goto Terminate;
	}
  pxRtpAppSessInfo->uiCallId = pxRtpAgentInfo->uiCallId;

  strcpy(pxRtpAppSessInfo->szCoderDeviceName,pxRtpAgentInfo->szCoderDeviceName);

  pxRtpAppSessInfo->uiSessId=IFX_RTP_SessCreate(1,1,pxRtpAppSessInfo,&xCallBks);
  pxRtpAppSessInfo->nVoiceFd = -1; 
  
	IFX_RTP_SessSetSsrc(pxRtpAppSessInfo->uiSessId,pxRtpAgentInfo->uiSsrcNumber);
#ifdef QOS_SUPPORT
	sprintf(acCommand,"/etc/rc.d/rt_media.sh start %s %d udp 2> /dev/null",
          pxRtpAgentInfo->xRtpParams.szLocalRtpIpAddr,
					pxRtpAgentInfo->xRtpParams.uiLocalRtpPort);
  ucQosEnabled = 1;
	system(acCommand);

/*Also Add rule for default route
  command: route add $remote_ip default gw $ip_addr_voip_if
	Do not add route if VoIP is running on br0 */
  
  if( (getenv("WAN") != NULL) && strcmp("br0",getenv("WAN")) ){
  sprintf(acCommand,"/etc/rc.d/rc.voip_routing_rule.sh add %s %s",
  pxRtpAgentInfo->xRtpParams.szRemoteRtpIpAddr,getenv("WAN"));
  //printf("RtpAgetnStart command is %s \n",acCommand);
  system(acCommand);
  }
#endif

#ifdef FIREWALL_DRILL	
	sprintf(acCommand,"/etc/rc.d/port_drill add udp %d 2> /dev/null",
					pxRtpAgentInfo->xRtpParams.uiLocalRtpPort);
  ucQosEnabled = 1;
	system(acCommand);
	sprintf(acCommand,"/etc/rc.d/port_drill add udp %d 2> /dev/null",
					pxRtpAgentInfo->xRtpParams.uiLocalRtcpPort);
	system(acCommand);

#endif

  cRet=IFX_RTP_SessConfig(pxRtpAppSessInfo->uiSessId,
		     unOption,
		     IFX_RTP_SEND_RECV,
		     pxRtpAgentInfo->xRtpParams.szRemoteRtpIpAddr,
		     pxRtpAgentInfo->xRtpParams.uiRemoteRtpPort,
		     pxRtpAgentInfo->xRtpParams.szLocalRtpIpAddr,
			 pxRtpAgentInfo->xRtpParams.uiLocalRtpPort);
  if(cRet== IFX_FAILURE)
  {
      IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
                 "<OpenConnection> Session config failed ");
      ucErr = 1;
		  goto Terminate;
  }

  
  cRet=IFX_RTCP_SessConfig(pxRtpAppSessInfo->uiSessId,
                     unOption,
                     3200,
                     (char8 *)pxRtpAgentInfo->xRtpParams.szRemoteRtpIpAddr,
                     pxRtpAgentInfo->xRtpParams.uiRemoteRtcpPort|0x1,
                    (char8 *) pxRtpAgentInfo->xRtpParams.szLocalRtpIpAddr,
			         pxRtpAgentInfo->xRtpParams.uiLocalRtcpPort|0x01);
  if(cRet== IFX_FAILURE)
  {
      IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
                 "<OpenConnection> RTCP Session config failed ");
      ucErr = 1;
		  goto Terminate;
  }



  cRet=IFX_RTP_SessOpen(pxRtpAppSessInfo->uiSessId);
  if(cRet== IFX_FAILURE)
  {
      IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
                 "<OpenConnection>Session open failed =");
      ucErr = 1;
		  goto Terminate;
  }
#ifndef UDP_REDIRECT 
  pxRtpAppSessInfo->nVoiceFd = open( pxRtpAgentInfo->szCoderDeviceName,O_RDWR );
  if(pxRtpAppSessInfo->nVoiceFd < 0 )
  {
    IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
             "<StartSession>PLI Device open failed");
	  ucErr = 1;
		goto Terminate;
  }
  else 
  {
    FD_SET(pxRtpAppSessInfo->nVoiceFd,&v_ReaddSelectFd );
  }
#endif	

Terminate:

#ifdef QOS_SUPPORT
if(ucQosEnabled == 1 && ucErr ==1) {
    sprintf(acCommand,"/etc/rc.d/rt_media.sh stop %s %d udp 2> /dev/null",
            pxRtpAgentInfo->xRtpParams.szLocalRtpIpAddr,
	          pxRtpAgentInfo->xRtpParams.uiLocalRtpPort);

    system(acCommand);
   /*Delete QoS Route rules*/ 
  if( (getenv("WAN") != NULL) && strcmp("br0",getenv("WAN")) ){
  sprintf(acCommand,"/etc/rc.d/rc.voip_routing_rule.sh del %s %s",
  pxRtpAgentInfo->xRtpParams.szRemoteRtpIpAddr,getenv("WAN"));

  //printf("RtpAgetnStart command is %s \n",acCommand);
  system(acCommand);
	}

   }
#endif
#ifdef FIREWALL_DRILL
if(ucFirewall == 1 && ucErr ==1) {
	sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null",
					pxRtpAgentInfo->xRtpParams.uiLocalRtpPort);
	system(acCommand);
	sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null",
					pxRtpAgentInfo->xRtpParams.uiLocalRtcpPort);
	system(acCommand);
  }
#endif

	
  if( ucErr && pxRtpAppSessInfo)
  {
    /* clear the session and connection */
    if( pxRtpAppSessInfo->uiSessId )
    {
#ifndef UDP_REDIRECT 
       if(pxRtpAppSessInfo->nVoiceFd != -1)
      		FD_CLR(pxRtpAppSessInfo->nVoiceFd,&v_ReaddSelectFd);
#endif 
      cRet=IFX_RTP_SessClose(pxRtpAppSessInfo->uiSessId);
      if(cRet<0)
      {
        IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                "<Open Connection>Error in RTP Close Session");
      }
      IFX_RTPAPP_EventNotifier(pxRtpAppSessInfo->uiCallId,IFX_RTP_AGENT_OPEN_FAIL);
    }
    /*delete the session information*/
    IFX_RTPAPP_deleteList((uint32)pxRtpAppSessInfo);
  }
  IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
      			"<OpenConnection> Open Connection success" ); 
  return IFX_SUCCESS;
}

/***********************************`*******************************
*  Function Name  :  IFX_RTP_ModifyConnection
*  Description    :  This function modifies the existing connection
*  Input Values      :  pxSsMsg
*  Output Values  :  xRtpMsg
*  Return Value      :  IFX_SUCCESS/IFX_FAILUREURE
*  Notes    :
*********************************************************************/
int8  IFX_RTPAPP_ModifySession( IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo)
{

   x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo=NULL;
   IFX_RTPAPP_SearchList(pxRtpAgentInfo->uiCallId,&pxRtpAppSessInfo);
   uint16 unOption=IFX_RTP_SET_TXADDR|IFX_RTP_SET_TXPORT|IFX_RTP_SET_RXPORT|IFX_RTP_SET_RXADDR;
	 char8 cRet=IFX_FAILURE,ucErr=0;
   if(pxRtpAppSessInfo == NULL){
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<ModifySession> Session does not exsists");
		 return IFX_SUCCESS;
	 }	 

   /*Call the rtp api*/
   cRet=IFX_RTP_SessConfig(pxRtpAppSessInfo->uiSessId,
             unOption,
  		     IFX_RTP_SEND_RECV,
		     pxRtpAgentInfo->xRtpParams.szRemoteRtpIpAddr,
		     pxRtpAgentInfo->xRtpParams.uiRemoteRtpPort,
		     pxRtpAgentInfo->xRtpParams.szLocalRtpIpAddr,
			 pxRtpAgentInfo->xRtpParams.uiLocalRtpPort);
   if(cRet== IFX_FAILURE)
   {
       IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<ModifyConnection> RTP Session config failed ");
       ucErr = 1;
   }
   unOption |= IFX_RTCP_SET_INTSTATCALC;
   cRet=IFX_RTCP_SessConfig(pxRtpAppSessInfo->uiSessId, unOption,
	                  3200,
                     (char8 *) pxRtpAgentInfo->xRtpParams.szRemoteRtpIpAddr,
                    pxRtpAgentInfo->xRtpParams.uiRemoteRtcpPort|0x1,
                     (char8 *)pxRtpAgentInfo->xRtpParams.szLocalRtpIpAddr,
			         pxRtpAgentInfo->xRtpParams.uiLocalRtcpPort|0x01);
   if(cRet== IFX_FAILURE)
   {
       IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<ModifyConnection> RTCP Session config failed =");
       ucErr = 1;
   }
   if( ucErr )
   {
    /* clear the session and connection */
    if( pxRtpAppSessInfo->uiSessId )
    {
#ifndef UDP_REDIRECT 
      FD_CLR(pxRtpAppSessInfo->nVoiceFd,&v_ReaddSelectFd); 
#endif      
      cRet=IFX_RTP_SessClose(pxRtpAppSessInfo->uiSessId);
      if(cRet<0)
      {
        IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                "<Modify Connection>Error in RTP Close Session");
      }
      IFX_RTPAPP_EventNotifier(pxRtpAppSessInfo->uiCallId,IFX_RTP_AGENT_MODIFY_FAIL);
	  }
    /*delete the session information*/
    IFX_RTPAPP_deleteList((uint32)pxRtpAppSessInfo);
    IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
              "<ModifyConnection> The error type  =");
   }
  
   return IFX_SUCCESS;
}
/******************************************************************
 * *  Function Name  :  IFX_RTP_CloseSession
 * *  Description    :  This function Close the current connection
 * 			after recives response from RM
 * *  Input Values   :  ucSessId, pxRmTxMsg,pxRtpMsg
 * *  Output Values  :  none
 * *  Return Value      :  void
 * *  Notes    :
 * *********************************************************************/
int8 IFX_RTPAPP_CloseSession(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo)
{

   x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo = NULL;
	 char8 cRet=IFX_FAILURE;
   IFX_RTPAPP_SearchList(pxRtpAgentInfo->uiCallId,&pxRtpAppSessInfo);
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<CloseSession>In Function Close Session");
   if(pxRtpAppSessInfo == NULL){
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<CloseSession> Session does not exsists");
		 return IFX_SUCCESS;
	 }
#ifndef UDP_REDIRECT 
   FD_CLR(pxRtpAppSessInfo->nVoiceFd,&v_ReaddSelectFd); 
   close(pxRtpAppSessInfo->nVoiceFd);
#endif	


#ifdef QOS_SUPPORT
if(NULL != pxRtpAppSessInfo)
{
	x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)
	pxRtpAppSessInfo->uiSessId;
        char acCommand[128]="";
	if(NULL != pxSess){     
		if(pxSess->pxConnListHeadPtr != NULL && pxSess->pxConnListHeadPtr->pxConn !=NULL) {
       uint16 unPort = pxSess->pxConnListHeadPtr->pxConn->unLocalPort;
       char acIPAddr[128]="";
		   char8 acRemoteIPAddr[32]="";
       
			 /*Remove RTP QoS Rule*/
       sprintf(acIPAddr,"%d.%d.%d.%d",(pxSess->uiLocalIpAddr>>24 & 0xFF),
       (pxSess->uiLocalIpAddr>>16 & 0xFF),(pxSess->uiLocalIpAddr>>8 & 0xFF),
       (pxSess->uiLocalIpAddr & 0xFF));
       sprintf(acCommand,"/etc/rc.d/rt_media.sh stop %s %d udp 2> /dev/null",acIPAddr,unPort);
       system(acCommand);

       /*Get Remote IP Addr*/
       sprintf(acRemoteIPAddr,"%d.%d.%d.%d",(pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP>>24 & 0xFF),
       (pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP>>16 & 0xFF),(pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP>>8 & 0xFF),
       (pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP & 0xFF));
			
			 /*Remove QoS Route Rule
				command: route del $remote_ip default gw $local_ip*/	
  		 if( (getenv("WAN") != NULL) && strcmp("br0",getenv("WAN")) ){
       sprintf(acCommand,"/etc/rc.d/rc.voip_routing_rule.sh del %s %s",
			acRemoteIPAddr,getenv("WAN"));
       //printf("CloseRtpSess command = %s\n",acCommand);
       system(acCommand);
      }
    }
  }
}

#endif
#ifdef FIREWALL_DRILL
if(NULL != pxRtpAppSessInfo)
{
	x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)
	pxRtpAppSessInfo->uiSessId;
        char acCommand[128]="";
	if(NULL != pxSess) {  
		if(pxSess->pxConnListHeadPtr != NULL && pxSess->pxConnListHeadPtr->pxConn !=NULL) {
       uint16 unPort = pxSess->pxConnListHeadPtr->pxConn->unLocalPort;
       sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null",unPort);
       system(acCommand);
       unPort = pxSess->pxConnListHeadPtr->pxConn->unLocalRtcpPort;
       sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null",unPort);
       system(acCommand);
    }
  }
}
#endif

   cRet=IFX_RTP_SessClose(pxRtpAppSessInfo->uiSessId);
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Returned from IFX_RTP_SessClose");
   if(cRet < 0)
   {
     IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                     "<CloseSession>Error in RTP Close session");
      IFX_RTPAPP_EventNotifier(pxRtpAppSessInfo->uiCallId,IFX_RTP_AGENT_CLOSE_FAIL);      
   }
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Before IFX_RTPAPP_deleteList");
   IFX_RTPAPP_deleteList((uint32)pxRtpAppSessInfo);
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "After IFX_RTPAPP_deleteList");
   return IFX_SUCCESS;
}

/******************************************************************
 ** *  Function Name  :  IFX_RTPAPP_ByeArrived
 ** *  Description    :  This function Close the current connection
 ** *  Input Values   :
 ** *  Output Values  :  Session Identifier, pvUserData
 ** *  Return Value   :  IFX_SUCCESS/IFX_FAILURE
 ** *  Notes          :
 ** *********************************************************************/
int32 IFX_RTPAPP_ByeArrived(IN uint32 uiSessionId, IN void *pvUserData,
                            OUT char8 *pcSrcPkt, OUT uint16 unSrcPktLen)
{
  x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo = (x_IFX_RTPAPP_SessInfo *) pvUserData;
#ifdef QOS_SUPPORT
if(NULL != pxRtpAppSessInfo)
{
	x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)
	pxRtpAppSessInfo->uiSessId;
  char acCommand[128]="";
  char8 acRemoteIPAddr[32]="";
	if(NULL != pxSess){     
		if(pxSess->pxConnListHeadPtr != NULL && pxSess->pxConnListHeadPtr->pxConn !=NULL) {
       uint16 unPort = pxSess->pxConnListHeadPtr->pxConn->unLocalPort;
       char acIPAddr[128]="";
       sprintf(acIPAddr,"%d.%d.%d.%d",(pxSess->uiLocalIpAddr>>24 & 0xFF),
       (pxSess->uiLocalIpAddr>>16 & 0xFF),(pxSess->uiLocalIpAddr>>8 & 0xFF),
       (pxSess->uiLocalIpAddr & 0xFF));
       sprintf(acCommand,"/etc/rc.d/rt_media.sh stop %s %d udp 2> /dev/null",acIPAddr,unPort);
       system(acCommand);
		
				/*Get Remote IP Address*/	
				sprintf(acRemoteIPAddr,"%d.%d.%d.%d",(pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP>>24 & 0xFF),
       (pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP>>16 & 0xFF),(pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP>>8 & 0xFF),
       (pxSess->pxConnListHeadPtr->pxConn->uiRemoteIP & 0xFF));
			
			 /*Remove QoS Route Rule
				command: route del $remote_ip default gw $local_ip*/	
  		if( (getenv("WAN") != NULL) && strcmp("br0",getenv("WAN")) ){
       sprintf(acCommand,"/etc/rc.d/rc.voip_routing_rule.sh del %s %s",
        acRemoteIPAddr,getenv("WAN"));
       //printf("CloseRtpSess command = %s\n",acCommand);
       system(acCommand);
      }
    }
  }
}

#endif
#ifdef FIREWALL_DRILL
if(NULL != pxRtpAppSessInfo)
{
	x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)
	pxRtpAppSessInfo->uiSessId;
        char acCommand[128]="";
	if(NULL != pxSess) {  
		if(pxSess->pxConnListHeadPtr != NULL && pxSess->pxConnListHeadPtr->pxConn !=NULL) {
       uint16 unPort = pxSess->pxConnListHeadPtr->pxConn->unLocalPort;
       sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null",unPort);
       system(acCommand);
       unPort = pxSess->pxConnListHeadPtr->pxConn->unLocalRtcpPort;
       sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null ",unPort);
       system(acCommand);
    }
  }
}
#endif
  
	if(NULL != pxRtpAppSessInfo)
  	IFX_RTPAPP_EventNotifier(pxRtpAppSessInfo->uiCallId,IFX_RTCP_AGENT_BYE_IND); 
	return IFX_SUCCESS;
}
/******************************************************************
 ** *  Function Name  :  IFX_RTPAPP_InactivityTimeout
 ** *  Description    :  This function Close the current connection
 ** *  Input Values   :
 ** *  Output Values  :  Session Identifier, pvUserData
 ** *  Return Value   :  IFX_SUCCESS/IFX_FAILURE
 ** *  Notes          :
 ** *********************************************************************/
int32 IFX_RTPAPP_InactivityTimeout(IN uint32 uiSessionId, IN void *pvUserData)
{
 
  x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo = (x_IFX_RTPAPP_SessInfo *) pvUserData;  
  IFX_RTPAPP_EventNotifier(pxRtpAppSessInfo->uiCallId,IFX_RTCP_AGENT_INACTIVITY_IND); 
  return IFX_SUCCESS;
}       

/******************************************************************
 *  ** *  Function Name  :  IFX_RTPAPP_SsrcCollision 
 *  ** *  Description    :  This function Close the current connection
 *  ** *  Input Values   :
 *  ** *  Output Values  :  Session Identifier, pvUserData
 *  ** *  Return Value   :  IFX_SUCCESS/IFX_FAILURE
 *  ** *  Notes          :
 *  ** *********************************************************************/
int32 IFX_RTPAPP_SsrcCollision(IN uint32 uiSessionId, IN void *pvUserData)
{

  x_IFX_RTPAPP_SessInfo *pxRtpAppSessInfo = (x_IFX_RTPAPP_SessInfo *) pvUserData;
  IFX_RTPAPP_EventNotifier(pxRtpAppSessInfo->uiCallId,IFX_RTP_AGENT_CLOSE_IND); 
  return IFX_SUCCESS;
}



 /******************************************************************************
 *  Function Name   : IFX_RTP_SendMsgToFifo
 *  Description     : This module writes Msg to FIFO 
 *
 *  Input Values    : ua Message
 *  Output Values   : None
 *  Return Value    :
 *  Notes           :
 ******************************************************************************
*/
int8 IFX_RTPAPP_SendMsgToFifo(IN int16 nFifoFd, 
					          IN char *pcFifoMsg,
							  IN int16 nMsgLen )
{
   int16 nBytes = 0;
   nBytes = IFX_OS_WriteFifo(nFifoFd, (char8 *) pcFifoMsg,nMsgLen);
	if (nBytes != nMsgLen)
	{
       IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "<RTP> Error Writing to Fifo" );
       return IFX_FAILURE;
	}
   IFX_DBGC(vcRtpAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
                 "<RTP> Bytes Written to Fifo",nBytes );
   return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_RTPAPP_AddFDToSelect
 *  Description     : 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    :
 *  Notes           :
 ******************************************************************************
*/
int32 IFX_RTPAPP_AddFDToSelect(void *pvUserData,int32 iRtpFd,int32 iRtcpFd,int32 iRtpIntSockFd)
{
 if(iRtpFd != 0)
 {
   FD_SET(iRtpFd,&v_ReaddSelectFd ); 
 }
 if(iRtcpFd != 0)
 {
   FD_SET( iRtcpFd,&v_ReaddSelectFd ); 
 }
 if(iRtpIntSockFd != 0)
 {			
   FD_SET(iRtpIntSockFd,&v_ReaddSelectFd );
 }
  return 0;
}
/******************************************************************************
 *  Function Name   : IFX_RTPAPP_AddFDToSelect
 *  Description     :
 *
 *  Input Values    :
 *  Output Values   :
 *  Return Value    :
 *  Notes           :
 ******************************************************************************
*/
int32 IFX_RTPAPP_RemoveFDFromSelect(void *pvUserData,int32 iRtpFd,int32 iRtcpFd,int32 iRtpIntSockFd)
{
 if(iRtpFd != 0)
 {
   FD_CLR(iRtpFd,&v_ReaddSelectFd ); 
 }
 if(iRtcpFd != 0)
 {
    FD_CLR( iRtcpFd,&v_ReaddSelectFd ); 
 }
 if(iRtpIntSockFd != 0)
 {			
    FD_CLR(iRtpIntSockFd,&v_ReaddSelectFd );
 }
   return 0;
}

