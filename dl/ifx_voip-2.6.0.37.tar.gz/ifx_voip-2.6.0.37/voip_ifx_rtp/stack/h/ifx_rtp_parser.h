/**************************************************************************
 **   FILE NAME       : ifx_rtp_parser.h
 **   PROJECT         : RTP/RTCP for Inca IP Phone
 **   MODULES         : RTP/RTCP Encoder Decoder Implementation
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_RTP_PARSER_H__
#define __IFX_RTP_PARSER_H__

#define IFX_RTP_MAX_PKT_SIZE        (sizeof(x_IFX_RTCP_SR) + \
                                     IFX_RTP_MAX_CONNS * \
                                     sizeof(x_IFX_RTCP_RR) + \
                                     sizeof(x_IFX_RTCP_SdesItems) + \
                                     4 + IFX_RTP_NUM_PKT_SDES_ITEMS * \
                                     (IFX_RTCP_SDES_TEXT_LEN + 2) * \
                                     IFX_RTP_MAX_CONNS+sizeof(x_IFX_RTCP_Bye) + \
                                     4 * IFX_RTP_MAX_MEMBERS)

#define IFX_RTP_NUM_PKT_SDES_ITEMS   (8)

/* Defined for the time being, should be later changed to a meaningful value */
#define IFX_RTP_RTCP_DEF_PKT_SIZE    200 



EXTERN char8 
IFX_RTCP_Decode(IN x_IFX_RTP_Session *pxSess,
                IN x_IFX_RTP_ConnInfo *pxConn,
                IN uchar8 *pcBuffer, 
                IN int16 nBuffLen, 
                IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr);

EXTERN  int16 
IFX_RTP_EncodeSr(IN x_IFX_RTP_Session *pxSess, 
                 IN x_IFX_RTP_ConnInfo *pxConn,
                 OUT uchar8 *pucBuff, 
                 OUT uint16 *punBuffLen);

EXTERN  int16 
IFX_RTP_EncodeRr(IN x_IFX_RTP_Session *pxSess, 
                 IN x_IFX_RTP_ConnInfo *pxConn,
                 OUT uchar8 *pucBuff, 
                 OUT uint16 *punBuffLen);

EXTERN  int16 
IFX_RTP_EncodeSdes(IN x_IFX_RTP_Session *pxSess, 
                   IN x_IFX_RTP_ConnInfo *pxConn,
                   OUT uchar8 *pucBuff, 
                   OUT uint16 *punBuffLen);

EXTERN  int16 
IFX_RTP_EncodeBye(IN x_IFX_RTP_Session *pxSess, 
                  IN x_IFX_RTP_ConnInfo *pxConn,
                  OUT uchar8 *pucBuff, 
                  OUT uint16 *punBuffLen, 
                  IN char8 *pcReason);
PUBLIC int16
IFX_RTP_EncodeApp(IN x_IFX_RTP_Session *pxSess,
                  IN x_IFX_RTP_ConnInfo *pxConn,
                  OUT uchar8 *pucBuff,
                  OUT uint16 *punBuffLen,
                  IN void* vpUserPlugInData);

EXTERN int8 
IFX_RTP_CheckSsrcCollision(IN x_IFX_RTP_Session *pxSess, 
                           IN x_IFX_RTP_ConnInfo *pxConn,
                           IN uint8 ucPktType, 
                           IN char8 *pcBuffer, 
                           IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr );

#endif /* __IFX_RTP_PARSER_H__ */
