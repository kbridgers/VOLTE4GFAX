/**************************************************************************
 **   FILE NAME       : ifx_rtp_db.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : RTP/RTCP DB  module
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_RTP_DB_H__
#define __IFX_RTP_DB_H__

/* Max number of connections supported for a session
 * We support only a 3 party conference, so max is 2
 */

#define IFX_RTP_MAX_MEMBERS   3
#define IFX_RTP_MAX_CSRC 15

typedef struct
{
   uint8 ucCollisionCnt;
   uint16 unDataPort;
   uint16 unControlPort;
   uint32 uiSsrc;
   uint32 uiConflictIP;
   uint32 uiLastConflictTime;
   uint32 uiLastConflictTimeFrac;
}x_IFX_RTP_ConflictList;


typedef struct
{
   uint32 auiMembers[IFX_RTP_MAX_MEMBERS];
   double64 adiLastPktTime[IFX_RTP_MAX_MEMBERS];
} x_IFX_RTP_MemberList;

typedef struct
{
   uint32 auiSenders[IFX_RTP_MAX_MEMBERS];
   double64 adiLastRtpPktTime[IFX_RTP_MAX_MEMBERS];
} x_IFX_RTP_SenderList;

/* Connection info */
typedef struct
{
   x_IFX_RTP_AddOnCallBks xAddOnCB[IFX_RTP_MAX_ADD_ON];

   x_IFX_RTP_CallBks xCB;

   uint8 ucConnMode;

   /* Local Address Info */
   uint16 unLocalPort;
   uint16 unLocalRtcpPort;

   /* Remote Address Info */
   uint16 unRemoteRtpPort;
   uint16 unRemoteRtcpPort;
   uint16 unRemoteTxRtpPort;
   uint16 unRemoteTxRtcpPort;
   uint32 uiRemoteIP;
   uint32 uiRemoteRtcpIP;

   /* Socket Fds for this session */
   int32 iRtpFd;
   int32 iRtcpFd;
   int32 iConnId; /*<! GPRS ID to be associated with the FDs */

   /* Receiver SSRC for this Connection
    * Is also the CSRC in RTP header when the voice is mixed
    */
   uint32 uiRxSsrc;

   uint8 ucFirstRxPkt;
   /* To check whether RTP received*/
   uchar8 ucNoRtpCount;

   /* Last payload type for voice packet sent */
   uint32 uiTxLastPT;

   /* Last payload type Received, Could be Normal/SID/DTMF Event */
   uint8 ucRxLastPT;

   /* Last RTP TimeStamp Received */
   uint32 uiTxLastRtpTS;

   /* Number of Packets sent */
   uint32 uiNoTxPkt;

   /* Number of Octets sent */
   uint32 uiNoTxOctet;

   /* Last Sent Packet Size */
   uint16 unLastPktSize;

   /* Number of Packets received */
   uint32 uiNoRxPkt;

   /* Number of Octets received */
   uint32 uiNoRxOctet;

   /* Last SR Time */
   uint32 uiLastSrTime; 

   /* Last SR Recd Time */
   uint32 uiLastSrRecdTime;
   uint32 uiLastSrRecdTimeFrac;

   /* Timer Id */
   uint16 unTimerId;

   /* Parameters required for RTCP Interval Calculation */
   /* Reference Page 29 : RFC 3550 */

   /* Last Tx RTCP Pkt Time */
   double64 diLastTxRtcpPktTime;
   double64 diNextRtcpTime;

   /* Last Rx RTCP Pkt Time */
   long32 lLastRxRtcpPktTime;

   /* Initial RTCP Pkt Sent Flag */
   uchar8 ucInitial;
 
   /* TBD configuration Sender Source Description */
   x_IFX_RTCP_SdesItems xRxSrcDesc;

   void *pvUserData; /* !< User Data*/

   uint16 unSeqNum; /*!< Local sequence number*/

   void *pvAddonUserData[IFX_RTP_MAX_ADD_ON]; /*!< User data for Addons*/

   void *pvAddonProcAidData[IFX_RTP_MAX_ADD_ON]; /*!< Proc Aid data for Addons*/

   uint32 uiSessOwner;/*!< The Session that created the Connection */

   uint8 ucOwnerCount;
  
   uint16 unBaseSeqNum;

   uint32 uiLastHighSeqNo;
   
   int32 iTransitTime;
  
   int32 iTSOffset;

   uint8 ucFractionLost;

   int32 iCumPacketsLost;

   uint16 unSeqNoRoc;
   
   uint16 unHighSeqNo;

   uint32 uiInterArrJitter;

   uint32 uiPoCSessId;   

} x_IFX_RTP_ConnInfo;

typedef struct
{
  x_IFX_RTP_ConnInfo *pxConn; /*!< Pointer to connection node*/

}x_IFX_RTP_ConnList;

/* Session info */

typedef struct
{
   /* Session Number */
   //uchar8 ucSessNo;

   /* Session Close Flags */
   int iFlags;

   /* Sender SSRC for the session */
   uint32 uiTxSSRC;

   /* TBD config Sender Source Description */
    x_IFX_RTCP_SdesItems xTxSrcDesc;

   /* No. of members in the last interval */
   uint8 ucPrevMembers;

   /* No. of members */
   uint8 ucMembers;

   /* Member List */
   x_IFX_RTP_MemberList xMemberList;

   /* No. of Active senders */
   uint8 ucSenders;

   /* Sender List */
   x_IFX_RTP_SenderList xSenderList;
   
   /* RTCP Bandwidth in bytes/s
   * Bandwidth shall be calculated or 
   * shall be sent from the User application 
   * This is 1/4th of the Session Bandwidth sent by UA
   */
   double64 diRtcpBw;

   /* Average RTCP Pkt Size */
   double64 diAvgRtcpPktSize;

   /* We Sent Flag */
   uchar8 ucWeSent;

   uint8 ucItemCnt;

   /* Number of Connections in the ongoing Session */
   uchar8 ucNoConns;

   /* Connection List Head Node */
   x_IFX_RTP_ConnList *pxConnListHeadPtr;

   /*TBD to make it a list*/
   uint32 auiCsrcList[IFX_RTP_MAX_CSRC];

   /* Local address */
   uint32 uiLocalIpAddr;
   
   /* Local Rtcp address */
   uint32 uiLocalRtcpIpAddr;
   
   uchar8 ucIsRtpEnable; /*!< Rtp Enable*/
   uchar8 ucIsRtcpEnable; /*!< Rtcp Enable*/
   uchar8 ucIntRtcpStatCalc; /* Internal RTCP statistics calculations */
   uchar8 ucNoOfAddOnReg;

} x_IFX_RTP_Session;

/*! /struct x_IFX_RTP_TimerInfo
    /brief A Structure to be passed as the callback param for timers
*/
typedef struct
{
  x_IFX_RTP_ConnInfo *pxConn; /*!< Session pointer*/
  uchar8 ucPktType; /*!< Packet Type*/
}x_IFX_RTP_Timer;

EXTERN x_IFX_RTP_Session *vpxRtpSessHeadPtr;
EXTERN x_IFX_RTP_ConnInfo *vpxRtpConnHeadPtr;
EXTERN uchar8 vcRtpModId;

EXTERN int8 IFX_RTP_DB_SetRxSdes(IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN char8 *pcRxPkt );

EXTERN void IFX_RTP_DB_SetSdesItem(IN x_IFX_RTP_Session *pxSess,
                                   IN e_IFX_RTCP_SDES_Item eSdesItem,
                                   IN char8 *pcSdesItemValue);


EXTERN void IFX_RTP_DB_GetSdesItem(IN x_IFX_RTCP_SdesItems *pxSdesSrc,
                                   IN e_IFX_RTCP_SDES_Item eSdesItem,
                                   OUT x_IFX_RTCP_SdesItems *pxSdesDst);

/* List Operations */
EXTERN char8 IFX_RTP_DB_AddToMemberList(IN x_IFX_RTP_Session *pxSess,
                                        IN uint32 uiSsrc );

EXTERN char8 IFX_RTP_DB_AddToSenderList(IN x_IFX_RTP_Session *pxSess,
                                        IN uint32 uiSsrc );

EXTERN char8 IFX_RTP_DB_DeleteFromMemberList(IN x_IFX_RTP_Session *pxSess,
                                             IN uint32 uiSsrc );

EXTERN char8 IFX_RTP_DB_DeleteFromSenderList(IN x_IFX_RTP_Session *pxSess,
                                             IN uint32 uiSsrc );
#if 0
EXTERN  void IFX_RTP_DB_SetConnAddr(IN x_IFX_RTP_Session *pxSess,
                                    IN x_IFX_RTP_ConnInfo *pxConn,
				    IN x_IFX_RTP_ConnInfo *pxNewAddr );
#endif
EXTERN void IFX_RTP_DB_MemsetSessConnAddr(IN x_IFX_RTP_Session *pxSess,
                                          IN x_IFX_RTP_ConnInfo *pxConn);

EXTERN void IFX_RTP_DB_SetSdesItems(IN x_IFX_RTP_Session *pxSess);

EXTERN uint32 IFX_RTP_CreateSessNode();

EXTERN uint32 IFX_RTP_AddConnToSess(
                            IN x_IFX_RTP_Session *pxRtpSessPtr,
                            IN x_IFX_RTP_ConnInfo *pxRtpConnPtr);

EXTERN uint32 IFX_RTP_RemoveConnFromSess(
                            IN x_IFX_RTP_Session *pxRtpSessPtr,
                            IN x_IFX_RTP_ConnInfo *pxRtpConnPtr);

EXTERN uint32 IFX_RTP_RemoveSess(IN x_IFX_RTP_Session *pxRtpSessPtr);
#endif /* __IFX_RTP_DB_H__ */
