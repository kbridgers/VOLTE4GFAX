/**************************************************************************
 **   FILE NAME       : ifin_rtp_timerIface.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : RTP/RTCP Stack 
 **   SRC VERSION     : V0.1
 **   DATE            : 01-03-2004
 **   AUTHOR          : Hari 
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_RTP_TIMERIFACE_H__
#define __IFX_RTP_TIMERIFACE_H__

#define PRINT printf

#define  IFX_RTP_MAX_TIMERS   5
#define  IFX_RTP_TIMER_PERMS  0666

typedef struct
{
   char8 cIsFree;
   uint16 unTimerId;
   void  ( *pfnCallBackFn )( void * );
   void *pCallBackFnParam;
#ifdef __IMSENV__
  void* pvTimerId;
#endif
} x_IFX_RTP_TimerInfo;


EXTERN int8 IFX_RTP_GetTimerFromList( OUT x_IFX_RTP_TimerInfo **pxTimerInfo );
EXTERN void IFX_RTP_TimeOutHandler( x_IFX_RTP_TimerInfo * );
EXTERN int8 IFX_RTP_TimerInit( void );
EXTERN int8 IFX_RTP_TimerDelete( void );
EXTERN int8 IFX_RTP_StartTimer( IN uint32 uiTimeOutValue, /* milli seconds */
                               IN void *pfn_IFX_RTP_CallBackFn,
   IN void *pCallBackFnParam, OUT uint16 *punTimerId, OUT uint32 *peEcode );
EXTERN int8 IFX_RTP_StopTimer( IN uint16  unTimerId );
EXTERN int8 IFX_RTP_GetTimerFromList( OUT x_IFX_RTP_TimerInfo **pxTimerInfo );
EXTERN int8 IFX_RTP_TimerDelete( void );
EXTERN void IFX_RTP_ProcessTimerMsg( void *pTimerInfo );
EXTERN int8 IFX_RTP_DeleteTimerFromList( IN uint16 unTimerId );

#endif /* __IFX_RTP_TIMERIFACE_H__ */
