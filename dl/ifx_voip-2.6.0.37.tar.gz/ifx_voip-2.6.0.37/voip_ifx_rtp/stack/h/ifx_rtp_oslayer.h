/**************************************************************************
 **   FILE NAME       : ifx_rtp_oslayer.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : RTP/RTCP module
 **   SRC VERSION     : V0.1
 **   DATE            : 09-03-2004
 **   AUTHOR          : Hari 
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_RTP_OSLAYER_H__
#define __IFX_RTP_OSLAYER_H__

#ifdef __IMSENV__

#include "ifx_mmb_env.h"
#include "mmb_timer_lh.h"
#include "mmb_sock_lh.h"
#include "mmb_ipstack_lh.h"
#endif 

#ifdef __LINUX__
#include <pthread.h>
#include <sys/times.h>
#include <errno.h>
#include <malloc.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <sys/select.h>
#include <sys/time.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include "IFX_TLIB_Interface_Import.h"
#include <sys/sem.h>
#endif /*__LINUX__*/ 

#define MIN(A,B) ( (A) < (B) ? (A) : (B) )
#define MAX(A,B) ( (A) > (B) ? (A) : (B) )

/* MD5 context */
typedef struct
{
  uint32 state[4];        /* state (ABCD) */
  uint32 count[2];        /* number of bits, modulo 2^64 (lsb first) */
  uchar8 buffer[64];      /* input buffer */
} MD_CT;

typedef struct {
  uint32 uiIP; 
  int32 iPort;
}x_IFX_RTP_PacketSourceInfo;

#ifdef THREAD_SAFE
#ifdef __LINUX__
typedef  pthread_t x_IFX_RTP_ThreadId;
#endif
#ifdef __IMSENV__
typedef  int  x_IFX_RTP_ThreadId;
#endif
#ifdef __IMSENV__
typedef T_Mmb_HMutex x_IFX_RTP_LockType;
#else
typedef int32 x_IFX_RTP_LockType;
#endif

typedef union
{
  int32 val;
  struct semid_ds *buff;
  uint16 *array;
} ux_IFX_RTP_SEMUN;

typedef struct
{
  x_IFX_RTP_LockType xSemID;
  uint32 uiSess;
  x_IFX_RTP_ThreadId xThrdID;
} x_IFX_RTP_MutexTable;

typedef enum
{
  IFX_RTP_MUTEX_INIT,
  IFX_RTP_MUTEX_ALLOC,
  IFX_RTP_MUTEX_FREE,
  IFX_RTP_MUTEX_ACQUIRE_LIST,
  IFX_RTP_MUTEX_RELEASE_LIST,
  IFX_RTP_MUTEX_ACQUIRE_SESSION,
  IFX_RTP_MUTEX_RELEASE_SESSION,
  IFX_RTP_MUTEX_ACQUIRE_ALL_SESSIONS,
  IFX_RTP_MUTEX_RELEASE_ALL_SESSIONS,
} e_IFX_RTP_MutexAction;

char8 IFX_RTP_MutexAction(e_IFX_RTP_MutexAction eActionType, uint32 uiSess);

#endif

int32 IFX_RTP_CreateThread( void * (*start_routine)(void *));

/********** Memory Operations **********/
#ifndef USE_IFIN_MLIB
#define IFX_RTP_MLibInit(unMaxSegSize) IFX_RTP_SUCCESS
#define IFX_RTP_Malloc(iSize)          calloc(1, iSize) /* malloc(iSize) */
#define IFX_RTP_Calloc(iSize)          calloc(1, iSize)
#define IFX_RTP_Free(pcFree)           (free(pcFree),IFX_RTP_SUCCESS)
#endif
/********** Socket Operations **********/
#ifdef __LINUX__

typedef fd_set IFX_RTP_fd_set;

#define IFX_RTP_AF_INET AF_INET
#define IFX_RTP_inet_pton(af,src,dst) inet_pton(af,src,dst)
#define IFX_RTP_inet_ntop(af,src,dst,cnt) inet_ntop(af,src,dst,cnt)
#define IFX_RTP_GetHostByName(cname,length) gethostname(cname,length)

#define IFX_RTP_Htons(unNum) htons(unNum)
#define IFX_RTP_Htonl(uiNum) htonl(uiNum)
#define IFX_RTP_Ntohs(unLen) ntohs(unLen)
#define IFX_RTP_Ntohl(uiLen) ntohl(uiLen)

#define IFX_RTP_FdZero(pFdSet) FD_ZERO(pFdSet)

#define IFX_RTP_FdClear(iFd, pFdSet) FD_CLR(iFd, pFdSet)

#define IFX_RTP_FdSet(iFd, pFdSet) FD_SET(iFd, pFdSet)

#define IFX_RTP_FdIsSet(iFd, pFdSet) FD_ISSET(iFd, pFdSet)

#define IFX_RTP_Read(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

#define IFX_RTP_Write(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)

#define IFX_RTP_Close(Fd) close(Fd)

/***********************Thread**********************/
#define IFX_RTP_ThreadExit(pRet)  pthread_exit(pRet);
#define IFX_RTP_GetThreadID(piThreadId)   *piThreadId =pthread_self();
#endif 

#ifdef __IMSENV__

typedef IFX_SOCK_FD_SET IFX_RTP_fd_set;
#define IFX_RTP_inet_pton(af,src,dst) inet_pton(af,src,dst);
#define IFX_RTP_inet_ntop(af,src,dst,cnt) inet_ntop(af,src,dst,cnt);

#define IFX_RTP_Htons(unNum) Mmb_htons(unNum)
#define IFX_RTP_Htonl(uiNum) Mmb_htonl(uiNum)
#define IFX_RTP_Ntohs(unLen) Mmb_ntohs(unLen)
#define IFX_RTP_Ntohl(uiLen) Mmb_ntohl(uiLen)

#define IFX_RTP_FdZero(pFdSet) IFX_FD_ZERO(pFdSet)


void IFX_RTP_FdSet(int32 iFd, T_Mmb_SIfxSockFdSet* pFdSet);

void IFX_RTP_FdClear(int32 iFd, T_Mmb_SIfxSockFdSet* pFdSet);


T_Mmb_Int8 IFX_RTP_FdIsSet(int32 iFd, T_Mmb_SIfxSockFdSet* pFdSet);

void IFX_RTP_ThreadExit(int pRet);
#ifdef __IMSENV__
int32 IFX_RTP_Close(int32 Fd); 
#endif
#define IFX_RTP_AF_INET IFX_SOCK_AF_INET

IFX_RTP_GetHostByName(char8 *pcName, int32 iLength);
#define IFX_RTP_GetThreadID(piThreadId) Mmb_GetCurrentThreadID(piThreadId)

#endif 


/********** Memory Operations **********/
#define memset(pvDst, iChar, uiSize) memset(pvDst, iChar, uiSize)

#define memcpy(pvDst, pvSrc, uiSize) memcpy(pvDst, pvSrc, uiSize)

#define memcmp(pPtr1,pPtr2,uiSize) memcmp(pPtr1,pPtr2,uiSize)

#define memmove(pvDst,pvSrc,nBytes) memmove(pvDst,pvSrc,nBytes)

/********** String Operations **********/
#define strlen(pcPtr) strlen(pcPtr)

#define strcpy(pcDst,pcSrc) strcpy(pcDst,pcSrc)

#define strncpy(pcDst,pcSrc,nBytes) strncpy(pcDst,pcSrc,nBytes)
#define strcat(pcDst,pcSrc) strcat(pcDst,pcSrc)
#define strncat(pcDst,pcSrc,nBytes) strncat(pcDst,pcSrc,nBytes)
#define puts(pcString) puts(pcString)


/* Macros */
#if PROTOTYPES
   #define PROTO_LIST(list) list
#else
   #define PROTO_LIST(list) ()
#endif


/* Constants for MD5Transform routine. */

#define S11 7
#define S12 12
#define S13 17
#define S14 22
#define S21 5
#define S22 9
#define S23 14
#define S24 20
#define S31 4
#define S32 11
#define S33 16
#define S34 23
#define S41 6
#define S42 10
#define S43 15
#define S44 21

/* F, G, H and I are basic MD5 functions.  */

#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/* ROTATE_LEFT rotates x left n bits. */

#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))


/*
 * FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
 * Rotation is separate from addition to prevent recomputation.
 */

#define FF(a, b, c, d, x, s, ac) { (a) += F ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s)); (a) += (b); \
}

#define GG(a, b, c, d, x, s, ac) { (a) += G ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s));  (a) += (b); \
 }

#define HH(a, b, c, d, x, s, ac) { (a) += H ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s));  (a) += (b); \
 }

#define II(a, b, c, d, x, s, ac) { (a) += I ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s)); (a) += (b); \
}


typedef uchar8 *POINTER;


EXTERN int8 IFX_RTP_OpenUdpSocket( int32 *piSockFd,char8 *pcLocalIp,
                                   uint16 unLocalPort );

EXTERN int8 IFX_RTP_CloseSocket( int32 iSockFd, IFX_RTP_fd_set *pRdSelectFd );

EXTERN int32 IFX_RTP_RecvNwPkt( int32 iSockFd, char8 *pcBuffer, int32 iMsgLen,
    x_IFX_RTP_PacketSourceInfo *pxRemoteAddr );

EXTERN int8 IFX_RTP_SendToNw( int32 iSockFd, char8 *pcBuffer, int32 iMsgLen,
   uint32 uiRemoteIP, int16 nRemotePort );

EXTERN int8 IFX_RTP_GetTimeOfDay( long32 *plSeconds, long32 *plUseconds );

EXTERN uint32 IFX_MD5_GetRandomValue( void );

EXTERN int32 IFX_RTP_GetHostInfo( char8 *pc_Hostip );

EXTERN double32 IFX_RTP_GetDecimal( IN long32 lNum );

EXTERN int32 IFX_RTP_Select( int32 i,IFX_RTP_fd_set *pxReadFds,
                             IFX_RTP_fd_set *pxWriteFds,
                             IFX_RTP_fd_set *pxExceptFds, int32 iTimeSec);
#ifdef THREAD_SAFE
EXTERN int32 IFX_RTP_LockAcquire(x_IFX_RTP_LockType xSemId);

EXTERN int32 IFX_RTP_LockRelease(x_IFX_RTP_LockType xSemId);

EXTERN int32 IFX_RTP_LockCreate(x_IFX_RTP_LockType *pxSemId);

EXTERN int32 IFX_RTP_LockDestroy(x_IFX_RTP_LockType *pxSemId);
#endif
#endif /* __IFX_RTP_OSLAYER_H__ */
