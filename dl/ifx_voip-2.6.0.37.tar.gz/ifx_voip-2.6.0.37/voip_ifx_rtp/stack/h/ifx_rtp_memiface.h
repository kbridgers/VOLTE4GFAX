/**************************************************************************
 **   FILE NAME       : ifx_rtp_memiface.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : RTP/RTCP Database module 
 **   SRC VERSION     : V0.1
 **   DATE            : 01-03-2004
 **   AUTHOR          : Hari 
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_RTP_MEMIFACE_H__
#define __IFX_RTP_MEMIFACE_H__

#define IFX_RTP_MEM_LIB_KEY 20

#ifdef USE_IFIN_MLIB
EXTERN  int8 IFX_RTP_MLibInit(uint16 unMaxSegSize);
EXTERN char8 *IFX_RTP_Malloc( int32 iSize );
EXTERN void *IFX_RTP_Calloc( int32 iSize );
EXTERN uint32 IFX_RTP_Free( void *pcFree );
EXTERN void IFX_RTP_MemInfo();
#endif
#endif /* __IFX_RTP_MEMIFACE_H__  */
