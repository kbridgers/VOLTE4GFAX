/**************************************************************************
 **   FILE NAME   : IFX_RTP_TimerInterface.c
 **   PROJECT     : RTP/RTCP 
 **   MODULES     : RTP/RTCP Stack 
 **   SRC VERSION : V1.0
 **
 **   DATE        : 02-03-2004
 **   AUTHOR      : Hari 
 **   DESCRIPTION :
 **   FUNCTIONS   :
 **   COMPILER    :
 **   REFERENCE   : 
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "ifx_rtp_oslayer.h"
#include "ifx_rtp_timeriface.h"

#include "ifx_debug.h"
EXTERN int8 vcRtpModId;

EXTERN int16 IFX_RTP_WriteRtcpInfo( void );


x_IFX_RTP_TimerInfo axTimerList[IFX_RTP_MAX_TIMERS];
/******************************************************************
*  Function Name  :  IFX_RTP_TimerInit
*  Description    :  Initialises the Timer Interface 
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAILURE 
*  Notes          :
*********************************************************************/
PUBLIC int8 IFX_RTP_TimerInit( void )
{
#ifdef __IMSENV__
  T_Mmb_HTimer hTimer = NULL;
#endif
   uchar8 iCount;
#ifdef __LINUX__
   if(IFX_TLIB_TimersInit(IFX_RTP_MAX_TIMERS) == -1){
      return IFX_RTP_FAIL;
   }
#endif
   /* Initialize the Timer List */
   for( iCount = 0; iCount < IFX_RTP_MAX_TIMERS; iCount++ )
   {
      axTimerList[iCount].cIsFree = 'y';
#ifdef __IMSENV__
      if(Mmb_TimerCreate(&hTimer) != e_Mmb_ErrOk){
        return IFX_RTP_FAIL;
      }
      axTimerList[iCount].pvTimerId = hTimer;
#endif      
   }
   return IFX_RTP_SUCCESS;
}


/******************************************************************
*  Function Name  :  IFX_RTP_TimerDelete
*  Description    :  Clears all Timer Interface 
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAILURE 
*  Notes          :
 * *********************************************************************/
PUBLIC int8 IFX_RTP_TimerDelete( void )
{
#ifdef __LINUX__
   IFX_TLIB_TimersDelete();
#endif
#ifdef __IMSENV__
   int32 iCount=0;
  /* Initialize the Timer List */
  for( iCount = 0; iCount < IFX_RTP_MAX_TIMERS; iCount++ )
  {
                              
     axTimerList[iCount].cIsFree = 'y';
     Mmb_TimerDestroy(&axTimerList[iCount].pvTimerId);
     axTimerList[iCount].pvTimerId = NULL;
  }
#endif   
   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_RTP_StartTimer
*  Description    :  This function starts a timer 
*  Input Values   :  uiTimeOutValue, pfn_IFX_RTP_CallBackFn,
*                 :  pCallBackFnParam 
*                 :  uiTimeOutValue = Timer Duration
*                 :  pfn_IFX_RTP_CallBackFn = Timer Callback
*                 :  pCallBackFnParam = Timer Callback Param
*  Output Values  :  punTimerId, peEcode 
*                 :  punTimerId = Pointer to Timer Id
*                 :  peEcode = Pointer to Error Code
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAILURE 
*  Notes          : 
*********************************************************************/
PUBLIC int8 IFX_RTP_StartTimer( IN uint32 uiTimeOutValue, /* Milli seconds */
                                IN void *pfn_IFX_RTP_CallBackFn,
                                IN void *pCallBackFnParam,
                                OUT uint16 *punTimerId,
                                OUT uint32 *peEcode )
{
   x_IFX_RTP_TimerInfo *pxTimerInfo;
#ifdef __IMSENV__ 
   uint16 unTempTimerId;
  static short i = 1;
#endif
 
   if( IFX_RTP_GetTimerFromList( &pxTimerInfo ) == IFX_RTP_FAIL )
   {
     IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "<Timer> Timer list exhausted " );
     return IFX_RTP_FAIL;
   }

   /* Construct the Timer Structure */
   pxTimerInfo->pfnCallBackFn = pfn_IFX_RTP_CallBackFn;
   pxTimerInfo->pCallBackFnParam = pCallBackFnParam;
#ifdef __LINUX__   
   /* Convert the Timeout Value from Milliseconds to Microseconds */
   uiTimeOutValue *= 1000;
   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
              "<Timer> Timer Timeout value = ",uiTimeOutValue );

   /* Start the Timer for so many micro seconds */
   if( IFX_TLIB_StartTimer( punTimerId,
                             uiTimeOutValue,
                             IFX_TLIB_ONE_TIME_TIMER,
                             IFX_RTP_ProcessTimerMsg,
                             pxTimerInfo ) == IFX_TLIB_FAIL)
   {
     IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "<Timer> Start Timer Failed " );
      return IFX_RTP_FAIL;
   }
#elif __IMSENV__
  Mmb_TimerStartAsync((T_Mmb_HTimer)pxTimerInfo->pvTimerId,
                      (T_Mmb_StandardCallback)IFX_RTP_ProcessTimerMsg,
                      (T_Mmb_UserData)pxTimerInfo,uiTimeOutValue);
  unTempTimerId = i++;
  /* 
  Mmb_TimerStartAsync(hThis,(T_Mmb_StandardCallback)IFX_RTP_ProcessTimerMsg,
                (T_Mmb_UserData)pxTimerInfo,uiTimeOutValue);
  pxTimerInfo->pvTimerId = hThis;
  unTempTimerId = i++;*/
#endif
   /* Store the Timer id */
   pxTimerInfo->unTimerId = *punTimerId;
   IFX_DBGC(vcRtpModId, IFX_DBG_LVL_LOW, IFX_DBG_RTP_STR_PRINT,
            "start Timer Value", *punTimerId);
   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_RTP_StopTimer
*  Description    :  This function stops a timer 
*  Input Values   :  Timer Id 
*  Output Values  :  None 
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC int8 IFX_RTP_StopTimer( IN uint16 unTimerId )
{
#ifdef __IMSENV__
  int32 iCount;
  /*Locate the timer Info */
   for (iCount = 0; iCount < IFX_RTP_MAX_TIMERS; iCount++) {
      if (axTimerList[iCount].unTimerId == unTimerId) {
        break;
	  }
   }
   if(iCount == IFX_RTP_MAX_TIMERS){
     return IFX_RTP_FAIL;
   }
   Mmb_TimerStop(((T_Mmb_HTimer )axTimerList[iCount].pvTimerId));
   
   /*Mmb_TimerDestroy(&((T_Mmb_HTimer *)axTimerList[iCount].pvTimerId));*/
#elif __LINUX__
	if(unTimerId == 0){
		return IFX_RTP_SUCCESS;
	}
   if( IFX_TLIB_StopTimer( unTimerId ) == IFX_TLIB_FAIL )
   {
	   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "<Timer> Stop Timer Failed " );
      return IFX_RTP_FAIL;
   }
	IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
              "<Timer> stop timer " );
#endif
   /* Delete Timer info structure from the list */
   if( IFX_RTP_DeleteTimerFromList( unTimerId ) == IFX_RTP_FAIL )
   {
	   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_PRINT,
                "<Timer> No Timer with ID ",unTimerId );
   }
   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_RTP_ProcessTimerMsg
*  Description    :  This function Processes the timer info 
*                 :  message from the Fifo
*  Input Values   :  pTimerInfo - Timer Info
*  Output Values  :  None
*  Return Value   :  None
*  Notes          : 
*********************************************************************/
PUBLIC void IFX_RTP_ProcessTimerMsg( void *pTimerInfo )
{
   x_IFX_RTP_TimerInfo *pxTimerInfo = ( x_IFX_RTP_TimerInfo * ) pTimerInfo;

   /* Delete the timerinfo from the list */
   pxTimerInfo->cIsFree = 'y';
   pxTimerInfo->unTimerId = 0;
   /* call the function along with the parameters */
   pxTimerInfo->pfnCallBackFn( pxTimerInfo->pCallBackFnParam );
   return;
}

/******************************************************************
*  Function Name  :  IFX_RTP_DeleteTimerFromList
*  Description    :  This function deletes a timer from the list 
*  Input Values   :  Timer Id 
*  Output Values  :  None
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC int8 IFX_RTP_DeleteTimerFromList( IN uint16 unTimerId )
{
   uchar8 iCount;
   for( iCount = 0; iCount < IFX_RTP_MAX_TIMERS; iCount++ )
   {
      if( axTimerList[iCount].unTimerId == unTimerId )
      {
         axTimerList[iCount].cIsFree = 'y';
         axTimerList[iCount].unTimerId = 0;
         return IFX_RTP_SUCCESS;
      }
   }
   return IFX_RTP_FAIL;
}

/******************************************************************
*  Function Name  :  IFX_RTP_GetTimerFromList
*  Description    :  This function Gets a timer from the list 
*  Input Values   :  None
*  Output Values  :  pxTimerInfo
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAILURE 
*  Notes          : 
*********************************************************************/
PUBLIC int8 IFX_RTP_GetTimerFromList( OUT x_IFX_RTP_TimerInfo **pxTimerInfo )
{
   uchar8 iCount;

   for( iCount = 0; iCount < IFX_RTP_MAX_TIMERS; iCount++ )
   {
      if( axTimerList[iCount].cIsFree == 'y' )
      {
         axTimerList[iCount].cIsFree = 'n';
         *pxTimerInfo = &axTimerList[iCount];
         return IFX_RTP_SUCCESS;
      }
   }
   return IFX_RTP_FAIL;
}

