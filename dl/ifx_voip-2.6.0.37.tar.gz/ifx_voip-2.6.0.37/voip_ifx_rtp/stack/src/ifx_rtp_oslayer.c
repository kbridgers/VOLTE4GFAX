/**************************************************************************
 **   FILE NAME       : ifx_rtp_oslayer.c
 **   PROJECT         : RTP/RTCP
 **   MODULES         : OS Layer module
 **   SRC VERSION     : V0.1 
 **   DATE            : 01-03-2004
 **   AUTHOR          : Bharathraj Shetty 
 **   DESCRIPTION     : 
 **   FUNCTIONS       :  
 **   COMPILER        : gcc, monta vista linux 
 **   REFERENCE       : Coding guide lines for VSS ,  
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       Revision history
***********************************************************************/ 
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "ifx_rtp_oslayer.h"
#include "ifx_debug.h"

#ifdef __IMSENV__
#ifndef __IMSCORE__
extern T_Mmb_HIpStack hThis;
#else
#include "mmb_component_container_lh.h"
#include "mmb_ipstack_lh.h"
#include "mmb_error_ph.h"
#include "mmb_datetime_ph.h"
#endif
#endif

#ifdef __IMSENV__
static T_Mmb_HThread hRtpThread = NULL;
#endif 
/*Extern DEclaration*/
extern char8 vcRtpModId;

/* STATIC Functions */
STATIC void Encode PROTO_LIST((uchar8 *, uint32  *, uint32));
STATIC void Decode PROTO_LIST((uint32 *, uchar8 *, uint32));
STATIC void MD_memcpy (POINTER output, POINTER input,uint32 len);
STATIC void MD_memcpy PROTO_LIST ((POINTER, POINTER, uint32));
STATIC void MD_memset PROTO_LIST ((POINTER, int32, uint32));

/* STATIC Variables */

STATIC uchar8 PADDING[64] =
{
  0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/******************************************************************
*  Function Name  :  IFX_RTP_OpenUdpSocket
*  Description    :  opens a socket and binds to the local address
*  Input Values      :  nLocalPort
*  Output Values  :     pSockFd
*  Return Value      :  0/-1 
*  Notes    :
*********************************************************************/
PUBLIC int8 IFX_RTP_OpenUdpSocket( OUT int32 *piSockFd,IN char8 *pcLoaclIP,
                                   IN uint16 unLocalPort )
{
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_HString hString = NULLP;
  T_Mmb_UInt32 iTemp = 1;
  T_Mmb_Error eType;
  T_Mmb_SocketAddrFamily eIp4SockFamily = IFX_SOCK_AF_INET;
  T_Mmb_SocketType eUdpSock = IFX_SOCK_DGRAM;
  T_Mmb_SocketOptionsLevel eBsdsock = e_SOCK_BSD_SOL_SOCKET;
  T_Mmb_SocketOptions eSockOption = e_SOCK_BSD_SO_REUSEADDR;
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetHandle(&hHandle))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
    return IFX_RTP_FAIL;
  }    
#endif 
  if(e_Mmb_ErrOk != Mmb_IpStackSocket(hThis, eIp4SockFamily, eUdpSock, IFX_SOCK_IPPROTO_UDP, &hSock ))
  {
    return IFX_RTP_FAIL;
  }
  *piSockFd = (int32)hSock;
  if(e_Mmb_ErrOk != Mmb_IpStackSetSockOpt(hSock,e_SOCK_BSD_SOL_SOCKET,e_SOCK_BSD_SO_REUSEADDR,&iTemp,sizeof( iTemp )))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_StringCreateFromAscii(pcLoaclIP, &hString))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_IpStackBind(hSock, hString, unLocalPort))
  {
    return IFX_RTP_FAIL;
  }
  Mmb_StringDestroy(&hString);
#endif 
#ifdef __LINUX__
  struct sockaddr_in xLocalSockAddr;
  int32 itemp = 1;
  /* open a udp socket */
  *piSockFd = socket(IFX_RTP_AF_INET,SOCK_DGRAM,0 );
   
   /* construct the local addr structure */
   xLocalSockAddr.sin_family = AF_INET;
   /* Code need to be addedto make use of loacl ip*/
   xLocalSockAddr.sin_addr.s_addr = IFX_RTP_Htonl( INADDR_ANY );
   xLocalSockAddr.sin_port = IFX_RTP_Htons( unLocalPort );

   setsockopt( *piSockFd,SOL_SOCKET,SO_REUSEADDR,&itemp,sizeof( itemp ) );
   /* bind the socket to the local machine */
   if( bind( *piSockFd,( struct sockaddr * ) &xLocalSockAddr,
          sizeof( struct sockaddr_in ) ) < 0 )
   {
      perror( "bind failed \n" );
      return IFX_RTP_FAIL;
   }
#endif 

   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_RTP_CloseUdpSocket
*  Description    :  Close a socket
*  Input Values      :  iSockFd, pRdSelectFd
*  Output Values  :  void
*  Return Value      :  void
*  Notes    :
*********************************************************************/
PUBLIC int8 IFX_RTP_CloseSocket( IN int32 iSockFd, IN IFX_RTP_fd_set *pRdSelectFd )
{
#ifdef __IMSENV__        
   /* Delete the socket FD from the global FDSET */
  T_Mmb_HIfxSocket hSock = NULLP;
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis;
  
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetHandle(&hHandle))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
    return IFX_RTP_FAIL;
  }
#endif
  if(iSockFd)
  {
    IFX_RTP_FdClear( iSockFd,pRdSelectFd );
    /* Delete the socket FD from the global FDSET */
    if(e_Mmb_ErrOk != Mmb_IpStackCloseSocket(hThis, (T_Mmb_HIfxSocket) iSockFd))
    {
      return IFX_RTP_FAIL;
    }
  }
#endif
#ifdef __LINUX__
  IFX_RTP_FdClear( iSockFd,pRdSelectFd );
  IFX_RTP_Close( iSockFd );
#endif
  return IFX_RTP_SUCCESS;
}
/*******************************************************************************
*  Function Name :  IFX_RTP_RecvNwPkt
*  Description   :  Function to receive RTP/RTCP pkt
*  Input Values  :  iSockFd over which to receive,pcBuffer,
*  					iMsgLen , pxRemoteAddr
*  Output Values : x_IFX_RTP_: Packet source IP and port
*  Return Value  : iBufLen
*  Notes         : 
*******************************************************************************/
PUBLIC int32   IFX_RTP_RecvNwPkt( int32 iSockFd, char8 *pcBuffer,int32 iMsgLen, x_IFX_RTP_PacketSourceInfo *pxRemoteAddr )
{
  uint32 iAddrLen = 0, iBuffLen = 0;
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_UInt32 iRecvLen;
  T_Mmb_UInt16 iPort;
  T_Mmb_Error eType;
  T_Mmb_HString hPeerAddress = NULLP;
  T_Mmb_UInt32 uiNumber;
  char ip_addr[64];
#ifdef __IMSCORE__
 T_Mmb_HComponentContainer hHandle = NULLP;
 T_Mmb_HIpStack hThis = NULLP;
 
 if(e_Mmb_ErrOk != Mmb_ComponentContainerGetHandle(&hHandle))
 {
   return IFX_RTP_FAIL;
 }
 if(e_Mmb_ErrOk != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
 {
   return IFX_RTP_FAIL;
 }
#endif
 /* Delete the socket FD from the global FDSET */
  if(e_Mmb_ErrOk != Mmb_IpStackRecvFrom((T_Mmb_HIfxSocket)iSockFd, 0, iMsgLen, pcBuffer, &iRecvLen,	
  &hPeerAddress, &iPort))
  {
    return IFX_RTP_FAIL;
  }  
  iBuffLen = iRecvLen;
  if(e_Mmb_ErrOk != Mmb_StringConvertStringToAscii(hPeerAddress,ip_addr))
  {
    return IFX_RTP_FAIL;
  }
  inet_pton(IFX_SOCK_AF_INET,ip_addr, &pxRemoteAddr->uiIP);
  pxRemoteAddr->uiIP = pxRemoteAddr->uiIP;
  pxRemoteAddr->iPort = iPort;
  Mmb_StringDestroy(&hPeerAddress);  
#endif 
#ifdef __LINUX__
   struct sockaddr_in xRemoteAddr;
   /*   struct sockaddr_in xRemoteAddr;*/

   /* initialize the global buffer to store the message */
   iAddrLen = sizeof( struct sockaddr_in );
	 memset(&xRemoteAddr,0,iAddrLen);
   iBuffLen = recvfrom( iSockFd,pcBuffer,iMsgLen,0,
                 (struct sockaddr*)&xRemoteAddr,&iAddrLen );
   /*copy data from sockaddr to packetsource info*/
  pxRemoteAddr->uiIP = xRemoteAddr.sin_addr.s_addr;
  pxRemoteAddr->iPort = ntohs(xRemoteAddr.sin_port);
#endif 
  return iBuffLen;
}

/******************************************************************
*  Function Name  :  IFX_RTP_SendToNw
*  Description    :  sends packet to the specified remote address
*  Input Values      :  iSockFd,pcBuffer,iMsgLen,pcRemoteIp,nRemotePort
*  Output Values  :  void
*  Return Value      :  success/fail
*  Notes    : 
*********************************************************************/
PUBLIC int8 IFX_RTP_SendToNw( IN int32 iSockFd, IN char8 *pcBuffer,
   IN int32 iMsgLen, IN uint32 uiRemoteIp, IN int16 nRemotePort )
{
	if(uiRemoteIp == 0){
		return IFX_SUCCESS;
	}
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_HString hString = NULLP;
  T_Mmb_UInt32 iLength;
  char acTemp[16] = {'\0'};
  uiRemoteIp = Mmb_ntohl(uiRemoteIp);
  sprintf(acTemp,"%d.%d.%d.%d",(uiRemoteIp >> 24),
  ((uiRemoteIp>>16)&0xff),((uiRemoteIp>>8)&0xff),
  (uiRemoteIp&0xff));
  
  if(e_Mmb_ErrOk != Mmb_StringCreateFromAscii(acTemp, &hString))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_IpStackSendTo((T_Mmb_HIfxSocket)iSockFd, hString, nRemotePort, pcBuffer, iMsgLen, 0, &iLength))
  {
    Mmb_StringDestroy(&hString);  
    return IFX_RTP_FAIL;
  }
  else{
    Mmb_StringDestroy(&hString);  
  }
  if( iLength != iMsgLen)
  {
  return IFX_RTP_FAIL;
  } 
#endif 
#ifdef __LINUX__
   struct sockaddr_in xRemoteAddr;

   memset( &xRemoteAddr,0,sizeof( xRemoteAddr ) );
   /* construct the remote sock addr structure */
   xRemoteAddr.sin_family = AF_INET;
   xRemoteAddr.sin_addr.s_addr = uiRemoteIp;
   xRemoteAddr.sin_port = htons( nRemotePort );
   /* send the message over udp */
   if( sendto( iSockFd,( char * ) pcBuffer,iMsgLen,0,
          ( struct sockaddr * ) &xRemoteAddr,sizeof( xRemoteAddr ) ) !=
      iMsgLen )
   {
      perror( "<OS> Send to failed \n" );
      return IFX_RTP_FAIL;
   }
#endif 
   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name     :  IFX_RTP_GetTimeOfDay
*  Description       :  Get the current time of day
*  Input Values         :  pxGtime
*  Output Values     :  pxGtime
*  Return Value         :  success/fail
*  Notes       :
*********************************************************************/
PUBLIC int8 IFX_RTP_GetTimeOfDay( OUT long32 *plSeconds, 
		OUT long32 *plUseconds )
{
#ifdef __IMSENV__
  T_Mmb_HDatetime hThis;
  T_Mmb_Error err = e_Mmb_ErrOk;
  T_Mmb_UInt32         piHour=0;
  T_Mmb_UInt32         piMinute=0;
  T_Mmb_UInt32         piSecond=0;
  T_Mmb_UInt32         piFraction=0;
  err = Mmb_DatetimeCreate (&hThis);
  if(err != e_Mmb_ErrOk)
	  return IFX_RTP_FAIL;
  err = Mmb_DatetimeGetCurrentTime(hThis);
  if(err != e_Mmb_ErrOk){
	  Mmb_DatetimeDestroy(&hThis);
	  return IFX_RTP_FAIL;
	}
  err = Mmb_DatetimeGetTime(hThis,&piHour,&piMinute, &piSecond,&piFraction);
	*plSeconds = piSecond;
  /* Fraction returns in milliseconds */
  *plUseconds = piFraction*1000;
  Mmb_DatetimeDestroy(&hThis);
    
  /*
  * To be changed because this is not available in APOXI - Ramesh
  struct timeval xGtime;
  if( gettimeofday( &xGtime,NULL ) == -1 )
  {
    return IFX_RTP_FAIL;
  }
  *plSeconds = xGtime.tv_sec;
  *plUseconds = xGtime.tv_usec;
  */
#endif 
#ifdef __LINUX__
  struct timeval xGtime;
	memset(&xGtime,0,sizeof(struct timeval));
  if( gettimeofday( &xGtime,NULL ) == -1 )
  {
    return IFX_RTP_FAIL;
  }
  *plSeconds = xGtime.tv_sec;
  *plUseconds = xGtime.tv_usec;
#endif 
  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name                :  IFX_RTP_GetDecimal
*  Description                  :  This function returns a decimal  
*                               :  for an integer input 
*  Input Values                 :  lNum - Number
*                               :  
*                               : 
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/
PUBLIC double32   IFX_RTP_GetDecimal( IN long32 lNum )
{
   long32 lTempNum = lNum;
   char8 cCnt = 0;
   long lDenominator = 1;

   while( lTempNum )
   {
      cCnt++;
      lTempNum = lTempNum / 10;
   }
   while( cCnt )
   {
      lDenominator = lDenominator * 10;
      cCnt--;
   }
   return ( ( double32 ) lNum / ( double32 ) lDenominator );
}

/******************************************************************
*  Function Name                :  IFX_RTP_GetHostInfo 
*  Description                  :  This function returns Ip address of the host
*                               :  
*  Input Values                 :  lNum - Number
*                               :
*                               :
*  Output Values                :  None
*  Return Value                 :  Decimal Value
*  Notes                        :
*********************************************************************/
int   IFX_RTP_GetHostInfo( char8 *pc_Hostip )
{
  int iRetVal = 0; 
#ifdef __IMSENV__
{
  T_Mmb_UInt16 iConnectionId;
  T_Mmb_ApplicationType eApplication;
  T_Mmb_HString hIPAddress = NULLP; 
  T_Mmb_HLinkProvider hLinkProvider = NULL;
      
  /* Get the IP Address from the link provider */
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hcontainer = NULLP;
  
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetHandle(&hcontainer))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetLinkProvider( hcontainer,&hLinkProvider))
  {
    return IFX_RTP_FAIL;
  }
#endif 
  if(e_Mmb_ErrOk != Mmb_StringCreateNullString(&hIPAddress))
  {
    return IFX_RTP_FAIL;
  }
#ifndef __IMSCORE__ 
  if(e_Mmb_ErrOk != Mmb_LinkProviderCreate(&hLinkProvider))
  {
    return IFX_RTP_FAIL;
  }
#endif 
  eApplication = e_Mmb_ConnectionTypeIms;
  if(e_Mmb_ErrOk != Mmb_LinkProviderGetPrimaryPdpContextId(hLinkProvider,eApplication,&iConnectionId))
  {
    return IFX_RTP_FAIL;
  }    
  if(e_Mmb_ErrOk != Mmb_LinkProviderGetIPAddress(hLinkProvider,iConnectionId,hIPAddress))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_StringConvertStringToAscii(hIPAddress, pc_Hostip))
  {
    return IFX_RTP_FAIL;
  }
}
#endif 
#ifdef __LINUX__
   struct ifreq Interface;
   int Fd;
   struct in_addr *pAddr;

   Fd = socket( AF_INET,SOCK_DGRAM,0 );
   if( Fd < 0 )
   {
      return IFX_RTP_FAIL;
   }
   memset( &Interface,0,sizeof( struct ifreq ) );
   Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;

#if defined(ATA) || defined(AMAZON)
   strcpy( Interface.ifr_ifrn.ifrn_name,"adm1" );
#endif
#ifdef IIP
   strcpy( Interface.ifr_ifrn.ifrn_name,"eth0" );
#endif
   iRetVal = ioctl( Fd,SIOCGIFADDR,&Interface );
   close( Fd );
   if( iRetVal < 0 )
   {
      return IFX_RTP_FAIL;
   }
   Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
   pAddr = ( struct in_addr * ) &Interface.ifr_ifru.ifru_addr.sa_data[2];
   strcpy( pc_Hostip,inet_ntoa( *pAddr ) );
#endif 
   return iRetVal;
}


/******************************************************************
*  Function Name                :  IFX_RTP_Select 
*  Description                  :  Polls on the Provided FD sets
*                               :  
*  Input Values                 : ReadFdSet, WriteFdSet, ExceptionFdset
*                               : Timeout
*                               :
*  Output Values                :  None
*  Return Value                 :  Decimal Value
*  Notes                        :
*********************************************************************/
int IFX_RTP_Select( int i, IFX_RTP_fd_set *pxReadFds, IFX_RTP_fd_set *pxWriteFds, 
                    IFX_RTP_fd_set *pxExceptFds, int32 iTimeSec)
{
#ifdef __IMSENV__
  T_Mmb_UInt32 iNoFds = 0;

  if(e_Mmb_ErrOk != Mmb_IpStackSelect(i, iTimeSec, pxReadFds, pxWriteFds, 
                    pxExceptFds, &iNoFds))
  {
	return IFX_RTP_FAIL;
  }  
  return iNoFds;
#endif 
#ifdef __LINUX__
   struct timeval xTv={0};

   if (iTimeSec != 0){
     xTv.tv_sec = iTimeSec;
     xTv.tv_usec = 0;
   }
  return select( i, pxReadFds, pxWriteFds, pxExceptFds,&xTv);

#endif 
}

/* MD5 Algorithm */
/******************************************************************
*  Function Name                :  Decode
*  Description                  :  MD5 initialization. Begins an MD5 operation,
*                                  writing a new context.
*  Input Values                 :  context
*  Output Values                :  context 
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
MDInit(MD_CT * context)
{
  context->count[0] = context->count[1] = 0;
  /* Load magic initialization constants */

  context->state[0] = 0x67452301;
  context->state[1] = 0xefcdab89;
  context->state[2] = 0x98badcfe;
  context->state[3] = 0x10325476;
}

/******************************************************************
*  Function Name                :  MDTransform
*  Description                  :  MD5 basic transformation. Transforms 
*                                  state based on block.
*  Input Values                 :  state, block 
*  Output Values                :  state
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/

STATIC void
MDTransform (uint32 * state, uchar8 * block)
{
  uint32 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

  Decode (x, block, 64);

  /* Round 1 */
  FF (a, b, c, d, x[ 0], S11, 0xd76aa478); /* 1 */
  FF (d, a, b, c, x[ 1], S12, 0xe8c7b756); /* 2 */
  FF (c, d, a, b, x[ 2], S13, 0x242070db); /* 3 */
  FF (b, c, d, a, x[ 3], S14, 0xc1bdceee); /* 4 */
  FF (a, b, c, d, x[ 4], S11, 0xf57c0faf); /* 5 */
  FF (d, a, b, c, x[ 5], S12, 0x4787c62a); /* 6 */
  FF (c, d, a, b, x[ 6], S13, 0xa8304613); /* 7 */
  FF (b, c, d, a, x[ 7], S14, 0xfd469501); /* 8 */
  FF (a, b, c, d, x[ 8], S11, 0x698098d8); /* 9 */
  FF (d, a, b, c, x[ 9], S12, 0x8b44f7af); /* 10 */
  FF (c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
  FF (b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
  FF (a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
  FF (d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
  FF (c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
  FF (b, c, d, a, x[15], S14, 0x49b40821); /* 16 */

 /* Round 2 */
  GG (a, b, c, d, x[ 1], S21, 0xf61e2562); /* 17 */
  GG (d, a, b, c, x[ 6], S22, 0xc040b340); /* 18 */
  GG (c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
  GG (b, c, d, a, x[ 0], S24, 0xe9b6c7aa); /* 20 */
  GG (a, b, c, d, x[ 5], S21, 0xd62f105d); /* 21 */
  GG (d, a, b, c, x[10], S22,  0x2441453); /* 22 */
  GG (c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
  GG (b, c, d, a, x[ 4], S24, 0xe7d3fbc8); /* 24 */
  GG (a, b, c, d, x[ 9], S21, 0x21e1cde6); /* 25 */
  GG (d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
  GG (c, d, a, b, x[ 3], S23, 0xf4d50d87); /* 27 */
  GG (b, c, d, a, x[ 8], S24, 0x455a14ed); /* 28 */
  GG (a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
  GG (d, a, b, c, x[ 2], S22, 0xfcefa3f8); /* 30 */
  GG (c, d, a, b, x[ 7], S23, 0x676f02d9); /* 31 */
  GG (b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */

  /* Round 3 */
  HH (a, b, c, d, x[ 5], S31, 0xfffa3942); /* 33 */
  HH (d, a, b, c, x[ 8], S32, 0x8771f681); /* 34 */
  HH (c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
  HH (b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
  HH (a, b, c, d, x[ 1], S31, 0xa4beea44); /* 37 */
  HH (d, a, b, c, x[ 4], S32, 0x4bdecfa9); /* 38 */
  HH (c, d, a, b, x[ 7], S33, 0xf6bb4b60); /* 39 */
  HH (b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
  HH (a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
  HH (d, a, b, c, x[ 0], S32, 0xeaa127fa); /* 42 */
  HH (c, d, a, b, x[ 3], S33, 0xd4ef3085); /* 43 */
  HH (b, c, d, a, x[ 6], S34,  0x4881d05); /* 44 */
  HH (a, b, c, d, x[ 9], S31, 0xd9d4d039); /* 45 */
  HH (d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
  HH (c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
  HH (b, c, d, a, x[ 2], S34, 0xc4ac5665); /* 48 */

  /* Round 4 */
  II (a, b, c, d, x[ 0], S41, 0xf4292244); /* 49 */
  II (d, a, b, c, x[ 7], S42, 0x432aff97); /* 50 */
  II (c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
  II (b, c, d, a, x[ 5], S44, 0xfc93a039); /* 52 */
  II (a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
  II (d, a, b, c, x[ 3], S42, 0x8f0ccc92); /* 54 */
  II (c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
  II (b, c, d, a, x[ 1], S44, 0x85845dd1); /* 56 */
  II (a, b, c, d, x[ 8], S41, 0x6fa87e4f); /* 57 */
  II (d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
  II (c, d, a, b, x[ 6], S43, 0xa3014314); /* 59 */
  II (b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
  II (a, b, c, d, x[ 4], S41, 0xf7537e82); /* 61 */
  II (d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
  II (c, d, a, b, x[ 2], S43, 0x2ad7d2bb); /* 63 */
  II (b, c, d, a, x[ 9], S44, 0xeb86d391); /* 64 */

  state[0] += a;
  state[1] += b;
  state[2] += c;
  state[3] += d;


  /* Zeroize sensitive information. */

  MD_memset ((POINTER)x, 0, sizeof (x));
}

/******************************************************************
*  Function Name                :  Decode
*  Description                  :  Encodes input (uchar8) into output (uint32).
*                                  Assumes len is  a multiple of 4
*  Input Values                 :  input, len
*  Output Values                :  output
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
Encode (uchar8 *output, uint32 *input, uint32 len)
{
  uint32 i, j;

  for (i = 0, j = 0; j < len; i++, j += 4)
  {
    output[j] = (uchar8)(input[i] & 0xff);
    output[j+1] = (uchar8)((input[i] >> 8) & 0xff);
    output[j+2] = (uchar8)((input[i] >> 16) & 0xff);
    output[j+3] = (uchar8)((input[i] >> 24) & 0xff);
  }
}

/******************************************************************
*  Function Name                :  Decode
*  Description                  :  Decodes input (uchar8) into output (uint32).
*                                  Assumes len is  a multiple of 4
*  Input Values                 :  input, len
*  Output Values                :  output
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
Decode (uint32 *output, uchar8 *input, uint32 len)
{
  uint32 i, j;

  for (i = 0, j = 0; j < len; i++, j += 4)
  {
    output[i] = ((uint32)input[j]) | (((uint32)input[j+1]) << 8) |
    (((uint32)input[j+2]) << 16) | (((uint32)input[j+3]) << 24);
  }
}

/******************************************************************
*  Function Name                :  MD_memcpy
*  Description                  :  MD5 finalization. Ends an MD5 message-digest
*                                  operation, writing the the message digest
*                                  and zeroizing the context.
*  Input Values                 :  value, len
*  Output Values                :  output
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
MD_memcpy (POINTER output, POINTER input,uint32 len)
{
  uint32 i;
  for (i = 0; i < len; i++)
  {
     output[i] = input[i];
  }
}

/******************************************************************
*  Function Name                :  MD_memset
*  Description                  :  MD5 finalization. Ends an MD5 message-digest
*                                  operation, writing the the message digest
*                                  and zeroizing the context.
*  Input Values                 :  value, len
*  Output Values                :  output
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
MD_memset(POINTER output, int32 value, uint32 len)
{
  uint32 i;
  for (i = 0; i < len; i++)
  {
    ((char8 *)output)[i] = (char8)value;
  }
}

/******************************************************************
*  Function Name                :  MDUpdate
*  Description                  :  MD5 finalization. Ends an MD5 message-digest
*                                  operation, writing the the message digest
*                                  and zeroizing the context.
*  Input Values                 :  context, inputLen
*  Output Values                :  input
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
MDUpdate (MD_CT *context, uchar8 *input, uint32 inputLen)
{
  uint32 i, index, partLen;

  /* Compute number of bytes mod 64 */
  index = (uint32)((context->count[0] >> 3) & 0x3F);

  /* Update number of bits */
  if ((context->count[0] += ((uint32)inputLen << 3))
                               < ((uint32)inputLen << 3))
  {
    context->count[1]++;
  }
  context->count[1] += ((uint32)inputLen >> 29);

  partLen = 64 - index;
/* Transform as many times as possible.*/
  if (inputLen >= partLen)
  {
     MD_memcpy((POINTER)&context->buffer[index], (POINTER)input, partLen);
     MDTransform (context->state, context->buffer);

     for (i = partLen; i + 63 < inputLen; i += 64)
     MDTransform (context->state, &input[i]);

     index = 0;
  }
  else
    i = 0;

  /* Buffer remaining input */
  MD_memcpy((POINTER)&context->buffer[index], (POINTER)&input[i],inputLen-i);
}
/******************************************************************
*  Function Name                :  MDFinal
*  Description                  :  MD5 finalization. Ends an MD5 message-digest 
*                                  operation, writing the the message digest 
*                                  and zeroizing the context.
*  Input Values                 :  digest, context
*  Output Values                :  context
*  Return Value                 :  None
*  Notes                        :
*********************************************************************/
STATIC void
MDFinal (uchar8 * digest, MD_CT * context)
{
  uchar8 bits[8];
  uint32 index, padLen;

  /* Save number of bits */
  Encode (bits, context->count, 8);

  /* Pad out to 56 mod 64.*/

  index = (uint32)((context->count[0] >> 3) & 0x3f);
  padLen = (index < 56) ? (56 - index) : (120 - index);
  MDUpdate (context, PADDING, padLen);

  /* Append length (before padding) */
  MDUpdate (context, bits, 8);

  /* Store state in digest */
  Encode (digest, context->state, 16);

  /* Zeroize sensitive information.*/
  MD_memset ((POINTER)context, 0, sizeof (*context));
}

/******************************************************************
*  Function Name                :  IFX_RTP_Md32
*  Description                  :  This function returns a decimal  
*                               :  for an integer input 
*  Input Values                 :  string, length
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/
STATIC int32   IFX_RTP_Md32( char8 *string, int32 length )
{
   MD_CT context;
   union
   {
      char8 c[16];
      uint32 x[4];
   } digest;
   int32 r, i;


   MDInit( &context );
   MDUpdate( &context,( uchar8 * )string,length );
   MDFinal( ( uchar8 * ) &digest,&context );

   r = 0;
   for( i = 0; i < 3; i++ )
   {
      r ^= digest.x[i];
   }
   return r;
}

/******************************************************************
*  Function Name                :  IFX_RTP_GetRandomValue
*  Description                  :  This function returns random number 
*                               :   
*  Input Values                 :  
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/
PUBLIC uint32  IFX_MD5_GetRandomValue( void )
{
#ifdef __IMSENV__ 
  T_Mmb_UInt32 iRandom=0;
   
  if(e_Mmb_ErrOk != Mmb_GenerateRandomNumber(0x7FFFFFFF,&iRandom))
  {
    IFX_DBGC(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		"********Mmb_GenrateRandomNumber Fail*******");
  }

  return iRandom ;
#endif
#ifdef __LINUX__
   struct
   {
      struct  timeval tv;
      clock_t cpu;

      pid_t pid;
      uint32 hid;

      uid_t uid;
      gid_t gid;
      struct  utsname name;
   } s;
   s.tv.tv_usec = 200;
   s.tv.tv_sec = 0;

   gettimeofday( &s.tv,0 );
   uname( &s.name );

   s.cpu = clock();

   s.pid = getpid();
   s.uid = getuid();
   s.gid = getgid();
   return IFX_RTP_Md32( ( char8 * ) &s,sizeof( s ) );
#endif 
}

#ifdef __IMSENV__

/******************************************************************
*  Function Name                :  IFX_RTP_FdClear
*  Description                  :  This function clears the FD from FD set
*                               :   
*  Input Values                 :  FD, Fd_set
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/

void IFX_RTP_FdClear(int32 iFd, T_Mmb_SIfxSockFdSet* pFdSet)
{	
if(iFd)
  {
    IFX_FD_CLR((T_Mmb_HIfxSocket)iFd, pFdSet);
  }
}
/******************************************************************
*  Function Name                :  IFX_RTP_FdSet
*  Description                  :  This function adds the FD to FD set
*                               :   
*  Input Values                 :  FD FD_Set
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/

void IFX_RTP_FdSet(int32 iFd, T_Mmb_SIfxSockFdSet* pFdSet)
{	
  if(iFd)
  {
    IFX_FD_SET((T_Mmb_HIfxSocket)iFd, pFdSet);
  }
}
/******************************************************************
*  Function Name                :  IFX_RTP_FdIsSet
*  Description                  :  This function Check if FD is Set
*                               :   
*  Input Values                 :  FD, FD Set
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/

T_Mmb_Int8 IFX_RTP_FdIsSet(int32 iFd, T_Mmb_SIfxSockFdSet* pFdSet)
{
  	  return((iFd == 0)?0:IFX_FD_ISSET((T_Mmb_HIfxSocket)iFd,pFdSet));
}
/******************************************************************
*  Function Name                :  IFX_RTP_ThreadExit
*  Description                  :  Exits the Thread
*                               :   
*  Input Values                 :  pRet
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/

void IFX_RTP_ThreadExit(int pRet)
{
  Mmb_DestroyThread(&hRtpThread,pRet);
}
int32 IFX_RTP_GetHostByName(char8 *pcName, int32 iLength)
{
#ifdef __IMSENV__	
  T_Mmb_HIfxSocket socket = NULL;
  T_Mmb_HString localhostAddress = NULL;
  T_Mmb_HString resolvedAddr = NULL;
  const char * localhost = "127.0.0.1";

#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetHandle(&hHandle))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
    return IFX_RTP_FAIL;
  }    
#endif
  if(e_Mmb_ErrOk != Mmb_StringCreateFromAscii(localhost,&localhostAddress))
  {
    return IFX_RTP_FAIL;
  }

  if(e_Mmb_ErrOk != Mmb_IpStackSocket(hThis,IFX_SOCK_AF_INET,IFX_SOCK_STREAM,
                    IFX_SOCK_IPPROTO_IP,&socket))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_IpStackGetHostByAddr(socket,localhostAddress,
      &resolvedAddr))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_IpStackCloseSocket(hThis,socket))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_StringConvertStringToAscii(resolvedAddr, pcName))
  {
    return IFX_RTP_FAIL;
  }
  Mmb_StringDestroy(&localhostAddress);
  
  Mmb_StringDestroy(&resolvedAddr);
 
  return IFX_RTP_SUCCESS;
#endif
  return IFX_RTP_FAIL;
}
/******************************************************************
*  Function Name                :  IFX_RTP_Close
*  Description                  :  This function closes the FD
*                               :   
*  Input Values                 :  Fd
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/

#ifdef __IMSENV__       
int32 IFX_RTP_Close(int32 Fd)
{
  T_Mmb_Error eErrValue = e_Mmb_ErrFailed;

#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hComponentContainer = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetHandle(&hComponentContainer))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_ComponentContainerGetIpStack(hComponentContainer, &hThis))
  {
    return IFX_RTP_FAIL;
  }
#endif 

  eErrValue = Mmb_IpStackCloseSocket(hThis, (T_Mmb_HIfxSocket) Fd);
    
  return ((e_Mmb_ErrOk == eErrValue) ? IFX_RTP_SUCCESS : IFX_RTP_FAIL);
}

#endif
#endif 
/******************************************************************
*  Function Name                :  IFX_RTP_Md32
*  Description                  :  This function returns a decimal  
*                               :  for an integer input 
*  Input Values                 :  string, length
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/
int32 IFX_RTP_CreateThread( void * (*start_routine)(void *))
{
#ifdef __IMSENV__
  struct T_Mmb_SThread Thread;
  T_Mmb_UInt32 iThreadId = NULL;
 
  memset(&Thread,0,sizeof(struct T_Mmb_SThread));
  Thread.fnThread = start_routine;
  Thread.m_data =(T_Mmb_UserData) 1;
  if(e_Mmb_ErrOk != Mmb_CreateThread (&Thread,&hRtpThread))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_RunThread(&hRtpThread))
  {
    return IFX_RTP_FAIL;
  }
  if(e_Mmb_ErrOk != Mmb_GetThreadID (hRtpThread, &iThreadId))
  {
    return IFX_RTP_FAIL;
  } 
  if(iThreadId == 0)
  {
      return IFX_RTP_FAIL;
  }
#endif 
#ifdef __LINUX__
  pthread_t iThreadId = 0;
  pthread_attr_t xAttrib;
  int32 iRetVal;
  iRetVal = pthread_attr_init(&xAttrib);
  iRetVal = pthread_attr_setdetachstate(&xAttrib, PTHREAD_CREATE_DETACHED);
  if ((iRetVal =
         pthread_create(&iThreadId, &xAttrib,start_routine,
                        NULL)) != 0) {
        return IFX_RTP_FAIL;
  }
#endif
  return iThreadId;
}

/* All Mutex used for thread safe*/
#ifdef THREAD_SAFE
#ifdef __LINUX__
int32 IFX_RTP_LockAcquire(x_IFX_RTP_LockType xSemId)
{
  struct sembuf xWait ={0,-1,SEM_UNDO};
  return semop((int32)xSemId,&xWait,1);

}
int32 IFX_RTP_LockRelease(x_IFX_RTP_LockType xSemId)
{
  struct sembuf xPost = {0,1,SEM_UNDO};
  return semop((int32)xSemId,&xPost,1);
}
int32 IFX_RTP_LockCreate(x_IFX_RTP_LockType *pxSemId)
{
  ux_IFX_RTP_SEMUN uxArg={0};
  static int32 iKey =6666;
  /* Create Semaphore */
  if (( *pxSemId = semget(iKey,1,IPC_CREAT |0666)) == -1 )
  {
    IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "error creating semaphore\n");
    return IFX_RTP_FAIL;
  }
  iKey++;
  /* Initilize Sempahore */
  uxArg.val = 1;
  if (semctl(*pxSemId,0,SETVAL,uxArg) == -1)
  {
    IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "error initilizing semaphore\n");
    return IFX_RTP_FAIL;
  }
  return IFX_RTP_SUCCESS;
}
int32 IFX_RTP_LockDestroy(x_IFX_RTP_LockType *pxSemId)
{
  if(semctl(*pxSemId,1,IPC_RMID) < 0)
  {
    return IFX_RTP_FAIL; 
  } 
  return IFX_RTP_SUCCESS;
}
#endif

#ifdef __IMSENV__
int32 IFX_RTP_LockAcquire(IN x_IFX_RTP_LockType xMutex)
{
  if( Mmb_MutexAcquire(xMutex) != e_Mmb_ErrOk)
  {
    IFX_DBGC(vcRtpModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"acquiring Mutex Fail");
    return IFX_RTP_FAIL;
  }
  return IFX_RTP_SUCCESS;
}
int32 IFX_RTP_LockRelease(IN x_IFX_RTP_LockType xMutex)
{
  if( Mmb_MutexRelease(xMutex) != e_Mmb_ErrOk)
  {
    IFX_DBGC(vcRtpModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Releasing Mutex Fail");
    return IFX_RTP_FAIL;
  }
  return IFX_RTP_SUCCESS;
}
int32 IFX_RTP_LockCreate(OUT x_IFX_RTP_LockType *pxMutex)
{
  if( Mmb_MutexCreate(pxMutex) != e_Mmb_ErrOk)
  {
    IFX_DBGC(vcRtpModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Creating Mutex Fail");
    return IFX_RTP_FAIL;
  }
  return IFX_RTP_SUCCESS;
}
int32 IFX_RTP_LockDestroy(OUT x_IFX_RTP_LockType *pxMutex)
{
  Mmb_MutexDestroy(pxMutex);
  return IFX_RTP_SUCCESS;
}
#endif
#endif

