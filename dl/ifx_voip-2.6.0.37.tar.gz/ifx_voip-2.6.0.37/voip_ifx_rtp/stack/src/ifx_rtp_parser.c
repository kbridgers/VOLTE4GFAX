/**************************************************************************
 **   FILE NAME       : ifx_rtp_parser.c
 **   PROJECT         : RTP/RTCP for Inca IP Phone
 **   MODULES         : RTP/RTCP Encoder Decoder Implementation
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "ifx_rtp_memiface.h"
#include "ifx_rtp_oslayer.h"
#include "ifx_rtp_db.h"
#include "ifx_rtp_stack.h"
#include "ifx_rtp_parser.h"
#include "ifx_rtp_timeriface.h"

#include "ifx_debug.h"
#include "ifx_list.h"

/* STATIC declarations */

STATIC char8 IFX_RTP_ProcessRtcp_SR(x_IFX_RTP_Session *pxSess,
                                    x_IFX_RTP_ConnInfo *pxConn,
                                    char8 *pxPkt,
                                    int16 unLen );

STATIC char8 IFX_RTP_ProcessRtcp_RR(x_IFX_RTP_Session *pxSess,
                                    x_IFX_RTP_ConnInfo *pxConn,
                                    char8 *pxPkt,
                                    int16 unLen );

STATIC char8 IFX_RTP_ProcessRtcp_SDES(x_IFX_RTP_Session *pxSess,
                                      x_IFX_RTP_ConnInfo *pxConn,
                                      char8 *pxPkt,
                                      int16 unLen );

STATIC char8 IFX_RTP_ProcessRtcp_BYE(x_IFX_RTP_Session *pxSess,
                                     x_IFX_RTP_ConnInfo *pxConn,
                                     char8 *pxPkt,
                                     int16 unLen );

STATIC int8 IFX_RTP_SsrcCollision(x_IFX_RTP_Session *pxSess,
                                  x_IFX_RTP_ConnInfo *pxConn,
                                  IN uint32 uiSsrc );

EXTERN int32 viStackMode, v_iRtpSockFd;

EXTERN x_IFX_RTP_SyncCallBks vxSyncCallBks;

EXTERN x_IFX_RTP_Session *vpxSessInfo;

EXTERN x_IFX_RTP_Session *vpxRtpSessHeadPtr;


/*****************************************************************
*  Function Name     :  IFX_RTP_EncodeSr
*  Description       :  This function formate RTCP SR packet
*  Input Values      :  pxSess, pxConn
*  Output Values     :  *pucBuff,punBuffLen
*  Return Value      :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes             :
*********************************************************************/
PUBLIC int16
IFX_RTP_EncodeSr(IN x_IFX_RTP_Session *pxSess,
                 IN x_IFX_RTP_ConnInfo *pxConn,
                 OUT uchar8 *pucBuff,
                 OUT uint16 *punBuffLen)
{
  x_IFX_RTCP_Header *pxPktBuff = ( x_IFX_RTCP_Header * ) pucBuff;
  int16 nPktLen = 0;
  int32 iCumPacketsLost = 0;
  uint32 *puiTemp = NULL, uiLastSrTime, uiLastSrTimeFrac, uiLsr = 0;
  int32 uiRtpTimeStamp=0;
  long32 lTimeStamp = 0, lTimeStampFrac = 0;
  double64 diLastSrTime, diCurrTime, diDlsr = 0;
  x_IFX_RTP_ConnList *pxConnList = pxSess->pxConnListHeadPtr;
  x_IFX_RTP_ConnInfo *pxTmpConn;

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR, "<Parser> MakeSr" );

  /* Header for SR packet */
  pxPktBuff->ucVer = IFX_RTP_VERSION;
  pxPktBuff->ucPad = 0;
  pxPktBuff->ucCount = 0;
  pxPktBuff->ucPktType = IFX_RTCP_SR_PKT;

  /* Sender info */
  puiTemp = (uint32 *) pucBuff;
  puiTemp++;  /* increment by 4 byte to copy SSRC etc. */
  *puiTemp++ = IFX_RTP_Htonl(pxSess->uiTxSSRC);
  /* Add Fixed part */
  /* NTP timestamp */
  IFX_RTP_GetTimeOfDay(&lTimeStamp,&lTimeStampFrac);
  *puiTemp++ = IFX_RTP_Htonl(lTimeStamp);
  *puiTemp++ = IFX_RTP_Htonl(lTimeStampFrac);

  /* Corresponding RTP timestamp */

  uiRtpTimeStamp = pxConn->uiTxLastRtpTS;
  if(pxConn->xCB.pfnGetRtpTimeStamp !=NULL){
     pxConn->xCB.pfnGetRtpTimeStamp((uint32)pxSess,pxConn->pvUserData,
                       &uiRtpTimeStamp);
  }
  *puiTemp++ = IFX_RTP_Htonl(uiRtpTimeStamp);
  /* Sender statistics */
  *puiTemp++ = IFX_RTP_Htonl(pxConn->uiNoTxPkt);
  *puiTemp++ = IFX_RTP_Htonl(pxConn->uiNoTxOctet);

  /* RR Blocks */
  while(pxConnList != NULL)
  {
    pxPktBuff->ucCount++;
    pxTmpConn = pxConnList->pxConn;

    /* RR block's SSRC */
    *puiTemp++ = IFX_RTP_Htonl(pxTmpConn->uiRxSsrc);

     /* Calculate RTCP statistics if required */
    if( pxSess->ucIntRtcpStatCalc )
    {
      iCumPacketsLost = (pxTmpConn->unSeqNoRoc << 16) + pxTmpConn->unHighSeqNo -
                        pxTmpConn->unBaseSeqNum + 1 - pxTmpConn->uiNoRxPkt;

      if( (iCumPacketsLost < 0) ||
          (pxTmpConn->unHighSeqNo == (pxTmpConn->uiLastHighSeqNo & 0xFFFF)) )
      {
        pxTmpConn->ucFractionLost = 0;
      }
      else
      {
          pxTmpConn->ucFractionLost =
            (iCumPacketsLost - pxTmpConn->iCumPacketsLost) /
            ((pxTmpConn->unSeqNoRoc << 16) + pxTmpConn->unHighSeqNo 
              - pxTmpConn->uiLastHighSeqNo);
      }
    }
    else
    {
      iCumPacketsLost = pxTmpConn->iCumPacketsLost;
    }

    if( iCumPacketsLost >= 0x007FFFFF )
    {
      iCumPacketsLost = 0x007FFFFF;
    }
		/* Commented b radvajesh since -1 *n is negetive and msb is set and the result is always false*/
    /*else if( (-1 * iCumPacketsLost) >= 0x00800000 )
    {
      iCumPacketsLost = 0x00800000;
    }*/

    pxTmpConn->uiLastHighSeqNo = (pxTmpConn->unSeqNoRoc << 16) + 
                                 pxTmpConn->unHighSeqNo;
    pxTmpConn->iCumPacketsLost = iCumPacketsLost; 

    /* Prepare Fraction Lost + Cumulative loss field */
    iCumPacketsLost |= (pxTmpConn->ucFractionLost << 24);
    *puiTemp++ = IFX_RTP_Htonl(iCumPacketsLost);

    /* Prepare Extended Highest Seq Number Received field */
    *puiTemp++ = IFX_RTP_Htonl((pxTmpConn->unSeqNoRoc << 16) | pxTmpConn->unHighSeqNo);
  
    /* Prepare Inter Arrival Jitter field */
    *puiTemp++ = IFX_RTP_Htonl(pxTmpConn->uiInterArrJitter >> 4);

    /* Populate DLSR related fields */
    uiLsr = pxTmpConn->uiLastSrTime;
    *puiTemp++ = IFX_RTP_Htonl( uiLsr );
    if( uiLsr )
    {
      uiLastSrTime = pxTmpConn->uiLastSrRecdTime;
      uiLastSrTimeFrac =  pxTmpConn->uiLastSrRecdTimeFrac;
      diLastSrTime = (double64)uiLastSrTime +
                     IFX_RTP_GetDecimal((long32)uiLastSrTimeFrac);
      diCurrTime = (double64)lTimeStamp +
                   IFX_RTP_GetDecimal((long32)lTimeStampFrac);
      diDlsr = (diCurrTime - diLastSrTime);
      *puiTemp++ = IFX_RTP_Htonl((uint32)((diDlsr) * 65536));
    }
    else
    {
      *puiTemp++ = IFX_RTP_Htonl(0);
    }
    __ifx_list_GetNext((void *) &pxConnList);
  }

  /* Encode total no. of octets */
  nPktLen = ((puiTemp - (uint32 *)pucBuff)) - 1;
  pxPktBuff->unLen = IFX_RTP_Htons(nPktLen);
  *punBuffLen = (nPktLen+1) * 4;

  if(pxConn->xCB.pfnSRCreated != NULL)
  {
    pxConn->xCB.pfnSRCreated((uint32)pxSess, pxConn->pvUserData,
                             (char8 *)pxPktBuff, punBuffLen);
  }

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
		    "Sr Pkt Len =", *punBuffLen);
  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name     :  IFX_RTP_EncodeRr
*  Description       :  This function formate RTCP RR packet
*  Input Values      :  pxSess, pxConn
*  Output Values     :  *pucBuff,punBuffLen
*  Return Value      :  IFX_RTP_SUCCESS/IFX_RTP_FAIL 
*  Notes             :
*********************************************************************/
EXTERN  int16
IFX_RTP_EncodeRr(IN x_IFX_RTP_Session *pxSess,
                 IN x_IFX_RTP_ConnInfo *pxConn,
                 OUT uchar8 *pucBuff,
                 OUT uint16 *punBuffLen)
{
  x_IFX_RTCP_Header *pxPktBuff = ( x_IFX_RTCP_Header * ) pucBuff;
  int16 nPktLen =0;
  int32 iCumPacketsLost;
  uint32 *puiTemp = NULL, uiLastSrTime, uiLastSrTimeFrac, uiLsr = 0;
  long32 lTimeStamp = 0, lTimeStampFrac = 0;
  double64 diLastSrTime, diCurrTime, diDlsr = 0;
  x_IFX_RTP_ConnList *pxConnList = pxSess->pxConnListHeadPtr;
  x_IFX_RTP_ConnInfo *pxTmpConn;

  IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<Parser> MakeRr");

  pxPktBuff->ucVer = IFX_RTP_VERSION;
  pxPktBuff->ucPad = 0;
  pxPktBuff->ucCount = 0;
  pxPktBuff->ucPktType = IFX_RTCP_RR_PKT;

  puiTemp = (uint32 *)pxPktBuff;
  puiTemp = puiTemp + 1;  /* increment by 4 byte to copy SSRC etc. */

  /* Fill fixed part of RR pkt */
  *puiTemp++ = IFX_RTP_Htonl(pxSess->uiTxSSRC);

  /* RR Blocks */

  while(pxConnList != NULL)
  {
    pxPktBuff->ucCount++;
    pxTmpConn = pxConnList->pxConn;

    /* RR Block's SSRC */
    *puiTemp++ = IFX_RTP_Htonl(pxTmpConn->uiRxSsrc);

    /* Calculate RTCP statistics if required */
    if( pxSess->ucIntRtcpStatCalc )
    {
      iCumPacketsLost = (pxTmpConn->unSeqNoRoc << 16) + pxTmpConn->unHighSeqNo -
                        pxTmpConn->unBaseSeqNum + 1 - pxTmpConn->uiNoRxPkt;

      if( (iCumPacketsLost < 0) ||
          (pxTmpConn->unHighSeqNo == (pxTmpConn->uiLastHighSeqNo && 0xFFFF)) )
      {
        pxTmpConn->ucFractionLost = 0;
      }
      else
      {
        pxTmpConn->ucFractionLost =
          (iCumPacketsLost - pxTmpConn->iCumPacketsLost) /
          ((pxTmpConn->unSeqNoRoc << 16) + pxTmpConn->unHighSeqNo
            - pxTmpConn->uiLastHighSeqNo);
      }
    }
    else
    {
      iCumPacketsLost = pxTmpConn->iCumPacketsLost;
    }

    if( iCumPacketsLost >= 0x007FFFFF )
    {
      iCumPacketsLost = 0x007FFFFF;
    }
		/* Commented b radvajesh since -1 *n is negetive and msb is set and the result is always false*/
    /* else if( (-1 * iCumPacketsLost) >= 0x00800000 )
    {
      iCumPacketsLost = 0x00800000;
    }*/

    pxTmpConn->uiLastHighSeqNo = (pxTmpConn->unSeqNoRoc << 16) +
                                 pxTmpConn->unHighSeqNo;
    pxTmpConn->iCumPacketsLost = iCumPacketsLost; 

    /* Prepare Fraction Lost + Cumulative loss field */
    iCumPacketsLost |= (pxTmpConn->ucFractionLost << 24);
    *puiTemp++ = IFX_RTP_Htonl(iCumPacketsLost);

    /* Prepare Extended Highest Seq Number Received field */
    *puiTemp++ = IFX_RTP_Htonl((pxTmpConn->unSeqNoRoc << 16) | pxTmpConn->unHighSeqNo);
  
    /* Prepare Inter Arrival Jitter field */
    *puiTemp++ = IFX_RTP_Htonl(pxTmpConn->uiInterArrJitter >> 4);

    /* Populate DLSR related fields */
    uiLsr = pxTmpConn->uiLastSrTime;
    *puiTemp++ = IFX_RTP_Htonl( uiLsr );
    if( uiLsr )
    {
      uiLastSrTime = pxTmpConn->uiLastSrRecdTime;
      uiLastSrTimeFrac =  pxTmpConn->uiLastSrRecdTimeFrac;
      diLastSrTime = (double64)uiLastSrTime +
                     IFX_RTP_GetDecimal((long32)uiLastSrTimeFrac);
      diCurrTime = (double64)lTimeStamp +
                   IFX_RTP_GetDecimal((long32)lTimeStampFrac);
      diDlsr = (diCurrTime - diLastSrTime);
      *puiTemp++ = IFX_RTP_Htonl((uint32)((diDlsr) * 65536));
    }
    else
    {
      *puiTemp++ = IFX_RTP_Htonl(0);
    }
    __ifx_list_GetNext((void *) &pxConnList);
  }

  /* Encode total no. of octets */
  nPktLen = ((puiTemp -(uint32 *)pxPktBuff)) - 1;
  pxPktBuff->unLen = IFX_RTP_Htons(nPktLen);
  *punBuffLen = (nPktLen+1) * 4;

  /* Encode total no. of octets */
  nPktLen = ((puiTemp - (uint32 *)pxPktBuff )) - 1;
  pxPktBuff->unLen = IFX_RTP_Htons(nPktLen);
  *punBuffLen = (nPktLen+1) * 4;

  if(pxConn->xCB.pfnRRCreated != NULL)
  {
    pxConn->xCB.pfnRRCreated((uint32)pxSess, pxConn->pvUserData,
                             (char8*)pxPktBuff,punBuffLen);
  }

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
            "Rr Pkt Len =", *punBuffLen );
  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name     :  IFX_RTP_EncodeBye
*  Description       :  This function formate RTCP BYE packet
*  Input Values      :  pxSess, pxConn,pcReason
*  Output Values     :  *pucBuff,punBuffLen
*  Return Value      :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes             :
*********************************************************************/
PUBLIC int16
IFX_RTP_EncodeBye(IN x_IFX_RTP_Session *pxSess,
                  IN x_IFX_RTP_ConnInfo *pxConn,
                  OUT uchar8 *pucBuff,
                  OUT uint16 *punBuffLen,
                  IN char8 *pcReason )
{
   x_IFX_RTCP_Header *pxPktBuff = (x_IFX_RTCP_Header *)pucBuff;
   uint8 ucIdx, ucLen;
   char8 *pcTemp;
   uint16 unTempLen = 0, unPadLen = 0;
   uint32 *puiTemp = NULL, uiCount = 0;

   /* header*/
   pxPktBuff->ucVer = IFX_RTP_VERSION;
   pxPktBuff->ucPad = 0;
   pxPktBuff->ucCount = 1;
   pxPktBuff->ucPktType = IFX_RTCP_BYE_PKT;

   /* Bye info */
   puiTemp = (uint32 *) pucBuff;
   puiTemp++;

   /* save address for padding - to calculate the no. of octets*/
   uiCount = (uint32) pucBuff;

   /* Fixed part for Bye */
   *puiTemp++ = IFX_RTP_Htonl(pxSess->uiTxSSRC);

   /* Plug in memory block if not done by the caller...*/
   ucLen = strlen(pcReason);
   if( ucLen )
   {
     pcTemp = (char8 *) puiTemp;
     *pcTemp++ = ucLen;
     
     /* encode reason */
     for(ucIdx = 0;ucIdx < ucLen;ucIdx++)
     {
       *pcTemp++ = pcReason[ucIdx];
     }
     puiTemp = (uint32 *) pcTemp;
  }
  uiCount = ( uint32 ) puiTemp - uiCount;

  /* padding - check for 32-bit boundary if not fill w/ zero */
  unPadLen = 4 - (uiCount % 4);
  if(unPadLen != 4)
  {
    pcTemp = (char8 *) puiTemp;
    for(ucIdx = 0; ucIdx < unPadLen; ucIdx++)
    {
      *pcTemp++ = 0;
    }
    puiTemp = (uint32 *) pcTemp;
  }

  /* Update Length field */
  unTempLen = ((puiTemp - (uint32 *)pxPktBuff)) - 1;
  pxPktBuff->unLen = IFX_RTP_Htons( unTempLen );
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<parser> Bye Pkt Len =", unTempLen );

  /* Return len in bytes */
  *punBuffLen = (unTempLen + 1) * 4;

  if(pxConn->xCB.pfnByeCreated != NULL)
  {
    pxConn->xCB.pfnByeCreated((uint32)pxSess,pxConn->pvUserData,(char8*)pxPktBuff,punBuffLen);
  }

  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name     :  IFX_RTP_EncodeSdes
*  Description       :  This function formate RTCP SDES packet
*  Input Values      :  pxSess, pxConn
*  Output Values     :  *pucEncSdes,punSdesLen
*  Return Value      :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes       :
*********************************************************************/
PUBLIC int16
IFX_RTP_EncodeSdes(IN x_IFX_RTP_Session *pxSess,
                   IN x_IFX_RTP_ConnInfo *pxConn,
                   OUT uchar8 *pucEncSdes,
                   OUT uint16 *punSdesLen)
{
  x_IFX_RTCP_Header *pxPkt = (x_IFX_RTCP_Header * ) pucEncSdes;
  uint8 *pucTemp = NULL, ucItemLen, ucItemDataLoop;
  uint16 unTempLen;
  uint32 *puiTemp, uiCount = 0;
  x_IFX_RTCP_SdesItems *pxSdesItem;
  x_IFX_RTP_ConnList *pxConnList = pxSess->pxConnListHeadPtr;

  /* Header for SDES packet */
  pxPkt->ucVer = IFX_RTP_VERSION;
  pxPkt->ucPad = 0;
  pxPkt->ucCount = 0;
  pxPkt->ucPktType = IFX_RTCP_SDES_PKT;

  /* Save address for padding */
  uiCount = (uint32) pxPkt;

  /* SDES info */
  pucTemp = (uint8 *) pxPkt;
  pucTemp += 4;

  while( pxConnList != NULL )
  {
    puiTemp = (uint32 *) pucTemp;
    if( pxPkt->ucCount == 0 )
    {
      *puiTemp++ = IFX_RTP_Htonl(pxSess->uiTxSSRC);
      pxSdesItem = &(pxSess->xTxSrcDesc);
    }
    else if( (pxSess->ucNoConns > 1) && 
             (strcmp(pxConnList->pxConn->xRxSrcDesc.acCanName,"") != 0) &&
             (pxConnList->pxConn != pxConn) )
    {
      *puiTemp++ = IFX_RTP_Htonl(pxConnList->pxConn->uiRxSsrc);
      pxSdesItem = &(pxConnList->pxConn->xRxSrcDesc);
    }
    else
    {
      __ifx_list_GetNext((void *) &pxConnList);
      continue;
    }
    pucTemp = (uchar8 *) puiTemp;

    pxPkt->ucCount++;

    /* Compulsorily include CNAME */
    if(strcmp(pxSdesItem->acCanName,"" ) == 0){
      IFX_RTP_GetHostByName((char8 *)pxSdesItem->acCanName, IFX_RTCP_SDES_TEXT_LEN);
    }
    *pucTemp++ = IFX_RTCP_SDES_ITEM_CNAME;
    ucItemLen = strlen( pxSdesItem->acCanName );
    *pucTemp++ = ucItemLen;
    /* Fill item*/
    for(ucItemDataLoop = 0; ucItemDataLoop < ucItemLen; ucItemDataLoop++)
    {
      *pucTemp++ = pxSdesItem->acCanName[ucItemDataLoop];
    }

    pxSess->ucItemCnt++;
    /* Every third interval send other SDES type also */
    if((pxSess->ucItemCnt % 21) == 0)
    {
      if(strcmp( pxSdesItem->acName,"" ))
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_NAME;
        ucItemLen = strlen( pxSdesItem->acName );
        *pucTemp++ = ucItemLen;
        /* Fill item*/
        for(ucItemDataLoop = 0; ucItemDataLoop < ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->acName[ucItemDataLoop];
        }
      }
    }
    else if ((pxSess->ucItemCnt % 18) == 0)
    {
      if(strcmp(pxSdesItem->acEmail,"" ))
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_EMAIL;
        ucItemLen = strlen(pxSdesItem->acEmail);
        *pucTemp++ = ucItemLen;
        /* Fill item*/
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->acEmail[ucItemDataLoop];
        }
      }
    }
    else if ((pxSess->ucItemCnt % 15) == 0)
    {
      if(strcmp(pxSdesItem->acPhone,"" ))
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_PHONE;
        ucItemLen = strlen( pxSdesItem->acPhone );
        *pucTemp++ = ucItemLen;
        /* Fill item*/
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->acPhone[ucItemDataLoop];
        }
      }
    }
    else if ((pxSess->ucItemCnt % 12) == 0)
    {
      if(strcmp(pxSdesItem->acLoc,""))
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_LOC;
        ucItemLen = strlen( pxSdesItem->acLoc );
        *pucTemp++ = ucItemLen;
        /* Fill item*/
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->acLoc[ucItemDataLoop];
        }
      }
    }
    else if ((pxSess->ucItemCnt % 9) == 0)
    {
      if(strcmp(pxSdesItem->acAppTool,""))
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_TOOL;
        ucItemLen = strlen( pxSdesItem->acAppTool );
        *pucTemp++ = ucItemLen;
        /* Fill item */
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->acAppTool[ucItemDataLoop];
        }
      }
    }
    else if ((pxSess->ucItemCnt % 6) == 0)
    {
      if(strcmp( pxSdesItem->acNote,""))
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_NOTE;
        ucItemLen = strlen( pxSdesItem->acNote );
        *pucTemp++ = ucItemLen;
        /* Fill item*/
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->acNote[ucItemDataLoop];
        }
      }
    }
    else if ((pxSess->ucItemCnt % 3) == 0)
    {
      if( (strcmp(pxSdesItem->xPriv.acPrefixString,"")) &&
          (strcmp(pxSdesItem->xPriv.acPriv,"")) )
      {
        *pucTemp++ = IFX_RTCP_SDES_ITEM_PRIV;
        ucItemLen = strlen( pxSdesItem->xPriv.acPrefixString );
        *pucTemp++ = 1 + ucItemLen + strlen( pxSdesItem->xPriv.acPriv );
        *pucTemp++ = ucItemLen;
        /* Fill item*/
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
          *pucTemp++ = pxSdesItem->xPriv.acPrefixString[ucItemDataLoop];
        }
        ucItemLen = strlen( pxSdesItem->xPriv.acPriv );
        /* Fill item*/
        for(ucItemDataLoop=0;ucItemDataLoop<ucItemLen;ucItemDataLoop++)
        {
         *pucTemp++ = pxSdesItem->xPriv.acPriv[ucItemDataLoop];
        }
      }
    }

    /* Each Chunk must end on a 4 byte boundary and 
       must be terminated by atleast 1 NULL character */
    if( *(pucTemp - 1) != IFX_RTCP_SDES_ITEM_END )
    {
      *pucTemp++ = IFX_RTCP_SDES_ITEM_END;
    }

    uiCount = (uint32)pucTemp - uiCount;
    /* padding */
    while( uiCount & 0x3 )
    {
      *pucTemp++ = 0;
      uiCount++;
    }

    if( pxPkt->ucCount != 1 )
    {
      __ifx_list_GetNext((void *) &pxConnList);
    }
  }

  /* Update Length field */
  unTempLen = (pucTemp - (uchar8 *) pxPkt)/4 - 1;
  pxPkt->unLen = IFX_RTP_Htons(unTempLen);
  *punSdesLen = pucTemp - (uchar8 *) pxPkt;

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
            "Sdes Pkt Len =", *punSdesLen );
  if(pxConn->xCB.pfnSDESCreated != NULL)
  {
    pxConn->xCB.pfnSDESCreated((uint32)pxSess,pxConn->pvUserData,(char8 *)pucEncSdes,punSdesLen);
  }

  return IFX_RTP_SUCCESS;
}

/* APIs for setting the Application Information */
/******************************************************************
*  Function Name     :  IFX_RTCP_SetAppName
*  Description       :  Set the Name in the RTCP APP Header
*  Input Values      :  pucBuff is the APP packet, pcName is the
*                       pointer to the name value
*  Output Values     :  Updated APP packet
*  Return Value      :  IFX_RTP_SUCCESS or IFX_RTP_FAIL
*  Notes             :
*********************************************************************/
int16
IFX_RTCP_SetAppName(IN_OUT uchar8 *pucBuff,
                     IN uchar8 *pcName)
{
  int32 i;
  for( i=0; i<4; i++ )
  {
    pucBuff[8+i] = pcName[i];
  }
  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name     :  IFX_RTCP_SetAppSubType
*  Description       :  Set the Subtype in the RTCP APP Header
*  Input Values      :  pucBuff is the APP packet, cSubType is the subtype
*  Output Values     :  Updated APP packet
*  Return Value      :  IFX_RTP_SUCCESS or IFX_RTP_FAIL
*  Notes             :
*********************************************************************/
int16
IFX_RTCP_SetAppSubType(IN_OUT uchar8 *pucBuff,
                        IN uchar8 cSubType)
{
  x_IFX_RTCP_Header *pxPktBuff = (x_IFX_RTCP_Header * ) pucBuff;
  pxPktBuff->ucCount = cSubType & 0x1f;
  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name     :  IFX_RTCP_SetAppData
*  Description       :  Set the Subtype in the RTCP APP Header
*  Input Values      :  pucBuff is the APP packet,
*                       pcAppData is the Application specific data
*                       unAppDataLen- Num Octets of application specific data
*  Output Values     :  Updated APP packet
*  Return Value      :  IFX_RTP_SUCCESS or IFX_RTP_FAIL
*  Notes             :  Updates the length and padding fields
*********************************************************************/
int16
IFX_RTCP_SetAppData(IN_OUT uchar8 *pucBuff,
                        IN char8 *pcAppData,
                        IN uint16 unAppDataLen)
{
  x_IFX_RTCP_Header *pxPkt=(x_IFX_RTCP_Header *)pucBuff;
  uchar8 *pucTemp;
  uint16 unPadLoop,unTempLen;

  /* Copy the Application Data */
  memcpy((pucBuff+12),pcAppData,unAppDataLen);
  pucTemp = pucBuff+12+unAppDataLen;
  /* padding */
  if(4 - (unAppDataLen % 4) != 4)
  {
    for( unPadLoop=0; unPadLoop < (4 -(unAppDataLen % 4)); unPadLoop++ )
    {
      *pucTemp++ = 0;
    }
  }
  /* Update the length header */
  unTempLen = (uint16)(((uint32)pucTemp)-((uint32)pucBuff));
  unTempLen = unTempLen/4 - 1;
  pxPkt->unLen = IFX_RTP_Htons(unTempLen);
  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name     :  IFX_RTP_EncodeApp
*  Description       :  This function formate RTCP APP packet
*  Input Values      :  pxSess, pxConn, cSubType, pcName, pcAppData,
*                       unAppDataLen
*  Output Values     :  *pucBuff,punBuffLen
*  Return Value      :  IFX_RTP_SUCCESS or IFX_RTP_FAIL
*  Notes             :
*********************************************************************/
PUBLIC int16
IFX_RTP_EncodeApp(IN x_IFX_RTP_Session *pxSess,
                  IN x_IFX_RTP_ConnInfo *pxConn,
                  OUT uchar8 *pucBuff,
                  OUT uint16 *punBuffLen,
                  IN void* vpUserPlugInData  )
{
   x_IFX_RTCP_Header *pxPktBuff = (x_IFX_RTCP_Header * ) pucBuff;
   uint32 *puiTemp = NULL;

   IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
             "<Parser> MakeAPP" );

   /* Header for SR packet */
   pxPktBuff->ucVer = IFX_RTP_VERSION;
   pxPktBuff->ucPad = 0;
   pxPktBuff->ucCount = 0;
   pxPktBuff->ucPktType = IFX_RTCP_APP_PKT;

   /* Fill the SSRC */
   puiTemp = (uint32 *) pxPktBuff;
   puiTemp++;  /* increment by 4 byte to copy SSRC etc. */
   *puiTemp++ = IFX_RTP_Htonl(pxSess->uiTxSSRC);

   /* Call the Call back to intimate the application that the Application
      packet has been created  */
   if( pxConn->xCB.pfnAppCreated != NULL )
   {
     pxConn->xCB.pfnAppCreated((uint32)pxSess, pxConn->pvUserData,(char8 *)pucBuff,
                                punBuffLen,vpUserPlugInData);
   }

   *punBuffLen =(IFX_RTP_Ntohs( pxPktBuff->unLen)+1)*4;

   return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name                :  IFX_RTP_ProcessRtcp_SR
*  Description                  :  This function processes the RTCP SR packet
*  Input Values                 :  pxSess, pxConn, pcPkt, unLen
*                               :  pxSess + pxConn = Unique Connection
*                               :  pcPkt = char buffer containing SR pkt
*                               :  unLen = len of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
STATIC char8
IFX_RTP_ProcessRtcp_SR(IN x_IFX_RTP_Session *pxSess,
                       IN x_IFX_RTP_ConnInfo *pxConn,
                       IN char8 *pcPkt,
                       IN int16 unLen)
{
  char8 cRet = IFX_RTP_SUCCESS;
  uint32 uiLastSrTime = 0, uiLastSrTimeFrac = 0;
  long32 lTimeStamp, lTimeStampFrac;
  uint32 uiRxSsrc;

  uiRxSsrc = IFX_RTP_Ntohl(*((uint32 *)pcPkt + 1));
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<Parser> SR Ssrc ", uiRxSsrc );

  /* Store Last SR Time */
  uiLastSrTime = ((IFX_RTP_Ntohl(*(uint32 *)(pcPkt + 8)) & 0x0000FFFF) << 16);
  uiLastSrTimeFrac = ((IFX_RTP_Ntohl(*(uint32 *)(pcPkt + 12)) & 0xFFFF0000) >> 16);
  uiLastSrTime |= uiLastSrTimeFrac;
  IFX_RTP_GetTimeOfDay(&lTimeStamp,&lTimeStampFrac );

  /* Store values for RTCP calculations */
  pxConn->uiLastSrTime = uiLastSrTime;
  pxConn->uiLastSrRecdTime = lTimeStamp;
  pxConn->uiLastSrRecdTimeFrac =  lTimeStampFrac;
  if(pxConn->xCB.pfnSRArrived !=NULL)
  {
    pxConn->xCB.pfnSRArrived((uint32)pxSess,pxConn->pvUserData,
                             pcPkt,unLen);
  }
  return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_ProcessRtcp_RR
*  Description                  :  This function processes the RTCP RR packet
*  Input Values                 :  pxSess, pxConn, pcPkt, unLen
*                               :  pxSess + pxConn = Unique Connection
*                               :  pcPkt = char buffer containing RR pkt
*                               :  unLen = len of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
STATIC char8
IFX_RTP_ProcessRtcp_RR(IN x_IFX_RTP_Session *pxSess,
                       IN x_IFX_RTP_ConnInfo *pxConn,
                       IN char8 *pcPkt,
                       IN int16 unLen )
{
  uint32 uiRxSsrc;
  uiRxSsrc = IFX_RTP_Ntohl(*((uint32 *)pcPkt + 1));

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<Parser> RR Ssrc", uiRxSsrc );
  if(pxConn->xCB.pfnRRArrived !=NULL)
  {
    pxConn->xCB.pfnRRArrived((uint32)pxSess,pxConn->pvUserData,
                             pcPkt,unLen);
  }

  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name                :  IFX_RTP_ProcessRtcp_SDES
*  Description                  :  This function processes the RTCP SDES packet
*  Input Values                 :  pxSess, pxConn, pcPkt, unLen
*                               :  pxSess + pxConn = Unique Connection
*                               :  pcPkt = char buffer containing SDES pkt
*                               :  unLen = len of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
STATIC char8
IFX_RTP_ProcessRtcp_SDES(IN x_IFX_RTP_Session *pxSess,
                         IN x_IFX_RTP_ConnInfo *pxConn,
                         IN char8 *pcPkt,
                         IN int16 unLen)
{
  char8 cRet = IFX_RTP_SUCCESS;
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<Parser> SDES Rcvd on Conn=", (uint32) pxConn );
  /* store SDES item in DB */
  cRet = IFX_RTP_DB_SetRxSdes(pxSess,pxConn,pcPkt);
  if(pxConn->xCB.pfnSDESArrived !=NULL)
  {
    pxConn->xCB.pfnSDESArrived((uint32)pxSess,pxConn->pvUserData,
                               pcPkt,unLen);
  }

  return cRet;
}
/******************************************************************
*  Function Name                :  IFX_RTP_ProcessRtcp_APP
*  Description                  :  This function processes the RTCP APP packet
*  Input Values                 :  pxSess, pxConn, pcPkt, unLen
*                               :  pxSess + pxConn = Unique Connection
*                               :  pcPkt = char buffer containing APP Pkt
*                               :  unLen = len of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
STATIC char8
IFX_RTP_ProcessRtcp_APP(IN x_IFX_RTP_Session *pxSess,
                        IN x_IFX_RTP_ConnInfo *pxConn,
                        IN char8 *pcPkt,
                        IN int16 unLen)

{
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<Parser> APP Rcvd on Conn=", (uint32) pxConn );
  if(pxConn->xCB.pfnAppArrived !=NULL)
  {
    pxConn->xCB.pfnAppArrived((uint32)pxSess,pxConn->pvUserData,
                              pcPkt,unLen);
  }

  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name                :  IFX_RTP_ProcessRtcp_BYE
*  Description                  :  This function processes the RTCP BYE packet
*  Input Values                 :  pxSess, pxConn, pcPkt, unLen
*                               :  pxSess + pxConn = Unique Connection
*                               :  pcPkt = char buffer containing Bye Pkt
*                               :  unLen = len of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
STATIC char8
IFX_RTP_ProcessRtcp_BYE(IN x_IFX_RTP_Session *pxSess,
                        IN x_IFX_RTP_ConnInfo *pxConn,
                        IN char8 *pcPkt,
                        IN int16 unLen)
{
  char8 cRet = IFX_RTP_SUCCESS,
        cNoOfSsrc = (char8) ((x_IFX_RTCP_Header *) pcPkt)->ucCount;
  int16 nIdx = 0;
  uint32 uiRxSsrc, *puiPkt = (uint32 *) pcPkt;
  x_IFX_RTP_Session *pxSessNode;
  x_IFX_RTP_ConnList *pxMainConnListPtr;
  x_IFX_RTP_ConnInfo *pxConnNode;

  IFX_DBGC(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
           "<Parser> BYE received , No Of Ssrc ",cNoOfSsrc );

  /* Stop RTCP Connection timer */
  cRet = IFX_RTP_StopTimer(pxConn->unTimerId);
  if( cRet == IFX_RTP_FAIL )
  {
    return cRet;
  }

  puiPkt++;
  for( nIdx=0; nIdx < cNoOfSsrc; nIdx++)
  {
    uiRxSsrc = IFX_RTP_Ntohl(*puiPkt);
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
              "<Parser> Received Bye Pkt, Ssrc ",uiRxSsrc );

    /* Check if received SSRC belongs to a connection in this session */
    pxMainConnListPtr = pxSess->pxConnListHeadPtr;
    if( (pxMainConnListPtr != NULL ) &&
        (pxMainConnListPtr->pxConn->uiRxSsrc == uiRxSsrc ))
    {
      pxConnNode = pxMainConnListPtr->pxConn;
      pxSessNode = pxSess;
      if( pxConnNode->xCB.pfnByeArrived != NULL )
      {
        pxConnNode->xCB.pfnByeArrived((uint32)pxSessNode,
        pxConnNode->pvUserData,pcPkt,unLen);
      }
      /* Remove Ssrc from Member & Sender Lists */
      IFX_RTP_DB_DeleteFromMemberList(pxSessNode,uiRxSsrc);
      IFX_RTP_DB_DeleteFromSenderList(pxSessNode,uiRxSsrc);
      IFX_RTP_RemoveConnFromSess(pxSessNode, pxConnNode);
		pxMainConnListPtr = pxSess->pxConnListHeadPtr;
       IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "Bye Processing trace1");
      if( pxMainConnListPtr != NULL ) 
      {
      __ifx_list_GetNext((void *) &pxMainConnListPtr);
      if( pxMainConnListPtr != NULL ) 
      {
        /* Handle the other session associated with this connection */
        pxSessNode = (x_IFX_RTP_Session *) pxMainConnListPtr->pxConn->uiSessOwner;
        IFX_RTP_DB_DeleteFromMemberList(pxSessNode,uiRxSsrc);
        IFX_RTP_DB_DeleteFromSenderList(pxSessNode,uiRxSsrc);
        IFX_RTP_RemoveConnFromSess(pxSessNode, pxConnNode);
        }
      }
    } 
  }
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Bye Processing Success ");
  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name     :  IFX_RTCP_HeaderValidity
*  Description       :  This function will do Header validation for
*                       RTCP packet
*  Input Values      :  pxCompPkt,nLen
*  Output Values     :  punSrLen,punSdesLen,punByeLen,
*                       punAppLen,punErrCode
*  Return Value      :  SUCCESS/FAIL
*  Notes       :
*********************************************************************/
STATIC char8 IFX_RTCP_HeaderValidity( IN char8 *pxPacket,
                                      IN int16 nLen,
                                      IN_OUT uchar8 *ucStatus )
{
  x_IFX_RTCP_Header *pxPkt = (x_IFX_RTCP_Header *) pxPacket;
  int16 nTempLength = 0, nPktLen = 0, nSrRrField = 0;

  /* Includes 1 DWORD for header */
  nPktLen = ( IFX_RTP_Ntohs( pxPkt->unLen ) + 1 ) * 4 ;

  /* Compound Packet - Total Length cannot be the same
   * as a single packet length
   * But in a scenario where partial encryption is enabled,
   * SR or RR packets can come alone
   * 1st Packet - Dummy RR + SDES
   * 2nd Packet - SR
   */

  /* Check ( RC * 6 ) + 1 == Length for SR/RR */
  if( ( pxPkt->ucPktType == IFX_RTCP_SR_PKT ) )
  {
    nSrRrField = 6;
  }
  else
  {
    nSrRrField = 1;
  }

  /* if RTCP packet is SR/RR */
  if( (pxPkt->ucPktType == IFX_RTCP_SR_PKT) ||
      (pxPkt->ucPktType == IFX_RTCP_RR_PKT) )
  {
    if( ( pxPkt->ucCount * 6 + nSrRrField ) !=
        IFX_RTP_Ntohs( pxPkt->unLen ) )
    {
      IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
                "<Parser> Header Validity - Incompatible Chunk DWORDs,\
                Length=", IFX_RTP_Ntohs(pxPkt->unLen) );
      return IFX_RTP_FAIL;
    }
  }

  if( pxPkt->ucVer != IFX_RTP_VERSION )
  {
	IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "<Parser> Header Validity - Invalid Version" );
    return IFX_RTP_FAIL;
  }

  if( pxPkt->ucPad != 0 )
  {
    /* Padding not allowed for the first packet inside
     * the compound packet
     */
	IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
              "<Parser> Header Validity - \
              Wrong padding.", pxPkt->ucPad );
    return IFX_RTP_FAIL;
  }
#ifndef __IMSENV__
  if( ( ( pxPkt->ucPktType ) != IFX_RTCP_SR_PKT ) &&
       ( ( pxPkt->ucPktType ) != IFX_RTCP_RR_PKT )
#ifdef POC_SUPPORT
		 &&(( pxPkt->ucPktType ) != IFX_RTCP_APP_PKT )
#endif		 
	 )
  {
    /* Compound Packet should start with SR or RR */
	IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
              "<Parser> Header Validity - Wrong SR/RR packet type.",
              pxPkt->ucPktType );
    return IFX_RTP_FAIL;
  }
#endif
  nTempLength = nPktLen;
  /* parse till end of packet, since compound packet*/
  while( nTempLength < nLen )
  {
    pxPkt = ( x_IFX_RTCP_Header * ) ( ( uchar8 * ) pxPacket + nTempLength );
    if( pxPkt->ucVer != IFX_RTP_VERSION )
    {
      IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
                "<Parser> Header Validity - Wrong Ver No", pxPkt->ucVer );
      return IFX_RTP_FAIL;
    }
    if( ( pxPkt->ucPktType < IFX_RTCP_SR_PKT) ||
        ( pxPkt->ucPktType > IFX_RTCP_APP_PKT) )
    {
	  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_RTP_STR_ERR,
                "<Parser> Header Validity - Wrong OTHER  packet type..",
                pxPkt->ucPktType );
      return IFX_RTP_FAIL;
    }

    nPktLen = ( IFX_RTP_Ntohs( pxPkt->unLen ) + 1 ) * 4;
    nTempLength += nPktLen;
  }/*end of while */

  if( nTempLength != nLen )
  {
    return IFX_RTP_FAIL;
  }
  else
  {
    *ucStatus = 0;
  }

  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name                :  IFX_RTCP_Decode
*  Description                  :  This function decodes the RTCP packet
*  Input Values                 :  pxSess, pxConn, pcBuffer, nBuffLen
*                               :  pxSess + pxConn = Unique Connection
*                               :  pcBuffer = char buffer containing RTCP pkt
*                               :  nBuffLen = Length of pkt buffer
*                               :  pxRemoteAddr = remote end address
*                               :
*  Output Values                :  
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8
IFX_RTCP_Decode(IN x_IFX_RTP_Session *pxSess,
                IN x_IFX_RTP_ConnInfo *pxConn,
                IN uchar8 *pcBuffer,
                IN int16 nBuffLen,
                IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr)
{
  x_IFX_RTCP_Header *pxPacket = (x_IFX_RTCP_Header *)pcBuffer;
  uint16 nTempLen, unPktLen;
  uchar8 ucStatus = 1;
  char8 cRet = IFX_RTP_SUCCESS;

  if( nBuffLen > 0 )
  {
    if( ucStatus )
    {
      cRet = IFX_RTCP_HeaderValidity((char8 *) pxPacket, nBuffLen,
                                     &ucStatus);
    }
    if( cRet == IFX_RTP_SUCCESS )
    {
      cRet = IFX_RTP_CheckSsrcCollision(pxSess, pxConn, IFX_RTCP_PKT,
                                         (char8 *)pcBuffer, pxRemoteAddr);
      if( cRet == IFX_RTP_FAIL)
      {
        return cRet;
      }
      IFX_RTP_DB_AddToMemberList(pxSess, *(uint32 *) (pcBuffer + 4));
      IFX_RTP_DB_AddToSenderList(pxSess, *(uint32 *) (pcBuffer + 4));
      /* Recalculate the Average RTCP Pkt Size */
      pxSess->diAvgRtcpPktSize = ((1.0/16.0) * (double64) (nBuffLen + 28) +
                                  ((15.0/16.0) * pxSess->diAvgRtcpPktSize));
      nTempLen = 0;
      while( nTempLen < nBuffLen )
      {
        pxPacket = (x_IFX_RTCP_Header *) (pcBuffer + nTempLen);
        unPktLen = (IFX_RTP_Ntohs(pxPacket->unLen) + 1) << 2;
       	switch( pxPacket->ucPktType )
        {
          case IFX_RTCP_SR_PKT:
            /* process SR packet */
            IFX_RTP_ProcessRtcp_SR(pxSess, pxConn, (char8 *)pcBuffer+nTempLen, unPktLen);
            break;
          case IFX_RTCP_RR_PKT:
            /* process RR packet */
            IFX_RTP_ProcessRtcp_RR(pxSess, pxConn, (char8 *)pcBuffer+nTempLen, unPktLen);
            break;
          case IFX_RTCP_SDES_PKT:
            /* process SDES packet */
            IFX_RTP_ProcessRtcp_SDES(pxSess, pxConn,(char8 *)pcBuffer+nTempLen,unPktLen);
            break;
          case IFX_RTCP_APP_PKT:
            /* IFX_RTCP_APP_PKT*/
            IFX_RTP_ProcessRtcp_APP(pxSess, pxConn, (char8 *)pcBuffer+nTempLen,unPktLen);
            break;
          case IFX_RTCP_BYE_PKT:
#ifndef __IMSENV__
            /* process BYE packet */
            IFX_RTP_ProcessRtcp_BYE(pxSess, pxConn, (char8 *)pcBuffer+nTempLen,unPktLen);
#endif
            break;
        }
        nTempLen += unPktLen;
      } /* While */
    }
    else
    {
      return IFX_RTP_FAIL;
    }
  }
  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name     :  IFX_RTP_CheckSsrcCollision
*  Description       :  This function will check for ssrc
*                       collision
*  Input Values      :  pxSess, pxConn,ucPktType,
*                       pcBuffer, pxRemoteAddr
*  Output Values     :
*  Return Value      :  IFX_RTP_SUCCESS or IFX_RTP_FAIL
*  Notes             :
* *********************************************************************/
int8
IFX_RTP_CheckSsrcCollision(IN x_IFX_RTP_Session *pxSess,
                           IN x_IFX_RTP_ConnInfo *pxConn,
                           IN uint8 ucPktType,
                           IN char8 *pcBuffer,
                           IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr)
{
  uint32 uiRxSsrc, uiCurrSsrc, uiTxSsrc;
  uint8 ucFirstRxPkt;
  uint32 uiRemoteIP, uiRxIP, uiRxPort, uiRemotePort;

  ucFirstRxPkt = pxConn->ucFirstRxPkt;
  uiRxIP = pxRemoteAddr->uiIP;
  uiRxPort = pxRemoteAddr->iPort;
  uiRemoteIP = pxConn->uiRemoteIP;

  /* check received packet is RTP or RTCP */
  if( ucPktType == IFX_RTP_PKT )
  {
    uiRxSsrc = IFX_RTP_Ntohl(*((uint32 *)pcBuffer + 2));
    uiRemotePort = pxConn->unRemoteRtpPort;
    /* if received pkt is first packet, store the data port*/
    if( !( ucFirstRxPkt & 1) )
    {
      if( uiRemoteIP != uiRxIP )
      {
         IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                  "<RTP> Remote IP and IP at conn are mismatch");
        return IFX_RTP_FAIL;
      }
      pxConn->ucFirstRxPkt = (ucFirstRxPkt | 1);
      pxConn->unRemoteTxRtpPort = IFX_RTP_Ntohs( pxRemoteAddr->iPort);
    }
    if( !pxConn->uiRxSsrc )
    {
      pxConn->uiRxSsrc = uiRxSsrc;
    }
  }
  else
  {
    /* RTCP packet */
    uiRemoteIP = pxConn->uiRemoteRtcpIP;
    uiRxSsrc = IFX_RTP_Ntohl(*((uint32 *)pcBuffer + 1));
    uiRemotePort = pxConn->unRemoteRtcpPort;
    /* first RTCP Pkt */
    if( !(ucFirstRxPkt & 2) )
    {
#ifndef __IMSENV__            
      if( uiRemoteIP != uiRxIP )
      {
        IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                  "<RTCP> Remote IP and IP at conn are mismatch");
        return IFX_RTP_FAIL;
      }
#endif      
      pxConn->ucFirstRxPkt = (ucFirstRxPkt | 2);
      pxConn->unRemoteTxRtcpPort =  IFX_RTP_Ntohs( pxRemoteAddr->iPort);
    }
    if( !pxConn->uiRxSsrc )
    {
      pxConn->uiRxSsrc = uiRxSsrc;
    }
  }

  uiTxSsrc = pxSess->uiTxSSRC;
  if( uiTxSsrc == uiRxSsrc )
  {
    /* new collision, change SSRC */
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "<Stack>  SSRC COLLISON ....SELF" );
    IFX_RTP_SsrcCollision(pxSess,pxConn,uiRxSsrc);
    return IFX_RTP_FAIL;
  }

  uiCurrSsrc = pxConn->uiRxSsrc;
  /* transport address doesn't match */
  if( (uiRemoteIP != uiRxIP) ||  (uiRemotePort != uiRxPort) )
  {
		if(uiRemoteIP == 0){
				return IFX_RTP_FAIL;
		}
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "<Stack>  SSRC COLLISON ....REMOTE" );
    if( pxConn->xCB.pfnSsrcCollision != NULL )
    {
      pxConn->xCB.pfnSsrcCollision((uint32) pxSess, pxConn->pvUserData);
    }
    return IFX_RTP_FAIL;
  }

  /* if receiver SSRC changed then configure the csrc in conference*/
  if( uiRxSsrc != uiCurrSsrc )
  {
    IFX_DBGC(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
             "<parser>  SSRC has channged" );
    IFX_RTP_DB_DeleteFromMemberList(pxSess, uiCurrSsrc);
    IFX_RTP_DB_DeleteFromSenderList(pxSess, uiCurrSsrc);
    IFX_RTP_DB_AddToMemberList(pxSess, uiRxSsrc);
    IFX_RTP_DB_AddToSenderList(pxSess, uiRxSsrc);
    pxConn->uiRxSsrc = uiRxSsrc;
  }
  return IFX_RTP_SUCCESS;
}

/******************************************************************
 *  Function Name     :  IFX_RTP_SsrcCollision
 *  Description       :  This function will HANDLE ssrc collision
 *  Input Values      :  pxSess, pxConn,uiSsrc,
 *  Output Values     :  None
 *  Return Value      :  IFX_RTP_SUCCESS or IFX_RTP_FAIL
 *  Notes             :  
******************************************************************/
STATIC int8 IFX_RTP_SsrcCollision(IN x_IFX_RTP_Session *pxSess,
                                  IN x_IFX_RTP_ConnInfo *pxConn,
                                  IN uint32 uiSsrc)
{
  x_IFX_RTP_ConnList *pxConnList = pxSess->pxConnListHeadPtr;
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
            "<Stack> SSRC collision " );

/*
 * Send Bye
 * Change SSRC
 */

  if( pxSess->ucIsRtcpEnable )
  {
    while( pxConnList != NULL )
    {
      IFX_RTP_SendRtcpReport(pxSess,pxConnList->pxConn,IFX_RTCP_SR|
                             IFX_RTCP_RR|IFX_RTCP_SDES|IFX_RTCP_BYE,NULL);
      __ifx_list_GetNext((void *) &pxConnList);
    }
  }

  //pxSess->uiTxSSRC = IFX_MD5_GetRandomValue();

  pxConnList = pxSess->pxConnListHeadPtr;
  while( pxConnList != NULL )
  {
    if( pxConnList->pxConn->xCB.pfnSsrcCollision != NULL )
    {
      pxConnList->pxConn->xCB.pfnSsrcCollision((uint32) pxSess,
                                               pxConnList->pxConn->pvUserData);
    }

    __ifx_list_GetNext((void *) &pxConnList);
  }

  return IFX_RTP_SUCCESS;
}

