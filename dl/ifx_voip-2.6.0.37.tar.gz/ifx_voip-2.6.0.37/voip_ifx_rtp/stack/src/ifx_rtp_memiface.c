/**************************************************************************
 **   FILE NAME       : ifx_rtp_memiface.c
 **   PROJECT         : RTP/RTCP
 **   MODULES         : Memory Library Interface
 **   SRC VERSION     : V0.1
 **   DATE            : 01-03-2004
 **   AUTHOR          : Bharathraj Shetty 
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifdef USE_IFIN_MLIB
#include "IFIN_MLIB_Main.h"
#include "ifx_rtp_memiface.h"

STATIC IFIN_MLIB_Id vMLibId;

/******************************************************************
*  Function Name        :  IFX_RTP_MLibInit
*  Description          :  This function initialises the Memory Lib
*  Input Values         :  unMaxSegSize 
*  								Maximum size of the segment size 
*  Output Values        :  None
*  Return Value         :  None
*  Notes                :
*********************************************************************/
PUBLIC char8   IFX_RTP_MLibInit( uint16 unMaxSegSize )
{
   x_IFIN_MLIB_SegInfo axSegsInfo[2];

   axSegsInfo[0].uiSegSize = unMaxSegSize;
   axSegsInfo[0].unNumOfSegs = 2;
   axSegsInfo[1].uiSegSize = 0;
   axSegsInfo[1].unNumOfSegs = 0;

   if( IFIN_MLIB_Init( &vMLibId,IFX_RTP_MEM_LIB_KEY,
          IFIN_MLIB_DYNAMIC_MEMORY | IFIN_MLIB_PTR_FEATURE,0,
	       &axSegsInfo[0],0 ) != IFIN_MLIB_SUCCESS )
   {
      return IFX_RTP_FAIL;
   }
   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name        :  IFX_RTP_Malloc
*  Description          :  This function allocates memory.
*  Input Values         :  Size, Requested memory size
*  Output Values        :  none
*  Return Value         :  Pointer to the allocated memory/NULL
*  Notes                :
*********************************************************************/
PUBLIC char8   *  IFX_RTP_Malloc( IN int32 iSize )
{
   char8 *pcBuffer;
   pcBuffer = IFIN_MLIB_AllocMem( vMLibId,iSize );

   return pcBuffer;
}

/******************************************************************
*  Function Name        :  IFX_RTP_Calloc
*  Description          :  This function allocates memory and initialises
                           it to Zero.
*  Input Values         :  Size, Requested memory size
*  Output Values        :  none
*  Return Value         :  Pointer to the allocated memory/NULL
*  Notes                :
*********************************************************************/
PUBLIC void *  IFX_RTP_Calloc( IN int32 iSize )
{
   char8 *pcBuffer;

   pcBuffer = ( char8 * ) IFIN_MLIB_AllocMem( vMLibId,iSize );
   memset( pcBuffer,0,iSize );

   return pcBuffer;
}

/******************************************************************
*  Function Name        :  IFX_RTP_Free
*  Description          :  This function frees the preallocated memory.
*  Input Values         :  pcFree, address needs to be freed 
*  Output Values        :  none
*  Return Value         :  IFX_RTP_SUCCESS/IFX_RTP_FAIL 
*  Notes                :
*********************************************************************/
PUBLIC uint32  IFX_RTP_Free( IN void *pcFree )
{
   if( pcFree != NULL )
   {
      if( IFIN_MLIB_FreeMem( vMLibId,pcFree ) != IFIN_MLIB_SUCCESS )
      {
         return IFX_RTP_FAIL;
      }
      pcFree = NULL;
   }
   return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name        :  IFX_RTP_MemInfo
*  Description          :  This function prints the memlibrary debug info
*  Output Values        :  None
*  Return Value         :  None
*  Notes                :
*********************************************************************/
PUBLIC void IFX_RTP_MemInfo( void )
{
   IFIN_MLIB_DbgInfo( vMLibId );
}
#endif
