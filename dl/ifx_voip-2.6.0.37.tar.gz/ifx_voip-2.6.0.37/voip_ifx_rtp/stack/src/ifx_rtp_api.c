/**************************************************************************
 **   FILE NAME       : ifx_rtp_api.c
 **   PROJECT         : RTP/RTCP
 **   MODULES         : Packet Formats for RTP/RTCP
 **   SRC VERSION     : V0.1
 **   DATE            :
 **   AUTHOR          :
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **
 **   COPYRIGHT       : Copyright © 2004
 **                     Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "ifx_rtp_memiface.h"
#include "ifx_rtp_oslayer.h"
#include "ifx_rtp_db.h"
#include "ifx_rtp_stack.h"
#include "ifx_rtp_parser.h"
#include "ifx_rtp_timeriface.h"

#include "ifx_debug.h"
#include "ifx_list.h"
#ifdef __IMSENV__
#ifndef __IMSCORE__
T_Mmb_HIpStack hThis;
#endif
#endif

IFX_RTP_fd_set v_RdSelectFd;
x_IFX_RTP_SyncCallBks vxSyncCallBks;
int32 v_iRtpSockFd, viStackMode, viRtpInternalPort;
uchar8 vcRtpModId;
#ifdef THREAD_SAFE
x_IFX_RTP_MutexTable vxMutexTable[IFX_RTP_MAX_SESSIONS + 1];
#endif
extern double64 IFX_RTP_GetRtcpTxInterval(IN x_IFX_RTP_ConnInfo *pxConn);
/******************************************************************
*  Function Name  :  IFX_RTP_ShutRtpThread
*  Description    :  This function is destroys RTP recive thread
*  Input Values   :  none
*  Output Values  :  none
*  Return Value   :  void
*  Notes          :
*********************************************************************/
PUBLIC int8 IFX_RTP_ShutRtpThread( void )
{
   int32 iLocalIp=0;
   char8 cRet=IFX_RTP_SUCCESS;
   x_IFX_RTP_INT_MSG xIntMsg;
   
   if(viStackMode == IFX_RTP_ASYNC_MODE)
   {
     xIntMsg.eIntMsgType = IFX_RTP_THREAD_SHUT;
     IFX_RTP_inet_pton(IFX_RTP_AF_INET,IFX_RTP_INTERNAL_IP,&iLocalIp);
     cRet = IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,
                             sizeof(x_IFX_RTP_INT_MSG),
                             iLocalIp,viRtpInternalPort);
   }
   return cRet;
}
/******************************************************************
*  Function Name  :  IFX_RTP_RtcpInit
*  Description    :  This function is initializes RTCP module
*  Input Values   :  none
*  Output Values  :  none
*  Return Value   :  void
*  Notes          :
*********************************************************************/
STATIC int8 IFX_RTP_RtcpInit( void )
{

   if( IFX_RTP_TimerInit() == IFX_RTP_SUCCESS )
   {
     return IFX_RTP_SUCCESS;
   }
   else
   {
    IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,      
             "RTP Timer Initialization failed");
      return IFX_RTP_FAIL;
   }
}

/******************************************************************
*  Function Name  :  IFX_RTP_RtcpShut
*  Description    :  This function frees all resources related
*                    to RTCP
*  Input Values   :  none
*  Output Values  :  none
*  Return Value   :  void
*  Notes          :
*********************************************************************/
STATIC int8 IFX_RTP_RtcpShut( void )
{
   IFX_RTP_TimerDelete();
   return IFX_RTP_SUCCESS;
}


/******************************************************************
*  Function Name  :  IFX_RTP_Main
*  Description    :  This function is entry point for an RTP/RTCP
*                    and blocks on pselect.
*  Input Values   :  none
*  Output Values  :  none
*  Return Value   :  void
*  Notes          :
*********************************************************************/
STATIC int32 IFX_RTP_Main()
{
   int32 iNoOfFds=0;
   uint32 uiEcode;
   char8 *pcBuffer=NULL, cRet = IFX_RTP_SUCCESS;
   IFX_RTP_fd_set xTempFdSet;
   int16 nPktLen=0;
   x_IFX_RTP_PacketSourceInfo xRemoteAddr={0};
   x_IFX_RTP_ConnInfo *pxConnPtr=NULL;
   x_IFX_RTP_Session *pxSessPtr=NULL;
   double64 diInterval = 0.0;
   x_IFX_RTP_INT_MSG xIntMsg;
   vpxRtpSessHeadPtr = NULL;

   /* Prepare for RTCP by default */
   IFX_RTP_RtcpInit();
   /* the free connection node points to head of connection list */
   IFX_RTP_FdZero( &v_RdSelectFd );
   /* parent is waiting , resume parent process*/
   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		        "Init success\n");
   IFX_RTP_FdSet(v_iRtpSockFd,&v_RdSelectFd);
   IFX_DBGA(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
              "RTP FIFO fd ",v_iRtpSockFd);
   while(1)
   {
      IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		"<Session> Select Block\n");
      memcpy(&xTempFdSet,&v_RdSelectFd,sizeof(IFX_RTP_fd_set));
      iNoOfFds = IFX_RTP_Select( FD_SETSIZE,&xTempFdSet,NULL,NULL,0);
      if(iNoOfFds <= 0)
      {
        continue;
      }
      IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		"<Session> Select UnBlock");
      pxSessPtr = vpxRtpSessHeadPtr;
      while(pxSessPtr != NULL)
      {
          x_IFX_RTP_Session *pxTempSessPtr=pxSessPtr;
          __ifx_list_GetNext((void*)(&pxTempSessPtr));
          pxConnPtr = pxSessPtr->pxConnListHeadPtr->pxConn;
          if((pxConnPtr->iRtpFd) && (IFX_RTP_FdIsSet(pxConnPtr->iRtpFd,&xTempFdSet)))
          {
            iNoOfFds--;
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       	      	   "<Session> RTP Packet Frm Network\n" );
            if (pxConnPtr->xCB.pfnAllocMemForRtpPkt != NULL)
            {
              pxConnPtr->xCB.pfnAllocMemForRtpPkt(pxConnPtr->uiSessOwner,
                                                  pxConnPtr->pvUserData,
                                                  (char8**)&pcBuffer);
            }
            nPktLen = IFX_RTP_RecvNwPkt(pxConnPtr->iRtpFd,pcBuffer, \
                                        IFX_RTP_MAX_BUFF_SIZE,&xRemoteAddr );
            if( nPktLen < 0 )
            {
              IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                       "<Session> Read NW RTP fail\n" );
            }
            else
            {                  
              cRet = IFX_RTP_ProcessDownstreamRtpPkt((x_IFX_RTP_Session*)
                       pxConnPtr->uiSessOwner,pxConnPtr,pcBuffer,
                       ((uint16 *)&nPktLen),&xRemoteAddr );
              if(cRet == IFX_RTP_FAIL)
              {
                IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     	   "<Session> Process NW RTP Failure\n" );
              }
              if(iNoOfFds == 0)
              {
                break;
              }
            }
          }
          else if((pxConnPtr->iRtcpFd) &&
                  (IFX_RTP_FdIsSet(pxConnPtr->iRtcpFd,&xTempFdSet)))
          {
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
             	   "<Session> Process NW RTCP \n" );
            iNoOfFds--;
            if (pxConnPtr->xCB.pfnAllocMemForRtcpPkt != NULL)
            {
               pxConnPtr->xCB.pfnAllocMemForRtcpPkt(pxConnPtr->uiSessOwner,
                                                    pxConnPtr->pvUserData,
                                                    (char8**)&pcBuffer);
            }
            nPktLen = IFX_RTP_RecvNwPkt(pxConnPtr->iRtcpFd,pcBuffer, \
                                        IFX_RTP_MAX_BUFF_SIZE,&xRemoteAddr);
            if(nPktLen < 0)
            {
              IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "<Session> recv NW RTCP fail\n" );
            }
            else
            {
#ifdef THREAD_SAFE
              if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_ALL_SESSIONS,
                                     pxConnPtr->uiSessOwner) != IFX_RTP_FAIL)
              {
#endif
                cRet = IFX_RTP_ProcessDownstreamRtcpPkt((x_IFX_RTP_Session*)
                         pxConnPtr->uiSessOwner,pxConnPtr,pcBuffer,nPktLen,
                         &xRemoteAddr );
                if(cRet == IFX_RTP_FAIL)
                {
                  IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     	     "<Session> Process NW RTCP failure\n" );
                }
#ifdef THREAD_SAFE
                IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_ALL_SESSIONS, 
                                    pxConnPtr->uiSessOwner);
              }
#endif            
              if(iNoOfFds == 0)
              {
                break;
              }
            }
          } 
          pxSessPtr=pxTempSessPtr;
        }
        if(iNoOfFds == 0)
        {
          continue;
        }
        if((v_iRtpSockFd )&& (IFX_RTP_FdIsSet(v_iRtpSockFd,&xTempFdSet)))
        {
          nPktLen = IFX_RTP_RecvNwPkt(v_iRtpSockFd,(char8 *)&xIntMsg, \
                                      sizeof(x_IFX_RTP_INT_MSG),&xRemoteAddr);
          if(-1 == nPktLen){
            iNoOfFds--;
            continue;              
          }
          if(xIntMsg.eIntMsgType == IFX_RTP_THREAD_SHUT)
          {
            break;
          }
          else if(xIntMsg.eIntMsgType == IFX_RTP_REM_SESS)
          {
#ifdef THREAD_SAFE
            if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_LIST, 0) == IFX_RTP_FAIL)
            {
              iNoOfFds--;
              continue;
            }  
#endif  
            IFX_RTP_RemoveSess((x_IFX_RTP_Session *)xIntMsg.uiSessPtr);
#ifdef THREAD_SAFE
            if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_LIST, 0) == IFX_RTP_FAIL)
            {
              iNoOfFds--;
              continue;
            }  
#endif        
          }
          else if((xIntMsg.eIntMsgType == IFX_RTP_EMRGCY_RSTRT_RTCP_TIMER) ||
                  (xIntMsg.eIntMsgType == IFX_RTP_RSTRT_RTCP_TIMER) )
          {
            if( ((x_IFX_RTP_Session *) xIntMsg.uiSessPtr)->ucIsRtcpEnable)
            {
              pxConnPtr = (x_IFX_RTP_ConnInfo *) xIntMsg.uiConnPtr;
              if(xIntMsg.eIntMsgType == IFX_RTP_EMRGCY_RSTRT_RTCP_TIMER)
              {
                diInterval = 100.0; 
              }
              else
              {
                diInterval = IFX_RTP_GetRtcpTxInterval(pxConnPtr);
              }
              IFX_RTP_StopTimer(pxConnPtr->unTimerId);
              cRet = IFX_RTP_StartTimer( (uint32) diInterval,
                                         (void *) IFX_RTP_ProcessRtcpInfo,
                                         (void *) pxConnPtr,
                                         &pxConnPtr->unTimerId,
                                         &uiEcode );
              if( cRet == IFX_RTP_FAIL )
              {
                IFX_DBGA( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                          "<Stack> Start Timer Failure" );
              }
            }
          }  
          iNoOfFds--;
          continue;
        }
   }
   IFX_RTP_RtcpShut();
   IFX_RTP_CloseSocket(v_iRtpSockFd,&v_RdSelectFd);
   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      	    "<Session> Terminated successfully\n" );
   return IFX_RTP_SUCCESS;     
}

/******************************************************************
*  Function Name  :  IFX_RTP_SyncRecvPkt
*  Description    :  This function is entry point for an RTP/RTCP
*                    and blocks on pselect.
*  Input Values   :  none
*  Output Values  :  none
*  Return Value   :  void
*  Notes          :
*********************************************************************/
int32 IFX_RTP_SyncRecvPkt(void *pvRDFdSet,int32 *piNoFds)		  
{
   char8 *pcBuffer=NULL, cRet = IFX_RTP_FAIL;   
   uint16 nPktLen;
   uint32 uiEcode;
   double64 diInterval = 0.0;
   IFX_RTP_fd_set *pxRDFdSet = (IFX_RTP_fd_set *) pvRDFdSet;
   x_IFX_RTP_PacketSourceInfo xRemoteAddr;
   x_IFX_RTP_ConnInfo *pxConnPtr,*pxTempConnPtr;
   x_IFX_RTP_INT_MSG xIntMsg;
           
   pxConnPtr = vpxRtpConnHeadPtr;
   if(pxConnPtr == NULL)
   {
     return IFX_RTP_FAIL;
   }
   if(IFX_RTP_FdIsSet(v_iRtpSockFd,pxRDFdSet))
   {
	  *piNoFds=*piNoFds-1;
		 nPktLen = IFX_RTP_RecvNwPkt(v_iRtpSockFd,(char8 *)&xIntMsg, \
                                 sizeof(x_IFX_RTP_INT_MSG),&xRemoteAddr);
     if( (xIntMsg.eIntMsgType == IFX_RTP_EMRGCY_RSTRT_RTCP_TIMER) ||
         (xIntMsg.eIntMsgType == IFX_RTP_RSTRT_RTCP_TIMER) )
     {
       if( ((x_IFX_RTP_Session *) xIntMsg.uiSessPtr)->ucIsRtcpEnable)
       {
         pxConnPtr = (x_IFX_RTP_ConnInfo *) xIntMsg.uiConnPtr;
         if(xIntMsg.eIntMsgType == IFX_RTP_EMRGCY_RSTRT_RTCP_TIMER)
         {
           diInterval = 100.0; 
         }
         else
         {
           diInterval = IFX_RTP_GetRtcpTxInterval(pxConnPtr);
         }
         IFX_RTP_StopTimer(pxConnPtr->unTimerId);
         cRet = IFX_RTP_StartTimer( (uint32) diInterval,
                                    (void *) IFX_RTP_ProcessRtcpInfo,
                                    (void *) pxConnPtr,
                                    &pxConnPtr->unTimerId,
                                    &uiEcode );
         if( cRet == IFX_RTP_FAIL )
         {
           IFX_DBGA( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "<Stack> Start Timer Failure" );
         }
       }
     }  
	  if(*piNoFds == 0){  
       return cRet;
	  }
   }
   pxTempConnPtr = pxConnPtr = vpxRtpConnHeadPtr;
   while(pxConnPtr != NULL)
   {
      __ifx_list_GetNext((void*)(&pxTempConnPtr));
      if((pxConnPtr->iRtpFd) &&(IFX_RTP_FdIsSet(pxConnPtr->iRtpFd,pxRDFdSet)))
      {
         IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
       	          "<Session> RTP Packet Frm Network\n" );
        *piNoFds=*piNoFds-1; 
				if (pxConnPtr->xCB.pfnAllocMemForRtpPkt != NULL)
				 {
            pxConnPtr->xCB.pfnAllocMemForRtpPkt(pxConnPtr->uiSessOwner,
                                            pxConnPtr->pvUserData,
                                            (char8**)&pcBuffer);
         }
				 else
				 {

            IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             	     "<Session> Memory Allocater CallBack is NULL \n" );
					 return IFX_RTP_FAIL;
				 }
         nPktLen = IFX_RTP_RecvNwPkt(pxConnPtr->iRtpFd,pcBuffer, \
                                     IFX_RTP_MAX_BUFF_SIZE,&xRemoteAddr );
         if( nPktLen <= 0 )
         {
           IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "<Session> Read NW RTP fail\n" );
           break;
         }
         cRet = IFX_RTP_ProcessDownstreamRtpPkt((x_IFX_RTP_Session*)
                   pxConnPtr->uiSessOwner,pxConnPtr,pcBuffer,
                   &nPktLen,&xRemoteAddr );
         if(cRet == IFX_RTP_FAIL)
         {
            IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               	   "<Session> Process NW RTP Failure\n" );
         }
	      if(*piNoFds == 0){  
           break;
			  }
      }
      else if((pxConnPtr->iRtcpFd) &&(IFX_RTP_FdIsSet(pxConnPtr->iRtcpFd,pxRDFdSet)))
      {
          IFX_DBGA(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           	   "<Session> Process NW RTCP \n" );
					*piNoFds=*piNoFds-1;
					if (pxConnPtr->xCB.pfnAllocMemForRtcpPkt != NULL)
          {
             pxConnPtr->xCB.pfnAllocMemForRtcpPkt(pxConnPtr->uiSessOwner,
                                            pxConnPtr->pvUserData,
                                            (char8**)&pcBuffer);
          }
					else{
            IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             	     "<Session> Memory Allocater CallBack is NULL \n" );
						return IFX_RTP_FAIL;
					}
          nPktLen = IFX_RTP_RecvNwPkt(pxConnPtr->iRtcpFd,pcBuffer, \
                                      IFX_RTP_MAX_BUFF_SIZE,&xRemoteAddr);
          if(nPktLen <= 0)
          {
            IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             	     "<Session> recv NW RTCP fail\n" );
            break;
          }
          cRet = IFX_RTP_ProcessDownstreamRtcpPkt((x_IFX_RTP_Session*)
                    pxConnPtr->uiSessOwner,pxConnPtr,pcBuffer,nPktLen,
                    &xRemoteAddr );
          if(cRet == IFX_RTP_FAIL)
          {
            IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               	     "<Session> Process NW RTCP failure\n" );
          }
	        if(*piNoFds == 0)
			    {  
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               	     "Fds zero\n" );
            break;
			    }
      }
		  pxConnPtr = pxTempConnPtr;
   }
nPktLen=(uint16)*piNoFds;	
   return cRet;
}
/*******************************************************************
*  Function Name        :  IFX_RTP_RtpShut
*  Description          :  This function is called by the UA
*                          and shuts the RTP module
*  Input Values         :  none
*  Output Values        :  none
*  Return Value         :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                :
*********************************************************************/
PUBLIC int8 IFX_RTP_RtpShut( void )
{
   if( viStackMode == IFX_RTP_SYNC_MODE )
   {
     if(vxSyncCallBks.pfnRemoveFDFromSelect != NULL)
     {
       vxSyncCallBks.pfnRemoveFDFromSelect(NULL,0,0,v_iRtpSockFd);
     }
     IFX_RTP_Close(v_iRtpSockFd);
   }
   else
   {
     IFX_RTP_ShutRtpThread();
   }
   return IFX_RTP_SUCCESS;
}



/*********************************************************************
*  Function Name        :  IFX_RTP_StackCfg
*  Description          :  This function is used to configure stack params
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                :
***********************************************************************/
PUBLIC int32 IFX_RTP_StackCfg(uchar8 ucDbgLvl,uchar8 ucDbgType)
{
  static char8 ucFirstTime =0;
  if ( ucFirstTime == 0)
  {
   int8 cRet = IFX_RTP_SUCCESS;
   IFX_DBG_Init(IFX_IPC_APP_NAME_RTP,ucDbgType, ucDbgLvl, &vcRtpModId, &cRet);
   if (cRet != IFX_RTP_SUCCESS)
   {
     return IFX_RTP_FAIL;
   }
   ucFirstTime++;
  }
  else
  {
     IFX_DBG_Set(IFX_IPC_APP_NAME_RTP,vcRtpModId,ucDbgType,ucDbgLvl);
  }
  return IFX_RTP_SUCCESS;
}

/*********************************************************************
*  Function Name        :  IFX_RTP_Init
*  Description          :  This function is used to init stack
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  IFX_RTP_SUCCESS/IFX_RTP_FAIL/ThreadId in case
*                          Stack operated in Async mode.
*  Notes                :
***********************************************************************/
int32 IFX_RTP_Init(int32 iStackMode, x_IFX_RTP_SyncCallBks *pxSyncCallBks,
                   int32 iRtpInternalPort)
{

  viStackMode = iStackMode;
  viRtpInternalPort = iRtpInternalPort;
#ifdef THREAD_SAFE
  if( IFX_RTP_MutexAction(IFX_RTP_MUTEX_INIT,0) == IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }        
#endif  
  /* Open an Internal socket for communication */
  if( IFX_RTP_OpenUdpSocket(&v_iRtpSockFd,"127.0.0.1",viRtpInternalPort)
        != IFX_RTP_SUCCESS )
  {
    return IFX_RTP_FAIL;
  }
  if(iStackMode == IFX_RTP_ASYNC_MODE)
  {
    int32 iRetVal = IFX_RTP_SUCCESS;
    #ifdef __IMSENV__
      IFX_RTP_Main();
    #else
    if ((iRetVal =
         IFX_RTP_CreateThread((void *)IFX_RTP_Main)) == IFX_RTP_FAIL) 
    {
      IFX_DBGC(vcRtpModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "RTP stack Thread Creation Error");
      return IFX_RTP_FAIL;
    }
    #endif
    return iRetVal;
  }
  else if(iStackMode == IFX_RTP_SYNC_MODE)
  {
    IFX_RTP_RtcpInit();
    memcpy(&vxSyncCallBks,pxSyncCallBks,sizeof(x_IFX_RTP_SyncCallBks));
    if(vxSyncCallBks.pfnAddFDToSelect != NULL)
    {
      vxSyncCallBks.pfnAddFDToSelect(NULL,0,0,v_iRtpSockFd);
    }
  }
  return IFX_RTP_SUCCESS;
}
/*********************************************************************
*  Function Name        :  IFX_RTP_SessRegisterAddOn
*  Description          :  This function is used to Register Addon Pkg
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  Session Identifier
*  Notes                :
***********************************************************************/
void
IFX_RTP_SessRegisterAddOn(IN uint32 uiSessionId,
                          IN e_IFX_RTP_AddOnType eType,
                          IN x_IFX_RTP_AddOnCallBks *pxAddOnCallbk)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) uiSessionId;
  x_IFX_RTP_ConnInfo *pxConn;
  
  pxSess->ucNoOfAddOnReg++;
  pxConn = pxSess->pxConnListHeadPtr->pxConn;
  memcpy(&pxConn->xAddOnCB[eType],pxAddOnCallbk,sizeof(x_IFX_RTP_AddOnCallBks));
}
/*********************************************************************
*  Function Name        :  IFX_RTP_SessSetAddOnProcAidData
*  Description          :  This function is used to Register Addon Pkg
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  Session Identifier
*  Notes                :
***********************************************************************/
void
IFX_RTP_SessSetAddOnProcAidData(IN uint32 uiSessionId,
                          IN e_IFX_RTP_AddOnType eType,
                          IN void *pvProcAidData)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) uiSessionId;
  x_IFX_RTP_ConnInfo *pxConn;

  pxSess->ucNoOfAddOnReg++;
  pxConn = pxSess->pxConnListHeadPtr->pxConn;
  pxConn->pvAddonProcAidData[eType]= pvProcAidData;
}
/*********************************************************************
*  Function Name        :  IFX_RTP_SessCreate
*  Description          :  This function is used to create a session
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  Session Identifier
*  Notes                :
***********************************************************************/
uint32
IFX_RTP_SessCreate(IN uchar8 ucIsRtpEnable,
                   IN uchar8 ucIsRtcpEnable,
                   IN void *pvUserData,
                   IN x_IFX_RTP_CallBks *pxCallBks)
{
  x_IFX_RTP_Session *pxSess;
  x_IFX_RTP_ConnInfo *pxConn;

#ifdef THREAD_SAFE
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_LIST, 0) == IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }
#endif

  pxSess = (x_IFX_RTP_Session *) IFX_RTP_CreateSessNode();
  pxConn = pxSess->pxConnListHeadPtr->pxConn;
  pxConn->pvUserData = pvUserData;
  pxSess->ucIsRtpEnable = ucIsRtpEnable;
  pxSess->ucIsRtcpEnable = ucIsRtcpEnable;

  /* Generate SSRC */
  pxSess->uiTxSSRC = IFX_MD5_GetRandomValue();
  IFX_RTP_GetHostByName(pxSess->xTxSrcDesc.acCanName, IFX_RTCP_SDES_TEXT_LEN);

  if( pxCallBks != NULL )
  {
    /* Copy the call backs to connection */
    memcpy(&pxConn->xCB,pxCallBks,sizeof(x_IFX_RTP_CallBks));
  }
  
#ifdef THREAD_SAFE
  IFX_RTP_MutexAction(IFX_RTP_MUTEX_ALLOC, (uint32) pxSess);
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_LIST, 0) == IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;       
  }
#endif
  
  return (uint32) pxSess;
}

/*********************************************************************
*  Function Name        :  IFX_RTCP_SessConfig
*  Description          :  This function is used to Confirure RTCP session
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  Session Identifier
*  Notes                :
**********************************************************************/
int32
IFX_RTCP_SessConfig(IN uint32 uiSessId,
                    IN uint32 uiOptions,
                    IN double64 diRtcpBw,
                    IN char8* pcRtcpTxAddr,
                    IN uint16 unTxPort,
                    IN char8* pcRtcpRxAddr,
                    IN uint16 unRxPort)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) uiSessId;
  x_IFX_RTP_ConnInfo *pxConn;
  x_IFX_RTP_INT_MSG xIntMsg;
  int32 iLocalIP;
  char8 cRet;
  
#ifdef THREAD_SAFE
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION, uiSessId) == IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }
#endif
  if(pxSess->pxConnListHeadPtr == NULL){
			return IFX_RTP_FAIL;
	}	

  pxConn = pxSess->pxConnListHeadPtr->pxConn;
  IFX_DBGA(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
               "<SessConfigure>session id is", uiSessId );
  /* This check has been removed since the TBCP, which is same as
   * RTCP operates on even port*/
  #ifndef __IMSENV__
  
  /* Ensure that ports are odd numbers */ 
  if( ((uiOptions & IFX_RTP_SET_TXPORT) && !(unTxPort&0x01)) ||
      ((uiOptions & IFX_RTP_SET_RXPORT) && !(unRxPort&0x01)) )
  {
#ifdef THREAD_SAFE
    IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, uiSessId);
#endif    
    return IFX_RTP_FAIL;
  }
  #endif
  /* Store the local and remote port Information */
  if(uiOptions & IFX_RTP_SET_TXADDR)
  {
    IFX_RTP_inet_pton(IFX_RTP_AF_INET, pcRtcpTxAddr,&pxConn->uiRemoteRtcpIP);
  }

  if(uiOptions & IFX_RTP_SET_TXPORT)
  {
    pxConn->unRemoteRtcpPort = unTxPort;
  }
  if(uiOptions & IFX_RTP_SET_RXPORT)
  {
    pxConn->unLocalRtcpPort = unRxPort;
  }
  /* Store the Local IP in network format */
  if(uiOptions & IFX_RTP_SET_RXADDR)
  {
    IFX_RTP_inet_pton(IFX_RTP_AF_INET, pcRtcpRxAddr,&pxSess->uiLocalRtcpIpAddr);
  }
  /* Store RTCP Bandwidth*/
  if(uiOptions & IFX_RTCP_SET_BW)
  {
    pxSess->diRtcpBw = diRtcpBw;
  }
  /* Internal RTCP statistics calculations */
  if( (uiOptions & IFX_RTCP_SET_INTSTATCALC) && (pxSess->ucIsRtcpEnable))
  {
    pxSess->ucIntRtcpStatCalc = 1;
  }
  if( (pxSess->ucIsRtcpEnable) && (pxSess->diRtcpBw) && 
      (pxConn->uiRemoteRtcpIP) && (pxConn->iRtpFd) )
  { 
    xIntMsg.eIntMsgType = IFX_RTP_RSTRT_RTCP_TIMER;
    xIntMsg.uiSessPtr = (uint32) pxSess;
    xIntMsg.uiConnPtr = (uint32) pxConn;
    IFX_RTP_inet_pton(IFX_RTP_AF_INET,IFX_RTP_INTERNAL_IP,&iLocalIP);
    cRet = IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,
                            sizeof(x_IFX_RTP_INT_MSG),
                            iLocalIP,viRtpInternalPort);
    if( cRet == IFX_RTP_FAIL )
    {
      IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<Stack> Send to Internal socket Failure" );
#ifdef THREAD_SAFE
      IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, uiSessId);
#endif   
      return IFX_RTP_FAIL;
    }
  }
  
#ifdef THREAD_SAFE
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, uiSessId)==IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }
#endif
      
  return IFX_RTP_SUCCESS;

}
/*********************************************************************
*  Function Name        :  IFX_RTP_SessConfig
*  Description          :  This function is used to Confirure a session
*  Input Values         :  void
*  Output Values        :  none
*  Return Value         :  Session Identifier
*  Notes                :
***********************************************************************/
int32
IFX_RTP_SessConfig(uint32 uiSessId,
                   uint32 uiOptions,
                   uchar8 ucMode,
                   uchar8* pcRtpTxAddr,
                   uint16 unTxPort,
                   uchar8* pcRtpRxAddr,
                   uint16 unRxPort)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) uiSessId;
  x_IFX_RTP_ConnInfo *pxConn;
  if(pxSess->pxConnListHeadPtr == NULL){
			return IFX_RTP_FAIL;
	}	
  pxConn = pxSess->pxConnListHeadPtr->pxConn;  
  IFX_DBGA(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
               "<SessConfigure>session id is", uiSessId );
#if 0
  /* Ensure that ports are even numbers */
  if( ((uiOptions & IFX_RTP_SET_TXPORT) && (unTxPort&0x01)) || 
      ((uiOptions & IFX_RTP_SET_RXPORT) && (unRxPort&0x01)) )
  {
    return IFX_RTP_FAIL;
  }
#endif	
  /*TODO: Handling 0.0.0.0 address not taken care yet
         and decide on starting and stoping RTCP session*/

  /* Store the local and remote port Information */
  if (uiOptions & IFX_RTP_SET_TXADDR)
  {
    IFX_RTP_inet_pton(IFX_RTP_AF_INET, (char8 *)pcRtpTxAddr,&pxConn->uiRemoteIP);
  }
  if (uiOptions & IFX_RTP_SET_TXPORT)
  {
    pxConn->unRemoteRtpPort = unTxPort;
  }

  if (uiOptions & IFX_RTP_SET_RXPORT)
  {
    pxConn->unLocalPort = unRxPort;
  }

  /* Store the Local IP in network format */
  if ( uiOptions & IFX_RTP_SET_RXADDR)
  {
    IFX_RTP_inet_pton(IFX_RTP_AF_INET, (char8 *)pcRtpRxAddr,&pxSess->uiLocalIpAddr);
  }
  if (uiOptions & IFX_RTP_SET_MODE)
  {
    pxConn->ucConnMode = ucMode;
    if((viStackMode == IFX_RTP_ASYNC_MODE) && (pxConn->iRtpFd))
    {
      IFX_RTP_FdClear(pxConn->iRtpFd,&v_RdSelectFd);
      if(ucMode != IFX_RTP_SEND_ONLY)
      {
        /* Send the FD's to the RTP internal socket*/
        IFX_RTP_FdSet(pxConn->iRtpFd,&v_RdSelectFd);
      }
    }
  }
  return IFX_RTP_SUCCESS;
}
/*********************************************************************
*  Function Name        :  IFX_RTP_SessOpen
*  Description          :  This function is used to Open a session
*  Input Values         :  iSessId is the session Identifier
*  Output Values        :  none
*  Return Value         :  Session Identifier
*  Notes                :
***********************************************************************/
int32
IFX_RTP_SessOpen(uint32 uiSessId)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)uiSessId;
  x_IFX_RTP_ConnInfo *pxConn;
  char8 cRet = IFX_RTP_SUCCESS;
  char8 acIpAddr[128];
  x_IFX_RTP_INT_MSG xIntMsg;
  int32 iLocalIP;
  pxConn = pxSess->pxConnListHeadPtr->pxConn;  
  IFX_DBGA(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
               "<SessOpen>session id is", uiSessId );

  /* create UDP socket for RTP/RTCP */
#ifdef UDP_REDIRECT	
	pxConn->iRtpFd = 0;
#else	
  if (pxSess->ucIsRtpEnable)
  {		
    IFX_RTP_inet_ntop(IFX_RTP_AF_INET,(void *)&pxSess->uiLocalIpAddr,
                      acIpAddr,128);
    cRet = IFX_RTP_OpenUdpSocket(&pxConn->iRtpFd,acIpAddr,
                                 pxConn->unLocalPort);
    if(cRet == IFX_RTP_FAIL)
    {
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error Creating UDP Sock" );
      return IFX_RTP_FAIL;
    }
  }
#endif

#ifdef __IMSENV__
	/* Set the connection id for the created socket.*/
    if(e_Mmb_ErrOk != Mmb_IpStackSetSockId(pxConn->iRtpFd, pxConn->uiPoCSessId))
    {
    	return IFX_RTP_FAIL;
	}
    /* Select will be updated in the end */  
    if(pxConn->iRtpFd != 0){
      IFX_RTP_FdClear(pxConn->iRtpFd,&v_RdSelectFd);
    }
    if(IFX_RTP_SEND_ONLY != pxConn->ucConnMode){
      /* Send the FD's to the RTP internal socket*/
      IFX_RTP_FdSet(pxConn->iRtpFd,&v_RdSelectFd);
    }
#endif

  if (pxSess->ucIsRtcpEnable)
  {
    IFX_RTP_inet_ntop(IFX_RTP_AF_INET,(void *)&pxSess->uiLocalRtcpIpAddr,
                       acIpAddr,128);
    cRet = IFX_RTP_OpenUdpSocket(&pxConn->iRtcpFd,acIpAddr,
                                 pxConn->unLocalRtcpPort);
    if(cRet == IFX_RTP_FAIL){
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error Creating UDP Sock");
      return IFX_RTP_FAIL;
    }
#ifdef __IMSENV__
	/* Set the connection id for the created socket.*/
    if(e_Mmb_ErrOk != Mmb_IpStackSetSockId(pxConn->iRtcpFd, pxConn->uiPoCSessId))
    {
    	return IFX_RTP_FAIL;
	}
    /* Send the FD's to the RTP internal socket*/
    IFX_RTP_FdSet(pxConn->iRtcpFd,&v_RdSelectFd);
#endif

    cRet = IFX_RTP_RtcpStartSession(pxSess);
    if(cRet == IFX_RTP_FAIL)
    {
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error Starting RTCP Session");
      return IFX_RTP_FAIL;
    }
  }

  /*Call the Call backs*/
  if(pxSess->ucNoOfAddOnReg)
  {
    int32 i=0;
    for ( i= 0; i< IFX_RTP_MAX_ADD_ON;i++)
    {
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "Calling the Call back");

      if (pxConn->xAddOnCB[i].pfnOpenSession != NULL)
      {
         pxConn->xAddOnCB[i].pfnOpenSession((uint32)pxSess,
                                            &pxConn->pvAddonUserData[i]);
      }
    }
  }

  if (viStackMode == IFX_RTP_SYNC_MODE)
  {
    if(vxSyncCallBks.pfnAddFDToSelect != NULL)
    {
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "Adding FD to select");
       vxSyncCallBks.pfnAddFDToSelect(pxConn->pvUserData,pxConn->iRtpFd,
                                      pxConn->iRtcpFd, v_iRtpSockFd);
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "After Adding FD to select");
    }
  } 
  else
  {
    if(pxConn->iRtpFd)
    {
      if(pxConn->ucConnMode != IFX_RTP_SEND_ONLY)
      {
        /* Send the FD's to the RTP internal socket*/
        IFX_RTP_FdSet(pxConn->iRtpFd,&v_RdSelectFd);
      }
    }
    if(pxConn->iRtcpFd)
    {
      /* Send the FD's to the RTP internal socket*/
      IFX_RTP_FdSet(pxConn->iRtcpFd,&v_RdSelectFd);
    }
	xIntMsg.eIntMsgType = IFX_RTP_ADD_SOCK_FD;
    xIntMsg.uiSessPtr = (uint32) pxSess;
    xIntMsg.uiConnPtr = (uint32) pxConn;
    IFX_RTP_inet_pton(IFX_RTP_AF_INET,IFX_RTP_INTERNAL_IP,&iLocalIP);
    cRet = IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,
                            sizeof(x_IFX_RTP_INT_MSG),
                            iLocalIP,viRtpInternalPort);
    if( cRet == IFX_RTP_FAIL )
    {
      IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<Stack> Send to Internal socket Failure" );
      return IFX_RTP_FAIL;
    }
  }        
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "Returning from SessOpen");
  return cRet;
}
/******************************************************************
*  Function Name  :  IFX_RTP_SessClose
*  Description    :  This function Closes the current connection
*  Input Values   :  iSessId
*  Output Values  :  none
*  Return Value   :  void
*  Notes          :
*********************************************************************/
int32
IFX_RTP_SessClose(uint32 uiSessId)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)uiSessId;
  char8 cRet;
  int32 iLocalIP;
  x_IFX_RTP_INT_MSG xIntMsg;

	pxSess->iFlags=1;
  
  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_RTP_STR_PRINT,
               "<SessClose>Closing session id ", uiSessId );

  if(pxSess->pxConnListHeadPtr != NULL)
  {
    cRet = IFX_RTP_StopTimer(pxSess->pxConnListHeadPtr->pxConn->unTimerId);    
    if(cRet == IFX_RTP_FAIL)
    {
      return cRet;
    }
  }
  
  if(viStackMode == IFX_RTP_SYNC_MODE)
  {
    cRet = IFX_RTP_RemoveSess(pxSess);
  }
  else
  {
    xIntMsg.eIntMsgType = IFX_RTP_REM_SESS;
    xIntMsg.uiSessPtr = (uint32) pxSess;
    IFX_RTP_inet_pton(IFX_RTP_AF_INET,IFX_RTP_INTERNAL_IP,&iLocalIP);
    cRet = IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,
                            sizeof(x_IFX_RTP_INT_MSG),
                            iLocalIP,viRtpInternalPort);
  }
#ifdef THREAD_SAFE
  /* Keep trying to destroy the mutex when its available */
  //while( IFX_RTP_MutexAction(IFX_RTP_MUTEX_FREE, uiSessId) == IFX_RTP_FAIL );
  IFX_RTP_MutexAction(IFX_RTP_MUTEX_FREE, uiSessId);
#endif
  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
            "Returning from Session Close" );
  return cRet;
}
/*********************************************************************
*  Function Name        :  IFX_RTP_SessSendRawPkt
*  Description          :  This function is used to send Constructed RTP packet to
                           the destination set for the session
*  Input Values         :  iSessId - is the session ID
*                          pcBuffStart - Start of the buffer
*                          iBuffSize - size of the buffer
*                          uiTimeStamp - Timestamp in the RTP header
*  Output Values        :  none
*  Return Value         :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                :
***********************************************************************/
char8
IFX_RTP_SessSendRawPkt(IN uint32 uiSessId,
                       IN char8 *pcBuffStart,
                       IN int16 nBuffSize)
{
  int32 iCount;
  int8 cRet=IFX_RTP_FAIL;
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *)uiSessId;
  x_IFX_RTP_ConnList *pxConnList;
  x_IFX_RTP_ConnInfo *pxConn;

  pxConnList = pxSess->pxConnListHeadPtr;
  IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
           "session id is", uiSessId );
  if( pxConnList != NULL )
  {
    pxConn = pxConnList->pxConn;
    /*Call the Call backs*/
    if (pxSess->ucNoOfAddOnReg)
    {
      for (iCount=0; iCount< IFX_RTP_MAX_ADD_ON;iCount++)
      {
        if (pxConn->xAddOnCB[iCount].pfnBeforeRtpSend != NULL)
        {
          pxConn->xAddOnCB[iCount].pfnBeforeRtpSend((uint32)pxSess,
                                   pxConn->pvAddonUserData[iCount],
                                   pcBuffStart,&nBuffSize,
                                   pxConn->pvAddonProcAidData[iCount]);
        }
      }
    }
    if(pxConn->unRemoteRtpPort)
    {
      cRet = IFX_RTP_ProcessUpstreamRtpPkt(pxSess, pxConn, pcBuffStart, nBuffSize);
      if(cRet == IFX_RTP_FAIL)
      {
        IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "<Session> Process DSP Pkt Fail\n" );
      }
    }
  }

  return cRet;
}

/*********************************************************************
*  Function Name        :  IFX_RTP_SessSendRtpPkt
*  Description          :  This function is used to send RTP packet to
                           the destination set for the session
*  Input Values         :  iSessId - is the session ID
*                          pcBuffStart - Start of the buffer
*                          iBuffSize - size of the buffer
*                          pcDataStart - Start of the Data
*                          iDataSize - Size of data
*                          bMarker - Set or reset the marker bit
*                          ucPT - Payload to be set
*                          uiTimeStamp - Timestamp in the RTP header
*  Output Values        :  none
*  Return Value         :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                :
***********************************************************************/
char8
IFX_RTP_SessSendRtpPkt(IN uint32 uiSessId,
                       IN char8 *pcBuffStart,
                       IN int16 nBuffSize,
                       IN char8 *pcDataStart,
                       IN int32 iDataSize,
                       IN char8 bMarker,
                       IN uchar8 ucPT,
                       IN int32 uiTimeStamp,
                       IN uint16 unIsExtnBitSet)
{
  int32 i;
  char8 cRet;
#ifdef RTP_PAYLOAD_PADDING
  char8 acPad[3]={'\0','\0','\0'};
#endif  
  int16 nPktSize = 0;
  x_IFX_RTP_Session *pxSess  = (x_IFX_RTP_Session *)uiSessId;
  x_IFX_RTP_ConnList *pxConnList;
  x_IFX_RTP_Header *pxRtpPkt = (x_IFX_RTP_Header *)pcBuffStart;
  x_IFX_RTP_ConnInfo *pxConn;

  pxConnList = pxSess->pxConnListHeadPtr; 
  if(pxConnList ==NULL){
		return IFX_RTP_FAIL;
  }
	if(pxConnList->pxConn == NULL){
		return IFX_RTP_FAIL;
	}
  if( ((iDataSize + 12) > nBuffSize) || (!pxConnList->pxConn->unRemoteRtpPort) )
  {
    return IFX_RTP_FAIL;
  }

  /* Construct the RTP header */
  pxRtpPkt->unVer = IFX_RTP_VERSION;
  pxRtpPkt->unExtnFlag = unIsExtnBitSet;
  pxRtpPkt->unMarkerBit = bMarker;
  pxRtpPkt->uiTimeStamp = IFX_RTP_Htonl(uiTimeStamp);
  pxRtpPkt->uiSSRC = IFX_RTP_Htonl(pxSess->uiTxSSRC);
  pxRtpPkt->unPadFlag = 0;
  pxRtpPkt->unPT = ucPT & 0x7f;

  nPktSize += 12;

  /* Handle CSRC information */
  pxRtpPkt->unCsrcCount = pxSess->ucNoConns - 1;
  for (i = 1 ;i<IFX_RTP_MAX_CONNS && i< pxSess->ucNoConns; i++)
  {
    if( (nPktSize + 4) > nBuffSize )
    {
      return IFX_RTP_FAIL;
    }
    pxRtpPkt->auiCSRC[i] = pxSess->auiCsrcList[i];
    nPktSize += 4;
  }

  /* Add all buffer information */
  if((nPktSize + iDataSize) > nBuffSize)
  {
     return IFX_RTP_FAIL;
  }
  memcpy((pcBuffStart+ nPktSize), pcDataStart,iDataSize);

  nPktSize += iDataSize;
#ifdef RTP_PAYLOAD_PADDING
  /* Adjust padding for data */
  if( iDataSize % 4 )
  { 
    i=4-(iDataSize % 4);
    if(nPktSize+ i > nBuffSize)
    {
      return IFX_RTP_FAIL;
    }
    acPad[i-1]=i;
    memcpy((pcBuffStart+ nPktSize),acPad,i);
    pxRtpPkt->unPadFlag = 1;
    nPktSize += i;
  }
#endif
  pxConn = pxConnList->pxConn;
  pxConn->unSeqNum ++;
  pxRtpPkt->unSeqNum = IFX_RTP_Htons(pxConn->unSeqNum);

  /*Call the Call backs*/
  if (pxSess->ucNoOfAddOnReg)
  {
      for (i=0; i< IFX_RTP_MAX_ADD_ON;i++)
      {
        if (pxConn->xAddOnCB[i].pfnBeforeRtpSend != NULL)
        {
          pxConn->xAddOnCB[i].pfnBeforeRtpSend((uint32)pxSess,
                                               pxConn->pvAddonUserData[i],
                                               pcBuffStart,&nPktSize,
                                               pxConn->pvAddonProcAidData[i]);
        }
      }
  }
  cRet = IFX_RTP_ProcessUpstreamRtpPkt(pxSess,pxConn, pcBuffStart,nPktSize);
  if(cRet == IFX_RTP_FAIL){
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<Session> Process DSP Pkt Fail\n" );
      return IFX_RTP_FAIL;
  }
  return IFX_RTP_SUCCESS;
}

/******************************************************************************
*  Function Name  : IFX_RTP_SessSendRtcpPkt
*  Description    : Send RTCP packets out of regular RTCP packets sequence
*  Input Values   : Session and packet type bits
*  Output Values  : none
*  Return Value   : void
*  Notes          : if compound pkt to be sent perform a bit or of rtcp packets
*******************************************************************************/
int32
IFX_RTP_SessSendRtcpPkt(IN uint32 uiSessionId,
                        IN uchar8 ucType,IN void* vpUserPlugInData)
{
  int32 iRet;
#ifdef THREAD_SAFE
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_ALL_SESSIONS, uiSessionId) == 
                         IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }
#endif
    
  iRet = IFX_RTP_SendRtcpReport( (x_IFX_RTP_Session *)  uiSessionId,
           ((x_IFX_RTP_Session*) uiSessionId)->pxConnListHeadPtr->pxConn,
           ucType,vpUserPlugInData);
  
#ifdef THREAD_SAFE
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_ALL_SESSIONS, uiSessionId) == 
                         IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }
#endif  
  return iRet;
}
/******************************************************************
*  Function Name  : IFX_RTP_SessGetRtpSequenceNum
*  Description    : Get the sequence number of the session
*  Input Values   : uiSessionId - Session Identifier
*  Output Values  : None
*  Return Value   : Sequence number for this session
*  Notes          :
*********************************************************************/
int32
IFX_RTP_SessGetRtpSequenceNum(IN uint32 uiSessionId)
{
  return ((x_IFX_RTP_Session*)uiSessionId)->pxConnListHeadPtr->pxConn->unSeqNum;
}
/******************************************************************
*  Function Name  : IFX_RTP_SessGetSsrc
*  Description    : Get the SSRC of the session
*  Input Values   : uiSessionId is the session Identifier
*  Output Values  : None
*  Return Value   : SSRC of the session
*  Notes          :
*********************************************************************/
uint32
IFX_RTP_SessGetSsrc(IN uint32 uiSessionId)
{
  uint32 uiRet;
  uiRet = ((x_IFX_RTP_Session*) uiSessionId)->uiTxSSRC;
  return uiRet;  
}
/******************************************************************
*  Function Name  : IFX_RTP_SessSetSsrc
*  Description    : Set the SSRC of the session
*  Input Values   : uiSessionId is the session Identifier
*  Output Values  : None
*  Return Value   : SSRC of the session
*  Notes          :
*********************************************************************/
void
IFX_RTP_SessSetSsrc(IN uint32 uiSessionId,uint32 uiSsrc)
{
  ((x_IFX_RTP_Session*) uiSessionId)->uiTxSSRC=uiSsrc;
}
/******************************************************************
*  Function Name  : IFX_RTP_SessGetRtcpFooterSize
*  Description    : Get the footer size of the RTCP packet
*  Input Values   : uiSessionId is the session identifierr
*  Output Values  : none
*  Return Value   : Footer size
*  Notes          :
*********************************************************************/
int32
IFX_RTP_SessGetRtcpFooterSize(IN uint32 uiSessionId)
{
  x_IFX_RTP_ConnInfo *pxConn;
  int32 iLen =0,i;  
 
  pxConn = ((x_IFX_RTP_Session*) uiSessionId)->pxConnListHeadPtr->pxConn;
  for (i=0;i<IFX_RTP_MAX_ADD_ON;i++)
  {
    if (pxConn->xAddOnCB[i].iRtcpFooterSize > 0)
    {
      iLen += pxConn->xAddOnCB[i].iRtcpFooterSize;
    }
  }

  return iLen;
}
/******************************************************************
*  Function Name  : IFX_RTP_SessGetRtcpHeaderSize
*  Description    : Get the Header size of the RTCP header
*  Input Values   : uiSessionId is the session Identifier
*  Output Values  : None
*  Return Value   : Header size
*  Notes          :
*********************************************************************/
int32
IFX_RTP_SessGetRtcpHeaderSize(IN uint32 uiSessionId)
{
  return sizeof(x_IFX_RTCP_Header);
}
/******************************************************************
*  Function Name  : IFX_RTP_SessGetRtpFooterSize
*  Description    : Get the footer size of the RTP header
*  Input Values   : uiSession Id is the session Identifier
*  Output Values  : None
*  Return Value   : RTP footer size
*  Notes          :
*********************************************************************/
int32
IFX_RTP_SessGetRtpFooterSize(IN uint32 uiSessionId)
{
  x_IFX_RTP_ConnInfo *pxConn;
  int32 iLen =0,i;

  pxConn = ((x_IFX_RTP_Session*) uiSessionId)->pxConnListHeadPtr->pxConn;
  for (i=0;i<IFX_RTP_MAX_ADD_ON;i++)
  {
    if (pxConn->xAddOnCB[i].iRtpFooterSize > 0)
    {
      iLen += pxConn->xAddOnCB[i].iRtpFooterSize;
    }
  }

  return iLen;
}
/******************************************************************
*  Function Name  : IFX_RTP_SessAddToConfList
*  Description    : Add Session 2 to Session 1 conference List
*  Input Values   : Session 1 and Session 2
*  Output Values  :  none
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes          :
*********************************************************************/

int32
IFX_RTP_SessAddToConfList(IN uint32 uiSessionId1,
                          IN uint32 uiSessionId2)
{
  x_IFX_RTP_Session  *pxSess1 = (x_IFX_RTP_Session *) uiSessionId1,
                     *pxSess2 = (x_IFX_RTP_Session *) uiSessionId2;
  x_IFX_RTP_ConnInfo *pxConn1, *pxConn2;

#ifdef THREAD_SAFE
  char8 cRet1, cRet2;
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION,
                         MIN(uiSessionId1, uiSessionId2)) == IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  } 
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION,
                         (uint32) MAX(pxSess1, pxSess2)) == IFX_RTP_FAIL)
  {
    IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, (uint32) 
                        MIN(pxSess1, pxSess2));
    return IFX_RTP_FAIL;
  }
#endif
  

  pxConn1 = pxSess1->pxConnListHeadPtr->pxConn;
  pxConn2 = pxSess2->pxConnListHeadPtr->pxConn;  
  IFX_RTP_AddConnToSess(pxSess1,pxConn2);
  IFX_RTP_AddConnToSess(pxSess2,pxConn1);

#ifdef THREAD_SAFE
  cRet1 = IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, 
                              (uint32)MAX(pxSess1, pxSess2));
  cRet2 = IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, 
                              (uint32)MIN(pxSess1, pxSess2));
  if((cRet1 == IFX_RTP_FAIL) || (cRet2 == IFX_RTP_FAIL))
  {
    return IFX_RTP_FAIL;
  }
#endif  
  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name  :  IFX_RTP_SessRemoveFromConfList
*  Description    :  Remove Session2 from the Session 1 conference list
*  Input Values   :  SessionId1 and SessionId2
*  Output Values  :  none
*  Return Value   :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes          :
*********************************************************************/

int32
IFX_RTP_SessRemoveFromConfList(IN uint32 uiSessionId1,
                               IN uint32 uiSessionId2)
{
  x_IFX_RTP_Session  *pxSess1 = (x_IFX_RTP_Session *) uiSessionId1,
                     *pxSess2 = (x_IFX_RTP_Session *) uiSessionId2;
  x_IFX_RTP_ConnInfo *pxConn1, *pxConn2;

#ifdef THREAD_SAFE
  char8 cRet1, cRet2;
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION,
                         (uint32)MIN(pxSess1, pxSess2)) == IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  } 
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION,
                         (uint32)MAX(pxSess1, pxSess2)) == IFX_RTP_FAIL)
  {
    IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, 
                        (uint32)MIN(pxSess1, pxSess2));
    return IFX_RTP_FAIL;
  }
#endif
  

  pxConn1 = pxSess1->pxConnListHeadPtr->pxConn;
  pxConn2 = pxSess2->pxConnListHeadPtr->pxConn;  
  IFX_RTP_RemoveConnFromSess(pxSess1,pxConn2);
  IFX_RTP_RemoveConnFromSess(pxSess2,pxConn1);

#ifdef THREAD_SAFE
  cRet1 = IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, 
                              (uint32)MAX(pxSess1, pxSess2));
  cRet2 = IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, 
                              (uint32)MIN(pxSess1, pxSess2));
  if((cRet1 == IFX_RTP_FAIL) || (cRet2 == IFX_RTP_FAIL))
  {
    return IFX_RTP_FAIL;
  }
#endif  
  return IFX_RTP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_RTP_SessGetRtpHeaderSize
*  Description    : Get the size of the RTP header
*  Input Values   : uiSessionId is the session Identifier
*  Output Values  : None
*  Return Value   : Expected RTP header size
*  Notes          :
*********************************************************************/
int32
IFX_RTP_SessGetRtpHeaderSize(IN uint32 uiSessionId)
{
  uchar8 ucCC = ((x_IFX_RTP_Session *) uiSessionId)->ucNoConns;
  /* Header size = fixed header = 8 bytes + 4bytes * no. of SSRC/CSRC +*/
  return (8+4*ucCC);
}

/******************************************************************
*  Function Name  : IFX_RTP_SetSessPocSessId
*  Description    : Set the PoC Session ID for the socket
*  Input Values   : uiSessionId is the session identifier,
*                   PocSessId
*  Output Values  : None
*  Return Value   : None
*  Notes          :
*********************************************************************/
void
IFX_RTP_SetSessPocSessId(IN uint32 uiSessionId,
                         IN uint32 uiPoCSessId)
{
  ((x_IFX_RTP_Session*) uiSessionId)->pxConnListHeadPtr->pxConn->uiPoCSessId = 
     uiPoCSessId;
}

/* Parse API's for ifx_rtp_pkt.h*/
/******************************************************************
*  Function Name  : IFX_RTP_GetRtpHeader
*  Description    : Gets the RTP header from the packet
*  Input Values   : Recived RTP packet
*  Output Values  : none
*  Return Value   : Pointer to RTP header
*  Notes          :
*********************************************************************/

x_IFX_RTP_Header *
IFX_RTP_GetRtpHeader(IN char8 *pszRtpPktBuff)
{
  return (x_IFX_RTP_Header *) pszRtpPktBuff;
}
/******************************************************************
*  Function Name  : IFX_RTP_GetRtpExtnHdr
*  Description    : Gets the RTP Extnsion header
*  Input Values   : Recived packet
*  Output Values  : length of the extension header
*  Return Value   : Pointer to extention header / NULL
*  Notes          :
*********************************************************************/
char8 *
IFX_RTP_GetRtpExtnHdr(IN char8 *pszRtpPktBuff,
                      OUT uint16 *punLength)
{
  char8 *pExtn = NULL;
  x_IFX_RTP_Header *pxRtpHdr = (x_IFX_RTP_Header *) pszRtpPktBuff;

  *punLength = 0;
  if ( pxRtpHdr->unExtnFlag)
  {
    uchar8 ucCC = pxRtpHdr->unCsrcCount;
    /* Extn header is at offset = 8 bytes fixed header + 4 bytes SSRC + 
                                  4bytes * no. of CSRC */
    pExtn =( pszRtpPktBuff+(12+4*ucCC));
    *punLength = htons(*((uint16*)(pExtn+2)));
  }
  return pExtn;

}
/******************************************************************
*  Function Name  : IFX_RTP_GetRtcpHdr
*  Description    : Extracts RTCP header from the received RTCP Pkt
*  Input Values   : Received RTCP Pkt
*  Output Values  : none
*  Return Value   : Pointer to RTCP header
*  Notes          :
*********************************************************************/
x_IFX_RTCP_Header *
IFX_RTP_GetRtcpHdr(IN char8 *pszRtcpPktBuff)
{
  return (x_IFX_RTCP_Header *) pszRtcpPktBuff;
}

/******************************************************************
*  Function Name  : IFX_RTCP_SR_GetSenderInfo
*  Description    : Extract Sender info from the Sender report.
*  Input Values   : Received RTCP SR Report.
*  Output Values  : None.
*  Return Value   : Pointer to Sender Info / NULL
*  Notes          :
*********************************************************************/
x_IFX_RTCP_SR *
IFX_RTCP_SR_GetSenderInfo(IN char8 *pszRtcpPktBuff)
{
  x_IFX_RTCP_Header *pxRtcpPkt =(x_IFX_RTCP_Header*)pszRtcpPktBuff;
  if( pxRtcpPkt->ucPktType == IFX_RTCP_SR_PKT)
  {
    return (x_IFX_RTCP_SR *) (pszRtcpPktBuff+sizeof(x_IFX_RTCP_Header));
  }
  return NULL;
}

/******************************************************************
*  Function Name  : IFX_RTCP_RR_GetRepBlock
*  Description    : Get the Recipent Block from the SR or RR report
*  Input Values   : Received SR or RR report,Report Length and Block no
*  Output Values  : None
*  Return Value   : Pointer to Recipent Block / NULL
*  Notes          :
*********************************************************************/
x_IFX_RTCP_RR *
IFX_RTCP_RR_GetRepBlock(IN char8 *pszRtcpPktBuff,
                        IN int32 iPktLen,
                        IN int32 iRRBlockNo)

{
  x_IFX_RTCP_RR *pxTemp = NULL;
  x_IFX_RTCP_Header *pxRtcpPkt =(x_IFX_RTCP_Header*)pszRtcpPktBuff;

  if( pxRtcpPkt->ucPktType == IFX_RTCP_RR_PKT)
  {
       pxTemp =(x_IFX_RTCP_RR *)( pszRtcpPktBuff + sizeof(x_IFX_RTCP_Header)+
                4 + (iRRBlockNo - 1) * sizeof(x_IFX_RTCP_RR));
  }
  else if(pxRtcpPkt->ucPktType == IFX_RTCP_SR_PKT)
  {
    pxTemp = (x_IFX_RTCP_RR *)(pszRtcpPktBuff + sizeof(x_IFX_RTCP_Header)+
              sizeof(x_IFX_RTCP_SR)+ (iRRBlockNo - 1) * sizeof(x_IFX_RTCP_RR));
  }
  else
  {
    return NULL;
  }

  /* Ensure sufficient packet length */
  if( (uint32) pxTemp >= ((uint32) pszRtcpPktBuff + iPktLen))
  {
    return NULL;
  }

  return pxTemp;
}
/******************************************************************
*  Function Name  : IFX_RTCP_GetSDESItemFromChunk
*  Description    : Get the SDES item from the SDES chunk
*  Input Values   : pointer to SDES chunk,item name
*  Output Values  : none
*  Return Value   : pointer to SDES item / NULL
*  Notes          :
*********************************************************************/
STATIC x_IFX_RTCP_SdesItemBlock *
IFX_RTCP_GetSdesItemFromChunk(IN char8 *pcTemp,
                              IN e_IFX_RTCP_SDES_Item eSdesItem)
{
  char8 *pcDataPtr = pcTemp;
  uint32 iMaxChunkLen = IFX_RTCP_GET_SDES_Size(pcDataPtr),
         iCurChunkLen = 0;

  while((iMaxChunkLen > iCurChunkLen) &&
       (*pcDataPtr != IFX_RTCP_SDES_ITEM_END) &&
       (*pcDataPtr != eSdesItem))
  {
       iCurChunkLen += (2+*(pcDataPtr + 1));
       pcDataPtr    += (2+*(pcDataPtr + 1));
  }

  if(*pcDataPtr == IFX_RTCP_SDES_ITEM_END)
  {
    pcDataPtr = NULL;  /* Failure Condition */
  }

  return (x_IFX_RTCP_SdesItemBlock *) pcDataPtr;
}
/******************************************************************
*  Function Name  : IFX_RTCP_GET_SDES_Size
*  Description    : Get the SDES Size of the SDES chunk
*  Input Values   : SDES chunk
*  Output Values  : None
*  Return Value   : SDES chunk size
*  Notes          :
*********************************************************************/
int32
IFX_RTCP_GET_SDES_Size(IN char8 *pcTemp)
{
  int32 iLen;
  char8 *pcStartChunk = pcTemp, *pcDataPtr = pcTemp;

  while( *pcDataPtr != IFX_RTCP_SDES_ITEM_END )
  {
       pcDataPtr += (2+*(pcDataPtr + 1));
  }
  /* Adjust to next 4 byte boundary*/
  iLen = (((pcDataPtr - pcStartChunk + 3) >> 2) << 2);
  return iLen;
}
/******************************************************************
*  Function Name  : IFX_RTCP_GetSdesItemFromPkt
*  Description    : Get the SDES record from the received RTCP pkt
*  Input Values   : Received RTCP pkt
*  Output Values  : SSRC value of sender
*  Return Value   : Pointer to SDES record / NULL
*  Notes          :
*********************************************************************/
x_IFX_RTCP_SdesItemBlock *
IFX_RTCP_GetSdesItemFromPkt(IN char8 *pszRtcpPktBuff,
                            IN int32 iPktLen,
                            IN int32 iSdesChunkNo,
                            IN e_IFX_RTCP_SDES_Item eSdesItem,
                            OUT uint32 *puiSsrc)
{
  char8 *pxTemp = pszRtcpPktBuff + sizeof(x_IFX_RTCP_Header);
  x_IFX_RTCP_Header *pxRtcpPktHdr = (x_IFX_RTCP_Header *) pszRtcpPktBuff;
  int32 iSize;

  if( (iSdesChunkNo > 0) &&
      (iPktLen > (sizeof(x_IFX_RTCP_Header) + 4)) &&
      (pxRtcpPktHdr->ucPktType == IFX_RTCP_SDES_PKT) )
  {
    --iSdesChunkNo;
    while (iSdesChunkNo != 0)
    {
      pxTemp +=4; /* Skip SSRC */
      iSize = IFX_RTCP_GET_SDES_Size(pxTemp);
      /* Ensure sufficient packet length */
      if ( pszRtcpPktBuff+iPktLen > pxTemp+iSize)
      {
        pxTemp += iSize;
        --iSdesChunkNo;
      }
      else
      {
        return NULL;
      }
    }
    *puiSsrc = *(uint32 *)(pxTemp);
    pxTemp  += 4; /* Skip SSRC */
    return (x_IFX_RTCP_SdesItemBlock *)
           IFX_RTCP_GetSdesItemFromChunk(pxTemp,eSdesItem);
  }
  return NULL;
}

/******************************************************************
*  Function Name  : IFX_RTP_GetByeRec
*  Description    : Get the BYE record
*  Input Values   : pszRtpPktBuff is the received RTP packet
*  Output Values  : None
*  Return Value   : RTCP BYE Record / NULL
*  Notes          :
*********************************************************************/
x_IFX_RTCP_Bye *
IFX_RTCP_BYE_GetByeOpt(IN char8 *pszRtcpPktBuff,
                       IN int32 iPktLen)
{
  x_IFX_RTCP_Header *pxPktHdr = (x_IFX_RTCP_Header *) pszRtcpPktBuff;

  if( (iPktLen > sizeof(x_IFX_RTCP_Header) + 
               (IFX_RTP_BYE_GetSrcCount(pszRtcpPktBuff) * 4)) &&
      (pxPktHdr->ucPktType == IFX_RTCP_BYE_PKT) )
  {
    return ((x_IFX_RTCP_Bye *) ( pszRtcpPktBuff + sizeof(x_IFX_RTCP_Header)
             + (IFX_RTP_BYE_GetSrcCount(pszRtcpPktBuff) * 4)));
  }
  return NULL;
}
/******************************************************************
*  Function Name  : IFX_RTCP_BYE_GetSsrc
*  Description    : Get the BYE SSRC
*  Input Values   : pszRtpPktBuff is the received RTP packet
*  Output Values  : None
*  Return Value   : SSRC value / 0
*  Notes          :
*********************************************************************/
uint32
IFX_RTCP_BYE_GetSsrc(IN char8 *pszRtcpPktBuff,
                     IN int32 iPktLen,
                     IN int32 iSCCount)
{
  char8 *pcTemp = pszRtcpPktBuff + sizeof(x_IFX_RTCP_Header);
  x_IFX_RTCP_Header *pxRtcpPkt = (x_IFX_RTCP_Header*) pszRtcpPktBuff;

  if( (iSCCount < 1) || (pxRtcpPkt->ucPktType != IFX_RTCP_BYE_PKT) )
  {
    return -1;
  }

  iSCCount--;
  while( iSCCount )
  {
    /* Ensie sufficient packet length */
    if( pszRtcpPktBuff+iPktLen < pcTemp+4 )
    {
      pcTemp += 4;
      iSCCount--;
    }
    else
    {
      return -1;
    }
  }
  return *(uint32 *) pcTemp;
}
/******************************************************************
*  Function Name  :  IFX_RTP_GetAppRec
*  Description    :  Get the App record from the recived RTCP pkt
*  Input Values   :  Recived RTCP packet
*  Output Values  :  pointer to the start of RTCP APP pkt
*  Return Value   :  Pointer to RTCP APP record / NULL
*  Notes          :
*********************************************************************/
x_IFX_RTCP_App *
IFX_RTP_APP_GetAppRec(IN char8 *pszRtcpPktBuff,int32 iPktlen)
{
  x_IFX_RTCP_Header *pxRtcpPkt = (x_IFX_RTCP_Header*) pszRtcpPktBuff;

  if( pxRtcpPkt->ucPktType == IFX_RTCP_APP_PKT )
  {
      return (x_IFX_RTCP_App *) (pszRtcpPktBuff + sizeof(x_IFX_RTCP_Header));
  }
  return NULL;
}

/******************************************************************
*  Function Name  :  IFX_RTP_GetRxSSRC
*  Description    :  Get the SSRC record from the recived RTCP pkt
*  Input Values   :  Recived RTCP packet
*  Output Values  :  pointer to the start of RTCP APP pkt
*  Return Value   :  SSRC value / NULL
*  Notes          :
*********************************************************************/
uint32 IFX_RTP_GetRxSSRC(uint32 uiSessionId)
{
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) uiSessionId;
  uint32 uiRet = 0;

  if(pxSess->pxConnListHeadPtr)
  {
    uiRet =  pxSess->pxConnListHeadPtr->pxConn->uiRxSsrc;
  }
 
  return uiRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_SetSdesItem
*  Description                  :  This function sets SDES items for
*                                  the session owner in the  Database
*  Input Values                 :  pxSess, eSdesItem, pcSdesItemValue
*  Output Values                :  none
*  Return Value                 :  void
*  Notes                        :
*********************************************************************/
void IFX_RTP_SetSdesItem(IN uint32 uiSessionId,
                         IN e_IFX_RTCP_SDES_Item eSdesItem,
                         IN char8 *pcSdesItemValue)
{
  IFX_RTP_DB_SetSdesItem((x_IFX_RTP_Session *) uiSessionId, eSdesItem, 
                         pcSdesItemValue);
}

/******************************************************************
*  Function Name                :  IFX_RTP_GetSdesItem
*  Description                  :  This function gets SDES items of
*                                  the session owner from the Database
*  Input Values                 :  pxSdesChunk = SDES information
*                               :  eSdesItem = Exact SDES iem name
*                               :  pxSdesItem = Storage location
*  Output Values                :  none
*  Return Value                 :  void
*  Notes                        :
*********************************************************************/
void IFX_RTP_GetSdesItem(IN uint32 uiSessionId,
                         IN uchar8 ucSessRemoteEndInfo,
                         IN e_IFX_RTCP_SDES_Item eSdesItem,
                         OUT char8 *pcSdesItemValue)
{ 
  x_IFX_RTCP_SdesItems *pxSdesSrc, xSdesDst;

  if(ucSessRemoteEndInfo)
  {
    pxSdesSrc = &(((x_IFX_RTP_Session*) 
                    uiSessionId)->pxConnListHeadPtr->pxConn->xRxSrcDesc);
  } 
  else 
  {
    pxSdesSrc = &((x_IFX_RTP_Session *) uiSessionId)->xTxSrcDesc;
  }

  IFX_RTP_DB_GetSdesItem( pxSdesSrc, eSdesItem, 
                         (x_IFX_RTCP_SdesItems *) &xSdesDst);

  switch( eSdesItem )
  {
    case IFX_RTCP_SDES_ITEM_CNAME:
      strcpy(pcSdesItemValue, xSdesDst.acCanName);
      break;
    case IFX_RTCP_SDES_ITEM_NAME:
      strcpy(pcSdesItemValue, xSdesDst.acName);
      break;
    case IFX_RTCP_SDES_ITEM_LOC:
      strcpy(pcSdesItemValue, xSdesDst.acLoc);
      break;
    case IFX_RTCP_SDES_ITEM_PHONE:
      strcpy(pcSdesItemValue, xSdesDst.acPhone);
      break;
    case IFX_RTCP_SDES_ITEM_EMAIL:
      strcpy(pcSdesItemValue, xSdesDst.acEmail);
      break;
    case IFX_RTCP_SDES_ITEM_TOOL:
      strcpy(pcSdesItemValue, xSdesDst.acAppTool);
      break;
    case IFX_RTCP_SDES_ITEM_NOTE:
      strcpy(pcSdesItemValue, xSdesDst.acNote);
      break;
    case IFX_RTCP_SDES_ITEM_PRIV:
      *((x_IFX_RTCP_SDES_PRIV_Item *)pcSdesItemValue) = xSdesDst.xPriv;
      break;

    default:
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "<IFX_RTP_GetSdesItem> no such item exists\n" );     
      break;
  }
}

#ifdef THREAD_SAFE
PUBLIC char8 IFX_RTP_MutexAction( e_IFX_RTP_MutexAction eActionType, uint32 uiSess)
{
  uint32 uiCnt, uiTmp;
  x_IFX_RTP_ThreadId xThrdID;
  x_IFX_RTP_Session *pxSess1, *pxSess2;
  x_IFX_RTP_ConnList *pxConnList;
  
  switch( eActionType )
  {
    case IFX_RTP_MUTEX_INIT:
      /* Setup IFX_RTP_MAX_SESSIONS + 1 mutexes and fill the vxMutexTable */
      for( uiCnt=0; uiCnt <=IFX_RTP_MAX_SESSIONS; uiCnt++ )
      {
        vxMutexTable[uiCnt].uiSess = 0;
        vxMutexTable[uiCnt].xThrdID = 0;
      }
      /* First mutex is always allocated to LIST */
      IFX_RTP_LockCreate( &vxMutexTable[0].xSemID );
      return IFX_RTP_SUCCESS;
      break;
            
    case IFX_RTP_MUTEX_ALLOC:
      for(uiCnt=1, uiTmp=0; uiCnt<=IFX_RTP_MAX_SESSIONS; uiCnt++)
      {
        if( vxMutexTable[uiCnt].uiSess == uiSess )
        {
          /* Mutex already allocated for this session */
          return IFX_RTP_SUCCESS;
        }
        if( (!uiTmp) && (!vxMutexTable[uiCnt].uiSess) )
        {
          uiTmp = uiCnt;
        }
      }
      if( uiCnt > IFX_RTP_MAX_SESSIONS )
      {
        IFX_RTP_LockCreate( &vxMutexTable[uiTmp].xSemID );
        vxMutexTable[uiTmp].uiSess = uiSess;
        vxMutexTable[uiTmp].xThrdID = 0;
        return IFX_RTP_SUCCESS;
      }
      /* No Mutex available for this request */ 
      break;
        
    case IFX_RTP_MUTEX_FREE:
      for(uiCnt=1; uiCnt<=IFX_RTP_MAX_SESSIONS; uiCnt++)
      {
        if( vxMutexTable[uiCnt].uiSess == uiSess)
        {
          vxMutexTable[uiCnt].uiSess = 0;
          vxMutexTable[uiCnt].xThrdID = 0;
          return IFX_RTP_LockDestroy(&vxMutexTable[uiCnt].xSemID);
        }
      }
      break;
        
    case IFX_RTP_MUTEX_ACQUIRE_LIST:
      /* Mutex Acquire function */       
	  IFX_RTP_GetThreadID(&xThrdID);
      if( (vxMutexTable[0].xThrdID != xThrdID) &&
          (IFX_RTP_LockAcquire(vxMutexTable[0].xSemID) != IFX_RTP_FAIL) )
      {
        IFX_RTP_GetThreadID(&vxMutexTable[0].xThrdID);
        return IFX_RTP_SUCCESS;
      }
      break;
      
    case IFX_RTP_MUTEX_RELEASE_LIST:
      /* Mutex Release function */
      IFX_RTP_GetThreadID(&xThrdID);
      if( (vxMutexTable[0].xThrdID == xThrdID) && 
          (IFX_RTP_LockRelease(vxMutexTable[0].xSemID) != IFX_RTP_FAIL) )
      {
        vxMutexTable[0].xThrdID = 0;
        return IFX_RTP_SUCCESS;
      }
      /* Process tried to free a mutex not acquired by it! */
      break;

    case IFX_RTP_MUTEX_ACQUIRE_SESSION:
      for(uiCnt=1; uiCnt<=IFX_RTP_MAX_SESSIONS; uiCnt++)
      {
        if( vxMutexTable[uiCnt].uiSess == uiSess )
        {
          /* Mutex Acquire function */
          IFX_RTP_GetThreadID(&xThrdID);
          if( (vxMutexTable[uiCnt].xThrdID != xThrdID) &&
             (IFX_RTP_LockAcquire(vxMutexTable[uiCnt].xSemID) != IFX_RTP_FAIL))
          {
            IFX_RTP_GetThreadID(&vxMutexTable[uiCnt].xThrdID);
            return IFX_RTP_SUCCESS;
          }
          break;
        }
      }
      /* No Mutex available for this request */
      break;

    case IFX_RTP_MUTEX_RELEASE_SESSION:
      for(uiCnt=1; uiCnt<=IFX_RTP_MAX_SESSIONS; uiCnt++)
      {
        if( vxMutexTable[uiCnt].uiSess == uiSess)
        {
          /* Mutex Release function */
          IFX_RTP_GetThreadID(&xThrdID);
          if( (vxMutexTable[uiCnt].xThrdID == xThrdID) &&
             (IFX_RTP_LockRelease(vxMutexTable[uiCnt].xSemID) != IFX_RTP_FAIL))
          {
            vxMutexTable[uiCnt].xThrdID = 0;
            return IFX_RTP_SUCCESS;
          }
          break;
        }
      }
      /* No mutex allocated for this session */
      return IFX_RTP_SUCCESS;
      break;

    case IFX_RTP_MUTEX_ACQUIRE_ALL_SESSIONS:
      /* Find out which other Session other than pxSess needs to be acquired,
         then acquire them in ascending order */
      pxConnList = ((x_IFX_RTP_Session *) uiSess)->pxConnListHeadPtr;
      pxSess1 = (x_IFX_RTP_Session *) uiSess;
      pxSess2 = 0;
      if( pxConnList != NULL )
      {
        __ifx_list_GetNext((void *) &pxConnList);
        if( pxConnList != NULL )
        {
          if( uiSess > pxConnList->pxConn->uiSessOwner )
          {
            pxSess1 = (x_IFX_RTP_Session *) pxConnList->pxConn->uiSessOwner;
            pxSess2 = (x_IFX_RTP_Session *) uiSess;
          }
          else
          {
            pxSess2 = (x_IFX_RTP_Session *) pxConnList->pxConn->uiSessOwner;
          }
        }
      }
      if( IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION, (uint32) pxSess1) 
            == IFX_RTP_SUCCESS )
      {
        if( (pxSess2 == 0) || 
            (IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION, (uint32)pxSess2) 
               == IFX_RTP_SUCCESS) )
        {
          return IFX_RTP_SUCCESS; 
        }
        IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, (uint32) pxSess1);
      }
     /* No Mutex available for this request */
      break;

    case IFX_RTP_MUTEX_RELEASE_ALL_SESSIONS:
      /* Find out which other Session other than pxSess needs to be released,
       *            then release them in ascending order */
      pxConnList = ((x_IFX_RTP_Session *) uiSess)->pxConnListHeadPtr;
      pxSess1 = (x_IFX_RTP_Session *) uiSess;
      pxSess2 = 0;
      if( pxConnList != NULL )
      {
        __ifx_list_GetNext((void *) &pxConnList);
        if( pxConnList != NULL )
        {
          if( uiSess > pxConnList->pxConn->uiSessOwner )
          {
            pxSess1 = (x_IFX_RTP_Session *) pxConnList->pxConn->uiSessOwner;
            pxSess2 = (x_IFX_RTP_Session *) uiSess;
          }
          else
          {
            pxSess2 = (x_IFX_RTP_Session *) pxConnList->pxConn->uiSessOwner;
          }
        }
      }
      if( (pxSess2 != 0) &&
          (IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION, (uint32)pxSess2) 
             != IFX_RTP_SUCCESS) )
      {
        break; 
      } 
      if( IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, (uint32) pxSess1) 
                   == IFX_RTP_SUCCESS )
      {
        return IFX_RTP_SUCCESS;
      }        
      /* Unable to release mutex */
      break;
     
    default:
      /* This enum is not defined! */
      break;
  }
  return IFX_RTP_FAIL;
}
#endif

