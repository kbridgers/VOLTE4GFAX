/**************************************************************************
 **   FILE NAME       : ifx_rtp_stack.c
 **   PROJECT         : RTP/RTCP for Inca IP Phone
 **   MODULES         : RTP/RTCP Stack Implementation
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc, monta vista linux
 **   REFERENCE       : Coding guide lines for VSS ,
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "ifx_rtp_memiface.h"
#include "ifx_rtp_oslayer.h"
#include "ifx_rtp_db.h"
#include "ifx_rtp_stack.h"
#include "ifx_rtp_parser.h"
#include "ifx_rtp_timeriface.h"

#include "ifx_debug.h"
#include "ifx_list.h"

/* STATIC declarations */

double64 IFX_RTP_GetRtcpTxInterval(IN x_IFX_RTP_ConnInfo *pxConn);

STATIC char8 v_acRtcpBuf[IFX_RTP_MAX_PKT_SIZE];

EXTERN x_IFX_RTP_Session *vpxRtpSessHeadPtr;

EXTERN int32 v_iRtpSockFd, viRtpInternalPort;

/******************************************************************
*  Function Name                :  IFX_RTP_ProcessUpstreamRtpPkt
*  Description                  :  This function processes the DSP packet
*  Input Values                 :  ucSessId, ucConnId, pcBuffer, unBuffLen
*                               :  ucSessId + ucConnId = Unique Connection
*                               :  pcBuffer = Char buffer containing pkt
*                               :  unBuffLen = Length of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8   IFX_RTP_ProcessUpstreamRtpPkt(IN x_IFX_RTP_Session *pxSess,
                                             IN x_IFX_RTP_ConnInfo *pxConn,
                                             IN char8 *pcBuffer,
                                             IN uint16 unBuffLen )
{
  char8 cRet = 0;
  uint32 i;
  long32 lnSecs, lnUsecs;

  /* Ensure packet has sufficient length */
  if( !unBuffLen )
  {
     return IFX_RTP_SUCCESS;
  }

  /* calculate offset for RTCP calculations if required */
  if( (!pxConn->iTSOffset) && (pxSess->ucIntRtcpStatCalc) )
  {
    IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs ); 
    pxConn->iTSOffset = (int32) lnSecs - 
                        ((x_IFX_RTP_Header *)pcBuffer)->uiTimeStamp;
  }

  /* Increment packet count */
  pxConn->uiNoTxPkt++;

  /* Increment data octet count (by removing fixed header of 12 bytes + 
     additional bytes required to indicate CSRCs) */
  pxConn->uiNoTxOctet += (unBuffLen - 12 -
                          ((x_IFX_RTP_Header *)pcBuffer)->unCsrcCount * 4);

  /* This logic to update last payloadtype & RTP timestamp will not work 
     for Encrypted RTP Packets */
  pxConn->uiTxLastPT = pcBuffer[1] & 0x7F;
  pxConn->uiTxLastRtpTS = IFX_RTP_Ntohl(*((uint32 *) pcBuffer + 1));
  pxSess->ucWeSent = IFX_RTP_TRUE;

  IFX_RTP_DB_AddToMemberList(pxSess, pxSess->uiTxSSRC);
  IFX_RTP_DB_AddToSenderList(pxSess, pxSess->uiTxSSRC);

  /* Handle CSRCs also */
  for( i=0; i < ((x_IFX_RTP_Header *)pcBuffer)->unCsrcCount ; i++)
  {
    IFX_RTP_DB_AddToMemberList(pxSess, *((uint32 *) pcBuffer + 2 + i));
    IFX_RTP_DB_AddToSenderList(pxSess, *((uint32 *) pcBuffer + 2 + i));
  }

  /* Write to the RTP socket */
  cRet = IFX_RTP_TransmitPkt(pxSess, pxConn, IFX_RTP_PKT, pcBuffer,
                             unBuffLen);
  return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_ProcessDownstreamRtpPkt
*  Description                  :  This function processes the RTP packet
*                               :  from network
*  Input Values                 :  ucSessId, ucConnId, pcBuffer, unBuffLen
*                               :  ucSessId + ucConnId = Unique Connection
*                               :  pcBuffer = Char buffer containing pkt
*                               :  unBuffLen = Length of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
char8
IFX_RTP_ProcessDownstreamRtpPkt(IN x_IFX_RTP_Session *pxSess,
                                IN x_IFX_RTP_ConnInfo *pxConn,
                                IN char8 *pcBuffer,
                                IN uint16 *punBuffLen,
                                IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr)
{
  char8 cRet = IFX_RTP_SUCCESS;
  int32 iTransitTime, iRelTransitTime, iCurrTS;
  uint32 uiRxSsrc, i;  
  long32 lnSecs, lnUsecs;
  uint16 unSeqNum;

  cRet = IFX_RTP_CheckSsrcCollision(pxSess, pxConn, IFX_RTP_PKT,
                                    pcBuffer, pxRemoteAddr);
  if( cRet == IFX_RTP_FAIL )
  {
    return cRet;
  }

  /*Call the Call backs*/
  if( pxSess->ucNoOfAddOnReg )
  {
    for( i=0; i < IFX_RTP_MAX_ADD_ON; i++ )
    {
      if( pxConn->xAddOnCB[i].pfnAfterRtpRecv != NULL )
      {
        cRet = pxConn->xAddOnCB[i].pfnAfterRtpRecv((uint32)pxSess,
                 pxConn->pvAddonUserData[i], pcBuffer,(int16 *)punBuffLen,
                 pxConn->pvAddonProcAidData[i]);
      }
    }
  }

  if ( cRet == IFX_RTP_FAIL)
  {
    return cRet;
  }

  /* Calculate RTCP statistics if required */
  if( pxSess->ucIntRtcpStatCalc )
  {
    unSeqNum = IFX_RTP_Ntohs(((x_IFX_RTP_Header *)pcBuffer)->unSeqNum);

    /* Check for first packet */
    if( !pxConn->uiNoRxPkt )
    {
      pxConn->unBaseSeqNum    = unSeqNum;
      pxConn->uiLastHighSeqNo = unSeqNum;
    }

    /* Update Highest Rcvd Seq No. & Rollover Counter */
    if( ((unSeqNum - pxConn->unHighSeqNo) < 
        (0xFFFF - IFX_RTP_SEQ_NUM_ROC_THRESHOLD)) ) 
    {
      pxConn->unHighSeqNo = unSeqNum;
    }
    else if( (pxConn->unHighSeqNo - unSeqNum) > 
             IFX_RTP_SEQ_NUM_ROC_THRESHOLD )
    {
      pxConn->unSeqNoRoc++;
      pxConn->unHighSeqNo = unSeqNum;
    }

    /* If no packets have been transmitted, pxConn->iTSOffset will 
       not be known so the calculations cannot be done */
    if( pxConn->uiNoTxPkt )
    {
      IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs );
      iCurrTS = (int32) lnSecs - pxConn->iTSOffset;
      iTransitTime = iCurrTS - ((x_IFX_RTP_Header *)pcBuffer)->uiTimeStamp;
      iRelTransitTime = iTransitTime - pxConn->iTransitTime;
      pxConn->iTransitTime = iTransitTime;
      if( iRelTransitTime < 0)
      {
        iRelTransitTime = -iRelTransitTime;
      }
      pxConn->uiInterArrJitter += iRelTransitTime - ((pxConn->uiInterArrJitter
                                                      + 8) >> 4); 
    }
  }

  /* Increment received packet count */
  pxConn->uiNoRxPkt++;

  /* Increment received data octet count by ignoring 12 byte fixed header 
     and additional bytes in case of CSRCs */
  pxConn->uiNoRxOctet += (*punBuffLen - 12 -
                          ((x_IFX_RTP_Header *)pcBuffer)->unCsrcCount * 4);

  /* Store last received payload type */ 
  pxConn->ucRxLastPT = pcBuffer[1] & 0x7F;

  uiRxSsrc = IFX_RTP_Ntohl(*((uint32 *) pcBuffer + 2));
  IFX_RTP_DB_AddToMemberList(pxSess, uiRxSsrc);
  IFX_RTP_DB_AddToSenderList(pxSess, uiRxSsrc);

  /* Handle CSRC information */
  for( i=0; i < ((x_IFX_RTP_Header *)pcBuffer)->unCsrcCount ; i++)
  {
    IFX_RTP_DB_AddToMemberList(pxSess, *((uint32 *) pcBuffer + 2 + i));
    IFX_RTP_DB_AddToSenderList(pxSess, *((uint32 *) pcBuffer + 2 + i));
  }

  if(pxConn->xCB.pfnRtpPktArrived != NULL)
  {
    pxConn->xCB.pfnRtpPktArrived((uint32)pxSess, pxConn->pvUserData,
                                  pcBuffer, *punBuffLen);
  }
  return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_ProcessDownstreamRtcpPkt
*  Description                  :  This function decodes and validates
*                               :  a RTCP packet arriving from network
*  Input Values                 :  ucSessId, ucConnId, pcBuffer, unBuffLen
*                               :  ucSessId + ucConnId = Unique Connection
*                               :  pcBuffer = Char buffer containing pkt
*                               :  unBuffLen = Length of pkt buffer
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_ProcessDownstreamRtcpPkt(IN x_IFX_RTP_Session *pxSess,
                                              IN x_IFX_RTP_ConnInfo *pxConn,
                                              IN char8 *pcBuffer,
                                              IN uint16 unBuffLen,
                                       IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr )
{
   char8 cRet = IFX_RTP_SUCCESS;
   uint16 i;

   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<Stack> RTCP decoder" );
  
   /*Call the Call backs*/
   if(pxSess->ucNoOfAddOnReg)
   {
     for ( i= 0; i< IFX_RTP_MAX_ADD_ON;i++)
     {
       if (pxConn->xAddOnCB[i].pfnAfterRtcpRecv != NULL)
       {
         cRet = pxConn->xAddOnCB[i].pfnAfterRtcpRecv((uint32)pxSess,
                      pxConn->pvAddonUserData[i],pcBuffer,(int16*)&unBuffLen,
                      pxConn->pvAddonProcAidData[i]);
       }
     }
   }

   if ( cRet != IFX_RTP_FAIL)
   {
     /* Decode the RTCP packet & update the Session Datbase */
     cRet = IFX_RTCP_Decode(pxSess, pxConn,(uchar8 *)pcBuffer, unBuffLen,
                            pxRemoteAddr);
     /* If UA has registered for an RTCP packet, then send packet to UA */
     if( cRet == IFX_RTP_FAIL )
     {
       IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "<Stack> Decoder Error" );
     }
   }
   IFX_DBGC(vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<Stack> RTCP decoder Success" );
   return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_RtcpStartSession
*  Description                  :  This function starts the RTCP
*                               :  Session
*  Input Values                 :  ucSessId, ucConnId
*                               :  ucSessId + ucConnId = Unique Connection
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_RtcpStartSession(IN x_IFX_RTP_Session *pxSess)
{
  char8 cRet = IFX_RTP_SUCCESS, cTemp[IFX_RTCP_SDES_TEXT_LEN];
  int32 iLocalIP;
  uint32 i;  
  long32 lnSecs, lnUsecs;
  x_IFX_RTP_INT_MSG xIntMsg;
  x_IFX_RTCP_SdesItems xSdesItems={{"\0"}};

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<Stack> Rtcp Start Sess, Sess Id = ",pxSess );

  /* Set the initial values for Interval Calculation Attributes
   * RFC 3550, Pg 30
  */

  IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs );
  pxSess->pxConnListHeadPtr->pxConn->diLastTxRtcpPktTime =
            ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );
  pxSess->ucSenders = 1;
  pxSess->ucMembers = 1;
  pxSess->ucPrevMembers = 1;
  pxSess->ucWeSent = IFX_RTP_FALSE;
  pxSess->diAvgRtcpPktSize = IFX_RTP_RTCP_DEF_PKT_SIZE;
  pxSess->pxConnListHeadPtr->pxConn->ucInitial = 1;

  if( (pxSess->diRtcpBw) &&
      (pxSess->pxConnListHeadPtr->pxConn->uiRemoteRtcpIP) )
  {
    xIntMsg.eIntMsgType = IFX_RTP_RSTRT_RTCP_TIMER;
    xIntMsg.uiSessPtr = (uint32) pxSess;
    xIntMsg.uiConnPtr = (uint32) pxSess->pxConnListHeadPtr->pxConn;
    IFX_RTP_inet_pton(IFX_RTP_AF_INET,IFX_RTP_INTERNAL_IP,&iLocalIP);
    cRet = IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,
                            sizeof(x_IFX_RTP_INT_MSG),
                            iLocalIP,viRtpInternalPort);
    if( cRet == IFX_RTP_FAIL )
    {
      IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<Stack> Send to Internal socket Failure");
      return IFX_RTP_FAIL;
    }
  }
  /* Ensure a unique Cname */
  IFX_RTP_DB_GetSdesItem(&pxSess->xTxSrcDesc, IFX_RTCP_SDES_ITEM_CNAME,
                           &xSdesItems);
  if(strlen(xSdesItems.acCanName) == 0)
  {
    i = 0;
    cTemp[i++] = (uint8) (pxSess->uiTxSSRC & 0x007) + '0';
    cTemp[i++] = ((uint8) (pxSess->uiTxSSRC & 0x070) >>  8) + '0';
    cTemp[i++] = ((uint8) (pxSess->uiTxSSRC & 0x700) >> 16) + '0';
    cTemp[i++] = '@';
    IFX_RTP_GetHostByName(cTemp + i, IFX_RTCP_SDES_TEXT_LEN - i);
    IFX_RTP_DB_SetSdesItem(pxSess, IFX_RTCP_SDES_ITEM_CNAME, cTemp);
  }

  return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_RtcpStopTimer
*  Description                  :  This function stops the RTCP
*                               :  Session Timer
*  Input Values                 :  ucSessId
*                               :  ucSessId = Session
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_RtcpStopSession(IN x_IFX_RTP_Session *pxSess,
                                     IN x_IFX_RTP_ConnInfo *pxConn,
                                     uint8 ucFlag)
{
  char8 cRet = 0;

  /* Stop any timer associated with this session */
  if( pxConn->unTimerId )
  {
    cRet = IFX_RTP_StopTimer(pxConn->unTimerId);
  }

  if( ucFlag == IFX_RTCP_BYE )
  {
    IFX_RTP_SendRtcpReport(pxSess, pxConn,
                    IFX_RTCP_BYE|IFX_RTCP_SDES|IFX_RTCP_SR|IFX_RTCP_RR,NULL);
  }

  return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_GetRtcpTxInterval
*  Description                  :  This function computes the
*                               :  transmission interval
*  Input Values                 :  ucSessId
*                               :  ucSessId = Session
*  Output Values                :  None
*  Return Value                 :  Interval Time
*  Notes                        :
*********************************************************************/
double64 IFX_RTP_GetRtcpTxInterval(IN x_IFX_RTP_ConnInfo *pxConn)
{
   double64 diInterval = 0.0;
   double32 dnRtcpMinTime = IFX_RTCP_MIN_TIME;
   double64 diRtcpBw = ((x_IFX_RTP_Session *)
                       (pxConn->uiSessOwner))->diRtcpBw;
   x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) pxConn->uiSessOwner;

   /* All calculations as per RFC 3550 */

   /* No. of members for computation */
   uchar8 ucCompMembers;

   /* Half the min tx delay if this is the first packet */
   if(pxConn->ucInitial )
   {
      dnRtcpMinTime /= 2.0;
   }

   ucCompMembers = pxSess->ucMembers;
   if( pxSess->ucSenders <=
       (pxSess->ucMembers * IFX_RTCP_SENDER_BW_FRACTION) )
   {
     /* If senders are less than a particular fraction of all members 
        use these calculations */
     if( pxSess->ucWeSent )
     {
       diRtcpBw *= IFX_RTCP_SENDER_BW_FRACTION;
       ucCompMembers = pxSess->ucSenders;
     }
     else
     {
       diRtcpBw *= IFX_RTCP_RCVR_BW_FRACTION;
       ucCompMembers -= pxSess->ucSenders;
     }
   }

   /* Final calculation */
   if( pxSess->diRtcpBw )
   {
     diInterval = ((pxSess->diAvgRtcpPktSize * ucCompMembers ) /
                   (pxSess->diRtcpBw ));
   }

   /* Ensure atleast min time must elapse */
   if( diInterval < IFX_RTCP_MIN_TIME )
   {
      diInterval = IFX_RTCP_MIN_TIME;
   }

   /* Randomise in a range to avoid sync */
   diInterval = 1000 * ( diInterval * ( drand48() + 0.5 ) ) / IFX_RTCP_COMPENSATION;
   return diInterval;
}

/******************************************************************
*  Function Name                :  IFX_RTP_ProcessRtcpInfo
*  Description                  :  This function handles the RTCP
*                               :  Interval Timer Expiry
*  Input Values                 :  pvReportInfo
*                               :  pvReportInfo = Pointer to Report Info
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8  IFX_RTP_ProcessRtcpInfo( IN void *pvInfo )
{
  char8 cRet;
  uint16 i;
  int32 iLocalIP;
  long32 lnSecs;
  long32 lnUsecs;
  double64 diInterval = 0.0;
  double64 diNextInterval = 0.0;
  double64 diCurrTime;
  x_IFX_RTP_ConnInfo *pxConn = (x_IFX_RTP_ConnInfo *) pvInfo;
  uint8 ucPktType = IFX_RTCP_SR | IFX_RTCP_RR | IFX_RTCP_SDES;
  x_IFX_RTP_Session *pxSess = (x_IFX_RTP_Session *) pxConn->uiSessOwner;
  x_IFX_RTP_INT_MSG xIntMsg;

  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<Stack> RTCP Timeout for Connection id =", pxConn );
  
  if(pxSess->iFlags ==1){
			pxSess->iFlags=0;
			return IFX_RTP_SUCCESS;
	}
  IFX_RTP_inet_pton(IFX_RTP_AF_INET,IFX_RTP_INTERNAL_IP,&iLocalIP);
  xIntMsg.uiSessPtr = (uint32) pxSess;
  xIntMsg.uiConnPtr = (uint32) pxConn;
  xIntMsg.eIntMsgType = IFX_RTP_RSTRT_RTCP_TIMER;
#ifdef THREAD_SAFE
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_ACQUIRE_SESSION, (uint32 )pxSess) == 
                         IFX_RTP_FAIL)
  {
    xIntMsg.eIntMsgType = IFX_RTP_EMRGCY_RSTRT_RTCP_TIMER;
    IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,sizeof(x_IFX_RTP_INT_MSG),
                     iLocalIP,viRtpInternalPort);
    return IFX_RTP_FAIL;
  }
#endif  

  IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs );
  diCurrTime = ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );

  diInterval = IFX_RTP_GetRtcpTxInterval(pxConn);
  diNextInterval = pxConn->diLastTxRtcpPktTime + diInterval/1000;

  /* Select Report Type */
  if( diNextInterval < diCurrTime )
  {
     /* tc-2T sender timeout algorithm */
     for( i=0; i < IFX_RTP_MAX_MEMBERS; i++ )
     {
       if( (pxSess->xSenderList.auiSenders[i]) &&
           ((diCurrTime - pxSess->xSenderList.adiLastRtpPktTime[i]) >
           (2 * diInterval)) )
       {
         /* Check if participant itself has been timed out */
         if( pxSess->xSenderList.auiSenders[i] == pxSess->uiTxSSRC )
         {
           pxSess->ucWeSent = IFX_RTP_FALSE; 
         }
         IFX_DBGA( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
                   "<Stack> remove from sender list...", 
                   pxSess->xSenderList.auiSenders[i] );
         IFX_RTP_DB_DeleteFromSenderList(pxSess,
           pxSess->xSenderList.auiSenders[i]);
       }
     }

     /* Member timeout algorithm */
     for( i=0; i < IFX_RTP_MAX_MEMBERS; i++ )
     {
       if( (pxSess->xMemberList.auiMembers[i]) &&
           ((diCurrTime - pxSess->xMemberList.adiLastPktTime[i]) >
           (IFX_RTP_MAX_INACTIVE_INTERVALS * diInterval)) )
       {
         IFX_DBGA( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
                   "<Stack> remove from member list...",
                   pxSess->xMemberList.auiMembers[i] );
         IFX_RTP_DB_DeleteFromMemberList(pxSess,
           pxSess->xMemberList.auiMembers[i]);
         if( pxConn->xCB.pfnInactivityTimeout != NULL )
         {
            pxConn->xCB.pfnInactivityTimeout((uint32)pxSess,pxConn->pvUserData);
            IFX_DBGA( vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                      "<Stack> No close indication has been sent" );
         }
       }
     }
     /* Send RTCP report due to timer expiry */
     IFX_RTP_SendRtcpReport(pxSess, pxConn, ucPktType,NULL);
     /* Reset Init Flag */
     pxConn->ucInitial = 0;
  }
  pxSess->ucPrevMembers = pxSess->ucMembers;

#ifdef THREAD_SAFE  
  if(IFX_RTP_MutexAction(IFX_RTP_MUTEX_RELEASE_SESSION, (uint32 )pxSess) ==
                         IFX_RTP_FAIL)
  {
    return IFX_RTP_FAIL;
  }          
#endif 

  cRet = IFX_RTP_SendToNw(v_iRtpSockFd,(char8 *)&xIntMsg,
                          sizeof(x_IFX_RTP_INT_MSG),
                          iLocalIP,viRtpInternalPort);
  return cRet;
}

/******************************************************************
*  Function Name                :  IFX_RTP_SendRtcpReport
*  Description                  :  This function prepares the RTCP
*                               :  reports to be be sent to peers
*  Input Values                 :  pxReportInfo
*                               :  pxReportInfo = Pointer to Report Info
*  Output Values                :  None
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8  IFX_RTP_SendRtcpReport(IN x_IFX_RTP_Session *pxSess,
                                     IN x_IFX_RTP_ConnInfo *pxConn,
                                     IN uint8 ucPktType ,IN void* vpUserPlugInData)
{
  char8 cRet = IFX_RTP_SUCCESS;
  uchar8 ucReportType;
  uint16 unBuffLen = 0, unPktLen = 0;
  uint32 i;
  long32 lnSecs, lnUsecs;
  double64 diCurrTime;

  /* Find if packet is to be sent to an existing member or not */
  for( i=0; i < IFX_RTP_MAX_MEMBERS; i++ )
  {
    if( pxSess->xMemberList.auiMembers[i] == pxConn->uiRxSsrc )
    {
      break;
    }
  }
  #ifndef __IMSENV__
  /* Dont send packets to non members */
  if( i == IFX_RTP_MAX_MEMBERS )
  {
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "<Stack> RTCP packet not sent as connection is not a member." );
    return IFX_RTP_FAIL;
  }
  #endif
  /* Dont send SR packet if not in send receive mode */
  if( (pxSess->ucWeSent == IFX_RTP_TRUE ) &&
      (pxConn->ucConnMode == IFX_RTP_MODE_SEND_RECV ) )
  {
     ucReportType = IFX_RTCP_SR_PKT;
  }
  else
  {
     ucReportType = IFX_RTCP_RR_PKT;
  }
  if( (ucReportType == IFX_RTCP_SR_PKT)  &&  (ucPktType & IFX_RTCP_SR))
  {
      /* packet type is SR */
      IFX_RTP_EncodeSr( pxSess, pxConn,
                               (uchar8 *) v_acRtcpBuf,
                               &unPktLen );
      unBuffLen += unPktLen;
  }
  if(ucPktType & IFX_RTCP_RR && ucReportType == IFX_RTCP_RR_PKT)
  {
      /* packet type is RR */
      IFX_RTP_EncodeRr( pxSess, pxConn,
                               (uchar8 *) v_acRtcpBuf,
                               &unPktLen );
      unBuffLen += unPktLen;
  }
  /* encode SDES packet */
  if( ucPktType & IFX_RTCP_SDES)
  {
    IFX_RTP_EncodeSdes( pxSess, pxConn, \
                            (uchar8 *) v_acRtcpBuf + unBuffLen, &unPktLen );
    unBuffLen += unPktLen;
  }
  if( ucPktType & IFX_RTCP_BYE )
  {
      IFX_RTP_EncodeBye( pxSess, pxConn,
                                (uchar8 *)v_acRtcpBuf + unBuffLen, &unPktLen,
                                "Normal call termination" );
      unBuffLen += unPktLen;
  }

  if( ucPktType & IFX_RTCP_APP)
  {
    IFX_RTP_EncodeApp( pxSess, pxConn,
                              (uchar8 *)v_acRtcpBuf + unBuffLen, &unPktLen,vpUserPlugInData);
    unBuffLen += unPktLen;
  }
  IFX_DBGC( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "Total Rtcp Packet length",unBuffLen );

  /* Call the Call backs */
  if( pxSess->ucNoOfAddOnReg )
  {
    for( i=0; i < IFX_RTP_MAX_ADD_ON; i++ )
    {
      if( pxConn->xAddOnCB[i].pfnBeforeRtcpSend != NULL )
      {
        pxConn->xAddOnCB[i].pfnBeforeRtcpSend(
                            (uint32)pxSess, pxConn->pvAddonUserData[i],
                            (char8 *) v_acRtcpBuf,(int16 *) &unBuffLen,
                            pxConn->pvAddonUserData[i]);
      }
    }
  }

  /* send RTCP packet to n/w */
  if( (cRet = IFX_RTP_TransmitPkt(pxSess, pxConn, IFX_RTCP_PKT,
            (char8 *) v_acRtcpBuf, unBuffLen)) != IFX_RTP_FAIL )
  {
    pxSess->diAvgRtcpPktSize = ((1.0/6.0)*(double64)(unBuffLen + 28 ) +
                               ((15.0/16.0) * pxSess->diAvgRtcpPktSize ));
    IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs );
    diCurrTime = ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );
    pxConn->diLastTxRtcpPktTime = diCurrTime;
  }

  IFX_DBGC(vcRtpModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
           "<Stack> Send Rtcp success" );
  return cRet;
}

/******************************************************************
*  Function Name  :  IFX_RTP_TransmitPkt
*  Description    :  This function sends RTP/RTCP packet to network
*  Input Values      :  ucSessId,ucConnId,ucPktType,pcPkt,unPktSize
*  Output Values  :  none
*  Return Value      :  SUCCESS/FAIL
*  Notes    :
*********************************************************************/
PUBLIC int8 IFX_RTP_TransmitPkt( IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN uint8 ucPktType,
                                 IN char8 *pcPkt,
                                 IN uint16 unPktSize )
{
  int32 iSockFd;
  char8 cRet=IFX_RTP_SUCCESS;
  uint16 unRemotePort;
  uint32 uiRemoteIP;

  if( ucPktType == IFX_RTP_PKT )
  {
    /* Get the Rtp sock fd from DB */
    iSockFd = pxConn->iRtpFd;
    /* Get the Remote port from DB */
    unRemotePort = pxConn->unRemoteRtpPort;
    /* Get the Remote IP from DB
       Get the remote IP in network format */
    uiRemoteIP = pxConn->uiRemoteIP;
  }
  else
  {
    /* Get the Rtcp sock fd from DB */
    iSockFd = pxConn->iRtcpFd;
    unRemotePort = pxConn->unRemoteRtcpPort;
    /* Get the Remote IP from DB
       Get the remote IP in network format */
    uiRemoteIP = pxConn->uiRemoteRtcpIP;
  }
  if((0 == iSockFd) || (( 0 == unRemotePort)&&(0==uiRemoteIP))){
      IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				   "<Stack> Send Pkt Failed" );			 
      return IFX_RTP_FAIL;
  }  
  cRet = IFX_RTP_SendToNw(iSockFd, pcPkt, unPktSize, uiRemoteIP, unRemotePort);

  return cRet;
}

