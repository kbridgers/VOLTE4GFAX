/**************************************************************************
 **   FILE NAME       : ifx_rtp_pkt.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : Packet Formats for RTP/RTCP
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
/*! \file ifx_rtp_pkt.h
    \brief This File contains the RTP/RTCP header and RTCP reports data structures
     that help the user application to interupt  RTP/RTCP packets.

*/
#ifndef __IFX_RTP_PKT_H__
#define  __IFX_RTP_PKT_H__

#include "ifx_common_defs.h"

/** \ingroup RTP_API
    \defgroup RTP_PKT_API RTP APIs for Packet Handling Services
	  \brief This section describes the data structures and functions used 
           by the Packet Handling Services of the RTP Toolkit. 
*/
/* @{ */
/*
 * Current protocol version.
 */
/*! \def IFX_RTP_VERSION
    \brief RTP Version.
*/
#define IFX_RTP_VERSION 2

/*! \def IFX_RTP_HEADER_LEN
    \brief RTP Header Length.
*/
#define IFX_RTP_HEADER_LEN 12

/*! \def IFX_RTP_SEQ_MOD
    \brief RTP Seq Mod.
*/
#define IFX_RTP_SEQ_MOD (1<<16)

/*! \def IFX_RTP_MAX_CC
    \brief RTP MAX CSRC List
*/
#define IFX_RTP_MAX_CC 15


/*! \struct x_IFX_RTP_Header 
    \brief Fixed RTP header
*/ 
typedef struct
{
#ifdef __BIG_ENDIAN
   uint16 unVer : 2; /*!< Protocol version*/

   uint16 unPadFlag : 1; /*!< Padding flag*/

   uint16 unExtnFlag : 1; /*!<  Header extension flag*/

   uint16 unCsrcCount : 4; /*!< CSRC count*/

   uint16 unMarkerBit : 1; /*!< Marker bit */

   uint16 unPT : 7; /*!< Payload type */

#else /* LITTLE_ENDIAN */

   uint16 unCsrcCount : 4; /*!< CSRC count */

   uint16 unExtnFlag : 1; /*!< Header extension flag */

   uint16 unPadFlag : 1; /*!< Padding flag */

   uint16 unVer : 2; /*!< Protocol version */

   uint16 unPT : 7;/*!< Payload type */

   uint16 unMarkerBit : 1;/*!< Marker bit */

#endif

   uint16 unSeqNum; /*!< Sequence number */

   uint32 uiTimeStamp; /*!< Timestamp */

   uint32 uiSSRC;    /*!< Synchronization source */

   uint32 auiCSRC[IFX_RTP_MAX_CC]; /*!< Optional CSRC list */

} x_IFX_RTP_Header;



/*! \def IFX_RTCP_SDES_TEXT_LEN
    \brief Maximum Text length for SDES packet
*/
#define IFX_RTCP_SDES_TEXT_LEN 255

/*! \def IFX_RTCP_SDES_MAX_ITEMS
    \brief Maximum SDES ITEMS
*/
#define IFX_RTCP_SDES_MAX_ITEMS 9 

/* Enum Constants */
/*!\enum e_IFX_RTCP_PktType
    \brief An Enumeration defining Rtcp record type.
*/
typedef enum 
{ IFX_RTCP_SR_PKT = 200, /*!< Sender Report*/
  IFX_RTCP_RR_PKT = 201,/*!< Receiver Report*/
  IFX_RTCP_SDES_PKT = 202,/*!< SDES Report*/
  IFX_RTCP_BYE_PKT = 203,/*!< Bye Report*/
  IFX_RTCP_APP_PKT = 204 /*!< APP Report*/
} e_IFX_RTCP_PktType;

/*!\enum e_IFX_RTCP_SDES_Item
    \brief An Enumeration defining SDES Items.
*/
typedef enum
{ IFX_RTCP_SDES_ITEM_END = 0,/*!< End*/
  IFX_RTCP_SDES_ITEM_CNAME = 1,/*!< Canonical name*/
  IFX_RTCP_SDES_ITEM_NAME = 2,/*!< Name */
  IFX_RTCP_SDES_ITEM_EMAIL = 3,/*!< Email*/
  IFX_RTCP_SDES_ITEM_PHONE = 4,/*!< Phone*/
  IFX_RTCP_SDES_ITEM_LOC = 5,/*!< Location */
  IFX_RTCP_SDES_ITEM_TOOL = 6,/*!< Tool */
  IFX_RTCP_SDES_ITEM_NOTE = 7,/*!< Note*/
  IFX_RTCP_SDES_ITEM_PRIV = 8/*!< Privacy*/
} e_IFX_RTCP_SDES_Item;

/*!\struct x_IFX_RTCP_SDES_PRIV_Item
    \brief A structure defining RTCP SDES PRIV item
*/
typedef struct
{
  uint8 ucPrefixLength;/*!< Prefix Length*/
  char8 acPrefixString[IFX_RTCP_SDES_TEXT_LEN];/*!<Prefix String*/
  char8 acPriv[IFX_RTCP_SDES_TEXT_LEN];/*!< Priv Item*/
}x_IFX_RTCP_SDES_PRIV_Item;

/*!\struct x_IFX_RTCP_SdesItems
    \brief A structure defining  RTCP SDES Items.
*/
typedef struct
{
   
   char8 acCanName[IFX_RTCP_SDES_TEXT_LEN];/*!< Canonical Name */
  
   char8 acName[IFX_RTCP_SDES_TEXT_LEN]; /*!< Name */
   
   char8 acEmail[IFX_RTCP_SDES_TEXT_LEN];/*!< Email */
   
   char8 acPhone[IFX_RTCP_SDES_TEXT_LEN];/*!< Phone */
   
   char8 acLoc[IFX_RTCP_SDES_TEXT_LEN];/*!< Location */
   
   char8 acAppTool[IFX_RTCP_SDES_TEXT_LEN];/*!< Application Tool Name */
   
   char8 acNote[IFX_RTCP_SDES_TEXT_LEN];/*!< Note */
   
   x_IFX_RTCP_SDES_PRIV_Item xPriv;/*!< Priv */

} x_IFX_RTCP_SdesItems;

/*! \struct x_IFX_RTCP_Header
    \brief A structure defining  FIXED RTCP Header .
*/
typedef struct
{
#ifdef __BIG_ENDIAN
   uint8 ucVer : 2; /*!< Protocol Version */

   uint8 ucPad : 1; /*!< Padding flag */

   uint8 ucCount : 5; /*!< Count, varies by packet type */

#else /* LITTLE_ENDIAN */

   uint8 ucCount : 5; /*!< Count, varies by packet type */

   uint8 ucPad : 1;  /*!< Padding flag */

   uint8 ucVer : 2;  /*!< Protocol Version */

#endif
   uint8 ucPktType; /*!< RTCP packet type */

   uint16 unLen;  /*!< Packet Length in words, not including Common Header word */

} x_IFX_RTCP_Header;

/*! \struct x_IFX_RTCP_RR
    \brief A structure defining Reception Block.
*/
typedef struct
{
   uint32 uiSSRC; /*!< Data source being reported */

   uint32 uiFractionLost : 8; /*!< Fraction lost since last SR/RR */

   int32 iCummPktLost : 24;  /*!< Cumulative No. Pkts lost */

   uint32 uiExtHighSeqNum;  /*!< Extended Highest Seq. No. received */

   uint32 uiJitter;  /*!< Interarrival jitter */

   uint32 uiLSR;   /*!< Time when the last SR packet came from this source */

   uint32 uiDLSR;  /*!< delay since last SR packet */

}x_IFX_RTCP_RR;


/*! \struct x_IFX_RTCP_SR 
    \brief A structure defining Sender Report (SR).
*/

typedef struct
{
   uint32 uiTxSSRC; /*!< Sender generating this report */

   uint32 uiNtpTimestamp; /*!< NTP timestamp */

   uint32 uiNtpTimestampFraction; /*!< NTP timestamp Fraction */

   uint32 uiRtpTimestamp; /*!< RTP timestamp */

   uint32 uiPktTx;  /*!< Packets sent */

   uint32 uiOctetTx;  /*!< Octets sent */

} x_IFX_RTCP_SR;


/*! \struct x_IFX_RTCP_SdesItemBlock 
    \brief A structure defining SdesItem.
*/
typedef struct
{

   uint8 ucItemType;/*!< Type of item  */

   uint8 ucItemLen;/*!< Length of item (in octets) */

   char8 acItemData[IFX_RTCP_SDES_TEXT_LEN];  /*!< Item text, not null-terminated */
 
} x_IFX_RTCP_SdesItemBlock;



/*! \struct x_IFX_RTCP_Bye
    \brief A structure defining BYE Packet.
*/
typedef struct
{
   uint8 ucLen; /*!< length of rtcp bye pkt*/
   char8 acText[IFX_RTCP_SDES_TEXT_LEN];/*!< reason for termination */
} x_IFX_RTCP_Bye;

/*! \struct x_IFX_RTCP_App
    \brief A structure defining Application Packet.
*/
typedef struct
{
   uint32 uiSSRC;/*!< Source of the APP packet */
   char8 acName[4];/*!< Name in the APP packet */
   char8 acText[IFX_RTCP_SDES_TEXT_LEN];/*!< Text representing the application data */
} x_IFX_RTCP_App;


/*! \def IFX_RTCP_GET_RECCount
    \brief Generic macro to get the count field from the RTCP hdr
*/
#define IFX_RTCP_GET_RECCount(pszRtcpPktBuff) ((x_IFX_RTCP_Header*)pszRtcpPktBuff)->ucCount
/*! \def IFX_RTP_APP_GetSubType
    \brief Get the Application SubType
*/
#define IFX_RTP_APP_GetSubType(pszRtcpPktBuff ) ((x_IFX_RTCP_Header*)pszRtcpPktBuff)->ucCount

/*! \def IFX_RTP_BYE_GetSrcCount
    \brief Get the Source Count for Bye Packet
*/
#define IFX_RTP_BYE_GetSrcCount(pszRtcpPktBuff ) ((x_IFX_RTCP_Header*)pszRtcpPktBuff)->ucCount

/*! \def IFX_RTP_SDES_GetSrcCount
    \brief Get the Source Count for SDES Pkts
*/
#define IFX_RTP_SDES_GetSrcCount(pszRtcpPktBuff ) ((x_IFX_RTCP_Header*)pszRtcpPktBuff)->ucCount

/*! \def IFX_RTCP_RR_GetRRCount
    \brief Get Recipent Count for RR Pkt
*/
#define IFX_RTCP_RR_GetRRCount(pszRtcpPktBuff ) ((x_IFX_RTCP_Header*)pszRtcpPktBuff)->ucCount

/*! \def IFX_RTCP_SR_GetRRCount
    \brief Get the Recipent Count for SR Pkt
*/
#define IFX_RTCP_SR_GetRRCount(pszRtcpPktBuff ) ((x_IFX_RTCP_Header*)pszRtcpPktBuff)->ucCount

/*! \def IFX_RTCP_GetSenderSSRC
    \brief Get Sender SSRC for all RTCP pkts except BYE
*/
#define IFX_RTCP_GetSenderSSRC(pszRtcpPktBuff) (uint32 *)(pszRtcpPktBuff+sizeof(x_IFX_RTCP_Header))

/*! \brief  Gets the Rtp header from the recived Rtp packet.
    \param[in] pszRtpPktBuff Recived Rtp packet
    \return x_IFX_RTP_RtpHdrType pointer to the RTP header struct.
*/
x_IFX_RTP_Header * 
IFX_RTP_GetRtpHeader(IN char8 *pszRtpPktBuff);


/*! \brief  Gets the Rtp Extension header from the recived Rtp packet.
    \param[in] pszRtpPktBuff Recived Rtp packet
    \param[out] punLength length of the extension header
    \return char8 pointer to the RTP Extension.
*/
char8 *
IFX_RTP_GetRtpExtnHdr(IN char8 *pszRtpPktBuff, OUT uint16 *punLength);


/*! \brief  Gets the Rtcp header from the recived Rtcp packet.
    \param[in] pszRtcpPktBuff Recived Rtcp packet
    \return x_IFX_RTP_RtcpHdrType pointer to the RTCP header struct.
*/
x_IFX_RTCP_Header *
IFX_RTP_GetRtcpHdr(IN char8 *pszRtcpPktBuff);


/*! \brief  Gets the Sender info from the recived Rtcp SR packet.
    \param[in] pszRtcpPktBuff Recived Rtcp SR packet
    \return x_IFX_RTP_SR pointer to the Sender info.
    \note to be called only in pfnSRArrived
*/
x_IFX_RTCP_SR *
IFX_RTCP_SR_GetSenderInfo(IN char8 *pszRtcpPktBuff);

/*! \brief  Gets the Recipent block from the recived Rtcp SR/RR packet.
  
     There can be more than one reciver reports so they need to be fetched one by one.
    \param[in] pszRtcpPktBuff Recived Rtcp SR or RR packet
    \param[in] iPktLen SR/RR packet Length
    \param[in] iRRBlockNo Recipent block number to be fetched.
    \return  x_IFX_RTP_RRRec pointer to the Receiver Report record.
    \note to be called only in pfnRRArrived
*/
x_IFX_RTCP_RR *
IFX_RTCP_RR_GetRepBlock(IN char8 *pszRtcpPktBuff,
                        IN int32 iPktLen,
                        IN int32 iRRBlockNo);

/*! \brief  Gets the Rtcp SDES packet size.
    \param[in] pcTemp Recived Rtcp SDES packet
    \return  size of SDES Pkt.
    \note to be called only in pfnSdesArrived
*/
int32
IFX_RTCP_GET_SDES_Size(IN char8 *pcTemp);

/*! \brief  Gets the SDES item from the recived RTCP SDES packet.
 
     There can be more than one SDES chunks so they need to be fetched one by one.
    \param[in] pszRtcpPktBuff Recived Rtcp SDES packet.
    \param[in] iPktLen SDES packet Length.
    \param[in] iSdesChunkNo SDES chunk number to be fetched.
    \param[in] eSdesItem Sdes item to be fecthed from SDES chunk.
    \param[out] puiSsrc SSRC of the SDES chunk orginator
    \return x_IFX_RTCP_SdesItemBlock pointer to the SDES item.
    \note to be called only in pfnSdesArrived
*/
x_IFX_RTCP_SdesItemBlock *
IFX_RTCP_GetSdesItemFromPkt(IN char8 *pszRtcpPktBuff,
                            IN int32 iPktLen,
                            IN int32 iSdesChunkNo,
                            IN e_IFX_RTCP_SDES_Item eSdesItem,
                            OUT uint32 *puiSsrc);

/*! \brief  Gets the Bye record from the recived RTCP Bye packet.
    \param[in] pszRtcpPktBuff Recived Rtcp BYE packet.
    \param[in] iPktLen BYE packet Length.
    \return x_IFX_RTP_ByeRec pointer to the Bye Opt.
    \note to be called only in pfnByeArrived
*/
x_IFX_RTCP_Bye *
IFX_RTCP_BYE_GetByeOpt(IN char8 *pszRtcpPktBuff,
                       IN int32 iPktLen);

/*! \brief  Gets the SSRC of the Bye orginator from the recived RTCP Bye packet.
     There can be more than one BYE SSRC so they need to be fetched one by one.
    \param[in] pszRtcpPktBuff Recived Rtcp BYE packet.
    \param[in] iPktLen BYE packet Length.
    \param[in] iSCCount Source Count
    \return x_IFX_RTP_ByeRec pointer to the Bye Opt.
*/
uint32
IFX_RTCP_BYE_GetSsrc(IN char8 *pszRtcpPktBuff,
                     IN int32 iPktLen,
                     IN int32 iSCCount);

/*! \brief  Gets the APP packet from the recived RTCP APP packet.
    \param[in] pszRtcpPktBuff Recived Rtcp APP packet
    \param[in] iPktlen APP packet Length.
    \return char8 * pointer to the begining of APP Record.
    \note to be called only in pfnAppArrived
*/
x_IFX_RTCP_App *
IFX_RTP_APP_GetAppRec(IN char8 *pszRtcpPktBuff,int32 iPktlen);

/*! \brief  Set the AppData Name in the RTCP APP PKT
    \param[in] pucBuff reference to APP Pkt.
    \param[in] pcName Name of the RTCP App Pkt.
    \return IFX_RTP_SUCCESS/IFX_RTP_FAIL
    \note Updates the length of the RTCP Header
*/
int16
IFX_RTCP_SetAppName(IN_OUT uchar8 *pucBuff,
                    IN uchar8 *pcName);

/*! \brief  Set the AppData SubType in the RTCP HDR
    \param[in] pucBuff reference to APP Pkt.
    \param[in] cSubType SubType of the RTCP App Pkt.
    \return IFX_RTP_SUCCESS/IFX_RTP_FAIL
*/
int16
IFX_RTCP_SetAppSubType(IN_OUT uchar8 *pucBuff,
                        IN uchar8 cSubType);

/*! \brief  Set the AppData in the RTCP APP PKT
    \param[in] pucBuff reference to APP Pkt.
    \param[in] pcAppData App data to be set.
    \param[in] unAppDataLen Length of the App Data.
    \return IFX_RTP_SUCCESS/IFX_RTP_FAIL
    \note Updates the length and padding fields of the RTCP Header
*/
int16
IFX_RTCP_SetAppData(IN_OUT uchar8 *pucBuff,
                        IN char8 *pcAppData,
                        IN uint16 unAppDataLen);

/* @} */
#endif /* __IFX_RTP_PKT_H__ */
