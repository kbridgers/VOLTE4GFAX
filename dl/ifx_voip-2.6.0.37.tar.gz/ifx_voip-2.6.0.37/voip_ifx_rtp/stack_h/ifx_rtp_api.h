/**************************************************************************
**   FILE NAME    : ifx_rtp_api.h
**   PROJECT      : RTP
**   MODULES      : Get and Set APIs for constructing the RTP
**   SRC VERSION  : V2.2.1
**   DATE         :
**   AUTHOR       : VoIP Team
**   DESCRIPTION  : APIs for using the RTP/RTCP Processing.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
/* A temprovary fix for the IMS team
   Need to be removed later */

#include "ifx_common_defs.h"
#include "ifx_ipc.h"
#include "ifx_rtp_pkt.h"

/*! \file ifx_rtp_api.h
    \brief This File contains the RTP Stack API's that help the user application to
     send and receive RTP/RTCP packets. The Data is assumed to be compressed
     with the codec and the payload type specified.
           
*/	
#ifndef IFX_RTP_API__H_
#define IFX_RTP_API__H_

/*---------- First Level Grouping ---------------------*/
/** \ingroup VoIP_LIB_API
    \defgroup RTP_API RTP API 
    \brief This section describes the RTP toolkit API
*/
/** \ingroup RTP_API
    \defgroup RTP_SESS_API RTP APIs for Media Session Services
	  \brief This section describes the data structures and functions used 
           by the Media Session Services of the RTP Toolkit. 
*/
/* @{ */

/*!\enum e_IFX_RTP_AddOnType
   \brief An Enumeration defining the Add On call back types.
   \note Add Ons are available for applications to perform
         additional processing like srtp/srtcp
*/
typedef enum
{
  IFX_RTP_MIB,/*!< Add on functions fro RTP MIB*/
  IFX_RTP_SRTP,/*!< Add on functions for SRTP Implementation*/
  IFX_RTP_EXTN,/*!< Add on functions for extensions*/
  IFX_RTP_MAX_ADD_ON/*!< Indicates the end of addon functions*/
}e_IFX_RTP_AddOnType;

/*! \def IFX_RTP_FAIL
    \brief RTP Fail.
*/
#define  IFX_RTP_FAIL       -1

/*! \def IFX_RTP_SUCCESS
    \brief RTP SUCCESS.
*/
#define  IFX_RTP_SUCCESS    0


/*! \def IFX_RTCP_SR
    \brief RTCP sender report.
    \note rtcp packets can be sent manually by specfying this
          packet type,Only Sender Report is sent.
*/
#define IFX_RTCP_SR 0x01

/*! \def IFX_RTCP_RR
    \brief RTCP reception report.
    \note rtcp packets can be sent manually by specfying this
          packet type,Only Reciver Report is sent
*/
#define IFX_RTCP_RR 0x02

/*! \def IFX_RTCP_SDES
    \brief RTCP session description.
    \note rtcp packets can be sent manually by specfying this
          packet type,Only SDES report is sent
*/
#define IFX_RTCP_SDES 0x04

/*! \def IFX_RTCP_BYE
    \brief RTCP BYE packet.
    \note rtcp packets can be sent manually by specfying this
          packet type,Only Bye packet is sent.
*/
#define IFX_RTCP_BYE 0x08

/*! \def IFX_RTCP_APP
    \brief RTCP application report.
    \note rtcp packets can be sent manually by specfying this
          packet type,Only Application Report is sent.
*/
#define IFX_RTCP_APP 0x10

/*! \def IFX_RTP_SEND_ONLY
    \brief If set RTP Connection operates in send only mode.
*/
#define IFX_RTP_SEND_ONLY 1

/*! \def IFX_RTP_RECV_ONLY
    \brief If Set RTP Connection operates in recv only mode.
*/
#define IFX_RTP_RECV_ONLY 2

/*! \def IFX_RTP_SEND_RECV
    \brief If Set RTP Connection operates in send recv mode.
:*/
#define IFX_RTP_SEND_RECV 3

/*! \def IFX_RTP_INACTIVE
    \brief If Set RTP Connection operates in Inactive mode.
*/
#define IFX_RTP_INACTIVE 4

/*! \def IFX_RTCP_SET_BW
    \brief This flag is used for configuring session Bandwidth parameter.
*/
#define IFX_RTCP_SET_BW 0x01

/*! \def IFX_RTP_SET_MODE
    \brief This flag is used for configuring session RTP Mode.
*/
#define IFX_RTP_SET_MODE 0x1

/*! \def IFX_RTP_SET_TXADDR
    \brief This flag is used for configuring session RTP/RTCP Dest Addr.
*/
#define IFX_RTP_SET_TXADDR 0x2

/*! \def IFX_RTP_SET_TXPORT
    \brief This flag is used for configuring session RTP/Rtcp Dext Port .
*/
#define IFX_RTP_SET_TXPORT 0x4


/*! \def IFX_RTP_SET_RXADDR
    \brief This flag is used for configuring session RTP/Rtcp Source Addr.
*/
#define IFX_RTP_SET_RXADDR 0x8


/*! \def IFX_RTP_SET_RXPORT
    \brief This flag is used for configuring session RTP/RTCP Source Port.
*/
#define IFX_RTP_SET_RXPORT 0x10

/*! \def IFX_RTCP_SET_INTSTATCALC
    \brief This flag is used for configuring session Enable Internal RTCP Statistics Calculations.
*/
#define IFX_RTCP_SET_INTSTATCALC 0x20

/*! \def IFX_RTP_SYNC_MODE
    \brief This flag is used for configuring session in SYNC mode.
*/
#define IFX_RTP_SYNC_MODE 0x1

/*! \def IFX_RTP_ASYNC_MODE
    \brief This flag is used for configuring session in ASYNC mode.
*/
#define IFX_RTP_ASYNC_MODE 0x2

/*! \def IFX_RTP_MODE_SEND_ONLY
    \brief RTP mode is sendonly.
*/
#define IFX_RTP_MODE_SEND_ONLY    1

/*! \def IFX_RTP_MODE_RECV_ONLY
    \brief RTP mode is recv only.
*/
#define IFX_RTP_MODE_RECV_ONLY    2

/*! \def IFX_RTP_MODE_SEND_RECV
    \brief RTP mode is sendrecv.
*/
#define IFX_RTP_MODE_SEND_RECV    3

/*! \def IFX_RTP_MODE_INACTIVE
    \brief RTP mode is inactive.
*/
#define IFX_RTP_MODE_INACTIVE     4

/*! \def IFX_RTP_MODE_CLOSE
    \brief close RTP connection.
*/
#define IFX_RTP_MODE_CLOSE        5

/*! \def IFX_RTP_PKT
    \brief For internal use to indicate RTP connection.
*/
#define IFX_RTP_PKT  0

/*! \def IFX_RTCP_PKT
    \brief For internal use to indicate RTP packet.
*/
#define IFX_RTCP_PKT  1

/*! \def IFX_RTP_MAX_BUFF_SIZE
    \brief Maximim RTP buffer size.
*/
#define IFX_RTP_MAX_BUFF_SIZE  4000

/*! \def IFX_RTP_TRUE
    \brief Indicates TRUE.
*/
#define IFX_RTP_TRUE       1

/*! \def IFX_RTP_FALSE
    \brief Indicates false.
*/
#define IFX_RTP_FALSE      0

/*! \def IFX_RTP_MAX_SESSIONS
    \brief Maximum RTP sessions.
*/
#define IFX_RTP_MAX_SESSIONS 4

/*! \def IFX_RTP_MAX_CONNS
    \brief Maximum RTP connections.
*/
#define IFX_RTP_MAX_CONNS   4


/*! \struct x_IFX_RTP_AddOnCallBks
    \brief A structure defining function pointers for handling Protocols on top of RTP/RTCP and some bookkeeping functionality.
*/
typedef struct
{
  int32 (*pfnBeforeRtpSend)(IN uint32 uiSessionId, IN void *pvUserData,
                            IN_OUT char8 *pcSrcPkt, IN_OUT int16 *punSrcPktLen,
                            IN void *pvProcAidData);/*!< Called when the RTP packet is about to be sent */

  int32 (*pfnAfterRtpRecv)(IN uint32 uiSessionId, IN void *pvUserData,
                           IN char8 *pcSrcPkt, IN int16 *punSrcPktLen,
                           IN void *pvProcAidData );/*!< Called on reception of RTP packet */

  int32 (*pfnBeforeRtcpSend)(IN uint32 uiSessionId, IN void *pvUserData,
                             IN char8 *pcSrcPkt, IN int16 *punSrcPktLen,
                             IN void *pvProcAidData);/*!< Called when the RTCP packet is about to be sent */

  int32 (*pfnAfterRtcpRecv)(IN uint32 uiSessionId, IN void *pvUserData,
                            IN char8 *pcSrcPkt, IN int16 *punSrcPktLen,
                            IN void *pvProcAidData );/*!< Called on reception of RTCP packet */

  int32 (*pfnOpenSession)(IN uint32 uiSessionId, OUT void **pvUserData);/*!< Called when a open session is called on a particular session. This can be used to keep track of number of ongoing sessions etc. */

  int32 (*pfnCloseSession)(IN uint32 uiSessionId, IN void *pvUserData);/*!< Called when close session is initiated. Can be used to keep track of the number of sessions */

  int32 iRtpFooterSize;/*!< RTP FooterSize required for this App Addon*/

  int32 iRtcpFooterSize;/*!< RTCP FooterSize required for this App Addon*/

}x_IFX_RTP_AddOnCallBks;

/*! \struct x_IFX_RTP_CallBks
    \brief A structure defining function pointers for handling RTP and RTCP stack.
    \note pcSrcPkt in all RTCP pkts is a refrence to the Corresponding Pkt
          and not the Compound Pkt. same applies for the unSrcPktLen.
*/
typedef struct
{
  int32 (*pfnAllocMemForRtpPkt)(IN uint32 uiSessionId, IN void *pvUserData,
                                OUT char8 **pcBuff);/*!< Called on reception of RTP packet. Data is copied to the buffer provided using this call back. */


  int32 (*pfnAllocMemForRtcpPkt)(IN uint32 uiSessionId, IN void *pvUserData,
                                 OUT char8 **pcBuff);/*!< Called on reception of RTCP packet. Data is copied to the buffer provided using this call back. */


  int32 (*pfnRtpPktArrived)(IN uint32 uiSessionId, IN void *pvUserData,
                            IN char8 *pcSrcPkt, IN int16 unSrcPktLen);/*!< Called on reception of RTP packet */


  int32 (*pfnGetRtpTimeStamp)(IN uint32 uiSessionId, IN void *pvUserData,
                              OUT int32 *piTimeStamp);/*!< Called while sending the SR report. Used to get the RTP timestamp to be filled in the SR report */


  int32 (*pfnInactivityTimeout)(IN uint32 uiSessionId, IN void *pvUserData);/*!< Called on reception of RTCP packet */

  int32 (*pfnSsrcCollision)(IN uint32 uiSessionId, IN void *pvUserData);/*!< Called on reception of RTCP packet */


  int32 (*pfnByeCreated)(IN uint32 uiSessionId, IN void *pvUserData,
                         IN char8 *pcSrcPkt, IN uint16 *punSrcPktLen);/*!< Called just before sending BYE packet to the destination */


  int32 (*pfnByeArrived)(IN uint32 uiSessionId, IN void *pvUserData,
                          OUT char8 *pcSrcPkt, OUT uint16 unSrcPktLen);/*!< Called on reception of BYE packet from the peer */

  int32 (*pfnAppCreated)(IN uint32 uiSessionId, IN void *pvUserData,
                         IN char8 *pcSrcPkt, IN uint16 *punSrcPktLen,void *vpUserPlugInData);/*!< Called just before sending APP packet to the destination */


  int32 (*pfnAppArrived)(IN uint32 uiSessionId, IN void *pvUserData,
                          OUT char8 *pcSrcPkt, OUT uint16 unSrcPktLen);/*!< Called on reception of APP packet from the peer */

  int32 (*pfnRRCreated)(IN uint32 uiSessionId, IN void *pvUserData,
                        IN char8 *pcSrcPkt, IN uint16 *punSrcPktLen);/*!< Called just before sending the Reception report to the destination */


  int32 (*pfnSRCreated)(IN uint32 uiSessionId, IN void *pvUserData,
                        IN char8 *pcSrcPkt, IN uint16 *punSrcPktLen);/*!< Called Just before sending the sender report to the peer */


  int32 (*pfnSDESCreated)(IN uint32 uiSessionId, IN void *pvUserData,
                          IN char8 *pcSrcPkt, IN uint16 *punSrcPktLen);/*!< Called before sending SDES to the peer */


  int32 (*pfnRRArrived)(IN uint32 uiSessionId, IN void *pvUserData,
                        IN char8 *pcSrcPkt, IN uint16 unSrcPktLen);/*!< Called on reception of Reception report */


  int32 (*pfnSRArrived)(IN uint32 uiSessionId, IN void *pvUserData,
                        IN char8 *pcSrcPkt, IN uint16 unSrcPktLen);/*!< Called on reception of Sender report */


  int32 (*pfnSDESArrived)(IN uint32 uiSessionId, IN void *pvUserData,
                          IN char8 *pcSrcPkt, IN uint16 unSrcPktLen);/*!< Called on reception of SDES packet */


}x_IFX_RTP_CallBks;

/*! \struct x_IFX_RTP_SyncCallBks
    \brief A structure defining function pointers for handling RTP and RTCP FD's.
    \note These Callbacks need to be registered only in the case of stack operating in SYNC mode.
*/

typedef struct
{
    int32 (*pfnAddFDToSelect)(IN void *pvUserData, IN int32 iRtpFd,
                              IN int32 iRtcpFd, IN int32 iRtpSockFd);/*!< Called on opening of RTP Conn.*/


  int32 (*pfnRemoveFDFromSelect)(IN void *pvUserData, IN int32 iRtpFd,
                            IN int32 iRtcpFd, IN int32 iRtpSockFd);/*!< Called on closing  of RTP Conn */  
}x_IFX_RTP_SyncCallBks;



/*! \brief Initializes RTP stack and initlizes all database.
 *
 *  In Sync mode stack is treated as a library and RTP Fd's are returned
 *  to the App for blocking. In case of Async mode a RTP thread is created
 *  and handling of rtp packet's from network is handled soley by the stack.
 *
 *  \param[in] iStackMode Stack mode of operation can be SYNC or ASYNC
 *  \param[in] pxSyncCallBks Callback functions
 *  \param[in] iRtpInternalPort Allows definition of a specific internal port
 *             for the RTP stack.
 *  \return IFX_RTP_SUCCESS/IFX_RTP_FAIL/iThreadId incase of Async Mode.
 *  \note In Async mode this API shall return the Thread ID.
 *
 *                                                                      */
int32 IFX_RTP_Init(int32 iStackMode, x_IFX_RTP_SyncCallBks *pxSyncCallBks,
                   int32 iRtpInternalPort);

/*! \brief Recive Pkt from network in Sync mode from the FD listed.
    \param[in] pvRdFdSet List of FD unblocked (fd_list).
    \param[in] nFd Fd unblocked.
*/
int32 IFX_RTP_SyncRecvPkt(void* pvRdFdSet,int32 *piNoFd);


/*! \brief Configure RTP Stack Paramaters.
    \param[in] ucDbgLvl Debug Level.
    \param[in] ucDbgType Debug type.
    \return IFX_RTP_SUCCESS/IFX_RTP_FAIL    
*/
int32
IFX_RTP_StackCfg(uchar8 ucDbgLvl,uchar8 ucDbgType);

/*! \brief Registers a AddOn Application.
    \param[in] uiSessId session identifier
    \param[in] etype Addon Type.
    \param[in] pxAddOnCallbk Addon Callbacks.
*/

void 
IFX_RTP_SessRegisterAddOn(IN uint32 uiSessId, 
                          IN e_IFX_RTP_AddOnType etype,
                          IN x_IFX_RTP_AddOnCallBks *pxAddOnCallbk);

/*! \brief Set ProcAid data for the Addon.
    \param[in] uiSessId session identifier
    \param[in] etype Addon Type.
    \param[in] pvProcAidData refrence to proc Aid Data.
*/
void
IFX_RTP_SessSetAddOnProcAidData(IN uint32 uiSessionId,
                          IN e_IFX_RTP_AddOnType eType,
                          IN void *pvProcAidData);

/*! \brief  Create a session and return the session ID for the same 
    \param[in] ucIsRtpEnable bool to enable RTP for the session.
    \param[in] ucIsRtcpEnable bool to enable RTCP for the session.
    \param[in] pvUserData User Data to be required at stack callbacks
    \param[in] pxCallBks Session Callbacks.
    \return Session ID of the session created. 
*/
uint32
IFX_RTP_SessCreate(IN uchar8 ucIsRtpEnable,
                   IN  uchar8 ucIsRtcpEnable,
                   IN void *pvUserData,
                   IN x_IFX_RTP_CallBks *pxCallBks);


/*! \brief  Configure RTCP session Parameters

    This function has to be called before open session 
    \param[in] uiSessId is the session Identifier of the RTP session
    \param[in] uiOptions is the config identifier that has to be changed.
    \param[in] diRtcpBW is the RTCP bandwidth
    \param[in] pcRtcpTxAddr is the RTP Tx Address
    \param[in] unTxPort is the RTP Tx port
    \param[in] pcRtcpRxAddr is the RTP Rx Address
    \param[in] unRxPort is the RTP Rx port
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
int32
IFX_RTCP_SessConfig(IN uint32 uiSessId,
                    IN uint32 uiOptions,
                    IN double64 diRtcpBw,
                    IN char8* pcRtcpTxAddr,
                    IN uint16 unTxPort,
                    IN char8* pcRtcpRxAddr,
                    IN uint16 unRxPort);

/*! \brief  Configure RTP session Parameters

    This function has to be called before open session 
    \param[in] uiSessId is the session Identifier of the RTP session
    \param[in] uiOptions is the config identifier that has to be changed.
    \param[in] ucMode is the connection mode
    \param[in] pcRtpTxAddr is the RTP Tx Address
    \param[in] unTxPort is the RTP Tx port
    \param[in] pcRtpRxAddr is the RTP Rx Address
    \param[in] unRxPort is the RTP Rx port
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
int32
IFX_RTP_SessConfig(IN uint32 uiSessId,
                   IN uint32 uiOptions,
                   IN uchar8 ucMode,
                   IN uchar8* pcRtpTxAddr,
                   IN uint16 unTxPort,
                   IN uchar8* pcRtpRxAddr,
                   IN uint16 unRxPort); 

/*! \brief  Open the session associated with the session ID
 
    Session configuration should have been done by this time 
    \param[in] iSessionId is the session Identifier of the RTP session
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
int32
IFX_RTP_SessOpen(IN uint32 uiSessionId);

/*! \brief  Close the RTP/RTCP session associated with the given session Identifier
 
    \param[in] iSessionId is the session Identifier of the RTP session
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
int32
IFX_RTP_SessClose(IN uint32 uiSessionId);

/*! \brief  Send constructed  RTP packet(including header) over the given session
 
    \param[in] uiSessId is the session Identifier of the RTP session
    \param[in] pcBuffStart - Start of the buffer
    \param[in] nBuffSize - size of the buffer
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
char8
IFX_RTP_SessSendRawPkt(IN uint32 uiSessId,
                       IN char8 *pcBuffStart,
                       IN int16 nBuffSize);


/*! \brief  Send an RTP packet over the given session
 
    \param[in] uiSessId is the session Identifier of the RTP session
    \param[in] pcBuffStart - Start of the buffer
    \param[in] nBuffSize - size of the buffer
    \param[in] pcDataStart - Start of the Data
    \param[in] iDataSize - Size of data
    \param[in] bMarker - Set or reset the marker bit
    \param[in] ucPT - Payload to be set
    \param[in] uiTimeStamp - Timestamp in the RTP header
    \param[in] unIsExtnBitSet - Extension bit in the RTP header
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
char8
IFX_RTP_SessSendRtpPkt(IN uint32 uiSessId,
                       IN char8 *pcBuffStart,
                       IN int16 nBuffSize,
                       IN char8 *pcDataStart,
                       IN int32 iDataSize,
                       IN char8 bMarker,
                       IN uchar8 ucPT,
                       IN int32 uiTimeStamp,
                       IN uint16 unIsExtnBitSet);

/*! \brief  Send RTCP packet of the specified type 
    \param[in] uiSessionId is the session Identifier of the RTP session
    \param[in] ucType Type of RTCP packets to be set
    \param[in] vpUserPlugInData User Plug in data type
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE. 
*/
int32
IFX_RTP_SessSendRtcpPkt(IN uint32 uiSessionId,
                        IN uchar8 ucType,IN void* vpUserPlugInData);

/*! \brief  Gets the Local RTP sequence number
    \param[in] uiSessionId is the session Identifier of the RTP session
    \return Returns the local RTP sequence number/ IFX_RTP_FAIL.
*/
int32 
IFX_RTP_SessGetRtpSequenceNum(IN uint32 uiSessionId);

/*! \brief  Gets the SSRC associated with the session
    \param[in] uiSessionId is the session Identifier of the RTP session
    \return Returns the SSRC for a given session.
*/
uint32 
IFX_RTP_SessGetSsrc(IN uint32 uiSessionId);

/*! \brief  Sets the SSRC associated with the session
    \param[in] uiSessionId is the session Identifier of the RTP session
    \param[in] uiSsrc session identifier
    \return none.
*/
void
IFX_RTP_SessSetSsrc(IN uint32 uiSessionId,IN uint32 uiSsrc);

/*! \brief  Gets the footer size associated with the session
    \param[in] uiSessionId is the session Identifier of the RTP session
    \return Returns the RTCP footer size for a given session.
*/
int32 
IFX_RTP_SessGetRtcpFooterSize(IN uint32 uiSessionId);

/*! \brief  Gets the header size associated with the session
    \param[in] uiSessionId is the session Identifier of the RTP session
    \return Returns the RTCP header size for a given session.
*/
int32 
IFX_RTP_SessGetRtcpHeaderSize(IN uint32 uiSessionId);

/*! \brief  Gets the footer size associated with the session
    \param[in] uiSessionId is the session Identifier of the RTP session
    \return Returns the RTP footer size for a given session.
*/
int32
IFX_RTP_SessGetRtpFooterSize(IN uint32 uiSessionId);

/*! \brief  Gets the header size associated with the session
    \param[in] uiSessionId is the session Identifier of the RTP session
    \return Returns the RTP header size for a given session.
*/
int32 
IFX_RTP_SessGetRtpHeaderSize(IN uint32 uiSessionId);

/*! \brief  Adds the new session to the conference list.

    Subsequently all the packets that are sent out using these session Identifier will contain the other in the CSRC list.piSessionId2 will be modified after this call 
    \param[in] uiSessionId1 is the session Identifier of the RTP session which is in conference
    \param[in,out] uiSessionId2 is the session which has to be taken into conference
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE.
*/
int32
IFX_RTP_SessAddToConfList(IN uint32 uiSessionId1,
                          IN uint32 uiSessionId2);

/*! \brief  Removes the new session from the conference list. 

    Subsequently all the packets that are sent out using these session Identifier will not contain the other in the CSRC list. piSessionId2 will be modified after this call
    \param[in] uiSessionId1 is the session Identifier of the RTP session which is in conference
    \param[in,out] uiSessionId2 is the session which has to be removed from conference
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE.
*/
int32
IFX_RTP_SessRemoveFromConfList(IN uint32 uiSessionId1,
                               IN uint32 uiSessionId2);

/*! \brief  Specific to PoC for associating the socket with the sess id.
    \param[in] uiSessId session identifier
    \param[in] uiPoCSessId Poc session identifier
    \return void.
*/
void
IFX_RTP_SetSessPocSessId(IN uint32 uiSessId,
                         IN uint32 uiPoCSessId);
/*! \brief  Get the remote SSRC of associated  sess id.
    \param[in] uiSessId session identifier
    \return remote SSRC.
*/

uint32 IFX_RTP_GetRxSSRC(uint32 uiSessId);

/*! \brief  Set the Sdes item associated with the sess id.
    \param[in] uiSessId session identifier
    \param[in] eSdesItem SDES item type
    \param[in] pcSdesItemValue pointer to SDES item data
    \return void
*/

void IFX_RTP_SetSdesItem(IN uint32 uiSessId,
                         IN e_IFX_RTCP_SDES_Item eSdesItem,
                         IN char8 *pcSdesItemValue);

/*! \brief  Get the Sdes item associated with the sess id or conn id.
    \param[in] uiSessId session identifier
    \param[in] ucSessRemoteEndInfo Set if remote SDES information is requested
    \param[in] eSdesItem SDES item type
    \param[in] pcSdesItemValue pointer to hold SDES item data
    \return void
*/

void IFX_RTP_GetSdesItem(IN uint32 uiSessId,
                         IN uchar8 ucSessRemoteEndInfo,
                         IN e_IFX_RTCP_SDES_Item eSdesItem,
                         OUT char8 *pcSdesItemValue);

/*! \brief  Shuts  RTP Stack & frees all the resources related to RTP. 
    \return IFX_RTP_SUCCESS or IFX_RTP_FAILURE.
*/

int8 IFX_RTP_RtpShut( void );
/* @} */
#endif /*IFX_RTP_API__H_*/
