/**************************************************************************
 **   SRC_FILE          : IFX_DECT_Agent.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <time.h>
/* According to POSIX 1003.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_TimerIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_DialPlanIf.h"
#include "IFX_Misc.h"
#include "ifx_debug.h"
#include "IFX_DialPlan.h"
#define DECT_APP 1 /* Needed to include dect stack headers */
#define FT 1

#include "IFX_DECT_Stack.h"
#include "IFX_DECT_MU.h"
#include "IFX_DECT_CSU.h"
#include "IFX_DECT_SMSU.h"
#include "IFX_DECT_DPSU.h"
#include "IFX_DECT_USU.h"
#include "IFX_DECT_Agent.h"
#include "IFX_DECT_MsgApi.h"
#include "IFX_AgentsUtils.h"
#ifdef LTQ_OSGI_POWER_OUTLET
#include "IFX_DECT_COMMIF.h"
#else
#include "IFX_DECT_ContentDownload.h"
#endif

#include "IFX_DECT_DIAG.h"
#include "IFX_DECT_ListAccess.h"
#include "IFX_DT_LAU.h"

//#include "IFX_DECT_MU_Fsm.h"
// This flag is used to test deflection
//#define DEFLECT_TEST

extern void IFX_Start_DECT(void);

extern void IFX_DECT_PageDrvClose(void);

#define IFX_MAX_VOIP_LINES 3
#define IFX_PSTN_LINE (IFX_MAX_VOIP_LINES + 1)
//#define IFX_DECT_CALL_UNDER_TRANSFER 12
/* Following definitions are used as DECT global flags in this file */
STATIC uchar8 vucCurPagingPPCount = 0;
extern boolean IFX_CMGR_IsCallAllowed(IN uint8 ucLineId, IN char8 *szEndPtId);
extern e_IFX_Return IFX_DECT_MU_RegisterCallBks(IN x_IFX_DECT_MU_CallBks *pxCCCallBks);
extern e_IFX_Return IFX_DECT_CSU_ExplicitConnect(IN uint32 uiCallHdl,IN x_IFX_DECT_CSU_CallParams *pxCallParams);
extern e_IFX_Return IFX_DECT_CSU_CallOnLineFailed(IN uint32 uiCallHdl,IN uchar8 ucLineId);
extern void IFX_DECT_InitStatus(int32 iStatus);
extern e_IFX_Return IFX_CIF_BMCRegparamGet(OUT x_IFX_DECT_BMCRegParams *pxBMCParams);
extern e_IFX_Return IFX_CIF_OscTrimParamGet(OUT x_IFX_DECT_OscTrimVal *pxOscTrimVal);
extern e_IFX_Return IFX_CIF_TPCValGet(OUT x_IFX_DECT_TransmitPowerParam *pxTpcGet);
extern e_IFX_Return IFX_CIF_RFPIGet(OUT uchar8 *paxRFPI);
extern void IFX_DECT_UnInitStack(void); 
extern e_IFX_Return IFX_CFG_Start_DECT(void); 
#ifdef DECT_PART
extern void LTQ_Init_ParamsFromDectPart();
#endif
#define IFX_DECT_PAGING_STARTED(pxEndptInfo) { \
		++vucCurPagingPPCount; \
	}
#define IFX_DECT_PAGING_STOPPED(pxEndptInfo) { \
		--vucCurPagingPPCount; \
	}

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
extern uchar8  vcDECTModId; 
#endif

#if defined(DECT_SUPPORT) 
int vuidect_drv_fd;
int vuitimer_fd;
extern int dect_drv_fd;
extern int timer_fd; 
#endif

#define WriteFifo(Fd, pcBuf, bufSize) write(Fd, pcBuf, bufSize)
#define printf(...)
/* TODO :: FOLLOWING DEFINITIONS TO BE MOVED TO CONFIG HEADER FILE */
#define IFX_DECT_RINGPAUSE_ON_DURATION		2000  /* in ms*/
#define IFX_DECT_RINGPAUSE_OFF_DURATION		4000  /* in ms*/
#define IFX_DECT_REG_DURATION		        60000 /* in ms*/
#define IFX_DECT_BUSY_TONE_TIMER	        5000  /* in ms */
#define IFX_DECT_ERROR_TONE_TIMER	        IFX_DECT_BUSY_TONE_TIMER	
#define IFX_DECT_DIAL_TONE_TIMER	        30000 /* in ms */
#define IFX_DECT_PAGING_TIMER		        30000 /* in ms*/
#define IFX_DECT_REG_KEY_PRESS_DUR	        5000  /* in ms*/

#define IFX_DECT_DIAL_TONE		        IFX_DECT_SIGNAL_DialTone
#define IFX_DECT_BUSY_TONE		        IFX_DECT_SIGNAL_BusyTone
#define IFX_DECT_INTERCEPT_TONE		    IFX_DECT_SIGNAL_InterceptTone
#define IFX_DECT_ERROR_TONE		        IFX_DECT_SIGNAL_ErrorBeep
#define IFX_DECT_CONFIRMATION_TONE		IFX_DECT_SIGNAL_ConfirmTone
#define IFX_DECT_RINGBACK_TONE		    IFX_DECT_SIGNAL_RingBackTone
#define IFX_DECT_CALL_WAITING_TONE		IFX_DECT_SIGNAL_CallWaitTone
#define IFX_DECT_OFF_HOOK_TONE		    IFX_DECT_SIGNAL_OffHookWarn_Tone 
#define IFX_DECT_STUTTER_TONE		      IFX_DECT_SIGNAL_NotificationTone
#define IFX_DECT_INVALID_TONE		      0xFF //DUMMY_FILL //TODO: Check 0xFF is OK??

//#define TEST_MEDIA_NEG 1
#define WRITE_SUBS_INFO

/* This array is used to store DECT endpoint FSM Infomration */
STATIC x_IFX_DECT_EndptFsmInfo vaxDectEndptFsmInfo[IFX_MMGR_MAX_DECT_CHANNELS];
uchar8 vucDectAgnetModId; /* DECT Agent Module Id */
uint32 viDectStackMode; /* Dect Stack Mode*/
uint32 vuiDateTimerTimerId;
#ifndef TONES
#define INTERNAL_CALL_CLASS 0x90
#endif
extern int32 viAgentFifoFd;
/* ----- Following are utility routines used in DECT Agent ----- */
STATIC e_IFX_Return IFX_DECT_CbRegisterWithCmgr(
					IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo );

STATIC e_IFX_Return IFX_DECT_GetEndptInfoById(
														 IN char8* szEndptId,
														 OUT x_IFX_DECT_EndptFsmInfo **ppxEndPtInfo );
char8 IFX_DECT_HsIdFromEPName(IN char8* szEndptId);
e_IFX_Return IFX_CIF_CNIPGet(IN boolean,IN uchar8,IN char8 *,IN OUT char8 *);
e_IFX_Return IFX_CIF_LineAssocSet(IN uchar8,IN uchar8);
e_IFX_Return 
IFX_DECTAPP_CSU_CallIntercept(IN uint32 uiCallHdl,
                             IN uchar8 ucHandsetId,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
			                       OUT e_IFX_DECT_ErrReason *pucRejectReason,
                             OUT  uint32 *puiPrivateData);
void IFX_DECT_InterceptTimerFired(IN uint32 uiTimerId,IN void* pvPrivateData);
e_IFX_Return 
IFX_DECT_IntrudeHdlr(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                      IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                      OUT e_IFX_ReasonCode* peReason );

STATIC e_IFX_Return IFX_DECT_GetEndptInfoByInstance(
														 IN uchar8 u8Instance,
														 OUT x_IFX_DECT_EndptFsmInfo **ppxEndPtInfo );

STATIC void IFX_DECT_FsmTimerFired(
										 IN uint32 uiTimerId,
										 IN void* pvPrivateData );


STATIC e_IFX_Return IFX_DECT_ExecuteDialPlan(
	                           IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo, 
										         IN e_IFX_DP_Action eDpAction, 
										         IN char8* pszDialOut, 
										         OUT uchar8* pucSignal, 
										         OUT e_IFX_DECT_States* peState );

STATIC e_IFX_Return IFX_DECT_InitiateCall(
                     IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
										 IN x_IFX_CMGR_AddressInfo* pxDialedAddr,
										 IN e_IFX_CMGR_FeatStatus eCidStatus,
	                   IN boolean bEmergencyCall,
	                   OUT e_IFX_CMGR_Status* peStatus,
	                   OUT e_IFX_ReasonCode* peReason );

STATIC e_IFX_Return IFX_DECT_RemotePartyAnswered(
	                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo );

STATIC e_IFX_Return IFX_DECT_HandleHoldSuccess(
	                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                    OUT e_IFX_DECT_States* peState);

STATIC e_IFX_Return IFX_DECT_ActiveCallHold(
	                      IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo);
STATIC e_IFX_Return IFX_DECT_CallResume(
	                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                    IN x_IFX_DECT_CallInfo* pxCallTobeResumed);
STATIC e_IFX_Return IFX_DECT_MakeConference(
	                      IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo);
STATIC e_IFX_Return IFX_DECT_InitiateAutoRedial( 
	                      IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo );
STATIC e_IFX_Return IFX_DECT_SendAutoRedialNtfy(
	                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                    IN boolean bNotify );
STATIC e_IFX_Return IFX_DECT_ResumeCallInBusy(
	                      IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo);
STATIC e_IFX_Return IFX_DECT_ActDeActvAutoRedial(
	                   IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                   IN boolean bActivate );

STATIC uint32 IFX_DECT_GetCmgrCodec(e_IFX_MMGR_CodecType eMmgrCodecType);
STATIC e_IFX_MMGR_CodecType IFX_DECT_GetMmgrCodec(uint32 uiCodec);

STATIC e_IFX_Return IFX_DECT_ConvertCodecToMMGR(
	                      OUT x_IFX_MMGR_CodecList* pxMmgrList, 
	                      IN x_IFX_CodecList* pxCifList);

STATIC e_IFX_Return IFX_DECT_ConvertCodecToCmgr(
	                      OUT x_IFX_CodecList* pxList,
	                      IN x_IFX_MMGR_CodecList* pxMmgrList);

STATIC boolean IFX_DECT_IsWidebandCodec(e_IFX_MMGR_CodecType eCodecType);

STATIC char8* IFX_DECT_GetStateStr( IN e_IFX_DECT_States eState );
STATIC char8* IFX_DECT_GetEventStr( IN  e_IFX_DECT_Event eEvent);

e_IFX_Return IFX_DECT_FsmHdlr_1(
                          IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                          IN x_IFX_DECT_EventInfo* pxEvtInfo,
                          OUT e_IFX_ReasonCode* peReason );


e_IFX_Return IFX_DECT_ActivateAfterServiceChange(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo, boolean bScStatus);


e_IFX_Return IFX_DECT_GetTimeDate(OUT x_IFX_DECT_USU_TimeDate *pxTimeDate);

/* List Access */
e_IFX_Return IFX_DECTAPP_ListAccessNtfn(
                IN char8 *pszEndPtId,
                IN e_IFX_CMGR_LA_Type eLAType,
                IN void *pxOld,
                IN void *pxNew);

e_IFX_Return IFX_DECTAPP_FreeVmapiObj (IN e_IFX_CMGR_LA_Type eLAType,
                                         IN void *pxOld,
                                         IN void *pxNew);

e_IFX_Return IFX_DECTAPP_DateTimeNtfn(IN char8 *pszEndPtId,
                                      IN void *pxOld,
                                      IN void *pxNew);

e_IFX_Return IFX_DECT_GetEndptName(IN uchar8 ucHandSetId,
																	 OUT char8 *szEndptId);

void                                                                                                                                                                         
IFX_DECT_EndpointLineIdSet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,                                                                                                          
                           IN uchar8 ucLineId);
void                                                                                                                                                                         
IFX_DECT_EndpointLineIdGet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,                                                                                                          
                           OUT IN uchar8 *pucLineId);                                                                                                                                                                         
e_IFX_Return                                                                                                                                                                 
IFX_DECT_IsEndpointLineIdSet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo);

#define IFX_DECT_GetCallInfo(pxEndpt, CallId, ppxCallInfo) \
	{ \
		if( (pxEndpt)->axCallInfo[0].uiCallId == (CallId) ) \
			*(ppxCallInfo) = ((pxEndpt)->axCallInfo+0); \
		else if( (pxEndpt)->axCallInfo[1].uiCallId == (CallId) ) \
			*(ppxCallInfo) = ((pxEndpt)->axCallInfo+1); \
		else \
			*(ppxCallInfo) = 0; \
	}

#define IFX_DECT_GetFreeCallInfo(pxEndpt, ppxCallInfo) \
	{ \
		if( (pxEndpt)->axCallInfo[0].uiCallId == 0 ) \
			*(ppxCallInfo) = ((pxEndpt)->axCallInfo+0); \
		else if( (pxEndpt)->axCallInfo[1].uiCallId == 0) \
			*(ppxCallInfo) = ((pxEndpt)->axCallInfo+1); \
		else \
			*(ppxCallInfo) = 0; \
	}

#define IFX_DECT_GetWaitingCallInfo(pxEndpt, ppxWaitingCall) \
	{ \
		if( IFX_DECT_CS_RINGING ==  pxEndpt->axCallInfo[0].eState ) \
			*(ppxWaitingCall) = (pxEndptInfo->axCallInfo + 0); \
		else if( IFX_DECT_CS_RINGING == pxEndptInfo->axCallInfo[1].eState ) \
			*(ppxWaitingCall) = (pxEndptInfo->axCallInfo + 1); \
		else \
			*(ppxWaitingCall) = 0; \
	}

/*
 * This routine returns last held call of a given endpoint.
 */
#define IFX_DECT_GetLastHeldCall(pxEndpt, ppxLastHeldCall) \
	{ \
		if( IFX_DECT_CS_HELD == pxEndpt->axCallInfo[0].eState ) \
			*(ppxLastHeldCall) = (pxEndpt->axCallInfo+0); \
		else if( IFX_DECT_CS_HELD ==  pxEndpt->axCallInfo[1].eState ) \
			*(ppxLastHeldCall) = (pxEndpt->axCallInfo+1); \
		else \
			*(ppxLastHeldCall) = 0; \
	}

#define IFX_DECT_ResetCall(pxRelCall,bRelease) \
	{ \
		if(pxRelCall){ \
		  if((bRelease)&&(pxRelCall->uiDTkCallId > 0)){\
		    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, \
					            "Calling IFX_DECT_CSU_CallRelease"); \
	      IFX_DECT_CSU_CallRelease(pxRelCall->uiDTkCallId,NULL,IFX_DECT_RELEASE_NORMAL);\
		  }\
		  memset(pxRelCall,0,sizeof(x_IFX_DECT_CallInfo)); \
		}\
	} 

#define IFX_DECT_UpdateCallState(pxEndpt, pxCall, eCallState) \
	{ \
		(pxCall)->eState = eCallState; \
	}

#define IFX_DECT_UpdateEndptState(pxEndpt, state) \
	{ \
		pxEndpt->eState = state; \
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO, \
				pxEndpt->szEndptId, IFX_DECT_GetStateStr(pxEndpt->eState) ); \
	} 
#define IFX_DECT_FsmTimerStart(pxEndpt, eEvent, uiDuration,  pTimerId) \
	{ \
		x_IFX_DECT_TimerEvent xTimerEvt={0}; \
		xTimerEvt.eTimerEvent = eEvent; \
		xTimerEvt.pxEndptInfo = pxEndpt; \
    if( IFX_SUCCESS != IFX_TIM_TimerStart(uiDuration,  \
				&xTimerEvt, sizeof(x_IFX_DECT_TimerEvent), IFX_DECT_FsmTimerFired, (pTimerId) ) ) \
	  { \
		  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, \
					"Could Not Start Timer"); \
		} \
	}

void IFX_DECT_ShutDown(void)
{
		if( IFX_TRUE == IFX_DECT_IsDectStackInitialized() )
		{
#ifndef LTQ_OSGI_POWER_OUTLET
			IFX_DECT_DPSU_ShutDectDataApp (NULL);/*Shuts SUOTA/CD thread of application*/
#endif
			IFX_DECT_Shut();/*Shuts Stck thread and modem*/
			IFX_DECT_UnInitStack();/*Set the stack init flag to FALSE*/
			//IFX_DECT_PageDrvClose();/*Close Page driver*/
		}
		else
		{
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"DECT has not been started so Ignore this request..." );
		}

		return;
}
e_IFX_Return  IFX_DECT_Start(void)
{
		if( IFX_TRUE != IFX_DECT_IsDectStackInitialized() )
		{
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"Re/Start DECT...." );
			return IFX_CFG_Start_DECT();
		}
		else
		{
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"DECT has not been Shutdown before....so no need to start again" );
		}

	return IFX_SUCCESS;
}
STATIC e_IFX_Return IFX_DECT_PlayTone(x_IFX_DECT_EndptFsmInfo* pxEndptInfo,uint32 uiDTkCallId, 
	                                    uchar8 ucSignal);
STATIC e_IFX_Return IFX_DECT_StopTone(x_IFX_DECT_EndptFsmInfo* pxEndptInfo,uint32 uiDTkCallId);
e_IFX_Return
IFX_CIF_LineIdListGet(uchar8 *pucLineId);

e_IFX_Return IFX_DECTAPP_PeerHandsetIdsGet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                                           OUT char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
                                           OUT uchar8 *pucCount){
	uchar8 ucIndex = 0;
  uchar8 ucCount = 0;
  e_IFX_Return eRet = IFX_FAILURE;

	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
    printf("\n vaxDectEndptFsmInfo[ucIndex].szCallerName = %s\n",vaxDectEndptFsmInfo[ucIndex].szCallerNumber);
    printf("\n pxEndptInfo->szEndptId = %s\n",pxEndptInfo->szEndptId);
		if((strcmp(vaxDectEndptFsmInfo[ucIndex].szCallerNumber, pxEndptInfo->szEndptId) == 0)&&
			((vaxDectEndptFsmInfo[ucIndex].eState==IFX_DECT_STATE_ALERTING)||
			(vaxDectEndptFsmInfo[ucIndex].eState==IFX_DECT_STATE_CALL_WAITING)))
		{
      strcpy(aszEndptId[ucCount],vaxDectEndptFsmInfo[ucIndex].szEndptId);
      printf("\n Forked EndptId %d = %s\n",ucCount+1,aszEndptId[ucCount]);
			ucCount++;
		}
  }

  if(ucCount){
    *pucCount = ucCount;
    eRet = IFX_SUCCESS;
  }
  return eRet;
}

e_IFX_Return 
IFX_DECTAPP_UpdateEndPtId(char8 *pcOldEndPtId, char8 *pcNewEndPtId)
{
  int32 i=0;
  printf("EndPoint Id Old %s New %s\n",pcOldEndPtId,pcNewEndPtId);
  for(i=0;i < IFX_MMGR_MAX_DECT_CHANNELS;i++) {
    if(!strcmp(vaxDectEndptFsmInfo[i].szEndptId,pcOldEndPtId))
	  {
	    strcpy(vaxDectEndptFsmInfo[i].szEndptId, pcNewEndPtId);
      printf("New EndPoint Id is %s for instance %d\n",vaxDectEndptFsmInfo[i].szEndptId,i);
		  return IFX_SUCCESS;
	  }
  }
  return IFX_FAILURE;


}

e_IFX_Return 
IFX_DECT_GetEndPtInfoFromCallHdl(IN uint32 uiCallHdl, 
						  IN_OUT  x_IFX_DECT_EndptFsmInfo **pxEndptInfo)
{
  int32 i=0, j=0;
  for(i=0;i < IFX_MMGR_MAX_DECT_CHANNELS;i++) {
    for(j=0;j <IFX_MAX_DECT_CALLS;j++) {
      if(vaxDectEndptFsmInfo[i].axCallInfo[j].uiDTkCallId == uiCallHdl)
	  {
	    *pxEndptInfo = &vaxDectEndptFsmInfo[i]; 
      printf("State is %d\n",vaxDectEndptFsmInfo[i].axCallInfo[j].eState);
		return IFX_SUCCESS;
	  }
    }
  }
  return IFX_FAILURE;
}

e_IFX_Return 
IFX_DECT_GetEvtInfoFromCallHdl(IN uint32 uiCallHdl, 
						  IN  x_IFX_DECT_EndptFsmInfo *pxEndptInfo,
						  IN_OUT x_IFX_DECT_CallInfo **pxCallInfo)
{
  int32 i=0;
  *pxCallInfo = NULL;
  for(i=0;i<IFX_MAX_DECT_CALLS;i++) {
    if(pxEndptInfo->axCallInfo[i].uiDTkCallId == uiCallHdl)
	{
	  *pxCallInfo = &pxEndptInfo->axCallInfo[i]; 
	  return IFX_SUCCESS;
	}    
  }
  return IFX_FAILURE;
}

e_IFX_Return 
IFX_DECT_IsEndPtInCall(IN char8 *pxTId)
{
  x_IFX_DECT_EndptFsmInfo *pxEndPtInfo = NULL;
  
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "Entry");
  if((IFX_FAILURE==IFX_DECT_GetEndptInfoById(pxTId,&pxEndPtInfo))||(*pxTId=='\0')){
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTId, "!! This Endpoint Does Not Exist !!" );
		return IFX_FAILURE;
	}
  if (((pxEndPtInfo->axCallInfo[0].uiCallId != 0)&&(pxEndPtInfo->axCallInfo[1].uiCallId == 0))
     ||((pxEndPtInfo->axCallInfo[0].uiCallId == 0)&&(pxEndPtInfo->axCallInfo[1].uiCallId != 0))){
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}

e_IFX_Return 
IFX_DECT_GetListOfEndPtInCall(IN  x_IFX_DECT_EndptFsmInfo *pxEndptInfo,
						               IN_OUT char8  *pacEndPtList,
						               IN_OUT uint32  *puiCount)
{
  int32 i=0;
  int32 iCount=0;
  *puiCount =0;
  
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "Entry");
  for(i=0;i < IFX_MMGR_MAX_DECT_CHANNELS;i++) {
    if((vaxDectEndptFsmInfo[i].axCallInfo[0].uiCallId != 0)&&(vaxDectEndptFsmInfo[i].axCallInfo[1].uiCallId != 0)){
      /* Endpoint is already involved in two calls */
    }else if (((vaxDectEndptFsmInfo[i].axCallInfo[0].uiCallId != 0)&&(vaxDectEndptFsmInfo[i].axCallInfo[1].uiCallId == 0))
           ||((vaxDectEndptFsmInfo[i].axCallInfo[0].uiCallId == 0)&&(vaxDectEndptFsmInfo[i].axCallInfo[1].uiCallId != 0))){
	    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			    "Endpoint =", i);
      *(pacEndPtList+iCount) = i+1;
      iCount++;
    }
  }
  if(iCount > 0){
    *puiCount = iCount;
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}

e_IFX_Return 
IFX_DECT_AnyCallInSystem(void)
{
  int32 i=0;
  int32 iCount=0;
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "Entry");
  for(i=0;i < IFX_MMGR_MAX_DECT_CHANNELS;i++) {
    if((vaxDectEndptFsmInfo[i].axCallInfo[0].uiCallId != 0)&&(vaxDectEndptFsmInfo[i].axCallInfo[1].uiCallId != 0)){
      /* Endpoint is already involved in two calls */
    }else if (((vaxDectEndptFsmInfo[i].axCallInfo[0].uiCallId != 0)&&(vaxDectEndptFsmInfo[i].axCallInfo[1].uiCallId == 0))
           ||((vaxDectEndptFsmInfo[i].axCallInfo[0].uiCallId == 0)&&(vaxDectEndptFsmInfo[i].axCallInfo[1].uiCallId != 0))){
	    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			    "Endpoint =", i);
      iCount++;
    }
  }
  if(iCount > 0){
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}

/*****************************Call Init Success****************************/
e_IFX_Return
IFX_DECTAPP_CSU_LineInfo(uchar8 ucHandsetId,IN x_IFX_DECT_CSU_CallParams *pxCallParams){
	x_IFX_DECT_CSU_LineInfo xLineInfo={0};
	uchar8 ucLineId=0,ucDefaultLineId=0;
	e_IFX_ReasonCode eReason;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	
	if( IFX_SUCCESS != 
			IFX_DECT_GetEndptInfoByInstance(ucHandsetId-1, &pxEndptInfo) )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Could Not Get Handset Info (Invalid Instance Number)" );
		return IFX_FAILURE;
	}
	IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, &ucDefaultLineId, &eReason);
		if(!pxCallParams->ucLineId&&(pxEndptInfo->uiTermCap&IFX_DECT_MU_HS_CAT2)){
  		if(!((pxCallParams->ucLineId >= 1) &&(pxCallParams->ucLineId <=4 ))){
	 		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			" Wrong Line ID received =", pxCallParams->ucLineId);
    		ucLineId = ucDefaultLineId;
  	}else{
				ucLineId=pxCallParams->ucLineId;
		}
   		xLineInfo.bMode= IFX_CIF_IsLineTypeMulti(ucLineId); 
   		xLineInfo.isCallPossible=IFX_CMGR_IsCallAllowed(ucLineId,pxEndptInfo->szEndptId);
   		xLineInfo.ucLineId=ucLineId;
			xLineInfo.bIntrude=IFX_CIF_IsIntrusionAllowed(ucLineId);
			if(xLineInfo.bMode==0&&xLineInfo.isCallPossible==0&&xLineInfo.bIntrude==1){
				pxCallParams->ucLineId=ucLineId;
			}
		}else{
			xLineInfo.isCallPossible=1;
		}
/*
	If Line Id is not received there is a possibility that PT may choose the line
  other than default line. So allow the call in that case
*/
		if(pxCallParams->ucLineId!=ucLineId){
			xLineInfo.isCallPossible=1;
		}
	IFX_DECT_CSU_SetLineInfo(ucHandsetId,pxCallParams,&xLineInfo);
	return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallIncoming
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is incoming call for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_OffHook 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_PP_OffHook event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_CSU_CallIncoming(IN uint32 uiCallHdl,
                             IN uchar8 ucHandsetId,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
			                       OUT e_IFX_DECT_ErrReason *pucRejectReason,
                             OUT  uint32 *puiPrivateData)
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_Return eRet =  IFX_FAILURE;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	//boolean bFlag=0;
	
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "IFX_DECTAPP_CSU_CallIncoming");
	if(pxCallParams->eCallType==IFX_DECT_CALL_INTERCEPT_REQ){
		if((atoi(pxCallParams->acRecvDigits) < 7)&&(atoi(pxCallParams->acRecvDigits) >0)&&
				(IFX_DECT_IsEndPtInCall(pxCallParams->acRecvDigits)==IFX_SUCCESS)){
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "Intercept Req:Active calls found:Calling CSU_CallIntercept");
    	eRet=IFX_DECTAPP_CSU_CallIntercept(uiCallHdl,ucHandsetId,pxCallParams,pucRejectReason,puiPrivateData);
	  	return eRet;
		}else if((IFX_DECT_AnyCallInSystem()==IFX_SUCCESS)&&(pxCallParams->acRecvDigits[0] == '*')){
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "Intercept Req:Active calls found:Calling CSU_CallIntercept");
    	eRet=IFX_DECTAPP_CSU_CallIntercept(uiCallHdl,ucHandsetId,pxCallParams,pucRejectReason,puiPrivateData);
	  	return eRet;
		}
		memset(pxCallParams->acRecvDigits,0,sizeof(pxCallParams->acRecvDigits));
  }else if(pxCallParams->eCallType==IFX_DECT_CALL_INTRUSION_REQ){
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Intrude Req");
    eRet=IFX_DECTAPP_CSU_CallIntercept(uiCallHdl,ucHandsetId,pxCallParams,pucRejectReason,puiPrivateData);
	  return eRet;
	}
	if( IFX_SUCCESS != 
			IFX_DECT_GetEndptInfoByInstance(ucHandsetId-1, &pxEndptInfo) )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Could Not Get Handset Info (Invalid Instance Number)" );
		return IFX_FAILURE;
	}
/*Added for checking digits received or not for a parallel call*/
#if 0
	if((IFX_DECT_IsEndPtInCall(pxEndptInfo->szEndptId)==IFX_SUCCESS)&&(pxCallParams->acRecvDigits[0]=='\0')){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"No digits for parallel call" );
		return IFX_FAILURE;
	}	
#endif
  if((pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_HPP) == IFX_DECT_MU_HS_HPP){
    /* Headset PP */
  }
#if 0
	if(pxCallParams->ucLineId==0x7F){
		e_IFX_ReasonCode eReason;
		bFlag=1;
		IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId,&pxCallParams->ucLineId, &eReason); 
	}
#endif

  /* Clear the ATX IGNORE Flag if set, It was retained during make endpoint idle as this flag was checked after 
     Endpoint was cleared*/
  IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_IGNORE_ATXSTATUS);
  
  if(!((pxCallParams->ucLineId >= 1) &&(pxCallParams->ucLineId <=4 ))){
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			" Wrong Line ID received  in CallIncoming =", pxCallParams->ucLineId);
     pxCallParams->ucLineId = 0xFF;
#if 0
/*SBB: Testing purpose*/
    pxCallParams->ucLineId = 0x01;
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			" Wrong Line ID received  in CallIncoming but setting to 1.Please remove this after test=", pxCallParams->ucLineId);
#endif
  }

	if((pxCallParams->ucLineId != 0xFF))
	{ 
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Line ID received from DECT Tk in CallIncoming =", pxCallParams->ucLineId);
      IFX_DECT_EndpointLineIdSet(pxEndptInfo,pxCallParams->ucLineId);
		/*SBB: to make it work for D&A :TC_FT_NG1.N.20_BV_202
  		if Hs specifies the same line id which is being used and line is in single call mode then send busy immeditely*/
		if((IFX_FALSE == IFX_CIF_IsLineTypeMulti(pxCallParams->ucLineId)) &&
      (IFX_FALSE == IFX_CMGR_IsCallAllowed(pxCallParams->ucLineId,pxEndptInfo->szEndptId)))
		{
	  	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Single call mode but Line ID received= which is already used so return failure", pxCallParams->ucLineId);
			return IFX_FAILURE;
		}

	}
#if 0
		if((IFX_DECT_IsEndPtInCall(pxEndptInfo->szEndptId)== IFX_SUCCESS)){
    if((IFX_FALSE == IFX_CMGR_IsCallAllowed(pxCallParams->ucLineId,pxEndptInfo->szEndptId))) {
			if((IFX_CIF_IsIntrusionAllowed(pxCallParams->ucLineId))&&(!strlen(pxCallParams->acRecvDigits))&&
				(pxEndptInfo->uiTermCap&IFX_DECT_MU_HS_CAT2)&&(IFX_DECT_IsEndPtInCall(pxEndptInfo->szEndptId)!= IFX_SUCCESS)){
			/*Implicit Intrude*/
     			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Implicit Intrusion"); 
					pxEndptInfo->uiDTkCallId=uiCallHdl;
					evtInfo.eEvent = IFX_DECT_EVT_Intercept;
					strcpy(evtInfo.uxEventData.xSetupEvt.xDigitInfo.szDigits,pxCallParams->acRecvDigits);
					evtInfo.uxEventData.xSetupEvt.ucLineId=pxCallParams->ucLineId;
					evtInfo.uxEventData.xSetupEvt.uiTmpDtkCallHdl = uiCallHdl;
					*puiPrivateData = (uint32)pxEndptInfo;
					IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_REQ);
					eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
					return IFX_PENDING;
			}else if(!bFlag){ 
     		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Can't take second call on this line - fail");
				 
     		return IFX_FAILURE; 
		  }
    }
		else{
    /*Set Line Id for the Handset Call received in pxCallParams*/
    	if(IFX_FAILURE == IFX_DECT_IsEndpointLineIdSet(pxEndptInfo)){
      	IFX_DECT_EndpointLineIdSet(pxEndptInfo,pxCallParams->ucLineId);
    	}
		}
	}
}
#endif

	/* Store the CallHdl of DectToolkit.*/
	evtInfo.uxEventData.xSetupEvt.uiTmpDtkCallHdl = uiCallHdl;
  pxEndptInfo->uiDTkCallId = uiCallHdl;	
   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			       "INIT: CALL Handle From Toolkit=%d\n\n\n",uiCallHdl);

	/* Construct the Event Info for the FSM*/
	evtInfo.eEvent = IFX_DECT_EVT_PP_OffHook;
	strcpy(evtInfo.uxEventData.xSetupEvt.xDigitInfo.szDigits,pxCallParams->acRecvDigits);
	evtInfo.uxEventData.xSetupEvt.ucBasicService = pxCallParams->eCallType;

  printf("\n Basic Service in Agent =%x\n",pxCallParams->eCallType);

  if((pxEndptInfo->pxActiveCall != NULL)&&(pxEndptInfo->pxActiveCall == &pxEndptInfo->axCallInfo[0])){
    pxEndptInfo->axCallInfo[1].eCallType = pxCallParams->eCallType;
  }else
    pxEndptInfo->axCallInfo[0].eCallType = pxCallParams->eCallType;

	*puiPrivateData = (uint32)pxEndptInfo;
	evtInfo.uxEventData.xSetupEvt.aunCodec[0] =
		(IFX_TRUE==pxCallParams->bwideband)?IFX_DECTNG_CODEC_G722_64:IFX_DECTNG_CODEC_G726_32;
	eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  if(IFX_SUCCESS != eRet)
  {
	  *pucRejectReason = evtInfo.uxEventData.xSetupEvt.ucRejectReason; 
  }
	return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallAccept
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is incoming call for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_Alert 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_PP_OffHook event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallAccept(IN uint32 uiCallHdl,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
														 IN uint32 uiPrivateData)
{
   x_IFX_DECT_EventInfo evtInfo = {0};
   e_IFX_ReasonCode eReason;
   e_IFX_Return eRet =  IFX_FAILURE;

   x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
   if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
   }
   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");

   evtInfo.eEvent = IFX_DECT_EVT_PP_Alert;
   evtInfo.uxEventData.aunCodec[0] = IFX_DECTNG_CODEC_G726_32;
   if(pxCallParams->bwideband){
  	evtInfo.uxEventData.aunCodec[0] = IFX_DECTNG_CODEC_G722_64;
   }
   IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Codec Selected By Pp In Alert (DECT)=", evtInfo.uxEventData.aunCodec[0]);

   eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
   return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallAnswer
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is incoming call for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_OffHook 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_PP_OffHook event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallAnswer(IN uint32 uiCallHdl,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
														 IN uint32 uiPrivateData)
{
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode eReason;
  //e_IFX_Return eRet =  IFX_FAILURE;
  char8 szEndptId[IFX_MAX_ENDPOINTID_LEN] = "";
  x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
  x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
  x_IFX_DECT_CSU_CallParams xCallParams = {0};

  if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");
 
  /* Star Dialing */ 
  if(pxCallParams->isInternal == IFX_TRUE){ 

    IFX_DECT_GetEndptName(pxCallParams->ucPeerHandsetId,szEndptId);
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
		  "Endpoint Id ", szEndptId);
	  if( IFX_SUCCESS == IFX_DECT_GetEndptInfoById(szEndptId, &pxPeerEndptInfo) )
	  {
       if( !IFX_DECT_CheckEndptFlag(pxPeerEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS) ){
         /*In case of Star Dialing,pxPeerEndptInfo is the Endpoint that performs it*/ 
         strcpy(pxPeerEndptInfo->szCallerNumber,pxEndptInfo->szEndptId);
       }else{
         /* Update CLIP/CNIP For Endpt that accepts internal general call during Reinjection */
         strcpy(xCallParams.acCLIP,pxPeerEndptInfo->szCallerNumber);//CLIP
         xCallParams.uiSignal = 0xFF; 
	       if(IFX_CIF_CNIPGet(IFX_TRUE,0,pxPeerEndptInfo->szCallerNumber,pxPeerEndptInfo->szCallerName)==IFX_SUCCESS)//CNIP
           strcpy(xCallParams.acCNIP,pxPeerEndptInfo->szCallerName);
         IFX_DECT_CSU_InfoReceived(pxEndptInfo->pxActiveCall?pxEndptInfo->pxActiveCall->uiDTkCallId:pxEndptInfo->uiDTkCallId,&xCallParams);
        }  
    }
  }

	if( IFX_DECT_STATE_CALL_WAITING == pxEndptInfo->eState )
  {
    if((pxCallParams->uiFlag & IFX_DECT_FLAG_ACTIVE_CALL_REPLACE) == IFX_DECT_FLAG_ACTIVE_CALL_REPLACE) {
      evtInfo.eEvent = IFX_DECT_EVT_PP_OffHook;
    } else {
      evtInfo.eEvent = IFX_DECT_EVT_PP_HookFlash;
    }
  }
  else {
    evtInfo.eEvent = IFX_DECT_EVT_PP_OffHook;
    evtInfo.uxEventData.aunCodec[0] = IFX_DECTNG_CODEC_G726_32;
    if(pxCallParams->bwideband){
  	  evtInfo.uxEventData.aunCodec[0] = IFX_DECTNG_CODEC_G722_64;
    }
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
		  "Codec Selected By Pp In Connect (DECT)=", evtInfo.uxEventData.aunCodec[0]);
  }
  /*eRet = */IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_IntrudeInfoReceived
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when PP sends Intrude Info. 
											This generates DECT event IFX_DECT_EVT_PP_SSMsg with subtype  
 *	                  IFX_DECT_SS_INTERCEPT for DECT PP FSM. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_IntrudeInfoReceived(IN uint32 uiCallHdl,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
														 IN uint32 uiPrivateData)
{
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason=IFX_MAX_REASON;
	//e_IFX_Return eRet =  IFX_FAILURE;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
	if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"INTRUDE Info received");
	if(pxEndptInfo->uiInterceptTimerId)
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiInterceptTimerId);
		pxEndptInfo->uiInterceptTimerId = 0;
	}
	/* Construct the Event Info for the FSM*/
		evtInfo.eEvent = IFX_DECT_EVT_Intercept;
		strcpy(evtInfo.uxEventData.xSetupEvt.xDigitInfo.szDigits,pxCallParams->acRecvDigits);
		evtInfo.uxEventData.xSetupEvt.ucLineId=pxCallParams->ucLineId;
		uiPrivateData = (uint32)pxEndptInfo;
		/*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
	return IFX_SUCCESS;
}




/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_InterceptAccept
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when PP accepts intercept request. 
											This generates DECT event IFX_DECT_EVT_PP_SSMsg with subtype  
 *	                  IFX_DECT_SS_INTERCEPT for DECT PP FSM. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_InterceptAccept(IN uint32 uiCallHdl,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
														 IN uint32 uiPrivateData)
{
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason;
	//e_IFX_Return eRet =  IFX_FAILURE;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
	uint16 i=0;
	x_IFX_DECT_TimerEvent xTimerEvt={0};
	xTimerEvt.eTimerEvent = 0;

	if(pxEndptInfo){
	
	xTimerEvt.pxEndptInfo = &vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49]; 
	
	if(!(vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49].uiInterceptTimerId)){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Timer Stopped before");
    return IFX_SUCCESS;
	}

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"INTERCEPT Accept received");
			
  if(pxCallParams->acRecvDigits[0] == '#') {	
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  " # Received ..... posting to FSM");
	if(vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49].uiInterceptTimerId)
	{
		IFX_TIM_TimerStop(vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49].uiInterceptTimerId);
		vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49].uiInterceptTimerId = 0;
	}
	strcpy(vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49].szDialledDigits,pxEndptInfo->szEndptId);
    evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
    evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_INTERCEPT;
		for(i=0;i<IFX_MMGR_MAX_DECT_CHANNELS;i++){
    	if((!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2))&&(vaxDectEndptFsmInfo[i].uiFlags&IFX_DECT_F_INTERCEPT_INIT)){
				IFX_DECT_StopTone(&vaxDectEndptFsmInfo[i],vaxDectEndptFsmInfo[i].pxActiveCall->uiDTkCallId);
			}
			if(strcmp(pxEndptInfo->szEndptId,vaxDectEndptFsmInfo[i].szEndptId)){
				vaxDectEndptFsmInfo[i].uiFlags&= ~IFX_DECT_F_INTERCEPT_INIT;
			}
		}
	  /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
    if( IFX_SUCCESS != IFX_TIM_TimerStart(6000, 
					&xTimerEvt, sizeof(x_IFX_DECT_TimerEvent),IFX_DECT_InterceptTimerFired,
					&vaxDectEndptFsmInfo[(uchar8)pxEndptInfo->szDialledDigits[0]-49].uiInterceptTimerId)) 
	  { 
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
				"Could Not Start Timer"); 
  		return IFX_FAILURE;
		}
  }else {
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  "No Digits Received ..... not posting to FSM");
  }
	return IFX_SUCCESS;
}
return IFX_FAILURE;
}



/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_InfoReceived
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is incoming call for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_OffHook 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_PP_OffHook event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_InfoReceived(IN uint32 uiCallHdl,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
														 IN uint32 uiPrivateData)
{
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet =  IFX_FAILURE;
  uchar8 ucDefaultLineId = 0;
  uchar8 ucLineId = 0;
	boolean bFlag=0;

	x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
	if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"INFO received");
			
#ifndef TONES 
 	IFX_DECT_StopTone(pxEndptInfo,pxEndptInfo->uiDTkCallId);
#endif

  if(IFX_SUCCESS != IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, &ucDefaultLineId, &eReason)){ 
        return IFX_FAILURE;                                                                                                                                               
  }
  printf("LineId From DECT TK in InfoReceived %d\n",pxCallParams->ucLineId);
    /*Case when  no valid line Id was received during setup*/
  if(IFX_FAILURE == IFX_DECT_IsEndpointLineIdSet(pxEndptInfo)){
  	if(!((pxCallParams->ucLineId >= 1) &&(pxCallParams->ucLineId <=4 ))){
	 		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			" Wrong Line ID received  in Info =", pxCallParams->ucLineId);
    		ucLineId=pxCallParams->ucLineId = ucDefaultLineId;
  	}else{
				ucLineId=pxCallParams->ucLineId;
        IFX_DECT_EndpointLineIdSet(pxEndptInfo,ucLineId);// 
				bFlag=1;
		}
    if((IFX_FALSE == IFX_CIF_IsLineTypeMulti(ucLineId)) && 
    	(IFX_FALSE == IFX_CMGR_IsCallAllowed(ucLineId,pxEndptInfo->szEndptId))) { 
			if((IFX_CIF_IsIntrusionAllowed(pxCallParams->ucLineId))&&(!strlen(pxCallParams->acRecvDigits))&&
				(pxEndptInfo->uiTermCap&IFX_DECT_MU_HS_CAT2)&&(IFX_DECT_IsEndPtInCall(pxEndptInfo->szEndptId)!= IFX_SUCCESS)){
				/*Implicit Intrude*/
    		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Implicit Intrusion"); 
				x_IFX_DECT_EventInfo xEvtInfo;
				e_IFX_ReasonCode eReason;
				memset(&xEvtInfo,0,sizeof(xEvtInfo));
				xEvtInfo.uxEventData.xSetupEvt.ucLineId=pxCallParams->ucLineId;
				eRet=IFX_DECT_IntrudeHdlr(pxEndptInfo,&xEvtInfo,&eReason);
				IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_REQ);
				return eRet;
			}else if(bFlag){
    		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Can't take second call on this line - fail");
				/* For 2.0 HS send the Ack status as idle and HS has to send release either its parallel call or normal call*/
				if((pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){
					IFX_DECT_CSU_CallOnLineFailed(pxEndptInfo->uiDTkCallId,ucLineId);
    			IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_BUSY_TONE);
      		/*Move to busy but resume dialing state for 2.0 HS if held call is not NULL*/
      		IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
      		IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,   
                             IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId);
    			return IFX_SUCCESS;
				}
				/* For 1.0 HS wait till execute dial plan and send fail */
				else{
				}
			} 
    }
  }
  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
	         pxCallParams->acRecvDigits, "Digits received" );
  if((pxCallParams->acRecvDigits[0] != '\0') && (pxCallParams->bHookFlash == IFX_FALSE)) {	
	  strcpy(evtInfo.uxEventData.xDigitEvt.szDigits,pxCallParams->acRecvDigits);
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
	  evtInfo.uxEventData.xDigitEvt.szDigits, "Digits received" );
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  "digit  Received ..... posting to FSM");
	  evtInfo.eEvent = (IFX_FALSE == pxCallParams->bHookFlash)?
					  IFX_DECT_EVT_PP_DigitPressed:IFX_DECT_EVT_PP_HookFlash;
	  eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  }else if(pxCallParams->bHookFlash == IFX_TRUE) {	
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  "HOOK Flash Received ..... posting to FSM");
	  evtInfo.eEvent = IFX_DECT_EVT_PP_HookFlash;
	  eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  }else {
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  "No Digits Received ..... not posting to FSM");
  }
	return IFX_SUCCESS;
}


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_ModifyVoice
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a change in codec. 
 *	                  This asks the application to start/stop the media. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_ModifyVoice(uint32 uiCallHdl,
												x_IFX_DECT_CSU_CallParams *pxCallParams,
                        e_IFX_DECT_CSU_VoiceEventType eType,
                        uint32 uiPrivateData)
{
	x_IFX_DECT_CallInfo* pxActCall = NULL;
	x_IFX_DECT_EventInfo evtInfo = {0};
	x_IFX_MMGR_CodecInfo xCodecInfo = {0};
	x_IFX_DECT_CSU_CallParams xCallParams = {0}; 
	e_IFX_ReasonCode eReason;

	x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
	if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");
	pxActCall = pxEndptInfo->pxActiveCall;
  xCodecInfo.eCodecType = IFX_MMGR_CODEC_G726_32;
  
  if(pxCallParams->bwideband){
  	xCodecInfo.eCodecType = IFX_MMGR_CODEC_G722_64;
  }
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"The Voice Channel is (DECT)=", pxEndptInfo->unDectChannel);
  switch(eType){
   case IFX_DECT_START_VOICE:

      if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT)){
			  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					    pxEndptInfo->szEndptId, "SLot Modification IND");
         IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
         evtInfo.eEvent = IFX_DECT_EVT_PP_SlotModInd;
			  if(IFX_TRUE == pxCallParams->bwideband){
				   IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				 	        pxEndptInfo->szEndptId, "Slot Modified: Using Long Slot Now");
         evtInfo.uxEventData.xSlotModInd.unCodecType = IFX_DECTNG_CODEC_G722_64;
			  }
			  else{
				  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Slot Modified: Using Full Slot Now");
          evtInfo.uxEventData.xSlotModInd.unCodecType = IFX_DECTNG_CODEC_G726_32;
			  }
        IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
      }

			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      	   "Start Voice Event");
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
				"Codec Type: ", xCodecInfo.eCodecType);
			if( IFX_MMGR_SUCCESS != 
					IFX_MMGR_DectResActivate( pxEndptInfo->szEndptId, &xCodecInfo,
																	(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_ECHO_TCL_55)?0:1) )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
    		return IFX_FAILURE;
			}
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED);
	  if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) ) {
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
			IFX_DECT_CSU_VoiceModify(pxActCall == NULL?pxEndptInfo->uiDTkCallId: pxActCall->uiDTkCallId,
	     		    	 	         &xCallParams,
									 IFX_DECT_START_VOICE,
									 pxEndptInfo->unDectChannel);

      }

    break;
   case IFX_DECT_STOP_VOICE:	
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      	   "Stop Voice Event");
			if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      		   "Deactivate Resource");
				IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);
			  IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
			IFX_DECT_CSU_VoiceModify(pxActCall == NULL?pxEndptInfo->uiDTkCallId: pxActCall->uiDTkCallId,
	     		    	 	                   &xCallParams,
																		 IFX_DECT_STOP_VOICE,
																		 pxEndptInfo->unDectChannel);
			}
		break;
   default :
    return IFX_FAILURE;
  }

	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_ServiceChange
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a change in codec. 
 *	                  This asks the application to start/stop the media. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_ServiceChange(uint32 uiCallHdl,
												x_IFX_DECT_CSU_CallParams *pxCallParams,
                        e_IFX_DECT_CSU_CodecChangeType eType,
                        uint32 uiPrivateData)
{
	//x_IFX_DECT_CallInfo* pxActCall = NULL;
	x_IFX_DECT_EventInfo evtInfo = {0};
  //e_IFX_Return eRet=IFX_SUCCESS;
	e_IFX_ReasonCode eReason;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
	if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");
	//pxActCall = pxEndptInfo->pxActiveCall;
  
 
  switch(eType){
   case IFX_DECT_CSU_SC_REQUEST:	
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Service Change Requested By PP");
      evtInfo.eEvent = IFX_DECT_EVT_PP_SCMsg ;
      evtInfo.uxEventData.xServiceChangeInfo.eScMsgType = IFX_DECT_SC_REQUEST;
      evtInfo.uxEventData.xServiceChangeInfo.unCodecType = IFX_DECTNG_CODEC_G726_32;
      if(pxCallParams->bwideband){
  	    evtInfo.uxEventData.xServiceChangeInfo.unCodecType = IFX_DECTNG_CODEC_G722_64;
      }
      /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
		break;
   case IFX_DECT_CSU_SC_ACCEPT:
#if 0	
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "SLot Modification IND");
      if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT)){
         IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
      }
       evtInfo.eEvent = IFX_DECT_EVT_PP_SlotModInd;
			if(IFX_TRUE == pxCallParams->bwideband){
				 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				 	        pxEndptInfo->szEndptId, "Slot Modified: Using Long Slot Now");
        evtInfo.uxEventData.xSlotModInd.unCodecType = IFX_DECTNG_CODEC_G722_64;
			}
			else{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Slot Modified: Using Full Slot Now");
          evtInfo.uxEventData.xSlotModInd.unCodecType = IFX_DECTNG_CODEC_G726_32;
			}
      eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
#endif
		  break;
   case IFX_DECT_CSU_SC_REJECT:	
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Service Change Rejected By PP");
			/*
			 * Now continuing with previous codec. So we will run different codec
			 * on each call leg !!
			 */
		
      evtInfo.eEvent = IFX_DECT_EVT_PP_SCMsg ;
      evtInfo.uxEventData.xServiceChangeInfo.eScMsgType = IFX_DECT_SC_REJECT;
      /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
		break;
   default :
    return IFX_FAILURE;
  }

	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallRelease
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a change in codec. 
 *	                  This asks the application to start/stop the media. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallRelease(uint32 uiCallHdl,
			    x_IFX_DECT_CSU_CallParams *pxCallParams,
	    		    e_IFX_DECT_RelType eReason,
                            uint32 uiPrivateData)
{
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode reason;
  //e_IFX_Return eRet =  IFX_FAILURE;
  x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;
	//uint16 i=0;

  if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");
  printf("Call ID 0 = %d Call ID 1 = %d\n",pxEndptInfo->axCallInfo[0].uiDTkCallId,
         pxEndptInfo->axCallInfo[1].uiDTkCallId);
  if(pxEndptInfo->axCallInfo[0].uiDTkCallId == pxEndptInfo->axCallInfo[1].uiDTkCallId)
  {
    printf("Release is for ATX or no Call assignment\n");
    evtInfo.eEvent = IFX_DECT_EVT_PP_OnHook;
    evtInfo.uxEventData.eDectReleaseReason = eReason; 
    /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &reason);
    return IFX_SUCCESS;
  }
  else{
	  printf("Call is being released : sending IFX_DECT_EVT_PP_SSMsg\n");
    evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
    evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_RELEASE;
    evtInfo.uxEventData.xSsMsg.uiTkCallId = uiCallHdl;
  	return IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &reason);
	}

  return IFX_SUCCESS;
}

#ifdef ENABLE_ENCRYPTION 
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CipherCfm
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) for notifying change in cipher.
 *	                  This notifies the application that cipher chage request is 
 *										accepted or not. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CipherCfm(uint32 uiCallHdl,
			x_IFX_DECT_CSU_CallParams *pxCallParams,
                        uint32 uiPrivateData)
{
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode reason;
  //e_IFX_Return eRet =  IFX_FAILURE;
  x_IFX_DECT_EndptFsmInfo* pxEndptInfo =(x_IFX_DECT_EndptFsmInfo*)uiPrivateData;

  if(!pxEndptInfo){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid Handle");
    return IFX_FAILURE;
  }
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");

  evtInfo.eEvent = IFX_DECT_EVT_PP_CipherStatus;
  evtInfo.uxEventData.bCipheringStatus = pxCallParams->bCipheringStatus;
  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	"Ciphering Notification =", evtInfo.uxEventData.bCipheringStatus);
  /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &reason);
  return IFX_SUCCESS;
}
#endif  //ENABLE_ENCRYPTION

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_Hold
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a hold request comes for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_HookFlash 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                         IFX_DECT_EVT_PP_HookFlash event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallHold(IN uint32 uiCallHdl,
                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
					     OUT e_IFX_DECT_ErrReason *peStatus,
						 IN uint32 uiPrivateData)
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo = NULL;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason;
	//e_IFX_Return eRet =  IFX_FAILURE;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry");
  printf("\n\n\n\n HOLD: CALL Handle From Toolkit=%d\n\n\n",uiCallHdl);
  printf("Actual endpoint from private data=%s\n\n",((x_IFX_DECT_EndptFsmInfo*)(uiPrivateData))->szEndptId);
	if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiCallHdl,&pxEndptInfo))
	{
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Call Handle !!!!!");
    return IFX_FAILURE;
	} else {
	    if(!pxEndptInfo){
        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
	}

  if((pxCallParams->ucLineId != 0xFF) && (pxCallParams->ucLineId != 0x7F) && (pxCallParams->ucLineId != 0))
   IFX_DECT_EndpointLineIdSet(pxEndptInfo,pxCallParams->ucLineId);

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO, 
	      pxEndptInfo->szEndptId,	"Endpoint receives Hold" );
  
	evtInfo.eEvent = IFX_DECT_EVT_PP_HookFlash;
	/*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_Resume
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a hold request comes for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_HookFlash 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                         IFX_DECT_EVT_PP_HookFlash event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallResume(IN uint32 uiCallHdl,
                           IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                           OUT e_IFX_DECT_ErrReason *peStatus,
						   IN uint32 uiPrivateData)
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo = NULL;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason;
	//e_IFX_Return eRet =  IFX_FAILURE;
  
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry");
	if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiCallHdl,&pxEndptInfo))
	{
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Call Handle !!!!!");
    return IFX_FAILURE;
	} else {
	    if(!pxEndptInfo){
        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
	}
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO, 
	      pxEndptInfo->szEndptId,	"Endpoint receives Resume" );

  evtInfo.eEvent = IFX_DECT_EVT_PP_HookFlash;
  /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
	return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallDeflect
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a deflection request comes for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_SSMsg 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_PP_SSMsg event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallDeflect(IN uint32 uiCallHdl,
                           IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                           OUT e_IFX_DECT_ErrReason *peStatus,
						   IN uint32 uiPrivateData)
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo = NULL;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason;
	//e_IFX_Return eRet =  IFX_FAILURE;
  
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry");
	if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiCallHdl,&pxEndptInfo))
	{
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Call Handle !!!!!");
    return IFX_FAILURE;
	} else {
	    if(!pxEndptInfo){
        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
	}

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO, 
	      pxEndptInfo->szEndptId,	"Endpoint receives Call Deflect" );

	strcpy(pxEndptInfo->szDialledDigits, pxCallParams->acRecvDigits);
  evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
  evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_CALL_DEFLECT;
  evtInfo.uxEventData.xSsMsg.uiTkCallId = uiCallHdl;
  /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
	return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallToggle
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a hold request comes for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_HookFlash 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                         IFX_DECT_EVT_PP_HookFlash event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallToggle(IN uint32 uiSrcCallHdl,
                       IN uint32 uiDstCallHdl,
                       IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                       OUT e_IFX_DECT_ErrReason *peStatus,
					   IN uint32 uiPrivateData)
{
  x_IFX_DECT_EndptFsmInfo *pxEndptInfo;
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_Return eRet =  IFX_FAILURE;
  e_IFX_ReasonCode eReason;

  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Call Toggle received");

  printf("Source Call Hanlde %d\n",uiSrcCallHdl);
  printf("Dest Call Hanlde %d\n",uiDstCallHdl);

  if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiSrcCallHdl,&pxEndptInfo))
  {
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Src Call Handle !!!!!");
    return IFX_FAILURE;
  } else {
      if(!pxEndptInfo){
        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Src Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
  }
  printf("EndPt Handle is %d and state \n",(uint32)pxEndptInfo);  
  pxEndptInfo->uiDTkCallId = uiDstCallHdl;
  evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
  evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_TOGGLE;
  eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  return eRet;

}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallTransfer
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a hold request comes for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_HookFlash 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                         IFX_DECT_EVT_PP_HookFlash event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallTransfer(IN uint32 uiSrcCallHdl,
                       IN uint32 uiDstCallHdl,
                       IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                       OUT e_IFX_DECT_ErrReason *peStatus,
                       IN uint32 uiPrivateData)
{
  x_IFX_DECT_EndptFsmInfo *pxEndptInfo= NULL;
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode eReason;
  //e_IFX_Return eRet =  IFX_FAILURE;

  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Call Transfer received");

  if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiSrcCallHdl,&pxEndptInfo))
  {
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Src Call Handle !!!!!");
    return IFX_FAILURE;
  } else {
      if(!pxEndptInfo){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Src Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
  }

  if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiDstCallHdl,&pxEndptInfo))
	{
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Dest Call Handle !!!!!");
    return IFX_FAILURE;
	} else {
	    if(!pxEndptInfo){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Dst Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
	}
  
  evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
  evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_ATX;
  /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallConference
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is a hold request comes for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_PP_HookFlash 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                         IFX_DECT_EVT_PP_HookFlash event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CSU_CallConference(IN uint32 uiSrcCallHdl,
                               IN uint32 uiDstCallHdl,
                               IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                               OUT e_IFX_DECT_ErrReason *peStatus,
						                   IN uint32 uiPrivateData)
{
  x_IFX_DECT_EndptFsmInfo *pxEndptInfo= NULL;
  x_IFX_DECT_EventInfo evtInfo = {0};
  e_IFX_ReasonCode eReason;
  //e_IFX_Return eRet =  IFX_FAILURE;

  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Call Conference received");

  if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiSrcCallHdl,&pxEndptInfo))
  {
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Wrong Src Call Handle !!!!!");
    return IFX_FAILURE;
  } else {
      if(!pxEndptInfo){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Src Call Handle does not exist!!!!!");
        return IFX_FAILURE;
      }
  }
  
  if(IFX_SUCCESS != IFX_DECT_GetEndPtInfoFromCallHdl(uiDstCallHdl,&pxEndptInfo))
  {
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
    		         "Wrong Dest Call Handle !!!!!");
    return IFX_FAILURE;
  } else {
  	 if(!pxEndptInfo){
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "EndPointInfo for this Dst Call Handle does not exist!!!!!");
        return IFX_FAILURE;
     }
  }
  
  pxEndptInfo->uiDTkCallId = uiDstCallHdl;
  evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
  evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_MAKE_CONF;
  /*eRet =*/ IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
 
  return IFX_SUCCESS;
}


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CSU_CallIntercept
 *  Description     : This function is called by DectToolkit (it is registered 
 *	                  as callback  function) when there is an intercept request 
 *	                  from a PP. This generates DECT event IFX_DECT_EVT_Intercept 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_Intercept event. 
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_CSU_CallIntercept(IN uint32 uiCallHdl,
                             IN uchar8 ucHandsetId,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
			                       OUT e_IFX_DECT_ErrReason *pucRejectReason,
                             OUT  uint32 *puiPrivateData)
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_Return eRet =  IFX_FAILURE;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	boolean bPostToFsm = IFX_TRUE;
	
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "IFX_DECTAPP_CSU_CallIntercept");
  
	if( IFX_SUCCESS != 
			IFX_DECT_GetEndptInfoByInstance(ucHandsetId-1, &pxEndptInfo) )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Could Not Get Handset Info (Invalid Instance Number)" );
		return IFX_FAILURE;
	}
	IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_REQ);
	if(pxCallParams->eCallType==IFX_DECT_CALL_INTRUSION_REQ){	
		IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_REQ);
		pxEndptInfo->uiFlags &= ~IFX_DECT_F_INTERCEPT_REQ;
		/* Intrude Info not received in the Setup*/
		if((strlen(pxCallParams->acRecvDigits) == 0)&&(pxCallParams->ucLineId == 0xFF)){
		x_IFX_DECT_TimerEvent xTimerEvt={0};
		xTimerEvt.eTimerEvent = 0;
		pxEndptInfo->uiInterceptTimerId = 0; 
		xTimerEvt.pxEndptInfo = pxEndptInfo; 
    if( IFX_SUCCESS != IFX_TIM_TimerStart(6000, 
					&xTimerEvt, sizeof(x_IFX_DECT_TimerEvent),IFX_DECT_InterceptTimerFired,&pxEndptInfo->uiInterceptTimerId)){ 
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
							"Could Not Start Timer"); 
  		return IFX_FAILURE;
		}
			bPostToFsm = IFX_FALSE;
		}
	}
	/* Store the CallHdl of DectToolkit.*/
  pxEndptInfo->uiDTkCallId = uiCallHdl;	
   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			       "INIT: CALL Handle From Toolkit=%d\n\n\n",uiCallHdl);

	/*Post to fsm if intrude/intercept info received in setup*/
	if(bPostToFsm == IFX_TRUE){
	/* Construct the Event Info for the FSM*/
		evtInfo.eEvent = IFX_DECT_EVT_Intercept;
		strcpy(evtInfo.uxEventData.xSetupEvt.xDigitInfo.szDigits,pxCallParams->acRecvDigits);
		evtInfo.uxEventData.xSetupEvt.ucLineId=pxCallParams->ucLineId;
		*puiPrivateData = (uint32)pxEndptInfo;
		eRet = IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
	}else{
		eRet=IFX_SUCCESS;
	}
  if(IFX_SUCCESS != eRet)
  {
	  *pucRejectReason = evtInfo.uxEventData.xSetupEvt.ucRejectReason; 
  }
	if(bPostToFsm==IFX_FALSE){return IFX_SUCCESS;}
	if(eRet==IFX_FAILURE){return IFX_FAILURE;}else{return IFX_PENDING;}
}


#ifdef MESSAGE_SUPPORT
#define IFX_DECT_SMSU_MAX_PREAM_SIZE 16
#define IFX_VMAPI_MAX_DECT_ENDPTS 6
x_IFX_CMGR_Msg_Info vaxMsgInfo[IFX_VMAPI_MAX_DECT_ENDPTS][IFX_DECT_SMSU_MAX_MESG];

e_IFX_Return
IFX_DECTAPP_GetMsgHdl(IN uchar8 ucMesgIndex,
											IN uchar8 ucLineId,
											IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
											OUT uint32 *puiMsgHdl)
{
	uint32 uiMsgHdl;
	uiMsgHdl = ucMesgIndex;
	uiMsgHdl = uiMsgHdl | ucLineId<<8;
	uiMsgHdl = uiMsgHdl | eMesgBox<<16; 

	*puiMsgHdl = uiMsgHdl;
	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SMSU_SendMessageOut
 *  Description     :  
 *	                   
 *	                   
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_SMSU_SendMessageOut(IN uchar8 ucHandSet,
																IN x_IFX_DECT_SMSU_Mesg xMesg,
																OUT uchar8 *pucMesgIndex)
{
	uchar8 ucEndPtId[12];
	uchar8 ucLineId;
	x_IFX_CMGR_AddressInfo xAddrFrom = {0};
	x_IFX_CMGR_AddressInfo xAddrTo = {0};
	uint32 uiSmsId;
	char8 acMesg[IFX_DECT_SMSU_MAX_MESG_DATALEN];
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");

	/* Get the EndPtId from HandsetId */
	IFX_CFG_DectHandsetGetEndPtId(ucHandSet,&ucEndPtId);	
	/*  Get default VoiceLine for the EndPtId */
	IFX_CIF_EndptDefaultVLGet(ucEndPtId,&ucLineId,&eReason );
	strcpy(xAddrFrom.uxAddressInfo.szEndptId,ucEndPtId);
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			"EndPointId is: ", xAddrFrom.uxAddressInfo.szEndptId);
	strcpy(acMesg, xMesg.acMesgContents);
	xAddrFrom.eAddressType = IFX_CMGR_TYPE_EXTN;
	xAddrTo.eAddressType = IFX_CMGR_TYPE_VOIP;
	eRet = IFX_CMGR_Msg_Send(&xAddrFrom,&xAddrTo,acMesg,&uiSmsId,&eStatus,&eReason);
	
	if( IFX_SUCCESS == eRet )
		{
			if( IFX_CMGR_STATUS_FAIL == (eStatus) )
			{
				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						"IFX_DECTAPP_SMSU_SendMessageOut :: STATUS FAIL", ucEndPtId);
				return IFX_DECT_SMSU_FAILURE;
			}
			else
			{
				*pucMesgIndex = (uchar8)(uiSmsId & 0xFF);
			}
	}
	
	return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SMSU_GetMesg
 *  Description     :  
 *	                   
 *	                   
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_SMSU_GetMesg(IN uchar8 ucHandSet,
												 IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
												 IN uchar8 ucMesgIndex,
												 OUT x_IFX_DECT_SMSU_Mesg *pxMesg)
{
	char8 acMsg[IFX_DECT_SMSU_MAX_MESG_DATALEN];
	uchar8 ucEndPtId[12];
	uchar8 ucLineId; 
	e_IFX_ReasonCode eReason;
	uint32 uiMsgHdl;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");

	/* Get the EndPtId from HandsetId */
	IFX_CFG_DectHandsetGetEndPtId(ucHandSet,&ucEndPtId);	
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			"EndPointId is: ", ucEndPtId);
	/*  Get default VoiceLine for the EndPtId */
	IFX_CIF_EndptDefaultVLGet(ucEndPtId,&ucLineId,&eReason );
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Sending to CMGR: LineId=", ucLineId);
	ucLineId = 1;
	IFX_DECTAPP_GetMsgHdl(ucMesgIndex,ucLineId,eMesgBox,&uiMsgHdl);

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Sending to CMGR: MsgHdl=", uiMsgHdl);
	/* Call the CMGR API to read the message */
	if(IFX_SUCCESS != IFX_CMGR_Msg_Read(ucLineId, uiMsgHdl, &vaxMsgInfo[ucHandSet][ucMesgIndex])) {
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			"!! Fail to Read the Message !!" );
		return IFX_DECT_SMSU_FAILURE;
	}
	strcpy(pxMesg->aucToFromNumber, vaxMsgInfo[ucHandSet][ucMesgIndex].acUserName);
	strcpy(pxMesg->acMesgContents,vaxMsgInfo[ucHandSet][ucMesgIndex].szMsgBody);
	pxMesg->ucMesgSize = strlen(pxMesg->acMesgContents);
	return IFX_SUCCESS;

}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SMSU_GetHdrs
 *  Description     :  
 *	                   
 *	                   
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_SMSU_GetHdrs(	IN uchar8 ucHandSet,
													IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
													OUT x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
													OUT uchar8 *pucNoHeaders)
{
	uint16 uiHdrCnt,i;
	uchar8 ucLineId;
	uchar8 ucEndPtId[12];
	e_IFX_ReasonCode eReason;
  x_IFX_DECT_SMSU_Mesg xMsgInfo= {0} ;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");

	/* Get the EndPtId from HandsetId */
	IFX_CFG_DectHandsetGetEndPtId(ucHandSet,&ucEndPtId);	
	/*  Get default VoiceLine for the EndPtId */
	IFX_CIF_EndptDefaultVLGet(ucEndPtId,&ucLineId,&eReason );

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Sending to CMGR: LineId=", ucLineId);
	ucLineId = 1;
	if(IFX_SUCCESS != IFX_CMGR_Msg_GetHdrs(ucLineId,eMesgBox,&vaxMsgInfo[ucHandSet][0],&uiHdrCnt)) {
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			"!! Fail to Get Message Headers !!" );
		return IFX_DECT_SMSU_FAILURE;
	}
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Number Of Headers=", uiHdrCnt);
	*pucNoHeaders = uiHdrCnt;

	for(i=0;i<uiHdrCnt;i++) {
		strcpy((pxHeaders+i)->aucToFromNumber, vaxMsgInfo[ucHandSet][i].acUserName);
		strncpy((pxHeaders+i)->aucMesgPreamble,vaxMsgInfo[ucHandSet][i].szMsgBody, IFX_DECT_SMSU_MAX_PREAM_SIZE);
		(pxHeaders+i)->ucMesgStatus = vaxMsgInfo[ucHandSet][i].bMsgUnread;
	}
	
	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SMSU_DeleteMesg
 *  Description     :  
 *	                   
 *	                   
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_SMSU_DeleteMesg(IN uchar8 ucHandSet,
														IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
														IN uchar8 ucMesgIndex,
														OUT e_IFX_DECT_SMSU_Return *peDeleteStatus,
														OUT e_IFX_DECT_SMSU_ReasonCode *peFailReason)
{
	uchar8 ucLineId;
	uint32 uiMsgHdl;
	uchar8 ucEndPtId[12];
	e_IFX_ReasonCode eReason;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry");

	/* Get the EndPtId from HandsetId */
	IFX_CFG_DectHandsetGetEndPtId(ucHandSet,&ucEndPtId);	
	/*  Get default VoiceLine for the EndPtId */
	IFX_CIF_EndptDefaultVLGet(ucEndPtId,&ucLineId,&eReason );

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Sending to CMGR: LineId=", ucLineId);
	ucLineId = 1;
	IFX_DECTAPP_GetMsgHdl(ucMesgIndex,ucLineId,eMesgBox,&uiMsgHdl);
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Sending to CMGR: MsgHdl=", uiMsgHdl);
	if(IFX_SUCCESS != IFX_CMGR_Msg_Delete(ucLineId,uiMsgHdl))	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			"!! Failure in Message Delete !!" );
		*peDeleteStatus = IFX_FAILURE;
		return IFX_DECT_SMSU_FAILURE;
	}
	else {
		*peDeleteStatus = IFX_SUCCESS;
	}
	return IFX_SUCCESS;
}

#endif /* MESSAGE_SUPPORT */



/*----------------------------------------------------------------------------*/
e_IFX_Return
  IFX_CIF_NoOfUnreadGet(IN uchar8 ucLineId,OUT uchar8 *pucNoOfUnread);
void IFX_DECTAPP_DateTimeTimerFired(IN uint32 uiTimerId,
                                 IN void* pvPrivateData)
{
   x_IFX_DECT_USU_TimeDate xTimeDate = {0};
   uchar8 ucHandset = *(uchar8 *)pvPrivateData;
		uchar8 ucNoOfUnRead=0;
		uchar8 aucLineIdList[15] = "";
		uint32 i = 0;
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
				"<SendDateTimeToPP>Entry");
  IFX_DECT_GetTimeDate(&xTimeDate);
  if(IFX_SUCCESS != IFX_DECT_USU_DateTimeSync(ucHandset+1,
	   &xTimeDate)){
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
	IFX_DBG_STR,
	    "Failed to Update TimeDate of PT");
  }else{
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
			  IFX_DBG_STR,"Updated TimeDate of PT");
  }
  if(IFX_FAILURE == IFX_DECTAPP_InternalNamesNotify(ucHandset+1,
                                                 NULL,NULL)){
     printf("\nFailed to Notify List Change to Attached PP.\n"); 
  }else{
     printf("\nSent List Change Notification to Attached PP.\n"); 
   }

   if(IFX_FAILURE == IFX_CIF_AssocLineIdsGet(ucHandset+1,&aucLineIdList[0])){

	    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
							 "<IFX_DECTAPP_LAU_StartSession>IFX_CIF_AssocLineIdGet failed." );
   } 
	 for(i=0;aucLineIdList[i] != '\0';i++){
		 
      if(IFX_FAILURE == IFX_CIF_NoOfUnreadGet(aucLineIdList[i],&ucNoOfUnRead)){

          printf("\n<IFX_DECTAPP_ListChangeNotify>IFX_CIF_NoOfUnreadGet failed\n"); 
			}else{
        if(ucNoOfUnRead != 0){

          if(IFX_FAILURE == IFX_DECTAPP_MissedCallNotify(ucHandset+1,
                                                 NULL,NULL)){
            printf("\nFailed to Notify Missed call List Change to Attached PP.\n");
          }else{
            printf("\nSent List Change Notification on Missed Call to Attached PP.\n");
           }
				  break;
			  }	 
	    }			
   }			
   printf("\n<Date_TIme_TimerFired:%d\n",ucNoOfUnRead); 
 
}
e_IFX_Return IFX_DECTAPP_USU_XRAM(IN uchar8 *pMesg);
e_IFX_Return IFX_CIF_StoreXram(IN uchar8 *pCont);
e_IFX_Return IFX_DECTAPP_USU_XRAM(IN uchar8 *pMesg){
 if(IFX_CIF_StoreXram(&pMesg[1])==IFX_SUCCESS){
	return IFX_SUCCESS;
	}
	else
   return IFX_FAILURE;
}
/*****************************************************************************
 *  Function Name   : IFX_DECTAPP_MU_Notify
 *  Description     : This routine notify Dect Application for MM Events
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/

e_IFX_Return IFX_DECTAPP_MU_Notify(IN x_IFX_DECT_MU_NotifyInfo *pxAttachInfo)
{
 
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  uchar8 ucLineIdList[10] = {'\0'};
  e_IFX_ReasonCode eReason;
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		       "In IFX_DECTAPP_MU_Notify");
  pxAttachInfo->ucHandSet--; 
  switch(pxAttachInfo->eEvent){
 		case IFX_DECT_MU_REGISTERED:
			{
#ifdef WRITE_SUBS_INFO
				char aszRegDate[32], aszRegTime[32];
				char aszRegDateTime[64];
#endif
				if(vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].ucInstance == IFX_DECT_INVALID_INSTANCE )
        {
          vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].ucInstance = pxAttachInfo->ucHandSet;
#ifdef WRITE_SUBS_INFO
					//Update Registration time
					IFX_GetDateTime(aszRegDate, aszRegTime);
					sprintf(aszRegDateTime, "%s %s", aszRegDate,aszRegTime);
					IFX_CIF_DectSubsInfoSet(vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].szEndptId, 
																&vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].xDECTSubsInfo, 
																IFX_FALSE, //Don't know at this point
																aszRegDateTime );
#endif

		}else{
					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
						"!! Already Registered !!" );
		}
    /* If handset is not Associated to any of the line,default line,Line association is being set*/ 
    if(IFX_SUCCESS == IFX_CIF_AssocLineIdsGet((pxAttachInfo->ucHandSet+1), (uchar8 *)&ucLineIdList))
    {
      if(ucLineIdList[0] == 0 ) {
		    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"!! Not Associated to any line  !!" );
        
		    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"Get the VoiceLineId list. Set the list to endpoint line id list" );
        IFX_CIF_LineIdListGet((uchar8 *)&ucLineIdList);

        IFX_CIF_AssocLineIdSet((pxAttachInfo->ucHandSet+1),ucLineIdList[0]);
        
		    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"Set to default VoiceLine" );
        IFX_CIF_EndptDefaultVLSet(
	                 vaxDectEndptFsmInfo[pxAttachInfo->ucHandSet].szEndptId,
	                 ucLineIdList[0],&eReason );
        
        IFX_CIF_LineAssocSet((pxAttachInfo->ucHandSet+1),ucLineIdList[0]);
		    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"Line association set for the Handset" );
      }
    } 
				break;
			}
		case IFX_DECT_MU_ATTACHED:
			{

				if( IFX_SUCCESS != 
						IFX_DECT_GetEndptInfoByInstance(pxAttachInfo->ucHandSet, &pxEndptInfo) )
				{
					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							"No Handset Registered With This Instance Number" );
				}	else {
#ifdef WRITE_SUBS_INFO
					x_IFX_CIF_DectSubsInfo* pxDectSubsInfo = 0;
#endif
					if( IFX_DECTNG_CODEC_G722_64 == pxAttachInfo->ucCodec_Pri1 ||
							IFX_DECTNG_CODEC_G722_64 == pxAttachInfo-> ucCodec_Pri2||
							IFX_DECTNG_CODEC_G722_64 == pxAttachInfo->ucCodec_Pri3	)
					{
						IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, 
								IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId,
								"This Handset Supports Wideband Calls" );
						pxEndptInfo->bWidebandEnabled = IFX_TRUE;
            printf("\n Wideband enabled\n");
					}
					else
					{
						IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, 
								IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId,
								"This Handset Does Not Support Wideband Calls" );
						pxEndptInfo->bWidebandEnabled = IFX_FALSE;
					}
				  /* Whenever attach comes store term caps */	
          pxEndptInfo->uiTermCap = pxAttachInfo->uiTermCap;
          pxEndptInfo->xDECTSubsInfo.uiTermCap = pxAttachInfo->uiTermCap;
          printf("\n Term Capab -----------%d",pxAttachInfo->uiTermCap);
					if( IFX_TRUE != pxEndptInfo->bPPAttached )
					{
					  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, 
								     IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId, 
								     "Endpt is not attached.");
						//Register callbacks with call manager
						pxEndptInfo->bPPAttached = IFX_TRUE;
            /* Save terminal Capabilities of the remote part */
						if( IFX_SUCCESS != IFX_DECT_CbRegisterWithCmgr(pxEndptInfo) )
						{
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, 
								IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId, 
								"Could Not Register Callbacks With Call Manager");
						}
						else
						{
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
								IFX_DBG_ATA_STRING_INFO,	pxEndptInfo->szEndptId, 
								"Handset Attached. It Can Make/Receive Calls");
						}
					}
#ifdef WRITE_SUBS_INFO
					pxDectSubsInfo =(x_IFX_CIF_DectSubsInfo*) pxAttachInfo->pxSubscInfo;
				  memset(pxEndptInfo->axCallInfo,0,(sizeof(x_IFX_DECT_CallInfo)*IFX_MAX_DECT_CALLS));
#if 1
							{
								int i=0;
              	printf("\nLocate Req DB Sub Info \n");
								for(i=0;i<8;i++)
								{
									printf("  %x",pxEndptInfo->xDECTSubsInfo.aucCipherKey[i]);
								}
								printf("\n");
              	printf("\nLocate Req current Sub Info \n");
								for(i=0;i<8;i++)
								{
									printf("  %x",pxDectSubsInfo->aucCipherKey[i]);
								}
								printf("\n");
							}
#endif

					if( memcmp(pxDectSubsInfo,&pxEndptInfo->xDECTSubsInfo,  
																sizeof(x_IFX_CIF_DectSubsInfo)))
					{
						//There is difference, write to config
             printf("\nLocate Req Sub Info there is  difference\n");
            if(1/*pxDectSubsInfo->bIsRegistered != pxEndptInfo->xDECTSubsInfo.bIsRegistered*/ )
					  {
						  memcpy(&pxEndptInfo->xDECTSubsInfo, pxDectSubsInfo, 
							     sizeof(x_IFX_CIF_DectSubsInfo));
          	  pxEndptInfo->xDECTSubsInfo.uiTermCap = pxAttachInfo->uiTermCap;
						  IFX_CIF_DectSubsInfoSet(pxEndptInfo->szEndptId, 
							 									&pxEndptInfo->xDECTSubsInfo, 
																pxEndptInfo->bWidebandEnabled, NULL);
						  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_NORMAL,
							  	IFX_DBG_STR, 
								  "Changes found writing to flash");
             printf("\nLocate Req Sub Info there is difference writting to flash\n");
						  system("/etc/rc.d/backup &"); //save config
            } else{
             printf("\nLocate Req Sub Info there is difference but old and new state are same so copy to RAM\n");
						  memcpy(&pxEndptInfo->xDECTSubsInfo, pxDectSubsInfo, 
							     sizeof(x_IFX_CIF_DectSubsInfo));
							
          	  pxEndptInfo->xDECTSubsInfo.uiTermCap = pxAttachInfo->uiTermCap;
						}
					}
					else
					{
             printf("\nLocate Req Sub Info there is no difference\n");
					}
#endif
#ifndef LTQ_OSGI_POWER_OUTLET
          if(IFX_DECT_DPSU_IsCallExisting(pxAttachInfo->ucHandSet+1)== IFX_SUCCESS) {
              IFX_DECT_DPSU_CleanUpConnectionResources(pxAttachInfo->ucHandSet+1);
          }
#endif
                                  if((pxAttachInfo->uiTermCap & IFX_DECT_MU_HS_CAT2) == IFX_DECT_MU_HS_CAT2){
                           	    IFX_TIM_TimerStart(1000*10, &(pxAttachInfo->ucHandSet), 1,
							IFX_DECTAPP_DateTimeTimerFired, &vuiDateTimerTimerId);
                                  }
				} 
				break;
			}
 		case IFX_DECT_MU_UNREGISTERED:
				if( IFX_SUCCESS != 
					IFX_DECT_GetEndptInfoByInstance(pxAttachInfo->ucHandSet, &pxEndptInfo) )
				{
					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							"Could Not Retrieve Handset Information" );
				}	else {
					pxEndptInfo->bPPAttached = IFX_FALSE;
					pxEndptInfo->ucInstance = IFX_DECT_INVALID_INSTANCE;
                                        pxEndptInfo->xDECTSubsInfo.bIsRegistered = 0;
					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_NORMAL,IFX_DBG_ATA_STRING_INFO,				
						pxEndptInfo->szEndptId, "Handset Is Unregistered" );
						IFX_CIF_DectSubsInfoSet(pxEndptInfo->szEndptId, 
									&pxEndptInfo->xDECTSubsInfo, 
									pxEndptInfo->bWidebandEnabled, NULL);
	
				}
				break;
		case IFX_DECT_MU_STOPPED_PAGING:
		{
      x_IFX_DECT_EndptFsmInfo* pxDectEndpt = vaxDectEndptFsmInfo;
      uchar8 ucIndex ;

		    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 "Stopped Paging from toolkit...." );
                    vucCurPagingPPCount =0;

	        for(ucIndex = 0; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; 
					++ucIndex, ++pxDectEndpt )
	        {
               	if( IFX_DECT_CheckEndptFlag(pxDectEndpt, IFX_DECT_F_PAGE_CALL) )
	             {
		                IFX_DECT_MakeDectPPIdle(pxDectEndpt);
	             }
	        }
      }
      break;
			case IFX_DECT_MU_REJECT_PAGING:
			{
				if( IFX_SUCCESS != 
					IFX_DECT_GetEndptInfoByInstance(pxAttachInfo->ucHandSet, &pxEndptInfo) )
				{
					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
							"Could Not Retrieve Handset Information" );
				}	else {
               		if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) )
	             		{
		                IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	             		}
				}

				break;
			}
     
      default:
       break; 
   }/* end of switch*/
   return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_MU_ModemReset
 *  Description     : This routine notify Dect Application for Modem Reset
 *  Input Values    :
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS/ 
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_MU_ModemReset()
{
				/* 
				 * Terminate all DECT calls. todo this send dect on hook indication to
				 * all attached handsets (if they have a call)
				 */
				x_IFX_DECT_EventInfo evtInfo = {IFX_DECT_EVT_PP_OnHook};
				x_IFX_DECT_EndptFsmInfo* pxDectEndpt = vaxDectEndptFsmInfo;
				e_IFX_ReasonCode eReason;
				uchar8 ucIndex = 0;
				evtInfo.uxEventData.eDectReleaseReason = 1; //abnormal release
				for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex, ++pxDectEndpt )
				{
					//if PP is attached and is not in idle state, release calls
					if( IFX_TRUE == pxDectEndpt->bPPAttached &&
							IFX_DECT_STATE_IDLE != pxDectEndpt->eState ) 
					{
						IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
							pxDectEndpt->szEndptId, "Terminating Call(s)" );
						
						IFX_DECT_FsmHdlr(pxDectEndpt, &evtInfo, &eReason);
					}	
				}
  return IFX_SUCCESS;
}
e_IFX_Return
IFX_DECTAPP_LAU_Init();
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_USU_DateTimeSync
 *  Description     : If date and time is set from PP inform all attached handsets
 *                    and set the system date and time
 *  Input Values    : ucHandsetId-Handset that updated the date and time
 *                    pxTimeDate-Date and time received from handset
 *  Output Values	  : None
 *  Return Value    : Returns IFX_SUCCESS if DECT agent is initialized, else
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_USU_DateTimeSync(IN uchar8 ucHandsetId,
					     IN x_IFX_DECT_USU_TimeDate *pxTimeDate)
{
  int32 i=0;
  char acDateTime[100];
#if 1
  x_IFX_DECT_EndptFsmInfo* pxDectEndpt = vaxDectEndptFsmInfo+(ucHandsetId-1);
#else
  x_IFX_DECT_EndptFsmInfo* pxDectEndpt = vaxDectEndptFsmInfo;
  for(i = 0; i < IFX_MMGR_MAX_DECT_CHANNELS; ++i, ++pxDectEndpt){
    if((i+1)==ucHandsetId){
      continue;
    }
#endif
    printf("\nIFX_DECTAPP_USU_DateTimeSync: HS = %d\n",ucHandsetId);
			{/*Check for clock master. If it is base then we don't set. If it is HS then we set/sync date & Time*/
							x_IFX_DECT_LAU_SystemSettingsList xSysSetList = {0};
							if(IFX_FAILURE == IFX_CIF_SystemGet(&xSysSetList)){
          					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "		<USU_ProcessStkMesg>IFX_CIF_SystemGet failed");
          					return IFX_FAILURE;
       				}
							printf("\nClock Master (hex) = %x\n",xSysSetList.cClockMaster);
							if(xSysSetList.cClockMaster == IFX_DECT_LAU_CLOCK_MASTER_FP)
							{
          					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "		<USU_ProcessStkMesg>Clock Master is FP so we dont sync date & Time");
          					return IFX_FAILURE;
							}
							else
							{
          					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "		<USU_ProcessStkMesg>Clock Master is PP so we sync date & Time");
							}
				}

    if(IFX_TRUE == pxDectEndpt->bPPAttached){ 
	    IFX_DECT_USU_DateTimeSync(i+1,pxTimeDate);
      if((pxTimeDate->ucDay!=0)&&(pxTimeDate->ucHour!=0)){
        sprintf(acDateTime,"date %02x%02x%02x%02x20%02x",pxTimeDate->ucMonth,pxTimeDate->ucDay,
               pxTimeDate->ucHour,pxTimeDate->ucMinutes,pxTimeDate->ucYear);
        system(acDateTime);
        system("echo 3 > /proc/pagemode");
        
      }
      else if(pxTimeDate->ucDay!=0){
        sprintf(acDateTime,"date %02x%02x000020%02x",pxTimeDate->ucMonth,pxTimeDate->ucDay,pxTimeDate->ucYear);
        system(acDateTime);
        system("echo 3 > /proc/pagemode");
      }
      else if(pxTimeDate->ucHour!=0){
        sprintf(acDateTime,"date -s \"%02x:%02x\"",pxTimeDate->ucHour,pxTimeDate->ucMinutes);
        system(acDateTime);
        system("echo 3 > /proc/pagemode");
      }
    }
#if 0
  }
#endif
  return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_USU_FirmwareDownloadStatus(uchar8 ucStatus){
  if ((char8)ucStatus == IFX_FAILURE){
     exit(1);
  }
return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECT_AgentInit
 *  Description     : This routine initializes DECT stack, DECT endpoints FSM.
 *	                  Registered DECT handsets information is passed to DECT 
 *	                  stack during initialization.
 *  Input Values    : aszEndPointId - list of DECT handsets to be initialized.
 *	                  ucNoOfEndpts - No of DECT handsets to be initialized.
 *	                  ucDectDbgId - DECT Agent's debug id.
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if DECT agent is initialized, else
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/

e_IFX_Return IFX_DECT_AgentInit(
	                            IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
	                            IN uchar8 ucNoOfEndpts,
	                            IN uchar8 ucDectDbgId )
{
	x_IFX_CIF_DectSubsInfo xPPSubsInfo[IFX_MMGR_MAX_DECT_CHANNELS];
	x_IFX_CIF_DectSubsInfo* pxPPSubsInfo = 0;
	x_IFX_DECT_EndptFsmInfo* pxDectEndpt = 0;
	uchar8 ucNoOfSubscribedPPs = 0;
	uchar8 ucEndptCount = 0;
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_DECT_MU_CallBks xMUCbs;
	x_IFX_DECT_CSU_CallBks xCSUCbs;
  x_IFX_DECT_USU_CallBks xUSUCbs;
	vucDectAgnetModId = ucDectDbgId;

	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Initializing DECT Agent.....");

	vucDectAgnetModId = ucDectDbgId;
printf("$$$$$Reading params from DectConfiguration......\n");
#ifdef DECT_PART
LTQ_Init_ParamsFromDectPart();
#endif	
	if( ucNoOfEndpts > IFX_MMGR_MAX_DECT_CHANNELS )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
			 "Endpoints exceeded IFX_MMGR_MAX_DECT_CHANNELS");
		return eRet;
	}

	if( IFX_TRUE == IFX_DECT_IsDectStackInitialized() )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
			 "Dect Agent Module Is Already Initialized");
		return IFX_SUCCESS;
	}

	pxDectEndpt = vaxDectEndptFsmInfo;
	pxPPSubsInfo = &xPPSubsInfo[0];
	while( ucEndptCount < ucNoOfEndpts )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				"Initializing DECT Endpoint", aszEndPointId[ucEndptCount]);
		strcpy(pxDectEndpt->szEndptId, aszEndPointId[ucEndptCount]);
		/*
		 * Retrieve subscription info from configuration. If subscription info is
		 * available for the endpoint, then set instance number. Otherwise no 
		 * handset is using this endpoint, so assign invalid instance number.
		 */
		if(IFX_SUCCESS != IFX_CIF_DectSubsInfoGet(pxDectEndpt->szEndptId, 
				                          pxPPSubsInfo ) )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxDectEndpt->szEndptId, 
				"!! Could Not Read Subscription Infomration !!");
		}

			memcpy(&pxDectEndpt->xDECTSubsInfo, 
							pxPPSubsInfo, sizeof(x_IFX_CIF_DectSubsInfo));
		if( pxPPSubsInfo->bIsRegistered )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxDectEndpt->szEndptId, "This Endpoint Is Registered !!");
						//Register callbacks with call manager
						//IOP FIX:For handling short RF loss.
						pxDectEndpt->bPPAttached = IFX_TRUE;
						if( IFX_SUCCESS != IFX_DECT_CbRegisterWithCmgr(pxDectEndpt) )
						{
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, 
								IFX_DBG_ATA_STRING_INFO, pxDectEndpt->szEndptId, 
								"Could Not Register Callbacks With Call Manager");
						}
						else
						{
							IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_NORMAL,
								IFX_DBG_ATA_STRING_INFO,	pxDectEndpt->szEndptId, 
								"Handset by default is moved to attached state for handling IOP issues");
            }
			pxDectEndpt->ucInstance = ucNoOfSubscribedPPs++;
		}
		else 
		{
			//This instance does not registered, set instance number to invalid
			pxDectEndpt->ucInstance = IFX_DECT_INVALID_INSTANCE;
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxDectEndpt->szEndptId, "!! This Endpoint Is Not Registered !!");
		}
		++pxPPSubsInfo;
		++pxDectEndpt;
		++ucEndptCount;
	}

	/*
	 * Note: Callback functions for DECT endpoint will be registered only after
	 * handset attaches to basestation.
	 */	

    xMUCbs.pfn_MU_Notify = IFX_DECTAPP_MU_Notify; 
    xMUCbs.pfn_MU_ModemReset = IFX_DECTAPP_MU_ModemReset;
    IFX_DECT_MU_RegisterCallBks(&xMUCbs);
	 xUSUCbs.pfn_USU_XRAM = IFX_DECTAPP_USU_XRAM;
	 xUSUCbs.pfn_USU_DateTimeSync = IFX_DECTAPP_USU_DateTimeSync;
	 xUSUCbs.pfn_USU_FirmwareDownloadStatus = IFX_DECTAPP_USU_FirmwareDownloadStatus;
	 IFX_DECT_USU_RegisterCallBks(&xUSUCbs);	
    //IFX_DECT_ContDownInit();
#ifdef LTQ_OSGI_POWER_OUTLET
   IFX_DECTAPP_COMMIF_Init();
#else
   IFX_DECT_DPSU_Init(NULL);
#endif
    xCSUCbs.pfnCallInitiate = IFX_DECTAPP_CSU_CallIncoming; /*!< Call Incomoing*/
    xCSUCbs.pfnLineInfo = IFX_DECTAPP_CSU_LineInfo; /*!< Call Incomoing*/
    xCSUCbs.pfnCallAccept = IFX_DECTAPP_CSU_CallAccept;
    xCSUCbs.pfnCallAnswer = IFX_DECTAPP_CSU_CallAnswer;
    xCSUCbs.pfnCallRelease = IFX_DECTAPP_CSU_CallRelease;
    xCSUCbs.pfnInfoReceived = IFX_DECTAPP_CSU_InfoReceived;
    xCSUCbs.pfnIntrudeInfoRecv = IFX_DECTAPP_CSU_IntrudeInfoReceived;
    xCSUCbs.pfnInterceptAccept = IFX_DECTAPP_CSU_InterceptAccept; 
    xCSUCbs.pfnServiceChange = IFX_DECTAPP_CSU_ServiceChange; 
    xCSUCbs.pfnVoiceModify = IFX_DECTAPP_CSU_ModifyVoice;
#ifdef ENABLE_ENCRYPTION 
    xCSUCbs.pfnCipherCfm  = IFX_DECTAPP_CSU_CipherCfm;
#endif
    xCSUCbs.pfnCallHold = IFX_DECTAPP_CSU_CallHold;
    xCSUCbs.pfnCallResume = IFX_DECTAPP_CSU_CallResume;
    xCSUCbs.pfnCallToggle = IFX_DECTAPP_CSU_CallToggle;
    xCSUCbs.pfnCallTransfer = IFX_DECTAPP_CSU_CallTransfer;
    xCSUCbs.pfnCallConference = IFX_DECTAPP_CSU_CallConference;
    xCSUCbs.pfnCallDeflect = IFX_DECTAPP_CSU_CallDeflect;

    IFX_DECT_CSU_RegisterCallBks(&xCSUCbs);
#ifdef MESSAGE_SUPPORT
		xSMSUCbs.pf_SMSU_SendMessageOut = IFX_DECTAPP_SMSU_SendMessageOut ;
		xSMSUCbs.pf_SMSU_GetMesg = IFX_DECTAPP_SMSU_GetMesg ;
		xSMSUCbs.pf_SMSU_GetHdrs = IFX_DECTAPP_SMSU_GetHdrs ;
		xSMSUCbs.pf_SMSU_DeleteMesg = IFX_DECTAPP_SMSU_DeleteMesg ;
    IFX_DECT_SMSU_RegisterCallBks(&xSMSUCbs);

		IFX_DECT_SMSU_Init();
		IFX_DECT_SMSU_StubInit();
#endif /* MESSAGE_SUPPORT */
       IFX_DECTAPP_LAU_Init();

	// Initialize DECT Stack
	if(	IFX_SUCCESS != IFX_DECT_InitDectStack(ucDectDbgId,ucDectDbgId,xPPSubsInfo, IFX_MMGR_MAX_DECT_CHANNELS/*ucNoOfSubscribedPPs*/) )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
			 "Could Not Initialize DECT Stack");
		return IFX_FAILURE;
	}
#ifndef ENABLE_PAGING
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
			 "No Paging Button. Allowing Registration After 5 Mins");
#endif
  
	
	IFX_DBGC( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		"DECT Agent Initialized");
	return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECT_CbRegisterWithCmgr
 *  Description     : This routine registers callback functions for given DECT
 *	                  endpoint with call manager. This routine is called after
 *	                  receiving FP_PORTABLE_ATTACHED_IN_MM message for handset
 *  Input Values    : uiReqId The request identifier for this subscription 
 *                    request
 *                    pxNotifyInfo the body of the notify message
 *                    pvPrivateData Assume New struct for time being
 *  Output Values	: -
 *  Return Value    : Returns IFX_SUCCESS if callbacks are registered with call
 *                    manager , else IFX_FAILURE.
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECT_NtfyRcv(IN uint32 uiReqId,
                 IN x_IFX_CMGR_VoiceMailNotifyInfo* pxNotifyInfo,
				 IN void* pvPrivateData)
{
  e_IFX_Return eRet=IFX_FAILURE;;
  char8 ucHandsetId =0;
  x_IFX_CMGR_VoiceMailEPNotify *pxVMNtfy = (x_IFX_CMGR_VoiceMailEPNotify *)pvPrivateData;
  printf("Notification received from remote party\n");
  
	if(pxVMNtfy){

	if((ucHandsetId = IFX_DECT_HsIdFromEPName((char8*)pxVMNtfy->acEndptId)) == -1){
    return IFX_FAILURE;
  }
  /* Notify the message to the appropriate handset */	
  eRet = IFX_DECT_USU_VoiceMesgWaitingNotify(ucHandsetId, 
                                             pxVMNtfy->ucLineId/*0*/,
				             pxNotifyInfo->unNumOfUnread);
  if(eRet != IFX_SUCCESS){
   printf("Voice mail notify to handset failed\n");
  }
}
  return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_DECT_CbRegisterWithCmgr
 *  Description     : This routine registers callback functions for given DECT
 *	                  endpoint with call manager. This routine is called after
 *	                  receiving FP_PORTABLE_ATTACHED_IN_MM message for handset
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info 
 *  Output Values	  : -
 *  Return Value    : Returns IFX_SUCCESS if callbacks are registered with call
 *                    manager , else IFX_FAILURE.
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_DECT_CbRegisterWithCmgr(
										IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo )
{
	x_IFX_CMGR_CallBackList xCallBacks = {0};
	char8 aszEndPointId[1][IFX_MAX_ENDPOINTID_LEN];
	
	xCallBacks.pfnCallIncoming = IFX_DECT_CallIncoming;
	xCallBacks.pfnRemoteCallAccept = IFX_DECT_RemoteCallAccept;
	xCallBacks.pfnRemoteCallAnswer = IFX_DECT_RemoteCallAnswer;
	xCallBacks.pfnRemoteCallHold = IFX_DECT_RemoteCallHold;
	xCallBacks.pfnRemoteCallResume = IFX_DECT_RemoteCallResume;
	xCallBacks.pfnCallHoldRsp =  IFX_DECT_CallHoldResponse;
	xCallBacks.pfnCallResumeRsp = IFX_DECT_CallResumeResponse;
	xCallBacks.pfnRemoteCallRelease = IFX_DECT_RemoteCallRelease;
	//xCallBacks.pfnCallFwdInfo = IFX_DECT_CallForwardInfo;
	xCallBacks.pfnConfStatus = IFX_DECT_ConfStatus;
	xCallBacks.pfnARD_Status = IFX_DECT_AutoRedialStatus;
	xCallBacks.pfnARD_NtfnRcv = IFX_DECT_AutoRedialNotifyReceived;
	xCallBacks.pfnARD_Reg = IFX_DECT_AutoRedialRegister;
	xCallBacks.pfnBlindTxReq = IFX_DECT_BlindTxRequest;
	xCallBacks.pfnBlindTxStatus = IFX_DECT_BlindTxStatus;
	xCallBacks.pfnAttendedTxReq = IFX_DECT_AttendedTxRequest;
	xCallBacks.pfnAttendedTxStatus = IFX_DECT_AttendedTxStatus;
	xCallBacks.pfnCallIdRep = IFX_DECT_CallIdReplace;
  /* List Access */
	xCallBacks.pfnListAccess	= IFX_DECTAPP_ListAccessNtfn;
	xCallBacks.pfnFreeVmapiObj = IFX_DECTAPP_FreeVmapiObj;

  /*Date Time Sync*/
	xCallBacks.pfnDateTime	= IFX_DECTAPP_DateTimeNtfn;

	//Callbacks for codec negotiation
	xCallBacks.pfnGetMediaParams = IFX_DECT_GetMediaParams; 
	xCallBacks.pfnMediaNegReq    = IFX_DECT_MediaNegReq;
	xCallBacks.pfnMediaNegRsp    = IFX_DECT_MediaNegResp;
#ifdef MESSAGE_SUPPORT
	xCallBacks.pfnMsgRcv     = IFX_DECT_MsgRcv;
	xCallBacks.pfnMsgStatus  = IFX_DECT_MsgStatus;
#endif /* MESSAGE_SUPPORT */	

	xCallBacks.pfnVM_NtfnRcv = IFX_DECT_NtfyRcv;

	strcpy(aszEndPointId[0], pxEndptInfo->szEndptId);
	return IFX_CMGR_CallBacksRegister(aszEndPointId, 1, &xCallBacks);
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AgentShut 
 *  Description     : This function unregisters DECT handset. Before 
 *	                  unregistering calls will be disconnected.
 *  Input Values    : aszEndPointId - List of DECT endpoint Ids
 *	                  ucNoOfEndpts  - Number of DECT endpoints available in the 
 *	                    list 
 *  Output Values	  : -
 *  Return Value    : If handset is unregistered successfully, this routine 
 *	                  returns IFX_SUCCESS, otherwise IFX_FAILURE.
 *  Notes           : If handset is not attached it may not get unregister 
 *	                  request
 ******************************************************************************/
e_IFX_Return IFX_DECT_AgentShut(
										IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNoOfEndpts)
{
	uchar8 ucEndptSlot = 0;
	uchar8 ucEndptIndex = 0;
	boolean bShutProblem = IFX_FALSE;

	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
																						"Shutting Down DECT Endpoint(s)");
	/*
	 * For each endpoint in aszEndPointId, make endpoint idle
	 */
	while( ucEndptIndex < ucNoOfEndpts )
	{
		ucEndptSlot = 0;
		while( ucEndptSlot < IFX_MMGR_MAX_DECT_CHANNELS )
		{
			if( strcmp(aszEndPointId[ucEndptIndex],
				vaxDectEndptFsmInfo[ucEndptSlot].szEndptId) == 0 )
			{
				break;
			}
			++ucEndptSlot;
		}

		if( IFX_MMGR_MAX_DECT_CHANNELS == ucEndptSlot )
		{
			bShutProblem = IFX_TRUE;
		} 
		else
		{
			x_IFX_DECT_EndptFsmInfo* pxEndPtInfo = (vaxDectEndptFsmInfo+ucEndptSlot);
			
			if( IFX_TRUE == pxEndPtInfo->bPPAttached )
			{
				/*
				 * If auto redial subscription is active Terminate it (both side). Make
				 * endpoint idle (this disconnects all calls). Then memset the endpoint
				 * information.
				 */
				if( IFX_DECT_CheckEndptFlag(pxEndPtInfo,IFX_DECT_F_AUTOREDIAL_ACTIVE_IN))
					IFX_DECT_SendAutoRedialNtfy(pxEndPtInfo,IFX_FALSE);

				if( IFX_DECT_CheckEndptFlag(pxEndPtInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT))
					IFX_DECT_ActDeActvAutoRedial(pxEndPtInfo,IFX_FALSE);
				
				if( IFX_DECT_STATE_IDLE != pxEndPtInfo->eState ) {
					IFX_DECT_MakeDectPPIdle(pxEndPtInfo);
				}
				
				if( IFX_SUCCESS != IFX_CMGR_CallBacksUnRegister(aszEndPointId+ucEndptIndex, 1))
				{
					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
							aszEndPointId[0], "IFX_CMGR_CallBacksUnRegister FAILED");
					bShutProblem = IFX_TRUE;
				}
			}
                        if(pxEndPtInfo->ucInstance != IFX_DECT_INVALID_INSTANCE){
			  /* Unregister PP */
		 	  IFX_DECT_MU_UNRegister(0,pxEndPtInfo->ucInstance+1);
                        }
			memset(pxEndPtInfo,0,sizeof(x_IFX_DECT_EndptFsmInfo));
			//Don't erase endpt id
			strcpy(pxEndPtInfo->szEndptId, aszEndPointId[ucEndptIndex]); 
			//Erase subscription info from configuration.
			IFX_CIF_DectSubsInfoSet(pxEndPtInfo->szEndptId, 
																&pxEndPtInfo->xDECTSubsInfo, 
																pxEndPtInfo->bWidebandEnabled, "");
		
#ifndef UTA		
		system("/etc/rc.d/backup"); //save config
#endif		
			pxEndPtInfo->ucInstance = IFX_DECT_INVALID_INSTANCE;
		}

		++ucEndptIndex;
	} /* while */

	return (IFX_TRUE == bShutProblem)?IFX_FAILURE:IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_MakeDectPPIdle 
 *  Description     : This routine moves DECT FSM into IDLE state by 
 *	                  disconnecting DECT handset's calls and also stops timers,
 *	                  tones and release resources if allocated. This routine is 
 *	                  used in DECT FSM to bring into Idle state.
 *  Input Values    : pxEndptInfo - DECT endpoint info 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MakeDectPPIdle(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{
	x_IFX_DECT_CallInfo* pxCallInfo=0;
	e_IFX_ReasonCode eReason;
	uchar8 ucCount = 0;
	uint16 i=0;
	uchar8 ucTxFlag=0;
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		     pxEndptInfo->szEndptId, "Making DECT Endpoint Idle");

  printf("----Active Call Handle-------EndpointInfo=%d  - %d\n",(uint32)pxEndptInfo,(uint32)pxEndptInfo->pxActiveCall);
	if( pxEndptInfo->uiRingPauseTimerId ){
		IFX_TIM_TimerStop( pxEndptInfo->uiRingPauseTimerId );
	}
	if( pxEndptInfo->uiToneTimerId ) {
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		IFX_DECT_StopTone(pxEndptInfo,pxEndptInfo->uiDTkCallId);
	}
	if( pxEndptInfo->uiIntrDgtTimerId)
		IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
	if( pxEndptInfo->uiBCETimerId )
		{
      /* If any tone is active, stop the tone */
  	  IFX_DECT_StopTone(pxEndptInfo,pxEndptInfo->uiDTkCallId);
		  IFX_TIM_TimerStop( pxEndptInfo->uiBCETimerId );
		}
	if( pxEndptInfo->uiInterceptTimerId )
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiInterceptTimerId);
		pxEndptInfo->uiInterceptTimerId = 0;
	}


	pxEndptInfo->uiToneTimerId = pxEndptInfo->uiBCETimerId = 
			pxEndptInfo->uiRingPauseTimerId = pxEndptInfo->uiIntrDgtTimerId = 0;

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) )
	{
		IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
	}
        if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS) ){
          ucTxFlag=1;
        }
	else if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS) )
	{
		//If vocie is enabled, disable the voice.
		if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
												pxEndptInfo->szEndptId, "Voice is Enabled. Disable it");
			IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
		}
	  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndptId, "Disconnect both incoming & outgoing calls");
		/* Disconnect both incoming & outgoing calls */
		pxCallInfo = pxEndptInfo->axCallInfo;
		while( ucCount < IFX_MAX_DECT_CALLS)
		{
			if( pxCallInfo->eState != IFX_DECT_CS_NONE )
			{
        if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_ATX_PENDING) ){
				  if(pxCallInfo->uiCallId){
				    IFX_CMGR_CallRelease(pxCallInfo->uiCallId, IFX_TERMINATED, NULL,
						                     NULL, &eReason);
				  }
        }
				IFX_DECT_ResetCall(pxCallInfo,0);
			}
      else {
	      IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Call State is IFX_DECT_CS_NONE");
      }
			++ucCount;
			++pxCallInfo;
		}
	}
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED) )
	{  
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Resource Allocated. Deallocate it");
#ifndef DEV_DEBUG
			IFX_MMGR_DectResDealloc(pxEndptInfo->szEndptId);
#else
			if( IFX_MMGR_SUCCESS != IFX_MMGR_DectResDealloc(pxEndptInfo->szEndptId) )
			{
				/* Could not de-allocate signaling resource !! */
				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId,"Could Not Release DECT Resource");
			}	
#endif	
		/* set reserved codec list to 0 and running codec to none */
		pxEndptInfo->xReservedCodecs.ucNoOfCodecs = 0;
		pxEndptInfo->eRunningCodec = IFX_MMGR_CODEC_NONE;
	}
	if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_REQ)){
		for(i=0;i<IFX_MMGR_MAX_DECT_CHANNELS;i++){
    	if((!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2))&&(vaxDectEndptFsmInfo[i].uiFlags&IFX_DECT_F_INTERCEPT_INIT)){
				IFX_DECT_StopTone(&vaxDectEndptFsmInfo[i],vaxDectEndptFsmInfo[i].pxActiveCall->uiDTkCallId);
			}
			vaxDectEndptFsmInfo[i].uiFlags &= ~IFX_DECT_F_INTERCEPT_INIT;
		}
	 IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,NULL,IFX_DECT_RELEASE_ABNORMAL);
	}else if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_REQ) && pxEndptInfo->szDialledDigits[0]!='\0'){
		vaxDectEndptFsmInfo[pxEndptInfo->szDialledDigits[0]-49].uiFlags &= ~IFX_DECT_F_INTRUDE_INIT;
	}
 /*	   
	* Reset all flags, except those that can be used in idle state. Set last		    
	* active call to NULL. Clear collected digits if exist.				   
	*/
	pxEndptInfo->uiFlags &= IFX_DECT_FLAGS_IN_IDLE_STATE ;
	pxEndptInfo->pxActiveCall = NULL;
	pxEndptInfo->uiConfReqId = 0;
  memset(pxEndptInfo->szDialledDigits,0,IFX_MAX_DIGITS);
	pxEndptInfo->unRingTimeOut = 0;
	pxEndptInfo->szCallerNumber[0] = pxEndptInfo->szCallerName[0] = '\0';
  pxEndptInfo->uiDTkCallId = 0;
	
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);
	
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_DECT_SendAutoRedialNtfy(pxEndptInfo, IFX_TRUE) )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Failed To Send Auto Redial Notification" );
	}
        if(ucTxFlag ==1){
           IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_IGNORE_ATXSTATUS);
        }				
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallIncoming
 *  Description     : This function is called by Call Manager (it is registered 
 *	                  as callback  function) when there is incoming call for a 
 *	                  PP. This generates DECT event IFX_DECT_EVT_IncomingCall 
 *	                  for DECT PP FSM. Search DECT PP info. If not found through 
 *	                  an error. If PP is registered, Invoke DECT PP FSM with 
 *                    IFX_DECT_EVT_IncomingCall event. If not registered reject 
 *	                  call. If FSM returns success,accept call,else reject call.
 *  Input Values    : Please refer pfnCallIncoming callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : If call is not intended for the given DECT PP or PP is 
 *	                  not attached to base then returns IFX_FAILURE, otherwise 
 *	                  returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CallIncoming(
								 IN uint32 uiCallId, 
								 IN x_IFX_CMGR_AddressInfo *pxFrom,
								 IN x_IFX_CMGR_AddressInfo *pxTo, 
								 IN x_IFX_CMGR_CallParams *pxCallParams, 
								 OUT e_IFX_CMGR_Status* peStatus,
								 OUT e_IFX_ReasonCode* peReason,
								 OUT void** ppvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
  //x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
	e_IFX_Return eRet = IFX_FAILURE;

	*peStatus = IFX_CMGR_STATUS_FAIL;
	*peReason = IFX_CIF_INVALID_ENDPOINT;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "Got Incoming Call" );
  printf("CMGR CALL ID %d\n",uiCallId);	
	if( IFX_CMGR_TYPE_EXTN != pxTo->eAddressType )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "Invalid Address Type" );
		return eRet;
	}
	
	if( IFX_SUCCESS != IFX_DECT_GetEndptInfoById(pxTo->uxAddressInfo.szEndptId, &pxEndptInfo) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "!! This Endpoint Does Not Exist !!" );
		return eRet;
	}

  /* If Incoming Call on PSTN Line,pass the PSTN Line Id to the Endpt. */

  if(pxFrom->eAddressType == IFX_CMGR_TYPE_FXO){
                
    pxTo->ucLineId = IFX_PSTN_LINE; 
  }

	if( pxEndptInfo->bPPAttached )
	{
		x_IFX_DECT_EventInfo evtInfo = {0};

		evtInfo.eEvent = IFX_DECT_EVT_IncomingCall;
		evtInfo.uiId = uiCallId;
		evtInfo.uxEventData.xIncCallEvt.pxFrom = pxFrom;
		evtInfo.uxEventData.xIncCallEvt.pxCallParams = pxCallParams;
		evtInfo.uxEventData.xIncCallEvt.ucLineId = pxTo->ucLineId;

		if( IFX_SUCCESS == IFX_DECT_FsmHdlr(pxEndptInfo, &evtInfo, peReason))
		{
      if(*peReason == IFX_ABNORMAL_RELEASE){
			  *peStatus = IFX_CMGR_STATUS_FAIL;
      }
      else{
			  *peStatus = IFX_CMGR_STATUS_PENDING;
      }
			/* waiting for ALERT_IN_CC */
			/* TODO: *peReason = IFX_REQ_PENDING; ?? */
			//*peReason = IFX_MAX_REASON;  
			*ppvPrivateData = (void*)pxEndptInfo;
		}
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Call Is Rejected." );
			*peReason = IFX_ENDPOINT_BUSY;
			return IFX_FAILURE;
		}
	}
	else
	{	
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "This Handset Is Not Registered/Reachable" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallAccept
 *  Description     :  This callback routine is called by call manager when peer
 *	                   party accepts the call. Pumps IFX_DECT_EVT_RmtAccept event 
 *	                   to DECT PP FSM.
 *  Input Values    : Please refer pfnRemoteCallAccept callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.  
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RemoteCallAccept(
							 IN uint32 uiCallId,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Accepted Call" );
	
	evtInfo.eEvent = IFX_DECT_EVT_RmtAccept;
	evtInfo.uiId = uiCallId;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "!! Remote Call Accept Failed !!");
	}
	
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallAnswer
 *  Description     : This callback function is called by CM once peer answers 
 *	                  call. This issues IFX_DECT_EVT_RmtAnswer event to DECT FSM
 *  Input Values    : Please refer pfnRemoteCallAnswer callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RemoteCallAnswer(
							 IN uint32 uiCallId,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason ;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Answered Call" );

	evtInfo.eEvent = IFX_DECT_EVT_RmtAnswer;
	evtInfo.uiId = uiCallId;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Remote Call Answer Failed !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallHold
 *  Description     :  This callback function is called by CM to indicate peer 
 *	                   held the call. Pumps IFX_DECT_EVT_RmtHold event to DECT 
 *	                   FSM.
 *  Input Values    : Please refer pfnRemoteCallHold callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RemoteCallHold(
							 IN uint32 uiCallId,
							 OUT e_IFX_CMGR_Status* peStatus,
							 OUT e_IFX_ReasonCode* peReason,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
#ifdef INFORM_PP_HOLD_RESUME
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason ;
#endif
	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Requested For Call Hold" );

#ifdef INFORM_PP_HOLD_RESUME
	evtInfo.eEvent = IFX_DECT_EVT_RmtHold;
	evtInfo.uiId = uiCallId;
	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Remote Call Hold Failed !!" );
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
#else
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
#endif
	return IFX_SUCCESS;
}

/*
 */
/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallResume
 *  Description     : This callback function is called by CM once peer resumes 
 *	                  held call. This sends IFX_DECT_EVT_RmtResume event to 
 *	                  DECT PP FSM.
 *  Input Values    : Please refer pfnRemoteCallResume callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RemoteCallResume(
							 IN uint32 uiCallId,
							 OUT e_IFX_CMGR_Status* peStatus,
							 OUT e_IFX_ReasonCode* peReason,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
#ifdef INFORM_PP_HOLD_RESUME
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason ;
#endif

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Resumed Call" );

#ifdef INFORM_PP_HOLD_RESUME
	evtInfo.eEvent = IFX_DECT_EVT_RmtResume;
	evtInfo.uiId = uiCallId;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Remote Call Resume Failed !!" );
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
#else
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
#endif
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallHoldResponse 
 *  Description     : This callback function is called by CM to inform status of 
 *	                  hold request (accepts/rejects). This sends 
 *	                  IFX_DECT_EVT_HoldResp event to DECT PP FSM.
 *  Input Values    : Please refer pfnCallHoldRsp callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CallHoldResponse(
							 IN uint32 uiCallId,
							 IN e_IFX_CMGR_Status eStatus,
							 IN e_IFX_ReasonCode eReason, 
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Call Hold Response" );

	evtInfo.eEvent = IFX_DECT_EVT_HoldResp;
	evtInfo.uiId = uiCallId;
	evtInfo.uxEventData.eStatus = eStatus;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Hold Response Failed !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallResumeResponse
 *  Description     :  This callback function is called by CM to inform status 
 *	                   of resume request (accepts/rejects). This sends 
 *	                   IFX_DECT_EVT_ResumeResp event to DECT PP FSM.
 *  Input Values    : Please refer pfnCallResumeRsp callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CallResumeResponse(
							 IN uint32 uiCallId,
							 IN e_IFX_CMGR_Status eStatus,
							 IN e_IFX_ReasonCode eReason, 
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Call Resume Response" );

	evtInfo.eEvent = IFX_DECT_EVT_ResumeResp;
	evtInfo.uiId = uiCallId;
	evtInfo.uxEventData.eStatus = eStatus;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Resume Response Failed !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConfStatus 
 *  Description     : This callback function is called by CM to indicate 
 *	                  conference status. This sends IFX_DECT_EVT_ConfStatus 
 *	                  event to DECT PP FSM.
 *  Input Values    : Please refer pfnConfStatus callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConfStatus(
							 IN uint32 uiRequestId,
							 IN e_IFX_CMGR_Status eStatus,
							 IN e_IFX_ReasonCode eReason,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Conference Status" );

	evtInfo.eEvent = IFX_DECT_EVT_ConfStatus;
	evtInfo.uiId = uiRequestId;
	evtInfo.uxEventData.eStatus = eStatus;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Conference Status Failed !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RemoteCallRelease
 *  Description     :  This callback function is called by CM to indicate remote 
 *	                   has released call. This sends IFX_DECT_EVT_ReleaseCall 
 *	                   event to DECT PP FSM.
 *  Input Values    : Please refer pfnRemoteCallRelease callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RemoteCallRelease(
							 IN uint32 uiCallId,
							 IN e_IFX_ReasonCode eReleaseReason,
							 IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};
	e_IFX_ReasonCode eReason ;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Call Is Released");

	evtInfo.eEvent = IFX_DECT_EVT_ReleaseCall;
	evtInfo.uiId = uiCallId;
	evtInfo.uxEventData.eReasonCode = eReleaseReason;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eReason) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Remote Call Release Failed !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallForwardInfo
 *  Description     : This callback function is called by CM if call initiated
 *	                  from this Agent is forwarded by peer.
 *  Input Values    : Please refer pfnCallFwdInfo callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CallForwardInfo(
							 IN uint32 uiCallId,
							 IN e_IFX_ReasonCode eReason, 			
							 IN x_IFX_CMGR_AddressInfo* pxFwdAddr,			
							 OUT boolean* pbFwdAllow,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
   *pbFwdAllow = IFX_TRUE;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Call Is Being Forwarded" );
	return IFX_SUCCESS; /* Let CM to initiate call to forwarded party */
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BlindTxRequest
 *  Description     : This callback function is called by CM when peer request 
 *	                  for blind transfer. If call is valid and can be transfered
 *	                  then function informs call manager to allow transfer. Other
 *	                  -wise transfer will be denied.
 *  Input Values    : Please refer pfnBlindTxReq callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_BlindTxRequest(
							 IN uint32 uiCallId,
							 IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
							 OUT e_IFX_TransferStatus* peTransferStatus,
							 OUT e_IFX_ReasonCode *peRespCode,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	*peTransferStatus = IFX_CMGR_TRANSFER_REJECTED;
	*peRespCode = IFX_TRANSFER_FAIL;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Requested For Blind Transfer" );

	if( IFX_DECT_STATE_ACTIVE == pxEndptInfo->eState /*||
			IFX_DECT_STATE_CALL_WAITING == pxEndptInfo->eState ||
			IFX_DECT_STATE_CONFERENCE == pxEndptInfo->eState */ )
	{
		*peTransferStatus = IFX_CMGR_TRANSFER_ACCEPTED;
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Blind Transfer Accepted" );
	}
	else
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Blind Transfer Rejected" );
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AttendedTxRequest
 *  Description     : This callback function is called by CM when peer requests 
 *	                  for attended transfers. 
 *  Input Values    : Please refer pfnAttendedTxReq callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AttendedTxRequest(
							 IN uint32 uiCallId,
							 IN uint32 uiReplacesCallId,
							 IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
							 OUT e_IFX_TransferStatus* peTransferStatus,
							 OUT e_IFX_ReasonCode *peRespCode,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	*peTransferStatus = IFX_CMGR_TRANSFER_REJECTED;
	*peRespCode = IFX_TRANSFER_FAIL;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Peer Reqested For Attended Transfer" );

	if( IFX_DECT_STATE_ACTIVE == pxEndptInfo->eState /*||
			IFX_DECT_STATE_CALL_WAITING == pxEndptInfo->eState ||
			IFX_DECT_STATE_CONFERENCE == pxEndptInfo->eState */ )
	{
		*peTransferStatus = IFX_CMGR_TRANSFER_ACCEPTED;
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Attended Transfer Accepted" );
	}
	else
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Attended Transfer Rejected" );
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BlindTxStatus
 *  Description     : This callback function is called by CM to indicate blind 
 *	                  transfer status.  
 *  Input Values    : Please refer pfnBlindTxStatus callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_BlindTxStatus(
							 IN uint32 uiCallId,
							 IN e_IFX_TransferStatus eTransferStatus, 
							 IN e_IFX_ReasonCode eRespCode,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	x_IFX_DECT_EventInfo evtInfo = {0};

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Blind Transfer Response" );

	evtInfo.eEvent = IFX_DECT_EVT_BtxResp;
	evtInfo.uiId = uiCallId;
	evtInfo.uxEventData.eTxStatus = eTransferStatus;

	if( IFX_SUCCESS != 
			IFX_DECT_FsmHdlr(pxEndptInfo,&evtInfo,&eRespCode) )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "!! Hold Tx Response FAILED !!" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AttendedTxStatus 
 *  Description     : This callback function is called by CM to indicate 
 *	                  Attended transfer status.  
 *  Input Values    : Please refer pfnAttendedTxStatus callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AttendedTxStatus(
							 IN uint32 uiCallId,
							 IN e_IFX_TransferStatus eTransferStatus, 
							 IN e_IFX_ReasonCode eRespCode,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;
	//x_IFX_DECT_EventInfo evtInfo = {0};
	x_IFX_DECT_CallInfo* pxHeldCall = 0;
	e_IFX_Return eRet = -1 ;
	e_IFX_TransferStatus eTfrStatus = IFX_CMGR_TRANSFER_FAILED;
	e_IFX_ReasonCode peReason =0;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Attended Transfer Response" );

	/*evtInfo.eEvent = IFX_DECT_EVT_BtxResp;
	evtInfo.uiId = uiCallId;
	evtInfo.uxEventData.eTxStatus = eTransferStatus;*/
    IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
    if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
				    IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
    {
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
	  		pxEndptInfo->szEndptId, "Could Not Initiated Attended Transfer" );
	  IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
	    		IFX_TERMINATED, NULL, NULL, &peReason);
	  IFX_DECT_ResetCall(pxHeldCall,0);
	  //Active call will be released in IFX_DECT_MakeDectPPIdle
      IFX_DECT_MakeDectPPIdle(pxEndptInfo);
    } else {
      if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS) ){  
        IFX_DECT_CSU_CallTransferAck(pxHeldCall->uiDTkCallId,
	                               pxEndptInfo->pxActiveCall->uiDTkCallId,
				                   NULL,IFX_SUCCESS);
      }else{
        IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS);
       }
	  IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
	    		IFX_TERMINATED, NULL, NULL, &peReason);
	  IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);

    }
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallIdReplace 
 *  Description     : This callback function is called by CM to replace call id.  
 *	                  Search call info using old call id and then replace 
 *	                  with new call id. This routine does not post any event to
 *	                  DECT FSM.
 *  Input Values    : Please refer pfnCallIdRep callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CallIdReplace( 
	                                  IN uint32 uiOldCallId,
	                                  IN uint32 uiNewCallId,
	                                  IN void** ppvPrivateData )
{
	x_IFX_DECT_CallInfo* pxCallInfo = 0 ;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo 
																	= (x_IFX_DECT_EndptFsmInfo*)*ppvPrivateData;
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Call Manager Requested To Replace Call Id" );

	IFX_DECT_GetCallInfo(pxEndptInfo, uiOldCallId, &pxCallInfo);

	if( NULL != pxCallInfo )
	{
    printf("\n Old Call Id = %x",uiOldCallId);
		pxCallInfo->uiCallId = uiNewCallId;
    printf("\n New Call Id = %x",uiNewCallId);
    printf("\n CallerNumber in Endpoint Info = %s\n",pxEndptInfo->szCallerNumber);
	}
#ifdef DEV_DEBUG
	else
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Wrong Call Id" );
	}
#endif
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetMediaParams
 *  Description     : This is callback routine is called by call manager to get
 *	                  media parameters for a call. If call id is valid, routine
 *	                  returns media parametrs to call manager.
 *  Input Values    : Please refer pfnGetMediaParams callback function for 
 *	                  parameter details
 *  Output Values	  : pxMediaParams - If call is valid, media parameters for 
 *	                  given call is returned in this param.
 *  Return Value    : If call id is valid, returns IFX_SUCCESS, otherwise
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_GetMediaParams(
	               IN uint32 uiCallId,
	               OUT x_IFX_CMGR_MediaParams* pxMediaParams,
	               IN void* pvPrivateData)
{
	x_IFX_DECT_CallInfo* pxCallInfo = 0;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo 
																	= (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	x_IFX_CMGR_ExtnMediaParams* pxExtnMediaParams = 
											&pxMediaParams->uxMediaParams.xExtnMediaParams;
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Call Manager Is Requesting For Media Params");
	IFX_DECT_GetCallInfo(pxEndptInfo, uiCallId, &pxCallInfo);
	if( pxCallInfo )
	{
		pxMediaParams->eAgentType = IFX_CMGR_TYPE_EXTN;
		pxExtnMediaParams->xCodecParams.unNoOfCodecs = 1;
		pxExtnMediaParams->xCodecParams.axCodec[0].uiCodec = 
													IFX_DECT_GetCmgrCodec(pxCallInfo->eNegCodec);
    printf("%s negotiated codec is %d\n",__FUNCTION__,pxCallInfo->eNegCodec);
		eRet = IFX_SUCCESS;
	}
	else
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Wrong Call Id From Call Manager");
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_MediaNegReq
 *  Description     : This routine is callback function registered with call 
 *	                  manager to receive media negotiation information. CM calls
 *	                  this routine when there is a change in media. If call-id is
 *	                  valid updates DECT call's media parameters and if needed to 
 *	                  change media on DECT air-interface, posts service change 
 *	                  request to DECT stack. In this case media wiil be changed 
 *	                  after receiving service change resposne from handset. 
 *  Input Values    : Please refer pfnMediaNegReq callback function for 
 *	                  parameter details
 *  Output Values	  : pxMediaParams- If call is valid, accepted media parameters 
 *	                  for given call is returned in this param.
 *  Return Value    : If call id is valid, returns IFX_SUCCESS, otherwise
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MediaNegReq(
	               IN uint32 uiCallId,
	               IN_OUT x_IFX_CMGR_MediaParams* pxMediaParams,
	               OUT e_IFX_CMGR_Status* peStatus,
	               OUT e_IFX_ReasonCode* peReason,
	               IN void* pvPrivateData)
{
	x_IFX_DECT_CallInfo* pxNegCall = 0;
	x_IFX_MMGR_CodecList xMmgrCodecList = {0};
	e_IFX_MMGR_CodecType eNewCodecType;
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo 
																	= (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	
	*peStatus = IFX_CMGR_STATUS_FAIL;
		
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Received Media Neg Req" );
	
	IFX_DECT_GetCallInfo(pxEndptInfo, uiCallId, &pxNegCall);

	if( 0 == pxNegCall )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Media Neg Req On Wrong Call Id" );
		return IFX_FAILURE; //No Call exist
	}
  //Can new media be accepted ?
	IFX_DECT_ConvertCodecToMMGR(&xMmgrCodecList,
				&pxMediaParams->uxMediaParams.xExtnMediaParams.xCodecParams);

	if( 0 == xMmgrCodecList.ucNoOfCodecs )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "No Matching Codec Found" );
		return IFX_SUCCESS;
	}
	
	eNewCodecType = xMmgrCodecList.axCodecs[0].eCodecType;
	
	if( pxNegCall == pxEndptInfo->pxActiveCall )
	{
		/*
		 * Its for active call. Send service change request to PP and return 
		 * status as pending.
		 */
		 pxNegCall->eNegCodec = IFX_MMGR_CODEC_G726_32; //TODO: Delete after testing 13/04/2009
		 
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Code has changed !!!!!" );
			printf("[%d]== [%d]\n",pxNegCall->eNegCodec,eNewCodecType);										
		if( pxNegCall->eNegCodec != eNewCodecType )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Service Change Request Needed" );

			x_IFX_DECT_CSU_CallParams xCallParams = {0};
      xCallParams.bwideband =
          IFX_DECT_IsWidebandCodec(eNewCodecType);
			//Change codec on air interface (i.e. DECT side)
			IFX_DECT_CSU_ServiceChange(
            pxNegCall->uiDTkCallId,
	        &xCallParams,
			IFX_DECT_CSU_SC_REQUEST);

			pxNegCall->eNegCodec = eNewCodecType;
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_MEDIA_CHANGE_REQ);
			*peStatus = IFX_CMGR_STATUS_PENDING;
		}
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Running codec and Offered Codec Are Same" );
			*peStatus = IFX_CMGR_STATUS_SUCCESS; //No need to change codec
		}
	}
	else
	{
		//For non-active call
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Media Neg Request Is For Non Active Call" );
		pxNegCall->eNegCodec = 
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
	}
		
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_MediaNegResp 
 *  Description     : This routine is registered with CM to receive media change
 *	                  response. CM invokes this callback after receiving media
 *	                  negotiation response. If media negotiation is initiated by
 *	                  DECT Agent on given call (uiCallId), then response is 
 *	                  processed.
 *  Input Values    : Please refer pfnMediaNegRsp callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : If call id is valid, returns IFX_SUCCESS, otherwise
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MediaNegResp(
	               IN uint32 uiCallId,
	               IN x_IFX_CMGR_MediaParams* pxMediaParams,
	               IN_OUT e_IFX_CMGR_Status* peStatus,
	               IN_OUT e_IFX_ReasonCode* peReason,
	               IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo 
																	= (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	*peStatus = IFX_CMGR_STATUS_FAIL;
#ifdef TEST_MEDIA_NEG
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"After Success Call's Codec = ", 
			pxMediaParams->uxMediaParams.xExtnMediaParams.xCodecParams.axCodec[0].uiCodec)
	return IFX_SUCCESS;
#endif
	
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_SERVICE_CHANGE_IN) )
	{
		x_IFX_DECT_CSU_CallParams xCallParams = {0};
		x_IFX_MMGR_CodecList xMmgrCodecList = {0};
		
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_IN);
		IFX_DECT_ConvertCodecToMMGR(&xMmgrCodecList,
					&pxMediaParams->uxMediaParams.xExtnMediaParams.xCodecParams);
		pxEndptInfo->eRunningCodec = xMmgrCodecList.axCodecs[0].eCodecType;
		IFX_DECT_CSU_ServiceChange(
          pxEndptInfo->pxActiveCall->uiDTkCallId,
		  &xCallParams,
		  IFX_DECT_CSU_SC_ACCEPT);
		//CHECK: Is it OK to activate DECT channel now??
		if( IFX_MMGR_SUCCESS != IFX_MMGR_DectResActivate(
												pxEndptInfo->szEndptId, (xMmgrCodecList.axCodecs+0),
												 (pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_ECHO_TCL_55)?0:1) )
		{
			//Configure codec on DECT Channel failed
			//This should never fail, TODO: if it fails, disconnect call
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
		}
	}
#ifdef DEV_DEBUG
	else
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Unexpected Media Neg Response");
	}
#endif
	
	return IFX_SUCCESS;
}

#ifdef MESSAGE_SUPPORT
/*******************************************************************************
 *  Function Name   : IFX_DECT_MsgRcv 
 *  Description     : This routine is registered with CM to receive new message
 *	                  response. CM invokes this callback after receiving a new
 *	                  message. 
 *  Input Values    : Please refer pfnMsgRcv callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS, or
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MsgRcv(
									IN x_IFX_CMGR_AddressInfo *pxFrom,
									IN x_IFX_CMGR_AddressInfo *pxTo,
									IN char8* szMsgBody,
									IN uint32 unMsgId,
								  IN uchar8 ucLineId,
									OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	boolean bGwMode = IFX_FALSE;
	uchar8 ucSize, ucNoOfUnReadMsg;
	char8 aszHandset[IFX_VMAPI_MAX_DECT_ENDPTS];
	e_IFX_ReasonCode eReason;
	uchar8 ucCnt =0;

	/* Get the Number of UnRead messages in this line */
	if(IFX_SUCCESS != IFX_CIF_VLNoOfUnReadMsgGet(ucLineId,&ucNoOfUnReadMsg,&eReason)) {

		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													ucLineId, "Getting of UnRead Msg Failed in this line" );
	}
	/* Get the associated handset Id list for that line */
	if(IFX_CIF_VLDectHandsetListGet(ucLineId,&ucSize,aszHandset,&eReason)) {

		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													ucLineId, "Getting of HandsetId Failed for this line" );
		return IFX_FAILURE;
	}

	for(ucCnt =0;  ucCnt<ucSize ; ucCnt++) {	
		IFX_DECT_SMSU_SendAlert(aszHandset[ucCnt],ucNoOfUnReadMsg);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_MsgStatus 
 *  Description     : This routine is registered with CM to receive new status 
 *  Input Values    : Please refer pfnMsgStatus callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS, or
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MsgStatus(
									IN uint32 unMsgHdl,
									IN e_IFX_CMGR_Status eMsgStatus)
{
	return IFX_SUCCESS;

}
#endif /* MESSAGE_SUPPORT */



/*******************************************************************************
 *  Function Name   : IFX_DECT_AutoRedialStatus
 *  Description     : This callback function is called by CM to inidicate auto 
 *	                  redial status. If auto-redial is initated by handset, then
 *	                  success or failure status is indicated to user by playing
 *	                  confirmation or error tone respectively.
 *  Input Values    : Please refer pfnARD_Status callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AutoRedialStatus( 
							 IN uint32 uiRequestId,
							 IN e_IFX_CMGR_Status eSubsStatus,
							 IN e_IFX_ReasonCode eRespCode,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo 
																		= (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Auto Redial Status" );
	

	if( IFX_DECT_STATE_DIALING == pxEndptInfo->eState )
	{
		if( uiRequestId == pxEndptInfo->uiAutoRedialOutReqId && 
				IFX_CMGR_STATUS_PENDING != eSubsStatus )
		{
			uchar8 ucSignal = IFX_DECT_CONFIRMATION_TONE;
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_REQ_INITIATED);

			if( IFX_CMGR_STATUS_SUCCESS == eSubsStatus)
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId, "Auto Redial Success" );
				IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT);
			}
			else //IFX_CMGR_STATUS_FAIL
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId, "Auto Redila Subscription Failed" );
				pxEndptInfo->uiAutoRedialOutReqId = 0;
				ucSignal = IFX_DECT_ERROR_TONE;
			}
			IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,ucSignal);
			IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,
													IFX_DECT_BUSY_TONE_TIMER,  &pxEndptInfo->uiBCETimerId);
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_BUSY);
		}
	}
	else
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "This Event Is Not Expected In This State" );
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AutoRedialNotifyReceived 
 *  Description     : This callback function is called by CM to inform the auto 
 *	                  redial notification received from peer. If auto-redial was
 *	                  initiated and given request id is valid, then notification
 *	                  is processed, else notification is ignored. Action taken 
 *	                  depends on the notification status and state DECT FSM 
 *	                  state.
 *	                  status=success :: state=IDLE, then initiate auto-redial
 *	                  	                state=busy, then set flag to initiate
 *	                  auto-redial when handset moves to IDLE state.
 *	                  status=fail    :: clear all auto redial ids and flasg.
 *	                  status=pending :: no action.
 *  Input Values    : Please refer pfnARD_NtfnRcv callback function for 
 *	                  parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : Notification may arrive before handset goes to IDLE state
 *	                  after initiating auto-redial request. This condition is 
 *	                  handled. 
 ******************************************************************************/
e_IFX_Return IFX_DECT_AutoRedialNotifyReceived( 
							 IN uint32 uiRequestId,
							 IN e_IFX_CMGR_Status eRemoteStatus, 
							 IN e_IFX_ReasonCode eRespCode,
							 IN void* pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;

	pxEndptInfo = (x_IFX_DECT_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Received Auto Redial Notify" );

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT ) &&
			uiRequestId == pxEndptInfo->uiAutoRedialOutReqId )
	{

		if( IFX_CMGR_STATUS_SUCCESS == eRemoteStatus )
		{
			/*
			 * Peer is free now. If this PP is idle, initiate call with PP and play
			 * distinvtive ring. If PP is in busy state, set flag to indicate peer
			 * is free (and call will be initiated when PP becomes idle), else ignore
			 * this event.
			 */
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT);
			pxEndptInfo->uiAutoRedialOutReqId = 0;
			if( IFX_DECT_STATE_IDLE == pxEndptInfo->eState )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Auto Redial: Peer Is Free" );
				IFX_DECT_InitiateAutoRedial(pxEndptInfo);
			}
			else if( IFX_DECT_STATE_BUSY == pxEndptInfo->eState )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, 
						"Auto Redial: Redial Will Be Initiated Later" );
				IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ON_IDLE);
			}
			else //Can not do auto redial, ignoring event
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, 
						"Auto Redial: Can Not Initiate Auto Redial" );
			}
		}
		else if( IFX_CMGR_STATUS_PENDING == eRemoteStatus )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Auto Redial: Peer Is Still Busy" );
		}
		else //IFX_CMGR_STATUS_FAIL
		{
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, 
			"Auto Redial Subscription Canceled by Peer Or Failed" );
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT);
			pxEndptInfo->uiAutoRedialOutReqId = 0;
		}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AutoRedialRegister
 *  Description     : This callback function is called by CM when peer party 
 *	                  requests for auto redial registration/cancelation. If 
 *	                  called for ARD registration, returns status as success if
 *	                  endpoint is IDLE, else pending.
 *  Input Values    : Please refer pfnARD_Reg callback function for parameter 
 *	                  details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : Only one Auto Redial Request is accepted for a endpoint.
 *	                  If ARD request is pending, new requested will be rejected.
 ******************************************************************************/
e_IFX_Return IFX_DECT_AutoRedialRegister( 
							 IN uint32 uiRequestId,
							 IN boolean bEnable,
							 IN char8* szEndptId,
							 OUT e_IFX_CMGR_Status* peLocalStatus,
							 IN void** pvPrivateData )
{
	x_IFX_DECT_EndptFsmInfo* pxEndptInfo;

	*peLocalStatus = IFX_CMGR_STATUS_FAIL;

	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			szEndptId, "Received Auto Redial Register Request" );
	if( IFX_SUCCESS != IFX_DECT_GetEndptInfoById(szEndptId, &pxEndptInfo) )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				szEndptId, "!! This Endpoint Does Not Exist !!" );
		return IFX_FAILURE;
	}

	*pvPrivateData = (void*)pxEndptInfo;

	if( bEnable )
	{
		/*
		 * Request for auto redial subscription. If someone has subscribed, reject
		 * this subscription. 
		 * If handset is in idle state, return status as success, else set flag -
		 * IFX_DECT_F_AUTOREDIAL_ACTIVE_IN, store request id and return status as 
		 * pending.
		 */
		if( 0 == pxEndptInfo->uiAutoRedialInReqId  )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					szEndptId, "Auto Redial Subscription Accepted" );
			if( IFX_DECT_STATE_IDLE == pxEndptInfo->eState )
				*peLocalStatus = IFX_CMGR_STATUS_SUCCESS;
			else
			{
				*peLocalStatus = IFX_CMGR_STATUS_PENDING;
				pxEndptInfo->uiAutoRedialInReqId = uiRequestId;
				IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_IN);
			}	
		}
		else
		{ //Reject this request
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					szEndptId, 
					"Auto Redial Subscription Exist Already. Rejecting This Request" );
		}
	}
	else //Disable subscription
	{
		if( uiRequestId == pxEndptInfo->uiAutoRedialInReqId )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					szEndptId, "Peer Canceled Auto Redial Subscription"); 
			pxEndptInfo->uiAutoRedialInReqId = 0;
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_IN);
		}
#ifdef DEV_DEBUG
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					szEndptId, "Auto Redial Subscription Cancel: Wrong Request Id"); 
		}
#endif
	}

	return IFX_SUCCESS;
}
#ifdef ENABLE_PAGING
/*******************************************************************************
 *  Function Name   : IFX_DECT_ProcessPagekeyMessage 
 *  Description     : This routine processes pagekey events. Paging key is used 
 *	                  for paging handsets and also for registring handsets. 
 *	                  These two events are distinguished using key pressed 
 *	                  duration.
 *	                  Paging - If registration is enabled, ignore the event. Else
 *	                  if paging is started earlier and still handsets are being 
 *	                  paged, stop paging. Otherwise start paging.
 *	                  Registration - Start registration if paging is not running
 *  Input Values    : uiPagingKeyPressedDur - Key pressed duration (in ms)
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/
e_IFX_Return IFX_DECT_ProcessPagekeyMessage( 
	                    uint32 uiPagingKeyPressedDur //in ms
											)
{
  char8 acBaseName[IFX_MAX_BASENAME]={'\0'};
	  /* FT Initiated Date-Time.uiPagingKeyPressedDur received as 500  */
  if(uiPagingKeyPressedDur == 50000){//Support in page button drv
    x_IFX_DECT_EndptFsmInfo* pxDectEndpt = vaxDectEndptFsmInfo;
    uchar8 ucIndex = 0;
    x_IFX_DECT_USU_TimeDate xTimeDate = {0};
    uchar8 ucHandset = 0;
   
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Page button invoked Date Time Notification");
    for(ucIndex = 0; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex, ++pxDectEndpt )
    {
       ucHandset = IFX_DECT_HsIdFromEPName(pxDectEndpt->szEndptId);
	     //if PP is attached, send date-time info
	    if( IFX_FALSE != pxDectEndpt->bPPAttached ){
 
	      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Sending Date-Time Notification to Handset Id = ", ucHandset);
        IFX_DECT_GetTimeDate(&xTimeDate);
        if(IFX_SUCCESS == IFX_DECT_USU_DateTimeSync(ucHandset, &xTimeDate)){

          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
                   IFX_DBG_STR,"Updated TimeDate of PT");
        }else{
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
                   IFX_DBG_STR,"Failed to Update TimeDate of PT");
          //TODO: Ask what to do 
         }
      }else{
	      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Not sending Date-Time Notification as Handset is not attached:", ucHandset);
       }
    }
    return IFX_SUCCESS;
  }
  if(uiPagingKeyPressedDur == 70000){//To chk DECT Shutdown API
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	"User Pressed Shutdown key. Allowing Shutdown...." );
		IFX_DECT_ShutDown();
		return IFX_SUCCESS;
	}
  if(uiPagingKeyPressedDur == 90000){//To chk restat DECT after Shutdown API
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"User Pressed Shutdown key. Allowing DECT restart after Shutdown...." );
			return IFX_DECT_Start();
	}
  
#ifdef  LTQ_DT_SUPPORT
	if(uiPagingKeyPressedDur == 6000){//To Send notification for RSS 
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Sending Notification for  RSS ..." );
			//return IFX_DECT_Start();
			return IFX_DECT_LAU_EmailNotify(1,0,1);
				//return IFX_DECT_LAU_DT_Notify(1,1,5,1,5);
	}
  if(uiPagingKeyPressedDur == 7000){//To Send notificatin for EMAIL 
    	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Sending notification for Email ... " );
			return IFX_DECT_LAU_EmailNotify(1,1,1);
				//return IFX_DECT_LAU_DT_Notify(1,1,5,1,5);
	}
#endif

  if( uiPagingKeyPressedDur < IFX_DECT_REG_KEY_PRESS_DUR )
  {
    x_IFX_DECT_EventInfo evtInfo = {IFX_DECT_EVT_Paging};
    x_IFX_DECT_EndptFsmInfo* pxDectEndpt = vaxDectEndptFsmInfo;
    e_IFX_ReasonCode eReason;
    uchar8 ucIndex ;

    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		"User Pressed Paging Key. Initiating Paging...." );

    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,"CurPagingPPCount:",vucCurPagingPPCount);

    evtInfo.uxEventData.bPagingOn = (vucCurPagingPPCount)?IFX_FALSE:IFX_TRUE ;
			
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,"bPagingOn:",evtInfo.uxEventData.bPagingOn);
	  
    if(IFX_DECT_MU_PageAllHandsets((uchar8 *)"Handset locator",(uchar8 *)"Handset locator") == IFX_SUCCESS){
       vucCurPagingPPCount =1;
    }else{
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"User Pressed Paging Key. Stopped Paging...." );
        IFX_DECT_MU_PageCancel(); 
        vucCurPagingPPCount =0;
    }
    for(ucIndex = 0; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; 
					++ucIndex, ++pxDectEndpt )
    {
	//if PP is attached, initiate/stop paging
	if( IFX_FALSE == pxDectEndpt->bPPAttached || 
			IFX_SUCCESS != IFX_DECT_FsmHdlr(pxDectEndpt, &evtInfo, &eReason) )
	{
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxDectEndpt->szEndptId, 
			"Ignored Paging Event. (PP Is Not Attached / In Call)" );
	}
    }
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,"CurPagingPPCount:",vucCurPagingPPCount);
	printf("Paging info---%d\n",vucCurPagingPPCount);
  }
  else
  { //Event is for registration
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	"User Pressed Registration Key. Allowing Registration...." );
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,"CurPagingPPCount:",vucCurPagingPPCount);
	printf("Paging info---%d\n",vucCurPagingPPCount);

	if( 0 == vucCurPagingPPCount )
	{
    IFX_CIF_BS_NameGet((char8*)acBaseName);
    if(acBaseName[0] != '\0'){
	    IFX_DECT_MU_RegistrationAllow(IFX_DECT_REG_DURATION,(char8*)acBaseName);
    }
    else{
	    IFX_DECT_MU_RegistrationAllow(IFX_DECT_REG_DURATION,NULL);
    }
	}
#ifdef DEV_DEBUG
	else
	{
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		"Could Not Start Registration Mode. Base Is Paging Handsets" );
	}
#endif
    }
    return IFX_SUCCESS;
}
#endif /* ENABLE_PAGING */


/*******************************************************************************
 *  Function Name   : IFX_DECT_IgnoreHdlr
 *  Description     : This is DECT FSM routine. It is used for ignoring a event.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_FAILURE 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_IgnoreHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
		
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Event Is Not Expected: Ignoring Event" );
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			IFX_DECT_GetStateStr(pxEndptInfo->eState), 
			IFX_DECT_GetEventStr(pxEvtInfo->eEvent));

	return IFX_FAILURE;
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_IgnoreCallHdlr
 *  Description     : This is DECT FSM routine. It is used for ignoring a event.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_FAILURE 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_IgnoreCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Event Is Not Expected: Ignoring Call" );
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			IFX_DECT_GetStateStr(pxEndptInfo->eState), 
			IFX_DECT_GetEventStr(pxEvtInfo->eEvent));
   *peReason = IFX_ABNORMAL_RELEASE;
   return IFX_SUCCESS;
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_IdlePPOffHookHdlr
 *  Description     : This routine handles handset off-hook event in idle state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call is accepeted and resources are allocated, then 
 *	                  returns IFX_SUCCESS, else IFX_FAILURE.
 ******************************************************************************/
e_IFX_Return IFX_DECT_IdlePPOffHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_DECT_SetupEvent* pxSetupEvt = &pxEvtInfo->uxEventData.xSetupEvt;
	
	*peReason = IFX_MAX_REASON;
	x_IFX_CodecList xCodecList = {0};

	xCodecList.unNoOfCodecs = 1;
	xCodecList.axCodec[0].uiCodec = IFX_G726_32;
	if(IFX_DECTNG_CODEC_G722_64 == pxSetupEvt->aunCodec[0] )
	{
		//wideband call
		xCodecList.unNoOfCodecs = 2;
		xCodecList.axCodec[0].uiCodec = IFX_G722_64;//high priority
		xCodecList.axCodec[1].uiCodec = IFX_G726_32;
	}

	/* Get free call info */
	/* Store the Dect Toolkit Call Handler into the New Call instance */
	//IFX_DECT_GetFreeCallInfo(pxEndptInfo, &pxEndptInfo->pxActiveCall);
    pxEndptInfo->uiDTkCallId = pxSetupEvt->uiTmpDtkCallHdl;
	IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs,&xCodecList);

	if( IFX_MMGR_SUCCESS !=
		IFX_MMGR_DectResAlloc(pxEndptInfo->szEndptId, 
								&pxEndptInfo->unDectChannel, &pxEndptInfo->xReservedCodecs) )
	
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Allocate DECT Resource" );
		pxSetupEvt->ucRejectReason = IFX_DECT_INSUFFICIENT_RESOURCES;
	}
	else
	{
		e_IFX_DECT_Event eTimerEvent = IFX_DECT_EVT_DialTimerExpired ;
		uint32 unTimerDur = IFX_DECT_DIAL_TONE_TIMER; 
		uint32* puiTimerId = &pxEndptInfo->uiToneTimerId;
		IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED);
#ifdef EST_UPLANE_BEFORE_CONNECT 
		//TODO: Establish u-plane
		pxEndptInfo->eRunningCodec = 
									pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType;
#endif			
		printf("Digits received %s\n",pxSetupEvt->xDigitInfo.szDigits);
    printf("\n Digits received.\n");
		if( pxSetupEvt->xDigitInfo.szDigits[0] != '\0' )
		{
			//Block dialing. Wait if any digits are on air
			  strcpy(pxEndptInfo->szDialledDigits, pxSetupEvt->xDigitInfo.szDigits);
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szDialledDigits,"Digits received. Wait for more digits");
			eTimerEvent = IFX_DECT_EVT_InterDigitTimerExpired;
			unTimerDur = 2000; //TODO: Check this timer value and define
			puiTimerId = &pxEndptInfo->uiIntrDgtTimerId;
		} 
      eRet = IFX_MMGR_DectResActivate(pxEndptInfo->szEndptId, 
											(pxEndptInfo->xReservedCodecs.axCodecs+0), (pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_ECHO_TCL_55)?0:1);


	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) )
	{											 
    x_IFX_DECT_CSU_CallParams xCallParams = {0};

		IFX_DECT_CSU_VoiceModify(
			pxEndptInfo->uiDTkCallId,
		      &xCallParams, IFX_DECT_START_VOICE, pxEndptInfo->unDectChannel);

		IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
	} 
#ifndef TONES
  if(pxSetupEvt->xDigitInfo.szDigits[0] == '\0'){
    IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_DIAL_TONE); 
  }
#endif
		IFX_DECT_FsmTimerStart(pxEndptInfo, eTimerEvent, unTimerDur,  puiTimerId);
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_DIALING);
		eRet = IFX_SUCCESS;
	}
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_IdleIncomingCallHdlr 
 *  Description     : This routine handles incoming call event in IDLE state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS - If call is accepted.
 *	                  IFX_FAILURE - On failure.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_IdleIncomingCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_IncCallEvent* pxIncallEvt = (&pxEvtInfo->uxEventData.xIncCallEvt);
	x_IFX_CMGR_CallParams* pxCallParams;
//	boolean bBlocked = IFX_FALSE;
	uchar8 ucIndex = 0;
	x_IFX_DECT_CSU_CallParams xCallParams = {0};
	boolean bWidebandCall = IFX_FALSE;

	*peReason = IFX_MAX_REASON;

	pxCallParams = pxIncallEvt->pxCallParams;
	
	IFX_AGU_GetCallerIdInfo(pxIncallEvt->pxFrom, 
			pxEndptInfo->szCallerName, pxEndptInfo->szCallerNumber);
	/*IFX_CIF_IncomingCallBlockCheck(pxEndptInfo->szEndptId,
											pxEndptInfo->szCallerName, &bBlocked, peReason);*/
  if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) == IFX_DECT_F_PAGE_CALL)
  {
    printf("In paging Mode ... so cancel it !!!");
    IFX_DECT_MU_PageCancel();
    IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL);
    vucCurPagingPPCount =0;
    sleep(2);
  }
	if( IFX_CMGR_TYPE_EXTN == pxIncallEvt->pxFrom->eAddressType)
	{
	  xCallParams.isInternal = IFX_TRUE;
	  xCallParams.ucPeerHandsetId = 
	          IFX_DECT_HsIdFromEPName(pxIncallEvt->pxFrom->uxAddressInfo.szEndptId);
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Peer Handset Id = ", xCallParams.ucPeerHandsetId);
	}
 /* if( bBlocked )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Incoming Call Is Blocked" );
		return IFX_FAILURE;
	}
	*/
	IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs, 
			&pxCallParams->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams);
	if( IFX_MMGR_SUCCESS !=
		IFX_MMGR_DectResAlloc(pxEndptInfo->szEndptId, 
						&pxEndptInfo->unDectChannel, &pxEndptInfo->xReservedCodecs))
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Allocate Resources For DECT ");

		*peReason = IFX_NO_RESOURCE;
		return IFX_FAILURE;
	}
	
	if(pxEndptInfo->bWidebandEnabled)
	{
		{
			if( IFX_DECT_IsWidebandCodec(
							pxEndptInfo->xReservedCodecs.axCodecs[ucIndex].eCodecType) )
			{
     		printf("%s WIDE BAND ENABLED YES",__FUNCTION__);
				bWidebandCall = IFX_TRUE;
			}
		}
	}

  IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED);
	
	/* Store ring timeout. This value will be used for ring timer. */
	pxEndptInfo->unRingTimeOut = IFX_RING_TONE_DURATION;
	if( pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.cRingCount ) {
		int32 iRingDur;
		
		IFX_MMGR_RingCadenceTimeGet(&iRingDur);
		pxEndptInfo->unRingTimeOut = 
			iRingDur * pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.cRingCount;
	}
     
	pxEndptInfo->pxActiveCall = (pxEndptInfo->axCallInfo+0);
	pxEndptInfo->pxActiveCall->uiCallId = pxEvtInfo->uiId;
	pxEndptInfo->pxActiveCall->ucLineId = pxEvtInfo->uxEventData.xIncCallEvt.ucLineId;
	xCallParams.bwideband = bWidebandCall;
	printf("Codec Sent during Setup %d\n",bWidebandCall);
	strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);
	if(IFX_CIF_CNIPGet(xCallParams.isInternal,pxEvtInfo->uxEventData.xIncCallEvt.ucLineId,
										pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS)
	strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
	xCallParams.ucLineId=	pxEvtInfo->uxEventData.xIncCallEvt.ucLineId;
        xCallParams.bIsPresentation =1;
  printf("CNIP Name1:%s\n",xCallParams.acCNIP);//Don't send CLIP/CNIP in setup but send for LiA Call
	if(IFX_SUCCESS != IFX_DECT_CSU_CallInitiate (pxEndptInfo->ucInstance+1,
                         		 &xCallParams, 
                         		 (uint32)pxEndptInfo,
	                 				   (uint32 *)&pxEndptInfo->pxActiveCall->uiDTkCallId))
  {
	  *peReason = IFX_ABNORMAL_RELEASE;
    return IFX_SUCCESS;
  }

  //Send Alert Signal and CLIP/CNIP.
  //IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_SIGNAL_AlertPattern0);

	printf("<IFX_DECT_IdleIncomingCallHdlr> Call Handle is %d\n",pxEndptInfo->pxActiveCall->uiDTkCallId);
	if( IFX_CMGR_TYPE_FXO == 
		(pxEndptInfo->pxActiveCall->eCallType = pxIncallEvt->pxFrom->eAddressType))
	{
		strcpy(pxEndptInfo->pxActiveCall->szCallInitrEndptId,
									pxIncallEvt->pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId );
	}
				
	IFX_DECT_UpdateCallState(pxEndptInfo, 
										pxEndptInfo->pxActiveCall, IFX_DECT_CS_INITIATED);	
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ALERTING);
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Waiting For Handset Response");

	*peReason = IFX_REQ_PENDING;
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_IdlePagingHdlr
 *  Description     : This routine is used for paging event in IDLE state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_IdlePagingHdlr(		
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	*peReason = IFX_MAX_REASON;

	if( IFX_TRUE == pxEvtInfo->uxEventData.bPagingOn )
	{
		/* Set flag to indicate srvice call */
		IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL);
	}
	else{
    IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_PAGE_CALL);
  }

	return IFX_SUCCESS;
}

/*****************************IIIIIIIII****************************/
e_IFX_Return 
IFX_DECT_PrepareForIntercept(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,IN char8 cEndPt,IN boolean bPostToFsm ){
	 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				     "Intercept Prepare");
	e_IFX_ReasonCode eReason;
  /* Store the TKId of intercept req PP to temp storage */
  vaxDectEndptFsmInfo[(uchar8)cEndPt-1].uiDTkCallId = pxEndptInfo->uiDTkCallId;
  /* Store the intercept req PP endpoint id */
  strcpy(vaxDectEndptFsmInfo[(uchar8)cEndPt-1].szDialledDigits, pxEndptInfo->szEndptId);
	IFX_DECT_SetEndptFlag(&vaxDectEndptFsmInfo[(uchar8)cEndPt-1], IFX_DECT_F_INTERCEPT_INIT);
	strcpy(pxEndptInfo->szDialledDigits, vaxDectEndptFsmInfo[(uchar8)cEndPt-1].szEndptId);
	if(bPostToFsm){
  	x_IFX_DECT_EventInfo evtInfo = {0};
		x_IFX_DECT_TimerEvent xTimerEvt={0};
		xTimerEvt.eTimerEvent = 0;
		pxEndptInfo->uiInterceptTimerId = 0; 
		xTimerEvt.pxEndptInfo = pxEndptInfo; 
  	evtInfo.eEvent = IFX_DECT_EVT_PP_SSMsg;
  	evtInfo.uxEventData.xSsMsg.eSSType = IFX_DECT_SS_INTERCEPT;
		IFX_DECT_FsmHdlr_1(&vaxDectEndptFsmInfo[(uchar8)cEndPt-1], &evtInfo,&eReason);
    if( IFX_SUCCESS != IFX_TIM_TimerStart(6000, 
					&xTimerEvt, sizeof(x_IFX_DECT_TimerEvent),IFX_DECT_InterceptTimerFired,&pxEndptInfo->uiInterceptTimerId)){ 
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
							"Could Not Start Timer"); 
  		return IFX_FAILURE;
		}
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_INTERCEPT);
	}
	return IFX_SUCCESS;
}

/*****************************************************************/
e_IFX_Return IFX_DECT_LineIntrudeHsIdGet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,IN char8* szDigits,IN uchar8* pucLineId,
																					IN char8* pacEndPtList){
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			     "Line Intrude Hs id Get");
	uint16 k=0,i=0;
	e_IFX_ReasonCode eReason;
	if(*pucLineId < 1 || *pucLineId > 4 ){
		IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, pucLineId, &eReason); 
	}
	szDigits[0]='\0';
	while(pacEndPtList[i] != '\0'){
		printf("Line Id %d\n",vaxDectEndptFsmInfo[pacEndPtList[i]-1].pxActiveCall->ucLineId);
		if(vaxDectEndptFsmInfo[pacEndPtList[i]-1].pxActiveCall->ucLineId==*pucLineId){
			szDigits[0]=pacEndPtList[i]+48;
			k++;
		}
	i++;
	}
	if((k>1)||(!IFX_CIF_IsIntrusionAllowed(*pucLineId))||(k==0)){ return IFX_FAILURE;}
	return IFX_SUCCESS;
}

/*****************Intrude HsId get********************************/
e_IFX_Return IFX_DECT_IntrudeHsIdGet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,IN char8* szDigits,IN uchar8* pucLineId){
	uint32 uiEndPtNo=0;
	boolean bSendNack=IFX_FALSE;
	char8 acEndPtList[5]={'\0'};
	x_IFX_DECT_EndptFsmInfo *pxTargetEndPtInfo=NULL;
  IFX_DECT_GetListOfEndPtInCall(pxEndptInfo,acEndPtList,&uiEndPtNo);
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			     "Intrude Hs id Get");
	if(uiEndPtNo>0){
		if(strlen(szDigits)!=0){
			if(szDigits[0]=='*'){
				if(uiEndPtNo>1){szDigits[0]=acEndPtList[0]+48;bSendNack=IFX_TRUE;}
				else if(uiEndPtNo==1){szDigits[0]=acEndPtList[0]+48;}
			}
	/*Received HS Id to Intrude*/
			else{
				if(IFX_DECT_IsEndPtInCall(szDigits)==IFX_FAILURE){szDigits[0]='\0';bSendNack=IFX_TRUE;}
			}
		}
/*Received Line Id to Intrude*/
		else{
			if(IFX_FAILURE==IFX_DECT_LineIntrudeHsIdGet(pxEndptInfo,szDigits,pucLineId,acEndPtList)){bSendNack=IFX_TRUE;}
		}
		if(szDigits[0] != '\0'){
  		IFX_DECT_GetEndptInfoById(szDigits,&pxTargetEndPtInfo);
			if(pxTargetEndPtInfo != NULL && !IFX_CIF_IsIntrusionAllowed(pxTargetEndPtInfo->pxActiveCall->ucLineId)){
				bSendNack=IFX_TRUE;
			}
		}
	}else{szDigits[0]='\0';bSendNack=IFX_TRUE;}
	if(pxTargetEndPtInfo!=NULL && bSendNack==IFX_TRUE && szDigits[0] != '\0'){
		IFX_DECT_CSU_CallIntrusionAck(pxEndptInfo->uiDTkCallId,pxTargetEndPtInfo->pxActiveCall->uiDTkCallId,IFX_FAILURE);
		return IFX_FAILURE;
	}
	else if(bSendNack==IFX_TRUE && szDigits[0] == '\0'){
		IFX_DECT_CSU_CallIntrusionAck(pxEndptInfo->uiDTkCallId,0,IFX_FAILURE);
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
}

/******************Intrude Hdlr****************************/
e_IFX_Return 
IFX_DECT_IntrudeHdlr(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                      IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                      OUT e_IFX_ReasonCode* peReason )
{
  char8 cEndPt;
  x_IFX_DECT_SetupEvent* pxSetupEvt = &pxEvtInfo->uxEventData.xSetupEvt;
	if(IFX_FAILURE==IFX_DECT_IntrudeHsIdGet(pxEndptInfo,pxSetupEvt->xDigitInfo.szDigits,&pxSetupEvt->ucLineId)){
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_INTERCEPT);
		return IFX_SUCCESS;
	}
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
	pxSetupEvt->xDigitInfo.szDigits,"Intrude request for endpoint.");
	cEndPt=pxSetupEvt->xDigitInfo.szDigits[0]-48;
	IFX_DECT_SetEndptFlag(&vaxDectEndptFsmInfo[(uchar8)cEndPt-1], IFX_DECT_F_INTRUDE_INIT);
	IFX_DECT_PrepareForIntercept(pxEndptInfo,cEndPt,1);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_IdlePPInterceptHdlr
 *  Description     : This routine handles INTERCEPT event in idle state. Check 
 *                    all the PPs who are in call. Send display info to all of them.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	 : 
 *  Return Value    : Always returns IFX_SUCCESS 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return 
IFX_DECT_IdlePPInterceptHdlr(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                      IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                      OUT e_IFX_ReasonCode* peReason )
{
  int32 i=0;
  int32 iCnt=0;
  char8 acEndPtList[5] = {'\0'};
  char8 *pacDisplayMsg = "Intercept Request";
  uint32 uiEndPtNo=0;
  x_IFX_DECT_SetupEvent* pxSetupEvt = &pxEvtInfo->uxEventData.xSetupEvt;
	x_IFX_DECT_TimerEvent xTimerEvt={0};
	xTimerEvt.eTimerEvent = 0;
	pxEndptInfo->uiInterceptTimerId = 0; 
	xTimerEvt.pxEndptInfo = pxEndptInfo; 
	e_IFX_Return eRet =  IFX_FAILURE;
	x_IFX_DECT_CSU_CallParams xCallParams = {0};
	if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_REQ)){
		eRet=IFX_DECT_IntrudeHdlr(pxEndptInfo,pxEvtInfo,peReason);
		return eRet;
	}
	strcpy(pxEndptInfo->szDialledDigits, pxSetupEvt->xDigitInfo.szDigits);
  if(pxSetupEvt->xDigitInfo.szDigits[0] == '*'){
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			     "Intercept Request for all the endpoints");
  	if(IFX_DECT_GetListOfEndPtInCall(pxEndptInfo,&acEndPtList[0],&uiEndPtNo)== IFX_SUCCESS){
    	if(uiEndPtNo == 1){
	   		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  	   "Only one endpoint is in call");
     		/* Check If Intercept is allowed for the Endpoint */
     		if((IFX_CIF_IsInterceptAllowed(acEndPtList[0]))&&
					!(IFX_DECT_CheckEndptFlag(&vaxDectEndptFsmInfo[(uchar8)acEndPtList[0]-1], IFX_DECT_F_INTERCEPT_INIT))){
					eRet=IFX_DECT_PrepareForIntercept(pxEndptInfo,acEndPtList[0],1);
     		}else{
     			IFX_DECT_CSU_InterceptAck(pxEndptInfo->uiDTkCallId,
																vaxDectEndptFsmInfo[(uchar8)acEndPtList[0]-1].pxActiveCall->uiDTkCallId, 
																IFX_DECT_CSU_INTERCEPT_NOTALLOWED);
				}
      }else {
	    		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			  	   "Multiple EndPts is in call");
    		for(i= 0; i<uiEndPtNo; i++){
      		/* Check If Intercept is allowed for the Endpoint */
      		if((IFX_CIF_IsInterceptAllowed(acEndPtList[i]))&&
						!(IFX_DECT_CheckEndptFlag(&vaxDectEndptFsmInfo[(uchar8)acEndPtList[i]-1], IFX_DECT_F_INTERCEPT_INIT))){
         		/* Send the DISPLAY to all the Endpoints who has one active call */
						strcpy(xCallParams.acCLIP,pxEndptInfo->szEndptId);
						xCallParams.bIsPresentation = 1;
						xCallParams.isInternal =1;
						if(iCnt!=0){/* check after the loop and send at that pt to this PP*/
         			IFX_DECT_CSU_SendInterceptReqToPP(vaxDectEndptFsmInfo[(uchar8)acEndPtList[i]-1].pxActiveCall->uiDTkCallId, 
                                           0x02,&xCallParams,pacDisplayMsg);
						}
    				if(!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){
							IFX_DECT_PlayTone(&vaxDectEndptFsmInfo[(uchar8)acEndPtList[i]-1],
										vaxDectEndptFsmInfo[(uchar8)acEndPtList[i]-1].pxActiveCall->uiDTkCallId,(char8)xCallParams.uiSignal);
						}	
						IFX_DECT_PrepareForIntercept(pxEndptInfo,acEndPtList[i],0);
     		 	} else {
       			/* Intercept is not allowed for the Endpoint */
       			iCnt++;
     			}
   		 	}
    		if(iCnt == uiEndPtNo){
      		/* Endpoint is in call but intercept is not allowed */
      		IFX_DECT_CSU_InterceptAck(pxEndptInfo->uiDTkCallId,
																vaxDectEndptFsmInfo[(uchar8)acEndPtList[0]-1].pxActiveCall->uiDTkCallId, 
																IFX_DECT_CSU_INTERCEPT_NOTALLOWED);
    		}else	if(iCnt==1){/*Intercept Allowed only for one End Pt*/
					eRet=IFX_DECT_PrepareForIntercept(pxEndptInfo,acEndPtList[0],1);
				}else{	
        	IFX_DECT_CSU_SendInterceptReqToPP(vaxDectEndptFsmInfo[(uchar8)acEndPtList[0]-1].pxActiveCall->uiDTkCallId, 
                                           0x02,&xCallParams,pacDisplayMsg);
				/*Start 30 seconds timer waiting for Intercept Accept*/
					if( IFX_SUCCESS != IFX_TIM_TimerStart(30000, 
								&xTimerEvt, sizeof(x_IFX_DECT_TimerEvent),IFX_DECT_InterceptTimerFired,&pxEndptInfo->uiInterceptTimerId)){ 
		    			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
							"Could Not Start Timer"); 
  						return IFX_FAILURE;
					}
				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_INTERCEPT);
		 		}
  		}
				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_INTERCEPT);
			return eRet;
		}
	return IFX_FAILURE; 	
  }else {
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxSetupEvt->xDigitInfo.szDigits,"Intercept request for endpoint.");
			acEndPtList[0]=pxSetupEvt->xDigitInfo.szDigits[0]-48;
      /* Check If Intercept is allowed for the Endpoint */
      if((IFX_CIF_IsInterceptAllowed(acEndPtList[0]))&&
					!(IFX_DECT_CheckEndptFlag(&vaxDectEndptFsmInfo[(uchar8)acEndPtList[0]-1], IFX_DECT_F_INTERCEPT_INIT))){
					IFX_DECT_PrepareForIntercept(pxEndptInfo,acEndPtList[0],1);
      }else{
      	IFX_DECT_CSU_InterceptAck(pxEndptInfo->uiDTkCallId,
																	vaxDectEndptFsmInfo[(uchar8)acEndPtList[0]-1].pxActiveCall->uiDTkCallId, 
																	IFX_DECT_CSU_INTERCEPT_NOTALLOWED);
				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_INTERCEPT);
			}
			return IFX_SUCCESS;
   }
	return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingPPOffHookHdlr
 *  Description     : This routine handles OFF HOOK event in dialing state. Make 
 *                    DECT endpoint idle. Send auto redial notify if someone 
 *                    requested.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	 : 
 *  Return Value    : Always returns IFX_SUCCESS 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingPPOffHookHdlr(  
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
  x_IFX_DP_Rule xDpRule;
  char8  szDialOut[IFX_MAX_DIGITS];
  uchar8 ucDpAction = 0;
  uint16 unTimeOut = 0;
  e_IFX_DECT_States eState = IFX_DECT_STATE_MAX ;
  e_IFX_Return eRet;
  uchar8 ucDefaultLineId = 0;
  uchar8 ucLineId = 0;
	e_IFX_ReasonCode eReason;
  char8 aucPrefix[32] = "";
	x_IFX_DECT_SetupEvent* pxSetupEvt = &pxEvtInfo->uxEventData.xSetupEvt;

	uchar8 ucSignal = IFX_DECT_INVALID_TONE;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entry");

  strcpy(pxEndptInfo->szDialledDigits, pxSetupEvt->xDigitInfo.szDigits);
 
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_DTMF_CM_STRING_TEST,
      pxEndptInfo->szEndptId,  "Dialed Digits", pxEndptInfo->szDialledDigits);
#ifndef TONES
  if((pxEndptInfo->szDialledDigits[0] == '\0')&&(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){

    IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_DIAL_TONE);    
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            " No Digits just return");
  	return IFX_SUCCESS;
	}
#endif
  if(pxEndptInfo->szDialledDigits != NULL)
  {
    if((strlen(pxEndptInfo->szDialledDigits) ==1)&&((atoi(pxEndptInfo->szDialledDigits)>0)&&(atoi(pxEndptInfo->szDialledDigits)<7))){
      printf("Digit is %d",atoi(pxEndptInfo->szDialledDigits));
      IFX_DECT_GetEndptName(atoi(pxEndptInfo->szDialledDigits), pxEndptInfo->szDialledDigits);
    }else{
 
      uchar8 ucIsInternal = 0;
      if(IFX_SUCCESS == IFX_DP_RulePrefixGet(IFX_DP_EXTENSION_DIAL,aucPrefix)){
        if(!strncmp(pxEndptInfo->szDialledDigits,aucPrefix,strlen(aucPrefix)))
         ucIsInternal = 1;
      } 
      if(!ucIsInternal){
	      if(IFX_SUCCESS != IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, &ucDefaultLineId, &eReason)){
          return IFX_FAILURE;
        }
        IFX_DECT_EndpointLineIdGet(pxEndptInfo,&ucLineId);
        printf("\n ucLineId = %d\n",ucLineId);

	      if((ucDefaultLineId == IFX_PSTN_LINE)&&(ucLineId == IFX_PSTN_LINE || ucLineId == 0)){

         memset(aucPrefix,0,sizeof(aucPrefix));
         if(IFX_SUCCESS == IFX_DP_RulePrefixGet(IFX_DP_LOCAL_PSTN_CALLS,aucPrefix)){
           memmove(&pxEndptInfo->szDialledDigits[strlen(aucPrefix)],pxEndptInfo->szDialledDigits,strlen(pxEndptInfo->szDialledDigits));
		       memcpy(pxEndptInfo->szDialledDigits,aucPrefix,strlen(aucPrefix));
         }else{
           return IFX_FAILURE;
          } 
		     printf("\nPSTN Line Dial Plan Digits: %s \n", pxEndptInfo->szDialledDigits);
	      }	
      }
     }//else
  }
  strcpy(pxEndptInfo->szCallerNumber,pxEndptInfo->szDialledDigits);
  eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
                 IFX_TRUE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );
	if((pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)&&((xDpRule.eAction==IFX_DP_BLIND_TX)||
			/*(xDpRule.eAction==IFX_DP_PSTN_HOOKFLASH)||*/(xDpRule.eAction==IFX_DP_CALLWAITING_REJECT)||
			((xDpRule.eAction>=IFX_DP_DISCONNECT_LASTACTV_CALLL)&&(xDpRule.eAction<=IFX_DP_CONFERENCE))))
	{

     /*Dial plan error */  
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Not allowed for 2.0 handset" );
		eRet = IFX_FAILURE;
	} 
  else if( eRet == IFX_SUCCESS && IFX_DP_DIALOUT == ucDpAction )
  {
     eRet = IFX_DECT_ExecuteDialPlan(pxEndptInfo, xDpRule.eAction, szDialOut,
                    &ucSignal, &eState);
  }
  else
  {
     /*Dial plan error */
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
            pxEndptInfo->szEndptId, "Dial Plan Mismatch" );
    eRet = IFX_FAILURE;
  }

  /* Clear all collected digits */
  memset(pxEndptInfo->szDialledDigits,0,IFX_MAX_DIGITS);

  if(IFX_FAILURE == eRet)
  {
    ucSignal = IFX_DECT_BUSY_TONE;
#if 0
		if(pxEndptInfo->pxActiveCall != NULL){//SS: Why???
			pxEndptInfo->uiDTkCallId = pxEndptInfo->pxActiveCall->uiDTkCallId; 
#endif
  }

  if(IFX_DECT_INVALID_TONE != ucSignal)
  {
    IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,ucSignal);

    if(ucSignal == IFX_DECT_BUSY_TONE){
      /*Move to busy but resume dialing state for 2.0 HS if held call is not NULL*/
      IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
      IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,   
                             IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId);
    }
  }
  return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingPPOnHookHdlr
 *  Description     : This routine handles ON HOOK event in dialing state. Make 
 *                    DECT endpoint idle. Send auto redial notify if someone 
 *                    requested.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	 : 
 *  Return Value    : Always returns IFX_SUCCESS 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingPPOnHookHdlr(  
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DECT_MakeDectPPIdle(pxEndptInfo); //This releases all calls
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingHookFlashHdlr 
 *  Description     : This routine handles Hook Flash event in dialing state.
 *	                  This event is ignored if a emergency call is active or 
 *	                  resume, transfer or conference is  initiated. If event is 
 *	                  accepted following actions are taken.
 *	                  - If call is initiated then release the call and play dial
 *	                    tone, so that user initiated new call.
 *	                  - else if there are held call, resume last held call.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If event is accepted returns IFX_SUCCESS, otherwise 
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 *  Cati2.0         : This function may not used.
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingHookFlashHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxHeldCall = 0;
	e_IFX_Return eRet = IFX_FAILURE;

	*peReason = IFX_MAX_REASON;

	IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);

	if( pxEndptInfo->uiToneTimerId )
	{
		IFX_DECT_StopTone(pxEndptInfo,0);//
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
	}

	if( pxHeldCall  &&
			! IFX_DECT_CheckEndptFlag(pxEndptInfo, 
					(IFX_DECT_F_EMG_CALL_PROCEDING | IFX_DECT_F_RESUME_INITIATED | 
					IFX_DECT_F_TRANSFER_INITIATED | IFX_DECT_F_CONFERENCE_INITIATED) ) )
	{
		if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED) )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Releasing Active Call" );

			IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_TERMINATED,
				         NULL, NULL, peReason);
			IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
      memset(pxEndptInfo->szDialledDigits,0,IFX_MAX_DIGITS);
			pxEndptInfo->pxActiveCall = pxHeldCall;
			IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_DIAL_TONE);//ASK: wat case is dis???

			IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_DialTimerExpired,
											IFX_DECT_DIAL_TONE_TIMER,  &pxEndptInfo->uiIntrDgtTimerId);
			eRet = IFX_SUCCESS;
		}
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Resuming Last Held Call" );

			eRet =  IFX_DECT_CallResume(pxEndptInfo, pxEndptInfo->pxActiveCall);
		}
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingDigitPressedHdlr 
 *  Description     : This function handles Digit Pressed event in dialing state
 *	                  If call is initiated, digits are ignored. 
 *	                  Add new digits to end of previously pressed digits and run 
 *	                  dial plan. If dial plan fails, move to busy state else wait
 *	                  for next digit.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If event is processed returns IFX_SUCCESS, otherwise
 *	                  returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingDigitPressedHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_DigitInfo* pxDigitEvt = (&pxEvtInfo->uxEventData.xDigitEvt);
	x_IFX_DP_Rule xDpRule;
	e_IFX_Return eRet;
	char8 szDialOut[IFX_MAX_DIGITS];
	uchar8 ucDpAction;
	uint16 unTimeOut;
	
	*peReason = IFX_MAX_REASON;
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED ) )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Can not process Digit Event" );
		return IFX_FAILURE;
	}
	
	if( pxEndptInfo->uiToneTimerId )
	{
		IFX_DECT_StopTone( pxEndptInfo,pxEndptInfo->uiDTkCallId);
		IFX_TIM_TimerStop( pxEndptInfo->uiToneTimerId );
	}
	
	if( pxEndptInfo->uiIntrDgtTimerId )
		IFX_TIM_TimerStop( pxEndptInfo->uiIntrDgtTimerId );

	pxEndptInfo->uiToneTimerId = pxEndptInfo->uiIntrDgtTimerId = 0;

	strcat(pxEndptInfo->szDialledDigits, pxDigitEvt->szDigits);

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Digits given to DP" );

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->uiDTkCallId); 
	eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
						IFX_FALSE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );
	/* 
	 * In this handler, only small/large actions are relevant. For other action
	 * disconnect call.
	 */
	if( IFX_SUCCESS == eRet && (IFX_DP_ST_SMALL_TIM == ucDpAction || 
							 IFX_DP_ST_LARGE_TIM == ucDpAction) )
	{

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "Before Timer DTK Call Handle",pxEndptInfo->uiDTkCallId); 
		IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_InterDigitTimerExpired,
							   unTimeOut, &pxEndptInfo->uiIntrDgtTimerId);
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "After Timer DTK Call Handle",pxEndptInfo->uiDTkCallId); 
	} 
	else
	{
		/* Dial plan error */
		IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_BUSY_TONE);
		IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
		IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_BCETimerExpired, 
										IFX_DECT_BUSY_TONE_TIMER, &pxEndptInfo->uiBCETimerId);
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingSSMsgHdlr 
 *  Description     : This routine handles suplimentary service message in 
 *	                  dialing state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : 
 *  Notes           : This routine is not invoked.
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingSSMsgHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
		     pxEndptInfo->szEndptId);

	switch( pxSsMsg->eSSType )
	{
    
    case IFX_DECT_SS_ATX:
      {
	    	x_IFX_DECT_CallInfo* pxHeldCall = 0;
        IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		    if( pxEndptInfo->pxActiveCall != pxHeldCall ) {
				  /* Possible only if service change is triggered after trasfer target answers calls */
        	IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_ATX_PENDING);
				} 

        break;
      }
    
		case IFX_DECT_SS_RESUME:
			{
				//Resume call
				return IFX_DECT_CallResume(pxEndptInfo, pxEndptInfo->pxActiveCall);
			}
		case IFX_DECT_SS_RELEASE:
     {
				x_IFX_DECT_CallInfo* pxRelCall;
  			IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxRelCall);
	      if(pxRelCall){
	        IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, NULL,
	               NULL, peReason);

	      	IFX_DECT_ResetCall(pxRelCall,0);
					if(pxEndptInfo->pxActiveCall == pxRelCall)
					{
						IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxEndptInfo->pxActiveCall);
					}

					if(pxEndptInfo->pxActiveCall == NULL)
						IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	      } else {
					//PP initiated call..but not dialed out
				  if(pxEndptInfo->pxActiveCall != NULL)	
          {
						if(pxEndptInfo->uiIntrDgtTimerId)
            {
							IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
							pxEndptInfo->uiIntrDgtTimerId = 0;
            }
					}
					else //There are no calls
						IFX_DECT_MakeDectPPIdle(pxEndptInfo);
				}

				break;
		 }
		default:
			{
				IFX_DBGA(vucDectAgnetModId, 
						IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId, 
						"Can Not Handle This Supplementary Service Now");
			}
	}//switch
	
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingDialTimerExpHdlr
 *  Description     : This routne handles Dial timer expiry event in dialing 
 *	                  state
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If timer id is valid returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingDialTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId);

 /* if timer id did not match, ignore the event */
	if( pxEvtInfo->uiId != pxEndptInfo->uiToneTimerId )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Wrong Timer Id");
		return IFX_FAILURE;
	}

	pxEndptInfo->uiToneTimerId = 0;

  /* Stop Tone */
	IFX_DECT_StopTone(pxEndptInfo,pxEndptInfo->uiDTkCallId);	

	IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_BUSY_TONE);
	IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);	
	IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_BCETimerExpired, 
	        							 IFX_DECT_BUSY_TONE_TIMER, &pxEndptInfo->uiBCETimerId);

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingInterDigitTimerExpHdlr
 *  Description     : This function handles Inter digit timer expiry event in
 *	                  dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If event is processed returns IFX_SUCCESS, otherwise
 *	                  returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingInterDigitTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DP_Rule xDpRule;
	char8  szDialOut[IFX_MAX_DIGITS];
	uchar8 ucDpAction = 0;
	uint16 unTimeOut = 0;
	e_IFX_DECT_States eState;
	e_IFX_Return eRet;
  uchar8 ucDefaultLineId = 0;
  uchar8 ucLineId = 0;
	e_IFX_ReasonCode eReason;
  char8 aucPrefix[32] = "";

	uchar8 ucSignal = IFX_DECT_INVALID_TONE; 
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				   "Entry");

 /* if timer id did not match, ignore the event */
	if( pxEvtInfo->uiId != pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Wrong Timer Id");
		return IFX_FAILURE;
	}

		
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_DTMF_CM_STRING_TEST,
			pxEndptInfo->szEndptId,  "Dialed Digits", pxEndptInfo->szDialledDigits);
  
  if(pxEndptInfo->szDialledDigits != NULL)
  {
    if((strlen(pxEndptInfo->szDialledDigits) ==1)&&((atoi(pxEndptInfo->szDialledDigits)>0)&&(atoi(pxEndptInfo->szDialledDigits)<7))){
      printf("Digit is %d",atoi(pxEndptInfo->szDialledDigits));
      IFX_DECT_GetEndptName(atoi(pxEndptInfo->szDialledDigits), pxEndptInfo->szDialledDigits);
    }else{
      uchar8 ucIsInternal = 0;                                                                                                                                               
      if(IFX_SUCCESS == IFX_DP_RulePrefixGet(IFX_DP_EXTENSION_DIAL,aucPrefix)){
        printf("\n aucPrefix=%s\n",aucPrefix);
        if(!strncmp(pxEndptInfo->szDialledDigits,aucPrefix,strlen(aucPrefix))){
         printf("\n Internal Number\n");
         ucIsInternal = 1; 
        }
      }
                                                                                                                                                                      
      if(!ucIsInternal){                  
	     if(IFX_SUCCESS != IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, &ucDefaultLineId, &eReason)){
        return IFX_FAILURE;
       }
       IFX_DECT_EndpointLineIdGet(pxEndptInfo,&ucLineId);                                                                                                                  
       printf("\n ucLineId = %d\n",ucLineId);
	     if((ucDefaultLineId == IFX_PSTN_LINE)&&(ucLineId == IFX_PSTN_LINE || ucLineId == 0)){
           
        memset(aucPrefix,0,sizeof(aucPrefix));
        if(IFX_SUCCESS == IFX_DP_RulePrefixGet(IFX_DP_LOCAL_PSTN_CALLS,aucPrefix)){
         memmove(&pxEndptInfo->szDialledDigits[strlen(aucPrefix)],pxEndptInfo->szDialledDigits,strlen(pxEndptInfo->szDialledDigits));
		     memcpy(pxEndptInfo->szDialledDigits,aucPrefix,strlen(aucPrefix));
        }else{
          return IFX_FAILURE;
         } 
		     printf("\nPSTN Line Dial Plan Digits: %s \n", pxEndptInfo->szDialledDigits);
	     }	
      }
     }
  }
  strcpy(pxEndptInfo->szCallerNumber,pxEndptInfo->szDialledDigits);
	pxEndptInfo->uiIntrDgtTimerId = 0;
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->uiDTkCallId); 
 	eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
		             IFX_TRUE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );
	if((pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)&&((xDpRule.eAction==IFX_DP_BLIND_TX)||
			/*(xDpRule.eAction==IFX_DP_PSTN_HOOKFLASH)||*/(xDpRule.eAction==IFX_DP_CALLWAITING_REJECT)||
			((xDpRule.eAction>=IFX_DP_DISCONNECT_LASTACTV_CALLL)&&(xDpRule.eAction<=IFX_DP_CONFERENCE))))
	{

     /*Dial plan error */  
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Not allowed for 2.0 handset" );
		eRet = IFX_FAILURE;
	}
	else if( eRet == IFX_SUCCESS && IFX_DP_DIALOUT == ucDpAction )
	{
	  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->uiDTkCallId); 
		eRet = IFX_DECT_ExecuteDialPlan(pxEndptInfo, xDpRule.eAction, szDialOut, 
										&ucSignal, &eState);
	}
	else
	{
     /*Dial plan error */  
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Dial Plan Mismatch" );
		eRet = IFX_FAILURE;
	}
 
	/* Clear all collected digits */
  if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) )
    memset(pxEndptInfo->szDialledDigits,0,IFX_MAX_DIGITS);

	if( IFX_FAILURE == eRet )	
	{
    //x_IFX_DECT_CallInfo *pxHeldCall;
		eState = IFX_DECT_STATE_BUSY;
		ucSignal = IFX_DECT_BUSY_TONE;
#if 0 //ASK: When Does this occur?
    IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
    if(pxHeldCall == NULL) {
		  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						   pxEndptInfo->szEndptId, "Sending Release" );
	    IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,NULL,IFX_DECT_RELEASE_NORMAL);
    }
#endif
	}

	if( IFX_DECT_INVALID_TONE != ucSignal )
		IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,ucSignal);

	if( IFX_DECT_STATE_MAX != eState ){

		IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
		if( IFX_DECT_STATE_BUSY == eState )
			IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,
											       IFX_DECT_BUSY_TONE_TIMER, &pxEndptInfo->uiBCETimerId);
	}
	return IFX_SUCCESS;	
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingCallReleaseHdlr
 *  Description     : This routine handles peer call release event(from CM) in 
 *	                  dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If released call's call-id is valid, IFX_SUCCESS is 
 *	                  retunred, else IFX_FAILURE is retunred.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingCallReleaseHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxRelCall;
	x_IFX_DECT_CallInfo* pxHeldCall;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId);
  /*if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS) ){
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS);
		return IFX_SUCCESS;
	}*/

	if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_ATX_PENDING)){
    /* To reset call IDs of both the calls wen ATX is pending, reset the flag */
    IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_IGNORE_ATXSTATUS);
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
		return IFX_SUCCESS;
	}
	IFX_DECT_GetCallInfo(pxEndptInfo, pxEvtInfo->uiId, &pxRelCall);
  IFX_DECT_GetLastHeldCall(pxEndptInfo,&pxHeldCall);

	if((0 == pxRelCall)||(!(pxRelCall == pxEndptInfo->pxActiveCall || pxRelCall == pxHeldCall))){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Wrong Call Id" );
		return IFX_FAILURE;
	}

	if(pxEndptInfo->uiToneTimerId) //Stop Ringback Tone
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		pxEndptInfo->uiToneTimerId = 0;
	}
	IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);

  if(pxRelCall == pxEndptInfo->pxActiveCall)
		IFX_DECT_ResetEndptFlag(pxEndptInfo, 
            								(IFX_DECT_F_CALL_INITIATED | IFX_DECT_F_RESUME_INITIATED) );
#ifndef TONES
  pxRelCall->eState = IFX_DECT_CS_BUSYSTATE;
  if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) )
	IFX_DECT_PlayTone(pxEndptInfo,pxRelCall->uiDTkCallId,(pxEndptInfo->eState == IFX_DECT_STATE_DIALING)?
                      IFX_DECT_OFF_HOOK_TONE:IFX_DECT_BUSY_TONE); 

  /*Move to busy but resume dialing state for 2.0 HS if held call is not NULL*/
  IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
  IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_BCETimerExpired,
		       							 IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId);
	printf("TimerId---%d\n",pxEndptInfo->uiBCETimerId); 
#if 0
    if(pxHeldCall != NULL){
      pxEndptInfo->uiDTkCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;
    }
#endif 
#endif
  return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingRmtAcceptHdlr
 *  Description     : This routine handles remote party call accept event in 
 *	                  dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call id is valid, IFX_SUCCESS is retunred, otherwise 
 *	                  IFX_FAILURE is returned. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingRmtAcceptHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	x_IFX_DECT_CSU_CallParams xCallParams = {0};

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId);

	if( pxActCall->uiCallId != pxEvtInfo->uiId /* ||
			IFX_DECT_CS_INITIATED != pxEndptInfo->eState */ )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"FAILED: RmtAccept On Wrong Call");
		return IFX_FAILURE;
	}

	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED);
  IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_RINGBACK_TONE);

  if((pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)&&
     (pxEndptInfo->pxActiveCall->eCallType != IFX_CMGR_TYPE_EXTN)){
    //Populate Line Id.
    printf("\n pxActCall->ucLineId = %d\n",pxActCall->ucLineId);
	  xCallParams.ucLineId = pxActCall->ucLineId;//CHECK
  }	
	IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_RingbackTimerExpired, 
									IFX_RINGBACK_TONE_DURATION, &pxEndptInfo->uiToneTimerId );
  xCallParams.bIsPresentation =1;
	/* Inform the toolkit */
	IFX_DECT_CSU_CallAccept(
	 pxActCall->uiDTkCallId,
	 &xCallParams);
	IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_RINGING);
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_RINGBACK);

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingRmtAnswerHdlr
 *  Description     : This routine handles remote party call answer event in
 *	                  dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call id is valid, IFX_SUCCESS is retunred, otherwise 
 *	                  IFX_FAILURE is returned. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingRmtAnswerHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId);

	if( pxEndptInfo->pxActiveCall->uiCallId != pxEvtInfo->uiId /* ||
			 WRONG** ( IFX_DECT_CS_INITIATED != pxEndptInfo->eState && 
			  IFX_DECT_CS_RINGING != pxEndptInfo->eState   ) */ )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"FAILED: Rmt Answer On Wrong Call");
		return IFX_FAILURE;
	}

	if( pxEndptInfo->uiToneTimerId ) //CHECK: Is any tone timer running?
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		pxEndptInfo->uiToneTimerId = 0;
	}

	return IFX_DECT_RemotePartyAnswered(pxEndptInfo);
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_EventNotHandledHdlr
 *  Description     : This rouitne is used in all FSM state. This routine is 
 *	                  invoked for events that are not mandatory or not required
 *	                  in this version.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_EventNotHandledHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingResumeRespHdlr
 *  Description     : This routine handles call resume response in dialing state
 *	                  If resume is success it moves FSM to active state, else 
 *	                  plays an error tone and goes to busy state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details.
 *  Output Values	  : 
 *  Return Value    : If call id is valid and call resume intiated, then 
 *	                  IFX_SUCCESS is returned, else IFX_FAILURE is returned.
 *  Notes           :
 *  CatIq2.0        : Send Resume Status to Toolkit
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingResumeRespHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	x_IFX_DECT_CSU_CallParams xCallParams={0};
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																					pxEndptInfo->szEndptId);
	if( pxActCall->uiCallId != pxEvtInfo->uiId ||
			IFX_DECT_CS_RESUME_INITIATED != pxActCall->eState )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"FAILED: Resume On Wrong Call");
		return IFX_FAILURE;
	}

	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_RESUME_INITIATED);
	if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
	{
		IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_ACTIVE);
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	  if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) ){
      IFX_DECT_CSU_CallToggleAck(pxActCall->uiDTkCallId,pxEndptInfo->uiDTkCallId,&xCallParams,IFX_SUCCESS);
	    IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
		}	
    else
    {
      IFX_DECT_CSU_CallResumeAck(pxActCall->uiDTkCallId, 
                                   &xCallParams,IFX_SUCCESS);
    }
		if( pxEndptInfo->eRunningCodec != pxActCall->eNegCodec)
		{
			x_IFX_DECT_CSU_CallParams xCallParams = {0};
      xCallParams.bwideband =
          IFX_DECT_IsWidebandCodec(pxActCall->eNegCodec);
			//Change codec on air interface (i.e. DECT side)
			IFX_DECT_CSU_ServiceChange(
			pxActCall->uiDTkCallId, 
			&xCallParams,
			IFX_DECT_CSU_SC_REQUEST);
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
      return IFX_SUCCESS;
		}
	}
	else
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"FAILED: Could Not Resume Call");
		//TODO: Need to play error tone or play dial tone, start dial tone timer 
		// ...like FXS??
	  if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) ){
      IFX_DECT_CSU_CallToggleAck(pxActCall->uiDTkCallId,pxEndptInfo->uiDTkCallId,&xCallParams,
	         (IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus)?IFX_SUCCESS:IFX_FAILURE);
	    IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
		}	
    else
      IFX_DECT_CSU_CallResumeAck(pxActCall->uiDTkCallId, &xCallParams,
	         (IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus)?IFX_SUCCESS:IFX_FAILURE);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingBtxRespHdlr
 *  Description     : This routine handles Btx Resp from CM in dialing state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingBtxRespHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	if( !(IFX_DECT_CheckEndptFlag(pxEndptInfo,  IFX_DECT_F_TRANSFER_INITIATED)))
  {
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId,"Blind Transfer Not Initiated");
    return IFX_FAILURE;
  }
	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TRANSFER_INITIATED);

  if( IFX_CMGR_TRANSFER_ACCEPTED == pxEvtInfo->uxEventData.eTxStatus ||
      IFX_CMGR_TRANSFER_PENDING == pxEvtInfo->uxEventData.eTxStatus ||
      IFX_CMGR_TRANSFER_PROCEEDING == pxEvtInfo->uxEventData.eTxStatus ||
      IFX_CMGR_TRANSFER_RINGING == pxEvtInfo->uxEventData.eTxStatus  )
  {
    /* Transfer is still going on */
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId, "Blind Transfer Is In Progress");
    return IFX_SUCCESS;
  }
  else if( IFX_CMGR_TRANSFER_ANSWERED == pxEvtInfo->uxEventData.eTxStatus )
  {
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId, "Blind Transfer SUCCESS");
  }
  else
  {
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndptId, "Blind Transfer Failed");
    IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_BUSY_TONE);
	  IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_BUSY);
		IFX_DECT_UpdateCallState(pxEndptInfo, pxEndptInfo->pxActiveCall, 
								 																					IFX_DECT_CS_HELD);
	  IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired, 
									       IFX_DECT_BUSY_TONE_TIMER, &pxEndptInfo->uiBCETimerId);
  }
  return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveConfStatusHdlr
 *  Description     : This routine handles conference status in Active state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveConfStatusHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CSU_CallParams xCallParams = {0};
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Call Handle =", pxEndptInfo->pxActiveCall->uiDTkCallId);
		if(pxEndptInfo->pxActiveCall->eNegCodec != pxEndptInfo->eRunningCodec){
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId, "Calling IFX_DECT_CSU_ServiceChange");
    	xCallParams.bwideband = IFX_DECT_IsWidebandCodec(pxEndptInfo->pxActiveCall->eNegCodec);
			IFX_DECT_CSU_ServiceChange(
					pxEndptInfo->pxActiveCall->uiDTkCallId,
					&xCallParams,
					IFX_DECT_CSU_SC_REQUEST);
					IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
		}
	//pxEndptInfo->eRunningCodec = pxEndptInfo->pxActiveCall->eNegCodec;
	return IFX_SUCCESS;
}



/*******************************************************************************
 *  Function Name   : IFX_DECT_DialingConfStatusHdlr
 *  Description     : This routine handles conference status in dialing state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If conference was initiated, then IFX_SUCCESS is returned,
 *	                  otherwise IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_DialingConfStatusHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
    uint32 uiSrcDtkCallId =0;
		uint32 uiHeldDtkCallId =0;
    int32 i=0;
    x_IFX_DECT_EndptFsmInfo* pxIntrudeEndPtInfo;

    for(i=0;i<IFX_MAX_DECT_CALLS;i++) {
      if(IFX_DECT_CS_ACTIVE == pxEndptInfo->axCallInfo[i].eState)
	    {
	      uiSrcDtkCallId = pxEndptInfo->axCallInfo[i].uiDTkCallId; 
	      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Source Call Handle =", uiSrcDtkCallId);
	    }else{
	      uiHeldDtkCallId = pxEndptInfo->axCallInfo[i].uiDTkCallId; 
	      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Held Call Handle =", uiHeldDtkCallId);
			}	
    }
	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_CONFERENCE_INITIATED))
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"!! Conference Not Initated !!");
		return IFX_FAILURE;
	}

	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CONFERENCE_INITIATED);

	if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus)
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"Conference Success");
       /* For GAP handsets DTKCallID will be same and conf ack need not be sent*/
       if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){ 
					if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTRUDE_INIT)){
          	IFX_DECT_GetEndptInfoById(pxEndptInfo->szDialledDigits, &pxIntrudeEndPtInfo);
						if( pxIntrudeEndPtInfo != NULL && pxIntrudeEndPtInfo->uiInterceptTimerId )
							{
								IFX_TIM_TimerStop(pxIntrudeEndPtInfo->uiInterceptTimerId);
								pxIntrudeEndPtInfo->uiInterceptTimerId = 0;
							}
						uiSrcDtkCallId = pxIntrudeEndPtInfo->uiDTkCallId;
          	IFX_DECT_CSU_CallIntrusionAck(uiSrcDtkCallId,
																					uiHeldDtkCallId,
							        					          IFX_SUCCESS);
					}else{
          	IFX_DECT_CSU_CallConferenceAck(uiHeldDtkCallId,
				    					                     uiSrcDtkCallId,
							        					           NULL, IFX_SUCCESS);
					}
       }
		IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+0), 
										IFX_DECT_CS_ACTIVE);
		IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+1), 
      									IFX_DECT_CS_ACTIVE);
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_CONFERENCE);
	}
	else
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId,"!! Conference Failed !!");
		IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_BUSY_TONE);
    pxEndptInfo->pxActiveCall = NULL;/*This will help release both calls for GAP*/
		IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
		IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired, 
									         IFX_DECT_BUSY_TONE_TIMER, &pxEndptInfo->uiBCETimerId);
	}
#if 0 /*2.0 Hs will nt come in this api*/
  if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){ 
    IFX_DECT_CSU_CallConferenceAck(pxEndptInfo->axCallInfo[0].uiDTkCallId,
	     pxEndptInfo->axCallInfo[1].uiDTkCallId,NULL,
	   (IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus)?IFX_SUCCESS:IFX_FAILURE);
  }
#endif
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RingbackPPOnHookHdlr
 *  Description     : This function handles ON-HOOK event in ringback state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RingbackPPOnHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RingbackPPHookFlashHdlr 
 *  Description     : This routine handles HOOK FLASH event in ringback state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RingbackPPHookFlashHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	//TODO: Need to handle it like FXS??
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_RingbackSSMsgHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
  e_IFX_Return eRet;
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
										pxEndptInfo->szEndptId);

	switch( pxSsMsg->eSSType )
	{
    case IFX_DECT_SS_ATX:
      {
	    	x_IFX_DECT_CallInfo* pxHeldCall = 0;
		    e_IFX_ReasonCode eReason = IFX_MAX_REASON;
        char8 aszEndptId[IFX_MMGR_MAX_DECT_CHANNELS][IFX_MAX_ENDPOINTID_LEN];
        uchar8 ucIndex = 0,ucNumForkEndpts = 0;

        IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		    if( pxHeldCall ) {
					IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_ATX_PENDING);
				}else{
						return IFX_FAILURE;
				}
       /* Changes for Call Reinjection */
       memset(&aszEndptId[0][0],0,IFX_MMGR_MAX_DECT_CHANNELS*IFX_MAX_ENDPOINTID_LEN);

       /* Determine the endpoints in the forked Call as well as remote extn for first call(there is 
          no way to distinguish between the two) */ 
       /*if(IFX_SUCCESS != IFX_DECTAPP_PeerHandsetIdsGet(pxEndptInfo,aszEndptId,&ucNumForkEndpts)){
         return IFX_FAILURE;
       }*/
				eRet=IFX_DECTAPP_PeerHandsetIdsGet(pxEndptInfo,aszEndptId,&ucNumForkEndpts);
				if(eRet==IFX_SUCCESS){
       		if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS)){

          	x_IFX_DECT_CSU_CallParams xCallParams = {0};
          	for(ucIndex = 0; ucIndex < ucNumForkEndpts; ucIndex++){

	         	xCallParams.ucPeerHandsetId = IFX_DECT_HsIdFromEPName(aszEndptId[ucIndex]);
           	xCallParams.uiFlag = 0x0C;

			     	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
					          "bIsAllCallsReleased ", xCallParams.bIsAllCallsReleased);
           	IFX_DECT_CSU_CallTransferAck(pxHeldCall->uiDTkCallId,
                                        pxEndptInfo->pxActiveCall->uiDTkCallId,
                                        &xCallParams,IFX_SUCCESS);
          	}
          /* Save the held call remote extn HS Id in pxEndptInfo->szCallerNumber because no other 
             alerting HS has as yet answered the call */
          	if(xCallParams.ucPeerHandsetId){
           		IFX_DECT_GetEndptName(xCallParams.ucPeerHandsetId,pxEndptInfo->szCallerNumber);
			     		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
					          "Save Held call remote HS Id in pxEndptInfo ",xCallParams.ucPeerHandsetId);
          	} 
          	IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_IGNORE_ATXSTATUS);
       		}
       /* Save the AtxCnxt to access it from the CurrentCnxt in case of premature release
          (release from one of the alerting HS or from remote party of held call) */
			 		IFX_CMGR_SetAtxCnxt(pxHeldCall->uiCallId, pxEndptInfo->pxActiveCall->uiCallId, &eReason );
				}else{
       		if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS)){
          	x_IFX_DECT_CSU_CallParams xCallParams = {0};
          	IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_IGNORE_ATXSTATUS);
    				IFX_DECT_CSU_CallRelease( pxHeldCall->uiDTkCallId,
                											&xCallParams, 
                											IFX_DECT_RELEASE_NORMAL);
  
						IFX_DECT_CSU_CallRelease( pxEndptInfo->pxActiveCall->uiDTkCallId,
                											&xCallParams, 
                											IFX_DECT_RELEASE_NORMAL); 
					}
       		/* Save the AtxCnxt to access it from the CurrentCnxt in case of premature release
          	(release from one of the alerting HS or from remote party of held call) */
			 		IFX_CMGR_SetAtxCnxt(pxHeldCall->uiCallId, pxEndptInfo->pxActiveCall->uiCallId, &eReason );
				}
				break;
			}
    case IFX_DECT_SS_RELEASE:
      {
				x_IFX_DECT_CallInfo* pxRelCall;
  			IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxRelCall);
	      if(pxRelCall) {
	        IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, NULL,
	               NULL, peReason);

          if(pxEndptInfo->uiToneTimerId){
					 IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
					 pxEndptInfo->uiToneTimerId = 0;
          }
          IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);

	      	IFX_DECT_ResetCall(pxRelCall,0);
					if(pxEndptInfo->pxActiveCall == pxRelCall)
					{
						IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxEndptInfo->pxActiveCall);
					}


					if(pxEndptInfo->pxActiveCall != NULL) { 
						IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
          }
          else {
						IFX_DECT_MakeDectPPIdle(pxEndptInfo);
          }
	      } 
				break;
			}
		default:
			{
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Unexpected Supplementary Request");
			}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RingbackRbTimerExpHdlr 
 *  Description     : This routine handles ringback timer expiry event in 
 *	                  ringback state. Since peer did not answer the call, so
 *	                  terminate call and move to busy state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If timer id is valid, then IFX_SUCCESS is returned, else
 *	                  IFX_FAILURE is returned. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RingbackRbTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
  //x_IFX_DECT_CallInfo *pxHeldCall = NULL;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	if( pxEndptInfo->uiToneTimerId != pxEvtInfo->uiId)
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Wrong Timer Id");
		return IFX_FAILURE;
	}  
	pxEndptInfo->uiToneTimerId = 0;

	IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_ENDPOINT_BUSY,
					       NULL, NULL, peReason);

	/*TODO since we decided not to play tone and then release the connection
	      if we need this feature , than copy the activcall-DTKCallId */
 
	IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiCallId,IFX_DECT_BUSY_TONE);

  pxEndptInfo->pxActiveCall->eState = IFX_DECT_CS_BUSYSTATE;
  /*Move to busy but resume dialing state for 2.0 HS if held call is not NULL*/
	IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);	
	IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired, 
		          					IFX_DECT_ERROR_TONE_TIMER, &pxEndptInfo->uiBCETimerId);
    
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_RingbackRmtAcceptHdlr
 *  Description     : This routine handles remote accept event in ringback state 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RingbackRmtAcceptHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingPPoffHookHdlr 
 *  Description     : This routine handles OFF-HOOK event in alerting state.
 *	                   Handles CC_CONNECT (treated as PP_OffHook event) event. 
 *                      - Cancel ring and ring pause timers
 *                      - If auto redialing flag is set, initiate a call to 
 *	                      last dialed number. If call is initiated successfuly, 
 *	                      move to ringback state if remote party accepted call, 
 *	                      else move to dialing state.
 *	                    - If page call flag is set, send release to PP and go 
 *	                      back to idle state.
 *	                    - If it is normal call, then inform remote party about 
 *                        call answer, enable dect voice, and move to active 
 *                        state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingPPoffHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	uchar8 ucSignal = IFX_DECT_INVALID_TONE;
	e_IFX_DECT_States eState = IFX_DECT_STATE_BUSY;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	//x_IFX_DECT_CSU_CallParams xCallParams={0};
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	/* Stop ring and ringpause timers */
	if(pxEndptInfo->uiToneTimerId) {
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
	}
	if(pxEndptInfo->uiRingPauseTimerId) {
		IFX_TIM_TimerStop(pxEndptInfo->uiRingPauseTimerId);
	}
	pxEndptInfo->uiRingPauseTimerId = pxEndptInfo->uiToneTimerId = 0;
 /*Added this check for D&A tests to pass for interception*/
	if(!IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_INIT)){
		/*Sending stop tones for Arendi reported issue.*/
		IFX_DECT_StopTone(pxEndptInfo,(pxEndptInfo->pxActiveCall!=NULL)?pxEndptInfo->pxActiveCall->uiDTkCallId:0);
	}
	if(pxEndptInfo->pxActiveCall!=NULL){
		//xCallParams.uiSignal=IFX_DECT_SIGNAL_AlertOff;
	 /*	IFX_DECT_CSU_InfoReceived(
        pxEndptInfo->pxActiveCall->uiDTkCallId,
				&xCallParams);*/
	}

#if 0 /* This case shall not occur*/	
	if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL))
	{
	  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
		return IFX_SUCCESS;
	}
#endif

	if( IFX_DECT_CheckEndptFlag(
													pxEndptInfo, IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS) )
	{
		/* Initiate call */	
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Auto Redial In Progress. Redialing");
		
		if( IFX_DECTNG_CODEC_G722_64 == pxEvtInfo->uxEventData.aunCodec[0] )
			pxEndptInfo->eRunningCodec = IFX_MMGR_CODEC_G722_64;
		else if( IFX_MMGR_CODEC_NONE == pxEndptInfo->eRunningCodec )
			pxEndptInfo->eRunningCodec = IFX_MMGR_CODEC_G726_32;

		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS);
		e_IFX_Return eRet;
		eRet = IFX_DECT_InitiateCall(pxEndptInfo, &pxEndptInfo->xLastDialedAddr,
							IFX_CMGR_DONT_CARE, IFX_FALSE, &eStatus, peReason);

		/* IFX_CMGR_STATUS_SUCCESS == eStatus is not expected here 
			 ...b'coz its voip call */
		if( IFX_SUCCESS == eRet && IFX_CMGR_STATUS_PENDING == eStatus )
		{
			eState = IFX_DECT_STATE_DIALING;
			pxEndptInfo->pxActiveCall->eNegCodec = pxEndptInfo->eRunningCodec;
			IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_CALL_INITIATED );
		} 
		else //if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_FAIL == eStatus )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Call Initiate Failed");
			eState = IFX_DECT_STATE_BUSY;	
			ucSignal = 
				(IFX_ENDPOINT_BUSY == *peReason)?IFX_DECT_BUSY_TONE:IFX_DECT_ERROR_TONE;
		}	
	}
	else //normal call
	{
		/* 
		 * Call is initiated from remote party. Answer call and move to active 
		 * state 
		 */
		x_IFX_MMGR_CodecInfo xMmgrCodec = {IFX_MMGR_CODEC_NONE};

		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
	         pxEndptInfo->szEndptId, "Incomoing Call Answered...");

		if( IFX_DECTNG_CODEC_G722_64 == pxEvtInfo->uxEventData.aunCodec[0]  )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Codec For This Call=IFX_MMGR_CODEC_G722_64");
			pxEndptInfo->eRunningCodec = 
									xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G722_64 ;
		}
		else if( pxEndptInfo->pxActiveCall != NULL && IFX_DECTNG_CODEC_G722_64 == pxEndptInfo->pxActiveCall->eNegCodec )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Codec For This Call=IFX_MMGR_CODEC_G726_32");
			pxEndptInfo->pxActiveCall->eNegCodec =
												pxEndptInfo->eRunningCodec = 
														xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G726_32;
		}
		else
		{
			//If codec is not sent by PP use G.726 
			if(pxEndptInfo->pxActiveCall != NULL && IFX_MMGR_CODEC_NONE == pxEndptInfo->pxActiveCall->eNegCodec )
			{
				pxEndptInfo->eRunningCodec = xMmgrCodec.eCodecType = IFX_MMGR_CODEC_G726_32;
			}
			else
			{
				pxEndptInfo->eRunningCodec = 
								xMmgrCodec.eCodecType = pxEndptInfo->pxActiveCall->eNegCodec;
			}
		}

		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
						"Coder Selected for the call (mmgr)= ", pxEndptInfo->eRunningCodec);
		if( IFX_MMGR_SUCCESS != 
							IFX_MMGR_DectResActivate(pxEndptInfo->szEndptId, &xMmgrCodec,
																			 (pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_ECHO_TCL_55)?0:1) )
		{
			//Configure codec on DECT Channel failed
			pxEndptInfo->eRunningCodec = 0;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
		}
		else
		{
			x_IFX_DECT_CSU_CallParams xCallParams = {0};
			if(pxEndptInfo->pxActiveCall != NULL)
			IFX_DECT_CSU_VoiceModify(
			pxEndptInfo->pxActiveCall->uiDTkCallId,
	    	    	 	                   &xCallParams,
																	 IFX_DECT_START_VOICE,
																	 pxEndptInfo->unDectChannel);
				pxEndptInfo->pxActiveCall->eNegCodec = pxEndptInfo->eRunningCodec;
			IFX_CMGR_CallAnswer(pxEndptInfo->pxActiveCall->uiCallId,
																								&eStatus, peReason );
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
		}

		if( IFX_CMGR_STATUS_SUCCESS != eStatus )
		{
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "IFX_CMGR_CallAnswer Failed");
			eState = IFX_DECT_STATE_BUSY;
      if(pxEndptInfo->pxActiveCall != NULL)
				pxEndptInfo->pxActiveCall->eState = IFX_DECT_CS_BUSYSTATE;
      ucSignal = IFX_DECT_BUSY_TONE;
		}
		else
		{
			IFX_DECT_UpdateCallState(pxEndptInfo,pxEndptInfo->pxActiveCall,
					IFX_DECT_CS_ACTIVE);
			eState = IFX_DECT_STATE_ACTIVE;
		}
	}

	if(IFX_DECT_INVALID_TONE != ucSignal)
	{

		if(IFX_DECT_STATE_BUSY == eState){
		  IFX_DECT_PlayTone( pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,ucSignal);
      IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,IFX_DECT_ERROR_TONE_TIMER,&pxEndptInfo->uiBCETimerId);
    }
	}
	if(IFX_DECT_STATE_MAX != eState){
		IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingPPonHookHdlr
 *  Description     : This routine handles ON-HOOK event in alerting state. All
 *	                  calls are released and DECT FSM moves to IDLE state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           : Getting release in alerting state is very rare. If there 
 *	                  is a problem establishing call with handset, DECT stack
 *	                  issues FP_RELEASE_IN_CC message to application. So this
 *                    event should be handled in alerting state. 
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingPPonHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{	

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Problem While Making Call To PP" );

	/* 
	 * If paging initiated or auto-redial call is initiated, then there is no call
	 * with CM.
	 */
	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, (IFX_DECT_F_PAGE_CALL | 
																								IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS)) )
	{
    if(pxEndptInfo->pxActiveCall->eState == IFX_DECT_CS_INITIATED){
		  IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, 
																				IFX_ABNORMAL_RELEASE, NULL, NULL, peReason);
    }
    else{
		  IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, 
																				IFX_TERMINATED, NULL, NULL, peReason);
    }
		IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
		pxEndptInfo->pxActiveCall = 0;
	}

	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingAlertRecvHdlr 
 *  Description     : This routine handles alert message from handset. 
 *	 									- Norma call : (initiated from remote)store codec info if 
 *	                  present in alert message, inform call acceptance to CM. 
 *	                  start ring timer and move to RINGING state. 
 *	                  - paging call : start paging timer.
 *	                  - Auto Redial : Store codec info if present. Note that 
 *	                  expiry event for both paging and ring timer are same.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingAlertRecvHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	uint32 unTimer = pxEndptInfo->unRingTimeOut;
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) )	
	{
		unTimer = IFX_DECT_PAGING_TIMER;
	}
	else if( IFX_DECT_CheckEndptFlag(
													pxEndptInfo, IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS) )
	{
		if( IFX_DECTNG_CODEC_G722_64 == pxEvtInfo->uxEventData.aunCodec[0] )
			pxEndptInfo->eRunningCodec = IFX_MMGR_CODEC_G722_64;
		else 
			pxEndptInfo->eRunningCodec = IFX_MMGR_CODEC_G726_32;
	}
	else //normal call
	{
		e_IFX_Return eRet;
		e_IFX_CMGR_Status eStatus;

		if( IFX_DECTNG_CODEC_G726_32 == pxEvtInfo->uxEventData.aunCodec[0] )
		{
			//narrowband call
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Received Narrowband Codec In Alert" );
			pxActCall->eNegCodec = IFX_MMGR_CODEC_G726_32;
		}
		else if( IFX_DECTNG_CODEC_G722_64 == pxEvtInfo->uxEventData.aunCodec[0] )
		{
			//wideband call
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Received Wideband Codec In Alert" );
			pxActCall->eNegCodec = IFX_MMGR_CODEC_G722_64;
		}
#ifdef DEV_DEBUG
		else
		{
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "No Codec Received In Alert Message" );
		}
#endif

		eRet = IFX_CMGR_CallAccept(pxActCall->uiCallId, &eStatus, peReason);
		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_FAIL == eStatus )
		{	
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId,"FAILED : IFX_CMGR_CallAccept");

			IFX_DECT_ResetCall(pxActCall,1);
			pxEndptInfo->pxActiveCall = 0;
			IFX_DECT_MakeDectPPIdle(pxEndptInfo);
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);	
			return IFX_SUCCESS;
		}
		else
		{
			IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_RINGING);
		}
		
		/* Start ringpause timer */ 
		IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_RingpauseTimerExpired,
										IFX_DECT_RINGPAUSE_ON_DURATION, &pxEndptInfo->uiRingPauseTimerId );
	}

	/* Start ring timer */	
	IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_RingTimerExpired,
									unTimer, &pxEndptInfo->uiToneTimerId );

  printf("\n DECT Timer Id = %d\n",pxEndptInfo->uiToneTimerId);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingRejectRecvHdlr 
 *  Description     : This routine handles Reject message from handset in 
 *	                  alerting state. If call initiated by peer, inform CM that
 *	                  call is being rejected by handset. Make DECT endpoint
 *	                  IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingRejectRecvHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
 //x_IFX_DECT_CSU_CallParams xCallParams={0};	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	if( pxEndptInfo->uiRingPauseTimerId )
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingPauseTimerId);
		pxEndptInfo->uiRingPauseTimerId = 0;
	}
	if(pxEndptInfo->pxActiveCall!=NULL){
		//xCallParams.uiSignal=IFX_DECT_SIGNAL_AlertOff;
	 /*	IFX_DECT_CSU_InfoReceived(
        pxEndptInfo->pxActiveCall->uiDTkCallId,
				&xCallParams);*/
	}

	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, 
								(IFX_DECT_F_PAGE_CALL | IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS)) )
	{
		if(pxActCall != NULL)
		IFX_CMGR_CallRelease(pxActCall->uiCallId, IFX_TERMINATED, NULL,
																													NULL, peReason);
		IFX_DECT_ResetCall(pxActCall,0);
		pxEndptInfo->pxActiveCall = 0;
	}
	
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

e_IFX_Return  IFX_DECT_AlertingSSMsgHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
										pxEndptInfo->szEndptId);

  printf("\n Entry\n");
	switch( pxSsMsg->eSSType )
	{

  	case IFX_DECT_SS_ATX:
			{
	    		x_IFX_DECT_CallInfo* pxHeldCall = 0;
					IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
										 pxEndptInfo->szEndptId, "Transfering Calls (UnAnnounced)" );
           IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		      if( pxHeldCall )
		      {
						e_IFX_Return eRet;
						e_IFX_TransferStatus eTfrStatus;
            uint32 uiDtkHeldCallId;
            uint32 uiDtkActiveCallId;

						IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
										 pxEndptInfo->szEndptId, "Transfering Calls (Attended)" );
						IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_TRANSFER_INITIATED);

            uiDtkActiveCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;
						uiDtkHeldCallId = pxHeldCall->uiDTkCallId;
						eRet = IFX_CMGR_AttendedTx(pxHeldCall->uiCallId,
							 pxEndptInfo->pxActiveCall->uiCallId, NULL, &eTfrStatus, peReason );

						if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
							IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
						{
						IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndptId, "Could Not Initiated Attended Transfer" );
						IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
									IFX_TERMINATED, NULL, NULL, peReason);
						IFX_DECT_ResetCall(pxHeldCall,0);
						IFX_DECT_CSU_CallTransferAck(uiDtkHeldCallId,
																				uiDtkActiveCallId,
																		 NULL,IFX_FAILURE);
						//Active call will be released in IFX_DECT_MakeDectPPIdle
									IFX_DECT_MakeDectPPIdle(pxEndptInfo);
						} else if(IFX_CMGR_TRANSFER_PROCEEDING == eTfrStatus) {
									IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);
						} else {
							IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
									pxEndptInfo->szEndptId, "Attended Transfer is successful" );
							IFX_DECT_CSU_CallTransferAck(uiDtkHeldCallId,
																					 uiDtkActiveCallId,
																		 NULL,IFX_SUCCESS);
							IFX_DECT_MakeDectPPIdle(pxEndptInfo);
						}
					} 
					break;
			 }

    case IFX_DECT_SS_RELEASE:
      {
#ifdef DEFLECT_TEST
				x_IFX_DECT_CallInfo* pxDefCall;
				x_IFX_CMGR_AddressInfo xTo;
	  		e_IFX_ReasonCode eReason;
				e_IFX_Return eRet = IFX_SUCCESS;

				FILE *f = fopen("/tmp/number","rb");
  			printf("\nOpened file /tmp/number\n");
  			fseek(f, 0, SEEK_END);
  			long pos = ftell(f);
  			fseek(f, 0, SEEK_SET);

  			char8 *cbBuf = (char8 *)malloc(pos);
  			fread(cbBuf, pos, 1, f);
  			fclose(f);
				uint32 i = 0;
				char8 number[10] = {0};

				while (*cbBuf != 'A'){
					*(number+i) = *cbBuf;
					cbBuf++;
					i++;
				}
				printf("aarif: Number read from file is %s\n\n",number);

				IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxDefCall);
				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                    pxEndptInfo->szEndptId, "Deflect Call");

				if(pxDefCall) {

          printf("\n Valid DefCall, Callid is %d, Lineid is %d\n",pxDefCall->uiCallId,pxDefCall->ucLineId);
					if (strlen(number) == 1){
						xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
			 			strcpy(xTo.uxAddressInfo.szEndptId, number);
          }else{
						xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
						xTo.uxAddressInfo.xVoipAddr.ucAddrType = IFX_EXTN;
						xTo.uxAddressInfo.xVoipAddr.acCalledAddr[0] = 0;
				 		strcpy(xTo.uxAddressInfo.xVoipAddr.acUserName, number);
						xTo.ucLineId = pxDefCall->ucLineId;
					}
						eRet = IFX_CMGR_CallDeflect(pxDefCall->uiCallId, &xTo, &eReason);
					printf("Deflection: eRet is %d \n",eRet);
				}
#else
				x_IFX_DECT_CallInfo* pxRelCall;
  			IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxRelCall);
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Release Call");
	      if(pxRelCall) {
          
          printf("\n Valid RelCall\n");
          if(pxRelCall->eState == IFX_DECT_CS_INITIATED){
            printf("\n Call Release with state CS_INITIATED\n");
		        IFX_CMGR_CallRelease(pxRelCall->uiCallId, 
																				IFX_ABNORMAL_RELEASE, NULL, NULL, peReason);
          }
          else{
            printf("\n Normal Release to CMGR\n");
	          IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, NULL,
	                               NULL, peReason);
          }
	      	IFX_DECT_ResetCall(pxRelCall,0);
					if(pxEndptInfo->pxActiveCall == pxRelCall)
					{
            printf("\n Released Call is Active Call,Make Held Call Active\n");
						IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxEndptInfo->pxActiveCall);
					}

					if(pxEndptInfo->pxActiveCall != NULL) {
						IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
						pxEndptInfo->uiToneTimerId = 0;
						IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
          }
          else {
            printf("\nMake Dect PP Idle\n");
						IFX_DECT_MakeDectPPIdle(pxEndptInfo);
          }
	      } 
#endif
				break;
			}
		case IFX_DECT_SS_CALL_DEFLECT:
			{
				x_IFX_DECT_CallInfo* pxDefCall;
				x_IFX_CMGR_AddressInfo xTo;
	  		e_IFX_ReasonCode eReason;
				e_IFX_Return eRet = IFX_SUCCESS;


				IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxDefCall);
				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                    pxEndptInfo->szEndptId, "Deflect Call");

				if(pxDefCall) {
          printf("\n Valid DefCall, Callid is %d\n",pxDefCall->uiCallId);
					if (strlen(pxEndptInfo->szDialledDigits) == 1){
						xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
			 			strcpy(xTo.uxAddressInfo.szEndptId, pxEndptInfo->szDialledDigits);
         	}else{
						xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
						xTo.uxAddressInfo.xVoipAddr.ucAddrType = IFX_EXTN;
						xTo.uxAddressInfo.xVoipAddr.acCalledAddr[0] = 0;
				 		strcpy(xTo.uxAddressInfo.xVoipAddr.acUserName, pxEndptInfo->szDialledDigits);
						xTo.ucLineId = pxDefCall->ucLineId;
					}
					eRet = IFX_CMGR_CallDeflect(pxDefCall->uiCallId, &xTo, &eReason);
					IFX_DECT_CSU_DeflectionAck(pxSsMsg->uiTkCallId, eRet);
				}
			break;
			}
		default:
			{
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Unexpected Supplementary Request");
			}
	}
  printf("\nAlertingSS Success!\n");
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ServiceChangeHdlr 
 *  Description     : This routine handles service change request/response in
 *	                  dialing, ringback, alerting and active state. 
 *	                  - IFX_DECT_SC_REQUEST : Return success.
 *	                  - IFX_DECT_SC_ACCEPT : Inform the codec acceptance to
 *	                  DECT stack, activate DECT channel and enable voice. If CM
 *	                  initated media negotiation then return media neg response.
 *	                  - IFX_DECT_SC_REJECT : Use previous codec that is 
 *	                  negotiated with handset.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if event is processed.
 *  Notes           : For IFX_DECT_SC_ACCEPT & IFX_DECT_SC_REJECT, if service 
 *	                  change request is not initated by agent, then event is 
 *	                  ignored.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ServiceChangeHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_ServiceChangeInfo* pxScInfo = 
																	&pxEvtInfo->uxEventData.xServiceChangeInfo;
	e_IFX_Return eRet = IFX_SUCCESS;
  x_IFX_DECT_CSU_CallParams xCallParams = {0};	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	if(  IFX_DECT_SC_REQUEST == pxScInfo->eScMsgType )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "!! Service Change Request By PP !!");
	}
	else if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT))
	{

		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);

		if( IFX_DECT_SC_ACCEPT == pxScInfo->eScMsgType )
		{
			boolean bLongSlot = 0;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Service Change Accepted By PP");
			/* de-activate DECT channel and request to change slot type */
			if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) )
			{
				IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);
			}

			if( IFX_MMGR_CODEC_G722_64 == pxEndptInfo->pxActiveCall->eNegCodec )
				bLongSlot = 1;
                xCallParams.bwideband = bLongSlot; 
      
	           IFX_DECT_CSU_ServiceChange(
			   pxEndptInfo->pxActiveCall->uiDTkCallId,
                                       &xCallParams,
                                       IFX_DECT_CSU_SC_REQUEST);
		}
		else if( IFX_DECT_SC_REJECT == pxScInfo->eScMsgType )
		{
			/*
			 * Now continuing with previous codec. So we will run different codec
			 * on each call leg !!
			 */
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Service Change Rejected By PP");
			IFX_DECT_ActivateAfterServiceChange(pxEndptInfo, IFX_FALSE);
		}
	}
#ifdef DEV_DEBUG
	else
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Unexpected Service Change Message");
	}
#endif
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_SlotModIndHdlr
 *  Description     : 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_SlotModIndHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{

	if(IFX_DECTNG_CODEC_G722_64 == pxEvtInfo->uxEventData.xSlotModInd.unCodecType)
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Slot Modified: Using Long Slot Now");
		pxEndptInfo->eRunningCodec = 
			/* pxEndptInfo->pxActiveCall->eNegCodec = */ IFX_MMGR_CODEC_G722_64;
	}
	else
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Slot Modified: Using Full Slot Now");
		pxEndptInfo->eRunningCodec = 
			/*	pxEndptInfo->pxActiveCall->eNegCodec = */IFX_MMGR_CODEC_G726_32;
	}
#ifdef RADVA_NOT_REQ
	/* Indicate that codec is accepted */
	IFX_DECT_SendIWUInfo(pxEndptInfo->ucInstance,
							IFX_DECT_IsWidebandCodec(pxEndptInfo->eRunningCodec));
#endif
	IFX_DECT_ActivateAfterServiceChange(pxEndptInfo, IFX_TRUE);
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_ATX_PENDING) )
  {
		x_IFX_DECT_CallInfo* pxHeldCall = 0;
		e_IFX_Return eRet;
		e_IFX_TransferStatus eTfrStatus;
		uint32 uiDtkHeldCallId;
		uint32 uiDtkActiveCallId;
	
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
							 pxEndptInfo->szEndptId, "Un-Announced Trf req...Initiating transfer now" );
		IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_ATX_PENDING);
    IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		if( pxHeldCall )
		{

			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_TRANSFER_INITIATED);

			uiDtkActiveCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;
			uiDtkHeldCallId = pxHeldCall->uiDTkCallId;
			eRet = IFX_CMGR_AttendedTx(pxHeldCall->uiCallId,
				 pxEndptInfo->pxActiveCall->uiCallId, NULL, &eTfrStatus, peReason );

			if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
				IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Could Not Initiated Attended Transfer" );
				IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
							IFX_TERMINATED, NULL, NULL, peReason);
				IFX_DECT_ResetCall(pxHeldCall,0);
				//Active call will be released in IFX_DECT_MakeDectPPIdle
				IFX_DECT_MakeDectPPIdle(pxEndptInfo);
			} else if(IFX_CMGR_TRANSFER_PROCEEDING == eTfrStatus) {
						IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);
			} else {
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Attended Transfer is successful" );//Check
				IFX_DECT_CSU_CallTransferAck(uiDtkHeldCallId,
																		 uiDtkActiveCallId,
															 NULL,IFX_SUCCESS);
			}
			return IFX_SUCCESS;
		}
  }
	return IFX_SUCCESS;
}

#ifdef ENABLE_ENCRYPTION
/*******************************************************************************
 *  Function Name   : IFX_DECT_CipherStatusHdlr
 *  Description     : 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CipherStatusHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
	if(IFX_FALSE == pxEvtInfo->uxEventData.bCipheringStatus)
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Ciphering Failed. Disconnecting Call");
		IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,&xCallParams, 
					                         IFX_DECT_RELEASE_ENCR_ACT_FAIL);	
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	} else if( IFX_DECT_STATE_DIALING == pxEndptInfo->eState ) {
		if( !IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_CALL_INITIATED ) ) {
      xCallParams.bwideband = IFX_DECT_IsWidebandCodec(pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType);
		}
	} 
	return IFX_SUCCESS;
}
#endif /* ENABLE_ENCRYPTION */

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingRingTimerExpHdlr 
 *  Description     : This routine is called by DECT FSM when ring timer expires
 *	                  If timer-id is not valid, event is ignored, else release 
 *	                  call and move to IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingRingTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	//x_IFX_DECT_CSU_CallParams xCallParams={0};
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	if(pxEndptInfo->pxActiveCall!=NULL){
		//xCallParams.uiSignal=IFX_DECT_SIGNAL_AlertOff;
	 /*	IFX_DECT_CSU_InfoReceived(
        pxEndptInfo->pxActiveCall->uiDTkCallId,
				&xCallParams);*/
	}

	if( pxEvtInfo->uiId != pxEndptInfo->uiToneTimerId )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Wrong Timer Id");
		return IFX_FAILURE;
	}
	
	pxEndptInfo->uiToneTimerId = 0;

	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, 
									(IFX_DECT_F_PAGE_CALL | IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS)) )
	{
		if(pxActCall != NULL)
		IFX_CMGR_CallRelease(pxActCall->uiCallId, IFX_TIMEOUT, NULL,
																													NULL, peReason);
		IFX_DECT_ResetCall(pxActCall,1);
		pxEndptInfo->pxActiveCall = 0;
	}
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingPauseTimerExpHdlr 
 *  Description     : This routine is called by DECT FSM when ring pause timer
 *	                  expires in aleritng state. If call is in ringing state, 
 *	                  toggle bRingPauseOn flag and send ring on or ring off 
 *	                  signal to PP depending on bRingPauseOn flag. Start 
 *	                  ringpause timer.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingPauseTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	uint16 unTimeOut;
	x_IFX_DECT_CSU_CallParams xCallParams={0};

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
			 pxEndptInfo->szEndptId);
	if( pxEvtInfo->uiId != pxEndptInfo->uiRingPauseTimerId )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Wrong Timer Id");
		return IFX_FAILURE;
	}

	pxEndptInfo->bRingPauseOn = ( pxEndptInfo->bRingPauseOn)?0:1;
	unTimeOut = pxEndptInfo->bRingPauseOn?
								IFX_DECT_RINGPAUSE_ON_DURATION:IFX_DECT_RINGPAUSE_OFF_DURATION;
	if( IFX_DECT_CS_RINGING == pxActCall->eState )	
	{

		//xCallParams.uiSignal = pxEndptInfo->bRingPauseOn?IFX_DECT_SIGNAL_AlertOnCont:IFX_DECT_SIGNAL_AlertOff;
		xCallParams.uiSignal = pxEndptInfo->bRingPauseOn?((pxActCall->eCallType==IFX_CMGR_TYPE_EXTN)?
													IFX_DECT_SIGNAL_AlertPattern0:IFX_DECT_SIGNAL_AlertOnCont):IFX_DECT_SIGNAL_AlertOff;
	 	IFX_DECT_CSU_InfoReceived(
        pxActCall->uiDTkCallId,
		&xCallParams);
	}

	IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_RingpauseTimerExpired, 
									unTimeOut,  &pxEndptInfo->uiRingPauseTimerId );

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingReleaseCallHdlr
 *  Description     : This routine is called by DECT FSM when it receives remote
 *	                  call release event from CM (in aleting state). Release call
 *	                  on DECT side and make endpoint IDLE. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingReleaseCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
  //Stop Tone
	//x_IFX_DECT_CSU_CallParams xCallParams={0};
 
	if(pxEndptInfo->uiRingPauseTimerId) //Stop Ringpause Timer
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingPauseTimerId);
		pxEndptInfo->uiRingPauseTimerId = 0;
	}
	if(pxEndptInfo->uiToneTimerId) //Stop Ring timer
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		pxEndptInfo->uiToneTimerId = 0;
	}
	if(pxEndptInfo->uiToneTimerId) //Stop Ring Timer
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		pxEndptInfo->uiToneTimerId = 0;
	}
/*Added for sending Alert off to Handset*/
	if(pxEndptInfo->pxActiveCall!=NULL){
		//xCallParams.uiSignal=IFX_DECT_SIGNAL_AlertOff;
	 	/*IFX_DECT_CSU_InfoReceived(
        pxEndptInfo->pxActiveCall->uiDTkCallId,
				&xCallParams);*/
	}
	IFX_DECT_StopTone(pxEndptInfo,(pxEndptInfo->pxActiveCall!=NULL)?pxEndptInfo->pxActiveCall->uiDTkCallId:0);
#if 0
    //Play Busy Tone
    IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_BUSY_TONE);                                                                                              
    pxEndptInfo->pxActiveCall->eState = IFX_DECT_CS_BUSYSTATE;
	  IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
	  IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_BCETimerExpired,
	      								 IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId );
#else
    IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
#endif
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_AlertingPagingHdlr
 *  Description     : This routine is called by DECT FSM to stop paging. This 
 *	                  routine release paging call and makes DECT endpoint IDLE. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_AlertingPagingHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) )
	{
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActivePPOnHookHdlr
 *  Description     : DECT FSM calls this routine when it receives ON-HOOK in
 *	                  active state. 
 *                    - If there is a held call then do attended transfer. else
 *                    release call. In both cases move to IDLE state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           : Risk is that sometime if user is not intended to do 
 *                    attended transfer, transfer goes through. For example, if
 *                    handset is not reachable we get call release from DECT
 *                    stack.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActivePPOnHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxHeldCall = 0;
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
			pxEndptInfo->szEndptId);
	if( 0 == pxEvtInfo->uxEventData.eDectReleaseReason )
	{ //normal release. try for attended transfer
		IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		if( pxHeldCall )
		{
			e_IFX_Return eRet;
			e_IFX_TransferStatus eTfrStatus;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
									 pxEndptInfo->szEndptId, "Transfering Calls (Attended)" );
			eRet = IFX_CMGR_AttendedTx(pxHeldCall->uiCallId,
						 pxEndptInfo->pxActiveCall->uiCallId, NULL, &eTfrStatus, peReason );

			if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
				IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Could Not Initiated Attended Transfer" );
				IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
						IFX_TERMINATED, NULL, NULL, peReason);
				IFX_DECT_ResetCall(pxHeldCall,0);
				//Active call will be released in IFX_DECT_MakeDectPPIdle
			} 
		}
	}
	
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActivePPHookFlashHdlr
 *  Description     : DECT FSM invokes this routine when handset sends HOOK-
 *	                  FLASH event in active state. Initiate hold on active call.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If hold initiated or call is held successfuly then 
 *	                  IFX_SUCCESS is returned, otherwise IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActivePPHookFlashHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	return IFX_DECT_ActiveCallHold(pxEndptInfo);
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_CwDigitPressedHdlr
 *  Description     : This routine is invoked when user presses digit during 
 *	                  call waiting. This event is ignored if hold,transfer, 
 *	                  conference or conference break was initiated.
 *	                  If accepted, send digit to CM or reject ther call for 1.0 if DP matches.
 *	                  
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CwDigitPressedHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	static char8 aucPrefix[10]={'\0'};
	static uint16 i=0;

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_HOLD_INITIATED |
				IFX_DECT_F_TRANSFER_INITIATED | IFX_DECT_F_CONFERENCE_INITIATED |
				IFX_DECT_F_BREAK_CONFERENCE_INITIATED))
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
											pxEndptInfo->szEndptId, "FAILED : Can Not Send Digits" );
	}
	else 
	{
		x_IFX_CMGR_DgtInfo xDigitInfo;
		e_IFX_CMGR_Status eStatus;
		memset(xDigitInfo.szDigits,0,sizeof(xDigitInfo.szDigits));
	if(!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){
    if(!strlen(aucPrefix)){
			IFX_DP_RulePrefixGet(IFX_DP_CALLWAITING_REJECT,aucPrefix);
		}
		if(aucPrefix[i]==pxEvtInfo->uxEventData.xDigitEvt.szDigits[0]){
			i++;
		}else{
			strncpy(xDigitInfo.szDigits,aucPrefix,i);
			memset(aucPrefix,0,sizeof(aucPrefix));
			i=0;
		}
	}
    if(i==0){
			strcat(xDigitInfo.szDigits, pxEvtInfo->uxEventData.xDigitEvt.szDigits);
			if( IFX_SUCCESS != 
				 IFX_CMGR_DigitsInCallSnd(pxEndptInfo->pxActiveCall->uiCallId, 
																								&xDigitInfo, &eStatus,peReason ) )
			{
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "FAILED : DigitsInCallSnd");
			}
		}else if((i==strlen(aucPrefix))&&(strlen(aucPrefix))){
			i=0;
			memset(aucPrefix,0,sizeof(aucPrefix));
			x_IFX_DECT_CallInfo* pxRelCall;
			IFX_DECT_GetWaitingCallInfo(pxEndptInfo,&pxRelCall);
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                         pxEndptInfo->szEndptId, "Release waiting call...");
			if(pxRelCall != NULL)
				IFX_DECT_StopTone( pxEndptInfo,pxRelCall->uiDTkCallId);
			if( pxEndptInfo->uiToneTimerId )
			{
				IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
				pxEndptInfo->uiToneTimerId = 0;
			}
			IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, 
								  NULL, NULL, peReason);
			IFX_DECT_ResetCall(pxRelCall,0);
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
		}
 	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveDigitPressedHdlr
 *  Description     : This routine is invoked when user presses digit during 
 *	                  conversation. This event is ignored if hold,transfer, 
 *	                  conference or conference break was initiated.
 *	                  If accepted, send digit to CM (for out of band ).
 *	                  
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveDigitPressedHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_HOLD_INITIATED |
				IFX_DECT_F_TRANSFER_INITIATED | IFX_DECT_F_CONFERENCE_INITIATED |
				IFX_DECT_F_BREAK_CONFERENCE_INITIATED))
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
											pxEndptInfo->szEndptId, "FAILED : Can Not Send Digits" );
	}
	else 
	{
		x_IFX_CMGR_DgtInfo xDigitInfo;
		e_IFX_CMGR_Status eStatus;

		strcpy(xDigitInfo.szDigits, pxEvtInfo->uxEventData.xDigitEvt.szDigits);
		if( IFX_SUCCESS != 
				 IFX_CMGR_DigitsInCallSnd(pxEndptInfo->pxActiveCall->uiCallId, 
																								&xDigitInfo, &eStatus,peReason ) )
		{
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "FAILED : DigitsInCallSnd");
		}
#ifdef TEST_MEDIA_NEG
		if( xDigitInfo.szDigits[0] == '4' && 
				(pxEndptInfo->xReservedCodecs.axCodecs[1].eCodecType != IFX_MMGR_CODEC_NONE ))
		{
			x_IFX_CMGR_MediaParams xMediaParams = {0};
			e_IFX_CMGR_Status eMediaNegStatus;
			x_IFX_CMGR_ExtnMediaParams* pxExtnMediaParams = 
											&xMediaParams.uxMediaParams.xExtnMediaParams;

			xMediaParams.eAgentType = IFX_CMGR_TYPE_EXTN;
			pxExtnMediaParams->xCodecParams.unNoOfCodecs = 1;
			
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
					"Current Call's Codec = ", pxEndptInfo->pxActiveCall->eNegCodec);

			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
					"Current Running Codec = ", pxEndptInfo->eRunningCodec);
			if( IFX_MMGR_CODEC_G726_32 == pxEndptInfo->pxActiveCall->eNegCodec )
			{
				pxExtnMediaParams->xCodecParams.axCodec[0].uiCodec = IFX_G722_64;
			}
			else
				pxExtnMediaParams->xCodecParams.axCodec[0].uiCodec = IFX_G726_32; 

			if( IFX_SUCCESS == 
					IFX_CMGR_MediaNegReq(pxEndptInfo->pxActiveCall->uiCallId,
											&xMediaParams, &eMediaNegStatus, peReason) &&
					eMediaNegStatus != IFX_CMGR_STATUS_FAIL)
			{
			 	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, 
						( IFX_CMGR_STATUS_PENDING == eMediaNegStatus)?
																"Media Neg Is Pending":"Media Neg Is Success");
				if( IFX_CMGR_STATUS_PENDING == eMediaNegStatus)
				{
				}
				else
				{ 
					IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
							"After Success Call's Codec = ", pxExtnMediaParams->xCodecParams.axCodec[0].uiCodec);
				}
			}
			else
			{
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "Media Negotiation Failed");
			}
		}
#endif
	}
	return IFX_SUCCESS;
}


/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveSSMsgHdlr
 *  Description     : This is onvoked for suplimentary serivce messages
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : This is not used
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveSSMsgHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
	//e_IFX_Return eRet;
	
	//TODO: When do agent get SS messages -- During BTX, whetehr PP puts call on hold
	// and then sends BTX message followed by transfer target or without putting call
	// on hold, sends BTX message followed by transfer target ??
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
										pxEndptInfo->szEndptId);

	switch( pxSsMsg->eSSType )
	{
		case IFX_DECT_SS_TOGGLE:
      {
			  IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
				/*eRet =*/ IFX_DECT_ActiveCallHold(pxEndptInfo);
        break;
      }
    case IFX_DECT_SS_INTERCEPT:
      {
				//if(!IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_INIT))
        IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_ATX_PENDING);
				/*eRet =*/ IFX_DECT_ActiveCallHold(pxEndptInfo);
				//eRet = IFX_DECT_MakeConference(pxEndptInfo);
        break;
      }

		case IFX_DECT_SS_HOLD:
			{
				/*eRet =*/ IFX_DECT_ActiveCallHold(pxEndptInfo);
				break;
			}
		case IFX_DECT_SS_MAKE_CONF:
			{
				/*eRet = */IFX_DECT_MakeConference(pxEndptInfo);
				break;
			}
		case IFX_DECT_SS_BTX:
				 return IFX_FAILURE;
		case IFX_DECT_SS_ATX:
			{
	    		x_IFX_DECT_CallInfo* pxHeldCall = 0;
           IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		      if( pxHeldCall )
		      {
						e_IFX_Return eRet;
						e_IFX_TransferStatus eTfrStatus;
            uint32 uiDtkHeldCallId;
            uint32 uiDtkActiveCallId;

						IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
										 pxEndptInfo->szEndptId, "Transfering Calls (Attended)" );
						IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_TRANSFER_INITIATED);

            uiDtkActiveCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;
						uiDtkHeldCallId = pxHeldCall->uiDTkCallId;
						eRet = IFX_CMGR_AttendedTx(pxHeldCall->uiCallId,
							 pxEndptInfo->pxActiveCall->uiCallId, NULL, &eTfrStatus, peReason );

						if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
							IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
						{
						IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndptId, "Could Not Initiated Attended Transfer" );
						IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
									IFX_TERMINATED, NULL, NULL, peReason);
						IFX_DECT_ResetCall(pxHeldCall,0);
						IFX_DECT_CSU_CallTransferAck(uiDtkHeldCallId,
																				uiDtkActiveCallId,
																		 NULL,IFX_FAILURE);
						//Active call will be released in IFX_DECT_MakeDectPPIdle
									IFX_DECT_MakeDectPPIdle(pxEndptInfo);
						} else if(IFX_CMGR_TRANSFER_PROCEEDING == eTfrStatus) {
									IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);
						} else {
							IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
									pxEndptInfo->szEndptId, "Attended Transfer is successful" );
							IFX_DECT_CSU_CallTransferAck(uiDtkHeldCallId,
																					 uiDtkActiveCallId,
																		 NULL,IFX_SUCCESS);
							IFX_DECT_MakeDectPPIdle(pxEndptInfo);
						}
					} 
					break;
			 }
		case IFX_DECT_SS_RELEASE:
			 {
			   x_IFX_DECT_CallInfo* pxCallInfo=NULL;

  			 IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxCallInfo);
        /* 
         * Mahipati: If call is released here IFX_DECT_MakeDectPPIdle crashes !!
         * - infact crash is in toolkit--inside IFX_DECT_CSU_VoiceModify 
         */
			  if( pxCallInfo == pxEndptInfo->pxActiveCall) {

					//Active call released.
          IFX_DECT_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall); 
          if(!pxEndptInfo->pxActiveCall )	
					{  
            pxEndptInfo->pxActiveCall = pxCallInfo;    	
						IFX_DECT_MakeDectPPIdle(pxEndptInfo);
          }
					else
					{
						if(pxCallInfo != NULL){
							IFX_CMGR_CallRelease( pxCallInfo->uiCallId, IFX_TERMINATED, NULL, NULL, peReason);
							IFX_DECT_ResetCall(pxCallInfo,0);
						}
						IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_DIALING);
					}
				} else {
					IFX_CMGR_CallRelease( pxCallInfo->uiCallId, IFX_TERMINATED, NULL, NULL, peReason);
					IFX_DECT_ResetCall(pxCallInfo,0);
				}
				break;
			}
		default:
			{
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Unexpected Supplementary Request");
			}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveIncomingCallHdlr 
 *  Description     : This routine is invoked by DECT FSM when it receives 
 *	                  incoming call in active state.  Check whether call can be 
 *	                  accepted. If so, send call waiting signal to PP, start ring 
 *	                  timer, update call state and move to call waiting state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Returns IFX_FAILURE, if call can not be accepted, else
 *	                  returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveIncomingCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_IncCallEvent* pxIncallEvt = (&pxEvtInfo->uxEventData.xIncCallEvt);
	x_IFX_DECT_CallInfo* pxNewCall = 0;
	x_IFX_MMGR_CodecList xReservedCodecs = {0};	
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
//	boolean bBlocked = IFX_FALSE;
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
			pxEndptInfo->szEndptId);

	IFX_DECT_GetFreeCallInfo(pxEndptInfo, &pxNewCall);
  /* If this handset has max calls or hold, transfer intiated or active call 
		 is emergency call, reject incoming call */
	if( NULL == pxNewCall || /* PP has MAX calls now */
			IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_HOLD_INITIATED |
				IFX_DECT_F_TRANSFER_INITIATED | IFX_DECT_F_EMG_CALL_PROCEDING|IFX_DECT_F_INTERCEPT_INIT|
				IFX_DECT_F_INTRUDE_INIT ) )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
											pxEndptInfo->szEndptId, "Can Not Accept Incoming Call" );
		return IFX_FAILURE;
	}
	
	IFX_AGU_GetCallerIdInfo(pxIncallEvt->pxFrom, 
								pxEndptInfo->szCallerName, pxEndptInfo->szCallerNumber);
	if( IFX_CMGR_TYPE_VOIP != pxIncallEvt->pxFrom->eAddressType)
	{
	  xCallParams.isInternal = IFX_TRUE;
	  xCallParams.ucPeerHandsetId = 
	             IFX_DECT_HsIdFromEPName(pxIncallEvt->pxFrom->uxAddressInfo.szEndptId);
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Peer Handset Id = ", xCallParams.ucPeerHandsetId);
	}

	/* Whether caller is allowed to reach ?? */
	/*IFX_CIF_IncomingCallBlockCheck(pxEndptInfo->szEndptId,
							pxEndptInfo->szCallerName, &bBlocked, peReason);
  if( bBlocked )
	{
		//No, this caller is not allowed 
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Incoming Call Is Blocked" );
		return IFX_FAILURE; 
	}
*/
			
	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndptId, "Calling IFX_DECT_CSU_CallInitiate for CW Indication" );

	if(pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams.axCodec[0].uiCodec == IFX_G722_64){
    xCallParams.bwideband = 1;
	}else{
    xCallParams.bwideband = 0;
	}
  xCallParams.bIsPresentation =1;
	strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);
	if(IFX_CIF_CNIPGet(xCallParams.isInternal,pxEvtInfo->uxEventData.xIncCallEvt.ucLineId,
										pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS)
	strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
  printf("CNIP Name2:%s\n",xCallParams.acCNIP);
	xCallParams.ucLineId=	pxEvtInfo->uxEventData.xIncCallEvt.ucLineId;
	IFX_DECT_CSU_CallInitiate (pxEndptInfo->ucInstance+1,
                         	   &xCallParams, 
                         	   (uint32)pxEndptInfo,
	           				   (uint32 *)&pxNewCall->uiDTkCallId
							   ); 

	pxEndptInfo->unRingTimeOut = IFX_RING_TONE_DURATION;
	if( pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.cRingCount ) {
		int32 iRingDur;
		
		IFX_MMGR_RingCadenceTimeGet(&iRingDur);
		pxEndptInfo->unRingTimeOut = 
			iRingDur * pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.cRingCount;
	}
   
	//Get codec for this call
	pxNewCall->eNegCodec = IFX_MMGR_CODEC_G726_32;
	if(pxEndptInfo->bWidebandEnabled)
	{
		IFX_DECT_ConvertCodecToMMGR(&xReservedCodecs, 
				&pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams);
		/* store the codec in eNegCodec */
		if( IFX_DECT_IsWidebandCodec(
					xReservedCodecs.axCodecs[0].eCodecType) )
		{
			pxNewCall->eNegCodec = IFX_MMGR_CODEC_G722_64;
		}
		else
		{
			pxNewCall->eNegCodec = IFX_MMGR_CODEC_G726_32;
		}
	}
	
	pxNewCall->uiCallId = pxEvtInfo->uiId;
	if( IFX_CMGR_TYPE_FXO == 
		(pxNewCall->eCallType = pxIncallEvt->pxFrom->eAddressType))
	{
		strcpy(pxNewCall->szCallInitrEndptId,
				pxIncallEvt->pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId );
	}
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_CALL_WAITING);
	//Start ring timer
	IFX_DECT_PlayTone(pxEndptInfo,pxNewCall->uiDTkCallId,IFX_DECT_CALL_WAITING_TONE);

	IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_RingTimerExpired,
									pxEndptInfo->unRingTimeOut, &pxEndptInfo->uiToneTimerId );
	IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
	IFX_DECT_UpdateCallState(pxEndptInfo, 
										pxNewCall, IFX_DECT_CS_RINGING);	

	*peReason = IFX_ENDPOINT_RINGING;
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveReleaseCallHdlr
 *  Description     : This routine is called by DECT FSM, in active state, when 
 *	                  remote party releases call. If call id is not valid ignore
 *	                  this event.
 *	                  - Active call Released : Release call resources, if there
 *	                  is a held call, if it current active call, start busy 
 *	                  timer and move to busy state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If released call id is valid returns IFX_SUCCESS, 
 *	                  otherwise returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveReleaseCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxRelCall = NULL;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
					 pxEndptInfo->szEndptId);
	IFX_DECT_GetCallInfo(pxEndptInfo, pxEvtInfo->uiId, &pxRelCall);

	if(NULL == pxRelCall)
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Could Not find Call Info");
		return IFX_FAILURE;
	}
  printf("\n pxRelCall = %d\n",(uint32)pxRelCall);
  if(pxRelCall == pxEndptInfo->pxActiveCall){
		//pxEndptInfo->uiDTkCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;					
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_HOLD_INITIATED | 
									IFX_DECT_F_TRANSFER_INITIATED);
  }

	IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_OFF_HOOK_TONE);

  pxRelCall->eState = IFX_DECT_CS_BUSYSTATE;
  IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);//For 2.0 Resume state to dialing if held not null
	IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,
										IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId );

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveHoldRespHdlr
 *  Description     : This routine is invoked by DECT FSM, in active state, when 
 *	                  CM sends call hold response. Ignore this event if call id
 *                    is not valid or call hold is not initiated on active call.
 *	                  - Hold is success : change call state, play dial tone and
 *											move to DIALING state.
 *	                  - Hold faild : Change call's state to active.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call hold is initated on current active call, returns 
 *	                  IFX_SUCCESS, else returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveHoldRespHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{	
	x_IFX_DECT_CallInfo* pxActCall;
	x_IFX_DECT_CallInfo* pxHeldCall;
	e_IFX_DECT_States eState = IFX_DECT_STATE_MAX;
	e_IFX_Return eRet = IFX_FAILURE;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
  IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
	pxActCall = pxEndptInfo->pxActiveCall;

	if( IFX_DECT_CS_HOLD_INITIATED != pxActCall->eState ||
		  pxEvtInfo->uiId != pxActCall->uiCallId )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Hold Resp For Uknown Call");
		return IFX_FAILURE;
	}

	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_HOLD_INITIATED);

	if(IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
	{
	if((! IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED)) 
			&& (!(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_INIT)))){
		uint32 uiDtkId = pxActCall->uiDTkCallId;
		eRet = IFX_DECT_HandleHoldSuccess(pxEndptInfo,&eState);
		IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
    IFX_DECT_CSU_CallHoldAck(uiDtkId,&xCallParams,IFX_SUCCESS);
		printf("Hold ack Sent\n");
	}else if((IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_INIT))){
		eRet = IFX_DECT_HandleHoldSuccess(pxEndptInfo,&eState);
		IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
		printf("CallHandle From Toolkit %d \n",pxEndptInfo->uiDTkCallId);
    
    /* Endpoint has already accepted the intercept req */
	    x_IFX_DP_Rule xDpRule;
	    char8  szDialOut[IFX_MAX_DIGITS];
	    uchar8 ucDpAction = 0;
	    uint16 unTimeOut = 0;
      /* Call Initiate to the Intercept req PP. Match the DP and put it to FSM */
      eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
						IFX_FALSE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );
	    if( IFX_SUCCESS == eRet && (IFX_DP_ST_SMALL_TIM == ucDpAction || 
							 IFX_DP_ST_LARGE_TIM == ucDpAction) )
	    {
		    IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_InterDigitTimerExpired,
							   unTimeOut, &pxEndptInfo->uiIntrDgtTimerId);
	    }

	 	}else{
			  IFX_DECT_HandleHoldSuccess(pxEndptInfo, &eState);
			  IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
    }			
	}else{
		/* Hold failed */
		if( IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) ){
    	if(pxHeldCall != NULL)
			IFX_DECT_CSU_CallToggleAck(pxHeldCall->uiDTkCallId,pxActCall->uiDTkCallId,NULL,IFX_FAILURE);
	  	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
		}	
  else
    IFX_DECT_CSU_CallHoldAck(pxActCall->uiDTkCallId,&xCallParams,IFX_FAILURE);
		pxActCall->eState = IFX_DECT_CS_ACTIVE;
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR,  IFX_DBG_ATA_STRING_INFO,
																			pxEndptInfo->szEndptId, "Hold Failed");
		
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CwPPOnHookHdlr
 *  Description     : In call waiting state, if DECT FSM receives OH-HOOK from
 *	                  handset, this routine is invoked. Stop playing call 
 *	                  waiting tone, release active call and try to establish
 *	                  call with handset. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           : Since ring timer is already running, so ring timer is not
 *	                  re-started.
 ******************************************************************************/
e_IFX_Return IFX_DECT_CwPPOnHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
  x_IFX_DECT_CallInfo *pxWaitCall = NULL;
 
	if( 0 == pxEvtInfo->uxEventData.eDectReleaseReason )
	{ //normal release. Setup call with PP for waiting call
		x_IFX_DECT_CSU_CallParams xCallParams = {0};

		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,  IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, 
				"One Call Is Waiting. Initiating Call With Handset");
		IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_CALL_WAITING | IFX_DECT_F_HOLD_INITIATED);
		IFX_DECT_GetWaitingCallInfo(pxEndptInfo, &pxWaitCall);
		if(pxWaitCall != NULL)
		IFX_DECT_StopTone(pxEndptInfo,pxWaitCall->uiDTkCallId);
		IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_TERMINATED, 
												NULL, NULL, peReason);
		IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,0);
    pxEndptInfo->pxActiveCall = pxWaitCall;
		xCallParams.bwideband = pxEndptInfo->bWidebandEnabled;
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Calling Dect Toolkit IFX_DECT_CSU_CallInitiate" );

		strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);
    xCallParams.bIsPresentation =1;
	strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
  printf("CNIP Name3:%s\n",xCallParams.acCNIP);//Don't send CLIP/CNIP in setup
		
                IFX_DECT_CSU_CallInitiate (pxEndptInfo->ucInstance+1,
                                   &xCallParams, 
                                   (uint32)pxEndptInfo,
	           		   (uint32 *)&pxEndptInfo->pxActiveCall->uiDTkCallId
							   ); 

  //Send Alert Signal and CLIP/CNIP.
  //IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_SIGNAL_AlertPattern0);

	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ALERTING);
	} else {
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CwSSMsgHdlr
 *  Description     : This routine is invoked on receving supplimentary service
 *	                  message in call waiting state. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : This is not used.
 ******************************************************************************/
e_IFX_Return IFX_DECT_CwSSMsgHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
	//e_IFX_Return eRet;
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	switch( pxSsMsg->eSSType )
	{
		case IFX_DECT_SS_HOLD:
			{
				/*eRet =*/ IFX_DECT_ActiveCallHold(pxEndptInfo);
				break;
			}
		case IFX_DECT_SS_BTX:
		case IFX_DECT_SS_ATX:
			{
				 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
														pxEndptInfo->szEndptId, "Transfer not possible...");
				 break;
			}
		case IFX_DECT_SS_RELEASE:
			{
      	x_IFX_DECT_CallInfo* pxRelCall;
  		
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                            pxEndptInfo->szEndptId, "Release  call...");
	
				IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId, pxEndptInfo,&pxRelCall);
			  if( pxRelCall == pxEndptInfo->pxActiveCall) {
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                            pxEndptInfo->szEndptId, "Release active call...");
				  IFX_DECT_GetWaitingCallInfo(pxEndptInfo, &pxEndptInfo->pxActiveCall);
				  if(pxRelCall) {
								
						x_IFX_DECT_CSU_CallParams xCallParams = {0};
      			IFX_DECT_CSU_VoiceModify(pxRelCall->uiDTkCallId,
	   	    	 	   										&xCallParams,
								 										IFX_DECT_STOP_VOICE,
								 										pxEndptInfo->unDectChannel);
			
		  			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
						IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);

					  IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, 
								  NULL, NULL, peReason);
					  IFX_DECT_ResetCall(pxRelCall,0);
						IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ALERTING);
				  }
				}
        else{ 
	
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                            pxEndptInfo->szEndptId, "Release waiting call...");
						if(pxRelCall)
							IFX_DECT_StopTone( pxEndptInfo,pxRelCall->uiDTkCallId);
					if( pxEndptInfo->uiToneTimerId )
					{
						IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
						pxEndptInfo->uiToneTimerId = 0;
					}
					if(pxRelCall){
					IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, 
								  NULL, NULL, peReason);
					IFX_DECT_ResetCall(pxRelCall,0);
        	}
					IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
					IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
        }	
		    break;	
			}
		case IFX_DECT_SS_CALL_DEFLECT:
			{
				x_IFX_DECT_CallInfo* pxDefCall;
				x_IFX_CMGR_AddressInfo xTo;
	  		e_IFX_ReasonCode eReason;
				e_IFX_Return eRet = IFX_SUCCESS;


				IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxDefCall);
				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
                    pxEndptInfo->szEndptId, "Deflect Call");

				if(pxDefCall) {
					if (strlen(pxEndptInfo->szDialledDigits) == 1){
						xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
			 			strcpy(xTo.uxAddressInfo.szEndptId, pxEndptInfo->szDialledDigits);
         	}else{
						xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
						xTo.uxAddressInfo.xVoipAddr.ucAddrType = IFX_EXTN;
						xTo.uxAddressInfo.xVoipAddr.acCalledAddr[0] = 0;
				 		strcpy(xTo.uxAddressInfo.xVoipAddr.acUserName, pxEndptInfo->szDialledDigits);
						xTo.ucLineId = pxDefCall->ucLineId;
					}
					eRet = IFX_CMGR_CallDeflect(pxDefCall->uiCallId, &xTo, &eReason);
					printf("Deflection: CMGR_CallDeflect API returned %d \n",eRet);
					IFX_DECT_CSU_DeflectionAck(pxSsMsg->uiTkCallId, eRet);
				}
			break;
			}
		default:
			{
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Supplementary Event: Ignore");
				 break;
			}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CwRingTimerExpHdlr
 *  Description     : This routine is invoked by DECT FSM, in call waiting state,
 *	                 when ring timer expires. If timer id is valid, then release
 *	                 wating call, stop call waiting tone and then move to ACTIVE
 *	                 state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If timer-id is valid returns IFX_SUCCESS, otherwise 
 *	                  returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_CwRingTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxWaitCall;
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	if( pxEvtInfo->uiId != pxEndptInfo->uiToneTimerId )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Wrong Timer Id");
		return IFX_FAILURE;
	}
	pxEndptInfo->uiToneTimerId = 0;
	IFX_DECT_GetWaitingCallInfo(pxEndptInfo, &pxWaitCall);
	//stop call waiting tone
	if(pxWaitCall)
		IFX_DECT_StopTone( pxEndptInfo,pxWaitCall->uiDTkCallId);
	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
	//TODO: Inform PP about this event ??
	IFX_CMGR_CallRelease(pxWaitCall->uiCallId, IFX_TERMINATED, 
	                  	 NULL, NULL, peReason);
	//TODO Call waiting not answered by PP, then what ? read NGPP		
	IFX_DECT_ResetCall(pxWaitCall,0);
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CwReleaseCallHdlr 
 *  Description     : This routine is invoked by DECT FSM,in call waiting state,
 *	                  when remote party releases call. If call-id is not valid,
 *	                  ignore the event.
 *	                  Stop call wiating tone.
 *	                  - Active call released : Terminate call with handset. 
 *	                  Start busy timer and move to busy state.
 *	                  - Waiting call released : stop ringing timer and move to
 *	                  active state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call-id is valid, returns IFX_SUCCESS, else 
 *	                  IFX_FAILURE is returned.
 *  Notes           : Ringing timer is not stopped. If ringigng timer expires
 *	                  before busy timer, then call will not be initated. 
 *	                  Otherwise call will be initiated to handset in busy state
 *	                  after busy timer expires.
 ******************************************************************************/
e_IFX_Return IFX_DECT_CwReleaseCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxRelCall;
	e_IFX_DECT_States eState ;
  int32 iWaitCallRel=0;	
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	IFX_DECT_GetCallInfo(pxEndptInfo, pxEvtInfo->uiId, &pxRelCall);

	if( NULL == pxRelCall)
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,"Unknown Call Is Being Released");
		return IFX_FAILURE;
	}

  if(pxEndptInfo->uiToneTimerId){
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		pxEndptInfo->uiToneTimerId = 0;
  }

	if( pxRelCall == pxEndptInfo->pxActiveCall )
	{ //Active call released
		x_IFX_DECT_CSU_CallParams xCallParams = {0};
		IFX_DECT_ResetEndptFlag(pxEndptInfo, 
				IFX_DECT_F_HOLD_INITIATED | IFX_DECT_F_TRANSFER_INITIATED );
	
	  //IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);
    
    if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){
		
      IFX_DECT_CSU_VoiceModify(
		             pxEndptInfo->pxActiveCall->uiDTkCallId,
	   	    	 	   &xCallParams,
								 IFX_DECT_STOP_VOICE,
								 pxEndptInfo->unDectChannel);
			
		  IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
			IFX_MMGR_DectResDeActivate(pxEndptInfo->szEndptId);
		  IFX_DECT_GetWaitingCallInfo(pxEndptInfo, &pxEndptInfo->pxActiveCall);

	  	IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);
		  eState = IFX_DECT_STATE_ALERTING;
		  IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
    }else{
      /* For GAP Handsets move to busy state */
      /* start timer and move to busy state. This PP has an incoming call(waiting)
         Once this timer expires, initiate call with PP.*/
      //pxRelCall->eState = IFX_DECT_CS_BUSYSTATE;
      pxEndptInfo->uiDTkCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;//Call Id might be reqrd in BusyRingTimer
	    IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_OFF_HOOK_TONE);
      IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,
                              IFX_DECT_BUSY_TONE_TIMER,  &pxEndptInfo->uiBCETimerId );
      eState = IFX_DECT_STATE_BUSY;
    }

	}
	else
	{
		//Waiting call released
    printf("Waiting call being release\n");
    iWaitCallRel=1;
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
		eState = IFX_DECT_STATE_ACTIVE;
	}
  /* For GAP handset Call release should not be sent to handset */
  printf("Term Cap = %x %d %d\n",pxEndptInfo->uiTermCap,pxEndptInfo->axCallInfo[0].uiDTkCallId,
             pxEndptInfo->axCallInfo[1].uiDTkCallId);

  if((!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2))&&(iWaitCallRel==1)){
    printf("Gap HS so doing partial rel\n");                                                                                                                                 
    IFX_DECT_ResetCall(pxRelCall,0);                                                                                                                            
	  IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);
  }                                                                                                                                                                          
  else{                                                                                                                                                                      
    printf("Gap Active call rel/CATIQ 2.0 HS Gap HS so doing rel\n");                                                                                                        
    IFX_DECT_ResetCall(pxRelCall,1);                                                                                                                            
  }                                                                                                                                                                          
	IFX_DECT_UpdateEndptState(pxEndptInfo, eState);

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConfPPOnHookHdlr
 *  Description     : DECT FSM invokes this routine if handset sends ON-HOOK 
 *	                  event in conference state. Breaks the conference and makes
 *	                  endpoint IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConfPPOnHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
  /* Release call, de-allocate signaling channel make endpoint idle. */
  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConfPPHookFlashHdlr
 *  Description     : This routine is invoked by DECT FSM on receiving HOOK
 *	                  -FLASH  in conference state. If conference break was not
 *	                  initiated, then asks CM to break conference. If conference
 *	                  status--
 *	                  - success : update calls states and move to DIALING.
 *	                  - pending : set conference break initiated flag.
 *	                  - fail    : do nothing.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConfPPHookFlashHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{

	if( ! IFX_DECT_CheckEndptFlag(pxEndptInfo, 
																			IFX_DECT_F_BREAK_CONFERENCE_INITIATED) )
	{
		//break conference 
		e_IFX_Return eRet;
		e_IFX_CMGR_Status eStatus;
		
		eRet = IFX_CMGR_ConfBreak(pxEndptInfo->uiConfReqId, &eStatus, peReason);
		
		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_FAIL == eStatus )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
													pxEndptInfo->szEndptId, "IFX_CMGR_ConfBreak Failed");
		}
		else if( IFX_CMGR_STATUS_SUCCESS == eStatus)
		{
			pxEndptInfo->uiConfReqId = 0;
			IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+0),
																											IFX_DECT_CS_HELD);
			IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+1),
																											IFX_DECT_CS_HELD);

			IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_DialTimerExpired,
											IFX_DECT_DIAL_TONE_TIMER,  &pxEndptInfo->uiToneTimerId);
			IFX_DECT_PlayTone( pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_DIAL_TONE);
			
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_DIALING);
		}
		else //conference status is pending
		{
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_BREAK_CONFERENCE_INITIATED);
		}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConfReleaseCallHdlr.
 *  Description     : This routine is called by DECT FSM when it receives remote
 * 	                  call release event in conference state. Ignore the event
 *	                  call-id is not valid.
 *	                  Reset released call info. Don't break conference. Wait
 *	                  till CM sends conference status.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call-id is valid, returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE.
 *  Notes           : When one of the remote party involved in conference term-
 *	                  nates call, CM is going to send conference status to
 *	                  indicate conference break.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConfReleaseCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxRelCall = NULL;

  /* This occurs when one of the remote parties terminates the call. */
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	IFX_DECT_GetCallInfo(pxEndptInfo, pxEvtInfo->uiId, &pxRelCall);

	if(NULL == pxRelCall){

		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					   pxEndptInfo->szEndptId,"Unknown Call Is Being Released");
		return IFX_FAILURE;
	}
  if(pxEndptInfo->uiTermCap&IFX_DECT_MU_HS_CAT2){
		if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_INIT)){
			IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_INTRUDE_INIT);
		}
  	IFX_DECT_ResetCall(pxRelCall,1);
  }else{
		IFX_DECT_ResetCall(pxRelCall,0);
	}

  if(pxRelCall == pxEndptInfo->pxActiveCall){

		if(IFX_DECT_CS_NONE != (pxEndptInfo->axCallInfo +0)->eState)
			pxEndptInfo->pxActiveCall = (pxEndptInfo->axCallInfo + 0);

		else if(IFX_DECT_CS_NONE != (pxEndptInfo->axCallInfo +1)->eState )
			pxEndptInfo->pxActiveCall = (pxEndptInfo->axCallInfo + 1);

		else/*Ideally this will nt be the case.*/
			pxEndptInfo->pxActiveCall = NULL; 
  }
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConfStatusHdlr
 *  Description     : This routine is called by DECT FSM when CM sends conf 
 *	                  status in conference state. If conference id is valid and 
 *	                  status is success, update all calls state to held and move 
 *	                  to dialing state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If conference id is valid, returns IFX_SUCCESS, else
 *	                  returns IFX_FAILURE.
 *  Notes           : CM sends conf status if conference break is initated by
 *	                  agent or one of the remote party terminates call.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConfStatusHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	
	if( pxEndptInfo->uiConfReqId != pxEvtInfo->uiId )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Invalid Conference call id");
		return IFX_FAILURE;
	}

	if(IFX_DECT_CheckEndptFlag(pxEndptInfo, 
									IFX_DECT_F_BREAK_CONFERENCE_INITIATED)) {

		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_BREAK_CONFERENCE_INITIATED);
		if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
		{
			pxEndptInfo->uiConfReqId = 0;
			IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+0),
																											IFX_DECT_CS_HELD);
			IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+1),
																											IFX_DECT_CS_HELD);

			IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_DialTimerExpired,
											IFX_DECT_DIAL_TONE_TIMER,  &pxEndptInfo->uiToneTimerId);
			IFX_DECT_PlayTone(pxEndptInfo,0,IFX_DECT_DIAL_TONE);
			
			IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
		}
#ifdef DEV_DEBUG
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "FAILED: Could Not Terminate Conference");
		}
#endif
	}
#if 0 /* Need to find out the case when this occurs */
   else { //Conference is broben by call manager
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Conference Is Terminated");
		if( NULL != pxEndptInfo->pxActiveCall ) {
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
		} else { //all coference participants are terminated
			IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTKCallId,IFX_DECT_BUSY_TONE);//SS: Call Id??
			IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_BCETimerExpired,
												     IFX_DECT_BUSY_TONE_TIMER,  &pxEndptInfo->uiBCETimerId);
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_BUSY);

		}
	}
#endif

	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_ConfSSMsgHdlr (
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
	e_IFX_CMGR_Status  eStatus;
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
										pxEndptInfo->szEndptId);

	switch( pxSsMsg->eSSType )
	{
    case IFX_DECT_SS_RELEASE:
			{
				if( IFX_SUCCESS !=
								IFX_CMGR_ConfBreak(pxEndptInfo->uiConfReqId, &eStatus, peReason) )
				{
					IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
															pxEndptInfo->szEndptId, "IFX_CMGR_ConfBreak Failed");
				}
   
				/* Release call, de-allocate signaling channel make endpoint idle. */
				IFX_DECT_MakeDectPPIdle(pxEndptInfo);

				break;
			}
		default:
			{
				 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Unexpected Supplementary Request");
			}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BusyPPOnHookHdlr
 *  Description     : This routine is called when handset goes ON-HOOK in busy 
 *	                  state. Release calls and make endpoint IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_BusyPPOnHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
 
  x_IFX_DECT_CallInfo *pxRelCall = NULL;
 
  if( pxEndptInfo->uiBCETimerId ) {
		IFX_TIM_TimerStop(pxEndptInfo->uiBCETimerId);
		pxEndptInfo->uiBCETimerId = 0;
	}
  pxRelCall = (pxEndptInfo->axCallInfo[0].eState == IFX_DECT_CS_BUSYSTATE)?&pxEndptInfo->axCallInfo[0]:
               &pxEndptInfo->axCallInfo[1];

	IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);
	IFX_DECT_ResetCall(pxRelCall,0);
	IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	
	if( 0 == pxEvtInfo->uxEventData.eDectReleaseReason &&
			IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ON_IDLE) )
	{
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ON_IDLE);
		IFX_DECT_InitiateAutoRedial(pxEndptInfo);
	}

	return IFX_SUCCESS;
}

e_IFX_Return  IFX_DECT_BusySSMsgHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_SSMsg* pxSsMsg = (&pxEvtInfo->uxEventData.xSsMsg);
	
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
										pxEndptInfo->szEndptId);

	switch( pxSsMsg->eSSType )
	{
    case IFX_DECT_SS_RELEASE:
      {
				x_IFX_DECT_CallInfo* pxRelCall = NULL;
				x_IFX_DECT_CallInfo* pxHeldCall = NULL;

  			IFX_DECT_GetEvtInfoFromCallHdl(pxSsMsg->uiTkCallId,pxEndptInfo,&pxRelCall);
				IFX_DECT_GetLastHeldCall(pxEndptInfo,&pxHeldCall);

	      if(pxRelCall) {
          if(pxRelCall->eState != IFX_DECT_CS_BUSYSTATE){
	          IFX_CMGR_CallRelease(pxRelCall->uiCallId, IFX_TERMINATED, NULL,
	                               NULL, peReason);
          }else{
					  if( pxEndptInfo->uiBCETimerId ) {
						  IFX_TIM_TimerStop(pxEndptInfo->uiBCETimerId);
						  pxEndptInfo->uiBCETimerId = 0;
					  }
	          IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);
           }
	      	IFX_DECT_ResetCall(pxRelCall,0);

          if(pxRelCall == pxEndptInfo->pxActiveCall){
            if(!pxHeldCall)
						  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
            else{
             pxEndptInfo->pxActiveCall = pxHeldCall; 
						 IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
            }
          }
        } 
				break;
			}
		default:
			{
				 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
										pxEndptInfo->szEndptId, "Unexpected Supplementary Request");
			}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BusyRingTimerExpHdlr 
 *  Description     : This routine is called by DECT FSM when ring timer expires
 *                    in busy state. Release the active call and move to IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           : This event occurs only when there is waiting call. 
 ******************************************************************************/
e_IFX_Return IFX_DECT_BusyRingTimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
	
  /*This happens when there is a call waiting on GAP PP, and active call is
    released from remote(say at 86 sec),handset moves to busy state and RingTimer(dur:90 sec) 
    expires before BusyBCETimer(dur:5 sec)*/

	if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING)){

		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
	  if(pxEndptInfo->uiBCETimerId){
		  IFX_TIM_TimerStop(pxEndptInfo->uiBCETimerId);
		  pxEndptInfo->uiBCETimerId = 0;
	  }
	  IFX_DECT_StopTone(pxEndptInfo,pxEndptInfo->uiDTkCallId);
	  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
    printf("\n Released wait call\n");

  }else{
    /*Say in case of internal call when PP2 doesn't receive call and for the initiating PP1
      the ringback timer expires then it releases the call for PP2 in alerting state.So the PP2
      moves to busy state and then the ring timer expires for it and it comes here.*/

    /*IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_TERMINATED, 
      NULL, NULL, peReason);*/

	  IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
  	pxEndptInfo->pxActiveCall = 0;
	  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
  }
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BusyBCETimerExpHdlr 
 *  Description     : This routine is called when BCE timer (busy timer)expires.
 *                    - Ignore event if timer id is not valid.
 *                    - Call Waiting : Initiate call to handset and move to 
 *                      alerting state.
 *                    - Call on hold : If there is no call in waiting and if a 
 *                      call is held ask CM to resume call.
 *                    - If none of above condition satisfy and if 'auto redial
 *                      on idle' flag is set then do auto redial. 
 *                    Otherwise make DECT endpoint IDLE.
 *                    If none of the above condiion is met, make endpoit IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If timer-id is valid, returns IFX_SUCCESS, else returns
 *                    IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_BusyBCETimerExpHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
  x_IFX_DECT_CallInfo *pxRelCall = NULL;
  x_IFX_DECT_CallInfo *pxHeldCall = NULL;
  
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
										pxEndptInfo->szEndptId);
	if(pxEndptInfo->uiBCETimerId != pxEvtInfo->uiId)
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Wrong Timer Id" );
		return IFX_FAILURE;
	}
  pxEndptInfo->uiBCETimerId = 0;

  if(pxEndptInfo->axCallInfo[0].eState == IFX_DECT_CS_BUSYSTATE)
          pxRelCall = &pxEndptInfo->axCallInfo[0];
  else if(pxEndptInfo->axCallInfo[1].eState == IFX_DECT_CS_BUSYSTATE)
          pxRelCall = &pxEndptInfo->axCallInfo[1];

  printf("\n pxRelCall = %d\n",(uint32)((pxRelCall)?pxRelCall:0));

  printf("\n Stop Tone in BCE\n");
  if(pxRelCall == NULL)
	 IFX_DECT_StopTone(pxEndptInfo,pxEndptInfo->uiDTkCallId);
  else
	 IFX_DECT_StopTone(pxEndptInfo,pxRelCall->uiDTkCallId);
  
	IFX_DECT_GetLastHeldCall(pxEndptInfo,&pxHeldCall);

  if(!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){//GAP PP

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING) )
	{
		//Intiiate call and move to Alerting state
    IFX_DECT_CSU_VoiceModify(
		             pxEndptInfo->pxActiveCall->uiDTkCallId,
	   	    	 	   &xCallParams,
								 IFX_DECT_STOP_VOICE,
								 pxEndptInfo->unDectChannel);
			
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
		IFX_DECT_GetWaitingCallInfo(pxEndptInfo, &pxEndptInfo->pxActiveCall);

		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);
		xCallParams.bwideband = pxEndptInfo->bWidebandEnabled;
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Calling Dect Toolkit IFX_DECT_CSU_CallInitiate" );

		strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);
    xCallParams.bIsPresentation =1;
	strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
  printf("CNIP Name4:%s\n",xCallParams.acCNIP);//Don't send CLIP/CNIP in setup
        //TODO Check if pxActiveCall is filled 	
		IFX_DECT_CSU_CallInitiate (pxEndptInfo->ucInstance+1,
                         				 &xCallParams, 
                         				 (uint32)pxEndptInfo,
	                 							 (uint32 *)&pxEndptInfo->pxActiveCall->uiDTkCallId
												 ); 

    //Send Alert Signal and CLIP/CNIP.
    //IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_SIGNAL_AlertPattern0);

		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ALERTING);
	}
	else if((!pxRelCall && pxEndptInfo->pxActiveCall) || (pxRelCall && (pxRelCall == pxEndptInfo->pxActiveCall) && pxHeldCall))
	{ //Resume last held call if exist.
    if(pxRelCall && pxHeldCall){//Can js check RelCall also.
		  IFX_DECT_ResetCall(pxRelCall,0);
      pxEndptInfo->pxActiveCall = pxHeldCall;
    }
		while( 1 )
		{
		 	if( IFX_SUCCESS != IFX_DECT_ResumeCallInBusy(pxEndptInfo) )
			{
				IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
								 IFX_TERMINATED, NULL, NULL, peReason);
				IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
				IFX_DECT_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall)
			}
			else
				 break;
		} 
	}
	else if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ON_IDLE) )
	{ //Initiate auto-redial
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ON_IDLE);
		/*
		 * Notify is received when handset in busy state. So connection with handset
		 * still exist, release connection and then initaite auto redial.
		 */
		IFX_DECT_InitiateAutoRedial(pxEndptInfo);
	}
	else{
    if(pxRelCall == NULL){
		  IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,&xCallParams,
			    		                 IFX_DECT_RELEASE_NORMAL);
		  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
    }else{
      if(pxRelCall != pxEndptInfo->pxActiveCall){
			 IFX_DECT_ResetCall(pxRelCall,0);
      }else{ 
			 IFX_DECT_ResetCall(pxRelCall,1);
		   IFX_DECT_MakeDectPPIdle(pxEndptInfo);
      }
     }
	}
  
  }else{

    if(pxRelCall == NULL){
		  IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,NULL,
					    IFX_DECT_RELEASE_NORMAL);
      if(pxHeldCall == NULL){
		    /*IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,NULL,
					    IFX_DECT_RELEASE_NORMAL);*/
		    IFX_DECT_MakeDectPPIdle(pxEndptInfo);
      }else{
		    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			           pxEndptInfo->szEndptId, "Held Call Exists." );
        pxEndptInfo->pxActiveCall = pxHeldCall;
        IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
       } 
    }else{
			if(IFX_DECT_CheckEndptFlag(pxEndptInfo,(IFX_DECT_F_INTERCEPT_INIT|IFX_DECT_F_INTRUDE_INIT))){
	    	IFX_DECT_ResetCall(pxRelCall,0);
			}else{
	    	IFX_DECT_ResetCall(pxRelCall,1);
			}
      if((pxRelCall == pxEndptInfo->pxActiveCall)&&
					!(IFX_DECT_CheckEndptFlag(pxEndptInfo,(IFX_DECT_F_INTERCEPT_INIT|IFX_DECT_F_INTRUDE_INIT)))){
       if(pxHeldCall == NULL){ 
		     return IFX_DECT_MakeDectPPIdle(pxEndptInfo);
       }else{
         pxEndptInfo->pxActiveCall = pxHeldCall;
         IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
        }
      }else{
				IFX_DECT_ResetEndptFlag(pxEndptInfo,(IFX_DECT_F_INTERCEPT_INIT|IFX_DECT_F_INTRUDE_INIT));
        printf("\n pxActiveCall->eState = %d\n",pxEndptInfo->pxActiveCall->eState); 
        if(pxEndptInfo->pxActiveCall->eState == IFX_DECT_CS_RINGING){
          IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_RINGBACK);
        }else if(pxEndptInfo->pxActiveCall->eState == IFX_DECT_CS_INITIATED){ 
          IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_DIALING);
        }else{
          IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_ACTIVE);
         }
       }
     }
   }
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BusyReleaseCallHdlr 
 *  Description     : This routine is called when remote party releases call in
 *	                  busy state. If call-id is valid, release call. If it is 
 *	                  current active call, then check if there is any held call. 
 *	                  If exist, make that call as active. Else make endpoint 
 *	                  IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : If call-id is valid returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE.
 *  Notes           :
******************************************************************************/
e_IFX_Return IFX_DECT_BusyReleaseCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxRelCall = NULL;
	x_IFX_DECT_CallInfo* pxRelPrevCall = NULL;

	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
				   pxEndptInfo->szEndptId);

	IFX_DECT_GetCallInfo(pxEndptInfo, pxEvtInfo->uiId, &pxRelCall);

	if(NULL == pxRelCall){
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			       pxEndptInfo->szEndptId, "Wrong Call Id" );
		return IFX_FAILURE;
	}

	if(IFX_DECT_CS_RINGING == pxRelCall->eState)
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_WAITING);

  if(pxEndptInfo->axCallInfo[0].eState == IFX_DECT_CS_BUSYSTATE)
    pxRelPrevCall = &pxEndptInfo->axCallInfo[0];
  else if(pxEndptInfo->axCallInfo[1].eState == IFX_DECT_CS_BUSYSTATE)
    pxRelPrevCall = &pxEndptInfo->axCallInfo[1];

#ifndef TONES
   if(pxRelPrevCall != NULL){
  
	   if(pxEndptInfo->uiBCETimerId){
		   IFX_TIM_TimerStop(pxEndptInfo->uiBCETimerId);
		   pxEndptInfo->uiBCETimerId = 0;
	   }
     if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) )
	     IFX_DECT_StopTone(pxEndptInfo,pxRelPrevCall->uiDTkCallId);

    if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){
    if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){
	    IFX_DECT_ResetCall(pxRelPrevCall,1);
	    IFX_DECT_ResetCall(pxRelCall,1);
    }else{
	    IFX_DECT_ResetCall(pxRelPrevCall,0);
	    IFX_DECT_ResetCall(pxRelCall,1);
     }
		  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
    return IFX_SUCCESS;
    }
  }
  
  printf("\n pxRelCall = %d\n",(uint32)((pxRelCall)?pxRelCall:0));

  if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) )
    IFX_DECT_PlayTone(pxEndptInfo,pxRelCall->uiDTkCallId,IFX_DECT_OFF_HOOK_TONE); 

  pxRelCall->eState = IFX_DECT_CS_BUSYSTATE;
  IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_BCETimerExpired,
		       							 IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId); 
#endif
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_BusyResumeRespHdlr 
 *  Description     : This routine is called by FSM in busy state to inform the
 *	                  resume request status. If resume is not initiated on 
 *	                  active call, ignore the event.
 *	                  - Resume success : update the call state and move to 
 *	                  ACTIVE. If codec on air interface is different from the
 *	                  resumed call, request DECT stack to change codec.
 *	                  - Resume failed : release call, if there is held call, try
 *	                  to resume call. If no held call move to IDLE state.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_BusyResumeRespHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_RESUME_INITIATED ) )
	{
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_RESUME_INITIATED);
		if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
		{
			IFX_DECT_UpdateCallState(pxEndptInfo, pxEndptInfo->pxActiveCall,
						IFX_DECT_CS_ACTIVE);
			IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
			if( pxEndptInfo->eRunningCodec != pxEndptInfo->pxActiveCall->eNegCodec)
			{
				x_IFX_DECT_CSU_CallParams xCallParams = {0};
				xCallParams.bwideband = 
						IFX_DECT_IsWidebandCodec(pxEndptInfo->pxActiveCall->eNegCodec);
				//Change codec on air interface (i.e. DECT side)
				IFX_DECT_CSU_ServiceChange(
				pxEndptInfo->pxActiveCall->uiDTkCallId,
																			 &xCallParams,
																			 IFX_DECT_CSU_SC_REQUEST);
				IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
			}
		}
		else if( IFX_CMGR_STATUS_FAIL == pxEvtInfo->uxEventData.eStatus )
		{
			/* If resume fails release the call and if there is held call, try to 
				 resume it else move to IDLE state */
			IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
										 IFX_TERMINATED, NULL, NULL, peReason);
			IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
			IFX_DECT_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);//ASK: this will be null???
		 	IFX_DECT_ResumeCallInBusy(pxEndptInfo);
		}
	}

	return IFX_SUCCESS;
}

e_IFX_Return 
IFX_DECT_SendDateTimeToPP(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                      IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                      OUT e_IFX_ReasonCode* peReason )
{
  x_IFX_DECT_USU_TimeDate xTimeDate = {0};
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
				"<SendDateTimeToPP>Entry");
  IFX_DECT_GetTimeDate(&xTimeDate);
  if(IFX_SUCCESS != IFX_DECT_USU_DateTimeSync(pxEvtInfo->uiId +1,
	   &xTimeDate)){
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
	IFX_DBG_STR,
	    "Failed to Update TimeDate of PT");
  }else{
    IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
			  IFX_DBG_STR,"Updated TimeDate of PT");
  }
   
  return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_InterceptPPOnHookHdlr
 *  Description     : This routine is called when handset goes ON-HOOK in intercept 
 *	                  state. Release calls and make endpoint IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_InterceptPPOnHookHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
 
  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_InterceptDigitPressedHdlr
 *  Description     : This routine is called when handset goes ON-HOOK in intercept 
 *	                  state. Release calls and make endpoint IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_InterceptDigitPressedHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
																						pxEndptInfo->szEndptId);
 
  IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,NULL,IFX_DECT_RELEASE_NORMAL);
  IFX_DECT_MakeDectPPIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_InterceptIncomingCallHdlr
 *  Description     : This routine is called when handset goes ON-HOOK in intercept 
 *	                  state. Release calls and make endpoint IDLE.
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_InterceptIncomingCallHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
  x_IFX_DECT_EndptFsmInfo *pxCallerEndPtInfo;
	x_IFX_DECT_IncCallEvent* pxIncallEvt = (&pxEvtInfo->uxEventData.xIncCallEvt);
	x_IFX_CMGR_CallParams* pxCallParams;
//	boolean bBlocked = IFX_FALSE;
	uchar8 ucIndex = 0;
	x_IFX_DECT_CSU_CallParams xCallParams = {0};
	boolean bWidebandCall = IFX_FALSE;

	*peReason = IFX_MAX_REASON;

	pxCallParams = pxIncallEvt->pxCallParams;
	
	IFX_AGU_GetCallerIdInfo(pxIncallEvt->pxFrom, 
			pxEndptInfo->szCallerName, pxEndptInfo->szCallerNumber);
	if(strcmp(pxEndptInfo->szDialledDigits,pxEndptInfo->szCallerNumber)){
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,"NOT ALLOWED");
		return IFX_FAILURE;
	}
  
  IFX_DECT_GetEndptInfoById(pxIncallEvt->pxFrom->uxAddressInfo.szEndptId,
	                                  &pxCallerEndPtInfo);
  printf("DTK CALL ID %d\n",pxEndptInfo->uiDTkCallId);
  printf("Caller DTK CALL ID %d\n",pxCallerEndPtInfo->uiDTkCallId);
  if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL) == IFX_DECT_F_PAGE_CALL)
  {
    printf("In paging Mode ... so cancel it !!!");
    IFX_DECT_MU_PageCancel();
    IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_PAGE_CALL);
    vucCurPagingPPCount =0;
    sleep(2);
  }
	if( IFX_CMGR_TYPE_EXTN == pxIncallEvt->pxFrom->eAddressType)
	{
	  xCallParams.isInternal = IFX_TRUE;
	  xCallParams.ucPeerHandsetId = 
	          IFX_DECT_HsIdFromEPName(pxIncallEvt->pxFrom->uxAddressInfo.szEndptId);
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Peer Handset Id = ", xCallParams.ucPeerHandsetId);
	}
 /* if( bBlocked )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Incoming Call Is Blocked" );
		return IFX_FAILURE;
	}
	*/
	IFX_DECT_ConvertCodecToMMGR(&pxEndptInfo->xReservedCodecs, 
			&pxCallParams->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams);
	if( IFX_MMGR_SUCCESS !=
		IFX_MMGR_DectResAlloc(pxEndptInfo->szEndptId, 
						&pxEndptInfo->unDectChannel, &pxEndptInfo->xReservedCodecs))
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Allocate Resources For DECT ");

		*peReason = IFX_NO_RESOURCE;
		return IFX_FAILURE;
	}
	
	if(pxEndptInfo->bWidebandEnabled)
	{
		{
			if( IFX_DECT_IsWidebandCodec(
							pxEndptInfo->xReservedCodecs.axCodecs[ucIndex].eCodecType) )
			{
     		printf("%s WIDE BAND ENABLED YES",__FUNCTION__);
				bWidebandCall = IFX_TRUE;
			}
		}
	}

  IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED);
	/* Store ring timeout. This value will be used for ring timer. */
	pxEndptInfo->unRingTimeOut = IFX_RING_TONE_DURATION;
	if( pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.cRingCount ) {
		int32 iRingDur;
		
		IFX_MMGR_RingCadenceTimeGet(&iRingDur);
		pxEndptInfo->unRingTimeOut = 
			iRingDur * pxIncallEvt->pxCallParams->uxCallParams.xExtnParams.cRingCount;
	}
     
	pxEndptInfo->pxActiveCall = (pxEndptInfo->axCallInfo+0);
	pxEndptInfo->pxActiveCall->uiCallId = pxEvtInfo->uiId;
  //xCallParams.bCipheringStatus=bEncyption;
	xCallParams.bwideband = bWidebandCall;
	printf("Codec Sent during Setup %d\n",bWidebandCall);
	strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);
	if(IFX_CIF_CNIPGet(xCallParams.isInternal,pxEvtInfo->uxEventData.xIncCallEvt.ucLineId,
										pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS)
	strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
	xCallParams.ucLineId=	pxEvtInfo->uxEventData.xIncCallEvt.ucLineId;
        xCallParams.bIsPresentation =1;
  printf("CNIP Name1:%s\n",xCallParams.acCNIP);//Don't send CLIP/CNIP in setup but send for LiA Call
	/*IFX_DECT_CSU_CallInitiate (pxEndptInfo->ucInstance+1,
                         		 &xCallParams, 
                         		 (uint32)pxEndptInfo,
	                 				   (uint32 *)&pxEndptInfo->pxActiveCall->uiDTkCallId); */

  //Send Alert Signal and CLIP/CNIP.
  //IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_SIGNAL_AlertPattern0);
  pxEndptInfo->pxActiveCall->uiDTkCallId = pxEndptInfo->uiDTkCallId;
	printf("<IFX_DECT_IdleIncomingCallHdlr> Call Handle is %d\n",pxEndptInfo->pxActiveCall->uiDTkCallId);
	if( IFX_CMGR_TYPE_FXO == 
		(pxEndptInfo->pxActiveCall->eCallType = pxIncallEvt->pxFrom->eAddressType))
	{
		strcpy(pxEndptInfo->pxActiveCall->szCallInitrEndptId,
									pxIncallEvt->pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId );
	}
				
	IFX_DECT_UpdateCallState(pxEndptInfo, 
										pxEndptInfo->pxActiveCall, IFX_DECT_CS_INITIATED);	
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ALERTING);
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Waiting For Handset Response");

	*peReason = IFX_REQ_PENDING;


	if(pxCallerEndPtInfo != NULL && IFX_DECT_CheckEndptFlag(pxCallerEndPtInfo, IFX_DECT_F_INTERCEPT_INIT) ){
	  x_IFX_DECT_EventInfo evtInfo = {0};
	  e_IFX_ReasonCode eReason;
	  x_IFX_DECT_CSU_CallParams xCP = {0};
    evtInfo.eEvent = IFX_DECT_EVT_PP_OffHook;
    evtInfo.uxEventData.aunCodec[0] = IFX_DECTNG_CODEC_G726_32;
    if(pxEndptInfo->bWidebandEnabled){
  	  evtInfo.uxEventData.aunCodec[0] = IFX_DECTNG_CODEC_G722_64;
    }
	  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Codec Selected By Pp In Alert (DECT)=", evtInfo.uxEventData.aunCodec[0]);
    xCP.ucPeerHandsetId = IFX_DECT_HsIdFromEPName(pxEndptInfo->szDialledDigits);
    printf("Intercepted HS Id %d\n",xCP.ucPeerHandsetId);
		IFX_DECT_CSU_ExplicitConnect(pxEndptInfo->uiDTkCallId,&xCP);
	  IFX_DECT_FsmHdlr_1(pxEndptInfo, &evtInfo, &eReason);
  }

	return IFX_SUCCESS;
}


/*******************************************************************************
 * vax_IFX_DECTFsm - This is FSM table for DECT endpoint.
*******************************************************************************/
pfn_IFX_DECT_Fsm vax_IFX_DECTFsm[IFX_DECT_STATE_MAX][IFX_DECT_EventMax] =
{
	//IFX_DECT_STATE_IDLE,             /** Idle */
	{
	  IFX_DECT_IdlePPOffHookHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IdleIncomingCallHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IdlePagingHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IdlePPInterceptHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_DIALING,          /** Outcall - Dialing */
	{
	  IFX_DECT_DialingPPOffHookHdlr,               //IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_DialingPPOnHookHdlr,      //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,               //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,               //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_DialingHookFlashHdlr,     //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_DialingDigitPressedHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_DialingSSMsgHdlr,         //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_ServiceChangeHdlr,        //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_SlotModIndHdlr,           //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_CipherStatusHdlr,         //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_DialingDialTimerExpHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_DialingInterDigitTimerExpHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IgnoreCallHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_DialingCallReleaseHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_DialingRmtAcceptHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_DialingRmtAnswerHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_EventNotHandledHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_EventNotHandledHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_DialingResumeRespHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_DialingBtxRespHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_DialingConfStatusHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_RINGBACK,         /** Outcll - Ringback */
	{
	  IFX_DECT_IgnoreHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_RingbackPPOnHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_RingbackPPHookFlashHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_RingbackSSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_ServiceChangeHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_SlotModIndHdlr,         //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_RingbackRbTimerExpHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IgnoreCallHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_DialingCallReleaseHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_RingbackRmtAcceptHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_DialingRmtAnswerHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_ALERTING, /** Incall - Alerting (ringing) */
	{
	  IFX_DECT_AlertingPPoffHookHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_AlertingPPonHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_AlertingAlertRecvHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_AlertingRejectRecvHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_AlertingSSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_ServiceChangeHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_SlotModIndHdlr,         //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_CipherStatusHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_AlertingRingTimerExpHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_AlertingPauseTimerExpHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IgnoreCallHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_AlertingReleaseCallHdlr,  //IFX_DECT_EVT_ReleaseCall

	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_AlertingPagingHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_ACTIVE,           /** Call active/in conversation */
	{
	  IFX_DECT_IgnoreHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_ActivePPOnHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_ActivePPHookFlashHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_ActiveDigitPressedHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_ActiveSSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_ServiceChangeHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_SlotModIndHdlr,         //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_CipherStatusHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_ActiveIncomingCallHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_ActiveReleaseCallHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_EventNotHandledHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_EventNotHandledHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_ActiveHoldRespHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
		IFX_DECT_ActiveConfStatusHdlr,//IFX_DECT_EVT_ConfStatus
	  //IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_CALL_WAITING,     /** Call Waiting */
	{
	  IFX_DECT_IgnoreHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_CwPPOnHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_ActivePPHookFlashHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_CwDigitPressedHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_CwSSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_IgnoreHdlr,   //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_IgnoreHdlr,   //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,   //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,   //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_CwRingTimerExpHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_CwReleaseCallHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_EventNotHandledHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_EventNotHandledHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_ActiveHoldRespHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_CONFERENCE,       /** Conferene */
	{
	  IFX_DECT_IgnoreHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_ConfPPOnHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_ConfPPHookFlashHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_ActiveDigitPressedHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_ConfSSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_ConfReleaseCallHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_ConfStatusHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
	//IFX_DECT_STATE_BUSY,     /** Service Call -SMS/Info send or recv */
	{
	  IFX_DECT_IgnoreHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_BusyPPOnHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_BusySSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_BusyRingTimerExpHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_BusyBCETimerExpHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_BusyReleaseCallHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_BusyResumeRespHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},
  //IFX_DECT_STATE_INTERCEPT,     /** Service Call -SMS/Info send or recv */
	{
	  IFX_DECT_IgnoreHdlr, 	//IFX_DECT_EVT_PP_OffHook
	  IFX_DECT_InterceptPPOnHookHdlr,  //IFX_DECT_EVT_PP_OnHook
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Alert
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_Reject
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_HookFlash
	  IFX_DECT_InterceptDigitPressedHdlr,  //IFX_DECT_EVT_PP_DigitPressed
	  IFX_DECT_ActiveSSMsgHdlr,  //IFX_DECT_EVT_PP_SSMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SCMsg
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_PP_SlotModInd
#ifdef ENABLE_ENCRYPTION
		IFX_DECT_CipherStatusHdlr,         //IFX_DECT_EVT_PP_CipherStatus
#endif
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_DialTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_InterDigitTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingpauseTimerExpired
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RingbackTimerExpired
	  IFX_DECT_BusyBCETimerExpHdlr,  //IFX_DECT_EVT_BCETimerExpired
	  IFX_DECT_InterceptIncomingCallHdlr,  //IFX_DECT_EVT_IncomingCall
	  IFX_DECT_BusyReleaseCallHdlr,  //IFX_DECT_EVT_ReleaseCall
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAccept
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtAnswer
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtHold
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_RmtResume
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_HoldResp
	  IFX_DECT_BusyResumeRespHdlr,  //IFX_DECT_EVT_ResumeResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_BtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_AtxResp
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_ConfStatus
	  IFX_DECT_IgnoreHdlr,  //IFX_DECT_EVT_Paging
	  IFX_DECT_SendDateTimeToPP, //IFX_DECT_EVT_Attached
	  IFX_DECT_IgnoreHdlr, //IFX_DECT_EVT_Intercept
	},

};

/*******************************************************************************
 *  Function Name   : IFX_DECT_FsmHdlr
 *  Description     : This routine invokes DECT FSM using given event. 
 *  Input Values    : Please see pfn_IFX_DECT_Fsm for parameter details. 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS - If DECT FSM processes event successfuly.
 *	                  IFX_FAILURE - On Error.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_FsmHdlr_1(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	pfn_IFX_DECT_Fsm pfnFsmHandler = 0;
	e_IFX_Return eRet = IFX_SUCCESS;
	
	/* IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			IFX_DECT_GetStateStr(pxEndptInfo->eState), 
			IFX_DECT_GetEventStr(pxEvtInfo->eEvent)); */
  printf("\n Call Info[0] = %x, Call State 0 = %d",(uint32)&pxEndptInfo->axCallInfo[0],pxEndptInfo->axCallInfo[0].eState);
  printf("\n Call Info[1] = %x, Call State 1 = %d",(uint32)&pxEndptInfo->axCallInfo[1],pxEndptInfo->axCallInfo[1].eState);
	if( pxEvtInfo->eEvent >= IFX_DECT_EventMax )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Invalid Event....");	
		return eRet;
	}
  if(viDectStackMode == IFX_DECT_SYNC_MODE && pxEndptInfo->eState >=0 && pxEndptInfo->eState < IFX_DECT_STATE_MAX){
	  pfnFsmHandler = vax_IFX_DECTFsm[pxEndptInfo->eState][pxEvtInfo->eEvent];
	  eRet = pfnFsmHandler(pxEndptInfo,pxEvtInfo,peReason);
  }else{
    x_IFX_DECT_IntFifoMsg xIntMsg={0};
    xIntMsg.pxEndptInfo = pxEndptInfo;
    memcpy(&xIntMsg.xEvtInfo,pxEvtInfo,sizeof(x_IFX_DECT_EventInfo));
    printf("Posting to Internal Fifo and the endpoint is %d\n", (uint32)pxEndptInfo);
    WriteFifo(viAgentFifoFd,&xIntMsg,sizeof(x_IFX_DECT_IntFifoMsg)); 
  }
	return eRet;
}

e_IFX_Return IFX_DECT_FsmHdlr(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                  IN x_IFX_DECT_EventInfo* pxEvtInfo,
	                  OUT e_IFX_ReasonCode* peReason )
{
	pfn_IFX_DECT_Fsm pfnFsmHandler = 0;
	e_IFX_Return eRet = IFX_SUCCESS;
	
	 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			IFX_DECT_GetStateStr(pxEndptInfo->eState), 
			IFX_DECT_GetEventStr(pxEvtInfo->eEvent)); 

  printf("\n Call Info[0] = %x, Call State 0 = %d",(uint32)&pxEndptInfo->axCallInfo[0],pxEndptInfo->axCallInfo[0].eState);
  printf("\n Call Info[1] = %x, Call State 1 = %d",(uint32)&pxEndptInfo->axCallInfo[1],pxEndptInfo->axCallInfo[1].eState);
	if( pxEvtInfo->eEvent >= IFX_DECT_EventMax )
	{
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Invalid Event....");	
		return eRet;
	}
	if(pxEndptInfo->eState >=0 && pxEndptInfo->eState < IFX_DECT_STATE_MAX)
	pfnFsmHandler = vax_IFX_DECTFsm[pxEndptInfo->eState][pxEvtInfo->eEvent];
	if(pfnFsmHandler != NULL)
		eRet = pfnFsmHandler(pxEndptInfo,pxEvtInfo,peReason);
	return eRet;
}

/*---------------------------- Utility Routines -----------------------------*/
/*******************************************************************************
 *  Function Name   : IFX_DECT_HsIdFromEPName
 *  Description     : This routine used to get endpoint info using endpoint id.
 *  Input Values    : szEndptId - DECT Endpoint id
 *  Output Values	  : ppxEndPtInfo -  If szEndptId matches with attached DECT 
 *	                  handset, pointer DECT endpoint info is returned in this.
 *  Return Value    : If endpoint is found returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
char8 IFX_DECT_HsIdFromEPName(IN char8* szEndptId)
{
	uchar8 ucIndex = 0;
	printf("Enter EPName\n");
	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
		if(strcmp(vaxDectEndptFsmInfo[ucIndex].szEndptId, szEndptId) == 0)
		{
			break;
		}
	}	
	if(ucIndex == IFX_MMGR_MAX_DECT_CHANNELS){
	  return -1;
	}
	return ucIndex+1;
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEndptName
 *  Description     : This routine returns End point Id based on Handset Id.
 *  Input Values    : Handset Id
 *  Output Values	  : Endpoint Id - String 
 *  Return Value    : IFX_SUCCESS / IFX_FAILURE
 *  Notes           :
 ******************************************************************************/

e_IFX_Return IFX_DECT_GetEndptName(IN uchar8 ucHandSetId,
																	 OUT char8 *szEndptId)
{
	if(szEndptId && ucHandSetId > 0 && ucHandSetId < IFX_DECTAPP_MAX_DECT_ENDPTS)  {

	  strcpy(szEndptId,vaxDectEndptFsmInfo[ucHandSetId-1].szEndptId);
		return IFX_SUCCESS;
	}
		return IFX_FAILURE;
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEndptInfoById
 *  Description     : This routine used to get endpoint info using endpoint id.
 *  Input Values    : szEndptId - DECT Endpoint id
 *  Output Values	  : ppxEndPtInfo -  If szEndptId matches with attached DECT 
 *	                  handset, pointer DECT endpoint info is returned in this.
 *  Return Value    : If endpoint is found returns IFX_SUCCESS, else returns
 *	                  IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_GetEndptInfoById(
	                                  IN char8* szEndptId,
	                                  OUT x_IFX_DECT_EndptFsmInfo **ppxEndPtInfo)
{
	uchar8 ucIndex = 0;
	*ppxEndPtInfo = 0;

	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
		if(strcmp(vaxDectEndptFsmInfo[ucIndex].szEndptId, szEndptId) == 0)
		{
			*ppxEndPtInfo = (vaxDectEndptFsmInfo+ucIndex);
			break;
		}
	}	
	return (*ppxEndPtInfo != 0)?IFX_SUCCESS:IFX_FAILURE;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEndptInfoByInstance
 *  Description     : This routine is used to retrive DECT endpoint info using
 *	                  DECT instance number.
 *  Input Values    : ucInstance - DECT instance number
 *  Output Values	  : ppxEndPtInfo - If instance number is valid, pointer to
 *	                  DECT endpoint info is returned in this variable.
 *  Return Value    : If instance number is valid, returns IFX_SUCCESS, else
 *	                  returns IFX_FAILURE.
 *  Notes           : This is used when message is received from DECT stack.
 ******************************************************************************/
e_IFX_Return IFX_DECT_GetEndptInfoByInstance(
														 IN uchar8 ucInstance,
														 OUT x_IFX_DECT_EndptFsmInfo **ppxEndPtInfo )
{
	uchar8 ucIndex = 0;
	*ppxEndPtInfo = 0;

	if( ucInstance == IFX_DECT_INVALID_INSTANCE )
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Wrong Instance Number" );
		return IFX_FAILURE;
	}

	for( ; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex )
	{
		if(vaxDectEndptFsmInfo[ucIndex].ucInstance == ucInstance)
		{
			*ppxEndPtInfo = (vaxDectEndptFsmInfo+ucIndex);
			break;
		}
	}	
	
	return (*ppxEndPtInfo != 0)?IFX_SUCCESS:IFX_FAILURE;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_FsmTimerFired 
 *  Description     : This is callback function registered with timer module to
 *                    get timer expiry event. If this event is valid then DECT
 *	                  FSM is invoked with proper event info.
 *  Input Values    : uiTimerId - Expired timer-id.
 *	                  pvPrivateData - Pointer to private data that is passed to
 *                      while starting timer. 
 *  Output Values	  : 
 *  Return Value    : None 
 *  Notes           : This is used only for DECT FSM timers.
 ******************************************************************************/
void IFX_DECT_FsmTimerFired(
								IN uint32 uiTimerId,
								IN void* pvPrivateData)
{
	x_IFX_DECT_TimerEvent* pxTimerEvt;
	printf("TimerId FsmTimerFired---%d\n",uiTimerId); 

	pxTimerEvt = (x_IFX_DECT_TimerEvent*)(pvPrivateData);

	if( strlen(pxTimerEvt->pxEndptInfo->szEndptId) &&
			IFX_TRUE == pxTimerEvt->pxEndptInfo->bPPAttached )
	{
		x_IFX_DECT_EventInfo xEvtInfo = {0};
		e_IFX_ReasonCode reason;

		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxTimerEvt->pxEndptInfo->szEndptId,
				IFX_DECT_GetEventStr(pxTimerEvt->eTimerEvent) );
		
		xEvtInfo.eEvent = pxTimerEvt->eTimerEvent;
		xEvtInfo.uiId = uiTimerId;
		
		if( IFX_SUCCESS != 
				IFX_DECT_FsmHdlr(pxTimerEvt->pxEndptInfo,&xEvtInfo,&reason) )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxTimerEvt->pxEndptInfo->szEndptId,
					"FAILED : Timer Event Failed");
		}
	}

	return ;
}



/*******************************************************************************
 *  Function Name   : IFX_DECT_ExecuteDialPlan 
 *  Description     : This routine is called to execute the dial plan actions.
 *                    Depending on action this routine initiates a call, transfer
 *                    conference etc...  
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *	                  eDpAction   - Dial plan action to be processed.
 *	                  pszDialOut  - Pointer to string returned by Dial Plan 
 *	                                (IFX_DP_Match)
 *  Output Values	  : pucSignal   - Signal to be sent to DECT handset.(i.e. tone
 *	                   to be played on DECT). If IFX_DECT_INVALID_TONE is 
 *	                   returned, then no tone should be played on handset.
 *	                  peState     - FSM state to be updated. If state returned  
 *	                   is IFX_DECT_STATE_MAX, then there is no change in FSM 
 *	                   state.
 *  Return Value    : 
 *  Notes           : Before calling this routine dial string that use enetered
 *	                  must be passed to IFX_DP_Match. If action returned is 
 *	                  IFX_DP_DIALOUT, then call this routine.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ExecuteDialPlan(
                      IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                      IN e_IFX_DP_Action eDpAction,
                      IN char8 *pszDialOut,
                      OUT uchar8* pucSignal,
                      OUT e_IFX_DECT_States* peState)
{
	x_IFX_CMGR_AddressInfo* pxDialedAddr = NULL;
	x_IFX_CMGR_AddressInfo xCmgrAddr = {0};
	x_IFX_CalledAddr xAddress;

	char8 szTempDialOut[IFX_MAX_DIGITS];

	//uchar8 ucChangeDefaultVL=0;
	uchar8 ucAction = 0;
	uint16 unTimeOut = 0;
	boolean bEmergencyCall = IFX_FALSE;
	boolean bMakeCall = IFX_FALSE;
	boolean bEnable = IFX_FALSE;
	boolean bRunDpPlan = IFX_FALSE;
  
	e_IFX_CMGR_Status  eStatus;
	e_IFX_TransferStatus eTxStatus;
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_CMGR_FeatStatus eCidStatus = IFX_CMGR_DONT_CARE;

	*pucSignal = IFX_DECT_INVALID_TONE;
	*peState = IFX_DECT_STATE_MAX;

	/*  IFX_DP_CALLWAITING_PERCALL_ACTV - not supported */

	/* Check if need to call IFX_DP_Match again. */
	printf("<ExecDP> DP Action =%d \n",eDpAction);
	if( IFX_DP_CALLWAITING_PERCALL_ACTV == eDpAction||
			IFX_DP_CALLWAITING_PERCALL_DEACTV == eDpAction ||
			IFX_DP_CID_BLOCK_PERCALL_DEACTV	== eDpAction ||
			IFX_DP_CID_BLOCK_PERCALL_ACTV == eDpAction )
	{
		bRunDpPlan = IFX_TRUE;
	}
#if 0
	else if(IFX_DP_NON_DEFAULT_VL_DIAL == eDpAction)
	{	
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId, "Dial Through Non Default Voice Line");
		ucChangeDefaultVL = pszDialOut[0];
		pszDialOut++;
		bRunDpPlan =  (strlen(pszDialOut) > 0 )?IFX_TRUE:IFX_FALSE ;
	}
#endif
	if( bRunDpPlan )
	{
		x_IFX_DP_Rule xDpRule;

		strcpy(szTempDialOut,pszDialOut);
		eRet = IFX_DP_Match(szTempDialOut, IFX_TRUE, &ucAction, pszDialOut, 
												&xDpRule, &unTimeOut );
		if( IFX_SUCCESS != eRet || (IFX_DP_DIALOUT != ucAction ) )
		{
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Dial Plan Error");
			return IFX_FAILURE;
		}

		if( IFX_DP_CALLWAITING_PERCALL_DEACTV == eDpAction )
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_REJECT_CW_CALL);
		else if( IFX_DP_CID_BLOCK_PERCALL_ACTV == eDpAction ) 
			eCidStatus = IFX_CMGR_DISABLE; 
		else if( IFX_DP_CID_BLOCK_PERCALL_DEACTV == eDpAction )
			eCidStatus = IFX_CMGR_ENABLE; 
		
		eDpAction = xDpRule.eAction;
	}
	
	/* 
	 * IFX_DP_CALLWAITING_REJECT is hanlded in call waiting state ( see 
	 * IFX_DECT_CwInterDigitTimerExpiryHdlr )
	 */
	eRet = IFX_FAILURE;
	switch( eDpAction )
	{
	 case IFX_DP_ANON_CALLBLOCK_ACTV:
	 case IFX_DP_ANON_CALLBLOCK_DEACTV:
     {
			 /* Activate or deactivate anonymous call block */
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
		       pxEndptInfo->szEndptId, 
					 "DP Action : Anonymous Call block Enable/Disable");
       bEnable = (IFX_DP_ANON_CALLBLOCK_ACTV == eDpAction)?IFX_TRUE:IFX_FALSE;
       if( IFX_SUCCESS == (eRet = IFX_CIF_EndptAnonymousCallBlockSet(
																		pxEndptInfo->szEndptId, bEnable,&eReason)) )
			 {
				 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 *peState = IFX_DECT_STATE_BUSY;	 
			 }
       break;
     }		 
	 case IFX_DP_DND_ACTV:
	 case IFX_DP_DND_DEACTV:
		 {
	 		 /* Activate/deactivate DND */
		 	 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndptId, "DP Action : DND Enable/Dissble");
			 bEnable = ( IFX_DP_DND_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
		
			 if( IFX_SUCCESS == (eRet = IFX_CIF_EndptDNDStatusSet( 
							 								pxEndptInfo->szEndptId, bEnable,&eReason)) )
			 {
				 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 *peState = IFX_DECT_STATE_BUSY;	 
			 }
	 		 break;
		} 
	 case IFX_DP_CALLWAITING_ACTV:
	 case IFX_DP_CALLWAITING_DEACTV:
		 {
			 /* Activate/Deactivate call waiting */
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId,
					"DP Action : Call Waiting Activate/DeActivate");
			 bEnable = ( IFX_DP_CALLWAITING_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;

			 if( IFX_SUCCESS == (eRet = IFX_CIF_EndptCallWaitingSet(
					 											pxEndptInfo->szEndptId, bEnable,&eReason)) )
			 {
				 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 *peState = IFX_DECT_STATE_BUSY;	 
			 }
			 break;
		 }
	 case	IFX_DP_UNC_CFWD_ACTV:
	 case	IFX_DP_UNC_CFWD_DEACTV:
	 case	IFX_DP_BUSY_CFWD_ACTV:
	 case	IFX_DP_BUSY_CFWD_DEACTV:
	 case	IFX_DP_NOANS_CFWD_ACTV:
	 case	IFX_DP_NOANS_CFWD_DEACTV:
		 {
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId,
					"DP Action : Call Forward Activate/DeActivate");
			 if( IFX_SUCCESS == (eRet = IFX_AGU_SetCallForward(
						pxEndptInfo->szEndptId, eDpAction, pszDialOut, vucDectAgnetModId)) )
			 {
				 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 *peState = IFX_DECT_STATE_BUSY;	 
			 }
			 break;
		 }
	 case	IFX_DP_CID_BLOCK_ACTV:
	 case	IFX_DP_CID_BLOCK_DEACTV:
		 {
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId,
					"DP Action : CID Activate/DeActivate");
			 bEnable = (IFX_DP_CID_BLOCK_ACTV == eDpAction )?IFX_FALSE:IFX_TRUE;
			 if( IFX_SUCCESS == (eRet = IFX_CIF_EndptCidStatusSet(
							 										pxEndptInfo->szEndptId, bEnable,&eReason)) )
			 {
				 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 *peState = IFX_DECT_STATE_BUSY;	 
			 }
			 break;
		 }
	#if DIAL_PLAN_REMOVE 
	case IFX_DP_DEF_OUTBOUND_INTERFACE_VOIP:
	 case IFX_DP_DEF_OUTBOUND_INTERFACE_PSTN:
		 {
		 	 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId,
					"DP Action : Default Outbund Interface set");

			 ucAction = (IFX_DP_DEF_OUTBOUND_INTERFACE_VOIP==eDpAction)?0:1;
			 if( IFX_SUCCESS == (eRet = IFX_CIF_DefaultOutBoundIfSet(
					pxEndptInfo->szEndptId, ucAction,&eReason)) )
			 {
				 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 *peState = IFX_DECT_STATE_BUSY;	 
			 }
			 break;
		 }
	#endif
	 case IFX_DP_AUTO_REDIAL_ACTV:
	 case IFX_DP_AUTO_REDIAL_DEACTV:
		 {
			 /* 
				* Activate or deactivate auto redial. This action is allowed only if
				* last dialed number is VoIP address.
				*/
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,	IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, 
					"DP Action : Auto Redail Activate/DeActivate");
			 bEnable = (IFX_DP_AUTO_REDIAL_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
			 if( IFX_SUCCESS == 
					 (eRet = IFX_DECT_ActDeActvAutoRedial(pxEndptInfo, bEnable)) )
			 {
				 //*pucSignal = IFX_DECT_CONFIRMATION_TONE;
				 //*peState = IFX_DECT_STATE_BUSY;	 
			 }
			 break;
		 }
#if DIAL_PLAN_REMOVE 
	 case IFX_DP_NON_DEFAULT_VL_DIAL:
		 {
		 		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "DP Action : Change Default Voice Line");
		 		if(	IFX_SUCCESS == (eRet = IFX_CIF_EndptDefaultVLSet(
						pxEndptInfo->szEndptId, ucChangeDefaultVL, &eReason)))
				{
					*pucSignal = IFX_DECT_CONFIRMATION_TONE;
					*peState = IFX_DECT_STATE_BUSY;	 
				}
			 break;
		 }
#endif
	 case IFX_DP_BLIND_TX: /* blind transfer */
		 {
			 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "DP Action : Blind Transfer");
       /*If Catiq 2.0 HS tries to do a Blind Tx using *98,clear digits and return*/
       if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){// Catiq 2.0 Handset
        memset(pszDialOut,0,IFX_MAX_DIGITS);
        return IFX_FAILURE;
       }

			 if( pxEndptInfo->pxActiveCall )
			 {
				 eRet = IFX_AGU_BlindTransfer(pxEndptInfo->szEndptId, 
							 												pxEndptInfo->pxActiveCall->uiCallId, 
																			pszDialOut, vucDectAgnetModId, &eTxStatus);
				 if( IFX_SUCCESS == eRet )
				 {
					 if( IFX_CMGR_TRANSFER_ANSWERED == eTxStatus )
					 {
						 //This happens only if auto answer mode is set on FXS.
						 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, 
								 IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId, 
								 													"Blind Transfer Successful");
						 IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxEndptInfo->pxActiveCall);
						 *pucSignal = IFX_DECT_CONFIRMATION_TONE;
						 *peState = IFX_DECT_STATE_BUSY;	 
					 }
					 else //Transfer initiated
					 {
						 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, 
								 IFX_DBG_ATA_STRING_INFO, pxEndptInfo->szEndptId, 
								 													"Blind Transfer Initiated");
						 IFX_DECT_UpdateCallState(pxEndptInfo, pxEndptInfo->pxActiveCall, 
								 																					IFX_DECT_CS_TX_INITIATED);
						 IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_TRANSFER_INITIATED);
					 }
				 }
			 }
			 else
			 {
		 			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId, 
							"Blind Transfer : There Is No Call To Transfer");
			 }
			 break;
		 }
#if DIAL_PLAN_REMOVE
case IFX_DP_PSTN_HOOKFLASH: /* PSTN hook flash */
		 {
			 /*
			  * If call is PSTN, resume call, send info to FXO and go to conversation state. 
			  */
			 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : PSTN Hook-Flash");
			 if( pxEndptInfo->pxActiveCall && 
				 IFX_CMGR_TYPE_FXO == pxEndptInfo->pxActiveCall->eCallType )
			 {
					x_IFX_CMGR_AddressInfo xToAddr = {0};

					xToAddr.eAddressType = IFX_CMGR_TYPE_FXO;
					strcpy(xToAddr.uxAddressInfo.xFxoInfo.szFxoLineId, 
													pxEndptInfo->pxActiveCall->szCallInitrEndptId );
					xCmgrAddr.eAddressType = IFX_CMGR_TYPE_EXTN;
					strcpy(xCmgrAddr.uxAddressInfo.szEndptId, pxEndptInfo->szEndptId);

			 		if( IFX_SUCCESS == 
							IFX_CMGR_InfoSnd(&xCmgrAddr,&xToAddr, NULL, 0, &eStatus, &eReason ) 
							&& IFX_CMGR_STATUS_SUCCESS == eStatus )
					{
						/* 
						 * IFX_CMGR_CallResume should never return pending status. 
						 * Pending status is not expected in this scenario. 
						 */
						eRet =  IFX_CMGR_CallResume(
								pxEndptInfo->pxActiveCall->uiCallId, &eStatus, &eReason ); 
#ifdef DEV_DEBUG
						if( IFX_SUCCESS == eRet && IFX_CMGR_STATUS_SUCCESS == eStatus )
						{
#endif
							IFX_DECT_UpdateCallState(pxEndptInfo,
								pxEndptInfo->pxActiveCall, IFX_DECT_CS_ACTIVE);
				 			*peState = IFX_DECT_STATE_ACTIVE; 
#ifdef DEV_DEBUG
						}
						else
						{
							IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO, 
								pxEndptInfo->szEndptId, "!! Error While Resuming Call !!");
						}
#endif
					}
					
					IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO, 
							pxEndptInfo->szEndptId, 	( IFX_SUCCESS == eRet )?
						"PSTN Hook Flash - Success":"PSTN Hook-Flash - Failed" );
			 }
			 break;
		 }
#endif
	 case IFX_DP_DISCONNECT_LASTACTV_CALLL:
		 {
			 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Disconnect Last Active Call");
			 if( pxEndptInfo->pxActiveCall )
			 {
					eRet = IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
										IFX_TERMINATED, NULL, NULL, &eReason);
          //Rule not used currently.Timer can be started to release active call when needed.
					IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
					IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxEndptInfo->pxActiveCall);
					*pucSignal = IFX_DECT_CONFIRMATION_TONE;
					*peState = IFX_DECT_STATE_BUSY;	 
					eRet = IFX_SUCCESS; /* Call release always treat as success */
			 }
			 break;
		 }
	 case IFX_DP_RESUME_LASTACTV_CALLL:
	 case IFX_DP_RESUME_NON_LASTACTV_CALLL:
		 {
			 x_IFX_DECT_CallInfo* pxCallToBeResumed;
			 
			 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Resume Call");
			 if( IFX_DP_RESUME_LASTACTV_CALLL == eDpAction)
				 pxCallToBeResumed = pxEndptInfo->pxActiveCall;
			 else
			 {
				 if( pxEndptInfo->pxActiveCall == (pxEndptInfo->axCallInfo + 0))
					 pxCallToBeResumed = (pxEndptInfo->axCallInfo + 1);
				 else
					 pxCallToBeResumed = (pxEndptInfo->axCallInfo + 0);
			 }
			 eRet = IFX_DECT_CallResume(pxEndptInfo, pxCallToBeResumed);
			 break; 
		 }
	 case IFX_DP_CONFERENCE:
		 {
			 IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Conference");
			 eRet = IFX_DECT_MakeConference(pxEndptInfo);
			 break;
		 }
	 case IFX_DP_CALL_RETURN: /* call return */
		 {
		 		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "DP Action : Call Return");
				if(	IFX_SUCCESS == IFX_CIF_CallReturnAddrGet(
						pxEndptInfo->szEndptId, &xCmgrAddr, &eReason ) )
				{
			 		bMakeCall = IFX_TRUE;
					memcpy(&pxEndptInfo->xLastDialedAddr,&xCmgrAddr,sizeof(xCmgrAddr));
					pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
				}
			 break;
		 }
	 case IFX_DP_VOICEMAIL_RETRIVAL: /* voice mail retrieval */
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Voice Mail Retrieve");
			 if( IFX_SUCCESS == IFX_CIF_EndptVMRetrievalAddrGet(
					 pxEndptInfo->szEndptId, &xAddress, &eReason ) )
			 {
					bMakeCall = IFX_TRUE;
					/* Note that voice mail address is not used for auto redial */
					pxDialedAddr = &xCmgrAddr;
					memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
					pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
					memcpy(&pxDialedAddr->uxAddressInfo.xVoipAddr,
								 &xAddress,sizeof(x_IFX_CMGR_VoipAddr));
			 }
			 break;
		 }
	 case IFX_DP_SPEED_DIAL:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Dial Through Address Book");
			 
			 if( IFX_SUCCESS == IFX_CIF_AddrBookEntryGet(pszDialOut, 
					 &pxEndptInfo->xLastDialedAddr, &eReason))
			 {
				 bMakeCall = IFX_TRUE;
				 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 }
			 break;
		 }
#if DIAL_PLAN_REMOVE	
 case IFX_DP_DIRECT_IP_CALLS:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Direct IP Dialing");
			 strcpy(szTempDialOut, pszDialOut);
			 if( IFX_SUCCESS !=  (eRet = IFX_ConvertIPAddr(szTempDialOut, pszDialOut)))
				 break;
		 }
	 case IFX_DP_SERV_SIDE_CFG:
	 case IFX_DP_LOCAL_VOIP_CALLS:
	 case IFX_DP_ISD_VOIP_CALLS:
	 case IFX_DP_STD_VOIP_CALLS:
		 {
			 char8* pszDomain;
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : VoIP Call");
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, pszDialOut);

			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;

			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pszDomain = strchr(pszDialOut,'@');
			 if( pszDomain )
			 {
					strncpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName,pszDialOut, 
							pszDomain-pszDialOut);
					pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName
																			[pszDomain-pszDialOut] = '\0';
					++pszDomain;
				 pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = 
					 ((IFX_DP_DIRECT_IP_CALLS == eDpAction)?IFX_IP_ADDR:IFX_SIP_URL);
				 strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acCalledAddr, pszDomain); 
			 }
			 else
			 { //If no domain name, use Voip Address type as IFX_EXTN
				 pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = 
					 ((IFX_DP_SERV_SIDE_CFG == eDpAction)?IFX_EXTN:IFX_TEL_NUM);
				 strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName, pszDialOut);
				 pxDialedAddr->uxAddressInfo.xVoipAddr.acCalledAddr[0] = '\0'; 
			 }
			 
			 break;
		 }
#endif
	 case IFX_DP_EMERGENCY_CALLS:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndptId, "DP Action : Emergency Call" );
			 IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_EMG_CALL_PROCEDING);
			 bEmergencyCall = IFX_TRUE;
		 }
	 case IFX_DP_TWO_STAGE_PSTN_DIALING:
	 case IFX_DP_LOCAL_PSTN_CALLS:
#if DIAL_PLAN_REMOVE 
	 case IFX_DP_STD_PSTN_CALLS:
	 case IFX_DP_ISD_PSTN_CALLS:
#endif
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
                 pxEndptInfo->szEndptId, "DP Action : PSTN Call" );
			 
			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_FXO;
			 strcpy(pxDialedAddr->uxAddressInfo.xFxoInfo.szPhoneNumber, pszDialOut);
			 break;
		 }
	 case IFX_DP_DIALDEFAULT_DEF_IF:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Dial Using Default Interface");
			 if( IFX_SUCCESS == IFX_CIF_DefaultOutBoundIfGet(
						pxEndptInfo->szEndptId, &ucAction, &eReason) )
			 {
				 bMakeCall = IFX_TRUE;
				 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
				 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
         printf("\n ucAction=%d\n",ucAction); 
				 if( ucAction )
				 {
					 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_FXO;
					 strcpy(pxDialedAddr->uxAddressInfo.xFxoInfo.szPhoneNumber, pszDialOut);
				 }
				 else
				 {
					 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
					 pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = IFX_TEL_NUM;
					 strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName, pszDialOut);
				 }
			 }
			 break;
		 }
	 case IFX_DP_EXTENSION_DIAL:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Extension Call");
			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
			 strcpy(pxDialedAddr->uxAddressInfo.szEndptId, pszDialOut);
			 break;
		 }
		case IFX_DP_NON_DEFAULT_VL_DIAL:
		{
		  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Star Dialing");
		  bMakeCall = IFX_TRUE;
		  pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
		  memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
		  pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
		  strcpy(pxDialedAddr->uxAddressInfo.szEndptId,"*");

		}
		break;

	 default:
		 {
			 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "DP Action : Unknown Dial Plan Action");
		 }
	} /* switch */

	/* 
	 * If bMakeCall is true need to initiate call. Before initiating call, If 
	 * auto redial was requested by user, cancel it. Check outgoing call bar for
	 * non-emergency calls. Don't make call if outgoing calls are barred. If 
	 * outgoing calls are not bared, initiate call. If initiate call fails, 
	 * return failure. On success, move to ringback state if remote endpoint 
	 * status is ringing or else move to conversation state.
	 *
	 * If call is not initiated or failed, reset emergency & reject waiting call 
	 * flag if set
	 */
	if( bMakeCall )
	{
		boolean bOutCallBar = IFX_FALSE;
		
		if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT))
			IFX_DECT_ActDeActvAutoRedial(pxEndptInfo,IFX_FALSE);

		/* Check outgoing call bar, except emergency & extension calls */
		if( IFX_FALSE == bEmergencyCall && IFX_DP_EXTENSION_DIAL != eDpAction) {
						
			IFX_CIF_OutgoingCallBlockCheck(pxEndptInfo->szEndptId, 
																		&bOutCallBar, &eReason);
		}

		if( IFX_FALSE == bOutCallBar )
		{
			//uchar8 ucOrgDefaultVL = 0;
			uchar8 ucDefaultLineId = 0;
			uchar8 ucLineId = 0;
			eRet = IFX_SUCCESS;
#if 0
			if( ucChangeDefaultVL )
			{
				/* 
				 * Set default voice line to ucChangeDefaultVL and after initiating
				 * call change back to actual default voice line.
				 */
				IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, 
																				&ucOrgDefaultVL, &eReason);
				eRet = IFX_CIF_EndptDefaultVLSet(pxEndptInfo->szEndptId, 
																				ucChangeDefaultVL, &eReason);
			}
#endif
				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->uiDTkCallId); 

        /* Populate Line Id in pxDialedAddr*/
        if(IFX_FAILURE == IFX_DECT_IsEndpointLineIdSet(pxEndptInfo)){
				  IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndptId, 
																	  &ucDefaultLineId, &eReason);
          IFX_DECT_EndpointLineIdSet(pxEndptInfo,ucDefaultLineId);// 
          pxDialedAddr->ucLineId = ucDefaultLineId;
        }else{
          IFX_DECT_EndpointLineIdGet(pxEndptInfo,&ucLineId);
          pxDialedAddr->ucLineId = ucLineId;
         } 
    	if((pxDialedAddr->eAddressType != IFX_CMGR_TYPE_EXTN)&&
				(IFX_FALSE == IFX_CIF_IsLineTypeMulti(pxDialedAddr->ucLineId)) && 
     	(IFX_FALSE == IFX_CMGR_IsCallAllowed(pxDialedAddr->ucLineId,pxEndptInfo->szEndptId))) { 
     		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Can't take second call on this line - fail");
				/* For 2.0 HS send the Ack status as idle and HS has to send release either its parallel call or normal call*/
				if((pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){
					IFX_DECT_CSU_CallOnLineFailed(pxEndptInfo->uiDTkCallId,pxDialedAddr->ucLineId);
				}
				/* For 1.0 HS send failure */
					return IFX_FAILURE;
		}else{
		}

			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "LINE ID",pxDialedAddr->ucLineId); 
			IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "Default LINE ID",ucDefaultLineId); 

			if( IFX_SUCCESS == eRet && 
					IFX_SUCCESS == (eRet = IFX_DECT_InitiateCall(pxEndptInfo, 
					pxDialedAddr, eCidStatus,	bEmergencyCall,	&eStatus, &eReason )) )
			{
				if( IFX_CMGR_STATUS_FAIL == eStatus )
				{
					eRet = IFX_FAILURE;
					printf("IFX_DECT_InitiateCall fails\n");
				}
				if( IFX_CMGR_STATUS_PENDING == eStatus && IFX_ENDPOINT_RINGING == eReason )
				{
					*pucSignal = IFX_DECT_RINGBACK_TONE; 
					*peState = IFX_DECT_STATE_RINGBACK;
				}
			}
#if 0
			if( ucOrgDefaultVL )
			{ /* Change back to actual default voice line */
				IFX_CIF_EndptDefaultVLSet(pxEndptInfo->szEndptId, 
																									ucOrgDefaultVL, &eReason);
			}
      else if(pxEndptInfo->ucDefaultLineId){//Revert Original Line Id

        IFX_CIF_EndptDefaultVLSet(pxEndptInfo->szEndptId,                                                                                                                    pxEndptInfo->ucDefaultLineId, &eReason);
        pxEndptInfo->ucDefaultLineId = 0;
       }  
#endif
		} /* bOutCallBar */
		else
		{
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
									 pxEndptInfo->szEndptId, "Outgoing Call Bar Enabled" );
			memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			/* Set to non-voip call, so that user can not do auto redial request */
			pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
			eRet = IFX_FAILURE;
		}
		if( IFX_SUCCESS != eRet &&  IFX_TRUE == bEmergencyCall )
		{
			IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_EMG_CALL_PROCEDING);
		}
	} /* bMakeCall */

	return eRet;
}

e_IFX_Return IFX_CMGR_StarDialling_CreateCall(
					 OUT uint32 *puiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom, 
					 IN uint32 uiActiveCallId,
					 IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 IN void* pvPrivateData);

/*******************************************************************************
 *  Function Name   : IFX_DECT_InitiateCall 
 *  Description     : This routine initates a outgoing call(from handset). If 
 *                    handset has max number of calls, then no call is initiated
 *                    and routine returns failure.  Else initiates a new call.
 *  Input Values    : pxEndptInfo  - Pointer to DECT endpoint info.
 *                    pxDialedAddr - Pointer to x_IFX_CMGR_AddressInfo struct
 *                     containing to valid parameter for the destination.
 *                    eCidStatus   - This indicates whether CID to be disabled.
 *                     IFX_CMGR_DISABLE - disable CID
 *                                 IFX_CMGR_ENABLE - enable CID
 *                                 IFX_CMGR_DONT_CARE - Use system config
 *                      If eCidStatus is IFX_CMGR_ENABLE, CM overrides this
 *                      option with system configuration.
 *                    bEmergencyCall - IFX_TRUE - for emergency call.
 *                                   IFX_FALSE - for non-emergency call. 
 *  Output Values	  : peStatus - This contains status of the initiated call.
 *                       This parameter is valid only if function returns
 *                       IFX_SUCCESS.
 *                     peReason - On return this contains the reason. If routine
 *                       returns IFX_SUCCESS, the valid values are 
 *                       IFX_ENDPOINT_RINGING and IFX_REQ_PENDING
 *  Return Value    : If call is initated returns IFX_SUCCESS, else returns 
 *                    IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_InitiateCall(
                     IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
										 IN x_IFX_CMGR_AddressInfo* pxDialedAddr,
										 IN e_IFX_CMGR_FeatStatus eCidStatus,
	                   IN boolean bEmergencyCall,
	                   OUT e_IFX_CMGR_Status* peStatus,
	                   OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DECT_CallInfo* pxNewCall;
        char8 ucStarDialFlag=0;
	e_IFX_Return eRet = IFX_FAILURE;


	/* Get free call info */
	IFX_DECT_GetFreeCallInfo(pxEndptInfo, &pxNewCall);
	
	if( pxNewCall )
	{
		x_IFX_CMGR_AddressInfo xFrom ={0};
		x_IFX_CMGR_CallParams xCallParams = {0};
		x_IFX_DECT_CSU_CallParams xCP = {0};
    boolean IsInternal=0;
		uint32 uiCallId;

		IFX_DECT_ConvertCodecToCmgr(
				&xCallParams.uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams,
				&pxEndptInfo->xReservedCodecs);

		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			"Number of codecs reserved", pxEndptInfo->xReservedCodecs.ucNoOfCodecs);


		/* Fill from endpoint id */
		xFrom.eAddressType = IFX_CMGR_TYPE_EXTN;
		strcpy(xFrom.uxAddressInfo.szEndptId, pxEndptInfo->szEndptId);
	
		/* set call params */
		xCallParams.eAgentType = IFX_CMGR_TYPE_EXTN;
		xCallParams.uxCallParams.xExtnParams.eCallerIdStatus = eCidStatus;
		xCallParams.uxCallParams.xExtnParams.bEmergency = bEmergencyCall;

		/* Get wideband capability of endpoint */
		xCallParams.uxCallParams.xExtnParams.bWideBandCapable = IFX_FALSE;

		if(0 == strcmp(pxDialedAddr->uxAddressInfo.szEndptId,"*")) {
			uint32 uiActiveCallId = 0;
			if(pxEndptInfo->pxActiveCall){
				uiActiveCallId =  pxEndptInfo->pxActiveCall->uiCallId;
			}
			eRet = IFX_CMGR_StarDialling_CreateCall(&uiCallId,&xFrom,uiActiveCallId,&xCallParams,
							peStatus,peReason,pxEndptInfo );
                        ucStarDialFlag =1;
		}
		else
		 {
		eRet = IFX_CMGR_CallInitiate( &uiCallId,  &xFrom,
							pxDialedAddr,	&xCallParams,	peStatus,	peReason,	pxEndptInfo );
     }
	  	
		if( IFX_SUCCESS == eRet )
		{
			if( IFX_CMGR_STATUS_FAIL == (*peStatus) )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						"IFX_CMGR_CallInitiate :: STATUS FAIL", pxEndptInfo->szEndptId);
				eRet = IFX_FAILURE;
#if 0
                /* For GAP handsets DTKCallID will be same and conf ack need not be sent*/
        if(((pxEndptInfo->uiTermCap&0x40)!=0x40) && (pxEndptInfo->axCallInfo[0].uiCallId != 0)){
				  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						"GAP HS and 1 call exists so dont send rel", pxEndptInfo->szEndptId);
        }
        else{
      	  IFX_DECT_CSU_CallRelease(pxEndptInfo->uiDTkCallId,NULL,IFX_DECT_RELEASE_NORMAL);
        }
#endif  
			}
			else
			{
				 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 								"Call Initiate Success. Call Id",uiCallId); 
				
				pxEndptInfo->pxActiveCall = pxNewCall;
				pxEndptInfo->pxActiveCall->ucLineId = pxDialedAddr->ucLineId;
				pxNewCall->uiCallId = uiCallId;

				pxEndptInfo->pxActiveCall->uiDTkCallId = pxEndptInfo->uiDTkCallId;

				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
 						    "DTK Call Handle",pxEndptInfo->pxActiveCall->uiDTkCallId); 
				pxNewCall->eCallType = pxEndptInfo->xLastDialedAddr.eAddressType;
				IFX_AGU_GetCallerIdInfo(pxDialedAddr,pxEndptInfo->szCallerName, 
																pxEndptInfo->szCallerNumber);

		    strcpy(xCP.acCLIP,pxEndptInfo->szCallerNumber);

        if(pxDialedAddr->eAddressType == IFX_CMGR_TYPE_EXTN){
        		IsInternal=1;/*For Extn call */
        }
        /* Get the LineId for VoIP or FXO call */
	      if(IFX_CIF_CNIPGet(IsInternal,pxDialedAddr->ucLineId,pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS){
	        strcpy(xCP.acCNIP,pxEndptInfo->szCallerName);
        }
				xCP.uiSignal=0xFF;
		//TODO check if pxactiveCall is set or not
	      if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){
          IFX_DECT_CSU_InfoReceived(
          pxEndptInfo->pxActiveCall->uiDTkCallId,
		      &xCP);
        }

				if(  pxEndptInfo->eRunningCodec ){
					pxNewCall->eNegCodec =  pxEndptInfo->eRunningCodec;
        }
		    else {
					pxNewCall->eNegCodec = pxEndptInfo->xReservedCodecs.axCodecs[0].eCodecType;
		    }

		    if( IFX_CMGR_STATUS_SUCCESS == (*peStatus))	
		    {
			  	IFX_DECT_RemotePartyAnswered(pxEndptInfo);
		    }
		    else //IFX_CMGR_STATUS_PENDING
		    {
			  	e_IFX_DECT_CallStates eCallState;
			  	eCallState = ((IFX_ENDPOINT_RINGING == *peReason)?
						IFX_DECT_CS_RINGING:IFX_DECT_CS_INITIATED);
			    IFX_DECT_UpdateCallState(pxEndptInfo,pxNewCall,eCallState);
          if(strstr(pxEndptInfo->szCallerName,"Phone") != NULL){
          	if(pxDialedAddr->eAddressType == IFX_CMGR_TYPE_EXTN){
							x_IFX_DECT_CSU_CallParams xCallParams = {0};
              xCallParams.bIsPresentation =1;
			        IFX_DECT_CSU_CallAccept( pxEndptInfo->uiDTkCallId, &xCallParams);
							IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_RINGBACK);
            }
          }
          if(ucStarDialFlag){
            *peStatus = IFX_CMGR_STATUS_SUCCESS;
             ucStarDialFlag =0;
          }
				}
		}
	}
		else
		{
			/* Failed to initiate call */
			*peStatus = IFX_CMGR_STATUS_FAIL;
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "IFX_CMGR_CallInitiate Failed " );
		}
     }
     else
     {
		/* Endpoint has max calls. */
	  *peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Can not Initiated :: DECT Has Max Calls " );
	}

	return eRet;
}
void IFX_DECT_InterceptTimerFired(
                     IN uint32 uiTimerId,
                     IN void* pvPrivateData )
{
		x_IFX_DECT_TimerEvent* pxTimerEvt= (x_IFX_DECT_TimerEvent*)(pvPrivateData);
    x_IFX_DECT_EndptFsmInfo* pxEndptInfo=pxTimerEvt->pxEndptInfo;
		uint16 i=0;
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
							 pxEndptInfo->szEndptId, "Intercept Request Timed Out" );
		for(i=0;i<IFX_MMGR_MAX_DECT_CHANNELS;i++){
    	if((!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2))&&(vaxDectEndptFsmInfo[i].uiFlags&IFX_DECT_F_INTERCEPT_INIT)){
				IFX_DECT_StopTone(&vaxDectEndptFsmInfo[i],vaxDectEndptFsmInfo[i].pxActiveCall->uiDTkCallId);
			}
			vaxDectEndptFsmInfo[i].uiFlags &= ~IFX_DECT_F_INTERCEPT_INIT;
		}
		IFX_DECT_MakeDectPPIdle(pxEndptInfo); 
}


void IFX_DECT_AtxTimerFired(
                     IN uint32 uiTimerId,
                     IN void* pvPrivateData )
{
		x_IFX_DECT_CallInfo* pxHeldCall = 0;
		e_IFX_Return eRet;
		e_IFX_TransferStatus eTfrStatus;
		uint32 uiDtkHeldCallId;
		uint32 uiDtkActiveCallId;
		e_IFX_ReasonCode eReason = IFX_MAX_REASON;
		x_IFX_DECT_TimerEvent* pxTimerEvt= (x_IFX_DECT_TimerEvent*)(pvPrivateData);
    x_IFX_DECT_EndptFsmInfo* pxEndptInfo=pxTimerEvt->pxEndptInfo;
		if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTRUDE_INIT)){
			pxEndptInfo->uiFlags &= ~IFX_DECT_F_INTERCEPT_INIT;
			eRet = IFX_DECT_MakeConference(pxEndptInfo);
      printf("Dialed Digits %s\n",pxEndptInfo->szDialledDigits);
			return;
		}
  
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
							 pxEndptInfo->szEndptId, "Un-Announced Trf req...Initiating transfer now" );
	
    IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
		if( pxHeldCall )
		{
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_TRANSFER_INITIATED);

			uiDtkActiveCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;
			uiDtkHeldCallId = pxHeldCall->uiDTkCallId;
			eRet = IFX_CMGR_AttendedTx(pxHeldCall->uiCallId,
				 pxEndptInfo->pxActiveCall->uiCallId, NULL, &eTfrStatus, &eReason );

			if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
				IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Could Not Initiated Attended Transfer" );
				IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
							IFX_TERMINATED, NULL, NULL, &eReason);
				IFX_DECT_ResetCall(pxHeldCall,0);
				//Active call will be released in IFX_DECT_MakeDectPPIdle
				IFX_DECT_MakeDectPPIdle(pxEndptInfo);
			} else if(IFX_CMGR_TRANSFER_PROCEEDING == eTfrStatus) {
						IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_IDLE);
			} else {
        if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){
          x_IFX_DECT_EndptFsmInfo* pxInterceptEndPtInfo;
          x_IFX_DECT_CSU_CallParams xCallParams = {0};
          printf("Dialed Digits %s\n",pxEndptInfo->szDialledDigits);
          IFX_DECT_GetEndptInfoById(pxEndptInfo->szDialledDigits, &pxInterceptEndPtInfo);
					if( pxInterceptEndPtInfo != NULL && pxInterceptEndPtInfo->uiInterceptTimerId )
						{
							IFX_TIM_TimerStop(pxInterceptEndPtInfo->uiInterceptTimerId);
							pxInterceptEndPtInfo->uiInterceptTimerId = 0;
						}
          /* This PP has accepted the Interecpt request */
				  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					  	pxEndptInfo->szEndptId, "Intercept is successful" );
          printf("DTKCallId %d\n",pxInterceptEndPtInfo->uiDTkCallId);
          IFX_DECT_CSU_InterceptAck(pxInterceptEndPtInfo->uiDTkCallId,
                        pxHeldCall->uiDTkCallId, IFX_DECT_CSU_INTERCEPT_SUCCESS);
					pxInterceptEndPtInfo->pxActiveCall->uiDTkCallId = pxInterceptEndPtInfo->uiDTkCallId;
	  			IFX_DECT_UpdateEndptState(pxInterceptEndPtInfo, IFX_DECT_STATE_ACTIVE);
					pxInterceptEndPtInfo->uiFlags &= ~IFX_DECT_F_INTERCEPT_REQ ;
          if( !IFX_DECT_CheckEndptFlag(pxInterceptEndPtInfo, IFX_DECT_F_VOICE_ENABLED) )
	        {
		        IFX_DECT_CSU_VoiceModify(
		          pxInterceptEndPtInfo->uiDTkCallId,
		          &xCallParams,
							IFX_DECT_START_VOICE,
							pxInterceptEndPtInfo->unDectChannel);

		        IFX_DECT_SetEndptFlag(pxInterceptEndPtInfo, IFX_DECT_F_VOICE_ENABLED);
	        }
          //IFX_DECT_PlayTone(pxInterceptEndPtInfo,pxInterceptEndPtInfo->uiDTkCallId,IFX_DECT_DIAL_TONE); 
          if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){
	          IFX_DECT_ResetCall(pxHeldCall,1);
	          IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
          }else{
	          IFX_DECT_ResetCall(pxHeldCall,0);
	          IFX_DECT_ResetCall(pxEndptInfo->pxActiveCall,1);
          }

		      IFX_DECT_MakeDectPPIdle(pxEndptInfo);
        } else {
				  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					  	pxEndptInfo->szEndptId, "Transfer is successful" );
        if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS) ){
				  IFX_DECT_CSU_CallTransferAck(uiDtkHeldCallId,
																		 uiDtkActiveCallId,
															 NULL,IFX_SUCCESS);
        }else{
          IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_IGNORE_ATXSTATUS);
         }
			}
		}
			return;
   }
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_RemotePartyAnswered 
 *  Description     : This routine is invoked after receiving call answer from
 *                    called party. Stop ringback tone if being played. If media
 *                    answered by remote party differs from that of handset, 
 *	                  requeest DECT stack to change codec. If there is no need
 *	                  to change codec then activate DECT channel and start voice
 *	                  on DECT side(by sending enable vice command to DECT stack).
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info. 
 *  Output Values	  : None 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_RemotePartyAnswered(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	x_IFX_CMGR_MediaParams xMediaParams = {0};
	x_IFX_MMGR_CodecList xMmgrCodecList = {0};
	x_IFX_MMGR_CodecInfo xCodecInfo = {0};
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
  //x_IFX_DECT_EventInfo xEvtInfo = {0};
	
	IFX_DECT_StopTone(pxEndptInfo,
		(pxEndptInfo->pxActiveCall!=NULL)?pxEndptInfo->pxActiveCall->uiDTkCallId:0);
  if(pxActCall != NULL && pxActCall->eCallType != IFX_CMGR_TYPE_EXTN){

    //Populate Line Id.
	  xCallParams.ucLineId = pxActCall->ucLineId;
  }else{
	  xCallParams.isInternal = IFX_TRUE;
   }
   printf("===CallType is %d LineId %d ===\n",pxActCall->eCallType,xCallParams.ucLineId);
   xCallParams.bSingleCallLine = IFX_FALSE; //multi call line

	//This API should never fail
	IFX_CMGR_MediaParamsGet(pxActCall->uiCallId, &xMediaParams);
	IFX_DECT_ConvertCodecToMMGR(&xMmgrCodecList,
				&xMediaParams.uxMediaParams.xExtnMediaParams.xCodecParams);


	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			 "Codec selected by CM",  xMmgrCodecList.axCodecs[0].eCodecType );
	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			 "Running Codec",   pxActCall->eNegCodec );
		
	if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT)&&
			!(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTRUDE_INIT))&&
			!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2) ){
		IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_SIGNAL_InterceptTone);
  }

  xCallParams.bIsPresentation =1;

 if(pxActCall->eCallType == IFX_CMGR_TYPE_EXTN){
   /* In case of Star Dialing, update CLIP/CNIP of endpt that performed it */
   xCallParams.uiSignal = 0xFF; 
   strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);//CLIP
	 if(IFX_CIF_CNIPGet(xCallParams.isInternal,0,
				             pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS)//CNIP
    strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
	  if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT))
   IFX_DECT_CSU_InfoReceived(pxActCall->uiDTkCallId,&xCallParams);
 }

	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_ATX_PENDING) ){
	  if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){

	IFX_DECT_CSU_CallAnswer(
	pxActCall->uiDTkCallId,
  &xCallParams);
  }
 }

  /*xEvtInfo.uiId =*/ IFX_DECT_HsIdFromEPName(pxEndptInfo->szEndptId);

	if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){
	if( pxActCall->eNegCodec != xMmgrCodecList.axCodecs[0].eCodecType )
	{
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId, "Changing Codec On DECT Side");
		pxEndptInfo->eRunningCodec = pxActCall->eNegCodec;
		pxActCall->eNegCodec =  xMmgrCodecList.axCodecs[0].eCodecType;
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 pxEndptInfo->szEndptId, "Calling IFX_DECT_CSU_ServiceChange");
    xCallParams.bwideband = IFX_DECT_IsWidebandCodec(pxActCall->eNegCodec);
		IFX_DECT_CSU_ServiceChange(
		pxActCall->uiDTkCallId,
		&xCallParams,
		IFX_DECT_CSU_SC_REQUEST);
		IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
	  IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_ACTIVE);
	  IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	//	return IFX_SUCCESS;
	}
  }
	
	pxEndptInfo->eRunningCodec = xCodecInfo.eCodecType = pxActCall->eNegCodec;
	if( IFX_MMGR_SUCCESS != 
			IFX_MMGR_DectResActivate( pxEndptInfo->szEndptId, &xCodecInfo,
															 (pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_ECHO_TCL_55)?0:1) )
	{
		//Configure codec on DECT Channel failed
		//This should never fail, TODO: if it fails, disconnect call ??
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
	}

	IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED);

	if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTERCEPT_INIT) ){
	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) )
	{
		IFX_DECT_CSU_VoiceModify(pxActCall->uiDTkCallId,
		                         &xCallParams,
														 IFX_DECT_START_VOICE,
														 pxEndptInfo->unDectChannel);

		IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
	}
  }
	//TODO: Check -- How to inform second call answer to PP
	/* else
	{
		//Already voice is enabled....
	} */
/////////////////////////ATX
	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_ATX_PENDING) )
  {

		IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_ATX_PENDING);
    {
		  x_IFX_DECT_TimerEvent xTimerEvt={0};
      uint32 uiTimer=0; 
		  xTimerEvt.eTimerEvent = 0; 
		  xTimerEvt.pxEndptInfo = pxEndptInfo; 
      if( IFX_SUCCESS != IFX_TIM_TimerStart(100, 
				&xTimerEvt, sizeof(x_IFX_DECT_TimerEvent), IFX_DECT_AtxTimerFired,&uiTimer ) ) 
	    { 
		    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
					"Could Not Start Timer"); 
		  }
			if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTRUDE_INIT)){
				IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_ACTIVE);
				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
			}
      return IFX_SUCCESS; 
    }
	}
/////////////////////////ATX
	IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_ACTIVE);
	IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_HandleHoldSuccess 
 *  Description     : This function is called when call is held successfuly. 
 *	                  - CALL WAITING state : answer the waiting call and
 *                      if codec on air-interface differs, request DECT stack to 
 *                      change codec on air-interface. Move to ACTIVE state.
 *                    - Ohter states : If FSM is not in call waiting state play 
 *                      dial tone and move to DIALING state.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info. 
 *  Output Values	  : peState - On return this indicates the FSM state to be 
 *	                    changed. 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_HandleHoldSuccess(
	                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                    OUT e_IFX_DECT_States* peState)
{
	e_IFX_CMGR_Status eStatus;
  
  x_IFX_DECT_EndptFsmInfo* pxPeerEndptInfo;
  printf("\n Entry HandleHoldSuccess. \n");
  printf("\n pxEndptInfo->pxActiveCall = %d \n",(uint32)(pxEndptInfo->pxActiveCall));
	/* Call hold success. Mark active call as held. */
	IFX_DECT_UpdateCallState(pxEndptInfo,pxEndptInfo->pxActiveCall, 
							             IFX_DECT_CS_HELD);
  pxEndptInfo->uiDTkCallId = pxEndptInfo->pxActiveCall->uiDTkCallId;

	if( IFX_DECT_STATE_CALL_WAITING == pxEndptInfo->eState )
	{
		x_IFX_DECT_CallInfo* pxWaitingCall;
		e_IFX_ReasonCode eReason = IFX_MAX_REASON;
		e_IFX_Return eRet = IFX_FAILURE;

		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Answering Waiting Call");
		IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_CALL_WAITING);
		/* Get waiting call */
		IFX_DECT_GetWaitingCallInfo(pxEndptInfo,&pxWaitingCall);
#ifndef TONES	

	if( pxEndptInfo->uiToneTimerId ) {
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
	  IFX_DECT_StopTone( pxEndptInfo,(pxWaitingCall != NULL) ? 
												pxWaitingCall->uiDTkCallId:0);
	}
#endif
		if( pxWaitingCall ){
      if(!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){
        /* To update CLIP/CNIP of remote party when 1.0 HS answers waiting call by pressing R key */ 
	      if( IFX_SUCCESS == IFX_DECT_GetEndptInfoById(pxEndptInfo->szCallerNumber, &pxPeerEndptInfo) )
          strcpy(pxPeerEndptInfo->szCallerNumber,pxEndptInfo->szEndptId);
      }
			eRet = IFX_CMGR_CallAnswer(pxWaitingCall->uiCallId, &eStatus, &eReason);
		}	
		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_SUCCESS != eStatus )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Answering Waiting Call Failed");
			if(pxWaitingCall){
#ifndef TONES

		    IFX_DECT_PlayTone(pxEndptInfo,pxWaitingCall->uiDTkCallId,
                         (pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)?IFX_DECT_OFF_HOOK_TONE:IFX_DECT_BUSY_TONE);
        pxWaitingCall->eState = IFX_DECT_CS_BUSYSTATE;
			  IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_BUSY);
  	    IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_BCETimerExpired,
		          								 IFX_DECT_BUSY_TONE_TIMER,&pxEndptInfo->uiBCETimerId); 
#endif
      }
		}
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Answered Waiting Call");
			pxEndptInfo->pxActiveCall = pxWaitingCall;
			IFX_DECT_UpdateCallState(pxEndptInfo, pxEndptInfo->pxActiveCall, 
																													IFX_DECT_CS_ACTIVE);
			/* initiate service change request now if there is change of codec */
			if( pxEndptInfo->eRunningCodec != pxWaitingCall->eNegCodec)
			{
				x_IFX_DECT_CSU_CallParams xCallParams = {0};
				xCallParams.bwideband = 
								IFX_DECT_IsWidebandCodec(pxWaitingCall->eNegCodec);
				//Change codec on air interface (i.e. DECT side)
				IFX_DECT_CSU_ServiceChange(
		      pxEndptInfo->pxActiveCall->uiDTkCallId,
					&xCallParams,
					IFX_DECT_CSU_SC_REQUEST);
				IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
			}
				
			*peState = IFX_DECT_STATE_ACTIVE;
		}
	}
	else if( IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) )
  {
    x_IFX_DECT_CallInfo* pxCallToBeResumed;
		//e_IFX_Return eRet = IFX_FAILURE;
			 
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "Toggle Case : Resume Call");
	  if( pxEndptInfo->pxActiveCall == (pxEndptInfo->axCallInfo + 0))
				pxCallToBeResumed = (pxEndptInfo->axCallInfo + 1);
		else
				pxCallToBeResumed = (pxEndptInfo->axCallInfo + 0);

		/*eRet =*/ IFX_DECT_CallResume(pxEndptInfo, pxCallToBeResumed);
	  if( IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_RESUME_INITIATED) )
    {
		  *peState = IFX_DECT_STATE_DIALING;
    }
    else
    {
		  *peState = IFX_DECT_STATE_ACTIVE;
    }
  }
	else
	{
		*peState = IFX_DECT_STATE_DIALING;
#ifndef TONES
    if(!(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)){
      
		  IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->uiDTkCallId,IFX_DECT_DIAL_TONE);
	    IFX_DECT_FsmTimerStart(pxEndptInfo,IFX_DECT_EVT_DialTimerExpired,
		       								   IFX_DECT_DIAL_TONE_TIMER,&pxEndptInfo->uiToneTimerId); 
    }
#endif
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_SendAutoRedialNtfy
 *  Description     : This routine notifies the remote party that whether it can
 *                    receive call if subscribed for auto redial. It does noting
 *                    if none have subscribed for redial.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.  
 *                    bNotify     - IFX_TRUE - If endpoint can receive call.
 *                                  IFX_FALSE - If endpoint can not receive call
 *  Output Values	  : 
 *  Return Value    : If notification is sent, returns IFX_SUCCESS, else returns
 *                    IFX_FAILURE. 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_SendAutoRedialNtfy(
	                    IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                    IN boolean bNotify )
{
	e_IFX_Return eRet = IFX_FAILURE;

	/* 
	 * Check if uiAutoRedialInReqId is valid. If valid send notification and 
	 * clear parameters.
	 */
	if( pxEndptInfo->uiAutoRedialInReqId )
	{
		if(IFX_SUCCESS != (eRet=IFX_CMGR_ARD_Ntf(pxEndptInfo->uiAutoRedialInReqId,
			 (bNotify)?IFX_CMGR_STATUS_SUCCESS:IFX_CMGR_STATUS_FAIL)) )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "IFX_CMGR_ARD_Ntf FAILED");
		}

		pxEndptInfo->uiAutoRedialInReqId = 0;
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_IN);
	}
#ifdef DEV_DEBUG
	else
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "No Auto Redial Requests");
	}
#endif

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ResumeCallInBusy
 *  Description     : This routine is called to resume active call from busy 
 *                    state. If there is no active call, makes endpoint IDLE.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *  Output Values	  : 
 *  Return Value    : If call resume fails, returns IFX_FAILURE, else returns
 *                    IFX_SUCCESS.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ResumeCallInBusy( IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{
	e_IFX_Return eRet = IFX_FAILURE;

	if( pxEndptInfo->pxActiveCall )
	{
		eRet = IFX_DECT_CallResume(pxEndptInfo, pxEndptInfo->pxActiveCall );
	}
	else
	{
		IFX_DECT_MakeDectPPIdle(pxEndptInfo);
		IFX_DECT_UpdateEndptState(pxEndptInfo,IFX_DECT_STATE_IDLE);
		eRet = IFX_SUCCESS;
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActDeActvAutoRedial 
 *  Description     : This routine is called to subscribe/unsuscribe auto redial
 *                    for last dialed VOIP number. If last dialed number is voip
 *                    then request CM for auto-redial subscription or cancelation
 *                    depending on bActivate flag and return status.
 *                    If there is a outstanding auto-redial request, then return
 *                    failure.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *                    bActivate   - IFX_TRUE - To activate auto-redial.
 *                                  IFX_FALSE - To cancel auto-redial.
 *  Output Values	  : None 
 *  Return Value    :  
 *  Notes           : Only on auto-redial request is allowed.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActDeActvAutoRedial(
	                   IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                   IN boolean bActivate )
{
	x_IFX_CMGR_AddressInfo xFromAddr;
	e_IFX_CMGR_Status  eStatus;
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;

	if( IFX_CMGR_TYPE_VOIP == pxEndptInfo->xLastDialedAddr.eAddressType )
  {
		if( bActivate )
		{
		  eRet = (0 == pxEndptInfo->uiAutoRedialOutReqId )?IFX_SUCCESS:IFX_FAILURE;
		}
	  else
		{
		  eRet = (0 == pxEndptInfo->uiAutoRedialOutReqId  )?IFX_FAILURE:IFX_SUCCESS;
		  IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_ACTIVE_OUT );
		}

	  if( IFX_SUCCESS == eRet )
		{
			xFromAddr.eAddressType = IFX_CMGR_TYPE_EXTN;
		  strcpy(xFromAddr.uxAddressInfo.szEndptId, pxEndptInfo->szEndptId);
		 
		  if( IFX_SUCCESS == (eRet = IFX_CMGR_ARD_Activate(	&pxEndptInfo->xLastDialedAddr,
								&xFromAddr, bActivate, &pxEndptInfo->uiAutoRedialOutReqId,
								&eStatus, &eReason, pxEndptInfo)) ) 
			{
			  if( bActivate )
				{
				  if( IFX_CMGR_STATUS_PENDING == eStatus )
					{
						IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId,"Auto Redial Initiated");
					  IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTOREDIAL_REQ_INITIATED );
					}
					else
					{
						IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndptId, "Could Not Initiate Auto Redial");
						eRet = IFX_FAILURE;
					}	
				}
				else
				{
					IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndptId, "Auto Redial Subscription Is Canceled");
					pxEndptInfo->uiAutoRedialOutReqId = 0;
				}
			}
		  else
			{
				/* If failed, in either case request id is invalid */
				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Failed To Initiate Auto Redial");
			  pxEndptInfo->uiAutoRedialOutReqId = 0; 
			}
		} //else auto redial not possible
	}
	else
	{	
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Last Dialed Number Is Not A VoIP Call");
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActiveCallHold 
 *  Description     : This routine is called to hold a active call. If active
 *                    is a emergency call or hold is already initiated or 
 *                    transfer initiated, then hold operation on active call is
 *                    not done. Otherwise request CM to hold active call and 
 *                    update DECT endpoint FSM state and call hold status.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info. 
 *  Output Values	  : 
 *  Return Value    : If call hold is initiated on active call then returns
 *                    IFX_SUCCESS, else returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActiveCallHold(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{
	x_IFX_DECT_CallInfo* pxActCall = pxEndptInfo->pxActiveCall;
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason;
	x_IFX_DECT_CallInfo* pxHeldCall = NULL;

	if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_EMG_CALL_PROCEDING |
				IFX_DECT_F_HOLD_INITIATED | IFX_DECT_F_TRANSFER_INITIATED ) )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Can Not Handle Hook Flash Now" );
		return IFX_FAILURE;
	}
  IFX_DECT_GetLastHeldCall(pxEndptInfo, &pxHeldCall);
	
	if( IFX_SUCCESS == 
			IFX_CMGR_CallHold(pxActCall->uiCallId, &eStatus, &eReason) &&
			IFX_CMGR_STATUS_FAIL != eStatus )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId,	(IFX_CMGR_STATUS_SUCCESS == eStatus)
				?"Call Hold Success":" Call Hold Pending" );
		if( IFX_CMGR_STATUS_SUCCESS == eStatus )
		{
			e_IFX_DECT_States eState;
	    if((!(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED)))	&&
								(!(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_INIT))))
      {
        x_IFX_DECT_CSU_CallParams xCallParams={0};
				uint32 uiDtkId = pxActCall->uiDTkCallId;
			  IFX_DECT_HandleHoldSuccess(pxEndptInfo, &eState);
			  IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
        IFX_DECT_CSU_CallHoldAck(uiDtkId,&xCallParams,IFX_SUCCESS);
      }
      /* Endpoint has already accepted the intercept req */
      else if( IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_INTERCEPT_INIT) )
      {
	      x_IFX_DP_Rule xDpRule;
	      char8  szDialOut[IFX_MAX_DIGITS];
	      uchar8 ucDpAction = 0;
	      uint16 unTimeOut = 0;
				e_IFX_Return eRet=IFX_FAILURE;
        /* Call Initiate to the Intercept req PP. Match the DP and put it to FSM */
        eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
				  		IFX_FALSE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );
	      if( IFX_SUCCESS == eRet && (IFX_DP_ST_SMALL_TIM == ucDpAction || 
							 IFX_DP_ST_LARGE_TIM == ucDpAction) )
	      {
		      IFX_DECT_FsmTimerStart(pxEndptInfo, IFX_DECT_EVT_InterDigitTimerExpired,
					  		   unTimeOut, &pxEndptInfo->uiIntrDgtTimerId);
	      }
      }
      else
	    {
			  IFX_DECT_HandleHoldSuccess(pxEndptInfo, &eState);
			  IFX_DECT_UpdateEndptState(pxEndptInfo, eState);
      }			
		}
		else
		{
			IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_HOLD_INITIATED);
			IFX_DECT_UpdateCallState(pxEndptInfo, pxActCall, IFX_DECT_CS_HOLD_INITIATED);
		}
	}
	else
	{

	if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) ){
    if(pxHeldCall)
			IFX_DECT_CSU_CallToggleAck(pxHeldCall->uiDTkCallId,pxActCall->uiDTkCallId,NULL,IFX_FAILURE);
	  IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
	}	
  else
    IFX_DECT_CSU_CallHoldAck(pxActCall->uiDTkCallId,NULL,IFX_FAILURE);
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "FAILED : Could Not Initiate Call Hold" );
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ActivateAfterServiceChange
 *  Description     : 
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *  Output Values	  : 
 *  Return Value    :
 *  Notes           : 
 ******************************************************************************/
e_IFX_Return IFX_DECT_ActivateAfterServiceChange(
	                  IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo, boolean bScStatus)
{
	x_IFX_MMGR_CodecInfo xMmgrCodec = {0};

	xMmgrCodec.eCodecType = pxEndptInfo->eRunningCodec;
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
							"Coder Selected for the call=", pxEndptInfo->eRunningCodec);
	if( IFX_MMGR_SUCCESS != IFX_MMGR_DectResActivate(
											pxEndptInfo->szEndptId, &xMmgrCodec,
											 (pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_ECHO_TCL_55)?0:1) )
	{
		//Configure codec on DECT Channel failed
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Activate DECT Channel" );
	}
	
	/* 
	 * If voice is not enabled, enable the voice. This check will ensure that
	 * IFX_DECT_EnableVoice will not be called if there is a voice call on PP.
	 */
	if(!IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) )
	{
  	x_IFX_DECT_CSU_CallParams xCallParams = {0};
		IFX_DECT_CSU_VoiceModify(
      pxEndptInfo->pxActiveCall->uiDTkCallId,
	    &xCallParams,
		  IFX_DECT_START_VOICE,
			pxEndptInfo->unDectChannel);
		IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED);
	}else{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Voice already enabled, so not enabling now" );
  }
	if( IFX_DECT_STATE_DIALING == pxEndptInfo->eState ||
									IFX_DECT_STATE_RINGBACK == pxEndptInfo->eState )
	{
		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_CALL_INITIATED);
		IFX_DECT_StopTone(pxEndptInfo,(pxEndptInfo->pxActiveCall != NULL) ? 
											pxEndptInfo->pxActiveCall->uiDTkCallId:0);
		//TODO: Check -- How to inform second call answer to PP
		if(pxEndptInfo->pxActiveCall != NULL)
		IFX_DECT_UpdateCallState(pxEndptInfo,  
										pxEndptInfo->pxActiveCall, IFX_DECT_CS_ACTIVE);
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);
	}
	else if( IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_MEDIA_CHANGE_REQ))
	{
		x_IFX_CMGR_MediaParams xMedia;
		e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
		x_IFX_CMGR_ExtnMediaParams* pxExtnMediaParams;
		e_IFX_ReasonCode eReason;

		IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_MEDIA_CHANGE_REQ);
		
		if( IFX_TRUE == bScStatus )
			eStatus = IFX_CMGR_STATUS_SUCCESS;

		pxExtnMediaParams = 	&xMedia.uxMediaParams.xExtnMediaParams;
		xMedia.eAgentType = IFX_CMGR_TYPE_EXTN;
		pxExtnMediaParams->xCodecParams.unNoOfCodecs = 1;
		pxExtnMediaParams->xCodecParams.axCodec[0].uiCodec = 
					IFX_DECT_GetCmgrCodec(pxEndptInfo->pxActiveCall->eNegCodec);

		IFX_CMGR_MediaNegRsp(pxEndptInfo->pxActiveCall->uiCallId,
				&xMedia, &eStatus, &eReason);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallResume
 *  Description     : This routine resumes held call. If call is in held state,
 *                    request CM to resume the call and using call resume status
 *                    update FSM state.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *                    pxCallTobeResumed - Call to be resumed. This call should
 *                      belong to the specified endpoint passed in first param. 
 *  Output Values	  : 
 *  Return Value    : If call resume is initated then returns IFX_SUCCESS, else
 *                    returns IFX_FAILURE.
 *  Notes           : This routine should not be called if resume call operation
 *                    is in progress on any held call or if transfer, conference
 *                    operation are in progress. 
 *                    If resume status is pending endpoint state is updated 
 *                    after receiving resume response.
 ******************************************************************************/
e_IFX_Return IFX_DECT_CallResume(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
	                               IN x_IFX_DECT_CallInfo* pxCallTobeResumed)
{
	e_IFX_Return eRet = IFX_FAILURE;
  x_IFX_DECT_CSU_CallParams xCallParam = {0};

	if( IFX_DECT_CS_HELD == pxCallTobeResumed->eState )
	{
		e_IFX_CMGR_Status eStatus;
		e_IFX_ReasonCode eReason;

		pxEndptInfo->pxActiveCall = pxCallTobeResumed;
		eRet = IFX_CMGR_CallResume(pxCallTobeResumed->uiCallId,
							&eStatus, &eReason );
		if( IFX_SUCCESS == eRet )
		{
			if( IFX_CMGR_STATUS_SUCCESS == eStatus )
			{
			  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "Call Resume Status from CM: Success");
				IFX_DECT_UpdateCallState(pxEndptInfo,
										pxCallTobeResumed, IFX_DECT_CS_ACTIVE);
				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ACTIVE);

				IFX_DECT_ResetEndptFlag(pxEndptInfo,IFX_DECT_F_RESUME_INITIATED);
	      if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) ){
          IFX_DECT_CSU_CallToggleAck(pxCallTobeResumed->uiDTkCallId,pxEndptInfo->uiDTkCallId,
							&xCallParam,IFX_SUCCESS);
	        IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
				}	
        else
          IFX_DECT_CSU_CallResumeAck(pxCallTobeResumed->uiDTkCallId, 
                                   &xCallParam,IFX_SUCCESS);
        printf("Resume Call Handle is %d\n",pxCallTobeResumed->uiDTkCallId);
        printf("EndPt Temp Call Handle is %d\n",pxEndptInfo->uiDTkCallId);

				if( pxEndptInfo->eRunningCodec != pxCallTobeResumed->eNegCodec)
				{
			    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		  pxEndptInfo->szEndptId, "Service Change Request");
					x_IFX_DECT_CSU_CallParams xCallParams = {0};
        	        xCallParams.bwideband =
                    IFX_DECT_IsWidebandCodec(pxCallTobeResumed->eNegCodec);
					//Change codec on air interface (i.e. DECT side)
					IFX_DECT_CSU_ServiceChange(
          pxCallTobeResumed->uiDTkCallId, 
					&xCallParams,
					IFX_DECT_CSU_SC_REQUEST);
					IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_SERVICE_CHANGE_OUT);
          return IFX_SUCCESS;
				}
			}
			else if( IFX_CMGR_STATUS_PENDING == eStatus )
			{
			  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndptId, "Call Resume Status from CM: Pending");
				IFX_DECT_UpdateCallState(pxEndptInfo, 
													pxCallTobeResumed, IFX_DECT_CS_RESUME_INITIATED);
				IFX_DECT_SetEndptFlag(pxEndptInfo,IFX_DECT_F_RESUME_INITIATED);
			}
			else
			{
	      if(IFX_DECT_CheckEndptFlag(pxEndptInfo,IFX_DECT_F_TOGGLE_INITIATED) ){
          IFX_DECT_CSU_CallToggleAck(pxCallTobeResumed->uiDTkCallId,pxEndptInfo->uiDTkCallId,
							&xCallParam,IFX_SUCCESS);
	        IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
				}	
        else
          IFX_DECT_CSU_CallResumeAck(pxCallTobeResumed->uiDTkCallId, 
                                   &xCallParam,IFX_FAILURE);
		    IFX_DECT_ResetEndptFlag(pxEndptInfo, IFX_DECT_F_TOGGLE_INITIATED);
				eRet = IFX_FAILURE;
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "IFX_CMGR_CallResume Failed" );
			}
		} 
	}
#ifdef DEV_DEBUG
	else
	{
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Internal Error :: Call Is Not In Held State" );

	}
#endif

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_MakeConference
 *  Description     : This routine initiates the conference.
 *                    Check if endpoint has two calls. If not ignore it. Else 
 *                    cinitiate onference. If conference status is success, mark 
 *                    both the call as active and move to active state. If 
 *                    status is pending set conference initiated flag and don't
 *                    change state. If error play error tone move to busy state.
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info 
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if conference is initated, otherwise
 *                    returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MakeConference(x_IFX_DECT_EndptFsmInfo* pxEndptInfo)
{			
	e_IFX_Return eRet = IFX_FAILURE;
	printf(" Conference First state %d\n\n",pxEndptInfo->axCallInfo[0].eState);
	printf(" Conference Second state %d\n\n",pxEndptInfo->axCallInfo[1].eState);
	if( !(IFX_DECT_CS_ACTIVE == pxEndptInfo->axCallInfo[0].eState ||
		 IFX_DECT_CS_HELD == pxEndptInfo->axCallInfo[0].eState) || 
			 !(IFX_DECT_CS_ACTIVE == pxEndptInfo->axCallInfo[1].eState ||
		 IFX_DECT_CS_HELD == pxEndptInfo->axCallInfo[1].eState) )
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Can Not Initiate Conference");
	}
	else //initiating conference
	{
		uint32 auiConfIds[2]; //Max of two calls
		e_IFX_CMGR_Status eStatus;
		e_IFX_ReasonCode eReason;
		uint32 uiSrcDtkCallId =0;
		uint32 uiHeldDtkCallId =0;
    int32 i=0;
    x_IFX_DECT_EndptFsmInfo* pxIntrudeEndPtInfo;

		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			     pxEndptInfo->szEndptId, "Initiating Conference");
		auiConfIds[0] = pxEndptInfo->axCallInfo[0].uiCallId;
		auiConfIds[1] = pxEndptInfo->axCallInfo[1].uiCallId;


	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Conf CallId 1 =",auiConfIds[0]);

	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Conf Callid 2 =",auiConfIds[1]);
    printf("=====%d  %d\n",(uint32)(&pxEndptInfo->axCallInfo[0]),(uint32)(&pxEndptInfo->axCallInfo[1]));
    printf("Before ConfMake pxEndptInfo=%d pxActiveCall= %d\n",
                    (uint32)pxEndptInfo,(uint32)(pxEndptInfo->pxActiveCall));

    for(i=0;i<IFX_MAX_DECT_CALLS;i++) {
      if(IFX_DECT_CS_ACTIVE == pxEndptInfo->axCallInfo[i].eState)
	    {
	      uiSrcDtkCallId = pxEndptInfo->axCallInfo[i].uiDTkCallId; 
	      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Source Call Handle =", uiSrcDtkCallId);
	    }else{
	      uiHeldDtkCallId = pxEndptInfo->axCallInfo[i].uiDTkCallId; 
	      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			             "Held Call Handle =", uiHeldDtkCallId);
			}	
    }

		if( (IFX_SUCCESS == IFX_CMGR_ConfMake(auiConfIds, 2,
					&pxEndptInfo->uiConfReqId, &eStatus, &eReason, pxEndptInfo)) &&
					IFX_CMGR_STATUS_FAIL != eStatus )
		{
			eRet = IFX_SUCCESS;
    	printf("After ConfMake pxActiveCall= %d\n",(uint32)(pxEndptInfo->pxActiveCall));
			if( IFX_CMGR_STATUS_SUCCESS == eStatus )
			{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndptId, "Conference is active");
        
    		printf("Before Conf ACK pxEndptInfo=%d pxActiveCall= %d\n",
              (uint32)pxEndptInfo, (uint32)(pxEndptInfo->pxActiveCall));
    		printf("uiSrcDtkCallId = %d  pxEndptInfo->uiDTkCallId=%d\n",uiSrcDtkCallId,pxEndptInfo->uiDTkCallId);
        /* For GAP handsets DTKCallID will be same and conf ack need not be sent*/
       if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){ 
       // if(pxEndptInfo->axCallInfo[0].uiDTkCallId != pxEndptInfo->axCallInfo[1].uiDTkCallId){
					if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTRUDE_INIT)){
          	IFX_DECT_GetEndptInfoById(pxEndptInfo->szDialledDigits, &pxIntrudeEndPtInfo);
						if(pxIntrudeEndPtInfo != NULL &&  pxIntrudeEndPtInfo->uiInterceptTimerId )
							{
								IFX_TIM_TimerStop(pxIntrudeEndPtInfo->uiInterceptTimerId);
								pxIntrudeEndPtInfo->uiInterceptTimerId = 0;
							}
							uiSrcDtkCallId = pxIntrudeEndPtInfo->uiDTkCallId;
          	IFX_DECT_CSU_CallIntrusionAck(uiSrcDtkCallId,
																					uiHeldDtkCallId,
							        					          IFX_SUCCESS);
					}else{
          	IFX_DECT_CSU_CallConferenceAck(uiHeldDtkCallId,
				    					                     uiSrcDtkCallId,
							        					           NULL,IFX_SUCCESS);
					}
        }
    		printf("After Conf ACK pxEndptInfo=%d pxActiveCall= %d\n",
                (uint32)pxEndptInfo, (uint32)(pxEndptInfo->pxActiveCall));
			  printf("Endpoint =%s\n", pxEndptInfo->szEndptId);

				IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+0),
						IFX_DECT_CS_ACTIVE );
				IFX_DECT_UpdateCallState(pxEndptInfo, (pxEndptInfo->axCallInfo+1),
						IFX_DECT_CS_ACTIVE );

				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_CONFERENCE);
    		printf("Before exit pxActiveCall= %d\n",(uint32)(pxEndptInfo->pxActiveCall));
			}
			else if( IFX_CMGR_STATUS_PENDING == eStatus )
			{
				IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_DIALING);
				IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_CONFERENCE_INITIATED );
			}
		}
		else
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Initiate Conference");
      /* For GAP handsets DTKCallID will be same and conf ack need not be sent*/
       if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){ 
      //if(pxEndptInfo->axCallInfo[0].uiDTkCallId != pxEndptInfo->axCallInfo[1].uiDTkCallId){
					if(IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_INTRUDE_INIT)){
          	IFX_DECT_GetEndptInfoById(pxEndptInfo->szDialledDigits, &pxIntrudeEndPtInfo);
						if( pxIntrudeEndPtInfo->uiInterceptTimerId )
							{
								IFX_TIM_TimerStop(pxIntrudeEndPtInfo->uiInterceptTimerId);
								pxIntrudeEndPtInfo->uiInterceptTimerId = 0;
							}
          	IFX_DECT_CSU_CallIntrusionAck(pxIntrudeEndPtInfo->uiDTkCallId,
																					uiSrcDtkCallId,
							        					          IFX_FAILURE);
					}else{
        		IFX_DECT_CSU_CallConferenceAck(uiSrcDtkCallId,
				                         					pxEndptInfo->uiDTkCallId,
							                   					NULL,IFX_FAILURE);
					}
      }
		}
	} //initiating conference

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_InitiateAutoRedial
 *  Description     : This routine is called to initiate auto-redial on last
 *                    dialed voip number. Allocates DECT resource and initiates 
 *                    call with handset. If call is initated set the flag to
 *                    indicate that once user answers call, initate call to last 
 *                    dialed voip party.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if call is initiated to handset, else
 *                    returns IFX_FAILURE. 
 *  Notes           : This should be called only to initiate auto-redial after
 *                    receiving successfull notify from remote party for auto-
 *                    redial subscription.
 *                    Call is being intiated to last dialed voip number once
 *                    user ansers the call. 
 *                    Currently there is no way handset user to differenciate
 *                    from normal call to this auto-redial call.
 ******************************************************************************/
e_IFX_Return IFX_DECT_InitiateAutoRedial( x_IFX_DECT_EndptFsmInfo* pxEndptInfo )
{
	e_IFX_Return eRet = IFX_SUCCESS;

	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndptId, "Auto Redialing....");

	if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED)	)
	{
		x_IFX_MMGR_CodecInfo* pxMMgrCodec = pxEndptInfo->xReservedCodecs.axCodecs;

		pxMMgrCodec->eCodecType = IFX_MMGR_CODEC_G726_32;
		++pxMMgrCodec;
		pxEndptInfo->xReservedCodecs.ucNoOfCodecs=1;
		if( IFX_TRUE == pxEndptInfo->bWidebandEnabled ) {
			pxMMgrCodec->eCodecType = IFX_MMGR_CODEC_G722_64;
			++pxEndptInfo->xReservedCodecs.ucNoOfCodecs;
		}
		eRet = ( IFX_MMGR_SUCCESS == 
					 	 IFX_MMGR_DectResAlloc(pxEndptInfo->szEndptId, 
						 &pxEndptInfo->unDectChannel,
						 &pxEndptInfo->xReservedCodecs))?IFX_SUCCESS:IFX_FAILURE;
	}
	if(IFX_SUCCESS == eRet )
	{
		x_IFX_DECT_CSU_CallParams xCallParams = {0};
    IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_RESOURCE_ALLOCATED);

		IFX_AGU_GetCallerIdInfo(&pxEndptInfo->xLastDialedAddr, 
				pxEndptInfo->szCallerName, pxEndptInfo->szCallerNumber);
		xCallParams.bwideband = pxEndptInfo->bWidebandEnabled;
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Calling Dect Toolkit IFX_DECT_CSU_CallInitiate" );

		strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);

        xCallParams.bIsPresentation =1;
	if(IFX_CIF_CNIPGet(xCallParams.isInternal,pxEndptInfo->xLastDialedAddr.ucLineId,
										pxEndptInfo->szCallerNumber,pxEndptInfo->szCallerName)==IFX_SUCCESS)
	strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
  printf("CNIP Name5:%s\n",xCallParams.acCNIP);//Don't send CLIP/CNIP in setup
		//TODO check if pxactiveCall is set or not
 
    /*Populate Line Id*/
    xCallParams.ucLineId = pxEndptInfo->xLastDialedAddr.ucLineId;

		IFX_DECT_CSU_CallInitiate (pxEndptInfo->ucInstance+1,
                         	          &xCallParams, 
                         		  (uint32)pxEndptInfo,
	                 		  (uint32 *)&pxEndptInfo->uiDTkCallId); 

    //Send Alert Signal and CLIP/CNIP.
    //IFX_DECT_PlayTone(pxEndptInfo,pxEndptInfo->pxActiveCall->uiDTkCallId,IFX_DECT_SIGNAL_AlertPattern0);

		/* Store ring timeout. This value will be used for ring timer. */
		pxEndptInfo->unRingTimeOut = IFX_RING_TONE_DURATION;
     
    IFX_DECT_SetEndptFlag(pxEndptInfo, IFX_DECT_F_AUTO_REDIAL_IN_PROGRESS);
		IFX_DECT_UpdateEndptState(pxEndptInfo, IFX_DECT_STATE_ALERTING);
	}
	else
	{
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndptId, "Could Not Allocate DECT Resource" );
		eRet = IFX_FAILURE;
	}

	return eRet;	
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetMmgrCodec 
 *  Description     : This function converts CMGR codec type to MMGR codec type.
 *                    If codec is not supported by DECT system, then
 *                    IFX_MMGR_CODEC_NONE is returned. 
 *  Input Values    : uiCodec - CMGR codec type.
 *  Output Values	  : 
 *  Return Value    : Returns valid MMGR codec if DECT system supports, else
 *                    returns IFX_MMGR_CODEC_NONE.
 *  Notes           :
 ******************************************************************************/
e_IFX_MMGR_CodecType IFX_DECT_GetMmgrCodec(uint32 uiCodec)
{
	e_IFX_MMGR_CodecType eMmgrCodecType = IFX_MMGR_CODEC_NONE;
	switch(uiCodec)
	{
	case IFX_G711_ALAW: 
		eMmgrCodecType = IFX_MMGR_CODEC_ALAW;
		break;
	case IFX_G711_ULAW:
		eMmgrCodecType = IFX_MMGR_CODEC_MLAW;
		break;
	case IFX_G726_32: 
		eMmgrCodecType = IFX_MMGR_CODEC_G726_32;
		break;
	case IFX_G722_64:
		eMmgrCodecType = IFX_MMGR_CODEC_G722_64;
		break;
	/*
	case IFX_G722_1_24:
		eMmgrCodecType = IFX_MMGR_CODEC_G722_1_24;
		break;
	case IFX_G722_1_32:
		eMmgrCodecType = IFX_MMGR_CODEC_G722_1_32;
		bReturn = IFX_TRUE;
		break; */
	default:
		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Unknown Codec: Not Supported On DECT System");
		break;
	}

	return eMmgrCodecType;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConvertCodecToMMGR
 *  Description     : This routine converts common(CMGR) codec list to MMGR 
 *                    codec list.
 *  Input Values    : pxList - CMGR codec list .
 *  Output Values	  : pxMmgrList - MMGR codec list.
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : If none of the CMGR codecs are supported by DECT system,
 *                    then pxMmgrList contains zero codec on return.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConvertCodecToMMGR(
	                      OUT x_IFX_MMGR_CodecList* pxMmgrList, 
	                      IN x_IFX_CodecList* pxList)
{
	x_IFX_MMGR_CodecInfo* pxMMGRCodec = pxMmgrList->axCodecs;
	x_IFX_Codec* pxCodec =  pxList->axCodec;
	uchar8 ucCount = 0;
	
	pxMmgrList->ucNoOfCodecs = 0;
	for( ; ucCount < pxList->unNoOfCodecs; ++ucCount, ++pxCodec)
	{
		if( (pxMMGRCodec->eCodecType = 
						IFX_DECT_GetMmgrCodec(pxCodec->uiCodec)) != IFX_MMGR_CODEC_NONE ) {
			++pxMmgrList->ucNoOfCodecs;
			++pxMMGRCodec;
		}
	}
	
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetCmgrCodec 
 *  Description     : This routine converts MMGR codec to CMGR codec.  
 *  Input Values    : eMmgrCodecType - MMGR codec 
 *  Output Values	  : 
 *  Return Value    : If codec is supported, returns matching CMGR codec, else
 *                    returns 0 (zero) 
 *  Notes           :
 ******************************************************************************/
uint32 IFX_DECT_GetCmgrCodec(e_IFX_MMGR_CodecType eMmgrCodecType)
{
	uint32 uiCodec = 0;
	switch(eMmgrCodecType)
	{		
		case IFX_MMGR_CODEC_ALAW: 
			uiCodec = IFX_G711_ALAW ;
			break;
		case IFX_MMGR_CODEC_MLAW: 
			uiCodec = IFX_G711_ULAW ;
			break;
		case IFX_MMGR_CODEC_G726_32:
			uiCodec = IFX_G726_32 ;
			break;
		case IFX_MMGR_CODEC_G722_64:
			uiCodec = IFX_G722_64 ;
			break;
		/*
		case IFX_MMGR_CODEC_G722_1_24:
			uiCodec = IFX_G722_1_24 ;
			break;
		case IFX_MMGR_CODEC_G722_1_32:
			uiCodec = IFX_G722_1_32 ;
			break;*/
		default:
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
					"Unknown Codec: Not Supported On DECT System");
		break;
	}
	return uiCodec;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_ConvertCodecToCmgr
 *  Description     : This routine converts MMGR codec list to CMGR codec list.
 *  Input Values    : pxMmgrList - MMGR codec list.
 *  Output Values	  : pxList     - CMGR codec list.
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : If there are no matching codecs, then CMGR list contains
 *                    no codecs.
 ******************************************************************************/
e_IFX_Return IFX_DECT_ConvertCodecToCmgr(
	                      OUT x_IFX_CodecList* pxList,
	                      IN x_IFX_MMGR_CodecList* pxMmgrList)
{
	x_IFX_MMGR_CodecInfo* pxMMGRCodec = pxMmgrList->axCodecs;
	x_IFX_Codec* pxCodec = pxList->axCodec;
	uchar8 ucCount = 0;

	pxList->unNoOfCodecs = 0;
	for(; ucCount < pxMmgrList->ucNoOfCodecs; ++ucCount, ++pxMMGRCodec)
	{
		if((pxCodec->uiCodec=IFX_DECT_GetCmgrCodec(pxMMGRCodec->eCodecType)) != 0 ) {
			++pxList->unNoOfCodecs;
			++pxCodec;
		}
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_IsWidebandCodec 
 *  Description     : This routine checks whether given codec is a wideband 
 *                    codec 
 *  Input Values    : eCodecType -- MMGR codec type.
 *  Output Values	  : 
 *  Return Value    : return IFX_TRUE if codec is wideband, else returns 
 *                    IFX_FALSE
 *  Notes           :
 ******************************************************************************/
boolean IFX_DECT_IsWidebandCodec(e_IFX_MMGR_CodecType eCodecType)
{
	boolean bWideband = IFX_FALSE;
	if(IFX_MMGR_CODEC_G722_64 == eCodecType )
		bWideband = IFX_TRUE;

	return bWideband;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_PlayTone
 *  Description     : This routine plays given tone on DECT channel. 
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *                    ucSignal - DECT tone signal.
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if tone is being played, else returns
 *                    IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_PlayTone(x_IFX_DECT_EndptFsmInfo* pxEndptInfo, uint32 uiDTkCallId, uchar8 ucSignal)
{
	e_IFX_MMGR_Return eMmgrRet = IFX_MMGR_FAIL;
  int32 eToneType = 0;
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
  printf("Playing the tone %d\n",ucSignal);
#if 0
	strcpy(xCallParams.acCLIP,pxEndptInfo->szCallerNumber);
  if(pxEndptInfo->szCallerName != '\0')
	 strcpy(xCallParams.acCNIP,pxEndptInfo->szCallerName);
#endif 
  if(pxEndptInfo->uiFlags & IFX_DECT_F_TONE_PLAYED){
    IFX_DECT_StopTone(pxEndptInfo,uiDTkCallId);
  }
  xCallParams.uiSignal = ucSignal;
  pxEndptInfo->uiFlags |= IFX_DECT_F_TONE_PLAYED;
  if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2){/*(IFX_DECT_MU_IsCAT2(ucHandsetId)*/
    //Send SIGNAL
    printf("\n Signal IE sent\n");
    printf("\n Signal Value = %d\n",ucSignal);
    if(pxEndptInfo->eState != IFX_DECT_STATE_CALL_WAITING){
     return IFX_DECT_CSU_InfoReceived(uiDTkCallId,
                                     &xCallParams);  
    }else{
      //In Call Waiting and Alerting Signal sent from Tk.
      return IFX_SUCCESS;
     }
  }else{
  
    printf("\n Playing Tone from base\n");
	  if( !IFX_DECT_CheckEndptFlag(pxEndptInfo, IFX_DECT_F_VOICE_ENABLED) ){
      printf("Voice is not enabled so returning without playing tone\n"); 
		  return IFX_SUCCESS;
    }

	  switch(ucSignal)
	  {
		 case IFX_DECT_DIAL_TONE: eToneType = IFX_MMGR_DIAL_TONE; printf("\n Play DIAL TONE\n");break;
		 case IFX_DECT_BUSY_TONE: eToneType = IFX_MMGR_BUSY_TONE; printf("\n Play BUSY TONE\n");break;
		 case IFX_DECT_ERROR_TONE: eToneType = IFX_MMGR_ERROR_TONE; printf("\n Play ERROR TONE\n");break;
		 case IFX_DECT_CONFIRMATION_TONE: eToneType = IFX_MMGR_CONFIRMATION_TONE; printf("\n Play CONFIRMATION TONE\n");break;
		 case IFX_DECT_RINGBACK_TONE: eToneType = IFX_MMGR_RING_BACK_TONE; printf("\n Play RINGBACK TONE\n");break;
		 case IFX_DECT_CALL_WAITING_TONE: eToneType = IFX_MMGR_CALL_WAITING_TONE; printf("\n Play CALL WAIT TONE\n");break;
		 case IFX_DECT_STUTTER_TONE: eToneType = IFX_MMGR_STUTTER_DIAL_TONE; break;
		 case IFX_DECT_OFF_HOOK_TONE: eToneType = IFX_MMGR_OFF_HOOK_WARNING_TONE; printf("\n Play OFF HOOK TONE\n");break;
		 case IFX_DECT_INTERCEPT_TONE:eToneType = IFX_MMGR_PROMPT_TONE;printf("\n Play Prompt TONE\n");break;
     default: ;
	  }
	  if( IFX_MMGR_MAX_TONE != eToneType){
      printf("Playing MMGR tone\n");
		  eMmgrRet = IFX_MMGR_TonePlay(pxEndptInfo->szEndptId, eToneType, NULL);
	    return (IFX_MMGR_SUCCESS==eMmgrRet)?IFX_SUCCESS:IFX_FAILURE;
    } 
   }
   return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_StopTone
 *  Description     : This function stops the tone on DECT channel. 
 *  Input Values    : pxEndptInfo - Pointer to DECT endpoint info.
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if tone is stopped on DECT channel,
 *                    else returns IFX_FAILURE.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_StopTone(x_IFX_DECT_EndptFsmInfo* pxEndptInfo,uint32 uiDTkCallId)
{
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  if(pxEndptInfo->uiFlags & IFX_DECT_F_TONE_PLAYED){
    xCallParams.uiSignal = IFX_DECT_SIGNAL_TonesOff;
    pxEndptInfo->uiFlags &= ~(IFX_DECT_F_TONE_PLAYED);
    if(pxEndptInfo->uiTermCap & IFX_DECT_MU_HS_CAT2)/*(IFX_DECT_MU_IsCAT2(ucHandsetId)*/{
      printf("Sending Tones off 2.0\n");
      //Send SIGNAL
      return IFX_DECT_CSU_InfoReceived(uiDTkCallId,
                                     &xCallParams);  
    }else{
      printf("Stopping MMGR tone\n");
	    return (IFX_MMGR_SUCCESS == IFX_MMGR_ToneStop(pxEndptInfo->szEndptId))
			  		 ?IFX_SUCCESS:IFX_FAILURE;
    }
 }
 return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetStateStr
 *  Description     : This routine is used to get human redable string for a 
 *                    given DECT FSM state. 
 *  Input Values    : eState - FSM state type.
 *  Output Values	  : 
 *  Return Value    : Returns pointer to string. 
 *  Notes           :
 ******************************************************************************/
char8* IFX_DECT_GetStateStr( IN e_IFX_DECT_States eState )
{
	static char8* aszStates[IFX_DECT_STATE_MAX+1] = 
	{
		"Handset Is In IDLE State",	           /** Idle*/
		"Handset Is In DIALING State",	         /** Outcall - Dialing */
		"Handset Is In RINGBACK State",	       /** Outcll - Ringback */
		//"Handset Is In PROCEEDING State", /** Incall - proceding */
		"Handset Is In ALERTING State",	         /** Incall - Alerting(ringing) */
		"Handset Is In ACTIVE State",	         /** Call active/in conversation */
		"Handset Is In WAITING State",	   /** Call Waiting */
		"Handset Is In CONFERENCE State",	     /** Conferene */
		"Handset Is In BUSY State",	   /** Service Call -SMS/Info send or recv */
		"!!** Handset Is In INVALID State **!!"
	};

	if( eState > IFX_DECT_STATE_BUSY )
		eState = IFX_DECT_STATE_MAX;
	return aszStates[eState];
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_GetEventStr 
 *  Description     : This routine is used to get human readable event string.
 *  Input Values    : eEvent - event type
 *  Output Values	  : 
 *  Return Value    : Returns pointer to string. 
 *  Notes           :
 ******************************************************************************/
char8* IFX_DECT_GetEventStr( IN  e_IFX_DECT_Event eEvent)
{
	static char8* aszDectEvents[IFX_DECT_EventMax+1] =
	{
		"IFX_DECT_EVT_PP_OffHook",	      /** Off-hook -- Setup from PP */
		"IFX_DECT_EVT_PP_OnHook",	        /** On-hook -- Call Release PP */
		"IFX_DECT_EVT_PP_Alert",	        /** PP alerted */
		"IFX_DECT_EVT_PP_Reject",	        /** PP Rejected call */ 
		"IFX_DECT_EVT_PP_HookFlash",	    /** Hook-flash event */
		"IFX_DECT_EVT_PP_DigitPressed",	  /** Digit pressed */
		"IFX_DECT_EVT_PP_SSMsg",	        /** Suplimentary Serivce Message */
		"IFX_DECT_EVT_PP_SCMsg",	        /** Service Call Message */
	  "IFX_DECT_EVT_PP_SlotModInd",	    /** Slot mod ind */
#ifdef ENABLE_ENCRYPTION
		"IFX_DECT_EVT_PP_CipherStatus",		/** Ciphering */
#endif
		/* DECT FSM Timer Events */
		"IFX_DECT_EVT_DialTimerExpired",	     /** Dial timer expired */
		"IFX_DECT_EVT_InterDigitTimerExpired", /** Interdigit timer expired */
		"IFX_DECT_EVT_RingTimerExpired",	     /** Ring timer expired */
		"IFX_DECT_EVT_RingpauseTimerExpired",	 /** Ringpause timer expired */
		"IFX_DECT_EVT_RingbackTimerExpired",	 /** Ringback timer expired */
		"IFX_DECT_EVT_BCETimerExpired",	       /** BCE timer expired */
		/* Call control events from call manager */
		"IFX_DECT_EVT_IncomingCall",	/** Incoming call */
		"IFX_DECT_EVT_ReleaseCall",  	/** Release call */
		"IFX_DECT_EVT_RmtAccept",    	/** Remote accepted call */
		"IFX_DECT_EVT_RmtAnswer",    	/** Remote answered call */
		"IFX_DECT_EVT_RmtHold",			 	/** Remote held call */
		"IFX_DECT_EVT_RmtResume",    	/** Remote resumed call */
		"IFX_DECT_EVT_HoldResp",  		/** Call hold response */
		"IFX_DECT_EVT_ResumeResp",    /** Call resume response */
		"IFX_DECT_EVT_BtxResp",    		/** Call BTX response */
		"IFX_DECT_EVT_AtxResp",    		/** Call ATX response */
		"IFX_DECT_EVT_ConfStatus",    /** Conference status */
		/* Paging key events */
		"IFX_DECT_EVT_Paging",	      /** Paging button pressed */
		"IFX_DECT_EventMax"
	};

	if( eEvent > IFX_DECT_EVT_Paging )
		eEvent = IFX_DECT_EventMax;
	return aszDectEvents[eEvent];
}

e_IFX_Return IFX_DECT_GetBCD(IN uchar8 ucTimeDateInfo,OUT uchar8 *pcBCDInfo)
{
  uchar8 ucTemp = 0;
  uchar8 ucTemp2= 0;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<GetBCD>Entry.");
	
  *pcBCDInfo = 0;


  if(((ucTimeDateInfo & 0XF0) == 0)&&((ucTimeDateInfo & 0X0F) <= 9)){

				   
   *pcBCDInfo = ucTimeDateInfo;
   return IFX_SUCCESS;
  }
				  
  while(ucTimeDateInfo != 0){
	ucTemp = ucTimeDateInfo % 10;
	*pcBCDInfo |= ucTemp;
    ucTimeDateInfo /= 10;
	if(ucTimeDateInfo !=0){
	  *pcBCDInfo <<= 4;
	}
  }

   //Now Reversing two semi-octets.
   ucTemp2 = (*pcBCDInfo & 0X0F);
   ucTemp2 <<= 4;
   *pcBCDInfo >>=4;
   *pcBCDInfo |= ucTemp2;
    return IFX_SUCCESS;
}
/*******************************************************************************
*  Function Name   : IFX_DECT_GetDateTime
*  Description     : This routine is invoked to read the system date and time.
*                    
*  Input Values    : pointer to DateTime structure.
*  Output Values   : filled DateTime structure.
*  Return Value    : IFX_SUCCESS or IFX_FAILURE.
*  Notes           :
******************************************************************************/
		
e_IFX_Return IFX_DECT_GetTimeDate(OUT x_IFX_DECT_USU_TimeDate *pxTimeDate){

  time_t theTime;
  struct tm *t;
  
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
				"<GetTimeDate>Entry");
  theTime = time((time_t *) NULL);
  t=localtime(&theTime);
	if(t != NULL){
  IFX_DECT_GetBCD((t->tm_year)-100,&pxTimeDate->ucYear);
  IFX_DECT_GetBCD((uchar8)(t->tm_mon+1),&pxTimeDate->ucMonth);
  IFX_DECT_GetBCD(t->tm_mday,&pxTimeDate->ucDay);
  IFX_DECT_GetBCD(t->tm_hour,&pxTimeDate->ucHour);
  IFX_DECT_GetBCD(t->tm_min,&pxTimeDate->ucMinutes);
  IFX_DECT_GetBCD(t->tm_sec,&pxTimeDate->ucSeconds);
  IFX_DECT_GetBCD(((t->tm_gmtoff)/(60*15)),&pxTimeDate->ucTimeZone);
}
  printf("The Time is Year %x Month %x Day %x Hours %x, Minutes %x seconds %x zone %x\n",
         pxTimeDate->ucYear,pxTimeDate->ucMonth,pxTimeDate->ucDay,pxTimeDate->ucHour,
		 pxTimeDate->ucMinutes,pxTimeDate->ucSeconds,pxTimeDate->ucTimeZone);
  return IFX_SUCCESS;
}

/*******************************************************************************
*  Function Name   : IFX_DECTAPP_ListAccessNtfn
*  Description     : Callback to register with CallManager
*                    
*  Input Values    : 
*  Output Values   : 
*  Return Value    : 
*  Notes           :
******************************************************************************/
e_IFX_Return IFX_DECTAPP_ListAccessNtfn (
                IN char8 *pszEndPtId,
                IN e_IFX_CMGR_LA_Type eLAType,
                IN void *pxOld,
                IN void *pxNew)
{
	printf("<IFX_DECTAPP_ListAccessNtfn>Entry\n");
  uchar8 ucHandset = 0;
 
  if(pszEndPtId == '\0'){
    return IFX_FAILURE;
  }
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 pszEndPtId, "For EndPointId");
  ucHandset = IFX_DECT_HsIdFromEPName(pszEndPtId);
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Handset Id = ", ucHandset);

  switch(eLAType){
      case IFX_CMGR_LA_CONTACTS:
			case IFX_CMGR_COMMON_CONTACTS:
        //TODO Commented to too avoid Facility  and PT initiated CC_SETUP collision 
         //IFX_DECTAPP_ContactListNotify(ucHandset,pxOld,pxNew);
	 break;

      case  IFX_CMGR_LA_MISSED_CALLS:
         IFX_DECTAPP_MissedCallNotify(ucHandset,pxOld,pxNew);
	 break;

      case  IFX_CMGR_LA_OUTGOING_CALLS:
        //TODO Commented to too avoid Facility  and PT initiated CC_SETUP collision 
        // IFX_DECTAPP_OutgoingCallNotify(ucHandset,pxOld,pxNew);
	 break;
      case  IFX_CMGR_LA_INCOMING_ACCEPT_CALLS:
        //TODO Commented to too avoid Facility  and PT initiated CC_SETUP collision 
        // IFX_DECTAPP_IncomingCallNotify(ucHandset,pxOld,pxNew);
	break;
    case  IFX_CMGR_LA_LINE_SETTINGS_ASSOC:
        IFX_DECTAPP_LineSettingsNotify(ucHandset,IFX_DECTAPP_LINEOBJ_LINEASSOC,pxOld,pxNew);
        break;
    case  IFX_CMGR_LA_LINE_SETTINGS_CF:
        IFX_DECTAPP_LineSettingsNotify(ucHandset,IFX_DECTAPP_LINEOBJ_CALLFEAT,pxOld,pxNew);
        break;
    case  IFX_CMGR_LA_LINE_SETTINGS_PSTN:
        IFX_DECTAPP_LineSettingsNotify(ucHandset,IFX_DECTAPP_LINEOBJ_PSTN,pxOld,pxNew);
        break;
    case  IFX_CMGR_LA_INTERNAL_NAMES:
        IFX_DECTAPP_InternalNamesNotify(ucHandset,pxOld,pxNew); 
        break;
    case  IFX_CMGR_LA_SYSTEM_SETTINGS:
        //TODO Commented to too avoid Facility  and PT initiated CC_SETUP collision 
        //IFX_DECTAPP_SystemSettingsNotify(ucHandset,pxOld,pxNew); 
        break;  
    
		default:
				 printf("Invlaid Notification\n"); 
         //return IFX_FAILURE;
				 break;
	}
	return IFX_SUCCESS;

}


/*******************************************************************************
*  Function Name   : IFX_DECTAPP_FreeVmapi_Obj
*  Description     : Callback to register with CallManager
*                    
*  Input Values    : 
*  Output Values   : 
*  Return Value    : 
*  Notes           :
******************************************************************************/
e_IFX_Return IFX_DECTAPP_FreeVmapiObj (IN e_IFX_CMGR_LA_Type eLAType,
                                         IN void *pxOld,
                                         IN void *pxNew){

 return IFX_CIF_FreeVmapiObj(eLAType,pxOld,pxNew);
}


/*******************************************************************************
*  Function Name   : IFX_DECTAPP_DateTimeNtfn
*  Description     : Callback to register with CallManager
*                    
*  Input Values    : 
*  Output Values   : 
*  Return Value    : 
*  Notes           :
******************************************************************************/
e_IFX_Return IFX_DECTAPP_DateTimeNtfn(IN char8 *pszEndPtId,
                                      IN void *pxOld,
                                      IN void *pxNew){

  x_IFX_DECT_USU_TimeDate xTimeDate = {0};
  uchar8 ucHandset = 0;
 
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<IFX_DECTAPP_DateTimeNtfn>Entry");
  if(pszEndPtId == '\0'){
    return IFX_FAILURE;
  }
  ucHandset = IFX_DECT_HsIdFromEPName(pszEndPtId);
	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			      "Handset Id = ", ucHandset);
  IFX_DECT_GetTimeDate(&xTimeDate);
  if(IFX_SUCCESS != IFX_DECT_USU_DateTimeSync(ucHandset, &xTimeDate)){

     IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
              IFX_DBG_STR,"Failed to Update TimeDate of PT");
     return IFX_FAILURE;
  }else{
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,
             IFX_DBG_STR,"Updated TimeDate of PT");
    return IFX_SUCCESS; 
   }
}

void
IFX_DECT_EndpointLineIdGet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                           OUT IN uchar8 *pucLineId){

  if(pxEndptInfo->pxActiveCall == NULL){                                                                                                                               
    *pucLineId = pxEndptInfo->axCallInfo[0].ucLineId; 
  }else{                                                                                                                                                               
    *pucLineId = (pxEndptInfo->pxActiveCall->uiDTkCallId == pxEndptInfo->axCallInfo[0].uiDTkCallId)?
                  pxEndptInfo->axCallInfo[1].ucLineId:pxEndptInfo->axCallInfo[0].ucLineId;
   }
  return;
}

void
IFX_DECT_EndpointLineIdSet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo,
                           IN uchar8 ucLineId){

  /*If Call is first call for the HS populate Line Id in CallInfo[0] 
    else in CallInfo[1] in EndptInfo struct*/
  if(pxEndptInfo->pxActiveCall == NULL){                                                                                                                                
    pxEndptInfo->axCallInfo[0].ucLineId = ucLineId;                                                                                                       
  }else{                                                                                                                                                                
    if(pxEndptInfo->pxActiveCall->uiDTkCallId == pxEndptInfo->axCallInfo[0].uiDTkCallId)                                                                                
      pxEndptInfo->axCallInfo[1].ucLineId = ucLineId;                                                                                                     
    else                                                                                                                                                                
        pxEndptInfo->axCallInfo[0].ucLineId = ucLineId;                                                                                                     
    }                                                                 
  printf("\n ucLineId set in Endpt=%d\n",ucLineId);
  return;
}

e_IFX_Return
IFX_DECT_IsEndpointLineIdSet(IN x_IFX_DECT_EndptFsmInfo* pxEndptInfo){

  /*Check whether Line Id is already populated for the Handset Call*/
  if(pxEndptInfo->pxActiveCall == NULL){                                                                                                                                
    if(!pxEndptInfo->axCallInfo[0].ucLineId)                                                                                                                           
      return IFX_FAILURE;  
  }else{                                                                                                                                                                
                                                                                                                                                                          
    if(pxEndptInfo->pxActiveCall->uiDTkCallId == pxEndptInfo->axCallInfo[0].uiDTkCallId){                                                                               
      if(!pxEndptInfo->axCallInfo[1].ucLineId)                                                                                                                          
        return IFX_FAILURE;  
    }else{                                                                                                                                                              
      if(!pxEndptInfo->axCallInfo[0].ucLineId)                                                                                                                          
        return IFX_FAILURE;  
     }                                                                                                                                                                  
   }                                                            
  return IFX_SUCCESS;
}


