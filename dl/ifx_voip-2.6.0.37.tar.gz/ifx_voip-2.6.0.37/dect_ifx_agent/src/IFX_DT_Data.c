#include<stdio.h>
#include<math.h>
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include <ixml.h>
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_ListAccess.h"
//#include "IFX_DECT_Agent.h"
#include "IFX_DT_LAU.h"
#include "IFX_DT_Data.h"

#ifdef LTQ_DT_SUPPORT
int32 dateTimeInfo[7];

/* Date and time Tokenizer */

int32 dateTokenizer(char8* mydatetime){
//yy:mm:dd:hr:mi:sec
char8 *str1;
int32 x=0;
/* print what we have so far */
        printf("String: %s\n", mydatetime);
        /* extract first string from string sequence */
        str1 = strtok(mydatetime, ":");

        /* print first string after tokenized */
        //printf("%i: %s : %x :%x\n", x, str1,atoi(str1),atoi(str1));
          dateTimeInfo[x]=atoi(str1);
          x++;
        /* loop until finishied */
        while (1)
        {
                /* extract string from string sequence */
                str1 = strtok(NULL, ":");

                /* check if there is nothing else to extract */
                if (str1 == NULL)
                        break;
                /* print string after tokenized */
                dateTimeInfo[x]=atoi(str1);
                x++;
        }
return 0;
}


//Ceil Function....
int CEIL(double var)
{
	int integer = (int)var;
	if(var - integer == 0) 
		return integer;
	else 
		return integer + 1;
}


/** 
	Test function: IFX_Get_EmailTreeList
	 Purpose : to Read the Email Tree List from the configuration  file /flash/rssemail.txt...
*/

void IFX_Get_EmailTreeList(x_IFX_EMAIL *axEmail){
FILE *fp;
char pcMsgBody[10000]={'\0'};
IXML_Document *pxXmlDoc = NULL;
IXML_NodeList *pxXmlTitleList = NULL, *pxXmlLinkList = NULL,*pxXmlNodeList = NULL;
IXML_Node *pxXmlNode = NULL, *pxXmlValueNode = NULL;
int i=0,c;

  fp = fopen("/flash/rssemail.txt","r");
  while ((c = fgetc(fp)) != EOF) {
    pcMsgBody[i]=c;
    i++;
  }
  fclose(fp);
  printf("Initialzing the  Email Account List \n");
  if((i = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != 0){
    return ;
  }
   pxXmlNodeList=ixmlDocument_getElementsByTagName(pxXmlDoc,"email");
   pxXmlTitleList = ixmlDocument_getElementsByTagName(pxXmlDoc,"account");
   pxXmlLinkList = ixmlDocument_getElementsByTagName(pxXmlDoc,"emailid");


  axEmail->ucNumOfAccounts=ixmlNodeList_length(pxXmlNodeList);
	if(axEmail->ucNumOfAccounts > IFX_MAX_NUM_OF_MAIL_ACCOUNTS)
				axEmail->ucNumOfAccounts = IFX_MAX_NUM_OF_MAIL_ACCOUNTS;

  for(i=0; i < axEmail->ucNumOfAccounts ; i++){
  axEmail->axMailAccounts[i].nEntryId=i+1;
      axEmail->axMailAccounts[i].uiUpdateTime=50;
			axEmail->axMailAccounts[i].xAttachedPP.cNoOfPP=3;
      strcpy(axEmail->axMailAccounts[i].xAttachedPP.acAttachedPP,"123\0");
      axEmail->axMailAccounts[i].ucUnreadMsgs=0;
      axEmail->axMailAccounts[i].ucTotalMsgs=0;
			//Getting the title of the Email Account 
        pxXmlNode = ixmlNodeList_item(pxXmlTitleList, i);
        pxXmlValueNode = ixmlNode_getFirstChild(pxXmlNode);
        printf("TITLE is %s\n",ixmlNode_getNodeValue(pxXmlValueNode));
        strcpy((char8*)axEmail->axMailAccounts[i].ucAccountName,ixmlNode_getNodeValue(pxXmlValueNode));
      //Getting url of the Email Account 
        pxXmlNode = ixmlNodeList_item(pxXmlLinkList, i);
        pxXmlValueNode = ixmlNode_getFirstChild(pxXmlNode);
        printf("URL is %s\n",ixmlNode_getNodeValue(pxXmlValueNode));
        strcpy((char8*)axEmail->axMailAccounts[i].ucEmailAddress,ixmlNode_getNodeValue(pxXmlValueNode));
  }
ixmlNodeList_free(pxXmlTitleList);
ixmlNodeList_free(pxXmlLinkList);
ixmlNodeList_free(pxXmlNodeList);
ixmlDocument_free(pxXmlDoc);
}


/**
	 Test function: IFX_Get_RssTreeList
	 Purpose : to Read the RSS Tree List from the configuration  file /flash/rssemail.txt...
*/
void IFX_Get_RssTreeList(x_IFX_RSS_FEEDS *xRssFeed){
FILE *fp;
char pcMsgBody[10000]={'\0'};
IXML_Document *pxXmlDoc = NULL;
IXML_NodeList *pxXmlTitleList = NULL, *pxXmlLinkList = NULL,*pxXmlNodeList = NULL; 
IXML_Node *pxXmlNode = NULL, *pxXmlValueNode = NULL;
int i=0,c;

  fp = fopen("/flash/rssemail.txt","r");
	if(fp == NULL){
	printf("rssemail.txt doesn't exist... \n");
	return;
	}
		
  while ((c = fgetc(fp)) != EOF) {
    pcMsgBody[i]=c;
    i++;
  }
  fclose(fp);
  printf("Initialzing the  RSS Chanel List \n");
  if((i = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != 0){
    return ;
  }
   pxXmlNodeList=ixmlDocument_getElementsByTagName(pxXmlDoc,"chanel");
	 pxXmlTitleList = ixmlDocument_getElementsByTagName(pxXmlDoc,"title");
   pxXmlLinkList = ixmlDocument_getElementsByTagName(pxXmlDoc,"link");
	 xRssFeed->ucNumOfChannels=ixmlNodeList_length(pxXmlNodeList);
	if(xRssFeed->ucNumOfChannels > IFX_MAX_NUM_OF_CHANNELS )
		xRssFeed->ucNumOfChannels = IFX_MAX_NUM_OF_CHANNELS;

  for(i=0; i < xRssFeed->ucNumOfChannels  ; i++){
      xRssFeed->axChannelList[i].nEntryId=i+1;
      xRssFeed->axChannelList[i].uiUpdateIntrvl=60;
			xRssFeed->axChannelList[i].xAttachedPP.cNoOfPP=3;
			strcpy(xRssFeed->axChannelList[i].xAttachedPP.acAttachedPP,"123\0");
      		xRssFeed->axChannelList[i].ucUnreadMsgCount=0;
		      xRssFeed->axChannelList[i].ucTotalMsgCount=0;
          xRssFeed->axChannelList[i].eChannelType=IFX_DT_READ;
       		
				//Getting the title of the chanel
				pxXmlNode = ixmlNodeList_item(pxXmlTitleList, i);
				pxXmlValueNode = ixmlNode_getFirstChild(pxXmlNode);
        printf("TITLE is %s\n",ixmlNode_getNodeValue(pxXmlValueNode));
  			strcpy((char8 *)xRssFeed->axChannelList[i].ucChannelTitle,ixmlNode_getNodeValue(pxXmlValueNode));
	 		//Getting url of the chanel 
				pxXmlNode = ixmlNodeList_item(pxXmlLinkList, i);
				pxXmlValueNode = ixmlNode_getFirstChild(pxXmlNode);
        printf("URL is %s\n",ixmlNode_getNodeValue(pxXmlValueNode));
        strcpy((char8 *)xRssFeed->axChannelList[i].ucChannelURL,ixmlNode_getNodeValue(pxXmlValueNode));
  }
ixmlNodeList_free(pxXmlTitleList);
ixmlNodeList_free(pxXmlLinkList);
ixmlNodeList_free(pxXmlNodeList);
ixmlDocument_free(pxXmlDoc);

}


/**
	Test Function : IFX_Get_NetPhoneBook 
	Purpose : To Initialize NetPhoneBook with few entries
*/ 
void IFX_Get_NetPhoneBook(x_IFX_NET_PHONE_BOOK *xPhoneBook){
  uint16 i=0;
  xPhoneBook->unNoOfEntries=5;
  for(i=0; i < 5 ; i++){
      xPhoneBook->axPhoneBookEntries[i].nEntryId=i+1;
    switch(i){
    case 0:
      strcpy(xPhoneBook->axPhoneBookEntries[i].acLastName,"Kumar");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acFirstName,"Ravi ");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acCity,"Bangalore");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acStreet,"9th cross");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acZip,"560016");
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucYear,"1983",4);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucMonth,"10",2);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucDay,"11",2);
       xPhoneBook->axPhoneBookEntries[i].xNumber.ucNoOfContactNumbers=3;
      xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].ctype=IFX_DT_FAX;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].acNumber,"7259520059");
       xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].ctype=IFX_DT_MOBILE;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].acNumber,"08934598978");
       xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[2].ctype=IFX_DT_FIXED;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[2].acNumber,"08934538389");
    break;
case 1:
      strcpy(xPhoneBook->axPhoneBookEntries[i].acLastName,"Kiran");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acFirstName,"KS ");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acCity,"Beopier");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acStreet,"crossi11");
			strcpy(xPhoneBook->axPhoneBookEntries[i].acZip,"561983");
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucYear,"1985",4);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucMonth,"11",2);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucDay,"11",2);
			xPhoneBook->axPhoneBookEntries[i].xNumber.ucNoOfContactNumbers=3;
      xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].ctype=IFX_DT_FAX;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].acNumber,"987654321");
       xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].ctype=IFX_DT_MOBILE;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].acNumber,"08998303459");
       xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[2].ctype=IFX_DT_FIXED;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[2].acNumber,"123456789");
    break;
case 2:
      strcpy(xPhoneBook->axPhoneBookEntries[i].acLastName,"Swaroop");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acFirstName,"uyter ");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acCity,"olkjghe");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acStreet,"19 cross");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acZip,"001683");
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucYear,"1986",4);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucMonth,"06",2);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucDay,"26",2);
       xPhoneBook->axPhoneBookEntries[i].xNumber.ucNoOfContactNumbers=2;
      xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].ctype=8;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].acNumber,"9376433459");
       xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].ctype=4;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].acNumber,"098393459");
    break;
case 3:
      strcpy(xPhoneBook->axPhoneBookEntries[i].acLastName,"Bala");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acFirstName,"Bala");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acCity,"Ban98ikj");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acStreet,"91thxx cross");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acZip,"560916");
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucYear,"1978",4);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucMonth,"02",2);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucDay,"28",2);
       xPhoneBook->axPhoneBookEntries[i].xNumber.ucNoOfContactNumbers=1;
      xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].ctype=8;
strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].acNumber,"789562989");
    break;
case 4:
      strcpy(xPhoneBook->axPhoneBookEntries[i].acLastName,"aarif");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acFirstName,"aarif");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acCity,"Bangalore");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acStreet,"cross21st");
      strcpy(xPhoneBook->axPhoneBookEntries[i].acZip,"5098016");
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucYear,"1983",4);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucMonth,"06",2);
      strncpy((char *)xPhoneBook->axPhoneBookEntries[i].xBirthDay.ucDay,"01",2);
       xPhoneBook->axPhoneBookEntries[i].xNumber.ucNoOfContactNumbers=2;
      xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].ctype=1;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[0].acNumber,"520059898");
       xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].ctype=8;
      strcpy(xPhoneBook->axPhoneBookEntries[i].xNumber.xNum[1].acNumber,"893459987");
    break;
}
}

}


/**
	Test Function : IFX_Get_RSSSubList
	Purpose : To initializes the RSS sublist from file(s) chanel1.txt/chanel2.txt/...chanelN.txt files
 */

void IFX_Get_RSSSubList(x_IFX_RSS_SUBLISTFEEDS *xChanel,uchar8 uCNo){
FILE *fp;
char cFileName[20];
char acDateTimeText[25];
char pcMsgBody[10000]={'\0'};
IXML_Document *pxXmlDoc = NULL;
IXML_NodeList *pxXmlTitleList = NULL, *pxXmlLinkList = NULL, *pxXmlDescList = NULL, *pxXmlDateTimeList = NULL,*pxXmlStatusList = NULL;
IXML_Node *pxXmlNode = NULL, *pxXmlFirstChildNode = NULL/*,*pxXmlGrandChildNode = NULL*/;
//char str[7][30]={"title","description","link","guid","pubDate"};
int i=0,c;

sprintf(cFileName,"/flash/chanel%d.txt",uCNo);

  fp = fopen(cFileName,"r");
if(fp == NULL){
printf("Chanel Feed File %s Doesn't exist \n",cFileName);
return;
}
  while ((c = fgetc(fp)) != EOF) {
    pcMsgBody[i]=c;
    i++;
  }
  fclose(fp);
	printf("Initialzing the Sub-List of Chanel %d \n",uCNo);
  if((i = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != 0){
	printf("Error parsing the XML Contents of File %s \n",cFileName);  
  return ;
  }
	 pxXmlTitleList = ixmlDocument_getElementsByTagName(pxXmlDoc,"title");
	 pxXmlLinkList = ixmlDocument_getElementsByTagName(pxXmlDoc,"link");
	 pxXmlDescList = ixmlDocument_getElementsByTagName(pxXmlDoc,"description");
   pxXmlDateTimeList = ixmlDocument_getElementsByTagName(pxXmlDoc,"pubDate");	
   pxXmlStatusList = ixmlDocument_getElementsByTagName(pxXmlDoc,"readstatus");	
  
xChanel->ucNumOfEntries/*pxRssFeed.axChannelList[uCNo-1].ucTotalMsgCount*/=ixmlNodeList_length(pxXmlTitleList);
	/*pxRssFeed.axChannelList[uCNo-1].ucUnreadMsgCount=xChanel->ucNumOfEntries;	*/

	if(xChanel->ucNumOfEntries > IFX_MAX_NUM_OF_SUB_ENTRIES )
		xChanel->ucNumOfEntries = IFX_MAX_NUM_OF_SUB_ENTRIES;
  for(i=0; i < xChanel->ucNumOfEntries; i++){
      xChanel->axChannelEntries[i].nEntryId=i+1;
      //xChanel->axChannelEntries[i].bStatus=1;
			
			//Get the tittle
			pxXmlNode = ixmlNodeList_item(pxXmlTitleList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy((char8*) xChanel->axChannelEntries[i].ucTitle, ixmlNode_getNodeValue(pxXmlFirstChildNode));
			printf("Tittle : %s\n",xChanel->axChannelEntries[i].ucTitle);	
			
			//Get the link
			pxXmlNode = ixmlNodeList_item(pxXmlLinkList, i);
       pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy((char8*) xChanel->axChannelEntries[i].ucURL,ixmlNode_getNodeValue(pxXmlFirstChildNode));
			printf("URL : %s\n",xChanel->axChannelEntries[i].ucURL);	
		
			//get the desc
			pxXmlNode = ixmlNodeList_item(pxXmlDescList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy((char8*) xChanel->axChannelEntries[i].ucText,ixmlNode_getNodeValue(pxXmlFirstChildNode));
			printf("Text : %s\n",xChanel->axChannelEntries[i].ucText);
		
			//get the read status
				pxXmlNode = ixmlNodeList_item(pxXmlStatusList, i);
	  	  pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      	xChanel->axChannelEntries[i].bStatus = atoi(ixmlNode_getNodeValue(pxXmlFirstChildNode));
      	printf("Read Status : %d\n",xChanel->axChannelEntries[i].bStatus);


			//get the date time
			pxXmlNode = ixmlNodeList_item(pxXmlDateTimeList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy(acDateTimeText,ixmlNode_getNodeValue(pxXmlFirstChildNode));
			memset(&dateTimeInfo,0,sizeof(dateTimeInfo));	
		  dateTokenizer(acDateTimeText);
			IFX_DECT_GetBCD((uchar8)dateTimeInfo[0]-100,&xChanel->axChannelEntries[i].xTimeDate.ucYear);
		  IFX_DECT_GetBCD((uchar8)dateTimeInfo[1],&xChanel->axChannelEntries[i].xTimeDate.ucMonth);
      IFX_DECT_GetBCD((uchar8)dateTimeInfo[2],&xChanel->axChannelEntries[i].xTimeDate.ucDay);
    	IFX_DECT_GetBCD((uchar8)dateTimeInfo[3],&xChanel->axChannelEntries[i].xTimeDate.ucHour);
     	IFX_DECT_GetBCD((uchar8)dateTimeInfo[4],&xChanel->axChannelEntries[i].xTimeDate.ucMinutes);
     	IFX_DECT_GetBCD((uchar8)dateTimeInfo[5],&xChanel->axChannelEntries[i].xTimeDate.ucSeconds);
					
	}
ixmlNodeList_free(pxXmlTitleList);
ixmlNodeList_free(pxXmlLinkList);
ixmlNodeList_free(pxXmlDescList);
ixmlNodeList_free(pxXmlDateTimeList);
ixmlDocument_free(pxXmlDoc);
}

/**
	Test Function : IFX_Get_EmailSubList
	Purpose : To initializes the Email sublist from file(s) email1.txt/email2.txt/...emailN.txt files
 */

void IFX_Get_EmailSubList(x_IFX_EMAIL_INBOXENTRIES *xMailList,uchar8 uCNo){
FILE *fp;
char cFileName[20];
char pcMsgBody[10000]={'\0'};
char acDateTimeText[25];
IXML_Document *pxXmlDoc = NULL;
IXML_NodeList *pxXmlTitleList = NULL, *pxXmlLinkList = NULL, *pxXmlDescList = NULL,*pxXmlStatusList = NULL,*pxXmlDateTimeList = NULL;
IXML_Node *pxXmlNode = NULL, *pxXmlFirstChildNode = NULL/*,*pxXmlGrandChildNode = NULL*/;
int i=0,c;

sprintf(cFileName,"/flash/email%d.txt",uCNo);

fp = fopen(cFileName,"r");
if(fp  == NULL){
printf("Email Feed File %s Doesn't exist \n",cFileName);
return;
}
  while ((c = fgetc(fp)) != EOF) {
    pcMsgBody[i]=c;
    i++;
  }
  fclose(fp);
  printf("Initialzing the Sub-List of Email %d \n",uCNo);
  if((i = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != 0){
  printf("Error parsing the XML Contents of File %s \n",cFileName);
  return ;
  }
   pxXmlTitleList = ixmlDocument_getElementsByTagName(pxXmlDoc,"subject");
   pxXmlLinkList = ixmlDocument_getElementsByTagName(pxXmlDoc,"mailid");
   pxXmlDescList = ixmlDocument_getElementsByTagName(pxXmlDoc,"message");
   pxXmlStatusList = ixmlDocument_getElementsByTagName(pxXmlDoc,"readstatus");
	 pxXmlDateTimeList = ixmlDocument_getElementsByTagName(pxXmlDoc,"pubDate");

  xMailList->ucNumOfEntries=ixmlNodeList_length(pxXmlTitleList);
	if(xMailList->ucNumOfEntries > IFX_MAX_NUM_OF_MAIL_ENTRIES)
		xMailList->ucNumOfEntries = IFX_MAX_NUM_OF_MAIL_ENTRIES;
  for(i=0; i < xMailList->ucNumOfEntries ; i++){
  xMailList->axInboxEntries[i].nEntryId=i+1;
      xMailList->axInboxEntries[i].bStatus=1;
			//Get the tittle
      pxXmlNode = ixmlNodeList_item(pxXmlTitleList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
     	strcpy((char8*)xMailList->axInboxEntries[i].ucSubject,ixmlNode_getNodeValue(pxXmlFirstChildNode));

			//Get the link
      pxXmlNode = ixmlNodeList_item(pxXmlLinkList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy((char8*)xMailList->axInboxEntries[i].ucFromAddress, ixmlNode_getNodeValue(pxXmlFirstChildNode));
    
			//get the desc
      pxXmlNode = ixmlNodeList_item(pxXmlDescList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy((char8*)xMailList->axInboxEntries[i].ucMessage,ixmlNode_getNodeValue(pxXmlFirstChildNode));

		//get the read status
        pxXmlNode = ixmlNodeList_item(pxXmlStatusList, i);
        pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
        xMailList->axInboxEntries[i].bStatus = atoi(ixmlNode_getNodeValue(pxXmlFirstChildNode));
        printf("Read Status : %d\n",xMailList->axInboxEntries[i].bStatus);

	
			//get the date time
    	pxXmlNode = ixmlNodeList_item(pxXmlDateTimeList, i);
      pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
      strcpy(acDateTimeText,ixmlNode_getNodeValue(pxXmlFirstChildNode));
      memset(&dateTimeInfo,0,sizeof(dateTimeInfo));
      dateTokenizer(acDateTimeText);
          IFX_DECT_GetBCD((uchar8)dateTimeInfo[0]-100,&xMailList->axInboxEntries[i].xTimeDate.ucYear);
          IFX_DECT_GetBCD((uchar8)dateTimeInfo[1],&xMailList->axInboxEntries[i].xTimeDate.ucMonth);
          IFX_DECT_GetBCD((uchar8)dateTimeInfo[2],&xMailList->axInboxEntries[i].xTimeDate.ucDay);
          IFX_DECT_GetBCD((uchar8)dateTimeInfo[3],&xMailList->axInboxEntries[i].xTimeDate.ucHour);
          IFX_DECT_GetBCD((uchar8)dateTimeInfo[4],&xMailList->axInboxEntries[i].xTimeDate.ucMinutes);
          IFX_DECT_GetBCD((uchar8)dateTimeInfo[5],&xMailList->axInboxEntries[i].xTimeDate.ucSeconds);
 
 }
ixmlNodeList_free(pxXmlTitleList);
ixmlNodeList_free(pxXmlLinkList);
ixmlNodeList_free(pxXmlDescList);
ixmlNodeList_free(pxXmlDateTimeList);
ixmlDocument_free(pxXmlDoc);
}

/**
  Test Function : IFX_DECTAPP_Get_SubList_UnReadCount
  Purpose : to Get Total Number of UnRead messages from SubList
*/
void IFX_DECTAPP_Set_SubList_ReadStatus(IN uchar8 pucListId, IN uchar8 pucSubListId,IN uchar8 pucEntryId,uchar8 pucReadStaus ){
int i=0;
FILE *fp;
char cFileName[20]="";
char cTagName[50]="";
char pcMsgBody[10000]={'\0'};
DOMString myval;
char cValue[10];
IXML_Document *pxXmlDoc = NULL;
IXML_NodeList *pxXmlTitleList = NULL;
IXML_Node *pxXmlNode = NULL, *pxXmlFirstChildNode = NULL/*,*pxXmlGrandChildNode = NULL*/;
int c;


switch(pucListId){

  case IFX_DT_LAU_RSS_CHANNEL_LIST:
  sprintf(cFileName,"/flash/chanel%d.txt",pucSubListId);
  //strcpy(cTagName,"title");
  strcpy(cTagName,"readstatus");
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  sprintf(cFileName,"/flash/email%d.txt",pucSubListId);
  //strcpy(cTagName,"subject");
  strcpy(cTagName,"readstatus");
  break;

  default:
  strcpy(cFileName,"DummyFile\0");
  break;

}
 fp = fopen(cFileName,"r");
if(fp == NULL){
printf("Feed File %s Doesn't exist \n",cFileName);
return;
}
  while ((c = fgetc(fp)) != EOF) {
    pcMsgBody[i]=c;
    i++;
  }
  fclose(fp);
  if((i = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != 0){
  printf("Error parsing the XML Contents of File %s \n",cFileName);
  return ;
  }
  pxXmlTitleList = ixmlDocument_getElementsByTagName(pxXmlDoc,cTagName);
        pxXmlNode = ixmlNodeList_item(pxXmlTitleList,pucEntryId );
        pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
				sprintf(cValue,"%d",pucReadStaus);
        ixmlNode_setNodeValue(pxXmlFirstChildNode,cValue);
				//Parser_LoadDocument(&pxXmlDoc,cFileName,1);
				myval=ixmlPrintDocument(pxXmlDoc);
fp = fopen(cFileName,"w");
if(fp == NULL){
printf("Feed File %s Doesn't exist \n",cFileName);
return;
}
fprintf(fp,"%s",myval);
fclose(fp);
ixmlFreeDOMString(myval);
ixmlNodeList_free(pxXmlTitleList);
ixmlDocument_free(pxXmlDoc);

}


/**
	Test Function : IFX_DECTAPP_Get_SubList_UnReadCount
	Purpose : to Get Total Number of UnRead messages from SubList
*/
void IFX_DECTAPP_Get_SubList_UnReadCount(IN uchar8 pucListId, IN uchar8 pucSubListId,uchar8 *pucNoOfListEntries ){
int i=0;
FILE *fp;
char cFileName[20]="";
char cTagName[50]="";
char pcMsgBody[10000]={'\0'};
IXML_Document *pxXmlDoc = NULL;
IXML_NodeList *pxXmlTitleList = NULL;
IXML_Node *pxXmlNode = NULL, *pxXmlFirstChildNode = NULL/*,*pxXmlGrandChildNode = NULL*/;
int c;


switch(pucListId){

  case IFX_DT_LAU_RSS_CHANNEL_LIST:
	sprintf(cFileName,"/flash/chanel%d.txt",pucSubListId);
	//strcpy(cTagName,"title");
	strcpy(cTagName,"readstatus");
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
	sprintf(cFileName,"/flash/email%d.txt",pucSubListId);
	//strcpy(cTagName,"subject");
	strcpy(cTagName,"readstatus");
	break;
	
	default:
	strcpy(cFileName,"DummyFile\0");
	break;

}
 fp = fopen(cFileName,"r");
if(fp == NULL){
printf("Feed File %s Doesn't exist \n",cFileName);
*pucNoOfListEntries=0;
return;
}
  while ((c = fgetc(fp)) != EOF) {
    pcMsgBody[i]=c;
    i++;
  }
  fclose(fp);
  if((i = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != 0){
  printf("Error parsing the XML Contents of File %s \n",cFileName);
  return ;
  }
  pxXmlTitleList = ixmlDocument_getElementsByTagName(pxXmlDoc,cTagName);
	*pucNoOfListEntries = 0;//ixmlNodeList_length(pxXmlTitleList);
		for(i=0; i < ixmlNodeList_length(pxXmlTitleList); i++){
				pxXmlNode = ixmlNodeList_item(pxXmlTitleList, i);
        pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);	
				if( 0 != atoi(ixmlNode_getNodeValue(pxXmlFirstChildNode)) )
						*pucNoOfListEntries = *pucNoOfListEntries  + 1;
		}
	if(*pucNoOfListEntries > IFX_MAX_NUM_OF_SUB_ENTRIES )
		*pucNoOfListEntries = IFX_MAX_NUM_OF_SUB_ENTRIES;

ixmlNodeList_free(pxXmlTitleList);
ixmlDocument_free(pxXmlDoc);

}



// Function Initializes the proprietary list inputs from configuration files....!!!

e_IFX_Return  IFX_DECTAPP_InitProprietaryTreeList(IN OUT x_IFX_DECT_ListInfo *pxListInfo){
int i=0;
switch(pxListInfo -> ucListId){

  case IFX_DT_LAU_RSS_CHANNEL_LIST:
	{
		x_IFX_RSS_FEEDS pxRssFeed;
    memset(&pxRssFeed,0,sizeof(pxRssFeed));
    IFX_Get_RssTreeList(&pxRssFeed);
		//Initialize the un-Read Message Count of Each channel....
    for(i =0 ;i < pxRssFeed.ucNumOfChannels;i++){
				IFX_DECTAPP_Get_SubList_UnReadCount(IFX_DT_LAU_RSS_CHANNEL_LIST, i+1, &pxRssFeed.axChannelList[i].ucUnreadMsgCount);
			  pxRssFeed.axChannelList[i].ucTotalMsgCount = pxRssFeed.axChannelList[i].ucUnreadMsgCount;
		}
		pxListInfo->pxSortedList = (x_IFX_RSS_FEEDS *) calloc (1, sizeof(x_IFX_RSS_FEEDS));
    memcpy(pxListInfo->pxSortedList,&pxRssFeed,sizeof(pxRssFeed));
    
     pxListInfo->ucNoOfListEntries = pxRssFeed.ucNumOfChannels;
	}
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
	{
    x_IFX_EMAIL pxEmail;
		memset(&pxEmail,0,sizeof(pxEmail));
		IFX_Get_EmailTreeList(&pxEmail);

    for(i =0 ;i < pxEmail.ucNumOfAccounts; i++){
				IFX_DECTAPP_Get_SubList_UnReadCount(IFX_DT_LAU_EMAIL_ACCOUNT_LIST, i+1, &pxEmail.axMailAccounts[i].ucUnreadMsgs);
				pxEmail.axMailAccounts[i].ucTotalMsgs	= pxEmail.axMailAccounts[i].ucUnreadMsgs;
		}
		pxListInfo->pxSortedList = ( x_IFX_EMAIL *) calloc (1, sizeof( x_IFX_EMAIL ));
    memcpy(pxListInfo->pxSortedList,&pxEmail,sizeof( x_IFX_EMAIL ));
    pxListInfo->ucNoOfListEntries = pxEmail.ucNumOfAccounts;
	}
  break;

  case IFX_DT_LAU_NET_PHONE_BOOK:
	{
    x_IFX_NET_PHONE_BOOK xPhoneBook;
		memset(&xPhoneBook,0,sizeof(x_IFX_NET_PHONE_BOOK));
	
			IFX_Get_NetPhoneBook(&xPhoneBook);
		
		pxListInfo->pxSortedList = ( x_IFX_NET_PHONE_BOOK *) calloc (1, sizeof( x_IFX_NET_PHONE_BOOK ));
    memcpy(pxListInfo->pxSortedList,&xPhoneBook,sizeof(  x_IFX_NET_PHONE_BOOK ));
  
		pxListInfo->ucNoOfListEntries = xPhoneBook.unNoOfEntries;
  }
  break;

   default:
       return IFX_FAILURE;

 }
return IFX_SUCCESS;
}

// Function to initialize the propritray sub-List from Configuration files
e_IFX_Return  IFX_DECTAPP_InitProprietarySubList(IN OUT x_IFX_DECT_ListInfo *pxListInfo){
switch(pxListInfo -> ucListId){

  case IFX_DT_LAU_RSS_CHANNEL_LIST:
	{
		x_IFX_RSS_SUBLISTFEEDS axChanel;
  	memset(&axChanel, 0 , sizeof(axChanel));
	  IFX_Get_RSSSubList(&axChanel,pxListInfo->ucSubListId);	
		if(pxListInfo -> pxSortedList != NULL)
			free(pxListInfo -> pxSortedList);
		pxListInfo -> pxSortedList = (x_IFX_RSS_SUBLISTFEEDS *)calloc(1,sizeof(x_IFX_RSS_SUBLISTFEEDS));
		 memcpy(pxListInfo->pxSortedList,&axChanel,sizeof( axChanel ));
	pxListInfo->ucNoOfListEntries = axChanel.ucNumOfEntries; 
	}
	break;

	 case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
		x_IFX_EMAIL_INBOXENTRIES axMailBox;
		memset(&axMailBox, 0 , sizeof(axMailBox));
		IFX_Get_EmailSubList(&axMailBox,pxListInfo->ucSubListId);
		if(pxListInfo -> pxSortedList != NULL)
			free(pxListInfo -> pxSortedList);
		pxListInfo -> pxSortedList = (x_IFX_EMAIL_INBOXENTRIES *)calloc(1,sizeof(x_IFX_EMAIL_INBOXENTRIES));
		 memcpy(pxListInfo->pxSortedList,&axMailBox,sizeof( axMailBox ));
	pxListInfo->ucNoOfListEntries = axMailBox.ucNumOfEntries; 
	}
	break;
  
	default:
       return IFX_FAILURE;

 }
return IFX_SUCCESS;

}


// Function to Initialize SubSubList from Configuration files
e_IFX_Return  IFX_DECTAPP_InitProprietarySubSubList(IN OUT x_IFX_DECT_ListInfo *pxListInfo){
int i=0,iLength;
char pcTextBody[IFX_DT_MAX_TEXT_SEGMENT_LENGTH * IFX_MAX_NUM_OF_SUB_ENTRIES], *cPtr;
double dDouble;
x_IFX_SUB_SUBLIST pxSubSubList;
memset(&pxSubSubList, 0 , sizeof(pxSubSubList));
switch(pxListInfo -> ucListId){

  case IFX_DT_LAU_RSS_CHANNEL_LIST:
  {
		void *axVoidTemp = pxListInfo->pxSortedList;
		x_IFX_RSS_SUBLISTFEEDS *axTemp = (x_IFX_RSS_SUBLISTFEEDS *)axVoidTemp;
		strcpy(pcTextBody,(char8 *) axTemp -> axChannelEntries[ pxListInfo -> ucSubSubListId-1].ucText);
	}
	break;

	 case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
		void *axVoidTemp = pxListInfo->pxSortedList;
		x_IFX_EMAIL_INBOXENTRIES *axTemp = (x_IFX_EMAIL_INBOXENTRIES *) axVoidTemp;
		strcpy(pcTextBody,(char8 *) axTemp -> axInboxEntries[pxListInfo -> ucSubSubListId-1].ucMessage);
	}
	break;

	default:
       return IFX_FAILURE;

}
printf("-------------------------------------------------------------------------------------\n");
printf("Forming the SubSubList Entry to : %s\n",pcTextBody);
      cPtr=pcTextBody;
    dDouble= strlen(pcTextBody) / (double) IFX_DT_TEXT_SEGMENT_LENGTH;
    pxSubSubList.ucNumOfEntries=CEIL(dDouble);
printf("Total Sub-Sub List(s) :  %d\n", pxSubSubList . ucNumOfEntries );

    if(pxSubSubList.ucNumOfEntries > IFX_MAX_NUM_OF_SUB_ENTRIES )
      pxSubSubList.ucNumOfEntries = IFX_MAX_NUM_OF_SUB_ENTRIES ;

    for(i = 0; i < pxSubSubList.ucNumOfEntries ; i++){
      pxSubSubList.axSubTextEntiries[i].nEntryId=i+1;
      strncpy((char*)pxSubSubList.axSubTextEntiries[i].ucText,cPtr,IFX_DT_TEXT_SEGMENT_LENGTH);
			iLength = strlen((char *)pxSubSubList.axSubTextEntiries[i].ucText);
      pxSubSubList.axSubTextEntiries[i].ucText[iLength - 1]='\0';
      cPtr+=IFX_DT_TEXT_SEGMENT_LENGTH - 1;
		printf("Segment : %d : Length : %d \n",i + 1,iLength);
    }
printf("-------------------------------------------------------------------------------------\n");
	if(pxListInfo -> pxSortedList != NULL)
		free(pxListInfo -> pxSortedList);

	// Copy into the session ptr
	pxListInfo -> pxSortedList = ( x_IFX_SUB_SUBLIST* ) calloc(1, sizeof(x_IFX_SUB_SUBLIST));
		memcpy(pxListInfo -> pxSortedList ,&pxSubSubList, sizeof(pxSubSubList)); 

	pxListInfo->ucNoOfListEntries = pxSubSubList.ucNumOfEntries;

return IFX_SUCCESS;
}



/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ReadTreeList
 *  Description     : This internal Api reads the entries stored in FP and sends
 *                    them to be displayed by PP.
 *  Input Values    : ucListId - Parent List Identifier
                      ucSubListId - Sub List Identifier's
 *                    pxSortedList - pointer to Sorted List
 *                    pxReadList - It contains read info such as start index,
 *                    counter,mark entries request required for fetching the
 *                    entries.
 *  Output Values   : pxReadList - NACK reason ,if any, is sent back.
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : In case of Missed call list/All Incoming calls list,
 *                    with non-zero mark entries request and empty subset of field
 *                    identifiers ,only the read status of the read entries is
 *                    changed(set/reset) and no data packet is sent subsequetly.
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_ReadTreeList(IN uchar8 ucListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList){

  void *pvPayload = NULL;
  uchar8 *pucDataPayload = NULL;
  uint16 unPayldSize = 0;
  /*IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_ReadSubList>Entry");*/
  printf("<ReadTreeSubList> Entries of List %d  \n",ucListId);
  if(NULL == pxSortedList && ucListId <=9  ){
    return IFX_SUCCESS;//Ask??
  }
  switch(ucListId){

 case IFX_DT_LAU_RSS_CHANNEL_LIST:
  {
       x_IFX_RSS_FEEDS xRssFeed = { 0 };
			 x_IFX_RSS_FEEDS *pxRssFeed = (x_IFX_RSS_FEEDS * )pxSortedList;

       xRssFeed.ucNumOfChannels = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
       memcpy(&xRssFeed.axChannelList[0],
             &pxRssFeed -> axChannelList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_RSS_CHANNEL)*xRssFeed.ucNumOfChannels);

      pvPayload = (void *)&xRssFeed;
  }
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
    x_IFX_EMAIL xEmail = {0};
		x_IFX_EMAIL *pxEmail = (x_IFX_EMAIL * ) pxSortedList;   
   xEmail.ucNumOfAccounts = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
       memcpy(&xEmail.axMailAccounts[0],
             &pxEmail -> axMailAccounts[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_EMAIL_ACCOUNT)*xEmail.ucNumOfAccounts);
            pvPayload = (void *)&xEmail;
  }
  break;
  case IFX_DT_LAU_NET_PHONE_BOOK:
  {
    x_IFX_NET_PHONE_BOOK pxPhoneBook={0};
		x_IFX_NET_PHONE_BOOK *xPhoneBook = (x_IFX_NET_PHONE_BOOK *) pxSortedList;
      pxPhoneBook.unNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
       memcpy(&pxPhoneBook.axPhoneBookEntries[0],
             &xPhoneBook -> axPhoneBookEntries[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_NET_PHONE_BOOK_ENTRY)*pxPhoneBook.unNoOfEntries);
    pvPayload = (void *)&pxPhoneBook;
   }
  break;
   default:
       pxReadList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
          printf("<IFX_DECTAPP_ReadTreeList>Error! List not supported.");
       return IFX_FAILURE;
  }
 pucDataPayload = (uchar8 *) malloc(2048 * sizeof(uchar8));
      //Encode proprietry List
      IFX_DT_TreeList_DataPktPayloadEncode(pxReadList->nSessionId,
                                    ucListId,
                                    pvPayload,
                                    &unPayldSize,
                                    (char8 *)pucDataPayload);
IFX_DECT_LAU_DataPktSend(pxReadList->nSessionId,
                           unPayldSize,
                           pucDataPayload);

  free(pucDataPayload);
  return IFX_SUCCESS;
}


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ReadSubList
 *  Description     : This internal Api reads the entries stored in FP and sends
 *                    them to be displayed by PP.
 *  Input Values    : ucListId - Parent List Identifier
											ucSubListId - Sub List Identifier's
 *                    pxSortedList - pointer to Sorted List
 *                    pxReadList - It contains read info such as start index,
 *                    counter,mark entries request required for fetching the
 *                    entries.
 *  Output Values   : pxReadList - NACK reason ,if any, is sent back.
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : In case of Missed call list/All Incoming calls list,
 *                    with non-zero mark entries request and empty subset of field
 *                    identifiers ,only the read status of the read entries is
 *                    changed(set/reset) and no data packet is sent subsequetly.
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_ReadSubList(IN uchar8 ucListId,
																		 IN uchar8 ucSubListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList){

  void *pvPayload = NULL;
  uchar8 *pucDataPayload = NULL;
  uint16 unPayldSize = 0;
	uchar8 bReadStatus=0;
  uchar8 i=0 ,j=0;
	/*IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_ReadSubList>Entry");*/
  printf("<ReadSubList> Sub List Entries of List %d  \n",ucListId);
	printf("^^^^^^^^^^^^^^^^^Read Sub List with Mark Entry : %x \n",pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq);
  if(NULL == pxSortedList && ucListId <=9  ){
    return IFX_SUCCESS;//Ask??
  }
  switch(ucListId){
	case IFX_DT_LAU_RSS_CHANNEL_LIST:
  {
			x_IFX_RSS_SUBLISTFEEDS xRssFeeds={0};
			x_IFX_RSS_SUBLISTFEEDS *axChanel =  ( x_IFX_RSS_SUBLISTFEEDS * ) pxSortedList;
			printf("@@@@@@@@@@@@@@@@@@@@@@ RSS- Sublist copying ....!\n");
	    xRssFeeds.ucNumOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
			printf("Start Index : %d & End Index : %d\n",pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1,xRssFeeds.ucNumOfEntries);
					
       memcpy(&xRssFeeds.axChannelEntries[0],
             &axChanel->axChannelEntries[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_RSS_SUBLIST)*xRssFeeds.ucNumOfEntries);
	//	#if 0	
			if(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq !=0 ){
			switch(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq){

          case 0/*Leave Unchanged*/:
              break;

          case 0x7F/*Mark as Read*/:
              bReadStatus = 0;
              break;

          case 0xFF/*Mark as UnRead*/:
              bReadStatus = 1;
              break;

       }
				for(i=0;i< xRssFeeds.ucNumOfEntries ; i++){
						for(j = 0; j < axChanel->ucNumOfEntries ; j++){
							if(axChanel->axChannelEntries[j].nEntryId == xRssFeeds.axChannelEntries[i].nEntryId){
									//axChanel->axChannelEntries[j].bStatus=bReadStatus;	
									IFX_DECTAPP_Set_SubList_ReadStatus(ucListId,ucSubListId,j,bReadStatus );
									xRssFeeds.axChannelEntries[i].bStatus=bReadStatus;
							}
      			}	
				}
      //ifx_Update_UnReadCount(ucListId,ucSubListId);
			}
		//#endif
				pvPayload = (void *)&xRssFeeds;
  }
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
		x_IFX_EMAIL_INBOXENTRIES xEmails={0};    
		x_IFX_EMAIL_INBOXENTRIES *axMailList = (x_IFX_EMAIL_INBOXENTRIES *)pxSortedList;	
		printf("@@@@@@@@@@@@@@@@@@@@@@ Email- Sublist Data Packet....!\n");
       xEmails.ucNumOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
			printf("Start Index : %d & End Index : %d\n",pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1,xEmails.ucNumOfEntries);
       memcpy(&xEmails.axInboxEntries[0],
             &axMailList -> axInboxEntries[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_EMAIL_INBOX_ENTRY)*xEmails.ucNumOfEntries);
	//#if 0
    	 if(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq !=0 ){
				switch(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq){

          case 0/*Leave Unchanged*/:
              break;

          case 0x7F/*Mark as Read*/:
              bReadStatus = 0;
              break;

          case 0xFF/*Mark as UnRead*/:
              bReadStatus = 1;
              break;

       }

        for(i=0;i< xEmails.ucNumOfEntries ; i++){
            for(j = 0; j < axMailList->ucNumOfEntries ; j++){
              if(axMailList->axInboxEntries[j].nEntryId == xEmails.axInboxEntries[i].nEntryId){
                  //axMailList->axInboxEntries[j].bStatus=bReadStatus; 
									IFX_DECTAPP_Set_SubList_ReadStatus(ucListId,ucSubListId,j,bReadStatus );
                  xEmails.axInboxEntries[i].bStatus=bReadStatus; 
              }
            }
        }
      //ifx_Update_UnReadCount(ucListId,ucSubListId);
			} 
	//#endif
		      pvPayload = (void *)&xEmails;
  }
  break;
	default:
       pxReadList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       /*IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Error! List not supported.");*/
       return IFX_FAILURE;
  }
  pucDataPayload = (uchar8 *) malloc(2500 * sizeof(uchar8));
  IFX_DT_SubList_DataPktPayloadEncode(pxReadList->nSessionId,
                                    ucListId,
                                    pvPayload,
                                    &unPayldSize,
                                    (char8 *)pucDataPayload);

  IFX_DECT_LAU_DataPktSend(pxReadList->nSessionId,
                           unPayldSize,
                           pucDataPayload);

  free(pucDataPayload);
  return IFX_SUCCESS;
}
#if 0
/******************************************************************************
 *  Function Name   : IFX_Update_UnReadCount
 *  Description     : This internal Api reads sub list entries
											and update the unread count.
 *  Input Values    : ucListId - Parent List Identifier
                      ucSubListId - Sub List Identifier's
 *  Output Values   : 
 *  Return Value    : 
 *  Notes           : 
 ****************************************************************************/

void ifx_Update_UnReadCount(uchar8 pucListId,uchar8 pucSubListId){
uchar8 j=0;
switch(pucListId){
    case IFX_DT_LAU_RSS_CHANNEL_LIST:
		pxRssFeed.axChannelList[pucSubListId-1].ucUnreadMsgCount=0;
		for(j = 0; j < axChanel[pucSubListId-1].ucNumOfEntries ; j++){
              if(axChanel[pucSubListId-1].axChannelEntries[j].bStatus == 1)
								pxRssFeed.axChannelList[pucSubListId-1].ucUnreadMsgCount++;		
		}
		break;

    case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
		pxEmail.axMailAccounts[pucSubListId-1].ucUnreadMsgs=0;
		for(j = 0; j < axMailList[pucSubListId-1].ucNumOfEntries ; j++){
              if(axMailList[pucSubListId-1].axInboxEntries[j].bStatus == 1)
								pxEmail.axMailAccounts[pucSubListId-1].ucUnreadMsgs++;
		}
		break;

}

}
#endif

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ReadSubSubList
 *  Description     : This internal Api reads the entries stored in FP and sends
 *                    them to be displayed by PP.
 *  Input Values    : ucListId - Parent List Identifier
                      ucSubListId - Sub List Identifier's
 *                    pxSortedList - pointer to Sorted List
 *                    pxReadList - It contains read info such as start index,
 *                    counter,mark entries request required for fetching the
 *                    entries.
 *  Output Values   : pxReadList - NACK reason ,if any, is sent back.
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : In case of Missed call list/All Incoming calls list,
 *                    with non-zero mark entries request and empty subset of field
 *                    identifiers ,only the read status of the read entries is
 *                    changed(set/reset) and no data packet is sent subsequetly.
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_ReadSubSubList(IN uchar8 ucListId,
                                     IN uchar8 ucSubListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList){

  void *pvPayload = NULL;
  uchar8 *pucDataPayload = NULL;
  uint16 unPayldSize = 0;
  /*IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_ReadSubList>Entry");*/
  printf("<ReadSubSubList> Sub-SubList Entries of List %d  \n",ucListId);
  if(NULL == pxSortedList && ucListId <=9  ){
    return IFX_SUCCESS;//Ask??
  }

	printf("^^^^^^^^^^^^^^^^^Read SubSub List with Mark Entry : %x \n",pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq);

  switch(ucListId){
  case IFX_DT_LAU_RSS_CHANNEL_LIST:
  {
      x_IFX_SUB_SUBLIST xRssSubFeeds={0};
			x_IFX_SUB_SUBLIST *axRSSSub_Sublist = (x_IFX_SUB_SUBLIST *)pxSortedList;
      printf("@@@@@@@@@@@@@@@@@@@@@@ RSS- Sub Sublist Data Packet....!\n");
      xRssSubFeeds.ucNumOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
      printf("Start Index : %d & End Index : %d\n",pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1,xRssSubFeeds.ucNumOfEntries);
      memcpy(&xRssSubFeeds.axSubTextEntiries[0],
             &axRSSSub_Sublist -> axSubTextEntiries[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_TEXT_SUB_ENTRY)*xRssSubFeeds.ucNumOfEntries);
			pvPayload = (void *)&xRssSubFeeds;
  }
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
    x_IFX_SUB_SUBLIST xEmails={0};
		 x_IFX_SUB_SUBLIST *axMailSub_Sublist = (x_IFX_SUB_SUBLIST *)pxSortedList;
      printf("@@@@@@@@@@@@@@@@@@@@@@ Email- Sub - Sublist Data Packet....!\n");
       xEmails.ucNumOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
      printf("Start Index : %d & End Index : %d\n",pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1,xEmails.ucNumOfEntries);
       memcpy(&xEmails.axSubTextEntiries[0],
             &axMailSub_Sublist -> axSubTextEntiries[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_TEXT_SUB_ENTRY)*xEmails.ucNumOfEntries);
				pvPayload = (void *)&xEmails;
  }
  break;
  default:
       pxReadList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       return IFX_FAILURE;
  }
  pucDataPayload = (uchar8 *) malloc(2600 * sizeof(uchar8));
  IFX_DT_SubSubList_DataPktPayloadEncode(pxReadList->nSessionId,
                                    ucListId,
                                    pvPayload,
                                    &unPayldSize,
                                    (char8 *)pucDataPayload);

  IFX_DECT_LAU_DataPktSend(pxReadList->nSessionId,
                           unPayldSize,
                           pucDataPayload);

  free(pucDataPayload);
  return IFX_SUCCESS;
}
#endif
