/**************************************************************************
 **   SRC_FILE          : IFX_DECT_COMMIF.h
 **   PROJECT           : DECT-OSGI IWU
 **   MODULES           : DECT DATA IWU
 **   SRC VERSION       : v1.0
 **   DATE              : 15th Dec 2010
 **   AUTHOR            : Sandor Plosz
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#ifdef LTQ_OSGI_POWER_OUTLET
/*! \file IFX_DECT_COMMIF.h
    \brief FT Application
*/

#ifndef __IFX_DECT_COMMIF_H__
#define __IFX_DECT_COMMIF_H__

#include <netinet/in.h>
/** \ingroup DECT_SS_1_1
    \defgroup FT Application acts as an interface between the DECT Toolkit and the Data App.
    \brief This file stores structures,macros,enumerations and API prototypes 
	   and callback function definitions useful for FT Application to meet requirements.
*/
/*@{*/

/*! \brief IFX_DECTAPP_COMMIF_MAX_CONN Maximum number of connections available.
           Equal to maximum number of handsets.
*/

#define IFX_DECTAPP_COMMIF_MAX_CONN 6

#define IFX_DECTAPP_COMMIF_SOCKET_LISTEN_PORT "12345"

#define IFX_DECTAPP_COMMIF_MAGIC 	0xCD

typedef enum {
	IFX_DECTAPP_COMMIF_MODULE_MAIN = 0xB0,
	IFX_DECTAPP_COMMIF_MODULE_DPSU
} IFX_DECTAPP_COMMIF_MODULES;


typedef enum {
	IFX_DECTAPP_COMMIF_DPSU_CallInitiate_IND = 0xA0,
	IFX_DECTAPP_COMMIF_DPSU_CallInitiate_REQ,
	IFX_DECTAPP_COMMIF_DPSU_CallRelease_IND,
	IFX_DECTAPP_COMMIF_DPSU_CallRelease_REQ,
	IFX_DECTAPP_COMMIF_DPSU_CallAccept_REQ,
	IFX_DECTAPP_COMMIF_DPSU_DataSending,
	
	IFX_DECT_COMMIF_Return = 0x77,
	IFX_DECT_COMMIF_ERROR = 0x88
} IFX_DECTAPP_COMMIF_DPSU_Commands;

typedef enum {
	IFX_DECTAPP_COMMIF_ERROR_INVALID_MAGIC = 0xE0,
	IFX_DECTAPP_COMMIF_ERROR_INVALID_MODULEID,
	IFX_DECTAPP_COMMIF_ERROR_INVALID_COMMAND,
} IFX_DECTAPP_COMMIF_ErrorType;

typedef enum {
	IFX_DECTAPP_RETURN_SUCCESS = 0xAA,
	IFX_DECTAPP_RETURN_FAILURE = 0xBB
} IFX_DECTAPP_ReturnType;

/** x_IFX_DECTAPP_COMMIF_Message structure encapsulates the message format in the communication interface*/
typedef struct  {
	uchar8	magic;
	uchar8	moduleID;
	uchar8	cmdType;
	uint32	callHdl;
	uint8	dataLength;
	uchar8	data[20];
} __attribute__((packed)) x_IFX_DECTAPP_COMMIF_Message;

/*! \brief typedef for thread function.*/
typedef void *(*THREAD_RTN_PTR)(void*);


/** x_IFX_DECT_ConnectionStruct structure stores the information pertaining to 
    a connection.
*/
typedef struct
{
 int32 iSessionId;                 /*!< Call Handle*/ 
 uchar8 conState;                  /*!< Indicates in which state this connection is*/ 
}x_IFX_DECTAPP_COMMIF_ConnectionStruct;

typedef enum {
	IFX_DECTAPP_CONN_STATE_UNUSED = 0,
	IFX_DECTAPP_CONN_STATE_PENDING,
	IFX_DECTAPP_CONN_STATE_ACCEPTED
} IFX_DECTAPP_CONN_STATES;


/*! \brief IFX_DECT_DPSU_CallInitiate,this callback function is issued when the PT
           initiates a Data Call to communicate with the Download Server.
    \param[in] uiCallHdl unique Connection handle.
    \param[in] ucHandsetId Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[out] pucRejectReason Reason for Call reject.
    \param[out] puiPrivateData data specific to app used to uniquely identify 
                a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallInitiate (IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,
                                         IN uint32 uiIEHdl,
                                         OUT uchar8 *pucRejectReason,
                                         OUT uint32 *puiPrivateData);
    

/*! \brief IFX_DECT_DPSU_CallRelease callback function is called once the DECT 
           stack closes the connection.
    \param[in] uiCallHdl unique Connection Handle.
    \param[in] uiIEHdl Information Element Handle.
    \param[in] eReason Reason for Release.
    \param[in] uiPrivateData data specific to app used to uniquely identify
               a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseCall( IN uint32 uiCallHdl,
                                        IN uint32 uiIEHdl,
                                        IN e_IFX_DECT_RelType eReason,
                                        IN uint32 uiPrivateData);
										
										
e_IFX_Return IFX_DECT_DPSU_HandleIncommingData (IN uint32 uiCallHdl, 
										IN char8 *pcBuff, 
										IN int32 iLen, 
										IN uint32 uiPrivateData);										
										


/*! \brief API IFX_DECTAPP_COMMIF_IF_Init is used to initialize the comminucation interface application 
			and create placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;      
*/

e_IFX_Return IFX_DECTAPP_COMMIF_Init();							  

e_IFX_Return IFX_DECTAPP_COMMIF_Loop_Thread();

e_IFX_Return IFX_DECTAPP_COMMIF_HandleIncomingData(uchar8* data, uint32 length);

e_IFX_Return IFX_DECTAPP_COMMIF_Write_Data(uchar8* data, uint32 length);

e_IFX_Return IFX_DECTAPP_COMMIF_Send_Return(x_IFX_DECTAPP_COMMIF_Message* origMsg, 
											IFX_DECTAPP_COMMIF_MODULES moduleID, 
											IFX_DECTAPP_ReturnType returnType);

e_IFX_Return IFX_DECTAPP_COMMIF_Send_Error(x_IFX_DECTAPP_COMMIF_Message* origMsg, 
										   IFX_DECTAPP_COMMIF_MODULES moduleID, 
										   IFX_DECTAPP_COMMIF_ErrorType errorType);

e_IFX_Return IFX_DECTAPP_COMMIF_Fill_Message(x_IFX_DECTAPP_COMMIF_Message* msg, 
											 IFX_DECTAPP_COMMIF_MODULES moduleID, 
											 IFX_DECTAPP_COMMIF_DPSU_Commands cmdType, 
											 uint32 callHdl);

e_IFX_Return IFX_DECTAPP_FIND_CALLID(uint32* callHdl, x_IFX_DECTAPP_COMMIF_ConnectionStruct* connStruct);

e_IFX_Return IFX_DECTAPP_PrintConnInfo();

#endif /*IFX_DECT_COMMIF_H_*/ 
#endif /*LTQ_OSGI_POWER_OUTLET*/ 
