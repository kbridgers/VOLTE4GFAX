#ifndef __IFX_DECT_APP_H__
#define __IFX_DECT_APP_H__



/*---------------------- define ESCAPE-TO-PROPRIETARY ---------------------------*/

                                       /* For PRODECT V2.0 !               */
                                       /* -------------------------------- */
#define MODEL_ID_PRODECT_V20	0x20
// Sub-Model Identifier for Loewe Telecom DECT Telephone Series
#define IFX_DECT_MODEL_ID		0x40



                                       /* reserved 0x01                       */
                                       /* -------------------------------- */
                                       /* reserved 0x02                       */
                                       /* -------------------------------- */
                                       /* CALL TYPE                        */
                                       /* -------------------------------- */
#define CALL_TYPE				0x03
                                       /* Call type coding according to    */
                                       /* << BASIC SERVICE >> IE !         */
                                       /* see 'CC_LIB.H'                   */
/*
#define EXTERNAL_CALL			0x80
#define INTERNAL_CALL			0x90
#define EMERGENCY_CALL			0xA0
#define SERVICE_CALL				0xB0
*/
                                       /* USER ACTION                      */
                                       /* -------------------------------- */
#define USER_ACTION				0x04
#define AUTO_ACCEPT			0
#define AUTO_RELEASE			1

                                       /* reserved 0x05                    */
                                       /* -------------------------------- */
                                       /* RR Number         */
                                       /* -------------------------------- */
#define RR_NUMBER		               0x06
                                       /* The internal portable number is  */
                                       /* appended !      */           

                                       /* reserved 0x07 ~ 0x0f             */
                                       /* -------------------------------- */

// New Escape-to-Proprietary Code for Memory Process accessing
/* Memory process action */
#define MEM_ACTION					0x10
//Handset --> Base
#define DATE_TIME_STATE			0
#define DEREGISTER_STATE			1
#define MASTER_PIN_STATE			2

// Base --> Handset


                                       /* CID ACTION                           */
                                       /* -------------------------------- */
/* Memory process action */
#define CID_ACTION					0x11
#define CID_RECEPTION_OK			0
#define CID_RECEPTION_ERROR		1


#define DATE_TIME					0x12
#define MODEL_NAME					0x13

                                       /* RECEIVED_CLIP                       */
                                       /* -------------------------------- */
/* CID Number and CID name */
#define CID_CLIP						0x14

                                       /* CALL MANAGE ACTION                           */
                                       /* -------------------------------- */
/* Memory process action */
#define CALL_MANAGE_ACTION		0x15
#define MAKE_CONF					0 // make conference [handset->Base]
#define MAKE_CONF_OK				1 // make conference ok [Base->handset]
#define MAKE_CONF_ERROR			2 // make conference error [Base->handset]
#define CALL_HOLD					3 // make call hold [handset->Base]
#define CALL_HOLD_OK				4 // make call hold ok [Base->handset]
#define CALL_HOLD_ERROR			5 // make call hold error [Base->handset]
#define CALL_RESUME					6 // make call resume [handset->Base]
#define CALL_RESUME_OK				7 // make resume ok  [Base->handset]
#define CALL_RESUME_ERROR			8 // make resume error  [Base->handset]
#define CALL_FOWARD				9 // make call forward [handset->Base]
#define CALL_FOWARD_OK				10 // make forward ok  [Base->handset]
#define CALL_FOWARD_ERROR			11 // make forward error  [Base->handset]
#define CALL_TRANSFER				12 // make call transfer [handset->Base]
#define CALL_TRANSFER_OK			13 // make transfer ok  [Base->handset]
#define CALL_TRANSFER_ERROR		14 // make transfer error  [Base->handset]
#define ACTIVE_CCBS					15 // make activate CCBS [handset->Base]
#define ACTIVE_CCBS_OK				16 // make call activate CCBS ok  [Base->handset]
#define ACTIVE_CCBS_ERROR			17 // make call activate CCBS error  [Base->handset]
#define DEACTIVE_CCBS				18 // make call deactivate CCBS [handset->Base]
#define DEACTIVE_CCBS_OK			19 // make call deactivate CCBS ok  [Base->handset]
#define DEACTIVE_CCBS_ERROR		20 // make call deactivate CCBS error  [Base->handset]
#define CALL_WAIT					21 // call wait status  [Base->handset]


                                       /* 3byte : EMC type + EMC Code      */
                                       /* Every proprietary code consists  */
                                       /* of 2 bytes !                     */
                                       /* added EP_KEY_ICON                */
#define MAX_PROPRIETARY_CODE_LENGTH    (3 + 57) 

#define MAX_IWU_PROPRIETARY_CODE_LENGTH      210

/*---------------------- End : define ESCAPE-TO-PROPRIETARY -----------------------*/




FPTR Construct_Proprietary( void );
FPTR Construct_IWU_Proprietary( void );
void Add_Prop_IE_2( FPTR frame_ptr, BYTE ie_identifier, BYTE ie_byte_1 );
void Add_Prop_IE_3( FPTR frame_ptr, BYTE ie_identifier, BYTE ie_byte_1, BYTE ie_byte_2 );
void Add_Prop_IE_4( FPTR frame_ptr, BYTE ie_identifier, BYTE ie_byte_1, BYTE ie_byte_2, BYTE ie_byte_3 );
void Append_Prop_IE( FPTR frame_ptr, BYTE ie_identifier, FPTR source_ptr );
void Append_IWU_IE( FPTR frame_ptr, BYTE ie_identifier, FPTR source_ptr );
void Add_Prop_Date( FPTR frame_ptr );
void Add_Prop_CLIP( FPTR frame_ptr, FPTR num_ptr,  FPTR name_ptr);
BIT evaluate_PROPRIETARY_IE( FPTR ptr );
BYTE scan_ETP_IE( FPTR ptr, BYTE etp_ie);

#endif /*__IFX_DECT_APP_H__ */

