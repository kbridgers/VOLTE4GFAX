#ifndef __IFX_DT_Data_H__
#define __IFX_DT_Data_H__
void IFX_Get_RssTreeList(x_IFX_RSS_FEEDS *xRssFeed);

void IFX_Get_RSSSubList(x_IFX_RSS_SUBLISTFEEDS *xChanel,uchar8 pIn);

void IFX_Get_EmailSubList(x_IFX_EMAIL_INBOXENTRIES *xMailList,uchar8 pIn);

void IFX_Get_EmailTreeList(x_IFX_EMAIL *axEmail);

void IFX_Get_NetPhoneBook(x_IFX_NET_PHONE_BOOK *xPhoneBook);

void ifx_Update_UnReadCount(uchar8 pucListId,uchar8 pucSubListId);


e_IFX_Return IFX_Get_SubListInfo(IN uchar8 pucListId,IN uchar8 pucSubListId,IN int16 piLevel, OUT uchar8 *pucAvailEntries);

e_IFX_Return IFX_DECTAPP_ReadTreeList(IN uchar8 ucListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList);

e_IFX_Return IFX_DECTAPP_ReadSubList(IN uchar8 ucListId,
                                     IN uchar8 ucSubListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList);

e_IFX_Return IFX_Get_SubSubListInfo(IN uchar8 pucListId,IN uchar8 pucSubListId,
                                    IN uchar8 pucSubSubListId,IN int16 piLevel,
                                    OUT uchar8 *pucAvailEntries);

void IFX_Get_SubSubList(IN uchar8 pucListId,IN uchar8 pucSubListId,
                                    IN uchar8 pucSubSubListId,x_IFX_SUB_SUBLIST *pxSubSubList);

e_IFX_Return IFX_DECTAPP_ReadSubSubList(IN uchar8 ucListId,
                                     IN uchar8 ucSubListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList);

e_IFX_Return IFX_DECTAPP_GetProprietaryListInfo(IN uchar8 pucListId, OUT uchar8 *pucNoOfListEntries);
void IFX_DECTAPP_Get_SubList_UnReadCount(IN uchar8 pucListId, IN uchar8 pucSubListId,uchar8 *pucNoOfListEntries );
e_IFX_Return IFX_DECTAPP_InitProprietaryTreeList(/*IN uchar8 pucListId, uchar8 *pucNoOfListEntries*/ IN OUT x_IFX_DECT_ListInfo *pxListInfo);
e_IFX_Return IFX_DECTAPP_InitProprietarySubList(/*IN uchar8 pucListId, uchar8 *pucNoOfListEntries*/ IN OUT x_IFX_DECT_ListInfo *pxListInfo);
e_IFX_Return IFX_DECTAPP_InitProprietarySubSubList(/*IN uchar8 pucListId, uchar8 *pucNoOfListEntries*/ IN OUT x_IFX_DECT_ListInfo *pxListInfo);
/*x_IFX_RSS_FEEDS pxRssFeed;
x_IFX_EMAIL pxEmail;
x_IFX_NET_PHONE_BOOK xPhoneBook;
x_IFX_EMAIL_INBOXENTRIES *axMailList;
x_IFX_RSS_SUBLISTFEEDS *axChanel;
x_IFX_SUB_SUBLIST axRSSSub_Sublist, axMailSub_Sublist;*/
#endif
