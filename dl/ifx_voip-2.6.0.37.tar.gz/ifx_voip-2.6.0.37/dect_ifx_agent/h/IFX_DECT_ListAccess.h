/**************************************************************************
 **   SRC_FILE          : IFX_DECT_Agent.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#ifndef __IFX_DECT_LISTACCESS_H__
#define __IFX_DECT_LISTACCESS_H__
#include "IFX_DECT_LAU.h"

extern uchar8 vucDectAgnetModId; 

/*! \def IFX_DECTAPP_MAX_EDITABLE
	  \brief Macro that defines the maximum number of Editable Fields in any List.
*/
#define IFX_DECTAPP_MAX_EDITABLE 9         /*!< Maximum number of Editable Fields */

/*! \def IFX_DECTAPP_MAX_UNEDITABLE
	  \brief Macro that defines the maximum number of Editable Fields in any List.
*/
#define IFX_DECTAPP_MAX_UNEDITABLE 9         /*!< Maximum number of UnEditable Fields */

/*! \def  IFX_DECTAPP_MAX_DECT_ENDPTS
	  \brief Macro that defines the maximum number of DECT Endpts.
*/
#define IFX_DECTAPP_MAX_DECT_ENDPTS 6       /*!< Maximum number of DECT Endpoints */   

/*! \def  IFX_DECTAPP_MAX_DECT_LINES
	  \brief Macro that defines the maximum supported lines.
*/
#define IFX_DECTAPP_MAX_LINES 4         /*!< Maximum Lines Supported */

/*! \def  IFX_DECTAPP_MAX_CONTACT_ENTRIES
	  \brief Macro that defines the maximum number of entries allowed in Contact list.
*/
#define IFX_DECTAPP_MAX_CONTACT_ENTRIES 15   /*!< Maximum possible entries in Contact List */

/*! \def  IFX_MAX_CONTACTS_PER_LINE
	  \brief Macro that defines the maximum number of entries allowed in Contact list.
*/
#define IFX_MAX_CONTACTS_PER_LINE 10   /*!< Maximum possible entries in Contact List */


/*! \def  IFX_DECTAPP_LASTENTRY
	  \brief Macro that defines the start index indicates the last entry in a list.
*/
#define IFX_DECTAPP_LASTENTRY 0              /*!< To indicate last entry in the list */

/*! \def  IFX_DECT_LINE_SUBTYPE_RELATING_TO
	  \brief Macro that defines the Line Subtype as All Lines.
*/
#define IFX_DECT_LINE_SUBTYPE_RELATING_TO 3         /*!< Indicates Line subtype as relating-to */


/*! \def  IFX_DECT_LINE_SUBTYPE_ALL
	  \brief Macro that defines the Line Subtype as All Lines.
*/
#define IFX_DECT_LINE_SUBTYPE_ALL 4         /*!< Indicates Line subtype as All Lines*/

/*! \brief Structure describing the List Information per Handset per Session.
*/
typedef struct
{
  int16 nSessId;                                               /*!< Session Identifier */
  uchar8 ucListId;                                             /*!< List Identifier */  
  uchar8 ucNoOfListEntries;                                    /*!< Total entries in a list */  
  int16 nEntryId;                                              /*!< Entry Identifier */
  int16 nPositionId;                                           /*!< Position Identifier */ 
  uint16 unFieldIds;                                           /*!< Field Identifier Map */
  void *pxSortedList;                                         /*!< Pointer to Sorted List*/
  uint32 uiFlags; /*!< Flags */
#ifdef LTQ_DT_SUPPORT
	uchar8 ucSubListId;    /* !< Sublist List Identifier */
	uchar8 ucSubSubListId; /* !<Sub- SubList Identifier */
	int16 nLevel; /* !< Tree List level */
#endif
}x_IFX_DECT_ListInfo;

/*! \brief Structure describing the Pin Verification for the Handset session.
*/
typedef struct 
{
	uchar8 aucPinEval[IFX_DECT_LAU_MAX_HS];                      /* If Pin verified,the octet for the HS is set. */
}x_IFX_DECT_PinEvalInfo; 

/*! \enum e_IFX_DECTAPP_ListNotify
	  \brief Enum containing the List Identifiers for Notification.
*/
#if 0
typedef enum{

  IFX_DECTAPP_MISSCALL = 1,                                    /*!< Missed Call List */
  IFX_DECTAPP_DIALCALL,                                        /*!< Outgoing Call List */
  IFX_DECTAPP_RECVCALL,                                        /*!< Incoming Call List */    
  IFX_DECTAPP_CONTACTS = 5,                                    /*!< Contact List */
  IFX_DECTAPP_INTERNAL_NAMES,                                  /*!< Internal Names List */
  IFX_DECTAPP_LINE = 8,                                        /*!< Line Settings List -Line/Attachment */ //TODO:Can Merge Below two??
	IFX_DECTAPP_CF = 9,                                          /*!< Line Settings List -Calling Featues*/
}e_IFX_DECTAPP_ListNotify;
#endif
/*! \enum e_IFX_DECTAPP_MissSubType
	  \brief Enum containing the Missed Call Subtype.New Entry -1,Read Status Changed -2
*/
typedef enum{

  IFX_DECTAPP_MISS_SUBTYPE_NEW = 1,                            /*!< New Entry Added */
  IFX_DECTAPP_MISS_SUBTYPE_READ = 2,                           /*!< Read Status Changed */

}e_IFX_DECTAPP_MissSubType;


/*! \enum e_IFX_DECTAPP_LineObjType
	  \brief Enum containing the Line Object Type.
*/
typedef enum{

  IFX_DECTAPP_LINEOBJ_LINEASSOC = 0,                            /*!< New LineAdded/Assoc HS List Changed */
  IFX_DECTAPP_LINEOBJ_CALLFEAT = 1,                           /*!< Calling Features Changed */
  IFX_DECTAPP_LINEOBJ_PSTN = 2,                           /*!< PSTN Line HS Assoc Changed */

}e_IFX_DECTAPP_LineObjType;

/*! \enum e_IFX_DECTAPP_ReadOrder
	  \brief Enum containing the direction of Read.
*/
typedef enum{

 IFX_DECTAPP_DIR_FWD = 0,                                       /*!< Read in Forward Direction */
 IFX_DECTAPP_DIR_BACKWD = 1,                                    /*!< Read in Backward Direction */
 
}e_IFX_DECTAPP_ReadOrder;

/*! \enum e_IFX_DECTAPP_ListOp
	  \brief Enum containing the List operation
*/
typedef enum{

  IFX_DECTAPP_DEL = 1,                                         /*!< Delete Operation */
  IFX_DECTAPP_MODIFY,                                          /*!< Modify Operation */
  IFX_DECTAPP_ADD,                                             /*!< Add Operation */  
  IFX_DECTAPP_DEL_ALL,                                         /*!< Delete Entire list*/  
}e_IFX_DECTAPP_ListOp;

/*! \brief  This Api is used to fetch a free session for a Handset.
	  \param[in] ucHandSet - Handset Number
		\param[in] puiSessHdl - Session Handle
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECTAPP_GetFreeSessionForHS(IN uchar8 ucHandSet,OUT uint32 *puiSessHdl);

/*! \brief  This Api validates the Session Identifier.
	  \param[in] nSessionId - Session Identifier
		\param[out] puiSessHdl - Session Handle
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECTAPP_ValidateSessionId(IN uint16 nSessionId,OUT uint32 *puiSessHdl);


/*! \brief  This internal Api reads the entries stored in FP and sends them to be displayed by PP.
	  \param[in] ucListId - List Identifier
		\param[in] pxSortedList - pointer to Sorted List
		\param[in][out] pxReadList - pointer to a structure containing read info such as start index,
	                  counter,mark entries request required for fetching the entries.
						         NACK reason ,if any, is sent back.
		\return IFX_SUCCESS / IFX_FAILURE
		\note  In case of Missed call list/All Incoming calls list,
		       with non-zero mark entries request and empty subset of field identifiers ,only the 
					 read status of the read entries is changed(set/reset) and no data packet is sent subsequetly.

*/
e_IFX_Return 
IFX_DECTAPP_ReadList(IN uchar8 ucListId,
		                              IN void *pxSortedList, 
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList);


/*! \brief  This internal Api searches the entries stored in FP matching the specified criteria and 
	          sends the corresponding entries in separate data packet.
	  \param[in] nSessionId - Session Identifier
		\param[in] ucListId - List Identifier
		\param[in][out] pxSearchList - pointer to structure containing  search info such as matching option,
		                               search string, counter, direction and mark entries request
						                       NACK reason ,if any, is sent back.
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return 
IFX_DECTAPP_SearchList(IN int16 nSessionId,
                                    IN uchar8 ucListId,
		                                IN void *pxSortedList, 
                                    IN OUT x_IFX_DECT_LAU_ListCommands *pxSearchList);

/*! \brief  This internal Api retrieves the requested entry stored in the FP.If available,the contents 
	          are encoded in a separate data packet and sent to PP.
	  \param[in] pxSortedList - pointer to Sorted List
		\param[in] pnPositionId - Position Identifier of the entry in sorted list
		\param[in][out] - pointer to structure containing the entry identifier of the requested entry.
		                   NACK reason ,if any, is sent back.
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return 
IFX_DECTAPP_EditList(IN uchar8 ucListId,
																	IN void *pxSortedList,
                                  OUT int16 *pnPositionId,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxEditList);


/*! \brief  This internal Api saves a new/previously editted entry in the FP.
	  \param[in] ucListId - List Identifier
		\param[in] pnPositionId - Position Identifier
		\param[in] pxSortedList - pointer to Sorted List
		\param[in] unDataLen - Length of entry
		\param[in] pucData - Entry contents
		\param[in] pxSaveList - pointer to structure containing entry identifier of the entry
		                        NACK reason ,if any, is sent back.
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECTAPP_SaveList(IN uchar8 ucListId,
                     IN int16 *pnPositionId,
										 IN void *pxSortedList,
										 IN uint16 *punFieldIds,
                     IN uint16 unDataLen,
                     IN uchar8 *pucData,
                     IN OUT x_IFX_DECT_LAU_ListCommands *pxSaveList);

/*! \brief  This  internal Api deletes from FP the entry identified by
            the entry identifier.	
	  \param[in] ucListId - List Identifier
		\param[in] pxSortedList - pointer to Sorted list
		\param[in][out] pxDeleteList - pointer to structure containing entry identifier of
		                               entry to be deleted and session identifier to specify
																	 the list.
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECTAPP_DeleteListEntry(IN uchar8 ucListId,
		                        IN void *pxSortedList,
                            IN OUT x_IFX_DECT_LAU_ListCommands *pxDeleteList);

/*! \brief  This internal Api deletes all the entries in the list specified.	
	  \param[in] ucListId - List Identifier
		\param[in] pxSortedList - pointer to Sorted list
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECTAPP_DeleteList(IN uchar8 ucListId,
											 IN uchar8 *pucLineIdList,
		                   IN void *pxSortedList);

/*! \brief   This internal Api converts time-date information into
	           BCD format and stores in the structure pxTimeDate.
	  \param[in] pcDate - date info
		\param[in] pcTime - time info
		\param[out] pxTimeDate - pointer to TimeDate structure with information
		                         stored in BCD format
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECT_GetDateTime(IN char* pcDate, IN char* pcTime,OUT x_IFX_DECT_USU_TimeDate *pxTimeDate);


/*! \brief  This internal Api verifies that the non-editable fields are not modified during a save.
	  \param[in] ucListId - List Identifier
		\param[in] unFieldMap - bit map of field identifiers
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
 IFX_DECTAPP_VerifyEditable(IN uchar8 ucListId,IN uint16 unFieldMap);


/*! \brief  This internal Api verifies whether Edit/Save operation is permitted on the List or not.
	          Edit or Save is not allowed in "Call Lists".
	  \param[in] ucListId - List Identifier
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECTAPP_AllowEditSave(IN uchar8 ucListId);


/*! \brief  This internal Api is used to Sort a given list as per the
          	default sorting field.
	  \param[in] pucLineIdList - Line Identifiers list
	  \param[in][out] pxListInfo - pointer to ListInfo structure.
		\return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
 IFX_DECTAPP_ListSort(IN uchar8 *pucLineIdList, 
                      IN OUT x_IFX_DECT_ListInfo *pxListInfo);

/*! \brief  This internal Api uses merge sort technique to sort an array.The array here 
	          comprises of addresses of elements to be sorted which are then typecast to 
						the appropriate type and compared on the basis of default sorting field.
	  \param[in] min_index - minimum index in the list 
	  \param[in] max_index - maximum index in the list 
	  \param[in][out] iSortedArray - integer array containing addresses of list entry
		                structures.The entries at addresses in the array are sorted and
									  sorted addresses are stored back in the array
		\return None
*/
void IFX_DECTAPP_SortList(IN int32 min_index,
                          IN int32 max_index,
                          IN OUT int32 iSortedArray[],
                          IN uchar8 ucListId);

/*! \brief  This internal Api merges the two sorted sub-lists divided at
            mid(mid being part of first sub-list) into one.The two sub-lists
	          contain addresses of list elements in sorted order.
	  \param[in] min_index - minimum index in the list 
	  \param[in] mid - index that divides the two sorted sub-lists
	  \param[in] max_index - maximum index in the list
	  \param[in][out] iSortedArray - integer array containing addresses of list entry
		                structures divided at mid(mid being part of first list).The two 
										sub-lists thus formed contain addresses of entries in sorted 
										order and are merged to form a single sorted list.
	  \param[in] ucListId - List Identifier
		\return IFX_SUCCESS / IFX_FAILURE
*/
void IFX_DECTAPP_MergeSortedLists(IN int32 min_index,
                                  IN int32 mid,
                                  IN int32 max_index,
                                  IN OUT int32 iSortedArray[],
                                  IN uchar8 ucListId);

/*! \brief  This internal Api compares the two list entries at addresses
	          specified by valueA and valueB and indicates whether first entry
	          is greater than,equal to or less than second.
	  \param[in] uiEntryAddrA - address of first entry
	  \param[in] uiEntryAddrB - address of second entry
	  \param[in] ucListId - List Identifier
	  \param[in] ucIscaseSense - Indicates case [in]sensitive search
		\return  interger -> -1,0 or 1
*/		
int32 IFX_DECTAPP_Compare(IN uint32 uiEntryAddrA,IN uint32 uiEntryAddrB,
		                      IN uchar8 ucListId,
                          IN uchar8 ucIsCaseSense);

/*! \brief  This internal Api is used to compare two entries in All Call/All Incoming Call List where 
	          sorting field is Date and Time.The two dates are compared by converting into seconds since 
						Jan 1,1970.
	  \param[in] pcDate - date and time info in the format yyyy-mm-dd HH:MM:SS
		\return  It returns number of seconds elapsed since 00:00:00 on January 1,
		         1970,UTC.The return data type is time_t holding the number of seconds
*/		
time_t toSeconds(uchar8 *pcDate);


/*! \brief  This internal Api takes a time/date element and converts its information into the
            BCD format
	  \param[in] ucTimeDateInfo - date/time info 
		\param[out] pcBCDInfo - date/time info in BCD format
		\return  IFX_SUCCESS/IFX_FAILURE
*/		
extern e_IFX_Return IFX_DECT_GetBCD(IN uchar8 ucTimeDateInfo,OUT uchar8 *pcBCDInfo);


/*! \brief This Api is invoked when there is a change in the Missed
	         Call List(new entry added,read status changed,list deleted,
	         unread missed calls during locate request),to notify the PP(s)
		       that the list is modified since last read operation.
	  \param[in] ucHandset - Handset Identifier
		\param[in] pxOld - Old Missed Call List structure
		\param[in] pxNew - New Missed Call List structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/		
e_IFX_Return
  IFX_DECTAPP_MissedCallNotify(IN uchar8 ucHandset,
			                         IN void *pxOld,
															 IN void *pxNew);

/*! \brief This Api is invoked when there is a change in the Outgoing
	         Call List(when a new entry gets added or list is deleted),
	         to notify the PP(s) that the list is modified since last read
		       operation.
	  \param[in] ucHandset - Handset Identifier
		\param[in] pxOld - Old Outgoing Call List structure
		\param[in] pxNew - New Outgoing Call List structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return
	IFX_DECTAPP_OutgoingCallNotify(IN uchar8 ucHandset,
				                         IN void *pxOld,
																 IN void *pxNew);

/*! \brief This Api is invoked when there is a change in the Incoming
	         Call List(new entry added in the list or list deleted),
	         to notify the PP(s) that the list is modified since last read
		       operation.
	  \param[in] ucHandset - Handset Identifier
		\param[in] pxOld - Old Incoming Call List structure
		\param[in] pxNew - New Incoming Call List structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return
	IFX_DECTAPP_IncomingCallNotify(IN uchar8 ucHandset,
				                         IN void *pxOld,
																 IN void *pxNew);

/*! \brief This Api is invoked when there is a change in the Internal
	         Names List(PP name modified or new entry during attachment),
	         to notify the PP(s) that the list is modified since last read
		       operation.
	  \param[in] ucHandset - Handset Identifier
		\param[in] pxOld - Old Internal Names List structure
		\param[in] pxNew - New Internal Names List structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return
	IFX_DECTAPP_InternalNamesNotify(IN uchar8 ucHandset,
				                          IN void *pxOld,
																	IN void *pxNew);


/*! \brief This Api is invoked when there is a change in the Line
	         Settings List(HS Assoc Changes,Change in Calling Features,Line
	         Add/Delete operation),to notify the PP(s) that the list is
		       modified since last read operation.
	  \param[in] ucHandset - Handset Identifier
	  \param[in] ucLineObjType - Line Object 1-Assoc HS,LineAdd/Delete 0-Call Features
		\param[in] pxOld - Old Line Settings List structure
		\param[in] pxNew - New Line Settings List structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return
  IFX_DECTAPP_LineSettingsNotify(IN uchar8 ucHandset,
			                           IN uchar8 ucLineObjType,
															   IN void *pxOld,
																 IN void *pxNew);

/*! \brief This Api is invoked when there is a change in the Contact
	         List(Edit/Add/Delete op),to notify the PP that the list is
	         modified since last read operation.
	  \param[in] ucHandset - Handset Identifier
		\param[in] pxOld - Old Contact List structure
		\param[in] pxNew - New Contact List structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return
	  IFX_DECTAPP_ContactListNotify(IN uchar8 ucHandset,
				                          IN void *pxOld,
																  IN void *pxNew);

/*! \brief This Api is invoked when there is a change in the System                                                                                                
           Settings List(change in mandatory param or base reset),                                                                                                 
           to notify the PP that the list is modified since last read                                                                                              
           operation.     
	  \param[in] ucHandset - Handset Identifier
		\param[in] pxOld - Old System Settings List structure
		\param[in] pxNew - New System Settings structure
		\return  IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return                                                                                                                                                       
  IFX_DECTAPP_SystemSettingsNotify(IN uchar8 ucHandset,                                                                                                            
                                IN void *pxOld,                                                                                                                    
                                IN void *pxNew); 
//Find Abode
char *strptime(const char *s, const char *format, struct tm *tm);

e_IFX_Return
  IFX_CIF_NoOfEntriesGet(IN uchar8 ucListId,
			                   IN uchar8 ucLineId,
												 OUT uchar8 *pucNoOfEntries);

e_IFX_Return
IFX_CIF_NoOfUnreadGet(IN uchar8 ucLineId,OUT uchar8 *pucNoOfUnread);

e_IFX_Return
IFX_CIF_AssocLineIdsGet(IN uchar8 ucHandset,OUT uchar8 *pucLineIdList);

e_IFX_Return
IFX_CIF_ModifiedNamePP(IN void *pxOld,IN void *pxNew,OUT uchar8 *pucHandset);

e_IFX_Return
IFX_CIF_RegisteredPPsGet(OUT uchar8 *pucRegisteredHS);

e_IFX_Return
IFX_CIF_LineChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *ucLineId);

e_IFX_Return
IFX_CIF_PSTNLineChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *ucLineId);

e_IFX_Return
IFX_CIF_CallFeatChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *ucLineId);

e_IFX_Return
IFX_CIF_SystemChange(IN void *pxOld,IN void *pxNew);

e_IFX_Return
IFX_CIF_MissedCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_MissedCallList *pxMissedCallList);

e_IFX_Return
IFX_CIF_MissedCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_MissedCallList *pxMissedCallList,
					                          IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_OutgoingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList);

e_IFX_Return
IFX_CIF_IncomingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList);

e_IFX_Return
IFX_CIF_AllCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_AllCallList *pxAllCallList);

e_IFX_Return
IFX_CIF_AllIncomingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCallList);

e_IFX_Return
IFX_CIF_LineGet(OUT x_IFX_DECT_LAU_LineSettingsList *pxLineList);

e_IFX_Return
IFX_CIF_SystemGet(OUT x_IFX_DECT_LAU_SystemSettingsList *pxSystemList);

e_IFX_Return
IFX_CIF_IntNameGet(OUT x_IFX_DECT_LAU_IntNameList *pxIntList);

e_IFX_Return
IFX_CIF_ContactListGet(OUT x_IFX_DECT_LAU_ContactList *pxContactList, uchar8 ucLineId);

e_IFX_Return
IFX_CIF_CommonContactListGet(OUT x_IFX_DECT_LAU_ContactList *pxContactList);

e_IFX_Return
IFX_CIF_SystemSet(IN x_IFX_DECT_LAU_SystemSettingsList *pxSysList);

e_IFX_Return
IFX_CIF_LineSet(IN x_IFX_DECT_LAU_LineSettingsList *pxLineSetList,
		            IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_IntNameSet(IN x_IFX_DECT_LAU_IntNameList *pxListName,
		               IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_ContactListSet(IN x_IFX_DECT_LAU_ContactListEntry *pxContactList,
											 IN uchar8 *pcLineIdList,
		                   IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_CommonContactListSet(IN x_IFX_DECT_LAU_ContactListEntry *pxContactList,
		                   IN uchar8 ucOp);
e_IFX_Return
  IFX_CIF_OutgoingCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList,
			                              IN uchar8 ucOp);

e_IFX_Return
  IFX_CIF_IncomingCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList,
			                              IN uchar8 ucOp);
e_IFX_Return
  IFX_CIF_ListObjectGet(IN uchar8 ucListType,IN void *pxObj,OUT void *pxList);

void
IFX_DECTAPP_PopulateSupportedFieldMap(IN OUT uint32 *puiList);
#endif // __IFX_DECT_LISTACCESS_H__
