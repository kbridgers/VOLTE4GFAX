#!/bin/sh

/usr/sbin/upgrade /etc/dect_rc.conf.gz dectconfig 0 0
cp -f /etc/dect_rc.conf.gz /ramdisk/flash/
/bin/gunzip -f /ramdisk/flash/dect_rc.conf.gz

#sleep 4
#reboot

