/*******************************************************************************
 **   FILE NAME    : LTQ_APP_Parser.h
 **   PROJECT      : COSIC VoIP Software
 **   MODULES      : AT Command Parser
 **   SRC VERSION  : 1.0
 **   DATE         : 10-July-2011
 **   AUTHOR       : Swaroop Sarma(LQIN)
 **   DESCRIPTION  : This header file defines Generic AT Command parser API's,  
 **                  Constants,enumerations and Data Structures..
 **   COMPILER     : Keil 8051 - uVision V3.62c
 **   REFERENCE    : DECT standards,GAP,CAT-iq 2.0
 **   COPYRIGHT    : Lantiq Deutschland GmbH 2011 � All rights reserved.

 **  Version Control Section  **
 ** $Rev:$
 ** $Author:$
 ** $Date:$

*******************************************************************************/
#ifndef __LTQ_APP_PARSER_H__
#define __LTQ_APP_PARSER_H__
#include "ifx_common_defs.h"

/*! \file LTQ_APP_Parser.h 
    \brief This File contains the Data structures Constants, enumerations and
           APIs for Generic ATCommandParser.
*/

 /*! \def LTQ_ATCMD_MAX_INDEX
    \brief Macro that specifies the maximum number of Indices in an ATCommand.
*/

#define LTQ_ATCMD_MAX_INDEX 20

/*! \def LTQ_ATCMD_MAX_INDEX
    \brief Macro that specifies the maximum size of ATCommand Buffer.
*/
#define LTQ_ATCMD_MAX_BUFF 50

/*#define uint32 unsigned long int
#define uint16 unsigned int
#define uchar8 unsigned char
typedef enum{
	IFX_SUCCESS,
	IFX_FAILURE
}e_IFX_Return;*/

 /*! 
    \brief Structure for maintaining the Command Handle for an ATCommand.
*/
typedef struct{
  uchar8  *pucBuff;                        /*!< Pointer to the Buffer*/
  uchar8  *aucIndex[LTQ_ATCMD_MAX_INDEX];  /*!< Array of pointers to the 
                                                   values in an AT Command*/
  uchar8  *pucCmd;                         /*!< Pointer to the Command
                                                    in an AT Command*/
  uchar8 ucSize;                                /*!< Length of the Parsed buffer*/
  uchar8 isAlloc;                               /*!< To check for buffer allocation
                                                  in case of Set Command*/
  uint32 uiFieldMap;                            /*!< Fieldmap of fields received*/
  uchar8 ucNoOfFields;                           /*!< No Of fields received in buffer*/
}x_LTQ_AT_Parser;

 /*! 
    \brief Structure to define the AT Command formatting.
*/
typedef struct{
	uchar8 ucTermChar;                 /*!< AT Command terminating character*/
	uchar8 ucRespChar;                 /*!< AT Command Response character*/
	uchar8 ucEditChar;                  /*!< AT Command Editingting character*/
	uchar8 ucEcho;                      /*!< AT Command Echo*/
	uchar8 ucResultCode;                /*!< AT Command Result Transmit*/
	uchar8 ucRespFormat;                /*!< AT Command Resp Format*/
}x_LTQ_ATCmd_V250;

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_GenericParse()                                                */
/* -------------------------------------------------------------------------- */
/*! 
    \brief  api to parse a ATCommand received from application.     
    \param[in] pucBuffer - pointer to buffer received from application.
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned 
                             after malloc in this function.
    \param[in,out] pucLength- pointer which indicates the length of the parsed 
                              buffer i0f the length received is non-zero the 
                              parsing the buffer starts from pucBuffer+pucLength
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_GenericParse(uchar8  *pucBuffer,
                                    void **pCmdHdl,
                                    uchar8 *pucLength);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_ValueGet()                                              */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to get the value from the Index passed by application.     
    \param[in] pucCmdHdl - pointer to Command Handle
    \param[in] ucIndex- Index of the param in an AT Command.
    \result return a pointer to the value or null on success or failure respectively
*/


 uchar8  *LTQ_ATCmd_ValueGet(uchar8 ucIndex,
                                      void *pCmdHdl);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_ValueSet()                                             */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the string for an Index passed by application.Should be 
            called after setting the Command.                 
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[in] pucCmdHdl - pointer to the callHdl.
    \param[in] pucString - pointer to the string value that need to be set.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_ValueSet(uchar8 ucIndex, 
                                        void *pCmdHdl,
                                        uchar8  *pucString);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_IntValueSet()                                          */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the Integer value for an Index passed by application.     
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[in] pucCmdHdl - pointer to the commandHdl.
    \param[in] uiValue - Integer value that need to be set.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_IntValueSet(uchar8 ucIndex, 
                                          void *pCmdHdl,
                                          uint16 uiValue);


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_ByteValueSet()                                         */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the uchar8 value for an Index passed by application.     
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[in] pucCmdHdl - pointer to the commandHdl.
    \param[in] ucValue - uchar8 value that need to be set.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_ByteValueSet(uchar8 ucIndex, 
                                           void *pCmdHdl,
                                           uchar8 ucValue);


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_CmdGet()                                                */
/* -------------------------------------------------------------------------- */
/*! 
    \brief  api to get the command from the Handle passed by application.     
    \param[in] pucCmdHdl - pointer to CommandHdl.
    \result return a pointer to the Command value or null on success or failure 
            respectively
*/
 uchar8  *LTQ_ATCmd_CmdGet(void *pCmdHdl);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_CmdSet()                                                */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the command and allocate the buffer for Setting an 
            AT Command.Should be set only once.      
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned after malloc 
                  in this function.
    \param[in] pucString - pointer to the string/Command.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_CmdSet(void **pCmdHdl,
                                     uchar8  *pucString);


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_Freehandle()                                                */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to free the CommandHandle.The buffer will also be frred if 
             the handle belongs to an set command.     
    \param[in] pucCmdhdl - pointer to the CommandHandle.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_FreeHandle(void  *pucCmdhdl);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_BufferGet()                                                */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to get the buffer after preparing the ATCommand for sending.
            Should be called after setting the individual params.     
    \param[in] pucCmdHdl - pointer to CommandHdl.
    \param[out] pucBuff- pointer to AT Command buffer.
    \result return the length of the buffer.
*/
 uchar8 LTQ_ATCmd_BufferGet(void *pCmdHdl,
                                uchar8  **pucBuff);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_FieldIdPresenceCheck()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to check presence of a field in an ATCommand..     
    \param[in] ucIndex - Index of the field.
    \param[in] pucCmdHdl - pointer to the CommandHandle.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_FieldIdPresenceCheck(uchar8 ucIndex,
                                                   void *pCmdHdl);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_FieldIdMapCheck()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to check for fieldmap of mandatory fields in an ATCommand.     
    \param[in] ucFieldMap - FieldMap that need to be checked.
    \param[in] pucCmdHdl - pointer to the CommandHandle.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_FieldMapCheck(uchar8 ucFieldMap,
                                            void *pCmdHdl);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_MaxIndexGet()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to fetch the Max Index in an ATCommand.     
    \param[in] pucCmdHdl - pointer to the CommandHandle.
    \result returns the Max Index Value.
*/

 uchar8 LTQ_ATCmd_MaxIndexGet(void *pCmdHdl);

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_ByteValueGet()                                             */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to get the value from the Index passed by application.     
    \param[in] pucCmdHdl - pointer to Command Handle
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[out] pucValue- Pointer to the value to be filled in
    \result return a IFX_SUCCESS or IFX_FAILURE in case of success/failure 
*/

 e_IFX_Return LTQ_ATCmd_ByteValueGet(uchar8 ucIndex,void *pCmdHdl,
                                        uchar8 *pucValue);

#endif //- __LTQ_APP_PARSER_H__
