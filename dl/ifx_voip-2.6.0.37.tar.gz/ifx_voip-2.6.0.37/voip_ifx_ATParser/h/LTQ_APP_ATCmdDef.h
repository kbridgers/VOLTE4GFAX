/*******************************************************************************
 **   FILE NAME    : LTQ_APP_ATCmdDef.h.h
 **   PROJECT      : COSIC VoIP Software
 **   MODULES      : AT Command Parser
 **   SRC VERSION  : 1.0
 **   DATE         : 10-July-2011
 **   AUTHOR       : Swaroop Sarma(LQIN)
 **   DESCRIPTION  : This header file defines AT Command definitions and 
 **                   structures
 **   COMPILER     : Keil 8051 - uVision V3.62c
 **   REFERENCE    : DECT standards,GAP,CAT-iq 2.0
 **   COPYRIGHT    : Lantiq Deutschland GmbH 2011 � All rights reserved.

 **  Version Control Section  **
 ** $Rev:$
 ** $Author:$
 ** $Date:$

*******************************************************************************/
#ifndef __LTQ_APP_ATCMDDEF_H__
#define __LTQ_APP_ATCMDDEF_H__
#include "ifx_common_defs.h"

/*! \file LTQ_ATCmdDef.h 
    \brief File containing the enums and structures of ATCommands.
*/
//#define uint32 unsigned long int
//#define uint16 unsigned int
//#define uchar8 unsigned char
 /*! \def LTQ_MAX_NO_OF_FIELDS
    \brief Macro that specifies the maximum number of fields in an ATCommand.
*/
#define LTQ_MAX_NO_OF_FIELDS 32

 /*! \def LTQ_NO_OF_ATTXCMD
    \brief Macro that specifies the number of AT Tx commands for CVoip.
*/

#define LTQ_NO_OF_ATTXCMD 9

  /*! \def LTQ_NO_OF_ATRXCMD
    \brief Macro that specifies the number of AT Rx commands for CVoip.
*/

#define LTQ_NO_OF_ATRXCMD 6

 /*! \def LTQ_NO_OF_ATCMD_RESP
    \brief Macro that specifies the number of AT Response commands for CVoip.
*/
#define LTQ_NO_OF_ATCMD_RESP 7

  /*! \def LTQ_NO_OF_ATCMD_COMMON
    \brief Macro that specifies the number of AT commands for CVoip common 
      for  Tx/Rx.
*/
#define LTQ_NO_OF_ATCMD_COMMON 18


/*! \def LTQ_NO_OF_ATCMD
    \brief Macro that specifies the number of AT commands 
*/
#define LTQ_NO_OF_ATCMD (LTQ_NO_OF_ATCMD_COMMON+LTQ_NO_OF_ATCMD_RESP+LTQ_NO_OF_ATRXCMD+LTQ_NO_OF_ATTXCMD)


/*typedef enum{
	IFX_SUCCESS,
	IFX_FAILURE
}e_IFX_Return;*/

/*! \enum e_LTQ_ErrorResp
    \brief Enum defining error codes for the error(+CME ERROR) response.
*/
typedef enum{
	LTQ_ErrorResp_General=0,  /*!< General Error */
	LTQ_ErrorResp_Cnxt=1,     /*!< Invalid Context */
	LTQ_ErrorResp_String=2,   /*!< Invalid String */
	LTQ_ErrorResp_LineId=3,   /*!< Invalid LineId*/
	LTQ_ErrorResp_CallType=4, /*!< Invalid call type */
	LTQ_ErrorResp_ConnType=5, /*!< Invalid Connection Type*/
	LTQ_ErrorResp_CodecList=6,/*!< Invalid Codec List */
	LTQ_ErrorResp_ChannelId=7,/*!< Invalid Channel id */
	LTQ_ErrorResp_Index=8,    /*!< Invalid Index */
	LTQ_ErrorResp_Direction=9,/*!< Invalid Direction */
	LTQ_ErrorResp_Option=10,  /*!< Invalid Option */
	LTQ_ErrorResp_EntryId=11  /*!< Invalid Entry Id */
}e_LTQ_ErrorResp;


/*! \enum e_LTQ_ATCmd_Type
    \brief Enum defining error codes for the error(+CME ERROR) response.
*/

typedef enum
{ /*TX Commands*/
	LTQ_ATCmd_Dial=0,              /*!< AT Command for dialing */
	LTQ_ATCmd_Hangup=1,            /*!< AT Command for Hangup */
	LTQ_ATCmd_Accept=2,            /*!< AT Command for Call Accept */
	LTQ_ATCmd_Answer=3,            /*!< AT Command for Call Answer */
  LTQ_ATCmd_Init=4,              /*!< AT Command for Initialization */
  LTQ_ATCmd_DTMF=5,              /*!< AT Command for DTMF Digits */
  /*RX Commands*/
	LTQ_ATCmd_CallProceeding=6,    /*!< AT Command for Call Proceeding Indication*/
	LTQ_ATCmd_RemoteAccept=7,      /*!< AT Command for Remote CallAccept Indication*/
  LTQ_ATCmd_IncomingCall=8,      /*!< AT Command for Incoming Call Indication */
	LTQ_ATCmd_CLIP=9,              /*!< AT Command for CLIP  Indication*/
	LTQ_ATCmd_CWCLIP=10,           /*!< AT Command for Call waiting CLIP Indication*/
	LTQ_ATCmd_Tone=11,             /*!< AT Command for Tone Indication */
	LTQ_ATCmd_Config_PCM=12,       /*!< AT Command for PCM Channel Configuration */
	LTQ_ATCmd_Reset=13,            /*!< AT Command for Modem reset */
	LTQ_ATCmd_Save=14,              /*!< AT Command for Config save */
  /*Responses*/
  LTQ_ATResp_Ok=15,              /*!< AT Response OK */
	LTQ_ATResp_Connect=16,         /*!< AT Response CONNECT*/
	LTQ_ATResp_NoCarrier=17,       /*!< AT Response NOCARRIER */
	LTQ_ATResp_CMEError=18,        /*!< AT Response CME_ERROR */
 	LTQ_ATResp_NoDialTone=19,      /*!< AT Response NO Dial Tone*/
	LTQ_ATResp_Busy=20,            /*!< AT Response BUSY */
	LTQ_ATResp_NoAnswer=21,        /*!< AT Response NO ANSWER */
  /*Common commands*/
	LTQ_ATCmd_COAP=22,            /*!< AT Command for query/set Close or open Audio path*/
	LTQ_ATCmd_CHLD=23,            /*!< AT Command for Supplementary services*/
	LTQ_ATCmd_CREG=24,            /*!< AT Command for query/set Registration*/
	LTQ_ATCmd_VersionInfo=25,     /*!< AT Command for query/set Version Info*/
	LTQ_ATCmd_Diagnostics=26,     /*!< AT Command for query/set Diagnostics mode*/
	LTQ_ATCmd_RAM=27,             /*!< AT Command for query/set RAM parameters*/
	LTQ_ATCmd_BMC=28,              /*!< AT Command for query/set BMC parameters*/
	LTQ_ATCmd_TPC=29,             /*!< AT Command for query/set TPC parameters*/
	LTQ_ATCmd_RfMode=30,          /*!< AT Command for query/set RF Mode*/
	LTQ_ATCmd_OscTrim=31,         /*!< AT Command for query/set Oscillator parameters*/
	LTQ_ATCmd_Freq=32,            /*!< AT Command for query/set Frequency parameters*/
	LTQ_ATCmd_Gfsk=33,            /*!< AT Command for query/set GFSK parameters*/
	LTQ_ATCmd_Rfpi=34,             /*!< AT Command for query/set RFPI parameters*/
	LTQ_ATCmd_TBR06=35,            /*!< AT Command for query/set TBR06 Mode*/
	LTQ_ATCmd_InterDigitTimer=36,  /*!< AT Command for query/set Interdigit Timer*/
	LTQ_ATCmd_Pin=37,              /*!< AT Command for query/set Base pin*/
	LTQ_ATCmd_Capabilities=38,     /*!< AT Command for query/set Base Capabilities*/
	LTQ_ATCmd_HSIDLE=39,     /*!< AT Command for query/set Base Capabilities*/
	LTQ_ATCmd_Invalid=40           /*!< Invalid AT Command */
}e_LTQ_ATCmd_Type;/*End*/

/*! \enum e_LTQ_DialCmd_Index
    \brief Enum defining the indices of DialCmd.
*/

typedef enum
{
	LTQ_DialCmd_CtxId=1,
	LTQ_DialCmd_CallId=2,
	LTQ_DialCmd_Number=3,
	LTQ_DialCmd_LineId=4,
	LTQ_DialCmd_CallType=5,
	LTQ_DialCmd_ConnType=6,
	LTQ_DialCmd_Codec1=7,
	LTQ_DialCmd_Codec2=8,
	LTQ_DialCmd_Codec3=9,
	LTQ_DialCmd_ChannelId=10
}e_LTQ_DialCmd_Index;

/*! \enum e_LTQ_HangUpCmd_Index
    \brief Enum defining the indices of HangupCmd.
*/
typedef enum
{
	LTQ_HangUpCmd_CtxId=1,
	LTQ_HangUpCmd_CallId=2
}e_LTQ_HangUpCmd_Index;


/*! \enum e_LTQ_AcceptCmd_Index
    \brief Enum defining the indices of CallAcceptCmd.
*/

typedef enum
{
	LTQ_AcceptCmd_CtxId=1,
	LTQ_AcceptCmd_CallId=2
}e_LTQ_AcceptCmd_Index;

/*! \enum e_LTQ_AnswerCmd_Index
    \brief Enum defining the indices of CallAnswerCmd.
*/
typedef enum
{
	LTQ_AnswerCmd_CtxId=1,
	LTQ_AnswerCmd_CallId=2,
 	LTQ_AnswerCmd_ChannelId=3
}e_LTQ_AnswerCmd_Index;


/*! \enum e_LTQ_DTMFCmd_Index
    \brief Enum defining the indices of DTMFDigitsCmd.
*/

typedef enum
{
	LTQ_DTMFCmd_CtxId=1,
	LTQ_DTMFCmd_Number=2,
 	LTQ_DTMFCmd_Duration=3
}e_LTQ_DTMFCmd_Index;

/*! \enum e_LTQ_InitCmd_Index
    \brief Enum defining the indices of InitCmd.
*/

typedef enum
{
	LTQ_InitCmd_CtxId=1
}e_LTQ_InitCmd_Index;

/*! \enum e_LTQ_CallProcCmd_Index
    \brief Enum defining the indices of CallProceedingCmd.
*/

typedef enum
{
	LTQ_CallProcCmd_CtxId=1,
	LTQ_CallProcCmd_CallId=2,
	LTQ_CallProcCmd_LineId=3
}e_LTQ_CallProcCmd_Index;

/*! \enum e_LTQ_RemoteAcceptCmd_Index
    \brief Enum defining the indices of RemoteAcceptCmd.
*/

typedef enum
{
	LTQ_RemoteAcceptCmd_CtxId=1,
	LTQ_RemoteAcceptCmd_CallId=2
}e_LTQ_RemoteAcceptCmd_Index;

/*! \enum e_LTQ_CallIncomingCmd_Index
    \brief Enum defining the indices of IncomingCallIndCmd.
*/
typedef enum
{
	LTQ_CallIncomingCmd_CtxId=1,
	LTQ_CallIncomingCmd_LineId=2,
	LTQ_CallIncomingCmd_CallType=3,
	LTQ_CallIncomingCmd_ConnType=4,
	LTQ_CallIncomingCmd_Codec1=5,
	LTQ_CallIncomingCmd_Codec2=6,
	LTQ_CallIncomingCmd_Codec3=7
}e_LTQ_CallIncomingCmd_Index;

/*! \enum e_LTQ_CLIPCmd_Index
    \brief Enum defining the indices of CLIPCmd.
*/

typedef enum
{
	LTQ_CLIPCmd_CtxId=1,
	LTQ_CLIPCmd_Number=2,
	LTQ_CLIPCmd_Name=3,
	LTQ_CLIPCmd_Validity=4
}e_LTQ_CLIPCmd_Index;

/*! \enum e_LTQ_CWCLIPCmd_Index
    \brief Enum defining the indices of CWCLIPCmd.
*/

typedef enum
{
	LTQ_CWCLIPCmd_CtxId=1,
	LTQ_CWCLIPCmd_Number=2,
	LTQ_CWCLIPCmd_Name=3,
	LTQ_CWCLIPCmd_Validity=4
}e_LTQ_CWCLIPCmd_Index;

/*! \enum e_LTQ_ToneCmd_Index
    \brief Enum defining the indices of ToneCmd.
*/

typedef enum
{
	LTQ_ToneCmd_CtxId=1,
	LTQ_ToneCmd_Tone=2
}e_LTQ_ToneCmd_Index;

/*! \enum e_LTQ_PCMConfCmd_Index
    \brief Enum defining the indices of PCMCfgCmd.
*/

typedef enum
{
	LTQ_PCMConfCmd_CtxId=1,
	LTQ_PCMConfCmd_Master=2,
	LTQ_PCMConfCmd_TxId1=3,
	LTQ_PCMConfCmd_RxId1=4,
	LTQ_PCMConfCmd_ChannelId1=5,
	LTQ_PCMConfCmd_TxId2=6,
	LTQ_PCMConfCmd_RxId2=7,
	LTQ_PCMConfCmd_ChannelId2=8,
	LTQ_PCMConfCmd_TxId3=9,
	LTQ_PCMConfCmd_RxId3=10,
	LTQ_PCMConfCmd_ChannelId3=11,
	LTQ_PCMConfCmd_TxId4=12,
	LTQ_PCMConfCmd_RxId4=13,
	LTQ_PCMConfCmd_ChannelId4=14
}e_LTQ_PCMConfCmd_Index;


/*! \enum e_LTQ_ResetCmd_Index
    \brief Enum defining the indices of BaseResetCmd.
*/
typedef enum
{
	LTQ_ResetCmd_CtxId=1
}e_LTQ_ResetCmd_Index;

/*! \enum e_LTQ_COAPCmd_Index
    \brief Enum defining the indices of COAPCmd.
*/

typedef enum
{
	LTQ_COAPCmd_CtxId=1,
	LTQ_COAPCmd_CallId=2,
	LTQ_COAPCmd_Operation=3,
	LTQ_COAPCmd_ChannelId=4,
	LTQ_COAPCmd_Codec1=5,
	LTQ_COAPCmd_Codec2=6,
	LTQ_COAPCmd_Codec3=7
}e_LTQ_COAPCmd_Index;

/*! \enum e_LTQ_CHLDCmd_Index
    \brief Enum defining the indices of ChildServicesCmd.
*/

typedef enum
{
	LTQ_CHLDCmd_CtxId=1,
	LTQ_CHLDCmd_ServiceNumber=2,
	LTQ_CHLDCmd_CallId=3,
	LTQ_CHLDCmd_CallState=4,
	LTQ_CHLDCmd_Number=5
}e_LTQ_CHLDCmd_Index;

/*! \enum e_LTQ_CREGCmd_Index
    \brief Enum defining the indices of RegistrationCmd.
*/

typedef enum
{
	LTQ_CREGCmd_CtxId=1,
	LTQ_CREGCmd_Mode=2,
	LTQ_CREGCmd_BaseName=3,
	LTQ_CREGCmd_Status=4,
	LTQ_CREGCmd_Cap=5
}e_LTQ_CREGCmd_Index;

/*! \enum e_LTQ_VersionInfoCmd_Index
    \brief Enum defining the indices of VersionInfoCmd.
*/
typedef enum
{

	LTQ_VersionInfoCmd_CtxId=1,

	LTQ_VersionInfoCmd_BMCVer=2,
	LTQ_VersionInfoCmd_SWVer=3,
	LTQ_VersionInfoCmd_DriverVer=4

}e_LTQ_VersionInfoCmd_Index;

/*! \enum e_LTQ_InterDigitTimerCmd_Index
    \brief Enum defining the indices of InterDigitTimersettingCmd.
*/
typedef enum
{
	LTQ_InterDigitTimerCmd_CtxId=1,
	LTQ_InterDigitTimerCmd_TimerValue=2
}e_LTQ_InterDigitTimerCmd_Index;

/*! \enum e_LTQ_BasePinCmd_Index
    \brief Enum defining the indices of BasepinCmd.
*/
typedef enum
{
	LTQ_BasePinCmd_CtxId=1,
	LTQ_BasePinCmd_Pin=2
}e_LTQ_BasePinCmd_Index;

/*! \enum e_LTQ_BaseCapCmd_Index
    \brief Enum defining the indices of BaseCapabCmd.
*/
typedef enum
{
	LTQ_BaseCapCmd_CtxId=1,
	LTQ_BaseCapCmd_EasyPair=2,
	LTQ_BaseCapCmd_NEMO=3,
	LTQ_BaseCapCmd_PCall=4,
	LTQ_BaseCapCmd_MultiLine=5,
	LTQ_BaseCapCmd_Encryption=6,
	LTQ_BaseCapCmd_Rekeying=7
}e_LTQ_BaseCapCmd_Index;

/*! \enum e_LTQ_DiagCmd_Index
    \brief Enum defining the indices of DiagnosticsCmd.
*/
typedef enum
{
	LTQ_DiagCmd_CtxId=1,
	LTQ_DiagCmd_Mode=2
}e_LTQ_DiagCmd_Index;

/*! \enum e_LTQ_RamParamsCmd_Index
    \brief Enum defining the indices of RamParamsCmd.
*/
typedef enum
{
	LTQ_RamParamsCmd_CtxId=1,
	LTQ_RamParamsCmd_MemType=2,
  LTQ_RamParamsCmd_Bank=3,
	LTQ_RamParamsCmd_Address=4,
	LTQ_RamParamsCmd_Value=5
}e_LTQ_RamParamsCmd_Index;

/*! \enum e_LTQ_BMCCmd_Index
    \brief Enum defining the indices of BMCParamsCmd.
*/
typedef enum
{
	LTQ_BMCCmd_CtxId=1,
	LTQ_BMCCmd_Rssifree=2,
	LTQ_BMCCmd_Rssibusy=3,
	LTQ_BMCCmd_BearerChangelimit=4,
	LTQ_BMCCmd_DefAntenna=5,
	LTQ_BMCCmd_Osf=6,
	LTQ_BMCCmd_Wsf=7,
	LTQ_BMCCmd_ControlReg=8,
	LTQ_BMCCmd_DelayReg=9,
	LTQ_BMCCmd_Gsmc=10,
	LTQ_BMCCmd_HOPeriod=11,
	LTQ_BMCCmd_PowerLevel=12,
	LTQ_BMCCmd_PowerAlgorithm=13,
	LTQ_BMCCmd_NormalTcoRR=14,
	LTQ_BMCCmd_NormalBattmeas=15,
	LTQ_BMCCmd_GreenTcoRR=16,
	LTQ_BMCCmd_GreenBattmeas=17
}e_LTQ_BMCCmd_Index;

/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_TPCCmd_CtxId=1,
	LTQ_TPCCmd_TxBias=17
}e_LTQ_TPCCmd_Index;
/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_OscTrimCmd_CtxId=1,
	LTQ_OscTrimCmd_HI,
	LTQ_OscTrimCmd_LOW,
	LTQ_OscTrimCmd_P10
}e_LTQ_OscTrimCmd_Index;
/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_GfskCmd_CtxId=1,
	LTQ_GfskCmd_HI,
	LTQ_GfskCmd_LOW
}e_LTQ_GfskCmd_Index;
/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_RfModeCmd_CtxId=1,
	LTQ_RfModeCmd_TxtTestMode,
	LTQ_RfModeCmd_Channel,
	LTQ_RfModeCmd_Slot
}e_LTQ_RfModeCmd_Index;
/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_RfpiCmd_CtxId=1,
	LTQ_RfpiCmd_Byte0,
	LTQ_RfpiCmd_Byte1,
	LTQ_RfpiCmd_Byte2,
	LTQ_RfpiCmd_Byte3,
	LTQ_RfpiCmd_Byte4
}e_LTQ_RfpiCmd_Index;
/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_RAMCmd_CtxId=1,
	LTQ_RAMCmd_Type,
	LTQ_RAMCmd_Addr,
	LTQ_RAMCmd_Value,
}e_LTQ_RAMCmd_Index;
/*! \enum e_LTQ_TPCCmd_Index
    \brief Enum defining the indices of TPCParamsCmd.
*/
typedef enum
{
	LTQ_FreqCmd_CtxId=1,
	LTQ_FreqCmd_TxOff,
	LTQ_FreqCmd_RxOff,
	LTQ_FreqCmd_Range,
	LTQ_FreqCmd_Eci,
	LTQ_FreqCmd_ChMaskHigh,
	LTQ_FreqCmd_ChMaskLow,
}e_LTQ_FreqCmd_Index;

/*! \enum e_LTQ_HSIdleCmd_Index
    \brief Enum defining the indices of HangupCmd.
*/
typedef enum
{
  LTQ_HSIDLECmd_CtxId=1,
  LTQ_HSIDLECmd_Value=2
}e_LTQ_HSIDLECmd_Index;

#endif  // - __LTQ_APP_ATCMDDEF_H__
