/*******************************************************************************
 **   FILE NAME    : LTQ_APP_Parser_Intf.h
 **   PROJECT      : COSIC VoIP Software
 **   MODULES      : AT Command Parser
 **   SRC VERSION  : 1.0
 **   DATE         : 10-July-2011
 **   AUTHOR       : Swaroop Sarma(LQIN)
 **   DESCRIPTION  : This header file defines AT Command parser Interface API's  
 **                   specific to the application.
 **   COMPILER     : Keil 8051 - uVision V3.62c
 **   REFERENCE    : DECT standards,GAP,CAT-iq 2.0
 **   COPYRIGHT    : Lantiq Deutschland GmbH 2011 � All rights reserved.

 **  Version Control Section  **
 ** $Rev:$
 ** $Author:$
 ** $Date:$

*******************************************************************************/
#ifndef __LTQ_APP_PARSER_INTF_H__
#define __LTQ_APP_PARSER_INTF_H__

 /*! \file LTQ_APP_Parser_Intf.h
    \brief This File contains the Data structures Constants, enumerations and
           APIs for AT Command parser interface specific to application.
*/
//- parser definitions
#include "LTQ_APP_ATCmdDef.h"
#include "LTQ_APP_Parser.h"

/* -----------------------------------------------------------------------
	  * Bit defines
		 * ----------------------------------------------------------------------- */
#define BIT0        0x01
#define BIT1        0x02
#define BIT2        0x04
#define BIT3        0x08
#define BIT4        0x10
#define BIT5        0x20
#define BIT6        0x40
#define BIT7        0x80

#define BIT8      0x0100
#define BIT9      0x0200
#define BIT10     0x0400
#define BIT11     0x0800
#define BIT12     0x1000
#define BIT13     0x2000
#define BIT14     0x4000
#define BIT15     0x8000

#define BIT16 0x00010000
#define BIT17 0x00020000
#define BIT18 0x00040000
#define BIT19 0x00080000
#define BIT20 0x00100000
#define BIT21 0x00200000
#define BIT22 0x00400000
#define BIT23 0x00800000

#define BIT24 0x01000000
#define BIT25 0x02000000
#define BIT26 0x04000000
#define BIT27 0x08000000
#define BIT28 0x10000000
#define BIT29 0x20000000
#define BIT30 0x40000000
#define BIT31 0x80000000






/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_CmdTypeSet()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief setcmd api to set a command in an ATCommand String.     
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned 
                    after malloc.
    \param[in] eType- anyone value from the enum e_LTQ_ATCmd_Type.
    \result IFX_SUCCESS / IFX_FAILURE on success or failure respectively.
*/
 e_IFX_Return LTQ_ATCmd_CmdTypeSet(void **pCmdHdl,
                                          e_LTQ_ATCmd_Type eType);


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_TypeGet()                                 */
/* -------------------------------------------------------------------------- */

/*! \method LTQ_ATCmd_TypeGet
    \brief getcmd api to get the type of command in the ATCommand.     
    \param[in] puCmdHdl - pointer to CommandHdl.
    \result value from the enum e_LTQ_ATCmd_Type 
*/
 uchar8  LTQ_ATCmd_TypeGet(void *pCmdHdl);


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_MandatoryparamCheck()                                 */
/* -------------------------------------------------------------------------- */
/*! 
    \brief api to check for mandatory commands in an  ATCommand String.     
    \param[in] pucCmdHdl - pointer to command handle.
    \param[in] eType- anyone value from the enum e_LTQ_ATCmd_Type.
    \result IFX_SUCCESS / IFX_FAILURE on success or failure respectively.
*/
 e_IFX_Return LTQ_ATCmd_MandatoryparamCheck(void *pCmdHdl,
                                                  e_LTQ_ATCmd_Type eType);




/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_Parse()                                                */
/* -------------------------------------------------------------------------- */
/*! 
    \brief  api to parse a ATCommand received from application.This will check
            for valid parameters present or not and whether the Cmd is a valid 
            one.returns Invalid CommandType in any errorcase.     
    \param[in] pucBuffer - pointer to buffer received from application.
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned 
                             after malloc in this function.
    \param[in,out] pucLength- pointer which indicates the length of the parsed 
                              buffer if the length received is non-zero the 
                              parsing the buffer starts from pucBuffer+pucLength
    \result value from the enum e_LTQ_ATCmd_Type 
*/
 uchar8 LTQ_ATCmd_Parse(uchar8  *pucBuffer,
                            void **pCmdHdl,
                            uchar8 *pucLength);
#endif //- __LTQ_APP_PARSER_INTF_H__
