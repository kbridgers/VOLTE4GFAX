/*******************************************************************************
 **   FILE NAME    : LTQ_APP_Parser_Intf.c
 **   PROJECT      : COSIC VoIP Software
 **   MODULES      : AT Command Parser
 **   SRC VERSION  : 1.0
 **   DATE         : 10-July-2011
 **   AUTHOR       : Swaroop Sarma(LQIN)
 **   DESCRIPTION  : This  file contains functions implementing the application 
 **                   specific routines for the ATCommand parser module.
 **   COMPILER     : Keil 8051 - uVision V3.62c
 **   REFERENCE    : DECT standards,GAP,CAT-iq 2.0
 **   COPYRIGHT    : Lantiq Deutschland GmbH 2011 � All rights reserved.

 **  Version Control Section  **
 ** $Rev:$
 ** $Author:$
 ** $Date:$

*******************************************************************************/

#include "LTQ_APP_Parser_Intf.h"
#include <string.h>
#include <stdio.h>

/*!< Initialising the AtCommand strings */
 uchar8 aucATCmdArray[LTQ_NO_OF_ATCMD][11]=
                                        {"ATD","ATH","AT+CA","ATA","AT#INIT",\
                                          "AT+VTS","+CDIALING","+CALERTING",\
                                        "+CRING","+CLIP","+CCWA","+CTONE","#SPCM",
																				"#RST","#SAVE","OK","CONNECT","NO CARRIER",\
                                        "+CME ERROR","NO DIALTONE","BUSY","NO ANSWER",\
                                        "AT+COAP","AT+CHLD","AT+CREG","AT+CGMR",\
                                        "AT#DIAG","AT#RAM","AT#BMC","AT#TPC","AT#RFMOD",\
																				"AT#OSCTRIM","AT#FREQ","AT#GFSK","AT#RFPI",\
                                         "AT#TBR06","AT#CIDTMR","AT+CPIN","AT+GCAP","AT#HSIDLE"};
/*!< Initialising Mandatory params of AT Commands*/
  uchar8 aucMandatoryParams[LTQ_NO_OF_ATCMD]=
                                    {
                                     BIT0|BIT1,BIT0,BIT0|BIT1,BIT0|BIT1,0,BIT0|BIT1,\
                                     BIT0|BIT1|BIT2,BIT0|BIT1,BIT0,BIT0|BIT1,BIT0|BIT1,\
                                     BIT0,0,0,0,BIT0,BIT0,BIT0,BIT0|BIT1,BIT0,BIT0,BIT0,\
                                     BIT0|BIT1,BIT0|BIT1,0,0,0,BIT3,0,0,0,0,0,0,0,0,BIT1,\
                                     0,0,0};


 
 /* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_TypeGet()                                 */
/* -------------------------------------------------------------------------- */

/*! \method LTQ_ATCmd_TypeGet
    \brief getcmd api to get the type of command in the ATCommand.     
    \param[in] puCmdHdl - pointer to CommandHdl.
    \result value from the enum e_LTQ_ATCmd_Type 
*/

 uchar8 LTQ_ATCmd_TypeGet(void *pCmdHdl){
  uchar8  *p;
  uchar8 i=0;
  uchar8 ucTempLen;

  p=LTQ_ATCmd_CmdGet(pCmdHdl);
  ucTempLen=strlen(p);
  printf("Length %d ==Command %s\r\n",ucTempLen,p);
  while(i < LTQ_NO_OF_ATCMD){
  //printf("ATCmdArray %d is %s\r\n",i,aucATCmdArray[i]);
    if(!memcmp(p,aucATCmdArray[i],ucTempLen))
      return i;
    i++;
  }
  return LTQ_ATCmd_Invalid;
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_CmdTypeSet()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief setcmd api to set a command in an ATCommand String.     
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned 
                    after malloc.
    \param[in] eType- anyone value from the enum e_LTQ_ATCmd_Type.
    \result IFX_SUCCESS / IFX_FAILURE on success or failure respectively.
*/

 e_IFX_Return LTQ_ATCmd_CmdTypeSet(void **pCmdHdl,e_LTQ_ATCmd_Type eType){
  uchar8 uclength=strlen(aucATCmdArray[eType]);
  uchar8  aucString[11];
	if(eType > LTQ_ATResp_NoAnswer  && eType < LTQ_ATCmd_Invalid){
  	memcpy(aucString,&aucATCmdArray[eType][2],uclength-2);
   	aucString[uclength-2]= 0;
	}else{
	 memcpy(aucString,aucATCmdArray[eType],uclength);	

   aucString[uclength]='\0';
	}
	return LTQ_ATCmd_CmdSet(pCmdHdl,aucString);
}

 /* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_MandatoryparamCheck()                                 */
/* -------------------------------------------------------------------------- */
/*! 
    \brief api to check for mandatory commands in an  ATCommand String.     
    \param[in] pucCmdHdl - pointer to command handle.
    \param[in] eType- anyone value from the enum e_LTQ_ATCmd_Type.
    \result IFX_SUCCESS / IFX_FAILURE on success or failure respectively.
*/
 e_IFX_Return LTQ_ATCmd_MandatoryparamCheck(void *pCmdHdl,
                                                  e_LTQ_ATCmd_Type eType){
  uchar8 ucFieldmap=aucMandatoryParams[eType];
  return LTQ_ATCmd_FieldMapCheck(ucFieldmap,pCmdHdl);
}



/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_Parse()                                                */
/* -------------------------------------------------------------------------- */
/*! 
    \brief  api to parse a ATCommand received from application.This will check
            for valid parameters present or not and whether the Cmd is a valid 
            one.returns Invalid CommandType in any errorcase.     
    \param[in] pucBuffer - pointer to buffer received from application.
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned 
                             after malloc in this function.
    \param[in,out] pucLength- pointer which indicates the length of the parsed 
                              buffer i0f the length received is non-zero the 
                              parsing the buffer starts from pucBuffer+pucLength
    \result value from the enum e_LTQ_ATCmd_Type 
*/
 uchar8 LTQ_ATCmd_Parse(uchar8  *pucBuffer,
                            void **pCmdHdl,
                            uchar8 *pucLength)
{
  if(IFX_SUCCESS==LTQ_ATCmd_GenericParse(pucBuffer,pCmdHdl,pucLength))
  {
    e_LTQ_ATCmd_Type eCmdType=LTQ_ATCmd_TypeGet(*pCmdHdl);
    if((eCmdType != LTQ_ATCmd_Invalid)&&
        (LTQ_ATCmd_MandatoryparamCheck(*pCmdHdl,eCmdType)==IFX_SUCCESS))
    {

      return eCmdType;
    }
    else
    {
      printf("CmdType Invalid/Mandatory Params missing\r\n");
      return LTQ_ATCmd_Invalid;   
    }
  }
  return LTQ_ATCmd_Invalid;
}

