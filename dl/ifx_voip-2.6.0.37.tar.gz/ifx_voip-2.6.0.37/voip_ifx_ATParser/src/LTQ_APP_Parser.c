/*******************************************************************************
 **   FILE NAME    : LTQ_APP_Parser.c
 **   PROJECT      : COSIC VoIP Software
 **   MODULES      : AT Command Parser
 **   SRC VERSION  : 1.0
 **   DATE         : 10-July-2011
 **   AUTHOR       : Swaroop Sarma(LQIN)
 **   DESCRIPTION  : This  file contains functions implementing the parsing  
 **                  routines for the ATCommand parser module.
 **   COMPILER     : Keil 8051 - uVision V3.62c
 **   REFERENCE    : DECT standards,GAP,CAT-iq 2.0
 **   COPYRIGHT    : Lantiq Deutschland GmbH 2011 � All rights reserved.

 **  Version Control Section  **
 ** $Rev:$
 ** $Author:$
 ** $Date:$

*******************************************************************************/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "LTQ_APP_Parser.h"

x_LTQ_ATCmd_V250  vxATCmdFormat={0};
/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_GenericParse()                                                */
/* -------------------------------------------------------------------------- */
/*! 
    \brief  api to parse a ATCommand received from application.     
    \param[in] pucBuffer - pointer to buffer received from application.
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned 
                             after malloc in this function.
    \param[in,out] pucLength- pointer which indicates the length of the parsed 
                              buffer i0f the length received is non-zero the 
                              parsing the buffer starts from pucBuffer+pucLength
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/

 e_IFX_Return LTQ_ATCmd_GenericParse(uchar8  *pucBuffer,
                                    void **pCmdHdl,
                                    uchar8 *pucLength){
	x_LTQ_AT_Parser  *pxTempATParser;		   
	uchar8 i; 
	uchar8 flag=0;
  /*local variable to set the bit map */                                    
	uint32 uiShift=0x01;
  
 //- TODO change the parsing based on termcharacter when transporting throught UART
  /*malloc for Cmd Hdl*/                   
	pxTempATParser = (x_LTQ_AT_Parser  *)malloc(sizeof(x_LTQ_AT_Parser));
  //printf("Get CmdHdl %p\r\n",(uchar8  *)pxTempATParser)
	*pCmdHdl = pxTempATParser;
	memset(pxTempATParser,0,sizeof(x_LTQ_AT_Parser));
#ifdef SPI
  /*
   *if length is non-zero means that we are decoding another cmd from the 
   *same buffer
  */
	if(*pucLength){                    
		*(pucBuffer+*pucLength)='\0';   
		(*pucLength)++;                 
	}
#endif
	if(*pucLength){                    
		*(pucBuffer+*pucLength)='\0';   
		(*pucLength)++;                 
	}
  /* Moving the buffer pointer to desired location based on length received*/
	pucBuffer += *pucLength;            
	pxTempATParser->pucBuff=pucBuffer;
  /*Assigning the pointer to the Cmd in the received in string*/    
	pxTempATParser->pucCmd=pucBuffer;   

  i=0;
  /*check for terminating character*/
	while((*pucBuffer != '\0')/*vxATCmdFormat.ucTermChar*/){
     /*i=0 && value==' ' represents its the first parameter*/
			if((flag>1)&&(i==0)&&(*pucBuffer == ' ')&&(((*(pucBuffer-1)=='O' 
				&& *(pucBuffer-2)=='N'))||((*(pucBuffer-1)=='E' && *(pucBuffer-2)=='M')))){
				pucBuffer++;
				if(*pucBuffer=='\r'){
					*pucBuffer='\0';
				}
				flag++;
				(*pucLength)++;
				continue;
			}else if((*pucBuffer == ' ' && i==0) || (*pucBuffer == ',' && i != 0)){ 
	  /*
     *replacing the the space after command or seperator between parameters, 
     *with \0
     */
      *pucBuffer = '\0';
			pucBuffer++;
     /*shifting left each time when a parameter is found in the command*/
			if(i != 0)
				uiShift = (uiShift<<1); 
      /*storing the pointer of the parameter in the index i of the array of pointers*/           
		  pxTempATParser->aucIndex[i]=pucBuffer;  
		 	pxTempATParser->ucNoOfFields++; 
			if(*pucBuffer=='\r'){
				*pucBuffer='\0';
			}
       /*If the parameter is not empty set the field map*/
       if((*pucBuffer!= ',')&&(*pucBuffer!='\0'))	               
				pxTempATParser->uiFieldMap |= uiShift;
			i++;
		}
#ifndef SPI
    else if(*pucBuffer == ';'){
			*pucBuffer = '\0';
			pucBuffer++;
			(*pucLength)++;
			uiShift=0x01;
			return IFX_SUCCESS;
		}
#endif
		else{
			pucBuffer++;
			flag++;
			if(*pucBuffer=='\r'){
			  *pucBuffer='\0';	
			}
		}
	(*pucLength)++;
	}  /*End of while*/
#ifdef SPI
   /*Making the new line character in buffer to \0*/
	*pucBuffer='\0'; 
	pucBuffer++;
   /*
   *Incrementing the length by 2 because of the \r and \n characters 
   *in the end of command
   */  
	(*pucLength)+=2;
#endif

  printf("PARSER: DECODED LENGTH %d \r\n",*pucLength);

	return IFX_SUCCESS;
}


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_ValueGet()                                             */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to get the value from the Index passed by application.     
    \param[in] pucCmdHdl - pointer to Command Handle
    \param[in] ucIndex- Index of the param in an AT Command.
    \result return a pointer to the value or null on success or failure 
            respectively
*/

 uchar8  *LTQ_ATCmd_ValueGet(uchar8 ucIndex,void *pCmdHdl){
	x_LTQ_AT_Parser  *pxTempATParser = (x_LTQ_AT_Parser  *)pCmdHdl;

	if(ucIndex > pxTempATParser->ucNoOfFields)
		return NULL;
	if(*pxTempATParser->aucIndex[ucIndex-1])
		return pxTempATParser->aucIndex[ucIndex-1];

	return NULL;
}
/* -------------------------------------------------------------------------- */
/* function: LTQ_ConvertTouchar8()                                             */
/* -------------------------------------------------------------------------- */
e_IFX_Return LTQ_ConvertToByte(uchar8  *pucString,uchar8 *pucValue){
  uchar8 ucLength= strlen(pucString);
  uchar8 i;
  uint16 uiValue;

  if(ucLength>3 ||ucLength==0)
    return IFX_FAILURE;
  uiValue = 0;
  for(i=0;i<ucLength;i++){
		//if(!(pucString[i]>='0'&& pucString[i]<='9'))
			//return IFX_FAILURE;
    uiValue = ((uiValue)*10)+pucString[i]-'0';
	}
  if(uiValue<=255){
    *pucValue = uiValue;
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_uchar8ValueGet()                                             */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to get the value from the Index passed by application.     
    \param[in] pucCmdHdl - pointer to Command Handle
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[out] pucValue- Pointer to the value to be filled in
    \result return a IFX_SUCCESS or IFX_FAILURE in case of success/failure 
*/

 e_IFX_Return LTQ_ATCmd_ByteValueGet(uchar8 ucIndex,void *pCmdHdl,
                                        uchar8 *pucValue){
	x_LTQ_AT_Parser  *pxTempATParser = (x_LTQ_AT_Parser  *)pCmdHdl;
	if(ucIndex > pxTempATParser->ucNoOfFields)
		return IFX_FAILURE;
	if(*pxTempATParser->aucIndex[ucIndex-1]){
    return LTQ_ConvertToByte(pxTempATParser->aucIndex[ucIndex-1],pucValue);
  }

	return IFX_FAILURE;
}


/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_ValueSet()                                             */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the string for an Index passed by application.Should be 
            called after setting the Command.                 
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[in] pucCmdHdl - pointer to the callHdl.
    \param[in] pucString - pointer to the string value that need to be set.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_ValueSet(uchar8 ucIndex, void *pCmdHdl,
                                        uchar8  *pucString){
	uchar8 i=ucIndex;
	uchar8 ucLength=strlen(pucString);
	char cTempLen=ucLength;
	x_LTQ_AT_Parser  *pxTempATParser = (x_LTQ_AT_Parser  *)pCmdHdl;


  //printf("ValueSet %s\r\n",pucString);
  if(!ucLength)
    return IFX_SUCCESS;
	if(*pxTempATParser->aucIndex[ucIndex-1] != '\0'){
	  cTempLen -= pxTempATParser->aucIndex[ucIndex]-
                pxTempATParser->aucIndex[ucIndex-1]-1;
	}
	 if(ucIndex > pxTempATParser->ucNoOfFields){
	 	pxTempATParser->ucNoOfFields=ucIndex;
	 }
	while (i<LTQ_ATCMD_MAX_INDEX){
	  pxTempATParser->aucIndex[i]=pxTempATParser->aucIndex[i]+cTempLen;
		i++;
	}
	if((pxTempATParser->aucIndex[LTQ_ATCMD_MAX_INDEX-1]-pxTempATParser->aucIndex[0]+
			strlen(pxTempATParser->aucIndex[LTQ_ATCMD_MAX_INDEX-1])+1)>LTQ_ATCMD_MAX_BUFF)
		return IFX_FAILURE;
	if(cTempLen>0)
		memmove(pxTempATParser->aucIndex[ucIndex-1]+cTempLen,
            pxTempATParser->aucIndex[ucIndex-1],
					  pxTempATParser->aucIndex[LTQ_ATCMD_MAX_INDEX-1]-
            pxTempATParser->aucIndex[ucIndex-1]+
						strlen(pxTempATParser->aucIndex[LTQ_ATCMD_MAX_INDEX-1]));
	else
		memmove(pxTempATParser->aucIndex[ucIndex]+cTempLen,
            pxTempATParser->aucIndex[ucIndex],
					  pxTempATParser->aucIndex[LTQ_ATCMD_MAX_INDEX-1]-
            pxTempATParser->aucIndex[ucIndex]+
					  strlen(pxTempATParser->aucIndex[LTQ_ATCMD_MAX_INDEX-1]));
	memcpy(pxTempATParser->aucIndex[ucIndex-1],pucString,ucLength);
	*(pxTempATParser->aucIndex[ucIndex-1]+ucLength)=',';

	return IFX_SUCCESS;
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_IntValueSet()                                          */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the Integer value for an Index passed by application.     
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[in] pucCmdHdl - pointer to the commandHdl.
    \param[in] uiValue - Integer value that need to be set.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_IntValueSet(uchar8 ucIndex, void *pCmdHdl,
                                          uint16 iValue){
	uchar8  ucString[6]={0};

	sprintf(ucString,"%d",iValue);

	return LTQ_ATCmd_ValueSet(ucIndex,pCmdHdl,ucString);
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_uchar8ValueSet()                                         */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the uchar8 value for an Index passed by application.     
    \param[in] ucIndex- Index of the param in an AT Command.
    \param[in] pucCmdHdl - pointer to the commandHdl.
    \param[in] ucValue - uchar8 value that need to be set.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_ByteValueSet(uchar8 ucIndex, void *pCmdHdl,
                                            uchar8 ucValue){
	uchar8  ucString[4]={0};

	sprintf(ucString,"%d",ucValue);

	return LTQ_ATCmd_ValueSet(ucIndex,pCmdHdl,ucString);
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_CmdGet()                                                */
/* -------------------------------------------------------------------------- */
/*! 
    \brief  api to get the command from the Handle passed by application.     
    \param[in] pucCmdHdl - pointer to CommandHdl.
    \result return a pointer to the Command value or null on success or failure 
            respectively
*/

 uchar8  *LTQ_ATCmd_CmdGet(void *pCmdHdl){
	x_LTQ_AT_Parser  *pxTempATParser = (x_LTQ_AT_Parser  *)pCmdHdl;


	if(*pxTempATParser->pucCmd){
		return pxTempATParser->pucCmd;
	}

	return NULL;
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_CmdSet()                                                */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to set the command and allocate the buffer for Setting an 
            AT Command.Should be set only once.      
    \param[in,out] pucCmdHdl - pointer to pointer which will be assigned after malloc 
                  in this function.
    \param[in] pucString - pointer to the string/Command.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_CmdSet(void **pCmdHdl,uchar8  *pucString){
	uchar8 ucLength=strlen(pucString);
	uchar8 i=0;
	x_LTQ_AT_Parser  *pxTempATParser1;
 
	pxTempATParser1 = (x_LTQ_AT_Parser  *)malloc(sizeof(x_LTQ_AT_Parser));
	memset(pxTempATParser1,0,sizeof(x_LTQ_AT_Parser));
  //printf("Set CmdHdl %p\r\n",(uchar8  *)pxTempATParser1)
	pxTempATParser1->pucBuff = (uchar8  *)malloc(LTQ_ATCMD_MAX_BUFF);
  //printf("Buff  %p\r\n",pxTempATParser1->pucBuff)
	pxTempATParser1->isAlloc=1;
	*pCmdHdl = pxTempATParser1;
	memset(pxTempATParser1->pucBuff,0,LTQ_ATCMD_MAX_BUFF);
	memcpy(pxTempATParser1->pucBuff,pucString,ucLength);
  printf("CmdSet %s\r\n",pxTempATParser1->pucBuff);
	memcpy(pxTempATParser1->pucBuff+ucLength," ",1);
		for(i=0;i<LTQ_ATCMD_MAX_INDEX;i++)
			pxTempATParser1->aucIndex[i]=pxTempATParser1->pucBuff+ucLength+1+i;

	return IFX_SUCCESS;
}

 /* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_Freehandle()                                                */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to free the CommandHandle.The buffer will also be frred if 
             the handle belongs to an set command.     
    \param[in] pucCmdhdl - pointer to the CommandHandle.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_FreeHandle(void  *pPointer){
  x_LTQ_AT_Parser  *pxTempATParser = (x_LTQ_AT_Parser  *)pPointer;

	if(pxTempATParser->isAlloc){
		free(pxTempATParser->pucBuff);
    //free(pxTempATParser->pucBuff);
    pxTempATParser->pucBuff = NULL;
	}
	free(pPointer);
  //free(pucPointer);
  //pucPointer = NULL;
	
	return IFX_SUCCESS;
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_BufferGet()                                                */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to get the buffer after preparing the ATCommand for sending.
            Should be called after setting the individual params.     
    \param[in] pucCmdHdl - pointer to CommandHdl.
    \param[out] pucBuff- pointer to AT Command buffer.
    \result return the length of the buffer.
*/
 uchar8 LTQ_ATCmd_BufferGet(void *pCmdHdl,uchar8  **pucBuff){
	x_LTQ_AT_Parser  *pxTempATParser = (x_LTQ_AT_Parser  *)pCmdHdl;
	uchar8 i=0;
  uchar8 ucSize;

	while(i<pxTempATParser->ucNoOfFields){
		if(*(pxTempATParser->aucIndex[i])=='\0'){ 
			*(pxTempATParser->aucIndex[i])=',';
		}

		i++;
	}
	*pucBuff=pxTempATParser->pucBuff;
  //printf("Buff  %p\r\n",(uchar8  *)pxTempATParser->pucBuff)
  printf("BUFFERGET %s\r\n",pxTempATParser->pucBuff);
	ucSize=pxTempATParser->aucIndex[i-1]-pxTempATParser->pucBuff+
          strlen(pxTempATParser->aucIndex[i-1])-1;
  printf("BUFFER GET: ENCODED LENGTH %d \r\n",ucSize);
  memset(&pxTempATParser->pucBuff[ucSize],0,1);
	
	return ucSize;
}


 /* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_FieldIdPresenceCheck()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to check presence of a field in an ATCommand..     
    \param[in] ucIndex - Index of the field.
    \param[in] pucCmdHdl - pointer to the CommandHandle.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_FieldPresenceCheck(uchar8 ucIndex,void *pCmdHdl){
  x_LTQ_AT_Parser  *pxATParser = (x_LTQ_AT_Parser  *)pCmdHdl;

  if((ucIndex > pxATParser->ucNoOfFields)&&(*pxATParser->aucIndex[ucIndex-1]))
    return IFX_SUCCESS;

  return IFX_FAILURE;
}


 /* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_FieldIdMapCheck()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to check for fieldmap of mandatory fields in an ATCommand.     
    \param[in] ucFieldMap - FieldMap that need to be checked.
    \param[in] pucCmdHdl - pointer to the CommandHandle.
    \result IFX_SUCCESS IFX_FAILURE on success or failure respectively
*/
 e_IFX_Return LTQ_ATCmd_FieldMapCheck(uchar8 ucFieldMap,void *pCmdHdl){
  x_LTQ_AT_Parser  *pxATParser = (x_LTQ_AT_Parser  *)pCmdHdl;

  printf("FIELDMAP: %lx \r\n",pxATParser->uiFieldMap);
  

  if((pxATParser->uiFieldMap&ucFieldMap)==ucFieldMap)
    return IFX_SUCCESS;

  return IFX_FAILURE;
}

/* -------------------------------------------------------------------------- */
/* function: LTQ_ATCmd_MaxIndexGet()                                 */
/* -------------------------------------------------------------------------- */

/*! 
    \brief  api to fetch the Max Index in an ATCommand.     
    \param[in] pucCmdHdl - pointer to the CommandHandle.
    \result returns the Max Index Value.
*/
 uchar8 LTQ_ATCmd_MaxIndexGet(void *pCmdHdl){
   x_LTQ_AT_Parser  *pxATParser = (x_LTQ_AT_Parser  *)pCmdHdl;
   return pxATParser->ucNoOfFields;
}

