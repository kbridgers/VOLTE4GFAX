#ifndef __IFX_TAPI_IF_H__
#define __IFX_TAPI_IF_H__
#define IFX_MMGR_MAX_MSG_LENGTH 3
#define IFX_MMGR_FREQUENCY_NON 0
#define IFX_MMGR_FREQUENCY_1 1
#define IFX_MMGR_FREQUENCY_2 2
#define IFX_MMGR_FREQUENCY_3 4
#define IFX_MMGR_FREQUENCY_4 8
#define IFX_MMGR_MODULATION 1<<5
#define IFX_MMGR_TONE_INDEX_START 34
#define IFX_MMGR_MAX_CADENCE_DURATION 32000
e_IFX_MMGR_Return IFX_MMGR_TAPI_Duslic_Init(int32 iDuslicFd,x_IFX_MMGR_FxoDevparam *pxDevParam);

e_IFX_MMGR_Return IFX_MMGR_TAPI_ChannelInit(int32 iChFd,
                                            int32 iPcmFd,
											e_IFX_MMGR_ResourceType eChType,
											uchar8 *pucFw,int32 iFwSize,
											uchar8* pucCoefficient,
											int32 iCoefficientSize);
e_IFX_MMGR_Return IFX_MMGR_TAPI_ConfigurePcmIf(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectECConfigure(int32 iFd,boolean bOn);

e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeed(int32 iFd);

e_IFX_MMGR_Return IFX_MMGR_TAPI_StartCptd(IN int32 iChFd,
							 IN uchar8 ucIndex
							 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopCptd(IN int32 iChFd
							 );

e_IFX_MMGR_Return IFX_MMGR_TAPI_PlayTone(IN int32 iChFd,
							 IN uchar8 ucIndex
							 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopTone(
										IN int32 iChFd
										 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_PlayToneNetwork(IN int32 iChFd,
							 IN uchar8 ucIndex
							 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopToneNetwork(
										IN int32 iChFd
										 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetRingCadence(
										 IN int32 iChFd,
										 IN x_IFX_MMGR_Tone *pxTone
										 );
int32 IFX_MMGR_TAPI_RingStart(
								 int32 iChFd,
								 x_IFX_MMGR_CidParams *pxCidParams
								 );

e_IFX_MMGR_Return IFX_MMGR_TAPI_StartCidRx(IN int32 iChFd,
                                           IN e_IFX_MMGR_CidRxMode eCidRxMode);

e_IFX_MMGR_Return IFX_MMGR_TAPI_StopCidRx(IN int32 iChFd
							              );
int32 IFX_MMGR_TAPI_StopRinging(IN int32 iChFd);

int32 IFX_MMGR_TAPI_AddTone(int32 iChannelFd,x_IFX_MMGR_Tone *pxTone);
e_IFX_MMGR_Return IFX_MMGR_TAPI_PcmChannelConfig(int32 iPcmFd,int32 iFxoFd,boolean bAct);
e_IFX_MMGR_Return IFX_MMGR_TAPI_HookTimeUpdate(
												int32 iChFd,
												x_IFX_MMGR_CountrySettingsParams *pxParams
												);
e_IFX_MMGR_Return IFX_MMGR_TAPI_CidConfigure(
											 int32 iChFd,
											 e_IFX_MMGR_CidStd eCidType
											 );
int32 IFX_MMGR_TAPI_AddDataChannelToAnalog(int32 iFd,uint16 nAnalogChNum);
int32 IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(int32 iFd,uint16 nAnalogChNum);
int32 IFX_MMGR_TAPI_AddDataChannelToPcm(int32 iFd,uint16 nPcmChNum);
int32 IFX_MMGR_TAPI_RemoveDataChannelFromPcm(int32 iFd,uint16 nPcmChNum);
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectPlayTone(IN int32 iChFd,
															 IN uchar8 ucIndex
															 							 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectStopTone(
																		IN int32 iChFd
																												 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_CidSend(
																 int32 iChFd,
																 x_IFX_MMGR_CidParams *pxCidParams
																		 );
e_IFX_MMGR_Return IFX_MMGR_TAPI_StartEncoding(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopEncoding(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopDecoding(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_StartDecoding(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_ConfigureVad(int32 iFd,boolean bOn);
e_IFX_MMGR_Return IFX_MMGR_TAPI_JitterBufferConfig(
																									int32 iFd,
																									x_IFX_MMGR_JitterBuffer_Conf *pxJBConf);
e_IFX_MMGR_Return IFX_MMGR_TAPI_LecConfigure(
																				int32 iFd,
																				e_IFX_MMGR_LecType eLecType ,
  																			uchar8 ucTailLen,
																				boolean bNlp);
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetEncType(int32 iFd,x_IFX_MMGR_CodecInfo *pxCodec);
int32 IFX_MMGR_TAPI_AddDataChannelToAnalog(int32 iFd,uint16 nAnalogChNum);
int32 IFX_MMGR_TAPI_AddAnalogToAnalog(int32 iFd,uint16 unAnalogChNum);
int32 IFX_MMGR_TAPI_RemoveAnalogFromAnalog(int32 iFd,uint16 unAnalogChNum);
int32 IFX_MMGR_TAPI_AddPcmToAnalog(int32 iFd,uint16 unAnalogChNum);
int32 IFX_MMGR_TAPI_AddPcmToDect(int32 iFd,uint16 unDectChNum);
int32 IFX_MMGR_TAPI_RemovePcmFromAnalog(int32 iFd,uint16 unAnalogChNum);
int32 IFX_MMGR_TAPI_RemovePcmFromDect(int32 iFd,uint16 unDectChNum);
int32 IFX_MMGR_TAPI_AddDataChannelToPCM(int32 iFd,uint16 nPCMChNum);
int32 IFX_MMGR_TAPI_RemoveDataChannelFromPCM(int32 iFd,uint16 nPCMChNum);
e_IFX_MMGR_Return IFX_MMGR_TAPI_HookTimeUpdate(int32 iChFd,x_IFX_MMGR_CountrySettingsParams *pxParams);
e_IFX_MMGR_Return IFX_MMGR_TAPI_CidConfigure(int32 iChFd,e_IFX_MMGR_CidStd eCidType);
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetHookMode(int32 iChFd,uint32 uiHookMode);
e_IFX_MMGR_Return IFX_MMGR_TAPI_PayLoadTblSet(int32 iChFd,
																			  x_IFX_MMGR_CodecList *pxCodecList
																															  );
e_IFX_MMGR_Return IFX_MMGR_TAPI_RtpConfig(
																		  IN int32 iChFd,
																		  IN uint16 unSeqNo,
																		  IN int32 iSSRC,
																		  IN x_IFX_MMGR_TelephonyEvent_Info *pxTelEvent
																		  );
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectChCfg(
																      IN int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectActivate(
																      IN int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectEncSet(
																      IN int32 iFd,
																												  x_IFX_MMGR_CodecInfo *pxCodec);
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectDeActivate(
																      IN int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_AddDectToDect(
																      IN int32 iFd,
																												  IN uint16 unChannelNum);
e_IFX_MMGR_Return IFX_MMGR_TAPI_RemoveDectFromDect(
																      IN int32 iFd,
																												  IN uint16 unChannelNum);
int32 IFX_MMGR_TAPI_AddDataChannelToDect(int32 iFd,uint16 nDectChNum);
int32 IFX_MMGR_TAPI_RemoveDataChannelFromDect(int32 iFd,uint16 nDectChNum);
int32 IFX_MMGR_TAPI_AddDectToAnalog(int32 iFd,uint16 unAnalogChNum);
int32 IFX_MMGR_TAPI_RemoveDectFromAnalog(int32 iFd,uint16 unAnalogChNum);
e_IFX_MMGR_Return IFX_MMGR_TAPI_KpiCfg(int32 iFd,int32 iKpiChNum);
e_IFX_MMGR_Return IFX_MMGR_TAPI_EnableMftd(int32 iFd,uint16 unChannelNum, boolean bEnable);
e_IFX_MMGR_Return IFX_MMGR_TAPI_FSKDataRcv(
																			int32 iFd,
																			uchar8* pucData,
																			int32 *piDataSize
																					);
e_IFX_MMGR_Return IFX_MMGR_TAPI_GenerateRFC2833Packet(int32 iFd, uchar8 ucDigit);
 e_IFX_MMGR_Return IFX_MMGR_TAPI_GR909TestStart(int32 iFd,x_IFX_MMGR_GR909_Param *pxParam);

e_IFX_MMGR_Return IFX_MMGR_TAPI_SetPcmMaster( int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetGPIODir(int32 iFd);
#ifdef TEREDIAN
e_IFX_MMGR_Return IFX_MMGR_Teridian_CfgPCMInterface(uint32 uiFxoDevFd);
#endif
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeedStandBy(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeedActive(int32 iFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_GetGR909Result(int32 iFd, x_IFX_MMGR_GR909_Result *pxResult);
int32 IFX_MMGR_TAPI_RingStop(IN int32 iChFd);
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeedDisabled(int32 iFd);

#endif /* __IFX_TAPI_IF_H__ */
