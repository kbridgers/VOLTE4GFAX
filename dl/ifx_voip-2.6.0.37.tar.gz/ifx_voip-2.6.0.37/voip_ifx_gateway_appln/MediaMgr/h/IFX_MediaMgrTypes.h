#ifndef __IFX_MMGR_TYPES_H__
#define __IFX_MMGR_TYPES_H__
/*!
	\brief Public 
*/
#define	PUBLIC
/*!
	\brief Extern 
*/
#define	EXTERN			extern
/*!
	\brief Static 
*/
#define	STATIC			static

/*!
	\brief Print 
*/
#define	PRINT			printf

/*!
	\brief IN 
*/
#define	IN
/*!
	\brief OUT 
*/
#define	OUT
/*!
	\brief IN_OUT 
*/
#define	IN_OUT

/*!
	\brief nullptr 
*/
#define nullptr(Type)	(Type *)NULL

#define IFX_MMGR_TRUE 1
#define IFX_MMGR_FALSE 0

#ifndef char8

/*!
	\brief char8
*/
typedef char               char8;
/*!
	\brief uchar8 
*/
typedef unsigned char      uchar8;
/*!
	\brief int8  
*/
typedef char               int8;
/*!
	\brief uint8 
*/
typedef unsigned char      uint8;
/*!
	\brief int16 
*/
typedef short int	         int16;
/*!
	\brief uint16 
*/
typedef unsigned short int	uint16;
/*!
	\brief int32 
*/
typedef int                int32;
/*!
	\brief uint32 
*/
typedef unsigned int	      uint32;
/*!
	\brief int64 
*/
typedef long long int      int64;
/*!
	\brief uint64 
*/
typedef unsigned long long int	uint64;
/*!
	\brief float32 
*/
typedef float              float32;
/*!
	\brief float64 
*/
typedef double             float64;
/*!
	\brief double32 
*/
typedef float              double32;
/*!
	\brief double64  
*/
typedef double             double64;
/*!
	\brief long32 
*/
typedef long               long32;
/*!
	\brief ulong32 
*/
typedef unsigned long      ulong32;
/*!
	\brief bool 
*/
typedef char               bool;
/*!
  \brief boolean
*/
typedef int32               boolean;
#endif
#endif
