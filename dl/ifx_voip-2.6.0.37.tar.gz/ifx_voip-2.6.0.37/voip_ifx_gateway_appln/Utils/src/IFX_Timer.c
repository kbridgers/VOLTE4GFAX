/**************************************************************************
 **   SRC_FILE          : 
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          : 
 **   SRC VERSION       : v0.1
 **   DATE                  : 
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
 *************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "ifx_ipc.h"

#include "IFX_Config.h"
# include "IFX_TLIB_Timlib.h"
# include "IFX_TimerIf.h"
# include "IFX_Timer.h"
# include "IFX_MediaMgrIf.h"
# include "IFX_MsgRtrIf.h"

# define TPrintf printf

/*********************** The data structure instantiation for timer agent***********************/

x_IFX_TimerInfo vaxTimerInfo[IFX_MAX_TIMERS];

uint32 vuiTimerFd;
extern uint32 vuiTimerLibFd;
char8 vszTimFifoName[40];
uchar8 vucTimModId=0;

e_IFX_Return IFX_TIM_TimerFdUnblocked(IN int32 iTimerFd)
{
 //printf("<ID2904>TimerFd unblocked\n");
 IFX_TLIB_CurrTimerExpiry(0);
 return IFX_SUCCESS;
}
/***************************** The Timer agent functions  **********************/
/*
	This Function does folowing actions
	-Initializes the TLIB timer library
	-Makes FIFO.
	-Opens FIFO in Read-Write mode
	-returns the Fd.
*/

e_IFX_Return IFX_TIM_Init(
	             IN char8* szFifoName,
	             OUT uint32* puiFifoFd )
{
	//e_IFX_Return eReturn=IFX_SUCCESS;
	//TPrintf("\n[Timer]<%s>:Entry %s\n",__FUNCTION__,__FUNCTION__);	
	
	/*Call MakeFifo*/	
	if(IFX_SUCCESS != IFX_OS_CreateFifo((uchar8 *)szFifoName))	
		return IFX_FAILURE;
	/*Call OpenFifo in Read-Write Mode*/
	if((vuiTimerFd = IFX_OS_OpenFifo((uchar8 *)szFifoName,O_RDWR|O_NONBLOCK)) < 0 )	
   {
  		//TPrintf("\n[Timer]<%s>::OpenFifo failed\n",__FUNCTION__);	
		return IFX_FAILURE;
   }
	 *puiFifoFd = vuiTimerFd;

	/* initialize the timers */
	if (IFX_TLIB_TimersInit(IFX_MAX_TIMERS,IFX_TLIB_NOTIFY_VIA_FD)== IFX_TLIB_SUCCESS)
	{	
	  x_IFX_MSGRTR_FdInfo  xFdInfo;
	  uchar8	ucNum =1;

		xFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;
		xFdInfo.uiFd = vuiTimerLibFd;
		if (IFX_MSGRTR_FdCallBackRegister(&xFdInfo, ucNum,IFX_TIM_TimerFdUnblocked) 
									                    != IFX_SUCCESS )
		{
		  return IFX_FAILURE;
		}
		//printf("<ID2904>CMGR: After TimerInit fd = %d\n",vuiTimerLibFd);
		return IFX_SUCCESS;
	}
	//printf("<ID2904>CMGR: Timer Init Failed\n");	
	return IFX_FAILURE;
}

/*
This function does following actions
-Remove the timer fifo
-Unregisterwith timer library
*/
void IFX_TIM_Shut()
{
	IFX_OS_RemoveFifo(vszTimFifoName,vuiTimerFd);
	return;
}

/*
This function would be registered with the timer library and 
would write in to the Timer FIFO.
*/
void IFX_TIM_TimeoutHandler(IN x_IFX_TimerInfo *pxTimerInfo)
{
	x_IFX_TimerInfo xTimerInfo;
	int32 iSz;
	
	/*Pick up the Corresponnding TimerInfo and send it to FIFO*/
	memcpy(&xTimerInfo,pxTimerInfo,sizeof(x_IFX_TimerInfo));
	
	//TPrintf("\n[Timer]<%s>:Entry %s\n",__FUNCTION__,__FUNCTION__);	
	/* Write the message to the TIMER FIFO */

	iSz = IFX_OS_WriteFifo(vuiTimerFd,&xTimerInfo,sizeof(x_IFX_TimerInfo)); 
	if(iSz != sizeof(x_IFX_TimerInfo))
	{	
		//TPrintf("\n[Timer]<%s>:FIFO Write failed\n",__FUNCTION__);	
		/*Major problem*/
		return;
	}
	/*Memset The corresponding timer info.*/
	memset(pxTimerInfo,0,sizeof(x_IFX_TimerInfo));
	return;
}

/*
This function would be calld when any one module starts timer. 
 -Populates the xTimerInfo
 -Searches for the free node in the array and attaches it in the list.
 */
e_IFX_Return IFX_TIM_TimerStart(
			  IN uint32 uiTimeOut,
			  IN void* pvPrivateData,
			  IN uint16 unPrivateDataLen,
			  IN pfn_IFX_TIM_TimerCallBack pfnTimerCallBack,
			  OUT uint32* puiTimerId
			 )

{
	e_IFX_Return eReturn=IFX_SUCCESS;
	int32 iRetVal,iCnt;
	uint16 *punTimerId;
	x_IFX_TimerInfo * pxTimerInfo;
	/*Check on Input parameters*/
	
	//TPrintf("\n[Timer]<%s>:Entry %s\n",__FUNCTION__,__FUNCTION__);	
	if((!pfnTimerCallBack) || (!uiTimeOut))
	{
		//TPrintf("\n[Timer]<%s>Null pointer\n",__FUNCTION__);
		/* error handling */
		return IFX_FAILURE;
	}
	
	/* get the free node */
	for(iCnt=0; iCnt<IFX_MAX_TIMERS; iCnt++)
	{
		if (0 == vaxTimerInfo[iCnt].unTimerId )
		{
			break;
		}
	}
	if (iCnt == IFX_MAX_TIMERS)
	{
		/* need to increase the number of timers */      
		return IFX_FAILURE;
	}
	//TPrintf("\n[Timer]<%s>:Empty slot found \n",__FUNCTION__);	
	
	pxTimerInfo = &vaxTimerInfo[iCnt];

	memset(pxTimerInfo,0,sizeof(x_IFX_TimerInfo));
	
	/*Populate the TimerInfo*/
	pxTimerInfo->pfnTimerCallBack = pfnTimerCallBack;
	punTimerId = &(pxTimerInfo->unTimerId);
	pxTimerInfo->uiTimerId = (uint32)pxTimerInfo; 
	
	if(!pvPrivateData)
	{
		/*Private data passed as Null pointer*/
		pxTimerInfo->unPrivateDataLen = 0; 
		pxTimerInfo->pvPrivateData = pvPrivateData;		
	}
	else if(0 == unPrivateDataLen)
	{
		/*Save the pointer*/
		pxTimerInfo->unPrivateDataLen = unPrivateDataLen; 
		pxTimerInfo->pvPrivateData = pvPrivateData;	
	}
	else
	{
		/*Malloc the pointer and save the data*/
		pxTimerInfo->pvPrivateData = (void *)malloc(unPrivateDataLen); 
		if (pxTimerInfo->pvPrivateData == NULL)
			return IFX_FAILURE;
		pxTimerInfo->unPrivateDataLen = unPrivateDataLen; 
		memcpy(pxTimerInfo->pvPrivateData,pvPrivateData,unPrivateDataLen);
	}

	/*Convert Tmeout vale in to Microseconds.*/
	uiTimeOut *=1000;	
	
	/* start the timer */
	iRetVal = IFX_TLIB_StartTimer(punTimerId,uiTimeOut, 0,
                                 (void*) IFX_TIM_TimeoutHandler,
                                 pxTimerInfo);
	
	//TPrintf("\n[Timer]<%s>:Timer value (usec) = %d\n",__FUNCTION__,uiTimeOut);	
	if(IFX_TLIB_FAIL == iRetVal)
	{
		/* error handling */
		return IFX_FAILURE;
	}
	
	if(pxTimerInfo->unTimerId == 0)
	{
		//TPrintf("\n[Timer]<%s>:Timer Id =0\n",__FUNCTION__);	
	}				
	
	//TPrintf("\n[Timer]<%s>:Timer Started TID=%d\n",__FUNCTION__,pxTimerInfo->unTimerId);	
	
	if(puiTimerId)
		*puiTimerId = (uint32)(pxTimerInfo->unTimerId);	
	return eReturn;
}



/*
This function would be invoked when the timer is required to be stopped  
*/
e_IFX_Return IFX_TIM_TimerStop(IN uint32 uiTimerId )
{
	int32 iRetVal,iCnt;
	x_IFX_TimerInfo *pxTimerInfo=(x_IFX_TimerInfo*)uiTimerId;
	//TPrintf("\n[Timer]<%s>:Entry %s\n",__FUNCTION__,__FUNCTION__);	
	//TPrintf("\n[Timer]<%s>:Stop Timer Id %d\n",__FUNCTION__,uiTimerId);	
	/* get the timer node */
	for(iCnt=0; iCnt<IFX_MAX_TIMERS; iCnt++)
	{
		if (uiTimerId ==(uint32)vaxTimerInfo[iCnt].unTimerId) 
		{
			break;
		}
	}
	if (iCnt == IFX_MAX_TIMERS)
	{
		/* Node not found */      
		return IFX_FAILURE;
	}
	pxTimerInfo = &vaxTimerInfo[iCnt];
	if (!pxTimerInfo->unTimerId)
	{
		/* Node already cleared */      
		return IFX_FAILURE;
	}
	//TPrintf("\n[Timer]<%s>:Node found \n",__FUNCTION__);	

	/*Stop the Timer*/
	iRetVal = IFX_TLIB_StopTimer(pxTimerInfo->unTimerId);

	if(iRetVal < 0)
	{
		/* ideally this should not fail, but if it fails it is still OK */
		return IFX_FAILURE;
	}
	
	/*Free the pointer if allocated*/	
	if(pxTimerInfo->unPrivateDataLen)
		if(pxTimerInfo->pvPrivateData)	
			free(pxTimerInfo->pvPrivateData);	

	/*Memset the data*/	
	memset(pxTimerInfo,0,sizeof(x_IFX_TimerInfo));

	return IFX_SUCCESS;
}

/*
 This function is called  by message router.when Read Fd on Timer FIFO unblocks. 
*/
e_IFX_Return IFX_TIM_TimerMsgReceived(IN int32 iTimFd)
{
	x_IFX_TimerInfo xTimerInfo;	
	e_IFX_Return eRetVal = IFX_SUCCESS;
	int32 iSz;
	
	//TPrintf("\n[Timer]<%s>:Entry %s\n",__FUNCTION__,__FUNCTION__);	
	/* Drain out the FIFO and copy the data in xTimerInfo*/	
	do
	{				
		iSz = IFX_OS_ReadFifo(vuiTimerFd,&xTimerInfo,sizeof(x_IFX_TimerInfo));	
		if(iSz == sizeof(x_IFX_TimerInfo))
		{
			//TPrintf("\n[Timer]<%s>:Invoking Callback\n",__FUNCTION__);	
			/*Invoke the Function pointer*/
			xTimerInfo.pfnTimerCallBack(
						(uint32)xTimerInfo.unTimerId,
						xTimerInfo.pvPrivateData
						);
			/*Free the data if allocated*/
			if(xTimerInfo.unPrivateDataLen)
				if(xTimerInfo.pvPrivateData)	
					free(xTimerInfo.pvPrivateData);	
		}
		else 
		{			
			//TPrintf("\n[Timer]<%s>:Timer FIFO Drained out\n",__FUNCTION__);	
			break;		
		}
	}while(1);				
	return eRetVal;
}








