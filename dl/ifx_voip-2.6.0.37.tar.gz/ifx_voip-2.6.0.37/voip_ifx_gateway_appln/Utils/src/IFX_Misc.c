/**************************************************************************
 **   SRC_FILE          :
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          :
 **   SRC VERSION       : v0.1
 **   DATE                  :
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   :
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#define _XOPEN_SOURCE
#include <time.h>

#include "ifx_common_defs.h"
#include "ifx_debug.h"
# include "IFX_Config.h"
# include "IFX_Misc.h"

/* External functions -> Is in time.h but still shows warning */
extern char *strptime(const char *s, const char *format, struct tm *tm);
/*********************************************************************************
   Name :IFX_GetDateTime
*  Description   :function gets system time date
*  Invoked Fns   :
*  Input Values  :character array
*  Output Values :character array with system date and time
*  Return Value  :void
*******************************************************************************/
PUBLIC e_IFX_Return IFX_GetDateTime(char8 *acDate,char8 *acTime)
{
   struct tm *ptr;
   time_t t;
   t = time(NULL);
   ptr = localtime(&t);
	 if (ptr){
   	strftime(acDate ,19 ,"%Y-%m-%d",ptr);		
   	//strftime(acDate ,19 ,"%D",ptr);
   	strftime(acTime ,19 ,"%H:%M:%S",ptr);
   	//strftime(acTime ,19 ,"%r",ptr);
	 }else{
   	return IFX_FAILURE;
	 }
   return IFX_SUCCESS;
}

/*********************************************************************************
   Name          :IFX_CompareDateTime
*  Description   : Compares and time date
*  Invoked Fns   :
*  Input Values  :The character arrays representing dates and time of events
*  Output Values :
*  Return Value  :intrger 1 or 2 whichever is EARLIER event. 
*******************************************************************************/
PUBLIC int32 IFX_CompareDateTime(char8 *acTimeOfEvent1,char8 *acTimeOfEvent2)
{

	struct tm t1,t2;

	memset (&t1,0,sizeof(struct tm));
	memset (&t2,0,sizeof(struct tm));

	if(strptime(acTimeOfEvent1,"%Y-%m-%d %H:%M:%S",&t1)==0)
		return IFX_FAILURE;
	if(strptime(acTimeOfEvent2,"%Y-%m-%d %H:%M:%S",&t2)==0)
		return IFX_FAILURE;
	
	if(t1.tm_year != t2.tm_year)
	{
		return (t1.tm_year > t2.tm_year ?1:2);
	}
	
	if(t1.tm_mon != t2.tm_mon)
	{
		return (t1.tm_mon > t2.tm_mon ?1:2);
	}
	
	if(t1.tm_mday != t2.tm_mday)
	{
		return (t1.tm_mday > t2.tm_mday ?1:2);
	}
	if(t1.tm_hour != t2.tm_hour)
	{
		return (t1.tm_hour > t2.tm_hour ?1:2);
	}
  
	if(t1.tm_min != t2.tm_min)
	{
		return (t1.tm_min > t2.tm_min ?1:2);
	}
	if(t1.tm_sec != t2.tm_sec)
	{
		return (t1.tm_sec > t2.tm_sec ?1:2);
	}
	return IFX_FAILURE;
}

/*********************************************************
 * Name: IFX_DP_ConvertIPAddr
 * Input values:-Converts IP addresses in to standard format
 * Output Values:-
 * Return Values:SUCCESS/FAIL
 * Action: 
 ********************************************************/
#if 0
PUBLIC e_IFX_Return IFX_ConvertIPAddr ( IN char8 *pcInDigitString, OUT char8* pcOUTDigitString) 
{
	int32 i, Dotflag = 0,Atflag = 1;
	char8 * pcOUTDigit = pcOUTDigitString;
	int32 icount = 0;
	char8 szInputBuffer[50] = "" ;
	char8 * pcINDigitString = szInputBuffer;
	strcpy(pcOUTDigitString,"");
	strcpy(szInputBuffer, pcInDigitString);
	
	for(i=0;pcINDigitString[i] != '\0';i++)
	{
		if(icount >= 5)
			return IFX_FAILURE;				  
		if(pcINDigitString[i] == '#')
		{
			if(icount == 0)
				pcINDigitString[i] = '@';
			else			  
				pcINDigitString[i] = '.';
			icount ++ ;				  
		}		  
	}
	
	for(i=0;pcINDigitString[i] != '\0';i++)
	{
		if(Atflag)
			{	  	  
				  *pcOUTDigit = pcINDigitString[i];
				  pcOUTDigit++;
					if(pcINDigitString[i] == '@')
					{		  
					Atflag = 0;
				  	Dotflag = 1;
					}
			}		  
		else 
			{
				if(pcINDigitString[i] == '.')
				{		  
					  if(Dotflag)
				  		{
				  		*pcOUTDigit = '0';
				  		pcOUTDigit++;
				  		*pcOUTDigit = pcINDigitString[i];
				  		pcOUTDigit++;
				  		}
				  		else  
				  		{
						Dotflag = 1;
				  		*pcOUTDigit = pcINDigitString[i];
				  		pcOUTDigit++;
			  	  		}	  
				}
				else if((pcINDigitString[i] >= '0' )&& (pcINDigitString[i] <= '9'))
				{		   
				  if((Dotflag)&&(pcINDigitString[i] == '0'));
				  else if((Dotflag)&&(pcINDigitString[i] != '0'))
				  {
				  Dotflag = 0;
				  *pcOUTDigit = pcINDigitString[i];
				  pcOUTDigit++;
				  }			 
				  else 
				  {			 
				  *pcOUTDigit = pcINDigitString[i];
				  pcOUTDigit++;
				  }
				}
				else return IFX_FAILURE;	
			}
	}
	*pcOUTDigit = '\0';
	printf("<CONVERT_IP_ADDR>Ip Addr is ==> %s <== \n",pcOUTDigitString);
	return IFX_SUCCESS;	
}
#else
PUBLIC e_IFX_Return IFX_ConvertIPAddr ( IN char8 *pcInDigitString, OUT char8* pcOUTDigitString) 
{
	uchar8 ucIpDotCount = 0;
	e_IFX_Return eRet = IFX_SUCCESS;
	
	//Find first # - that is user name
	while(((*pcInDigitString) != '#') && ((*pcInDigitString) != '\0') ) 
		*pcOUTDigitString++ = *pcInDigitString++;

	if(((*pcInDigitString) == '#'))
	{
		//Convert xxx#xxx#xxx#xxx into IP address string	
		uchar8 ucIpDigitCount;
		char8  acTemp[4];

		*pcOUTDigitString++ = '@';	
		while( (ucIpDotCount < 4  ) && (*pcInDigitString != '\0'))
		{
			ucIpDigitCount = 0;
			pcInDigitString++;
			while(((*pcInDigitString) != '#') && ((*pcInDigitString) != '\0') &&
					(ucIpDigitCount < 3) )
			{
			
				if( ucIpDigitCount || *pcInDigitString != '0')
					*pcOUTDigitString++ = *pcInDigitString;

				acTemp[ucIpDigitCount] = *pcInDigitString++;
				++ucIpDigitCount;
			}

			acTemp[3] = '\0';
			if(ucIpDigitCount != 3 || atoi(acTemp) > 254 )
			{
				break;
			}
			*pcOUTDigitString++ = '.';	
			++ucIpDotCount;
		}
	}

	if( ucIpDotCount != 4 || (*pcInDigitString != '\0'))
		eRet = IFX_FAILURE;
	else
		*(pcOUTDigitString - 1 ) = '\0';

	return eRet;	
}
#endif


/*****************************************************************************
*  Function Name        :   IFX_Invokescript
*  Description          :   This Function actually invokes the script.
*  Input Values         :   x_IFX_FirewallCfg pointer
*  Output Values        :
*  Return Value         :   IFX_SUCCESS - On Success
*                           IFX_FAILURE - On Failure
*  Notes                :
*****************************************************************************/
PUBLIC e_IFX_Return IFX_Invokescript(x_IFX_FirewallCfg * pxFirewallCfg)
{

	char8 acCommand[200]={0};
	//char8 acPath[200]={0};
	char8 val[6]={0};

	char8 *acFirewallCfg[]=
	{
		[VOIP_SIGNAL_PORT_UDP] = " VOIP_SIGNAL_PORT_UDP",
		[VOIP_SIGNAL_PORT_TCP] = " VOIP_SIGNAL_PORT_TCP",
		[VOIP_DATA_SPORT] = " VOIP_DATA_SPORT",
		[VOIP_DATA_EPORT] = " VOIP_DATA_EPORT",
		[VOIP_TCP_CLIENT_SPORT] = " VOIP_TCP_CLIENT_SPORT",
		[VOIP_TCP_CLIENT_EPORT] = " VOIP_TCP_CLIENT_EPORT",
		[FAX_SPORT] = " FAX_SPORT",
		[FAX_LISTEN_EPORT] = " FAX_LISTEN_EPORT",
		[FAX_EPORT] = " FAX_EPORT",

		[OLD_VOIP_SIGNAL_PORT_UDP] = " OLD_VOIP_SIGNAL_PORT_UDP",
		[OLD_VOIP_SIGNAL_PORT_TCP] = " OLD_VOIP_SIGNAL_PORT_TCP",
		[OLD_VOIP_DATA_SPORT] = " OLD_VOIP_DATA_SPORT",
		[OLD_VOIP_DATA_EPORT] = " OLD_VOIP_DATA_EPORT",
		[OLD_VOIP_TCP_CLIENT_SPORT] = " OLD_VOIP_TCP_CLIENT_SPORT",
		[OLD_VOIP_TCP_CLIENT_EPORT] = " OLD_VOIP_TCP_CLIENT_EPORT",
		[OLD_FAX_SPORT] = " OLD_FAX_SPORT",
		[OLD_FAX_LISTEN_EPORT] = " OLD_FAX_LISTEN_EPORT",
		[OLD_FAX_EPORT] = " OLD_FAX_EPORT",

		[VOIP_SIP_PRIORITY] = " VOIP_SIP_PRIORITY",
		[VOIP_RTP_PRIORITY] = " VOIP_RTP_PRIORITY",

		[OLD_VOIP_SIP_PRIORITY] = " OLD_VOIP_SIP_PRIORITY",
		[OLD_VOIP_RTP_PRIORITY] = " OLD_VOIP_RTP_PRIORITY"
 
	};

	uchar8 icount = 0;
	/*Copy the path*/
	strcpy(acCommand,IFX_FIREWALL_CMD);
	
	//printf("\nHERE ifx_cm_invokescript \n");

	if(!pxFirewallCfg)
		return IFX_FAILURE;

	for(icount =0;icount<IFX_MAX_FIREWALL_CFG;icount++)
	{
 		//printf("%d\n",pxFirewallCfg->aFwPort[icount]);	
		if(pxFirewallCfg->aFwPort[icount])
		{
			if ((strlen(acCommand) + strlen (acFirewallCfg[icount]) + 6) >200)
				break;
			memset(val,0,6);
			strcat(acCommand,acFirewallCfg[icount]);
			if (pxFirewallCfg->aFwPort[icount] < 6){
				sprintf(val," %d",pxFirewallCfg->aFwPort[icount]);	
				strcat(acCommand,val);
			}else{
	 			return IFX_FAILURE; 
			}
		}
	}

	/*invoke script*/
	//printf("\ncmd is %s\n",acCommand);
	if (IFX_FAILURE == system(acCommand))
	 return IFX_FAILURE; 
	return IFX_SUCCESS;

}

/* This routine converts Hex string into Hex:Hex: ... format */
void IFX_CIF_ConvertHexToString(char8* pszString, uchar8* puHex, 
																												uint16 unHexLen)
{ 
	uint16 unHex = 0;
	uint16 unCurStrLen = 0;
	*pszString = '\0';
	while( unHex < unHexLen ) 
	{ 
		sprintf(pszString+unCurStrLen, "%02X:", *puHex);
		++puHex;
		++unHex;
		unCurStrLen += 3;
	}
	pszString[unCurStrLen-1] = '\0';
}

/* This routine converts string Hex:Hex: ... into hex string */
uint16 IFX_CIF_ConvertStringToHex(uchar8* puHex, char8* pszString)
{
  uint32 unHex;
	uint16 unHexSize = 0;
	if(strlen(pszString) < 2 )
		return 0;
	do {
		sscanf(pszString, "%02X:",&unHex);
		*puHex = unHex;
		++puHex;
		pszString += 3;
		++unHexSize;
	} while(*(pszString-1) != '\0');

	return unHexSize;
}
