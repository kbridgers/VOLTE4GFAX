/**************************************************************************
 **   SRC_FILE          :IFX_TimerIf.h 
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          : 
 **   SRC VERSION       : v0.1
 **   DATE                  : 
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
 **************************************************************************/

# ifndef __TIM_H__
# define __TIM_H__
/********** The Timer data structures*********************/
                                                                                                                             
typedef struct
{
        uint16 unTimerId;               /*The Timer Id returned by the TLIB timer library*/
        void * pvPrivateData;   /*The private data*/
        uint16 unPrivateDataLen;/*Length of private data*/
        uint32 uiTimerId;               /*The Timer Id returned by timer agent*/
        pfn_IFX_TIM_TimerCallBack pfnTimerCallBack;
}x_IFX_TimerInfo;


# endif /*__TIM_H__*/























