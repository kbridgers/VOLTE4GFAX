/*****************************************************************************
**   FILE NAME       : ifx_rtp_agent.h
**   PROJECT         : RTP/RTCP
**   MODULES         : RTP Agent.
**   SRC VERSION     : V1.0
**   DATE            : 10-05-2006
**   AUTHOR          : Deepak Shrivastava.
**   DESCRIPTION     : This file contains data structure of session management.
**                     
**   FUNCTIONS       :
**   COMPILER        :
**   REFERENCE       : RTP-RTCP desgin dcoument, Coding guide lines
**   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 München, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_RTP_AGENT_H__
#define __IFX_RTP_AGENT_H__

#define IFX_IPC_APP_NAME_RTPAGENT "RtpAgent"

typedef enum{
	IFX_RTP_AGENT_START_SESSION,
	IFX_RTP_AGENT_STOP_SESSION,
	IFX_RTP_AGENT_MODIFY_SESSION,
	IFX_RTP_AGENT_MODIFY_CFG
}e_IFX_RTP_AGENT_Action;

typedef struct
{
	e_IFX_RTP_AGENT_Action eAction;
	x_IFX_CMGR_RtpAgentInfo xAgentInfo;
	uchar8 ucDbgLvl;
	uchar8 ucDbgType;
}x_IFX_RTP_AGENT_Agent2App;

typedef struct
{
	uint32 uiCallId;
	e_IFX_ReasonCode eErrCode;
}x_IFX_RTP_AGENT_App2Agent;

/*RtpAgent Api's*/
int32 IFX_RTPAgent_Init(uchar8 ucDbgLvl,uchar8 ucDbgType,uint32 uiInternalPort);


#endif/*__IFX_RTP_AGENT_H__*/




















