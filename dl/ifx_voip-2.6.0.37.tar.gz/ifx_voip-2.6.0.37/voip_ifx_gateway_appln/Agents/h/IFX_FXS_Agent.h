#ifndef __IFX_FXS_INFO_H__
#define __IFX_FXS_INFO_H__

/* 
 * \brief This enum defines events for FXS agent. Not all events that FXS 
 *        Agent handles are listed here. Only those events that are used 
 *        in FXS Endpoint FSM are defined in this enum. If action on an event
 *        remains same in all states, that event will not be added to FSM 
 *        table. For example AutoRedialRegister, BtxRequest/AtxRequest - 
 *        these type of events action is same in all states.
 */
typedef enum 
{
	/*TAPI Event*/
	IFX_FXS_EVT_OffHk=0, /** Off Hook */
	IFX_FXS_EVT_OnHk,    /** On hook */
	IFX_FXS_EVT_HkFlash, /** Hook Flash */
	IFX_FXS_EVT_DigitPressed,  /** Digit Press*/
	/*Timer Events*/
	IFX_FXS_EVT_InterDgtTimerExp,/** Inter digit timer expired */
	IFX_FXS_EVT_DialToneExpired,/** Dial tone timer expired */
	IFX_FXS_EVT_RingToneExpired,/** Ring tone timer expired */
	IFX_FXS_EVT_StutterToneExpired,/** Stutter tone timer expired */
	IFX_FXS_EVT_RingBackToneExpired,/** Ringback tone timer expired */
	IFX_FXS_EVT_BCEToneExpired,/** Busy/error/confirmation tone timer expired */
	/*CallControl Events*/
	IFX_FXS_EVT_IncomingCall, /** Incoming call */
	IFX_FXS_EVT_ReleaseCall,  /** Release call */
	IFX_FXS_EVT_RmtAccept,    /** Remote accepted call */
	IFX_FXS_EVT_RmtAnswer,    /** Remote released call */
	IFX_FXS_EVT_RmtHold,    /** Call held by remote */
	IFX_FXS_EVT_RmtResume,  /** Remote resumed call */
	IFX_FXS_EVT_HoldResp,     /** Hold response */
	IFX_FXS_EVT_ResumeResp,   /** Resume response */
	IFX_FXS_EVT_ConfStatus,   /** Conference status */
	//IFX_FXS_EVT_CallFwd,      /** Call is being forwarded */
	/*Transfer Events*/
	IFX_FXS_EVT_BTxResp,    /** Blind transfer response */
	IFX_FXS_EVT_ATxResp,    /** Attended transfer response */
	/*Automatic Redial Events*/
	//IFX_FXS_EVT_AutoRedialSubStatus, /** Auto redial subscription status */ 
	//IFX_FXS_EVT_AutoRedialNtfy,      /** Auto redial notify */
	IFX_FXS_EVT_FaxDISEvent,	/** FAX DIS event */
	IFX_FXS_EVT_FaxCEDEvent,  /** FAX CED event */
	IFX_FXS_EVT_FaxCNGEvent,  /** FAX CNG event */
	IFX_FXS_EventMax /** Max Event*/
}e_IFX_FXS_Event;

/*! \brief This macro sets the given flag.*/
#define IFX_FXS_SET_FLAG(uiFlag,FlagToBeSet) ( (uiFlag) |= FlagToBeSet )

/*! \brief This macro resets the given flag.*/
#define IFX_FXS_RESET_FLAG(uiFlag,FlagToBeReset) ((uiFlag) &= ~(FlagToBeReset) )

/*! \brief This macro is used to check flags.*/
#define IFX_FXS_CHECKFLAG(uiFlag,FlagToBeChecked) ((uiFlag) & (FlagToBeChecked))

//#define IFX_MAX_DIGITS 25 /** Maximum digits */
#define IFX_MAX_FXS_CALLS      2  /** Maximum calls */

/*! \brief FXS endpoint states */
typedef enum
{
	IFX_FXS_STATE_IDLE=0,      /** Idle state */
	IFX_FXS_STATE_DIALING,     /** Dialing state */
	IFX_FXS_STATE_RINGING,     /** Ringing state */
	IFX_FXS_STATE_RINGBACK,    /** Ringback state */
	IFX_FXS_STATE_CONVERSATION,/** Conversation state */
	IFX_FXS_STATE_CONFERENCE,  /** Conference state */
	IFX_FXS_STATE_CALLWAITING, /** Callwaiting state */
	IFX_FXS_STATE_BUSY,        /** Busy state */
	IFX_FXS_STATE_MAX          /** Maximum states */
}e_IFX_FXS_State;

/*! \brief Call states for FXS endpoint */
typedef enum
{
	IFX_FXS_CS_NONE,             /** No Call */	
	IFX_FXS_CS_CALL_INITIATED,   /** Call initiated */
	IFX_FXS_CS_RINGING,	         /** Ringing */
	IFX_FXS_CS_ACTIVE,	         /** Active */
	IFX_FXS_CS_LOCAL_HELD,			 /** Call held */
	//IFX_FXS_CS_REMOTE_HELD,	     /** Remote held */
	//IFX_FXS_CS_HELD_HELD,	       /** Both held */
	IFX_FXS_CS_RESUME_INITIATED, /** Resume initiated*/
	IFX_FXS_CS_HOLD_INITIATED,	 /** Hold initiated */
	IFX_FXS_CS_TX_INITIATED,	   /** Transfer pending */
}e_IFX_FXS_CallState;

/*! \brief structure to store Call information for FXS endpoint */
typedef struct
{
	uint32 uiCallId;/** Call Id */
	e_IFX_FXS_CallState eCallState;	/** State of call*/
	e_IFX_CMGR_CallType eCallType; /** Type of call */
	char8  szCallInitrEndptId[IFX_MAX_ENDPOINTID_LEN]; /** Call initiator's EndpointId id */
	boolean bFaxStarted;
}x_IFX_FXS_CallInfo;

/*! \brief This flag will be set when call is initiated, but no response is
	         received.
*/
#define IFX_FXS_CALL_INITIATED 0x00000001

/*! \brief Will be set when emergency call is initiated and will be cleared
	         when endpoint goes in to IDLE. If this flag is set only on-hook
	         event will be entertained.
*/
#define IFX_FXS_EMG_CALL_PROCEEDING 0x00000002

/*! \brief Will be set if the dial plan says to not to accept another call.
	         If this flag is set, second incoming call will not be entertained.
*/
#define IFX_FXS_REJECT_WAITING_CALL 0x00000004

/*! \brief Will be set if the auto redial subscription is success and is 
	         reset on off-hook,  incoming call or AutoRedialNtfy event.
*/
#define IFX_FXS_AUTOREDIAL_ACTIVE_OUT 0x00000008

/* \brief Will be set when remote party has request for to inform it when 
	        endpoint is in idle state. This flag will be reset when endpoint 
	        moves to idle state or if remote party calcels request.
*/
#define IFX_FXS_AUTOREDIAL_ACTIVE_IN 0x00000010

/*! \brief This flag is set when hold is initiated on active call and is 
	         cleared once hold response is received.
*/
	
#define IFX_FXS_HOLD_INITIATED 0x00000020

/*! \brief This flag is set when resume is initiated on held call and is 
	         cleared once resume response is received.
*/
#define IFX_FXS_RESUME_INITIATED 0x00000040

/*! \brief This flag is set when conference is initiated and will be reset 
	         on receiving conference status. */
#define IFX_FXS_CONFERENCE_INITIATED 0x00000080

/*! \brief This flag is set when conference is initiated and will be reset 
	         on receiving conference status. */
#define IFX_FXS_BREAK_CONFERENCE_INITIATED 0x00000100

/*! \brief This flag is set during blind/attended transfer and will be reset
	         on receiving blind transfer status. */
#define IFX_FXS_TRANSFER_INITIATED 0x00000200

/*! \brief This flag is set when user request for auto redial and will be reset
	         on receiving auto redial response */
#define IFX_FXS_AUTOREDIAL_INITIATED 0x00000400

/*! \brief This flag is set when there is a waiting call and  will be reset
	         if user answers call, remote cancelation or on timeout */
#define IFX_FXS_CALL_WAITING 0x00000800

/*! \brief This flag is set when ROH TONE played out and will be reset on 
	         on-hook event */
#define IFX_FXS_OFFHOOK_WARNING 0x00001000

/*! \brief This flag is set when subscribed for auto redial and response is 
	         received in IDLE state. */
#define IFX_FXS_DISTINCTIVE_RING_ON 0x00002000

/*! \brief This flag is set when signaling resource for endpoint is allocated 
	         and will be reset after deallocating */
#define IFX_FXS_SIG_RESOURCE_ALLOCATGED 0x10000000

/*! \brief This flag is set when Auto Redial Notification received in busy 
	state */
#define IFX_FXS_AUTOREDIAL_ON_ONHOOK 0x20000000 

#define IFX_FXS_IDLE_STATE_FLAGS (IFX_FXS_AUTOREDIAL_ACTIVE_OUT | \
																	IFX_FXS_AUTOREDIAL_ACTIVE_IN | \
	                                IFX_FXS_AUTOREDIAL_ON_ONHOOK)

/*! \brief The Fxs Endpoint data structure */
typedef struct
{
	char8 szEndPointId[IFX_MAX_ENDPOINTID_LEN]; /** EndpointId id */
	uint32 uiFlags; /** Flags */

	e_IFX_FXS_State eState; /** Current state of the endpoint */
	e_IFX_FXS_State ePrevState; /** Previous state of the endpoint */
	
	/** Call information is stored in this array. */
	x_IFX_FXS_CallInfo axFxsCallInfo[IFX_MAX_FXS_CALLS];
	/** Pointer to active call. This call may not be in conversation. It may be
	    in held state. This is the call which can be resumed automaticaly in busy
	    state.
	 */
	x_IFX_FXS_CallInfo *pxActiveCall;

	uint32 uiToneTimerId; /** Tone timer id */
	uint32 uiIntrDgtTimerId;/** Interdigit timer id */

	char8  szDialledDigits[2*IFX_MAX_DIGITS]; /** Dialed digits */
	/** Last dialed VoIP number. If last dialed number is not VoIP, no number 
	    is stored */
	x_IFX_CMGR_AddressInfo xLastDialedAddr; 
	x_IFX_MMGR_CidParams xCwCidParams; /** CID params for waiting call*/
	uchar8 ucPrevDefVLId; /** The Default voiceline - used for **1 feature */
	uint32 uiConfReqId; /** Conference id */
	uint32 uiAutoRedialOutReqId;   /** The RequestId - subscribe out */
	uint32 uiAutoRedialInReqId;/** The RequestId - subscribe in */

}x_IFX_FXS_EndptFsmInfo;

/*! \brief Incoming call event struct. */
typedef struct
{
	x_IFX_CMGR_AddressInfo* pxFrom;
	x_IFX_CMGR_CallParams*  pxCallParams;
}x_IFX_FXS_IncCallEvent;

/*! \brief Digit pressed event struct. */
typedef struct
{
	uchar8 ucNumDgts;
	uchar8 aucDgtInfo[IFX_MAX_DIGITS];
}x_IFX_FXS_DigitPressedEvent;

/*! \brief The Timer Info data structure */
typedef struct
{
	e_IFX_FXS_Event eTimerEvent;
	x_IFX_FXS_EndptFsmInfo *pxEndptInfo;
}x_IFX_FXS_TimerEvent;

/*! \brief This is a union that contains event related information. */
typedef union
{
	x_IFX_FXS_IncCallEvent xIncCallEvent; /** Incoming call event */
	x_IFX_FXS_DigitPressedEvent xDgtEvent;/** Digit pressed event */
	e_IFX_ReasonCode eReasonCode; /** Reason for call release */
	e_IFX_CMGR_Status eStatus;/** Status for hold,resume & conference */
	e_IFX_TransferStatus eTxStatus; /** transfer status */
}ux_IFX_FXS_EventData;

/*! \brief FXS event information is put into this struct. */
typedef struct
{
	e_IFX_FXS_Event eEvent;	/** Event type */
	uint32 uiId; /** Call, Request Id or timer id. */
	ux_IFX_FXS_EventData uxEventData; 
}x_IFX_FXS_EventInfo;

/* Agetn initializtion, shutdown and status functions */

e_IFX_Return IFX_FXS_AgentInit(
	                   IN char8  aszEndPointId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpoints,
	                   IN uchar8 ucFxsDbgId );

e_IFX_Return IFX_FXS_AgentShut(
	                   IN char8  aszEndPointId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpoints );

e_IFX_Return IFX_FXS_AgentStatus(char* pszEndptId, x_IFX_AgentStatus* pxStatus);

/* The Functions to be registered with external modules */

/*!
	\brief This function will be registered with the Message router and is called
	       by message router when there is any event for this Agent.	
	\param[in] szEndpointId FXS Endpoint id.
	\param[in] pxDevEvents Pointer Device event containing event for FXS endpoint
*/
#if 0
void IFX_FXS_MsgRouterEvtHdlr(
	           IN char8* szEndpointId, 
	           IN x_IFX_MMGR_DeviceEvents *pxDevEvents );
#endif

/* Following functions will be registered with call manager. */
	
e_IFX_Return IFX_FXS_CallIncoming(
	               IN uint32 uiCallId, 
	               IN x_IFX_CMGR_AddressInfo *pxFrom,
	               IN x_IFX_CMGR_AddressInfo *pxTo, 
	               IN x_IFX_CMGR_CallParams *pxCallParams, 
	               OUT e_IFX_CMGR_Status* peStatus,
	               OUT e_IFX_ReasonCode* peReason,
	               OUT void** ppvPrivateData );

e_IFX_Return IFX_FXS_RemoteCallRelease(
	             IN uint32 uiCallId,
	             IN e_IFX_ReasonCode eReleaseReason,
	             IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
	             IN void* pvPrivateData );

 e_IFX_Return IFX_FXS_CallForwardInfo(
	             IN uint32 uiCallId,
	             IN e_IFX_ReasonCode eReason, 			
	             IN x_IFX_CMGR_VoipAddr* pxFwdAddr,			
	             OUT boolean* pbFwdAllow,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_RemoteCallAccept(
	             IN uint32 uiCallId,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_RemoteCallAnswer(
	             IN uint32 uiCallId,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_RemoteCallHold(
	             IN uint32 uiCallId,
	             OUT e_IFX_CMGR_Status* peStatus,
	             OUT e_IFX_ReasonCode* peReason,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_RemoteCallResume(
	             IN uint32 uiCallId,
	             OUT e_IFX_CMGR_Status* peStatus,
	             OUT e_IFX_ReasonCode* peReason,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_CallHoldResponse(
	             IN uint32 uiCallId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason, 
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_CallResumeResponse(
	             IN uint32 uiCallId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason, 
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_ConfStatus(
	             IN uint32 RequestId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_BlindTxRequest(
	             IN uint32 uiCallId,
	             IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
	             OUT e_IFX_TransferStatus* peTransferStatus,
	             OUT e_IFX_ReasonCode *peRespCode,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_AttendedTxRequest(
	             IN uint32 uiCallId,
	             IN uint32 uiReplacesCallId,
	             IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
	             OUT e_IFX_TransferStatus* peTransferStatus,
	             OUT e_IFX_ReasonCode *peRespCode,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_BlindTxStatus(
	             IN uint32 uiCallId,
	             IN e_IFX_TransferStatus eTransferStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData );


e_IFX_Return IFX_FXS_AttendedTxStatus(
	             IN uint32 uiCallId,
	             IN e_IFX_TransferStatus eTransferStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_CallIdReplace(
	               IN uint32 uiOldCallId,
	               IN uint32 uiNewCallId,
	               IN_OUT void** ppvPrivateData );

e_IFX_Return IFX_FXS_AutoRedialStatus(
	             IN uint32 uiRequestId,
	             IN e_IFX_CMGR_Status eSubsStatus,
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_AutoRedialNotifyReceived(
	             IN uint32 uiRequestId,
	             IN e_IFX_CMGR_Status eRemoteStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData );

e_IFX_Return IFX_FXS_AutoRedialRegister(
	             IN uint32 uiRequestId,
	             IN boolean bEnable,
	             IN char8* szEndpointId,
	             OUT e_IFX_CMGR_Status* peLocalStatus,
	             IN void** pvPrivateData );

/*
	\brief Event handler prototype.
	\param[in] pxEndPtInfo Pointer to endpoint info struct.
	\param[in] puxEvtInfo pointer to event info struct.
*/
typedef e_IFX_Return (*pfn_IFX_FXS_Fsm)(
	                IN_OUT x_IFX_FXS_EndptFsmInfo *pxEndPtInfo,
	                IN x_IFX_FXS_EventInfo *puxEvtInfo,
	                OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is entry point for FXS FSM. It invokes the FSM depending
	       upon the event.
	\param[in] pxEndptInfo pointer to Endpoint Info  
	\param[in] pxEvtInfo pointer to Event Info 
	\param[out] peReason If function retunrs IFX_FAILURE, then this parameter
	            indicates the reason for failure.
	\return Retunrs IFX_SUCCESS or IFX_FAILURE. 
*/

e_IFX_Return IFX_FXS_FxsFsmHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

/* The internal utility functions for the FXS FSM */

/*!
	\brief As name indicate this routine makes FXS endpoint idle. Any timers if
	       running will be stopped and all existing calls will be released.
	       All flags will be reset. If any flag was set when this routine is 
	       called, then appropriate action will be taken.
	\param[in] pxEndptInfo FXS endpoint information.
	\param[out] peReason If function retunrs IFX_FAILURE, then this parameter
	            indicates the reason for failure.
	\return Retunrs IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return IFX_FXS_MakeFXSIdle(
	                x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                OUT e_IFX_ReasonCode* peReason );

/*---------------------- FXS FSM Handler Routines ---------------------------*/
e_IFX_Return IFX_FXS_IgnoreHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_IgnoreCallHdlr(
                 IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
                 IN x_IFX_FXS_EventInfo* pxEvtInfo,
                 OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_AutoRedialRequest(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_BtxRequestHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_AtxRequestHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_CallForwardHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
//Only for dialing state
e_IFX_Return IFX_FXS_AutoRedialStatusHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_IDLE        */
e_IFX_Return IFX_FXS_IdleOffHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_IdleIncomingCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_IdleAutoRedialNtfy(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
		

	/* IFX_FXS_STATE_DIALING     */
e_IFX_Return IFX_FXS_DialingOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingDigitPressedHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingInterDigitExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_ProcessDialPlan(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingDialToneExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingStutterToneExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

//This routine handles remote call release in dialing and ringback state
e_IFX_Return IFX_FXS_DialAndRingbackReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingRmtAcceptHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

//This event handler is used in dialing and ringback states
e_IFX_Return IFX_FXS_RemoteAnswerHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingResumeRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingConferenceStatusHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_DialingBtxRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_RINGING     */
e_IFX_Return IFX_FXS_RingOffHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_RingOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_RingRingTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_RingReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_AutoRedialRequest(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_RINGBACK    */
/* Remote answer event in ringback is handled in IFX_FXS_RemoteAnswerHdlr 
 * Remote release call event in ringback is handled in 
 * IFX_FXS_DialAndRingbackReleaseCallHdlr 
 */
e_IFX_Return IFX_FXS_RingbackOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_RingbackHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_RingbackRingbackTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_RingbackRmtAcceptHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_CONVERSATION*/
e_IFX_Return IFX_FXS_ConvOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

/* This routine handles hook-flash event in conversation & call waiting sates*/
e_IFX_Return IFX_FXS_ConvAndCwHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

/* 
 * This routine handles hold response event in conversation & call waiting 
 * sates
 */
e_IFX_Return IFX_FXS_ConvAndCwHoldRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

/* This handler is used in conversation and conference state*/
e_IFX_Return IFX_FXS_DigitPressedDuringConvHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
 
e_IFX_Return IFX_FXS_ConvIncomingCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_ConvReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );



e_IFX_Return IFX_FXS_ConvAtxRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_ConvFaxStartHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_ConvCNGHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_CONFERENCE  */
e_IFX_Return IFX_FXS_ConfOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_ConfHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
 
e_IFX_Return IFX_FXS_ConfReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_ConfConfStatusHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_CALLWAITING */
e_IFX_Return IFX_FXS_CwOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_CwHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_CwDigitPressedHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
 
e_IFX_Return IFX_FXS_CwInterDigitTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );
 
e_IFX_Return IFX_FXS_CwRingToneExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_CwReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_CwHoldRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

	/* IFX_FXS_STATE_BUSY        */
e_IFX_Return IFX_FXS_BusyOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_BusyRingTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_BCEToneTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_BusyReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

e_IFX_Return IFX_FXS_BusyResumeRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason );

#endif /*__IFX_FXS_INFO_H__ */
