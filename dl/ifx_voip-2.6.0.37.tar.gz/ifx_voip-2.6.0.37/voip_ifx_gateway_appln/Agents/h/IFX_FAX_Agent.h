/*****************************************************************************
**   FILE NAME       : ifx_FAX_agent.h
**   PROJECT         : FAX/RTCP
**   MODULES         : FAX Agent.
**   SRC VERSION     : V1.0
**   DATE            : 10-05-2006
**   AUTHOR          : Deepak Shrivastava.
**   DESCRIPTION     : This file contains data structure of session management.
**                     
**   FUNCTIONS       :
**   COMPILER        :
**   REFERENCE       : FAX-RTCP desgin dcoument, Coding guide lines
**   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 München, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_FAX_AGENT_H__
#define __IFX_FAX_AGENT_H__

#define IFX_IPC_APP_NAME_FAXAGENT "FAXAgent"

typedef enum{
	IFX_FAX_AGENT_START_SESSION,
	IFX_FAX_AGENT_STOP_SESSION,
	IFX_FAX_AGENT_START_SERVER,
	IFX_FAX_AGENT_MODIFY_CFG,
}e_IFX_FAX_AGENT_Action;

typedef struct
{
	e_IFX_FAX_AGENT_Action eAction;
	x_IFX_CMGR_FaxAgentInfo xAgentInfo;
	uchar8 ucDbgLvl;
	uchar8 ucDbgType;
}x_IFX_FAX_AGENT_Agent2App;

typedef struct
{
	uint32 uiCallId;
	e_IFX_ReasonCode eErrCode;
}x_IFX_FAX_AGENT_App2Agent;

/*FAXAgent Api's*/
int32 IFX_FAXAgent_Init(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg *pxFA_T38Cfg);


#endif/*__IFX_FAX_AGENT_H__*/




















