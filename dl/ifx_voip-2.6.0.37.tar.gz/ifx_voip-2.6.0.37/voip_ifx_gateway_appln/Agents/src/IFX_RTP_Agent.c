/**************************************************************************
 **   FILE NAME       : IFX_RTP_Agent.c
 **   PROJECT         : Rtp Agent
 **   MODULES         : Rtp Agent  Module.
 **   SRC VERSION     : V0.1
 **   DATE            :26-06-2007.
 **   AUTHOR          :Voip Lib Team.
 **   DESCRIPTION     :RTP Agent.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines.
 **
 **   COPYRIGHT       : Copyright © 2004
 **                     Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "fcntl.h"
#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_RTP_Agent.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include "ifx_os.h"

/* Global Variables */
STATIC int16 v_nRtpAgentFifoFd,v_nRtpAppFifoFd;
extern int32 IFX_RTPAPP_AppInit(uchar8 ucDbgLvl,uchar8 ucDbgType,uint32 uiInternalPort);

uint8 vcRtpAgentModId;
#define printf(...) 
 /******************************************************************************
 *  Function Name   : IFX_RTP_AGENT_SendMsgToFifo
 *  Description     : This module writes Msg to FIFO
 *
 *  Input Values    : ua Message
 *  Output Values   : None
 *  Return Value    :
 *  Notes           :
 ******************************************************************************
*/
int8 IFX_RTP_AGENT_SendMsgToFifo(IN int16 nFifoFd,
                                 IN char *pcFifoMsg,
                                 IN int16 nMsgLen )
{
   int16 nBytes = 0;
   nBytes = IFX_OS_WriteFifo(nFifoFd, (char8 *) pcFifoMsg,nMsgLen);
  if (nBytes != nMsgLen)
  {
       IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "<RTPAgent> Error Writing to Fifo" );
       return IFX_FAILURE;
  }
   IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
                 "<RTPAgent> Bytes Written to Fifo",nBytes );
   return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_RtpAgentNotifier
 *  Description     : This Function is responsible 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_RtpAgentNotifier(int32 iFd)
{
   int16 nBufSize=0;
   x_IFX_RTP_AGENT_App2Agent xAppInfo ={0};
   nBufSize = IFX_OS_ReadFifo( iFd,( char8 * )&xAppInfo,
                              sizeof( x_IFX_RTP_AGENT_App2Agent ) );
   if( nBufSize < 0 )
   {
         IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_READ_ERR,
			            "RTP App Fifo\n" );
   }

	 printf("Response from RTPAPP arrived the Error code %d\n",
					xAppInfo.eErrCode);
   return IFX_CMGR_RtpMediaError(xAppInfo.uiCallId,xAppInfo.eErrCode);
}
/******************************************************************************
 *  Function Name   : IFX_RTPAgent_CMGR_StartSession
 *  Description     : This Function is responsible  
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
e_IFX_Return IFX_RTPAgent_CMGR_StartSession
		  			(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo)
{
   x_IFX_RTP_AGENT_Agent2App xAgent2AppInfo={0};
   IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			            "Start Session Posted to RTPAPP\n" );
	 printf("Start Session posted to RTPAPP\n");
   xAgent2AppInfo.eAction = IFX_RTP_AGENT_START_SESSION;
   memcpy(&xAgent2AppInfo.xAgentInfo,pxRtpAgentInfo,
	      sizeof(x_IFX_CMGR_RtpAgentInfo));
	 printf("Start session The Remote IP %s Remote Port %d Local IP %s Local Port %d\n",
					xAgent2AppInfo.xAgentInfo.xRtpParams.szRemoteRtpIpAddr,
					xAgent2AppInfo.xAgentInfo.xRtpParams.uiRemoteRtpPort,
					xAgent2AppInfo.xAgentInfo.xRtpParams.szLocalRtpIpAddr,
					xAgent2AppInfo.xAgentInfo.xRtpParams.uiLocalRtpPort);
	 printf("The Device Name is %s\n",xAgent2AppInfo.xAgentInfo.szCoderDeviceName);
	 printf("The SSRC is %d\n",xAgent2AppInfo.xAgentInfo.uiSsrcNumber);
	 printf("The Sequence is %d\n",xAgent2AppInfo.xAgentInfo.uiSequenceNumber);
   return IFX_RTP_AGENT_SendMsgToFifo(v_nRtpAppFifoFd,(char*)&xAgent2AppInfo,
	                        sizeof(x_IFX_RTP_AGENT_Agent2App));

}
/******************************************************************************
 *  Function Name   : IFX_RTPAgent_CMGR_StopSession
 *  Description     : This Function is responsible of   
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
e_IFX_Return IFX_RTPAgent_CMGR_StopSession
		  		(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo)
{
   x_IFX_RTP_AGENT_Agent2App xAgent2AppInfo={0};

   IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			            "Stop Session Posted to RTPAPP\n" );
   xAgent2AppInfo.eAction = IFX_RTP_AGENT_STOP_SESSION;
   memcpy(&xAgent2AppInfo.xAgentInfo,pxRtpAgentInfo,
	      sizeof(x_IFX_CMGR_RtpAgentInfo));

   return IFX_RTP_AGENT_SendMsgToFifo(v_nRtpAppFifoFd,(char*)&xAgent2AppInfo,
	                        sizeof(x_IFX_RTP_AGENT_Agent2App));
}
/******************************************************************************
 *  Function Name   : IFX_RTPAgent_CMGR_ModifySession
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
e_IFX_Return IFX_RTPAgent_CMGR_ModifySession
		  		(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo)
{
  x_IFX_RTP_AGENT_Agent2App xAgent2AppInfo={0};
  IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			            "Modify Session Posted to RTPAPP\n" );
  xAgent2AppInfo.eAction = IFX_RTP_AGENT_MODIFY_SESSION;
  memcpy(&xAgent2AppInfo.xAgentInfo,pxRtpAgentInfo,
	      sizeof(x_IFX_CMGR_RtpAgentInfo));

  return IFX_RTP_AGENT_SendMsgToFifo(v_nRtpAppFifoFd,(char*)&xAgent2AppInfo,
	                        sizeof(x_IFX_RTP_AGENT_Agent2App));
}
/******************************************************************************
 *  Function Name   : IFX_RTPAgent_Init
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_RTPAgent_Init(uchar8 ucDbgLvl,uchar8 ucDbgType, uint32 uiInternalPort)
{
  int8 cRet = IFX_FAILURE;
  x_IFX_CMGR_CallBackList xCallBackList={0};
  x_IFX_MSGRTR_FdInfo xMSGFdInfo={0}; 
	char8 aszEndptId[1][IFX_MAX_ENDPOINTID_LEN] = {IFX_RTP_AGENT_ENDPT_ID};

	
  IFX_DBG_Init(IFX_IPC_APP_NAME_RTPAGENT,ucDbgType,
						   ucDbgLvl, &vcRtpAgentModId, &cRet);
  /*IFX_DBG_Init(IFX_IPC_APP_NAME_RTPAGENT,4,
						   1, &vcRtpAgentModId, &cRet);*/
	
  /* Create RTP Fifo */ 
   umask( 0 );
   if(access( IFX_IPC_RTP_AGENT_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_RTP_AGENT_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_RTP_AGENT_FIFO");
         return cRet;
      }
   }
   if((v_nRtpAgentFifoFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_RTP_AGENT_FIFO,O_RDWR)) 
	   == -1 )
   {
      IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
	           "<AppMain> IFX_IPC_RTP_AGENT_FIFO");
      return cRet;
   }
	if(access( IFX_IPC_RTP_APP_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_RTP_APP_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_RTP_APP_FIFO");
         return cRet;
      }
   }
   if((v_nRtpAppFifoFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_RTP_APP_FIFO,O_RDWR)) 
	     == -1 )
   {
      IFX_DBGA(vcRtpAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
	           "<AppMain> IFX_IPC_RTP_APP_FIFO");
      return cRet;
   } 
   /*Register the FD with the callmanager*/
   xMSGFdInfo.uiFd = v_nRtpAgentFifoFd;
   xMSGFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;
   IFX_MSGRTR_FdCallBackRegister(&xMSGFdInfo,1,IFX_RtpAgentNotifier);

   /*Register the CallBacks*/
   xCallBackList.pfnRtpSessionModify = IFX_RTPAgent_CMGR_ModifySession;
   xCallBackList.pfnRtpSessionStop = IFX_RTPAgent_CMGR_StopSession;
   xCallBackList.pfnRtpSessionStart = IFX_RTPAgent_CMGR_StartSession;
   IFX_CMGR_CallBacksRegister(aszEndptId,1,&xCallBackList);
	

		printf("%s: At line %d!",__FUNCTION__, __LINE__ );
   IFX_RTPAPP_AppInit(ucDbgLvl,ucDbgType,uiInternalPort);	 
	 return IFX_SUCCESS;

}
/******************************************************************************
 *  Function Name   : IFX_RTPAgent_Config
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_RTPAgent_Config(uchar8 ucDbgLvl,uchar8 ucDbgType)
{
  x_IFX_RTP_AGENT_Agent2App xAgentInfo={0};
  xAgentInfo.eAction = IFX_RTP_AGENT_MODIFY_CFG;
  xAgentInfo.ucDbgLvl = ucDbgLvl;
  xAgentInfo.ucDbgType = ucDbgType;
  IFX_DBG_Set(IFX_IPC_APP_NAME_RTPAGENT,vcRtpAgentModId,
	            ucDbgType,ucDbgLvl);
  return IFX_RTP_AGENT_SendMsgToFifo(v_nRtpAppFifoFd,(char*)&xAgentInfo,
				                          sizeof(x_IFX_RTP_AGENT_Agent2App));	
}


