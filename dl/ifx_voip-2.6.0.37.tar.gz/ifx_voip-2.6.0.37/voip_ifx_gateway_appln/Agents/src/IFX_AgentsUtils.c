/**************************************************************************
 **   SRC_FILE          : IFX_AgentsUtils.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : Agents
 **   SRC VERSION       : v0.1
 **   DATE              : 29th Nov 2007 
 **   AUTHOR            : 
 **   DESCRIPTION       : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#include <stdio.h>
#include <string.h>

#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_DialPlanIf.h"
#include "IFX_Misc.h"
#include "ifx_debug.h"
#include "IFX_AgentsUtils.h"

void IFX_AGU_GetCallerIdInfo(
	              IN x_IFX_CMGR_AddressInfo* pxAddr,
	              OUT char8* pszCallerName,
	              OUT char8* pszCallerNumber )
{
	ux_IFX_CMGR_AddressInfo* puxAddrInfo = &pxAddr->uxAddressInfo;
	uint16 unUserLen = 0;
	//uint16 unAddrLen = 0;

	pszCallerNumber[0] = pszCallerName[0] = '\0';

	if( IFX_CMGR_TYPE_VOIP == pxAddr->eAddressType )
	{
		//printf("\n\nUSER NAME RECEIVED=%s\n\n",puxAddrInfo->xVoipAddr.acUserName);
		/* Since the handset is only displaying Caller Number so append the user name
		   and @ to the caller number.*/
		unUserLen = strlen(puxAddrInfo->xVoipAddr.acUserName);
    if(unUserLen > 31) unUserLen = 31;
		if( unUserLen )
		{
      if(puxAddrInfo->xVoipAddr.acDisplayName[0] != '\0'){
				strncpy(pszCallerName,puxAddrInfo->xVoipAddr.acDisplayName,31);
      	pszCallerName[31]='\0';
			}
      strncpy(pszCallerNumber,puxAddrInfo->xVoipAddr.acUserName,31);
      pszCallerNumber[31]='\0';
			//strcpy(pszCallerName,puxAddrInfo->xVoipAddr.acUserName);
	 		//strcpy(pszCallerNumber,puxAddrInfo->xVoipAddr.acUserName);
		/*	unAddrLen = strlen(puxAddrInfo->xVoipAddr.acCalledAddr);
			if( unAddrLen && ((unAddrLen  + unUserLen +1)  < IFX_MAX_TSP_ADDR) )
			{
				sprintf((pszCallerNumber+unUserLen),"@%s", puxAddrInfo->xVoipAddr.acCalledAddr);
			}*/
		}
		else
		{
			//No user name, so domain name is treated as number
      if(puxAddrInfo->xVoipAddr.acDisplayName[0] != '\0'){
				strncpy(pszCallerName,puxAddrInfo->xVoipAddr.acDisplayName,31);
      	pszCallerName[31]='\0';
			}
	 		strncpy(pszCallerNumber,puxAddrInfo->xVoipAddr.acCalledAddr,49); //IFX_MAX_CALLER_NUMBER-1=49
			pszCallerNumber[49]=0;
		}
	}
	else if( IFX_CMGR_TYPE_FXO == pxAddr->eAddressType )
	{
		strcpy(pszCallerNumber,puxAddrInfo->xFxoInfo.szPhoneNumber);
		strcpy(pszCallerName,puxAddrInfo->xFxoInfo.szPhoneNumber);
	}
	else //IFX_CMGR_TYPE_EXTN
		strcpy(pszCallerNumber,puxAddrInfo->szEndptId);
}

/*
 * This function activate/deactivate call forward on default voice line of the
 * endpoint 
 */
e_IFX_Return IFX_AGU_SetCallForward(
	                   IN char8*  pszEnptId,
	                   IN e_IFX_DP_Action eDpAction,
	                   IN char8* pszDialOut,
	                   IN char8 ucDbgId )
{
	char8 szTempDialOut[IFX_MAX_DIGITS];
	x_IFX_DP_Rule xDpRule;
	x_IFX_CalledAddr xCfAdress = {0};
	boolean bEnable = IFX_FALSE;
	e_IFX_CallForwardType eCfType;
	e_IFX_ReasonCode eReason;
	uchar8 ucDpAction;
	uint16 unTimeOut;
	e_IFX_Return eRet = IFX_FAILURE;

	if( IFX_DP_UNC_CFWD_ACTV == eDpAction || IFX_DP_UNC_CFWD_DEACTV == eDpAction)
	{
		eCfType = IFX_CALL_FWD_UNCONDITIONAL;
	}
	else if( IFX_DP_BUSY_CFWD_ACTV == eDpAction || 
		IFX_DP_BUSY_CFWD_DEACTV == eDpAction )
	{
		eCfType = IFX_CALL_FWD_BUSY;
	}
	else if( IFX_DP_NOANS_CFWD_ACTV == eDpAction || 
		IFX_DP_NOANS_CFWD_DEACTV == eDpAction )
	{
		eCfType = IFX_CALL_FWD_ON_NO_ANSWER;
	}
	else
		return eRet;
	
	if( IFX_DP_UNC_CFWD_ACTV == eDpAction ||
		  IFX_DP_BUSY_CFWD_ACTV == eDpAction ||
			IFX_DP_NOANS_CFWD_ACTV == eDpAction )
	{
		strcpy(szTempDialOut,pszDialOut);
		eRet = IFX_DP_Match(szTempDialOut, IFX_TRUE,	&ucDpAction, pszDialOut,	
							&xDpRule, &unTimeOut );
		if( IFX_SUCCESS != eRet || (IFX_DP_DIALOUT != ucDpAction ) )
		{
			IFX_DBGC(ucDbgId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pszEnptId, "Call Forward Setting : Dial Plan Error" );
			return eRet;
		}
#ifdef DIAL_PLAN_REMOVE
		if( IFX_DP_LOCAL_VOIP_CALLS == xDpRule.eAction ||
			  IFX_DP_ISD_VOIP_CALLS == xDpRule.eAction ||
			  IFX_DP_STD_VOIP_CALLS == xDpRule.eAction )
		{
			xCfAdress.ucAddrType = IFX_SIP_URL;
		}
		else if( IFX_DP_DIRECT_IP_CALLS == xDpRule.eAction )
		{
			char8* pszDomain = 0;

			strcpy(szTempDialOut,pszDialOut);
			if( IFX_SUCCESS != (eRet = IFX_ConvertIPAddr(szTempDialOut, pszDialOut)))
				return eRet;
			xCfAdress.ucAddrType = IFX_IP_ADDR;

			 pszDomain = strchr(pszDialOut,'@');
			 if( pszDomain )
			 {
					strncpy(xCfAdress.acUserName,pszDialOut, 
							pszDomain-pszDialOut);
					xCfAdress.acUserName[pszDomain-pszDialOut] = '\0';
					++pszDomain;
			 }
			 else
				 pszDomain = pszDialOut;
			 
			 strcpy(xCfAdress.acCalledAddr,pszDomain);
		}
#endif
/*SMS01395036 Start: Fix for call forward activate*/
     else if (IFX_DP_DIALDEFAULT_DEF_IF == xDpRule.eAction){
        IFX_DBGC(ucDbgId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
            pszEnptId, "Dial on Default" );
        xCfAdress.ucAddrType = IFX_TEL_NUM;
        strcpy(xCfAdress.acDisplayName,pszDialOut);
        strcpy(xCfAdress.acUserName,pszDialOut);
      }
/*End: Fix for call forward activate*/

		else
		{
			IFX_DBGC(ucDbgId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pszEnptId, "Invalid Call Forward Address" );
			return IFX_FAILURE;
		}

		bEnable = IFX_TRUE;
	} 
	/* else deactivate call forward */

	return IFX_CIF_EndptCallFwdInfoSet(pszEnptId,
						eCfType, bEnable,	&xCfAdress,	&eReason );
}

e_IFX_Return IFX_AGU_BlindTransfer(
	                   IN char8* pszEnptId,
	                   IN uint32 uiCallId,
	                   IN char8* pszDialOut,
	                   IN uchar8 ucDbgId,
										 OUT e_IFX_TransferStatus* peTxStatus )
{

	x_IFX_CMGR_AddressInfo xCmgrAddr = {0};
	x_IFX_DP_Rule xDpRule;

	char8 szTempDialOut[IFX_MAX_DIGITS];
	uchar8 ucAction;
	uint16 unTimeOut;

	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;

	strcpy(szTempDialOut,pszDialOut);
	eRet = IFX_DP_Match(szTempDialOut, IFX_TRUE, &ucAction, pszDialOut, 
						&xDpRule, &unTimeOut );

	*peTxStatus = IFX_CMGR_TRANSFER_FAILED;

	if( IFX_SUCCESS != eRet || (IFX_DP_DIALOUT != ucAction ) )
	{
		IFX_DBGC(ucDbgId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pszEnptId, "Blind Transfer : Dial Plan Failed");
		return IFX_FAILURE;
	}

	//eRet = IFX_SUCCESS;

	switch( xDpRule.eAction )
	{
	case IFX_DP_SPEED_DIAL:
	 {
		IFX_DBGC(ucDbgId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pszEnptId, "Blind Transfer : Through Speed Dial");
		eRet = IFX_CIF_AddrBookEntryGet(pszDialOut,&xCmgrAddr,&eReason);
		break;
	 }
#ifdef DIAL_PLAN_REMOVE
	case IFX_DP_DIRECT_IP_CALLS:
	 {
		IFX_DBGC(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pszEnptId, "Blind Transfer : Through Direct IP Dial");
		 strcpy(szTempDialOut,pszDialOut);
		 if( IFX_SUCCESS != 
			 (eRet = IFX_ConvertIPAddr(szTempDialOut,pszDialOut)) )
		 {
			 break;
		 }
	 }
	case IFX_DP_LOCAL_VOIP_CALLS:
	case IFX_DP_ISD_VOIP_CALLS:
	case IFX_DP_STD_VOIP_CALLS:
	 {
		  char8* pszDomain;
			IFX_DBGC(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pszEnptId, "Blind Transfer : Through VoIP Line");
		 	xCmgrAddr.eAddressType = IFX_CMGR_TYPE_VOIP;

			 pszDomain = strchr(pszDialOut,'@');
			 if( pszDomain )
			 {
					strncpy(xCmgrAddr.uxAddressInfo.xVoipAddr.acUserName,pszDialOut, 
																												pszDomain-pszDialOut);
					xCmgrAddr.uxAddressInfo.xVoipAddr.acUserName[pszDomain-pszDialOut] = '\0';	
		 			xCmgrAddr.uxAddressInfo.xVoipAddr.ucAddrType = 
							((IFX_DP_DIRECT_IP_CALLS == xDpRule.eAction)?IFX_IP_ADDR:IFX_SIP_URL);
			 		strcpy(xCmgrAddr.uxAddressInfo.xVoipAddr.acCalledAddr, pszDomain+1);
			 }
			 else
			 { //If no domain name, use Voip Address type as IFX_EXTN
				 xCmgrAddr.uxAddressInfo.xVoipAddr.ucAddrType = 
							((IFX_DP_DIRECT_IP_CALLS == xDpRule.eAction)?IFX_EXTN:IFX_TEL_NUM);
				 strcpy(xCmgrAddr.uxAddressInfo.xVoipAddr.acUserName, pszDialOut);
				 xCmgrAddr.uxAddressInfo.xVoipAddr.acCalledAddr[0]='\0';
			 }
		 break;
	 }
#endif
	 case IFX_DP_TWO_STAGE_PSTN_DIALING:
	 case IFX_DP_LOCAL_PSTN_CALLS:
	#ifdef DIAL_PLAN_REMOVE 
	case IFX_DP_STD_PSTN_CALLS:
	 case IFX_DP_ISD_PSTN_CALLS:
	#endif
	 {
		 IFX_DBGC(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pszEnptId, "Blind Transfer : Through FXO Line");
		 xCmgrAddr.eAddressType = IFX_CMGR_TYPE_FXO;
		 strcpy(xCmgrAddr.uxAddressInfo.xFxoInfo.szPhoneNumber,pszDialOut);
		 break;
	 }
	 
	case IFX_DP_DIALDEFAULT_DEF_IF:
	 {
		
		 IFX_DBGC(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pszEnptId, "Blind Transfer : Through Default Interface");
		 if( IFX_SUCCESS == IFX_CIF_DefaultOutBoundIfGet(
						pszEnptId, &ucAction, &eReason) )
			
		 {
			 if( ucAction )
			 {
			 	 xCmgrAddr.eAddressType = IFX_CMGR_TYPE_FXO;
				 strcpy(xCmgrAddr.uxAddressInfo.xFxoInfo.szPhoneNumber, pszDialOut);
			 }
			 else
			 {
				 xCmgrAddr.eAddressType = IFX_CMGR_TYPE_VOIP;
				 xCmgrAddr.uxAddressInfo.xVoipAddr.ucAddrType = IFX_TEL_NUM;
				 strcpy(xCmgrAddr.uxAddressInfo.xVoipAddr.acUserName, pszDialOut);
			 }
		 }
		 break;
	 }
	case IFX_DP_EXTENSION_DIAL:
	 {
			IFX_DBGC(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pszEnptId, "Blind Transfer : Between extensions");
			xCmgrAddr.eAddressType = IFX_CMGR_TYPE_EXTN;
			strcpy(xCmgrAddr.uxAddressInfo.szEndptId,pszDialOut);
			break;
	 }
	default:
		{
			IFX_DBGA(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
				"Blind Transfer Dialout enum = ", xDpRule.eAction);
			IFX_DBGA(ucDbgId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pszEnptId, "Blind Transfer : Invalid Dial Pattern For Transfer");
			eRet = IFX_FAILURE;
		}
	} /* switch */


	if( IFX_SUCCESS == eRet )
	{
		if( IFX_SUCCESS != 
				(eRet = IFX_CMGR_BlindTx( uiCallId, &xCmgrAddr, peTxStatus, &eReason)) ||
				IFX_CMGR_TRANSFER_REJECTED == *peTxStatus || 
				IFX_CMGR_TRANSFER_FAILED == *peTxStatus )
		{
			IFX_DBGC(ucDbgId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pszEnptId, "Blind Transfer : Failed");
			eRet = IFX_FAILURE;
		}
	}
	return eRet;
}

#ifdef HEX_DUMP
void IFX_AGU_HEX_DUMP(uchar8* pucBuf, int size) 
{
	uchar8 ucByteCount = 0;

	while(size-- ) 
	{
		if( !(ucByteCount % 16) )
			printf("\n"), ucByteCount = 0;
		printf("0x%02X ", *pucBuf++);
		++ucByteCount;
	}
	printf("\n");
}
#endif
