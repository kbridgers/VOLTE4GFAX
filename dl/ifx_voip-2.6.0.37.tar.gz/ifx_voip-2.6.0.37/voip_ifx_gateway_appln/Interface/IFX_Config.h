/**************************************************************************
 **   SRC_FILE          : IFX_Config.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          : CallManager
 **   SRC VERSION       : v0.1
 **   DATE                  : 
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   : System Configuration Declerations
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
 **************************************************************************/
# ifndef __IFX_CONFIG_H__
# define __IFX_CONFIG_H__
//#define printf(...)

/*! \file IFX_Config.h
    \brief This file contains functions and callback functions provided by Configuration
	Interface
*/

/** \addtogroup GW_APIs Gateway Application APIs
    \brief This section lists the functions provided by different modules
*/
/* @{ */

/*! \brief Maximum number of timers supported by timer module */
# define IFX_MAX_TIMERS	        40

/*! \brief Maximum number of agents supported */
# define IFX_MAX_AGENTS	        4

/*! \brief Maximum number of endpoints supported */
# define IFX_MAX_ENDPTS	        9
/*! \brief Maximum Endpoint Id's string length */
# define IFX_MAX_ENDPOINTID_LEN	32
/*! \brief Maximum number of conference parties supported */
# define IFX_MAX_CONF_PARTIES 					2

/*! \brief Maximum number of FXS channels present in the system */
#ifdef UTA
# define IFX_MMGR_MAX_FXS_CHANNELS	    1
#else
# define IFX_MMGR_MAX_FXS_CHANNELS	    2
#endif
/*! \brief Maximum number of coder channels supported in the system */
# define IFX_MMGR_MAX_CODER_CHANNELS 			5
/*! \brief Maximum number of DECT channels supported in the system */
# define IFX_MMGR_MAX_DECT_CHANNELS	 			6
/*! \brief Maximum number of FXO channels supported in the system */
# define IFX_MMGR_MAX_FXO_CHANNELS 				1
/*! \brief Maximum number of PCM channels supported in the system */
# define IFX_MMGR_PCM_CHANNEL_NUM 				0

/*! \brief Country setting path where CRAM information is located */
# define IFX_MMGR_COUNTRYSETTINGS_PATH 		"/opt/ifx/downloads/ifx_country_settings/"
/*! \brief Country Name for India */
# define IFX_MMGR_COUNTRY_INDIA 					"India"
/*! \brief Country Name for China */
# define IFX_MMGR_COUNTRY_CHINA 					"China"
/*! \brief Country Name for Japan */
# define IFX_MMGR_COUNTRY_JAPAN 					"Japan"
/*! \brief Country Name for Taiwan */
# define IFX_MMGR_COUNTRY_TAIWAN 				"Taiwan"
/*! \brief Country Name for USA */
# define IFX_MMGR_COUNTRY_USA 					"USA"
/*! \brief Path for firmware */
# define IFX_MMGR_FIRMWARE_PATH 					"/opt/ifx/downloads/"
/*! \brief FXO device IRQ Number */
# define IFX_MMGR_FXODEV_IRQNUM 					95
/*! \brief FXO device Access mode */
# define IFX_MMGR_FXODEV_ACCESSMODE 			0

/*! \brief  BBD file ending when it is fxs specific */
#define TD_BBD_SUFIX_FXS    "fxs.bin"
/*! \brief BBD file ending when it is fxo specific */
#define TD_BBD_SUFIX_FXO    "fxo.bin"

#ifdef CONFIG_AR9 
/*! \brief PRAM file name. This will be present in IFX_MMGR_FIRMWARE_PATH */
# define IFX_MMGR_PRAM_FILE_NAME 				"ar9_firmware.bin"
/*! \brief CRAM file name for FXS endpoint(s) */
# define IFX_MMGR_FXS_CRAM_FILE_NAME 			"ar9_bbd_fxs.bin"
#endif
#ifdef CONFIG_DANUBE
# define IFX_MMGR_PRAM_FILE_NAME 				"danube_firmware.bin"
# define IFX_MMGR_FXS_CRAM_FILE_NAME 			"danube_bbd_fxs.bin"
#endif
#ifdef CONFIG_VR9
# define IFX_MMGR_PRAM_FILE_NAME 				"vr9_firmware.bin"
# define IFX_MMGR_FXS_CRAM_FILE_NAME 			"vr9_bbd_fxs.bin"
#endif
#ifdef CONFIG_AR10
# define IFX_MMGR_PRAM_FILE_NAME 				"xrx300_firmware.bin"
# define IFX_MMGR_FXS_CRAM_FILE_NAME 			"xrx300_bbd_fxs.bin"
#endif
/*! \brief CRAM file name for FXS endpoint(s) */
/*! \brief CRAM file name for FXO endpoint(s) */
# define IFX_MMGR_FXO_CRAM_FILE_NAME 			"fxocramfw.bin"
/*! \brief Country settings file name */
# define IFX_COUNTRYSETTINGS_FILENAME 			"Tone_Settings.txt"
/*! \brief PCM channel name */
# define IFX_MMGR_PCM_CHANNEL_NAME 				"/dev/vmmc11"
/*! \brief Maximum Device strings length */
# define IFX_MAX_DEV_STR_LEN 						32
/*! \brief Total coder, FXO and FXS device */
# define IFX_MAX_DEVICES 							7

/*FXO agent Configurations*/

/*! \brief Offhook duration for FXO Agent */
# define IFX_FXO_OFF_HK_WAIT_DURATION  		2000 /* in milliseconds */
/*! \brief Digit duration for FXO Agent */
# define IFX_FXO_LINE_DIGIT_DURATION     		100 /* in milliseconds */
/*! \brief Inter digit duration for FXO digit */
# define IFX_FXO_LINE_INTERDIGIT_DURATION 	100 /* in milliseconds */
/*! \brief Ringburst duration for FXO Agent */
# define IFX_FXO_RINGBURST_DURATION    		6000  /* in milliseconds */
/*! \brief Call retry duration FXO Agent. */
# define IFX_FXO_RETRY_DURATION      			6000 /* in milliseconds */
/*! \brief Dial wait duration for FXO Agent */
# define IFX_FXO_DIALWAIT_DURATION   			2000 /* in milliseconds */
/*! \brief hookflash duration for FXO Agent */
# define IFX_FXO_HOOKFLASH_DURATION   			80 /* in milliseconds */
/*! \brief Onhook wait duration for FXO Agent */
# define IFX_FXO_ON_HK_WAIT_DURATION   		80 /* in milliseconds */
/*! \brief Offhook CID duration for FXO Agent */
# define IFX_FXO_OFF_HK_CID_DURATION   		IFX_FXO_RINGBURST_DURATION 
																	/* in milliseconds */
/* Tone Configurations (for both FXS and FXO agent)*/

/*! \brief Dial tone duration in milliseconds */
# define IFX_DIAL_TONE_DURATION 					10000
/*! \brief Eror tone duration in milliseconds */
# define IFX_ERROR_TONE_DURATION 				10000 /*in milliseconds*/
/*! \brief Confirmation tone duration in milliseconds */
# define IFX_CONF_TONE_DURATION 					10000 /*in milliseconds*/
/*! \brief Busy tone duration in milliseconds */
# define IFX_BUSY_TONE_DURATION 					10000 /*in milliseconds*/
/*! \brief Ring tone duration in milliseconds */
# define IFX_RING_TONE_DURATION	          90000 /*in milliseconds*/
/*! \brief Ringback tone duration in milliseconds */
# define IFX_RINGBACK_TONE_DURATION 			85000 /*in milliseconds*/
/*! \brief Stutter tone duration in milliseconds */
# define IFX_STTR_TONE_DURATION 					5000 /*in milliseconds*/
/*! \brief Inter digit duration in milliseconds */
# define IFX_FULL_INTERDIGIT_DURATION 			4000 /*in miliseconds*/
/*! \brief Progressive interdigit duration in milliseconds */
# define IFX_PROGRESSIVE_INTERDIGIT_DURATION 2000 /*in miliseconds*/

/*! \brief Firewall script path */
# define IFX_FIREWALL_PATH 						"/root/"
/*! \brief Firewall script file name */
# define IFX_FIREWALL_CMD 							"./voip_port.sh"

/* @} */

# endif /*__IFX_CONFIG_H__*/
