/*****************************************************************************
 **   FILE NAME       :IFX_MediaMgr_If.h 
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : ATA Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **						exposed by the Media manager to the different agents
 **                     and the call manager.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

/*! \file IFX_MediaMgrIf.h
    \brief This File contains the constants, enumerations, data
    structures and functions for using the functionality provided
    by the Media Manager
*/
/** \addtogroup GW_APIs Gateway Application APIs
    \brief This section lists the functions provided by different modules
*/
/* @{ */


/** \defgroup MM_APIs Media Manager
	\brief This section lists the functions provided by the Media Manager
*/
/* @} */

/** \addtogroup MM_APIs Media Manager
	\brief This section lists the functions provided by the Media Manager
*/
/* @{ */
#ifndef __IFX_MMGR_IF__
#define __IFX_MMGR_IF__
/** \defgroup BASIC_TELEPHONY_SERVICES Basic Telephony Service
	\brief This section lists the basic telephony functionss. These functions 
	can be used by the agents for requesting for services like playing of 
	call progress tones, playing of DTMF digits, etc.
*/
/* @{ */
/*!
   \brief Maximum length of device channel name string.
*/
#define IFX_MMGR_MAX_CHANNEL_NAME 32

/*!
	\brief Enumeration containing the Media Manager return values
*/

typedef enum
{
	IFX_MMGR_NO_RESOURCE = -11,		/*!< No resource available */
    IFX_MMGR_MEMORY_ERROR=-10,			/*!< Memory allocation error */
	IFX_MMGR_OPERATIN_NOT_ALLOWED=-9,	/*!< Operation not allowed */
	IFX_MMGR_INVALID_RESOURCE_ID=-8,	/*!< Invalide Resource Identifier */
	IFX_MMGR_INVALID_PARAMETER=-7,		/*!< Invalid Parameter */
	IFX_MMGR_DSP_DEV_INIT_FAILED=-6,	/*!< DSP device Initialization error */
	IFX_MMGR_FXO_DEV_INIT_FAILED=-5,	/*!< FXO device Initialization error */
	IFX_MMGR_CHANNEL_INIT_FAILED=-4,	/*!< Channel Initialization error */
	IFX_MMGR_LM_INIT_FAILED=-3,		/*!< Load Manager Initialization error */
	IFX_MMGR_INIT_FAILED=-2,			/*!< Media manager Initialization error */
	IFX_MMGR_FAIL=-1,                  /*!< Operation Failure */
	IFX_MMGR_SUCCESS = 0			/*!< Operation Success */
}e_IFX_MMGR_Return;


/*!
    \brief Enumeration containing the type of codecs.
*/

typedef enum 
{
	IFX_MMGR_CODEC_NONE=0,
	IFX_MMGR_CODEC_ALAW=1,      /*!< Codec type ALAW */
	IFX_MMGR_CODEC_MLAW=2,      /*!< Codec type MLAW*/
	IFX_MMGR_CODEC_G729_AB=3,   /*!< Codec type g729 Annex AB */
	IFX_MMGR_CODEC_G729_E=4,    /*!< Codec type g729 Annex E */
	IFX_MMGR_CODEC_G723_5_3=5,  /*!< Codec type g723 5.3 kbps */
	IFX_MMGR_CODEC_G723_6_3=6,  /*!< Codec type g723 6.3 kbps */
	IFX_MMGR_CODEC_G728=7,      /*!< Codec type g728 */
	IFX_MMGR_CODEC_G726_16=8,   /*!< Codec type g726 16 kbps */
	IFX_MMGR_CODEC_G726_24=9,   /*!< Codec type g726 24 kbps */
	IFX_MMGR_CODEC_G726_32=10,   /*!< Codec type g726 32 kbps */
	IFX_MMGR_CODEC_G726_40=11,   /*!< Codec type g726 40 kbps */
	IFX_MMGR_CODEC_G722_64=12,   /*!< Codec type g722 64 kbps */
	IFX_MMGR_CODEC_G722_1_24=13, /*!< Codec type g722.1 24 kbps */
	IFX_MMGR_CODEC_G722_1_32=14, /*!< Codec type g722.1 32 kbps */
	IFX_MMGR_CODEC_ILBC=15,      /*!< Codec type iLBC */
	IFX_MMGR_CODEC_T38=16,       /*!< Fax Data pump */
	IFX_MMGR_CODEC_MAX=17 
}e_IFX_MMGR_CodecType;

typedef enum{
	IFX_MMGR_CODEC_PCM_G722_64=6,
	IFX_MMGR_CODEC_PCM_G726_32=9
}e_IFX_MMGR_PcmCodecType;

/*!
   \brief Maximum number of tokens
*/
#define IFX_MMGR_MAX_TOKEN 10

/*! 
    \brief  Structure containing the frequency and gain information 
			of a single frequency component of a tone.
	*/
typedef struct 
{
  char8 szFreqName[IFX_MMGR_MAX_TOKEN]; /*!< Name of the Frequency component. e.g F1,F2 */
  uint32 uiFrequency;				  /*!< Frequency Value */
  int32 iGain;                        /*!< Gain Value of the frequency component */
}x_IFX_MMGR_FreqGain;

/*!
   \brief Maximum number of frequency components in a tone
*/
#define IFX_MMGR_TONE_FREQ_COMP 4 
/*!
   \brief Maximum number of cadences in a tone
*/
#define IFX_MMGR_TONE_MAX_STEPS 6
/*!
    \brief Enumeration containing different types of tones.
*/
typedef enum
{
    IFX_MMGR_BUSY_TONE=0,             /*!< Busy Tone */
    IFX_MMGR_DIAL_TONE=1,             /*!< Dial Tone */
    IFX_MMGR_RING_BACK_TONE=2,        /*!< Ring back Tone */
    IFX_MMGR_STUTTER_DIAL_TONE=3,     /*!< Stutter Dial Tone */
    IFX_MMGR_CONFIRMATION_TONE=4,     /*!< Confirmation Tone */
    IFX_MMGR_OFF_HOOK_WARNING_TONE=5, /*!< Off Hook Warning Tone */
    IFX_MMGR_ERROR_TONE=6,            /*!< Error Tone */
    IFX_MMGR_PROMPT_TONE=7,           /*!< Prompt Tone */
    IFX_MMGR_RING_TONE=8,             /*!< Ring Tone */
    IFX_MMGR_CALL_WAITING_TONE=9,     /*!< Call Waiting Tone */
    IFX_MMGR_SEC_DIAL_TONE=10,         /*!< Second Dial Tone */
    IFX_MMGR_MAX_TONE=11               /*!< Maximum Tone */
}e_IFX_MMGR_ToneType;


/*! 
    \brief  Structure containing tone information for a type of tone.  Includes
	the frequency, gain and the cadencing information. 
	*/
typedef struct 
{

  e_IFX_MMGR_ToneType  eToneType;  /*!< Type of Tone */
  uchar8 ucNoOfFreqComp;          /*!< Number of frequency components */
  x_IFX_MMGR_FreqGain xFrequencies[IFX_MMGR_TONE_FREQ_COMP]; /*!< Frequency and 
														 gain information */
  uint32 uiNoOfCadences;          /*!< Number of cadence periods */ 
  /* Cadence duration .. cadence[0] is On Period */
  uint32  uiCadenceduration[IFX_MMGR_TONE_MAX_STEPS]; /*!< Duration of 
													each of the cadences */
  
  /* eg f1 + f2 */
  uint32  uiCadencePattern[IFX_MMGR_TONE_MAX_STEPS]; /*!< Cadence pattern 
												   information e.g. f1+f2 */
  uchar8 ucLoop;            /*!< Number of times the cadence pattern 
							has to be repeated */
  uint32 uiPause;           /*!< Pause duration before the
							next loop starts */    
  
  /* Index in the Tone table has a default value of -1 */
  uchar8 ucIndex;          /*!< Index of the tone */
  
}x_IFX_MMGR_Tone;

/*!
	\brief Enumeration containing Tx mode CID transmission types
*/
typedef enum 
{
	IFX_MMGR_ONHOOK=0,/*!< On-Hook CID-Type I*/
	IFX_MMGR_OFFHOOK=1/*!< Off-Hook CID-Type II*/
}e_IFX_MMGR_CidTxMode;

/*!
	\brief Enumeration for Rx mode CID transmission type
*/	
typedef e_IFX_MMGR_CidTxMode e_IFX_MMGR_CidRxMode;

/*!
	\brief Maximum caller name length
*/
#define IFX_MAX_CALLER_NAME      32
/*!
	\brief Maximum caller number length
*/
#define IFX_MAX_CALLER_NUMBER    50

/*! 
    \brief  Structure containing the CID data to be presented to the End point. 
	Consists of Caller name and number.
	*/
typedef struct
{
  e_IFX_MMGR_CidTxMode eTxType;/*!< CID Transmission Type*/
  char8 szCallerName[IFX_MAX_CALLER_NAME];/*!< Name of the Caller*/
  char8 szCallerNumber[IFX_MAX_CALLER_NUMBER];/*!< Phone Number of the caller*/
}x_IFX_MMGR_CidParams;

/*!
	\brief Enumeration describing the FSK Message types
*/
typedef enum
{
	IFX_MMGR_FSK_MSG_CALL_SETUP       = 0x80, /*!< Call Setup */
	IFX_MMGR_FSK_MSG_MSG_WAITING_IND  = 0x82, /*!< Message Waiting */
	IFX_MMGR_FSK_MSG_ADVICE_OF_CHARGE = 0x86, /*!< Advice of Charge */
	IFX_MMGR_FSK_MSG_SMS              = 0x89  /*!< SMS */
}e_IFX_MMGR_FSK_MsgType;

/*!
	\brief Enumeration describing the FSK Message Parameters
*/
typedef enum
{
	IFX_MMGR_FSK_PARAM_DATE               = 0x01, /*!< Date */
	IFX_MMGR_FSK_PARAM_CLI                = 0x02, /*!< CLI */
	IFX_MMGR_FSK_PARAM_CALLED_ID          = 0x03, /*!< CID */
	IFX_MMGR_FSK_PARAM_CLI_ABS_REASON     = 0x04, /*!< CLI absent reason */
	IFX_MMGR_FSK_PARAM_NAME               = 0x07, /*!< Name */
	IFX_MMGR_FSK_PARAM_NAME_ABS_REASON    = 0x08, /*!< Name absent reason */
	IFX_MMGR_FSK_PARAM_VISUAL_IND         = 0x0B, /*!< Visual Indicator */
	IFX_MMGR_FSK_PARAM_MSG_IND            = 0x0D, /*!< Message Indicator */
	IFX_MMGR_FSK_PARAM_LAST_MSG_CLI       = 0x0E, /*!< Last message in CLI */
	IFX_MMGR_FSK_PARAM_COMP_DATE          = 0X0F, /*!< Completion date */
	IFX_MMGR_FSK_COMP_CLI                 = 0X10, /*!< CLI */
	IFX_MMGR_FSK_PARAM_CALL_TYPE          = 0X11, /*!< Call  Type */
	IFX_MMGR_FSK_PARAM_FIRST_CLI          = 0X12, /*!< First CLI */
	IFX_MMGR_FSK_PARAM_NUM_OF_MSG         = 0X13, /*!< Number of messages */
	IFX_MMGR_FSK_PARAM_TYPE_OF_FWD_CALL   = 0X15, /*!< Type of Call forward */
	IFX_MMGR_FSK_PARAM_TYPE_OF_CALLER     = 0X16, /*!< Type of Caller */
	IFX_MMGR_FSK_PARAM_REDIRECTING_NUMBER = 0X1A, /*!< Redirecting Number */
	IFX_MMGR_FSK_PARAM_CHANRGE            = 0X20, /*!< Charge*/
	IFX_MMGR_FSK_PARAM_ADD_CHARGE         = 0X21, /*!< Add Charge */
	IFX_MMGR_FSK_PARAM_CALL_DURATION      = 0X23, /*!< Call Duration */
	IFX_MMGR_FSK_PARAM_NW_ID              = 0X30, /*!< Newtwork Id */
	IFX_MMGR_FSK_PARAM_CARRIER_ID         = 0X31, /*!< Carrier Id */
	IFX_MMGR_FSK_PARAM_SEL_OF_TERMINAL    = 0X40, /*!< Selection of Terminal */
	IFX_MMGR_FSK_PARAM_DISPLAY_INFO       = 0X50, /*!< Display Info */
	IFX_MMGR_FSK_PARAM_SERVICE_INFO       = 0X55, /*!< Service Info */
	IFX_MMGR_FSK_PARAM_EXTN               = 0XE0 /*!< Extension Parameter */
}e_IFX_MMGR_FSK_ParamType;

/*!
	\brief Maximum FSK Parameters
*/
#define IFX_MMGR_FSK_MAX_PARAMS 0xE1 

/*!
	\brief Enumeration containing the FSK Call Type
*/
typedef enum 
{
	IFX_MMGR_FSK_CALL_NORMAL_CALL = 1, /*!< Normal Call */
	IFX_MMGR_FSK_CALL_CCBS        = 2, /*!< CCBS */
	IFX_MMGR_FSK_CALLING_NAME_DEL = 3, /*!< Calling Name Delete */
	IFX_MMGR_FSK_CALL_RETURN      = 4, /*!< Call Return */
	IFX_MMGR_FSK_CALL_ALARM       = 5, /*!< Call Alarm */
	IFX_MMGR_FSK_DOWNLOAD_FUNC    = 6, /*!< Download Function */
	IFX_MMGR_FSK_REV_CHRG_CALL    = 7, /*!< Charging Call */
	IFX_MMGR_FSK_CALL_EXTERNAL    = 10, /*!< External Call */
	IFX_MMGR_FSK_CALL_INTERNAL    = 11, /*!< Internal Call */
	IFX_MMGR_FSK_CALL_MONOTORING  = 50, /*!< Monitoring */
	IFX_MMGR_FSK_CALL_MSG_WAITING = 81, /*!< Message Waiting */
}e_IFX_MMGR_FSK_CallType;

/*!
	\brief Enumeration containing the Call Forward Type
*/
typedef enum
{
	IFX_MMGR_FSK_FWD_UNKNOWN =0, /*!< Unknown Type */
	IFX_MMGR_FSK_FWD_ONBUSY=1, /*!< On Busy */
	IFX_MMGR_FSK_FWD_NOREPLY=2, /*!< No reply */
	IFX_MMGR_FSK_FWD_UNCOND=3, /*!< Unconditional */
	/* Deflected call after alerting */
	IFX_MMGR_FSK_FWD_DEF_CALL_ALERT=4, /*!< Deflect after altering */
	/* Deflected call immediately */
	IFX_MMGR_FSK_FWD_DEF_IMM=5, /*!< Deflect immediately */
	/* Forwarding in case of the mobile is unreachablr */
	IFX_MMGR_FSK_FWD_MOB_UNREACH=6 /*!< Mobile unreachable */
}e_IFX_MMGR_FSK_CallFwdType;

/*!
	\brief Structure describing the Calling User Type
*/
typedef enum
{
	IFX_MMGR_FSK_USER_UNKNOWN=0, /*!< User Unknown */
	IFX_MMGR_FSK_USER_VOICE_CALL=1, /*!< Voice Call User */
	IFX_MMGR_FSK_USER_TEXT_CALL=2, /*!< Text Call User */
	IFX_MMGR_FSK_USER_VPN=3, /*!< VPN User */
	IFX_MMGR_FSK_USER_MOBILE=4, /*!< Mobile User */
	IFX_MMGR_FSK_USER_FAX_CALL=5, /*!< Fax Call User */
	IFX_MMGR_FSK_USER_VIDEO_CALL=6, /*!< Video Call User */
	IFX_MMGR_FSK_USER_E_MAIL=7, /*!< Email User */
	IFX_MMGR_FSK_USER_OPERATOR=8, /*!< Operator */
	IFX_MMGR_FSK_USER_ORD_CALL_SUBS=9, /*!< Ordinary Call Subscriber */
	IFX_MMGR_FSK_USER_PRIORITY_CALL_SUBS=10, /*!< Priority Call Subscriber */
	IFX_MMGR_FSK_USER_DATA_CALL=11, /*!< Data Call User */
	IFX_MMGR_FSK_USER_TEST_CALL=12, /*!< Test Call User */
	IFX_MMGR_FSK_USER_TELEMETRIC_CALL=13, /*!< Telemetric Call User */
	IFX_MMGR_FSK_USER_PAYPHONE=14 /*!< Payphone User */
}e_IFX_MMGR_FSK_CallingUserType;

/*!
	\brief Structure describing the FSK Date and Time Info
*/
typedef struct
{
	uchar8 ucDay; /*!< Day */
	uchar8 ucMonth; /*!< Month */
	uchar8 ucHour; /*!< Hour */
	uchar8 ucMin; /*!< Minute */
	uchar8 ucSeconds; /*!< Seconds */
}x_IFX_MMGR_FSK_DateTime;

/*!
	\brief FSK Removed Message
*/
#define IFX_MMGR_FSK_REMOVED_MSG 0 
/*!
	\brief FSK Reference Message
*/
#define IFX_MMGR_FSK_REFERENCE_MSG 0X055 
/*!
	\brief FSK Added Message
*/
#define IFX_MMGR_FSK_ADDED_MSG 0XFF 

/*!
	\brief Structure describing the FSK Message Id
*/
typedef struct
{

	uchar8 ucMsgId; /*!< Message Id */
	uint16 unMsgRef; /*!< Message Reference */
}x_IFX_MMGR_FSK_MsgId;

/*!
	\brief FSK Normal Charge
*/
#define IFX_MMGR_FSK_CHARGE_NORMAL 0x1 
/*!
	\brief FSK Free Charge
*/
#define IFX_MMGR_FSK_CHARGE_FREE 0x2 
/*!
	\brief FSK Total Charge
*/
#define IFX_MMGR_FSK_CHARGE_TOTAL 0x4 
/*!
	\brief FSK Subtotal Charge
*/
#define IFX_MMGR_FSK_CHARGE_SUBTOTAL 0x8 
/*!
	\brief FSK Credit Card Charge
*/
#define IFX_MMGR_FSK_CHARGE_CREDIT_CARD 0x10 
/*!
	\brief FSK Available Charge Info
*/
#define IFX_MMGR_FSK_CHARGE_INFO_AVAIL 0x20 
/*!
	\brief FSK Unavailable Charge Info
*/
#define IFX_MMGR_FSK_CHARGE_INFO_UNAVAIL 0x40 
/*!
	\brief FSK Charge Current Amount
*/
#define IFX_MMGR_FSK_CHARGE_CURR_AMT 0x80 
/*!
	\brief FSK Charge Units
*/
#define IFX_MMGR_FSK_CHARGE_UNITS 0x100 
/*!
	\brief FSK Charge Current Call
*/
#define IFX_MMGR_FSK_CHARGE_CURR_CALL 0x200 
/*!
	\brief FSK Accumulated Charge
*/
#define IFX_MMGR_FSK_CHARGE_ACCU 0x400 
/*!
	\brief FSK Extra Charge
*/
#define IFX_MMGR_FSK_CHARGE_EXTRA 0x800 

/*!
	\brief Structure describing the FSK Charge Parameters
*/
typedef struct
{
	uchar8 aucCurrency[3]; /*!< Currency */
	uint32 uiCharge; /*!< Charge */
	uchar8 aucCharge[10]; /*!< Charge Parameters */
}x_IFX_MMGR_FSK_ChargeParam;

/*!
	\brief Structure describing the FSK Call Duration
*/
typedef struct
{
	uint16 unHr; /*!< Hour */
	uint16 unMin; /*!< Minute */
	uint16 unSec; /*!< Sec */
}x_IFX_MMGR_FSK_CallDuration;

/*!
	\brief FSK Display Information Length
*/
#define IFX_MMGR_FSK_DISP_INFO_LEN 253 
/*!
	\brief FSK Display Unknown
*/
#define IFX_MMGR_FSK_DISP_UNKNOWN 0 
/*!
	\brief FSK Display Acknowledgement
*/
#define IFX_MMGR_FSK_DISP_ACK 1 
/*!
	\brief FSK Display Negative Acknowledgement
*/
#define IFX_MMGR_FSK_DISP_NACK 3 
/*!
	\brief FSK Display Advice
*/
#define IFX_MMGR_FSK_DISP_ADV 4 
/*!
	\brief FSK Display Network Provider Info
*/
#define IFX_MMGR_FSK_DISP_NET_PROV_INFO 5 
/*!
	\brief FSK Display Provider Info
*/
#define IFX_MMGR_FSK_DISP_REM_PROV_INFO 6 

/*!
	\brief Structure describing FSK Display Information
*/
typedef struct
{
	uint32 uiFlag; /*!< Flag - one of IFX_MMGR_FSK_DISP_* */
	uchar8 aucDispInfo[IFX_MMGR_FSK_DISP_INFO_LEN]; /*!< Display Information */
}x_IFX_MMGR_FSK_DisplayInfo;

/*!
	\brief Structure describing the FSK Data
*/
typedef struct 
{
	e_IFX_MMGR_FSK_MsgType eMsgType; /*!< FSK Message Type - one of IFX_MMGR_FSK_MSG_* */
	e_IFX_MMGR_FSK_ParamType aeParams[IFX_MMGR_FSK_MAX_PARAMS]; /*!< FSK Parameters Type - one of IFX_MMGR_FSK_PARAM_* */
	void *apvParams[IFX_MMGR_FSK_MAX_PARAMS]; /*!< Array of FSK Parameters */
}x_IFX_MMGR_FSK_Data;

/*! 
    \brief  Structure containing the Codec information.  Information such as, 
	Codec, Packet(Frame) length and corresponding IANA payload type.
	*/
typedef struct
{
	e_IFX_MMGR_CodecType eCodecType;	/*!< Codec */
	uchar8 ucPacketLength;			   /*!< Packet (Frame) length in milliseconds */
	uchar8 ucIANA_PayloadType;		   /*!< IANA payload number of the codec */
}x_IFX_MMGR_CodecInfo;

/*!
	\brief Structure containing the whole list of Codecs with their complete information 
	*/
typedef struct
{
	uchar8 ucNoOfCodecs;   /*!< Number of codecs in the list */
	x_IFX_MMGR_CodecInfo axCodecs[IFX_MMGR_CODEC_MAX]; /*!< Array containing the codecs */
}x_IFX_MMGR_CodecList;

/*! 
    \brief      This function allocates a signaling resource (channel).  
	A signaling resource is required for establishing the telephony services
	like, playing tones, DTMF generation and detection, CID transmission
	and reception, etc.  This function is invoked by the agents, viz., the
	FXS and FXO agents.
    \param[in]  iEndptId Endpoint identifier
	\param[in]	pvParams Pointer to agent specific parameters
    \return     IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/


e_IFX_MMGR_Return IFX_MMGR_SigResAlloc(
									IN char8* iEndptId,
									IN void *pvParams
									);

/*! 
    \brief      This function frees a previously allocated signaling resource (channel).
	This function is invoked by agents when the signaling resource is no 
	longer required.  Typically, the signaling resources are not required after 
	the call is terminated.
    \param[in]  iEndptId Endpoint identifier
	\return     IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_SigResDealloc(
									  IN char8* iEndptId
									  );

/*! 
    \brief         This function adds a new tone to the tone table maintained
	in the media manager. An agent may define its own tone and register 
	it with the media manager, if it wants to use a tone which is different 
	from the predefined tones already available.The complete tone information 
	such as the frequency components, cadence information have to be 
	provided while invoking this function. 
    \param[in]     pxToneInfo Pointer to the structure defining the tone
	\param[out]    piIndex Pointer to the tone Index. This is an identifier 
			to the tone. 
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_ToneAdd(
						   IN x_IFX_MMGR_Tone *pxToneInfo,
						   OUT int32 *piIndex
						   );
/*! 
    \brief         This function removes a previously registered tone from the media manager.
	This function is invoked by the agents to remove only the tones registered 
	using the IFX_MMGR_ToneAdd function.
   	\param[in]     iIndex Identifier of the tone to be removed.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_ToneRemove(
	    							  IN int32 iIndex
		        					  );

/*! 
    \brief         This function plays a tone on a endpoint. In addition, it
	also transmits the CID to the endpoint if the type of tone requested 
	is IFX_MMGR_RING_TONE.  This function is invoked by the 
	agents when they have to play tones at the endpoints managed by them.
	\param[in]     pszEndptId Identifier of the endpoint
	\param[in]     eToneType Type of tone if it is preconfigured. Otherwise,
					index of the user defined tone
    \param[in]     pxCidparams Pointer to CID parameters. This parameter
				needs to be passed only if eToneType is IFX_MMGR_RING_TONE .
	\return        IFX_MMGR_SUCCESS , 
			IFX_MMGR_NO_RESOURCE incase no signaling resource was allocated 
			or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_TonePlay(
							IN char8* pszEndptId,
							IN e_IFX_MMGR_ToneType eToneType,
							IN x_IFX_MMGR_CidParams *pxCidparams
							);

/*! 
    \brief         This function stops a tone currently being played at an endpoint.
	The agents call this function to stop a tone.
	\param[in]     pszEndptId Endpoint identifier.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
	
e_IFX_MMGR_Return IFX_MMGR_ToneStop(
							IN char8* pszEndptId
							);


/*! 
    \brief         This function gives the durartion of one Ring cadence.
	\param[out]     piTime pointer to Integer .
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_RingCadenceTimeGet(
								IN int32 *piTime
								);
/*!
    \brief         This function generates the DTMF tones.  The agents
	use this function to generate the DTMF tones.  This function is also
	used by the FXO agent to generate DTMF tones to the PSTN.
    \param[in]     pszEndptId Endpoint identifier
	\param[in]     ucDigit ASCII value of digit whose DTMF tone has to be played.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no signaling 
			resource was allocated or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfPlayLocal(
								 IN char8* pszEndptId,
								 IN uchar8 ucDigit
								 );

/*!
    \brief         This function stops the currently being played DTMF tone. 
    \param[in]     pszEndptId Endpoint identifier
	\return        IFX_MMGR_SUCCESS 
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfStopLocal(
								 IN char8* pszEndptId
								 );

/*!
    \brief         This function plays a DTMF tone on a connection.  This means 
	that the DTMF tone is generated to the remote party. This function is 
	used to play the DTMF tones to the remote VoIP party.  
    \param[in]     iResourceId Identifier of the resource.
	\param[in]	   pszRemoteId Remote Party Id
	\param[in]     pszLocalId Local Party Id
	\param[in]     ucDigit ASCII value of digit whose DTMF tone has to be played.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no coder 
			resource was allocated or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfPlayRemote(
								  IN int32 iResourceId,
									IN char8* pszRemoteId,
									IN char8* pszLocalId,
								  IN uchar8 ucDigit
								  );

/*!
    \brief         This function stops a currently playing DTMF tone on the network side. 
    \param[in]     iResourceId Identifier of the resource.
	\return        IFX_MMGR_SUCCESS 
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfStopRemote(
								  IN int32 iResourceId
								  );
/*! 
    \brief         This function starts the CID reception on a FXO Line.
	This function is invoked by the FXO agent after detecting a ring event in 
    			   the FXO interface.
  	\param[in]     pszEndptId FXO Line Id.
	\param[in]     eCidRxMode Mode of CID Reception (OffHook/OnHook)
 	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no
				   signaling resource was allocated or IFX_MMGR_FAIL
 */

e_IFX_MMGR_Return IFX_MMGR_CidRxStart(
							  IN char8* pszEndptId,
							  IN e_IFX_MMGR_CidRxMode eCidRxMode
							  );
/*! 
    \brief         This function stops the CID reception on a FXO Line.
  	\param[in]     pszEndptId FXO Line Id.
 	\return        IFX_MMGR_SUCCESS
 */

e_IFX_MMGR_Return IFX_MMGR_CidRxStop(
							  					IN char8* pszEndptId
					 							);
/*! 
    \brief         This function starts the CID transmission on a FXS endpoint.
	This function is invoked by the FXS agent to display the CID of an incoming 
	call.
   	\param[in]     pszEndptId Endpoint identifier.
	\param[in]     pxCidParams Pointer to CID parameters
 	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no
				   signaling resource was allocated or IFX_MMGR_FAIL
 */

e_IFX_MMGR_Return IFX_MMGR_CidTxStart(
							  IN char8* pszEndptId,
							  IN x_IFX_MMGR_CidParams *pxCidParams
							  );
/*! 
    \brief         This function starts the Call progress tone detection on a FXO Line.
		The FXO agent may invoke this function to detect the tones played
		from the PSTN end.  The detection is followed by reporting of the event 
		to the FXO Agent through the event reporting services of the media manager.
		This function shall be invoked only after a successful allocation of a 
		signaling resource through IFX_MMGR_SigResAlloc function.	   
	\param[in]     pszEndptId FXO Line Id.
	\param[in]     eToneType The tone to be detected.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no 
				   signaling resource was allocated or IFX_MMGR_FAIL.
*/

e_IFX_MMGR_Return IFX_MMGR_CptdStart(
							 IN char8* pszEndptId,
							 IN e_IFX_MMGR_ToneType eToneType
							 );
/*!
   \brief This function stops the Call progress tone detection on a FXO Line.  
   The FXO Agent invokes this function when Call Progress tone detection is 
   no longer needed.
	
   \param[in]  pszEndptId FXO Line Id.
   \return        IFX_MMGR_SUCCESS
  */	
e_IFX_MMGR_Return IFX_MMGR_CptdStop(
							 IN char8* pszEndptId
							 );

/*! 
    \brief         This function sets the FXO Line into Off Hook State.  This
	function is invoked by the FXO Agent to setup/answer an outgoing/incoming 
	call(s) to PSTN.
	\param[in]     pszEndptId FXO Line Id.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_OffHookSet(
							  IN char8* pszEndptId
							  );
/*! 
    \brief         This function sets the FXO Line into On Hook State.  This
	function is invoked by the FXO Agent to terminate the call to PSTN.
	\param[in]     pszEndptId FXO Line Id.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_OnHookSet(
							 IN char8* pszEndptId
							 );
/*! 
    \brief         This function sends the Hook Flash event on the FXO Line 
	to the PSTN.  This function is invoked by the FXO Agent to put calls with PSTN on
	hold.  Typically, the hook flash event is a combination of an onhook 
	and an offhook within the timing limits governing the hook status in PSTN.
	\param[in]     pszEndptId FXO Line Id.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_HookFlashSet(
							 IN char8* pszEndptId
							 );

/*! 
    \brief         This function sends out the FSK data transparently.  
	This function is invoked by the FXS agent to send the FSK data to the 
	device connected to the FXS port.   This function is also invoked by the
	FXO Agent to send the FSK data on the FXO Line to the PSTN.  The data 
	exchange through FSK data is required to realise the PSTN SMS feature.
	This function shall be invoked only after a successful allocation of a 
	signaling resource through IFX_MMGR_SigResAlloc function.
	\param[in]     pszEndptId Endpoint identifier.
	\param[in]     pucData Pointer to FSK data buffer
	\param[in]     iDataSize Size/Length of the FSK data
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_FSKDataSnd(
							 IN char8* pszEndptId,
							 IN uchar8* pucData,
							 IN int32 iDataSize
							 );
							 

/*! 
    \brief         This function receives the FSK data transparently.  
	This function is invoked by the FXO Agent to receive the FSK data on the 
	FXO Line from the PSTN.  This function is also invoked by the FXS agent to 
	receive the FSK data from the device connected to the FXS port.   
	This function shall be invoked only after a successful allocation of a 
	signaling resource through IFX_MMGR_SigResAlloc function.
	\param[in]     pszEndptId Endpoint identifier.
	\param[in,out] pxFsk Pointer to FSK data buffer
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_FSKDataRcv(
							 IN char8* pszEndptId,
							 IN_OUT x_IFX_MMGR_FSK_Data  *pxFsk
							 );
							 
/*! 
    \brief         This function sets the line feed on the FXS to standby.  
	This function is invoked by the FXS agent to put the FXS channel to power  
	saving mode i.e. Stand by mode whenever the user goes on-hook.   
	\param[in]     pszEndPtId Endpoint identifier.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
 e_IFX_MMGR_Return IFX_MMGR_SetFxsToStandBy(
								 IN char8* pszEndPtId
								 );
/*! 
    \brief         This function sets the line feed on the FXS to Active.  
	\param[in]     pszEndPtId Endpoint identifier.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
 e_IFX_MMGR_Return IFX_MMGR_SetFxsToActive(
								 IN char8* pszEndPtId
								 );


/*! 
    \brief         This function gets the APOH (Another Phone Off Hook) status on a line.  
	This function is invoked by the FXO Agent during the system restart to know 
	if there is an ongoing call with the PSTN using the hardware relay based 
	connection.
	\param[in]     pszEndptId FXO Line id.
	\param[in,out] puiApohStatus Pointer to APOH status.  One of IFX_MMGR_EVENT_APOH or 
				   IFX_MMGR_EVENT_NOPOH
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_ApohStatusGet(
										 IN char8* pszEndptId,
										 IN_OUT uint32 *puiApohStatus
										 ); 

/*! 
    \brief         This function activates a DECT channel resource previously
	obtained using a IFX_MMGR_DectResAlloc call.  This function is invoked by the DECT 
	agent, after the codecs have been negotiated for a call involving the DECT
	endpoint.  This function configures a codec from the codec list and enables
	encoding/decoding on the DECT channel.
	\param[in]     pszEndPtId DECT Endpoint Id
	\param[in] 	   pxCodec DECT Codec List
	\param[in] 	   bECOn Echo Cancelation flag
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DectResActivate(IN char* pszEndPtId ,
					   IN x_IFX_MMGR_CodecInfo *pxCodec, IN boolean bECOn);

/*! 
    \brief         This function deactivates a previously allocated DECT channel.  This 
	function is invoked by the DECT agent, when the DECT call has to be put on hold or muted
	or during the release of the call.
	\param[in]     pszEndPtId DECT Endpoint Id
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/					   
e_IFX_MMGR_Return IFX_MMGR_DectResDeActivate(IN char* pszEndPtId);

/*! 
    \brief         This function reserves a DECT channel resource from the available
	resource pool.  This function is invoked by the DECT agent, when it has to setup a
	call involving the DECT endpoint.  
	\param[in]     pszEndPtId DECT Endpoint Id
	\param[out]    puiChNum DECT Channel Number
	\param[in] 	   pxCodec DECT Codec List
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DectResAlloc(IN char* pszEndPtId ,
	   				OUT uint16 *puiChNum ,
					IN_OUT x_IFX_MMGR_CodecList *pxCodec);

/*! 
    \brief         This function releases a DECT channel resource previously
	reserved using a IFX_MMGR_DectResAlloc call.  This function is invoked by the DECT 
	agent, during a release of a call involving the DECT endpoint.
	\param[in]     pszEndPtId DECT Endpoint Id
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DectResDealloc(IN char8* pszEndPtId);



/* @} */

/** \defgroup MEDIACONTROL_SERVICES Media Control Service
	\brief This section lists the Media control functions. These functions 
	are used by the Call Manager to request for allocation of
	resources to set up a call, configure the media settings,
	establish and breaks the voice paths.
*/
/* @{ */

/*!
	\brief Enumeration containing different types of calls 
	*/
typedef enum
{
	IFX_MMGR_CALL_EXTN_EXTN=0,  /*!< Extension to Extension call */
	IFX_MMGR_CALL_EXTN_VOIP=1,  /*!< Extension to VOIP call */
	IFX_MMGR_CALL_VOIP_EXTN=2,  /*!< VOIP to Extension call */
	IFX_MMGR_CALL_FXO_VOIP=3,	  /*!< FXO to VOIP call */
	IFX_MMGR_CALL_VOIP_FXO=4,   /*!< VOIP to FXO call */
	IFX_MMGR_CALL_FXO_EXTN=5,   /*!< FXO to Extension call */
	IFX_MMGR_CALL_EXTN_FXO=6    /*!< Extension to FXO call */
}e_IFX_MMGR_TypeOfCall;

/*!
    \brief Enumeration containing the type of DTMF/telephony events transmission.
*/

typedef enum
{
	/* No event to be transmitted */
	IFX_MMGR_TEL_EVENT_NONE=0,        /*!< No event to be transmitted */
	/* Events to be transmitted voice in-band */
	IFX_MMGR_TEL_EVENT_VOICE_IN_BAND=1, /*!< Events to be transmitted voice inband
									*/
	/* Events to be transmitted using RFC 2833 */
	IFX_MMGR_TEL_EVENT_RFC_2833=2, /*!< Events to be transmitted using RFC 2833 */
	IFX_MMGR_TEL_EVENT_VOICE_IN_BAND_RFC_2833=3 /*!< Events to be transmitted voice 
											inband as well as using RFC 2833 
											*/
}e_IFX_MMGR_TelephonyEvent;

/*!
    \brief Enumeration containing the action to be taken when a RFC 2833 Event
	packet is received.
*/
typedef enum
{
	/* Play the received RFC 2833 packets */
	IFX_MMGR_TEL_EVENT_PLAY = 1, /*!< Play the received RFC 2833 packets */
	/* Mute the received RFC 2833 packets */
	IFX_MMGR_TEL_EVENT_MUTE =2/*!< Mute the received RFC 2833 packets */
}e_IFX_MMGR_RFC2833_Rx_Action;


/*!
   \brief Definition for the Fixed jitter buffer type
 */
#define IFX_MMGR_JB_TYPE_FIXED 1
/*!
   \brief Definition for the Adaptive jitter buffer type
 */
#define IFX_MMGR_JB_TYPE_ADAPTIVE 2

/*!
   \brief Jitter Buffer adapted for voice, reduced adjustment
   speed and packet repetition is off.
 */
#define IFX_MMGR_PACKET_ADAPT_VOICE 2
/*!
   \brief Jitter Buffer adapted for data (fax/modem). Reduced
   adjustment speed and packet repetition is on.
 */
#define IFX_MMGR_PACKET_ADAPT_DATA 3

/*! 
    \brief  Structure containing the Jitter Buffer information 
	*/

typedef struct
{

	uchar8 ucJBType;           /*!< Jitter Buffer Type */

	/* Packet Adaptation */
	uchar8 ucPacketAdaptation; /*!< Packet adaptation. Value could be 
							   either IFX_MMGR_PACKET_ADAPT_VOICE or
							   IFX_MMGR_PACKET_ADAPT_DATA */
	uchar8 ucLocalAdpt;       /*!< Local Adaptation */  
	uchar8 ucscaling;         /*!< This factor influences the play out delay.
								If ucPacketAdaptation is 1, ucScaling multiplied by the
								packet length determines the play out delay. If
								ucPacketAdaptation is 0, the play out delay is calculated
								by the multiplication of the estimated network
								jitter and nScaling. ucscaling can be chosen
								between 1 and 16. */
	uint16 unInitialSize;     /*!< Initial size of the jitter buffer in timestamps of
							  125 µs in case of an adaptive jitter buffer.*/
	uint16 unMaxSize;         /*!< Maximum size of the jitter buffer in timestamps
							   of 125 µs in case of an adaptive jitter buffer.*/
	uint16 unMinSize;         /*!< Minimum size of the jitter buffer in timestamps
								of 125 µs in case of an adaptive jitter buffer.*/
}x_IFX_MMGR_JitterBuffer_Conf;

/*! 
    \brief  Structure containing the DTMF/Telephony event configuration for a RTP Session
*/

typedef struct
{
	e_IFX_MMGR_TelephonyEvent eEventTransMode; /*!< DTMF/Telephony Event Transmission mode */
	/* This is only Valid if the transmission mode 
	 * is IFX_MMGR_TEL_EVENT_RFC_2833 
	 */
	uchar8 ucPayLoadTypeTx;  /*!< DTMF/Telephony Event payload type, valid 
						   only if the transmission mode is 
						   IFX_MMGR_TEL_EVENT_RFC_2833 */
	uchar8 ucPayLoadTypeRx;  /*!< DTMF/Telephony Event payload type, valid 
						   only if the transmission mode is 
						   IFX_MMGR_TEL_EVENT_RFC_2833 */
	e_IFX_MMGR_RFC2833_Rx_Action eAction; /*!< Action to be taken when a 
										RFC2833 packet is received */
}x_IFX_MMGR_TelephonyEvent_Info;

/*!
   \brief Start Encoding for the session.
 */
#define IFX_MMGR_START_ENCODING 0x01
/*!
   \brief Stop Encoding for the session.
 */
#define IFX_MMGR_STOP_ENCODING 0x02
/*!
   \brief Stop Decoding for the session.
 */
#define IFX_MMGR_STOP_DECODING 0x04
/*!
   \brief Update the Codec List for the session
 */
#define IFX_MMGR_UPDATE_CODEC_LIST 0x08
/*!
   \brief Set the encoder type for the media session 
 */
#define IFX_MMGR_SET_ENC_TYPE 0x010
/*!
   \brief Enable the VAD (Voice Activity Detection) for the session 
 */
#define IFX_MMGR_SID_ACTIVATE 0x020
/*!
   \brief Configure the Telephony event mechanism 
 */
#define IFX_MMGR_TELEPHONY_EVENT_CONFIG 0x40
/*!
   \brief Configure the Jitter buffer for the session 
 */
#define IFX_MMGR_JB_CONFIGURE 0x080
/*!
   \brief Cross-Connect the channels, for internal calls
 */
#define IFX_MMGR_XCONNECT 0x0100
/*!
   \brief Dis-Connect the channels, for internal calls
 */
#define IFX_MMGR_XDISCONNECT 0x200


/*! 
    \brief  Structure containing the information to Start/Modify a media session.
*/
typedef struct
{

	/* Bit field to contain the actions mentioned above */
	uint32 uiOptions; /*!< Bit mask of actions to be performed for a media session */
	x_IFX_MMGR_JitterBuffer_Conf xJBCfg; /*!< Jitter buffer information,
									   should be populated if the uiOptions 
									   contains IFX_MMGR_JB_CONFIGURE */
	x_IFX_MMGR_CodecList xCodecList; /*!< List of codecs to be 
													   used for a media session */
	x_IFX_MMGR_CodecInfo xEncCodec; /*!< Set the Encoder type */
	x_IFX_MMGR_TelephonyEvent_Info xTelEventInfo; /*!< Information about handling of
							telephony/DTMF events on the transmission path */
}x_IFX_MMGR_MediaParams;

/*! 
    \brief  Structure containing the RTP session information.
*/
typedef struct
{
	char8 szDevChannelName[IFX_MMGR_MAX_CHANNEL_NAME]; /*!< Device name of the coder channel */
	uint32 uiSSRC;  /*!< SSRC */
	uint16 unSeqNo; /*!< Sequence Number */
}x_IFX_MMGR_SessionInfo;

/*! 
    \brief         This function reserves all the resources required for a call.  
	This function is invoked by the Call manager during the call setup.  Based 
	on the inputs, this function finds out the type of resources required for the 
	call and reserves them.  In addition, before reservation of the resources, 
	the load manager is checked for the cumulative CPU load the resources 
	would take.  The resources are allocated as per the load available. 
	In case of FXS-FXS internal call this function pre-allocates the LEC 
	algorithms on both the FXS channels and in the case of FXS-VOIP call it 
	allocates a coder channel to the FXS channel and updates the 
	load manager with the new value of CPU usage.  In the case of DECT to
	VoIP call, two codec lists have to be provided, one list, to be used for the 
	Coder channel and the second list to be used for the DECT channel.
	These type of call field, determines the usage of the lists.  For other
	types of calls, the codec lists can be NULL.
	
	This function also supports the forking feature for a VOIP/FXO incoming call(s).
	This function may be called multiple times with the same resource identifier
	to achieve the forking feature.
				   
	\param[in,out] piResourceId Identifier of the resource context.
	\param[in,out] piiAdditionalResourceId Additional identifier of the same 
			resource context.  This parameter should be non zero, for reusing 
			an already allocated resource context. It means the same resource 
			can be identified with two different resourceIds.
    \param[in]     bGenerateAddId Flag to indicate that a additional resourceId has to be 
	               generated.
	\param[in]     pszFromId Endpoint Identifier of the call call initiating end.
	\param[in]     pszToId Endpoint Identifier of the call call terminating end.
	\param[in]     eCall Type of call (VOIP/NON_VOIP)
	\param[in,out] paxCodecList1 Pointer to the codec list 1.  	   
		This also returns the actual list of codecs that could be used for the call.
	\param[in,out] paxCodecList2 Pointer to the codec list 2.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL or IFX_MMGR_NO_RESOURCE
*/


e_IFX_MMGR_Return IFX_MMGR_ResReserveForCall(IN_OUT int32 *piResourceId,
								   OUT int32 *piiAdditionalResourceId,
								   IN boolean bGenerateAddId,
								   IN_OUT char8* pszFromId,
								   IN char8* pszToId,
								   IN e_IFX_MMGR_TypeOfCall eCall,
								   IN_OUT x_IFX_MMGR_CodecList *paxCodecList1,
								   IN_OUT x_IFX_MMGR_CodecList *paxCodecList2

								   );
/*! 
    \brief         This function frees all the resources that was reserved 
	for a call.  This function is invoked by the Call Manager while terminating a call.
	This function, deallocates the resources and frees the load usage for 
	that resource context.  A resource is identified by the 
	tuple (iResourceId, iFromId, iToId).
				   
  	\param[in]     iResourceId Identifier of the resource context.
	\param[in]     pszFromId Endpoint Identifier of the call call initiating end.
	\param[in]     pszToId Endpoint Identifier of the call call terminating end.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForCall(
								IN int32 iResourceId,
								IN char8* pszFromId,
								IN char8* pszToId
								);

/*! 
    \brief         This function transfers the resource context from an endpoint
	to another.  In particular, a coder resource attached to an endpoint is 
	detached from there and attached to another endpoint without any loss
	in the configuration of the resource.  This function is invoked by the 
	Call Manager during the VoIP Call Transfer scenarios.
   	\param[in]     pszFromId Endpoint Identifier of the call initiating end.
	\param[in]     pszToId Endpoint Identifier of the call terminating end.
	\param[in]     iResourceId Identifier of the resource context.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_ResMove(
								IN char8* pszFromId,
								IN char8* pszToId,
								IN int32 iResourceId
								);

/*! 
    \brief         This function configures the media for a call. The media 
	configuration has to be done for setting up the voice path for a call. 
	For internal calls this function sets up a voice path between the endpoints 
	by cross-connecting the resources. For VOIP calls a RTP session has to be 
	established. The media configuration needs to be done before starting a RTP
	session. This function configures the coder channel with the list of 
	codecs provided, enables the VAD if requested, configures the 
	telephony event parameters, configures the jitter buffer and starts 
	the encoder/decoder on the coder channel. This function is invoked
	by the Call Manager during the call setup.
   	\param[in]     iResourceId Identifier of the resource context.
	\param[in]     pxMediaParams Pointer to media parameters.
	\param[out]     pxSessionInfo Pointer to Session Info.
	This function generates the ssrc and the sequence number for the RTP 
	session.  The out parameter structure contains the ssrc and sequence 
	number of the RTP stream for VoIP calls.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/

e_IFX_MMGR_Return IFX_MMGR_MediaCfg(
							 IN int32 iResourceId,
							 IN x_IFX_MMGR_MediaParams *pxMediaParams,
							 OUT x_IFX_MMGR_SessionInfo *pxSessionInfo
							 );
/*!
    \brief         This function modifies the media parameters for an ongoing media session.
	This function helps realising features like call hold and call resume. 
	Some of the  modification options could be breaking a existing internal 
	voice path, holding and resuming a VOIP call and updating the codec for a 
	VOIP call.  This function is invoked by the Call Manager to realise some
	of the supplementary call features.
   	\param[in]     iResourceId Identifier of the resource context.
	\param[in]     pxMediaParams Pointer to media parameters.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/

e_IFX_MMGR_Return IFX_MMGR_MediaModify(
							 IN int32 iResourceId,
							 IN x_IFX_MMGR_MediaParams* pxMediaParams
							 );

/*!
    \brief         This function configures the firmware to mix voice streams.  
	This function is used to realise the voice path during conferencing scenarios
	where, the system acts as a voice mixer.  This function configures the 
	connections between the resources in such a way to realise the mixing.  
	The Call Manager invokes this function when setting up n-party conferences.
    \param[in]     pszEndPtId Endpoint Id of the initiator.
    \param[in,out]     piConfernceId Conference identifier
    \param[in]     iNoOfParties Number of participants 
	\param[in]     paiResourceId Pointer to array of resourceIds 
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_MixingEnable(
										IN char8* pszEndPtId,
										IN_OUT int32 *piConfernceId,
										IN int32 iNoOfParties,
										IN int32 *paiResourceId
										);
/*!
    \brief         This function configures the firmware to stop mixing of voice 
	streams.  The Call Manager invokes this function when disabling the 
	n-party conference.
    \param[in]     iConfernceId Conference identifier
    \param[in]     iNoOfParties Number of participants 
	\param[in]     paiResourceId Pointer to array of resourceIds 
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_MixingDisable(
										IN int32 iConfernceId,
										IN int32 iNoOfParties,
										IN int32* paiResourceId
										);
										
#ifdef UDP_REDIRECT
/*!
    \brief         This function stops the packet flow within a RTP redirected channel and
	disables the channel.  The RTP agent calls this function when the RTP session is being 
	closed.  
    \param[in]     iResId Resource Identifier
    \param[in]     uiLocalPort Local Port Number 
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_QosStop(int32 iResId,uint16 uiLocalPort);

/*!
    \brief         This function activates the packet flow within a RTP redirected channel.
	Prior to the calling of this function, the IFX_MMGR_QosStart function should have been 
	invoked with success.  The RTP agent invokes this function after the media path is completely 
	established and the encoders/decoders are enabled.
    \param[in]     iResId Resource Identifier
    \param[in]     uiLocalPort Local Port Number  
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_QosActivate (int32 iResId,uint16 uiLocalPort);

/*!
    \brief         This function enables the start of a RTP redirected session.  The 
	RTP redirected session, provides a mechanism to deliver packets from/to TAPI and TCP/IP
	stack within the kernel mode, thereby reducing a context switch to the user space.  
	The RTP Agent invokes this function during the creation of a RTP session.
	\param[in]     iResId Resource Identifier
	\param[in]     uiLocalIp Local IP Address
    \param[in]     uiLocalPort Local Port Number  
	\param[in]     uiRemIP Remote IP Address
    \param[in]     uiRemPort Remote Port Number  
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_QosStart (int32 iResId, uint32 uiLocalIp, uint16 uiLocalPort,
                                     uint32 uiRemIP,uint16 uiRemPort);
#endif
/* @} */

/** \defgroup Misc_API  Misc Service
	\brief This section lists the Miscellaneous functions of the Media Manager. 
	This consists of the initialization functions of the media manager and the 
	event reporting functions.
*/
/* @{ */

/*!
	\brief Enumeration containing the CID standards
	*/
typedef enum
{
	IFX_MMGR_CID_STD_TELCORDIA=0, /*!< CID Standard telcordia */
	IFX_MMGR_CID_STD_ETSI=1, /*!< CID Standard ETSI */
	IFX_MMGR_CID_STD_NTT=2, /*!< CID Standard NTT */
	IFX_MMGR_CID_STD_SIN=3 /*! CID Standard SIN */
}e_IFX_MMGR_CidStd;
/*!
	\brief Structure containing the DSP device parameters
	*/
typedef struct
{
	uchar8 temp; /*!< Temporary */
}x_IFX_MMGR_DspDevParam;

/*!
	\brief Structure containing FXO Interface parameters 
	*/
typedef struct
{
	uchar8 ucIrqNum;    /*!< Irq number to be used by the FXO (Linux) device */
	int32 iAccessMode;  /*!< Access mode */
}x_IFX_MMGR_FxoDevparam;
/*!
   \brief Union containing Device Initialization Parameters 
	*/
typedef struct
{
	x_IFX_MMGR_DspDevParam xDspParam;   /*!< DSP device initialization parameters */
	x_IFX_MMGR_FxoDevparam xFxoParam;   /*!< FXO device initialization parameters */
}ux_IFX_MMGR_Device_Params;		  
/*!
   \brief Structure containing information on a device channel 
	*/
typedef struct
{
	char8 szDeviceName[IFX_MMGR_MAX_CHANNEL_NAME]; /*!< Device control channel name */
	ux_IFX_MMGR_Device_Params uxDevParams;         /*!< Device initialization parameters */
}x_IFX_MMGR_Device_Info;

/*!
    \brief  Structure containing initialization parameters for the Media Manager. 
	This structure also contains information about the resource channel(s). 
	*/
typedef struct
{
   
	char8 bIsWideBandEnabled; /*!< Flag indicating whether wideband is enabled or 
						     disabled */
	char8 bIsLecEnabled;   /*!< Flag indicating whether LEC is enabled or 
						    disabled */
	char8 cLecTailLength; /*!< LEC tail length in ms if LEC is enabled */
	uint32  uiCodec; /*!< Codec that is currently selected on
							   the DECT channel. This field is not valid for FXS/FXO channel */
	uchar8 ucPcmChToBeUsed; /*!< The PCM channel number to be used for the FXO channel */
}x_IFX_MMGR_ChannelParams;

/*!
	\brief Structure containing resource information to be used along with 
	FXS endpoints
*/
typedef struct 
{
	char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN]; /*!< Endpoint Indentifier associated with this 
						     resource. This is valid only for 
							 FXS/FXO/DECT resource */
	int32 iInterfaceId; /*!< Interface Id of the channel. This value 
							cannot be changed for a particular resource */ 
	uint16 unChannelNum;  /*!< TAPI channel number */
	char8  szChannelName[IFX_MMGR_MAX_CHANNEL_NAME];/*!< Name of the device 
									channel which identifies the resource */
	boolean bIsWideBandEnabled; /*!< Flag indicating whether wideband is enabled or 
						     disabled */
	boolean bIsLecEnabled;   /*!< Flag indicating whether LEC is enabled or 
						    disabled */
	char8 cLecTailLength; /*!< LEC tail length in ms if LEC is enabled */
	int16 unVolumeLevel; /*!< Volume level (Gain Rx as well as Tx). */
}x_IFX_MMGR_FXS_ResourceInfo;
/*!
   \brief Structure containing the FXS Resource information and the number of instances of it. 
   This structure is required during media manager initialization  
 */
typedef struct
{
	uint16 unNoOfFxsResources;   /*!< Number of FXS Resources */
	x_IFX_MMGR_FXS_ResourceInfo *pxFxsInfo; /*!< Pointer to FXS Resource Info */
	uchar8* pucFw; /*!< Pointer to the Voice firmware */
	int32 iFWSize; /*!< Size of the firmware buffer*/
	uchar8* pucCoeffcient; /*!< CRAM coefficients */
	int32 iCoefficientSize; /*!< Size of the CRAM coefficients buffer*/
}x_IFX_MMGR_FXS_Resources;


/*!
	\brief Structure containing FXO resource Information
*/
typedef struct 
{
	char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN]; /*!< Endpoint Indentifier associated with this 
						     resource. This is valid only for 
							 FXS/FXO/DECT resource */
	int32 iInterfaceId; /*!< Interface Id of the channel. This value 
							cannot be changed for a particular resource */ 
	char8  szChannelName[IFX_MMGR_MAX_CHANNEL_NAME];/*!< Name of the device 
									channel which identifies the resource */
    uint16 unChannelNum;     /*!< TAPI channel number */
	uint16 unPcmChannelNum;   /*!< TAPI PCM channel number to be used */
	char8 szPcmChannelName[IFX_MMGR_MAX_CHANNEL_NAME]; /*!< Channel Name */
	boolean bIsLecEnabled;    /*!< Flag indicating whether LEC is enabled or 
						    disabled */
	uchar8 ucLecTailLength; /*!< LEC tail length in ms if LEC is enabled */
	int16 unVolumeLevel; /*!< Volume level (Gain Rx as well as Tx). */
}x_IFX_MMGR_FXO_ResourceInfo;

/*!
	\brief Structure containing the FXO Resource information and the number of instances of it. 
   This structure is required during media manager initialization
*/
typedef struct
{
	uint16 unNoOfFxoResources;   /*!< Number of FXO Resources */
	x_IFX_MMGR_FXO_ResourceInfo *pxFxoInfo; /*!< Pointer to FXO Resource Info */
	uchar8* pucCoefficient; /*!< Pointer to the DUSLIC coefficients buffer */
	int32 iCoefficientSize; /*!< Size of the DUSLIC coefficients buffer */
}x_IFX_MMGR_FXO_Resources;

/*!
	\brief Structure containing information on the Coder resource of the 
	voice firmware 
	*/
typedef struct 
{
	
	char8  szChannelName[IFX_MMGR_MAX_CHANNEL_NAME];/*!< Name of the device 
									channel which identifies the resource */
	uint16 unChannelNum;     /*!< TAPI channel number */
}x_IFX_MMGR_Coder_ResourceInfo;

/*!
	\brief Coder resource info and its number of instances.
	*/
typedef struct
{
	uint16 unNoOfCoderResources;   /*!< Number of Coder Resources */
	x_IFX_MMGR_Coder_ResourceInfo *pxCoderInfo; /*!< Pointer to Coder Resource Info */
	uchar8* pucFw; /*!< Pointer to the firmware */
	int32 iFWSize; /*!< Size of the firmware */
	uchar8* pucCoeffcient; /*!< CRAM coefficients buffer */
	int32 iCoefficientSize; /*!< Size of the CRAM coefficient buffer*/
}x_IFX_MMGR_Coder_Resources;

/*! 
	\brief Structure containing the information on the DECT Resource
	*/

typedef struct 
{
	
	char8  szChannelName[IFX_MMGR_MAX_CHANNEL_NAME];/*!< Name of the device 
									channel which identifies the resource */
	int16 unVolumeLevel; /*!< Volume level (Gain Rx as well as Tx). */
	x_IFX_MMGR_CodecInfo xCodec; /*!< Default codec */
	uint16 unChannelNum;     /*!< TAPI channel number */
	int32 iInterfaceId; /*!< Interface Id */
}x_IFX_MMGR_DECT_ResourceInfo;



/*!
   \brief Structure containing the information on the number of DECT resources 
	*/
typedef struct
{
	uint16 unNoOfDectResources;    /*!< Number of instance of DECT resource */
	x_IFX_MMGR_DECT_ResourceInfo *pxDectInfo; /*!< Array of the resource information */
	uchar8* pucFW; /*!< Pointer to Firmware */
	int32 iFWSize; /*!< Size of the firmware */
}x_IFX_MMGR_DECT_Resources;

/*!
	\brief Structure containing the configuration parameters for each country
	*/

typedef struct 
{

  /* Tone Settings */
  x_IFX_MMGR_Tone axTones[IFX_MMGR_MAX_TONE]; /*!< Array of tone information */
  uint16 unNoOfTones;                         /*!< Number of tones */
  /* On Hook validation duration */
  uint32 uiOnHookMaxDuration;                 /*!< Max On-hook validation duration */
  uint32 uiOnHookMinDuration;				  /*!< Min On-hook validation duration */
  /* Off Hook validation duration */
  uint32 uiOffHookMaxDuration;				  /*!< Max Off-hook validation duration */
  uint32 uiOffHookMinDuration;                /*!< Min Off-hook validation duration */
  /* Hookflash validation duration */
  uint32 uiHookFlashMaxDuration;              /*!< Max Hook flash validation duration */
  uint32 uiHookFlashMinDuration;              /*!< Min Hook flash valiation duration */
  e_IFX_MMGR_CidStd eCidStd ;				  /*!< CID standard */
}x_IFX_MMGR_CountrySettingsParams;

/*! 
    \brief  Structure containing more initialization parameters for the Media Manager. 
	This structure contains information on all the resources read from the topology file. 
	*/
typedef struct
{
   x_IFX_MMGR_Device_Info xDSPDevice; /*!< DSP Device Information */
	x_IFX_MMGR_Device_Info xFXODevice; /*!< FXO Device Information */
	x_IFX_MMGR_DECT_Resources xDectRes; /*!< DECT channel Information */
	x_IFX_MMGR_FXS_Resources xFxsRes;   /*!< FXS channel Information */
	x_IFX_MMGR_FXO_Resources xFxoRes;   /*!< FXO channel Information */
	x_IFX_MMGR_Coder_Resources xCoderRes; /*!< Coder channel Information */
	x_IFX_MMGR_CountrySettingsParams xSettingparams; /*!< Country settings params */
}x_IFX_MMGR_InitParams;

/*!
	\brief Maximum number of devices
	*/
#define IFX_MMGR_MAX_DEVICES 2

/*!
	\brief Structure containing an array of open file descriptions
	*/
typedef struct
{
    int32 aiFd[IFX_MMGR_MAX_DEVICES]; /*!< Array of open file descriptors */
    uchar8 ucNoOfFds;                 /*!< Number of fds */
}x_IFX_MMGR_FdSet;

/*!
   \brief OFFHOOK event on a channel(FXS)
*/
#define IFX_MMGR_EVENT_OFFHOOK 0x01
/*!
   \brief ONHOOK event on a channel(FXS)
*/
#define IFX_MMGR_EVENT_ONHOOK 0x02
/*!
   \brief HOOK_FLASH event on a channel(FXS)
*/
#define IFX_MMGR_EVENT_HOOK_FLASH 0x04
/*!
   \brief Ring burst Start event on a channel(FXO)
*/
#define IFX_MMGR_EVENT_RING_START 0x08
/*!
   \brief Ring burst Stop event on a channel(FXO)
*/
#define IFX_MMGR_EVENT_RING_STOP 0x010
/*!
   \brief Occurence of a digit event on a channel(FXS/FXO)
*/
#define IFX_MMGR_EVENT_DIGIT 0x020
/*!
   \brief Event indicating an end of reception of CID data 
*/
#define IFX_MMGR_EVENT_CID_DATA 0x40

/*!
   \brief Fax DIS Event on a channel(FXS)
*/
#define IFX_MMGR_EVENT_FAXMODEM_DIS 0x80
/*!
   \brief Fax CED Event on a channel(FXS)
*/
#define IFX_MMGR_EVENT_FAXMODEM_CED 0x100
/*!
   \brief Fax CNG Event on a channel(FXS)
*/
#define IFX_MMGR_EVENT_FAXMODEM_CNGFAX 0x0200
/*!
   \brief GR909 test data ready event on a channel(FXS)
*/
#define  IFX_MMGR_EVENT_LT_GR909_READY 0x0400
/*!
   \brief Event indiating a successful tone detection
*/
#define IFX_MMGR_EVENT_TONE_DETECTION_END 0x0800
/*!
   \brief Event indicating a start of a CID reception sequence
*/
#define IFX_MMGR_EVENT_CID_RX_CAS 0x01000
/*!
	\brief Event indicating another phone offhook (APOH).
*/
#define IFX_MMGR_EVENT_APOH 0x2000
/*!
	\brief Event indicating no phones are offhook.
*/
#define IFX_MMGR_EVENT_NOPOH 0x4000 
/*!
	\brief Event indicating no phones are offhook.
*/
#define IFX_MMGR_EVENT_GR909_RESULT 0x8000 
/*!
	\brief Maximum number of DTMF digits 
*/
#define IFX_MMGR_MAX_DIGITS 20

/*!
	\brief Structure containing the GR909 Results 
*/

/** GR909 Results */
typedef struct 
{

   /** Valid results flag */
   uint32 uiValidResult;
   /** Passed flag according to valid flag */
   uint32 uiPassedResult;
   /** HPT AC RING wire to GND result */
   float32 nHPT_AC_R2G;
   /** HPT AC TIP wire to GND result */
   float32 nHPT_AC_T2G;
   /** HPT AC TIP wire to RING wire result */
   float32 nHPT_AC_T2R;
   /** HPT DC RING wire to GND result */
   float32 nHPT_DC_R2G;
   /** HPT DC TIP wire to GND result */
   float32 nHPT_DC_T2G;
   /** HPT DC TIP wire to RING wire result */
   float32 nHPT_DC_T2R;
   /** FEMF AC RING wire to GND result */
   float32 nFEMF_AC_R2G;
   /** FEMF AC TIP wire to GND result */
   float32 nFEMF_AC_T2G;
   /** FEMF AC TIP wire to RING wire result */
   float32 nFEMF_AC_T2R;
   /** FEMF DC RING wire to GND result */
   float32 nFEMF_DC_R2G;
   /** FEMF DC TIP wire to GND result */
   float32 nFEMF_DC_T2G;
   /** FEMF DC TIP wire to RING wire result */
   float32 nFEMF_DC_T2R;
   /** RFT RING wire to GND result */
   float32 nRFT_R2G;
   /** RFT TIP wire to GND result */
   float32 nRFT_T2G;
   /** RFT TIP wire to RING wire result */
   float32 nRFT_T2R;
   /** ROH TIP wire to RING wire result for low voltage */
   float32 nROH_T2R_L;
   /** ROH TIP wire to RING wire result for high voltage */
   float32 nROH_T2R_H;
   /** RIT result */
   float32 nRIT_RES;
#if 0
  /** Stored open loop resistance tip to ring [Ohm] (out). */
   float32          OLR_T2R;
   /** Stored open loop resistance tip to ground [Ohm] (out). */
   float32          OLR_T2G;
   /** Stored open loop resistance ring to ground [Ohm] (out). */
   float32          OLR_R2G;
#endif
} x_IFX_MMGR_GR909_Result;

/*!
	\brief Enumeration listing the GR909 Frequencies 
*/

typedef enum 
{
   /** EU/Europe like countries */
   IFX_MMGR_GR909_EU_50HZ = 0, 
   /** US like countries */
   IFX_MMGR_GR909_US_60HZ=1
} e_IFX_MMGR_GR909_Freq;

/*!
	\brief Enumeration listing the GR909 Test Types
*/

typedef enum 
{
   /** Hazardous Potential Test */
   IFX_MMGR_GR909_HPT  = 0x1,
   /** Foreign Electromotive Forces Test */
   IFX_MMGR_GR909_FEMF = 0x2,
   /** Resistive Faults Test */
   IFX_MMGR_GR909_RFT  = 0x4,
   /** Receiver Offhook Test */
   IFX_MMGR_GR909_ROH  = 0x8,
   /** Ringer Impedance Test */
   IFX_MMGR_GR909_RIT  = 0x10
} e_IFX_MMGR_GR909_TestType;

/*!
	\brief Structure containing the GR909 Test Parameters 
*/
typedef struct 
{
    e_IFX_MMGR_GR909_Freq   eFreq; /*!< One of values from e_IFX_MMGR_GR909_Freq */
    uint32                uiTests; /*!< One of values from e_IFX_MMGR_GR909_TestType */
} x_IFX_MMGR_GR909_Param;


/*! 
    \brief  Structure containing information of events occuring on a device. 
	*/
typedef struct 
{

   char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN]; /*!< Identifier of the endpoint for which the
								   event has occured */
   uint32 uiEvents;             /*!< Bit mask of all the events */
   uchar8 ucNoOfDigits;         /*!< Number of digit events */
   uchar8 aucDigits[IFX_MMGR_MAX_DIGITS]; /*!< Array containing all the digits */
   x_IFX_MMGR_GR909_Result xGR909Result; /*!< GR909 test reults */
}x_IFX_MMGR_DeviceEvents;

/*! 
    \brief      This function initializes the Media Manager.  All the topology 
	information needs to provided while invoking this function.  This function 
	has to be invoked during system initialization.
    \param[in]  pxInitParams Pointer to the initialization parameters
	\param[in]  iDbgId Module Debug Id
	\param[out] pxFdSet Pointer to Voice engine devices 
					descriptors
    \return     IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/

e_IFX_MMGR_Return IFX_MMGR_Init(
						IN x_IFX_MMGR_InitParams *pxInitParams,
                        IN int32 iDbgId,
                        OUT x_IFX_MMGR_FdSet *pxFdSet
						);
/*! 
    \brief      This function reconfigures the parameters on a channel interface.  
	The parameters are for example, Endpoint Ids, Wideband flag, Codec to be
	used for DECT channels, etc.  
	    \param[in]  iInterfaceId Interface Id of the channel.
	\param[in]  pszEndPtId Endpoint identifier.
	\param[in]  pxChannelParams Pointer to channel parameters.
    \return     IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_ChannelReCfg(
	                                      IN int32 iInterfaceId,
										  IN char8* pszEndPtId,
										  x_IFX_MMGR_ChannelParams* pxChannelParams);

/*!
    \brief          This function returns the events occuring on a device.  The events
	for a device are collected through their file descriptors.
	all the events that occured on a device.
    \param[in]      iFd File descriptor of the open control device.
	\param[in,out]  pxEventInfo Pointer to the event info.
	\param[in,out]  punNoOfEndPts Pointer to the number of endpoints on
	                which the events have occured.
    \return         IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/										  
e_IFX_MMGR_Return IFX_MMGR_DeviceEventsGet(
                           IN int32 iFd,
                           IN_OUT x_IFX_MMGR_DeviceEvents *pxEventInfo,
						   IN_OUT int32 *punNoOfEndPts
                           );
						   

/*! 
    \brief         This function starts the GR909 testing on one of the FXS ports.  
	\param[in]     pszEndptId Endpoint identifier.
	\param[in]     pxParam Test parameters
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_GR909TestStart(
							 IN char8* pszEndptId,
							 IN x_IFX_MMGR_GR909_Param  *pxParam
							 );

/* CVoIP PCM Chanel configuration */

typedef struct{
	//uchar8 ucChanelId;
	int32 nTimeslotTX;
	int32 nTimeslotRX;
	boolean bWidebandEnabled; //PP supprts wideband ??
}x_LTQ_CVOIP_PcmConfig;


#endif
/* @} */

/* @} */
