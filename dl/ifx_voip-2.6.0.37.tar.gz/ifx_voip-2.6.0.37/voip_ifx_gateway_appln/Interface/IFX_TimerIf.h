/*****************************************************************************
 **   FILE NAME       : IFX_TimerIfc.h 
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Timer Module 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/April/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains APIs and callback functions needed 
 **                     to support Timer Module.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_TIMER__
#define __IFX_TIMER__

/*! \file IFX_TimerIf.h
    \brief This file contains functions and callback functions needed to support
	 Timer Interface Module.
*/

/** \addtogroup UTIL_APIs Utilities
	\brief This section lists the functions provided for various utilities
*/
/* @{ */
/** \defgroup TIMER_INTERFACE_APIs Timer Service
	\brief This section defines the services provided by the Timer interface module.
*/

/* @{ */

/*! 
	\brief	This is the timer callback function.  This function is implemented
	by the module, requesting for services from the Timer module.  This function
	pointer needs to be passed to the Timer module when requesting for a timer 
	to be started.  This function will be called back when the timer expires.
	\param[in] uiTimerId The timer Id of the Timer which is expired.  
	\param[in] pvPrivateData Pointer to Data given by 
					the module which triggered the timer
	\return 	void No Value
*/
typedef void (*pfn_IFX_TIM_TimerCallBack)(
	                 IN uint32 uiTimerId,
	                 IN void* pvPrivateData );

/*!
	\brief 		This function initializes the Timer Interface module.
	This function is invoked when the timer module is initialized.
	\param[in] 	szFifoName Name of fifo to be used by timer interface module	       
	\param[out] puiFifoFd Fifo descriptor is returned in this parameter. Caller 
	           	of this function should wait for this fd and when ready for reading,
	           	call IFX_TIM_TimerMsgReceived to process and invoke timer callback.
	\return 		If timer initialization is success IFX_SUCCESS is returned, else
	        		IFX_FAILURE is returned.
*/
e_IFX_Return IFX_TIM_Init(
	             IN char8* szFifoName,
	             OUT uint32* puiFifoFd );


/*!
	\brief 		This function shuts down the timer interface module. 
	\return 		void No Value
*/
void IFX_TIM_Shut();

/*!
	\brief  This function indicates the availability of a message in the Timer FIFO.
	This function must be called when there is data available for reading in 
	        the fifo descriptor passed during initialization. This functions reads the fifo
	        data and invokes the appropriate timer callback function.
	\param[in] iTimFd Timer Fifo Fd that is used for reading the 
	        timer message.
	\return If returned IFX_FAILURE, then something wrong with timer interface module
	        and caller should reinitialize this module.
*/
e_IFX_Return IFX_TIM_TimerMsgReceived( IN int32 iTimFd);


/*! 
	 \brief       This function starts a timer.  This function is called  by
	 modules to start a timer. The modules can start more than one timer. 
	 \param[in]   uiTimeOut     Time out value in milliseconds.
	 \param[in]   pvPrivateData Private data of the caller. Timer module does not 
	              modify this data.
	 \param[in]   uiPrivateDataLen Length of the private data. If length is zero
	              no data will be copied, only pointer (pvPrivateData) value will
	              be passed into timer callback function.
	 \param[in]   pfnTimerCallBack Pointer to Timer call back function
	 \param[out]  puiTimerId On success, this contains the Timer Id. 
		This Id is unique and should be used to stop timer and also when timer fires.
	 \return 	  On success returns IFX_SUCCESS otherwise IFX_FAILURE.
*/
e_IFX_Return IFX_TIM_TimerStart(
			  IN uint32 uiTimeOut,
			  IN void* pvPrivateData,
			  IN uint16 uiPrivateDataLen,
			  IN pfn_IFX_TIM_TimerCallBack pfnTimerCallBack,
			  OUT uint32* puiTimerId
			 );

/*! 
	 \brief  This function stops a previously started timer.  
	 The modules invoke this function to stop the timer that was started 
	 by invoking IFX_TIM_StartTimer.  If timer had fired already or if the 
	 Timer Id is wrong, this function returns failure.
	 \param[in] uiTimerId  Timer Id of the timer to be stopped.
	 \return On success returns IFX_SUCCESS otherwise IFX_FAILURE.
*/
e_IFX_Return IFX_TIM_TimerStop(
			 IN uint32 uiTimerId
			 );

/* @} */
/* @} */
#endif /*__IFX_TIMER__*/
