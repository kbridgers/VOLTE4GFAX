/***********************************************************************
*   SRC_FILE           : IFX_MsgRtr.c
*   PROJECT            : Voip Gateway Subsystem
*   MODULES            : Gateway Application
*   SRC VERSION        : V1.0
*   DATE               : 21/05/2007
*   AUTHOR             : Gw Appln Team
*   DESCRIPTION        :
*   FUNCTIONS          :
*   COMPILER           : mips(el)-linux-gcc
*   REFERENCE          :
*   COPYRIGHT          :Copyright © 2004
*                       Infineon Technologies AG
*                       St. Martin Strasse 53; 81669 München, Germany
*   DESCLAIMER         :Any use of this Software is subject to the conclusion
*                       of a respective License Agreement.
*                       Without such a License Agreement no rights to the
*                       Software are granted.
*   Version Control Section
*   $Author$ 
*   $Date$
*   $Revisions$
*   $Log$       Revision history
***********************************************************************/

#ifndef __MSGRTR_IF_H__
#define __MSGRTR_IF_H__

/*! \file IFX_MsgRtrIf.h
    \brief This file contains the functions and callback functions provided by Message
	Router
*/

/** \addtogroup GW_APIs Gateway Application APIs
    \brief This section lists the functions provided by different modules
*/
/* @{ */


/** \defgroup MSG_RTR_APIs Message Router
	\brief This section lists the functions provided by the Message Router
          for registering Agents, that require notification on events  
		  either from TAPI or from their FIFO(s).
*/

/* @{ */

/*!
   \brief Enumeration containing the types of file descriptors
*/

typedef enum
{
    IFX_MSGRTR_READ_TYPE=1,		/*!< Indicates the read FD */
    IFX_MSGRTR_WRITE_TYPE=2,		/*!< Indicates the write FD */
    IFX_MSGRTR_EXCEPTION_TYPE=4	/*!< Indicates the exception FD */

} e_IFX_MSGRTR_FdType;

/*!
   \brief Structure containing the file descriptor number and the type of
   FDSET in which it has to be added
 */

typedef struct
{
    uint32				uiFd;		/*!< The Fd that has to be added to the select*/
    e_IFX_MSGRTR_FdType eFdSetType;	/*!< Read/Write/Exception set*/	

} x_IFX_MSGRTR_FdInfo;


/*!
   \brief This callback function is implemented by the agents, hence agent
   specific.  The agents register this function alongwith one or more FDs for 
   listening on, in the select system call.  Whenever there is some activity on 
   the FD, this callback would be invoked by the Message Router on the agent.
   \param[in] iFd File descriptor on an activity is detected
   \return     IFX_SUCCESS or IFX_FAILURE
 */

typedef e_IFX_Return (*pfn_IFX_MSGRTR_FdCallback) ( IN int32 iFd );

/*
 *this is available only for SIP Network Agent and not to any other agents
 */
 
/*!
   \brief This callback function is implemented by the SIP Agent.  The SIP Agent 
   registers this function alongwith one or more FDs for 
   listening on, in the select system call.  Whenever there is some activity on 
   the FD, this callback would be invoked by the Message Router on the SIP Agent.
   \param[in] pxReadFdSet Pointer to the FDSET array of Read File Descriptors
   \param[in] pxWriteFdSet Pointer to the FDSET array of Write File Descriptors
   \param[in] pxExcFdSet Pointer to the FDSET array of Exception File Descriptors
   \param[in] piNumFds Pointer to the array of File Descriptors
   \return     IFX_SUCCESS or IFX_FAILURE
 */ 
typedef e_IFX_Return (*pfn_IFX_MSGRTR_SipFdCallback)(
											IN fd_set *	pxReadFdSet, 
											IN fd_set *	pxWriteFdSet, 
											IN fd_set *	pxExcFdSet, 
											IN int32  * piNumFds );

/*!
   \brief This callback function is implemented by the agents, hence agent
   specific.  The FXS and FXO agents register this function alongwith one 
   or more TAPI FDs for listening on, in the select system call.  
   Whenever there is some activity on the TAPI FD, this callback would be 
   invoked by the Message Router on the (FXS/FXO) agent.
   \param[in] pxDevEvents The TAPI event structure for the endpoint
   \return     IFX_SUCCESS or IFX_FAILURE
 */

typedef e_IFX_Return (*pfn_IFX_MSGRTR_EventCallback) ( 
											IN x_IFX_MMGR_DeviceEvents	*pxDevEvents);

/*!
   \brief This function registers the callback function with the Message Router.
   This function is invoked by agents who require a notification on reception of 
   events/messages on a FIFO or Socket FD. The Callback function registered through this function, is invoked 
   when there is an event/message on any of the registered set of FDs.
   \param[in] paxFdInfo Pointer to array of FD info structures that
              contain the FD and its type.
   \param[in] ucNumFds Number of FDs in the array of FD info structures
   \param[in] pfnFdCallback Pointer to the callback function 
   \return     IFX_SUCCESS or IFX_FAILURE
 */

e_IFX_Return 
IFX_MSGRTR_FdCallBackRegister(  
                                IN x_IFX_MSGRTR_FdInfo          *paxFdInfo,
                                IN uchar8                       ucNumFds,
                                IN pfn_IFX_MSGRTR_FdCallback    pfnFdCallback);

/*!
   \brief This function unregisters a previously registered FD from the Message 
   Router.  This function is invoked by agents when the registered file descriptor is 
   no longer valid or applicable.  
   \param[in] pxFdInfo Pointer to FD info structure that needs to be unregistered
   \return     IFX_SUCCESS or IFX_FAILURE
 */

PUBLIC e_IFX_Return
IFX_MSGRTR_FdUnregister(
                        IN x_IFX_MSGRTR_FdInfo   *pxFdInfo);
/*!
   \brief This function registers the callback function with the Message Router.
   This function is invoked by FXS/FXO agents who require a notification on reception of 
   events on a TAPI FD. The Callback function registered through this function, is invoked 
   when there is an event on any of the registered set of TAPI FDs.
    \param[in] aszEndptId Pointer to array of Endpoint IDs of FXS/FXO agent(s).
   \param[in] ucNumEndpts Number of endpoints.
   \param[in] pfnEventCallback Pointer to the callback function
   \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return 
IFX_MSGRTR_EventCallBackRegister( 
          IN char8                        aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
          IN uchar8                       ucNumEndpts,
          IN pfn_IFX_MSGRTR_EventCallback pfnEventCallback);

/*!
   \brief This function unregisters a previously registered FD from the Message 
   Router.  This function is invoked by the FXS/FXO agent(s) when the registered 
   file descriptor is no longer valid or applicable. After successful execution 
   of this function, no more events are reported on this endpoint.
   \param[in] aszEndptId Pointer to array of Endpoint ID of FXS/FXO agent(s).
   \param[in] ucNumEndpts The number of endpoints
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return
IFX_MSGRTR_EventCallBackUnregister(
          IN char8		aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
          IN uchar8   ucNumEndpts);

/*Available only for SIP NA
*/
/*!
   \brief This function registers the callback function with the Message Router.
   This function is invoked by SIP Agent that requires notifications on reception of 
   events on its FDs. The Callback function registered through this function, is invoked 
   when there is an event on any of the registered set of FDs.
    \param[in] pxFdInfo Structure containing the information on the FDs
   \param[in] pfnCallBack Callback function being registered
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return 
IFX_MSGRTR_SipFdCallBackRegister(  
                                IN x_IFX_MSGRTR_FdInfo          *pxFdInfo,
                                IN pfn_IFX_MSGRTR_SipFdCallback pfnCallBack );

/*Available only for DECT  Agent
*/
/*!
   \brief This function registers the callback function with the Message Router.
   This function is invoked by Dect Agent that requires notifications on reception of 
   events on its FDs. The Callback function registered through this function, is invoked 
   when there is an event on any of the registered set of FDs.
    \param[in] pxFdInfo Structure containing the information on the FDs
   \param[in] pfnCallBack Callback function being registered
   \return     IFX_SUCCESS or IFX_FAILURE
*/

PUBLIC e_IFX_Return 
IFX_MSGRTR_DectFdCallBackRegister(  
                                IN x_IFX_MSGRTR_FdInfo          *pxFdInfo,
                                IN pfn_IFX_MSGRTR_SipFdCallback pfnCallBack );

/* @} */
/* @} */

#endif /* __MSGRTR_IF_H__ */
