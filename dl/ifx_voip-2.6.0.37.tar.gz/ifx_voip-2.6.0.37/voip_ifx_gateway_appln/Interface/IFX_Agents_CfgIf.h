/*****************************************************************************
 **   FILE NAME       : IFX_Agents_CfgIf.h
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Agent 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains the functions and the data structures 
 **                     needed by Agnets to get/set configuration parameters.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef _IFX_AGENT_EXT_H__
#define _IFX_AGENT_EXT_H__

/*! \file IFX_Agents_CfgIf.h
	\brief This file contains configuration service functions for Agents.
*/

/** \ingroup CONFIG_API
        \defgroup CIF_AGENT Configuration Service for the Agents
    	\brief This section describes the Configuration APIs defined
        for the usage of the Agents.
*/

/* @{ */

/*! \brief Structure containing the FXS endpoint information and the FXO information */
typedef struct {
   int32 iInterfaceId; /*!< Interface Id*/
   char8  szChannelName[IFX_MAX_DEV_STR_LEN]; /*!< Channel name */
   boolean bIsWideBandEnabled; /*!< Wideband Capability Flag */
   boolean bIsLecEnabled; /*!< Line Echo Cancellation Flag*/
   char8 cLecTailLength; /*!< LEC tail length*/
   int16 unVolumeLevel; /*!< Volume Level */
}x_IFX_CIF_FxResourceInfo;

/*! \brief Enumeration of Agent's state */
typedef enum {
	IFX_AGENT_STATE_IDLE=0,   /*!< Idle State */
	IFX_AGENT_STATE_ACTIVE=1, /*!< Active State */
	IFX_AGENT_STATE_BUSY=2,   /*!< Busy State */
}e_IFX_AgentState;

/*! \brief Structure containing Agent's status */
typedef struct {
	e_IFX_AgentState eState; /*!< Agent FSM state */
}x_IFX_AgentStatus;

/*!
	\brief This function initializes the Configuration Interface (CIF) 
	and the MAPI Extensions for Voice (MAPI-V). This function has to be called
	before usage of CIF functions.  The Configuration Agent invokes this 
	function during the system initialization procedure.
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CIF_Init(void);

/*!
	\brief This function retrieves the FXS endpoint's/FXO Line's resource information.
	\param[in] szEndptId FXS/FXO Line Id.
	\param[in] pxFxResInfo Pointer to x_IFX_CIF_FxResourceInfo. On successful
	      return, this contains endpoint resource information.
	\param[out] peReason Reason code.  During failure, this indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE Failure to retrieve data or Endpoint Id is not correct.
		   
 */
e_IFX_Return IFX_CIF_FxEndptResInfoGet(
	               IN char8* szEndptId,
	               OUT x_IFX_CIF_FxResourceInfo* pxFxResInfo,
	               OUT e_IFX_ReasonCode* peReason );
/*!
	\brief This function retrieves the physical device list.
	\param[in] ucSize Size of the aszDeviceList array.
	\param[out] aszDeviceList Array to hold device list strings. This must be 
	      large enough to hold IFX_MAX_DEVICES device strings.
	\param[out] peReason Reason code.  On failure, this indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE Failure to retrieve data or Endpoint Id is not correct
 */
e_IFX_Return IFX_CIF_DeviceListGet(
								 IN uchar8 ucSize,
	               OUT char8 aszDeviceList[][IFX_MAX_DEV_STR_LEN],
	               OUT e_IFX_ReasonCode* peReason );
				   
/* Duplicated declaration - Doxygen comments removed */

e_IFX_Return IFX_CIF_EndptCodecListGet(
	               IN char8* szEndptId, 
	               OUT x_IFX_CodecList* pxCodecParams,
	               OUT e_IFX_ReasonCode* peReason  );
/*!
	\brief This function retrieves the Voice Profile identifier list.
	\param[out] pucProfileId Array of Profile Ids.
	\return IFX_SUCCESS or IFX_FAILURE
 */
				   
e_IFX_Return
IFX_CIF_ProfileIdListGet(uchar8 *pucProfileId);

/*!
	\brief This function retrieves the endpoints of a particular type.
	
	\param[in] eEpType Endpoint type
	\param[in,out] pucSize Size of the aszEndptList array. The number of 
	      endpoints in aszEndptList is returned.
	\param[out] aszEndptList Array to hold Endpoint Ids. 
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE Failure to retrieve config data or if pucSize is not 
			enough to hold endpoints
 */
e_IFX_Return IFX_CIF_EndptListGet(
	                 IN e_IFX_EndptType eEpType,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszEndptList[][IFX_MAX_ENDPOINTID_LEN],
									 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief Macro to retrieve all the FXS endpoints. 
 */
#define IFX_CIF_FxsEndptListGet(pucSize,aszEndptList, peReason) \
	              IFX_CIF_EndptListGet(IFX_EP_FXS,pucSize, \
	                                      aszEndptList, peReason)
/*!
	\brief Macro to retrieve all the FXO interfaces. 
 */
#define IFX_CIF_FxoEndptListGet(pucSize,aszEndptList, peReason) \
	              IFX_CIF_EndptListGet(IFX_EP_FXO,pucSize, \
	                                      aszEndptList, peReason)

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
/*!
	\brief Macro to retrieve all the DECT handsets. 
 */
#define IFX_CIF_DectEndptListGet(pucSize,aszEndptList, peReason) \
	              IFX_CIF_EndptListGet(IFX_EP_DECT,pucSize, \
	                                      aszEndptList, peReason)
#endif

/*!
	\brief This function updates the endpoint data.  This function
	shall be invoked only by the Configuration Agent.
	\param[in] szOldEndptId Old Endpoint Id.
	\param[in] szNewEndptId New Endpoint Id. If not changed, pass szOldEndptId.
	\param[in] ucDefaultVL Default Voice Line for the endpoint
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS
		  IFX_FAILURE - This function fails only if invalid szOldEndptIf is passed.
 */
e_IFX_Return IFX_CIF_EndptDataUpdate(
	                 IN char8* szOldEndptId,
	                 IN char8* szNewEndptId,
	                 IN uchar8 ucDefaultVL,
	                 OUT e_IFX_ReasonCode* peReason);


/*!
	\brief This function updates the all endpoints default line ids.  This function
	shall be invoked only by the Configuration Agent.
	\return IFX_SUCCESS This function always return success.
 */
e_IFX_Return IFX_UpdateEnptDefaultLine();

/*!
	\brief This function updates the RTP and Fax Port range data in a
		voice profile.  (This is used by CFG agent ).
	\param[in] ucProfileId Voice Profile Id.
	\return IFX_SUCCESS or IFX_FAILURE
 */			 
e_IFX_Return IFX_CIF_UpdateProfilePorts( uchar8 ucProfileId );

/*!	
	\brief This function returns name of the country whose settings are
	currently applicable.	
	\param[out] szCountryName Country Name.  This string should be large enough 
			to hold country name. 
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CIF_CountryNameGet(OUT char8* szCountryName);

/*!
	\brief This function sets the status of the SIP registration in a voice line.
	\param[in] ucVoiceLineId Voice line Id.
	\param[in] ucStatus Registration status.
	\param[in] uiExpiresAfter Registration expiry in seconds.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLRegisterStatusSet(
	                 IN uchar8 ucVoiceLineId,
	                 IN uchar8 ucStatus,
	                 IN uint32 uiExpiresAfter,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function sets the status of voice mail subscription in a 
	       voice line.
	\param[in] ucVoiceLineId Voice line Id.
	\param[in] ucStatus Voice Mail Subscription Status.  
	\param[in] uiExpiresAfter Subscription expiration time in seconds.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLVMStatusSet(
	                 IN uchar8 ucVoiceLineId,
	                 IN uchar8 ucStatus,
	                 IN uint32 uiExpiresAfter,
	                 OUT e_IFX_ReasonCode* peReason );


/*!
	\brief This function sets the voice line information such as number of
	       unread voice mails in a voice line.
	\param[in] ucVoiceLineId Voice line Id
	\param[in] ucNoOfWaitingMails Number of unread voice mails for given line. 
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLVMWaitingStatusSet(
	                 IN uchar8 ucVoiceLineId,
	                 IN uchar8 ucNoOfWaitingMails,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function is used to check whether unsolicited notify is to be 
		      accepted.
	\param[out] pbUnsolNtfy IFX_TRUE, if unsolicited notify to be accepted, else
	            IFX_FALSE.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_UnsolicitedNtfyStatusGet(
	                 OUT boolean* pbUnsolNtfy,
	                 OUT e_IFX_ReasonCode* peReason );
/*! 
	\brief  This function checks whether incoming call is blocked or allowed.
	\param[in] szEndptId Endpoint Id.
	\param[in] szCallerAddr Caller Address.
	\param[out] pbBlocked Blocking Status.  On return, this indicates whether call is blocked.
	\param[out] peReason Reason Code.  If this function returns IFX_FAILURE, the failure reason 
	            is returned in this parameter.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_IncomingCallBlockCheck(
	                 IN char8* szEndptId, 
	                 IN char8* szCallerAddr,
	                 OUT boolean* pbBlocked,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief  This function checks whether outgoing calls are blocked or allowed.
	This function is used by all agents before placing a new call. 
	\param[in] szEndptId Endpoint Id.
	\param[out] pbBlocked Blocking Status. If outgoing call block is enabled, on return pbBlocked
	            contains IFX_TRUE. 
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_OutgoingCallBlockCheck(
	                 IN char8* szEndptId,
	                 OUT boolean* pbBlocked,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief  This function checks if the phones connected to the FXS ports of the
	device are SMS capable.
	\param[in] szEndptId Endpoint Id.
	\param[out] pbCapable Capability Flag.  Whether phone is SMS capable or not.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_FxsSMSCapablityCheck(
	                 IN   char8* szEndptId,
	                 OUT boolean* pbCapable ,
	                 OUT e_IFX_ReasonCode* peReason );


/*!
	\brief  This function checks if the phones connected to the FXS ports of the
	device are Wideband capable.
	\param[in] szEndptId Endpoint Id.
	\param[out] pbCapable Capability Flag.  Whether phone is Wideband capable or not.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_FxsWidebandCapablityCheck(
	                 IN   char8* szEndptId,
	                 OUT boolean* pbCapable ,
	                 OUT e_IFX_ReasonCode* peReason );
/*!
	\brief This function gets the default outbound interface (VoIP/PSTN) for making calls. 
	     In this version of the software, the default outbound interface(s) for
		 endpoint(s) and the system is the same.
	\param[in] szEndptId Endpoint Id
	\param[out] pucInterface Interface Identifier.  
			On return, This parameter contains default interface of the 
					endpoint. 0- VoIP interface, 1- PSTN interface.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_DefaultOutBoundIfGet(
	                 IN   char8* szEndptId,
	                 OUT uchar8* pucInterface,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function sets default outbound interface of the given endpoint. In 
	       this version default interface of endpoint and system are same.
	\param[in] szEndptId Endpoint Id
	\param[in] ucInterface Default interface id. 0- VoIP interface, 
	           1- PSTN interface.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_DefaultOutBoundIfSet(
	                 IN  char8* szEndptId, 
	                 IN uchar8  ucInterface ,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function gets the FXO Line Mode.
	\param[in] szFxoEndpointId FXO Line Id.	
	\param[out] pbMode Pointer to the Mode Flag. On return this parameter contains
	           IFX_TRUE for gateway mode, IFX_FALSE for Forwarding mode.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_FxoModeGet(
	                 IN char8* szFxoEndpointId,
	                 OUT boolean* pbMode,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function gets the SMS-SC number for the FXO Line.	
	\param[in] szFxoEndpointId FXO Line Id.
	\param[out] pszSmsScNumber Pointer to the SMS-SC number. This array must
	            be large enough to hold SMS-SC number (12 characters).
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_FxoSmsScNumberGet(
	                 IN char8* szFxoEndpointId,
	                 OUT char8* pszSmsScNumber,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function gets the Voice line Id associated with the FXO Line.
	\param[in] szFxoEndpointId FXO Line Id.
	\param[out] pucVoiceLineId Voice line Id associated with the FXO Line.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_FxoVLIdGet(
	                 IN char8* szFxoEndpointId,
	                 OUT uchar8* pucVoiceLineId,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function gets the call forward address (on no answer) for the 
	FXO Line.
	\param[in] szFxoEndpointId FXO Line Id.
	\param[out] pucEnabled Call Forward Flag.  On return, ITX_TRUE indicates, 
				call forward is enabled.
	\param[out] pxCfAdress Call Forward Address.  On return, if pucEnabled is 
		IFX_TRUE, then this contains the call forward address.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_FxoCallForwardAddrGet(
	                 IN char8* szFxoEndpointId,
	                 OUT uchar8* pucEnabled,
	                 OUT x_IFX_CalledAddr* pxCfAdress,
									 OUT e_IFX_ReasonCode* peReason );


/*!
	\brief This function checks if the voice line is registered. 	
	\param[in] szEndptId Endpoint Id. 
	\param[out] pbRegisred Registration Flag.  On return IFX_TRUE indicates
	           line is registered.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptDefaultVLRegStatusCheck(
	                 IN char8* szEndptId,
	                 OUT boolean* pbRegisred,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function check if the voice line has unread voice mails.
	\param[in] szEndptId Endpoint Id. 
	\param[out] pbVMWI Unread Voice Mail Flag.  On return, if IFX_TRUE then 
		given voice line has new (unread) voice mails.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptVMStatusCheck(
	                 IN char8* szEndptId,
	                 OUT boolean* pbVMWI,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function gets the voice mailbox retrieval address (URI).
	\param[in] szEndptId Endpoint Id. 
	\param[out] pxAddress Pointer to hold the voice mailbox retrieval 
	            address
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptVMRetrievalAddrGet(
	                 IN char8* szEndptId,
	                 OUT x_IFX_CalledAddr* pxAddress,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function sets the default Voice line for an endpoint.
	\param[in] szEndptId Endpoint Id
	\param[out] ucLineId Voice line Id.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_EndptDefaultVLSet(
	                 IN char8* szEndptId,
	                 OUT uchar8 ucLineId,
	                 OUT e_IFX_ReasonCode* peReason );

/* This function is duplicated in IFX_CallMgr_CfgIf.h
 * Hence doxygen comments are removed from here
 */
e_IFX_Return IFX_CIF_EndptDefaultVLGet(
	                 IN char8* szEndptId,
	                 OUT uchar8* pucLineId,
	                 OUT e_IFX_ReasonCode* peReason );


/*!
	\brief This function configures the call forwarding options on default voice line of
	       an endpoint.
	\param[in] szEndptId Endpoint Id.
	\param[in] eCfType Call Forward Type.
	\param[in] bEnabled Call Forward Flag.  Whether call forward is enabled/disabled ?
	\param[in] pxCfAdress Call Forward Address.  If bEnabled is IFX_TRUE, then 
		this contains the call forward address. Otherwise it is null. 
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptCallFwdInfoSet(
	                 IN char8* szEndptId, 
	                 IN e_IFX_CallForwardType eCfType,
	                 IN boolean bEnabled,
	                 IN x_IFX_CalledAddr* pxCfAdress,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function sets the DND status on default voice line of an endpoint.
	\param[in] szEndptId Endpoint Id. 
	\param[in] bEnable DND Flag.  IFX_TRUE - Enable DND. 
						IFX_FALSE - Disable DND.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptDNDStatusSet(
	                 IN char8* szEndptId,
	                 IN boolean bEnable, 
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function sets the anonymous call block status on default voice
	       line of endpoint.
	\param[in] szEndptId Endpoint Id. 
	\param[in] bEnable Anonymous Call Block Flag.  IFX_TRUE - Enable Anonymous call block. 
	                   IFX_FALSE - Disable Anonymous call block.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptAnonymousCallBlockSet(
	                 IN char8* szEndptId,
	                 IN boolean bEnable, 
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function toggles the call waiting function on default voice line
	       of an endpoint.
	\param[in] szEndptId Endpoint Id.
	\param[out] bEnable Call Waiting Flag.  IFX_TRUE, if call waiting is to be enabled.
					IFX_FALSE, if call waiting is to be disabled.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_EndptCallWaitingSet(
	               IN char8* szEndptId,
	               IN boolean bEnable,
	               OUT e_IFX_ReasonCode* peReason );


/*!
	\brief This function toggles the Caller Id transmission on the default 
		voice line of an endpoint.
	\param[in] szEndptId Endpoint Id.
	\param[out] bEnable CID Transmission Flag.  If IFX_TRUE, CID transmission 
			is to be enabled.  IFX_FALSE to disable CID transmission.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_EndptCidStatusSet(
	               IN char8* szEndptId,
	               IN boolean bEnable,
	               OUT e_IFX_ReasonCode* peReason );
/*!
	\brief This function gets an address book entry.	
	\param[in] szAddrIndex Address book Entry index.
  \param[out] pxAddr Pointer to structure holding the address info.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_AddrBookEntryGet(
	                 IN char8* szAddrIndex, 
					 OUT x_IFX_CMGR_AddressInfo* pxAddr,
	                 OUT e_IFX_ReasonCode* peReason );
/*!
	\brief	This function modifies the address book entry.
	\param[in] szAddrIndex Address book Entry index to be modified
	\param[out] pxAddress Pointer to structure holding the changed address.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_AddressBookEntryModify(
	                 IN  char8* szAddrIndex,
	                 IN x_IFX_CalledAddr* pxAddress,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief	This function retrieves the call return address for an endpoint.
	\param[in] szEndptId Endpoint Id.
	\param[out] pxCallRetAddr Pointer to structure holding the call return address
	\param[out] peReason Reason code. Indicates reason for failure.
	\return If invalid Endpoint Id is passed or there are no missed or received call
	      entries, this function returns IFX_FAILURE, otherwise returns IFX_SUCCESS.
*/
e_IFX_Return IFX_CIF_CallReturnAddrGet(
	                 IN  char8* szEndptId,
									 OUT x_IFX_CMGR_AddressInfo* pxCallRetAddr,
	                 OUT e_IFX_ReasonCode* peReason );
/*!
	\brief	This function checks if line allows simultaneous multiple calls or only Single call.
	\param[in] ucVoipLineId VoIP Line Id
	\return IFX_TRUE if line supports multipe calls
					IFX_FALSE if line does not support multiple calls.
*/
boolean  IFX_CIF_IsLineTypeMulti(uchar8 ucVoipLineId);
#ifdef DELAYED_HOTLINE
/*!
	\brief	This function sets the Delayed Hotline Info received.
	\param[in] szEndptId Endpoint Id for which DHL info has to be set 
	\param[in] bEnabled Flag to enable/disable DHL
	\param[in] pcDhlNumber Delayed Hotline number
	\param[out] peReason Reason code, Indicates reason for failure
	\return IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptDhlInfoSet(
                   IN char8* szEndptId,
                   IN boolean bEnabled,
                   IN char8* pcDhlNumber,
                   OUT e_IFX_ReasonCode* peReason);

/*!
	\brief	This function gets the Delayed Hotline Info received.
	\param[in] szEndptId Endpoint Id for which DHL info is enquired
	\param[out] bEnabled Indicates whether DHL is enabled/disabled
	\param[out] pcDhlNumber Delayed Hotline number
	\param[out] peReason Reason code, indicates reason for failure
	\return IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptDhlInfoGet(
	               IN char8* szEndptId,
                 OUT boolean* pbEnable,
                 OUT char8* pcDhlNumber,
                 OUT e_IFX_ReasonCode* peReason );
#endif
/*!
	\brief	This function sets the vunDialToneLength.
	\return IFX_SUCCESS/IFX_FAILURE
*/
e_IFX_Return IFX_CIF_DialToneLengthSet();

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)

/*! \brief Structure containing the DECT Subscription Info */
typedef struct
{

/*! \brief Size of IPUI */
#define IFX_CIF_IPUI_SIZE 5
/*! \brief Size of IPUI */
#define IFX_CIF_TPUI_SIZE 3
/*! \brief Size of authentication key */
#define IFX_CIF_AUTH_KEY_SIZE 16
/*! \brief Size of cipher key */
#define IFX_CIF_CIPHER_KEY_SIZE 8

	uchar8  bIsRegistered;              /*!< Handset registration  status */
	uchar8  aucIPUI[IFX_CIF_IPUI_SIZE]; /*!< Handset IPUI number */ 
	uchar8  aucTPUI[IFX_CIF_TPUI_SIZE]; /*!< Handset TPUI number */
	uchar8  aucAuthKey[IFX_CIF_AUTH_KEY_SIZE];    /*!< Handset's authentication key*/
	uchar8  aucCipherKey[IFX_CIF_CIPHER_KEY_SIZE];/*!< Handset's Cipher key */
	uchar8  ucServiceClass;             /*!< Service class */
	uchar8  ucModelId;                  /*!< Handset model ID */
  uint32  uiTermCap;					/*!< Terminal Capabilities */
}x_IFX_CIF_DectSubsInfo;

/*!
	\brief This function is used to retrieve the RFPI number of the DECT base.
	\param[out] paxRFPI Pointer to char buffer. This buffer size must be enough
	               to hold RFPI number.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
#if 0
e_IFX_Return IFX_CIF_RFPIGet(OUT uchar8 *paxRFPI);
/*!
	\brief This function retrieves the BMC parameters of the DECT base.	
	\param[out] pxBMCParams Pointer to x_IFX_CIF_BMCRegParams struct.
	\return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return IFX_CIF_BMCRegparamGet(
	               OUT x_IFX_CIF_BMCRegParams *pxBMCParams );

/*!
	\brief This function retrieves the OSC trim values of the DECT base.
	\param[out] pxOscTrimVal Pointer to struct x_IFX_CIF_OscTrimVal.
	\return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return IFX_CIF_OscTrimParamGet(
	               OUT x_IFX_CIF_OscTrimVal *pxOscTrimVal);

/*!
	\brief This function retrieves the gaussian value configured for DECT system.	
	\param[out] pucGaussianVal Pointer to uchar to hold guassian value.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_GaussianValGet(OUT uint16 *punGaussianVal);
#endif
/*!
	\brief This function retrieves the gaussian value configured for DECT system.	
	\param[out] pucDbgType Debug type
	\param[out] pucDbgLvl Debug level
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_DectDbgGet(OUT uchar8 *pucDbgType, OUT uchar8 *pucDbgLvl);


#if 0
/*!
	\brief This routine retrieves DECT tone cadence. (Not used)
	\param[in] eToneType
	\param[out] pxTone
	\return 
*/
e_IFX_Return IFX_CIF_ToneCadenceGet( 
	               IN  e_IFX_MMGR_ToneType eToneType,
	               OUT x_IFX_MMGR_Tone *pxTone );
#endif
/*!
	\brief This function retrieves the handset subscription information.	
	\param[in] pszEndptId Handset id.
	\param[out] pxDectSubsInfo Pointer to x_IFX_CIF_DectSubsInfo struct to
	              hold subscription info.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_DectSubsInfoGet(
	               IN char8* pszEndptId,
	               OUT x_IFX_CIF_DectSubsInfo *pxDectSubsInfo );

/*!
	\brief This function writes the handset registration information into configuration.	
	\param[in] pszEndptId Endpoint Id.
	\param[in] pxDectSubsInfo Pointer to x_IFX_CIF_DectSubsInfo struct that 
	             contains subscription info.
	\param[in] bWidebandCapable Whether handset is wideband capable? IFX_TRUE,
	           if handset is wideband capabble, else IFX_FALSE.
	\param[in] pszRegDateAndTime String that contains handset registration date 
	           and time. If this parameter is NULL, then registration date and 
	           time will not be changed.
	\return Returns IFX_SUCCESS if registration info is written, else IFX_FAILURE. 
*/
e_IFX_Return IFX_CIF_DectSubsInfoSet(
	               IN char8* pszEndptId,
	               IN x_IFX_CIF_DectSubsInfo *pxDectSubsInfo,
							   IN boolean bWidebandCapable,
								 IN char8* pszRegDateAndTime	);

/*!
	\brief This function is used to get the list of voice lines associated with an
	       endpoint.	
	\param[in]  pszEndptId Endpoint id.
	\param[out] pacVLList Pointer to uchar array. this should have sufficeint 
	              memory to hold list of voice lines associated with the endpoint.
	\param[in,out] pucNumVLs Number of voice lines.
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return  IFX_CIF_EndptVLListGet(
	                IN char8 *pszEndptId,
	                OUT	uchar8	*pacVLList,
	                IN_OUT uchar8	*pucNumVLs );

/*!
	\brief This function is used to set voice lines for an endpoint.	
	\param[in] pszEndptId Endpoint ID.
	\param[in] pacVLList List of voice lines.
	\param[in] pucNumVLs Number of Voice lines
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return  IFX_CIF_EndptVLListSet(
	                IN char8 *pszEndptId,
	                IN uchar8	*pacVLList,
	                IN uchar8	*pucNumVLs );

/*!
	\brief This function sets the base PIN.	
	\param[out] pszBasePin New base PIN. Size of the array is 4.
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return IFX_CIF_BS_PinSet(OUT char8*  pszBasePin);
e_IFX_Return IFX_CIF_BS_EncryptionSet(OUT uchar8  pszEncryption);


/*!
	\brief This function checks if Call interception is allowed for a Handset.
	\param[in] ucHandsetId Handset Identifier
	\return IFX_TRUE or IFX_FALSE 
*/
boolean IFX_CIF_IsInterceptAllowed(uchar8 ucHandsetId);

/*!
	\brief This function checks if Call intrusion is allowed on a Line.
	\param[in] ucLineId Line Identifier
	\return IFX_TRUE or IFX_FALSE 
*/
boolean IFX_CIF_IsIntrusionAllowed(uchar8 ucLineId);


/*!
	\brief This function retrieves the name of the DECT basestation.
	\param[out] pszBaseName Pointer to char array containing the name. Length of array must be 
	              greater than 18 bytes
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return IFX_CIF_BS_NameGet(OUT char8* pszBaseName);
#ifndef CVOIP_SUPPORT
e_IFX_Return IFX_CIF_GaussianValGet(OUT uint16 *punGaussianVal);
#endif
e_IFX_Return IFX_CIF_DectBasicParamsGet(char8* pszBasePin, uchar8* pucBitMap);



#endif // DECT_SUPPORT

/*!
	\brief This function frees a VMAPI List Object.
	\param[in] eLAType List Type
	\param[in] pxOld Old Buffer
	\param[in] pxNew New Buffer
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return
IFX_CIF_FreeVmapiObj(IN e_IFX_CMGR_LA_Type eLAType,
                      IN void *pxOld,
                      IN void *pxNew);

/*!
	\brief This function associates a DECT handset to a line.
	\param[in] ucHandsetId Handset Identifier
	\param[in] ucLineId Line Identifier
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return
  IFX_CIF_AssocLineIdSet(IN uchar8 ucHandsetId,IN uchar8 ucLineId);

/*!
	\brief This function fetches whether the Fxo is enable or not.
	\return IFX_SUCCESS or IFX_FAILURE 
*/
e_IFX_Return IFX_CIF_FxoEnableGet();

/* @} */ /* CIF for Agents - Functions */
e_IFX_Return
  IFX_CIF_AssocLineIdsGet(IN uchar8 ucHandset,OUT uchar8 *pucLineIdList);
e_IFX_Return
IFX_CIF_LineIdListGet(uchar8 *pucLineId);
e_IFX_Return IFX_CIF_LineAssocSet(IN uchar8,IN uchar8);

#endif /*_IFX_AGENT_EXT_H__ */
