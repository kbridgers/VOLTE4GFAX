/*****************************************************************************
 **   FILE NAME       :IFX_LMGR.h 
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : DECT VOIP GW Team
 **   DESCRIPTION     : This file contains code for the Line Mananger
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include "IFX_Config.h"
#include "ifx_common_defs.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_CallMgr_CfgIf.h"
#include "IFX_CallMgr.h"
#include "IFX_LineMgr.h"
#include "IFX_Agents_CfgIf.h"
EXTERN x_IFX_CMGR_CallMgrInfo vxCmgrInfo;
#define printf(...)
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFxoLineForEndpt
 *  Description     : This function finds the default FXO line id for the 
 *  						 Endpoint Id given
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFxoLineForEndpt(IN char8* szEid, 
					 								OUT char8* szFxoLineId, 
								 					OUT e_IFX_ReasonCode* peReason
					 )
{
	return IFX_CIF_EndptDefaultFxoLineGet(szEid,szFxoLineId,peReason);
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetEndptDefaultVoipLine
 *  Description     : This function finds the default Voip line id for the 
 *  						 Endpoint Id given. It also checks if the line is reg or not.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetEndptDefaultVoipLine(
					 char8* szEndptId,
					 OUT uchar8* pucVoipLineId,
					 OUT boolean* pbIsReg,
					 OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
  if(*pucVoipLineId == 0){
	  eRet = IFX_CIF_EndptDefaultVLGet(szEndptId, 
												pucVoipLineId, peReason);
  }
	if((IFX_SUCCESS == eRet) && (*pucVoipLineId > 0))
	{
		/*Check if line is reg & enabled*/
		eRet = IFX_CIF_VLStatusGet(*pucVoipLineId,pbIsReg,peReason);
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_FindEndptsFromFxoId
 *  Description     : This function finds the endpoints attched to FXO line 
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_FindEndptsFromFxoId
								(
								 IN char8* szFxoLineId, 
								 IN_OUT uchar8* pucSize,
								 OUT char8 aszEid[][IFX_MAX_ENDPOINTID_LEN],
								 OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	eRet = IFX_CIF_FxoLineEndptListGet(szFxoLineId,pucSize,aszEid,peReason);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFxoDefaultVoipLine 
 *  Description     : This function finds the default Voip line attched to 
 *  						 the FXO port given.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFxoDefaultVoipLine(
					 char8* szFxoLineId,
					 OUT uchar8* pucVoipLineId,
					 OUT e_IFX_ReasonCode* peReason)
{
	return IFX_CIF_FxoVLIdGet(szFxoLineId, 
												pucVoipLineId, peReason);
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetVoipLineIdFromUrl 
 *  Description     : This function finds the voip line id from a URL
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetVoipLineIdFromUrl(
					 IN x_IFX_CMGR_VoipAddr* pxAddress,
					 OUT uchar8* pucVoipLineId,
					 OUT e_IFX_ReasonCode* peReason)
{
	return IFX_CIF_VLFromUrlGet(pxAddress, pucVoipLineId, peReason);
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetEndpointsForVoipLine 
 *  Description     : This function finds the list of endpoints tied to a VL.
 *  						 It does so according to the mode of the VL.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetEndpointsForVoipLine(
		IN uint8 ucVoipLineId,
		OUT char8 aszEndptIdList[][IFX_MAX_ENDPOINTID_LEN],
		IN_OUT uchar8* pucSize,
		OUT boolean *pbFwdMode,
		OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	boolean bGwMode = IFX_FALSE;
	/*Find mode of the VL first*/
	eRet = IFX_CIF_VLModeGet(ucVoipLineId, &bGwMode, peReason);
	if(IFX_FAILURE == eRet)
	{
		return eRet;
	}
	/* Get endpoints for that line mode*/
	eRet = IFX_CIF_VLEndptListGet(ucVoipLineId, bGwMode, 
						 							pucSize, aszEndptIdList, peReason);
	if(IFX_TRUE == bGwMode)
	{
		*pbFwdMode = IFX_FALSE;
	}
	else
	{
		*pbFwdMode = IFX_TRUE;
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCallFwdAddr 
 *  Description     : This function returns the call forward address of the 
 *  						 given type .
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCallFwdAddr(
		IN uint8 ucVoipLineId,
		IN e_IFX_CallForwardType eFwdType,
		OUT boolean* pbFwdEnabled,
		OUT uchar8* pucRingCount,
		OUT x_IFX_CMGR_VoipAddr* pxFwdAddr,
		OUT e_IFX_ReasonCode* peReason)
{
	uchar8 ucRingCountDummy = 0;
	e_IFX_Return eRetVal= IFX_FAILURE;
	eRetVal= IFX_CIF_VLCallFwdInfoGet( ucVoipLineId,eFwdType, 
						pbFwdEnabled,&ucRingCountDummy, pxFwdAddr, peReason);
	if(eRetVal == IFX_FAILURE) {
		return IFX_FAILURE;
	}
	if(pucRingCount)
	{
		*pucRingCount = ucRingCountDummy;
		/*Fix: Use Ring count only if FwdEnabled*/
    if(IFX_FALSE == *pbFwdEnabled){
		 *pucRingCount = 0;
    }
	}
	eRetVal = IFX_CIF_GetCallFrwdDomain (ucVoipLineId,pxFwdAddr);
	
  return eRetVal;
}
/*****************************************************************************
 *  Function Name   : IFX_LMGR_CanCallBeAccepted
 *  Description     : This function checks if an incoming Voip call can be 
 *  						 accepted or not after passing through checks like
 *  						 UCF and DND.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_CanCallBeAccepted(
		IN uint8 ucVoipLineId,
		IN x_IFX_CMGR_VoipAddr *pxFrom,
		IN boolean bFirstIncVoipCall,
		OUT boolean *pbReject,
		OUT x_IFX_CMGR_VoipAddr* pxFwdAddr,
		OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	boolean bUncFwdEnabled = IFX_FALSE;
	boolean bBusyFwdEnabled = IFX_FALSE;
	boolean bVmFwdEnabled = IFX_FALSE;
	boolean bVlCwEnabled = IFX_FALSE;
	boolean bRejectForCw = IFX_FALSE;
	boolean bRejectForAcb = IFX_FALSE;
  boolean bBlocked = IFX_FALSE;
	x_IFX_CMGR_VoipAddr xVmAddr;
	x_IFX_CMGR_VoipAddr xBusyAddr;
	uchar8 ucRingCount = 0;
	//boolean bLineType = IFX_TRUE;
	*pbReject = IFX_FALSE;
  eRet=IFX_CIF_IncomingCallBlockCheck(NULL,pxFrom->acUserName,&bBlocked,peReason);	
	if(IFX_TRUE == bBlocked)
	{
	 *pbReject = IFX_TRUE;
	 *peReason = IFX_INTERNAL_ERR; //Chaging 603 to 5XX error in this case. For BUG #2 Oct 07 Pre-rel
		return eRet;
	}
	/*Check Anonymous Call Block*/
	eRet = IFX_CIF_VLAnonCallBlkStatusGet(ucVoipLineId,&bRejectForAcb, peReason);
	if(IFX_TRUE == bRejectForAcb)
	{
		/* ACB is enabled*/
		if(!strcasecmp(pxFrom->acUserName, "Anonymous"))
		{
			/* the call should not be fwd to any place. It should just be rejected*/
			*pbReject = IFX_TRUE;
			*peReason = IFX_INTERNAL_ERR; //Chaging 603 to 5XX error in this case. For BUG #2 Oct 07 Pre-rel
			return eRet;
		}
	}
	
	//bLineType = IFX_CIF_IsLineTypeMulti(ucVoipLineId);
	/*Check Voip Line Call Waiting*/
	eRet = IFX_CIF_VLCallWaitingCheck(ucVoipLineId, 
						 							&bVlCwEnabled, peReason);
	if( (/*IFX_FALSE == bLineType || */IFX_FALSE == bVlCwEnabled) 
			&& (IFX_FALSE == bFirstIncVoipCall))
	{
		bRejectForCw = IFX_TRUE;		/* Call is to be Rejected */
	}
	
	/* Check the DND feature */
	eRet = IFX_CIF_VLDNDStatusGet(ucVoipLineId, pbReject, peReason);
	/* Check the  unconditional call forward */
	eRet = IFX_CIF_VLCallFwdInfoGet( ucVoipLineId, 
		IFX_CALL_FWD_UNCONDITIONAL, &bUncFwdEnabled, &ucRingCount,pxFwdAddr, peReason);
	/* Check the VM Fwd address to get the FWD addr */		
	IFX_CIF_VLCallFwdInfoGet(ucVoipLineId, 
		IFX_CALL_FWD_VOICE_MAIL, &bVmFwdEnabled, &ucRingCount,&xVmAddr, peReason);
	/* Check the  unconditional call forward */
	eRet = IFX_CIF_VLCallFwdInfoGet( ucVoipLineId, 
		IFX_CALL_FWD_BUSY, &bBusyFwdEnabled, &ucRingCount,&xBusyAddr, peReason);

	/* Find the actual thing to be done*/
	if((IFX_TRUE == *pbReject) || 
			(IFX_TRUE == bRejectForCw) || (IFX_TRUE == bUncFwdEnabled))
	{
		*pbReject = IFX_TRUE; /*Call has to be rejected*/
		if(IFX_TRUE == bUncFwdEnabled)
		{
			*peReason = IFX_CALL_FORWARD;
		}else
		if(IFX_TRUE == bVmFwdEnabled)
		{
			memcpy(pxFwdAddr, &xVmAddr, sizeof(x_IFX_CMGR_VoipAddr));
			*peReason = IFX_CALL_FORWARD;
		}else
		if(IFX_TRUE == bBusyFwdEnabled)
		{
			memcpy(pxFwdAddr, &xBusyAddr, sizeof(x_IFX_CMGR_VoipAddr));
			*peReason = IFX_CALL_FORWARD;
		}
		else
		{
			*peReason = IFX_ENDPOINT_BUSY;
		}
/*SMS01395036 Start: Fix for call forward activate*/
    /*Get domain address of forward number*/
    if(*peReason == IFX_CALL_FORWARD){
       IFX_CIF_GetCallFrwdDomain (ucVoipLineId,pxFwdAddr);
    }
/*End: Fix for call forward activate*/
	}

	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFaxParams 
 *  Description     : This function gets the FAX information from the VMAPI
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFaxParams(
									IN uint8 ucLineId,
									IN uint32 uiFaxTrProto,
									OUT x_IFX_CMGR_FaxParams *pxFax)
{
#ifdef FAX_SUPPORT
	boolean bProtoSupport = IFX_FALSE;
	e_IFX_ReasonCode eReason = 0;
	e_IFX_Return eRet = IFX_SUCCESS;	
#if 1
	eRet = 
		IFX_CIF_VLFaxMediaCfgGet(ucLineId,uiFaxTrProto,pxFax,&bProtoSupport,&eReason);
	if(IFX_FALSE == bProtoSupport)			
	{
		eRet = IFX_FAILURE;
	}
	else
	{
		if(IFX_TRPROTO_UDP == uiFaxTrProto)
		{
				printf("pxFax->xFaxCfg.uiTransportProtocol: %d\n",pxFax->xFaxCfg.uiTransportProtocol);
				printf("pxFax->xFaxCfg.ucVersion: %d\n",pxFax->xFaxCfg.ucVersion);
				printf("pxFax->xFaxCfg.ucRateManagement : %d\n",pxFax->xFaxCfg.ucRateManagement);
				printf("pxFax->xFaxCfg.unMaxBitRate : %d\n ",pxFax->xFaxCfg.unMaxBitRate);
				printf("pxFax->xFaxCfg.uiBitOptions : %d\n",pxFax->xFaxCfg.uiBitOptions);
				printf("pxFax->xFaxCfg.unUDPMaxBufferSize : %d\n",pxFax->xFaxCfg.unUDPMaxBufferSize);
				printf("pxFax->xFaxCfg.unUDPMaxDatagramSize :%d\n",pxFax->xFaxCfg.unUDPMaxDatagramSize);
				printf("pxFax->xFaxCfg.ucUDPErrCorrection : %d\n",pxFax->xFaxCfg.ucUDPErrCorrection);
				printf("Local Ip Addr = %s ",pxFax->szLocalFaxIpAddr);
				printf("Local Fax Port = %d\n",pxFax->uiLocalFaxPort); 
		}
		else
		{
				printf("pxFax->xFaxCfg.uiTransportProtocol: %d\n",pxFax->xFaxCfg.uiTransportProtocol);
				printf("pxFax->xFaxCfg.ucVersion: %d\n",pxFax->xFaxCfg.ucVersion);
				printf("pxFax->xFaxCfg.ucRateManagement : %d\n",pxFax->xFaxCfg.ucRateManagement);
				printf("pxFax->xFaxCfg.unMaxBitRate : %d\n ",pxFax->xFaxCfg.unMaxBitRate);
				printf("pxFax->xFaxCfg.uiBitOptions : %d\n",pxFax->xFaxCfg.uiBitOptions);
				printf("Local Ip Addr = %s ",pxFax->szLocalFaxIpAddr);
				printf("Local Fax Port = %d\n",pxFax->uiLocalFaxPort); 
		}
		
	}
	
#else
	static uint32 vuiFaxStartPort = 8000;
	if(IFX_TRPROTO_UDP == uiFaxTrProto)
	{
		/* Just for testing - Delete later  - TO DO*/
		pxFax->xFaxCfg.uiTransportProtocol = IFX_TRPROTO_UDP;
		pxFax->xFaxCfg.ucVersion = 0;
		pxFax->xFaxCfg.ucRateManagement = 1;
		pxFax->xFaxCfg.unMaxBitRate = 14400;
		pxFax->xFaxCfg.uiBitOptions = 0;
		pxFax->xFaxCfg.unUDPMaxBufferSize = 512;
		pxFax->xFaxCfg.unUDPMaxDatagramSize = 512;
		pxFax->xFaxCfg.ucUDPErrCorrection = 1;

		IFX_OS_GetHostIp(pxFax->szLocalFaxIpAddr);
		pxFax->uiLocalFaxPort = ++vuiFaxStartPort; 
		//Get(pxFax, uiFaxTrProto, &bSupport)
	}else
	if(IFX_TRPROTO_TCP == uiFaxTrProto)
	{
		/* Just for testing - Delete later  - TO DO*/
		pxFax->xFaxCfg.uiTransportProtocol = IFX_TRPROTO_TCP;
		pxFax->xFaxCfg.ucVersion = 0;
		pxFax->xFaxCfg.ucRateManagement = 1;
		pxFax->xFaxCfg.unMaxBitRate = 14400;
		pxFax->xFaxCfg.uiBitOptions = 0;	

		IFX_OS_GetHostIp(pxFax->szLocalFaxIpAddr);
		pxFax->uiLocalFaxPort = ++vuiFaxStartPort; 
	}
#endif
#endif
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_LMGR_FreeMediaPort 
 *  Description     : This fn frees a FAX/RTP port for re-use
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_FreeMediaPort(uint32 uiPort, e_IFX_TransportType eProto)
{
	IFX_CIF_ReleasePort(uiPort,eProto);
	return IFX_SUCCESS;
}
																		

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetInfoForVoipCall 
 *  Description     : This function populates information for a Voip call,
 *  						 based on the VL id. It populates the Codecs, rtp, fax
 *  						 , URL etc.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetInfoForVoipCall
				(
					 IN uint8 ucVoipLineId,
					 OUT x_IFX_CMGR_VoipLegInfo* pxLineInfo,
					 OUT e_IFX_ReasonCode* peReason
				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_DtmfType eDtmfType;
	uint16 unDynPayNum = 0;
	uint32 i = 0;
	pxLineInfo->ucLineId = ucVoipLineId;
	*peReason  = IFX_MAX_REASON;
	
#ifdef FAX_SUPPORT
	x_IFX_CMGR_FaxParams *pxFaxUdp = pxLineInfo->axFaxParams;
	x_IFX_CMGR_FaxParams *pxFaxTcp = &pxLineInfo->axFaxParams[1];
#endif
	eRet = IFX_CIF_UrlFromVLGet(ucVoipLineId,
						 &pxLineInfo->xLocalVlAddr, peReason);	
	if(IFX_FAILURE == eRet)
	{
		*peReason = IFX_USER_NOT_FOUND;
		return eRet;	
	}
	eRet = IFX_CIF_VLCodecInfoGet(ucVoipLineId, 
						 &pxLineInfo->xOfferedCodecInfo, peReason);
	if((IFX_FAILURE == eRet) || (!pxLineInfo->xOfferedCodecInfo.unNoOfCodecs))
	{
		*peReason = IFX_NO_RESOURCE;
		return eRet;	
	}
	eRet = IFX_CIF_VLRtpMediaCfgGet(ucVoipLineId, 
						 &pxLineInfo->xNegRtpParams, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peReason = IFX_NO_RESOURCE;
		return eRet;	
	}
	eRet = IFX_CIF_VLJBCfgGet(ucVoipLineId, &pxLineInfo->xJbInfo, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peReason = IFX_NO_RESOURCE;
		return eRet;	
	}
	eRet = IFX_CIF_VLSIDCheck(ucVoipLineId, 
						 &pxLineInfo->bSilenceSupEnabled, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peReason = IFX_INTERNAL_ERR;
		return eRet;	
	}
	eRet = IFX_CIF_VLDigitMethodGet(ucVoipLineId, 
											&eDtmfType,&unDynPayNum, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peReason = IFX_INTERNAL_ERR;
		return eRet;	
	}
	/*Create the xTelEvtInfo for use by the Media Manager*/
	if(unDynPayNum < IFX_CMGR_MIN_DYN_PT)
		unDynPayNum = IFX_CMGR_MIN_DYN_PT;
	
	if((IFX_DTMF_INBAND_EVENT == eDtmfType) || (IFX_DTMF_BOTH == eDtmfType))
	{
		pxLineInfo->xLocTelEvtInfo.eEventTransMode = 
				  					IFX_MMGR_TEL_EVENT_VOICE_IN_BAND_RFC_2833;
		pxLineInfo->xLocTelEvtInfo.ucPayLoadTypeTx = unDynPayNum;
		pxLineInfo->xLocTelEvtInfo.eAction = IFX_MMGR_TEL_EVENT_MUTE;
	}
	else
	{
		pxLineInfo->xLocTelEvtInfo.eEventTransMode =	
				  					IFX_MMGR_TEL_EVENT_VOICE_IN_BAND;
	}
	
#ifdef FAX_SUPPORT
	/* Get the FAX CFG for the T.38 fax TCP and UDP if present in 
		 the offered codec list.*/
	for(i=0;i<pxLineInfo->xOfferedCodecInfo.unNoOfCodecs;i++)
	{
		/* Get Port and the IP and the T.38 parameters*/
		if(IFX_T38_TCP == pxLineInfo->xOfferedCodecInfo.axCodec[i].uiCodec)
		{
			eRet = IFX_LMGR_GetFaxParams(ucVoipLineId, IFX_TRPROTO_TCP,pxFaxTcp);	
			if(IFX_FAILURE == eRet)
			{
				*peReason = IFX_INTERNAL_ERR;
				return eRet;	
			}
		}else
		if(IFX_T38_UDP == pxLineInfo->xOfferedCodecInfo.axCodec[i].uiCodec)
		{	
			eRet = IFX_LMGR_GetFaxParams(ucVoipLineId, IFX_TRPROTO_UDP,pxFaxUdp);	
			if(IFX_FAILURE == eRet)
			{
				*peReason = IFX_INTERNAL_ERR;
				return eRet;	
			}
		}
	}
	if((pxFaxUdp->xFaxCfg.uiTransportProtocol != IFX_T38_UDP) && 
									(IFX_T38_TCP == pxFaxTcp->xFaxCfg.uiTransportProtocol))
	{
		memset(pxFaxUdp,0,sizeof(x_IFX_CMGR_FaxParams));
		memcpy(pxFaxUdp,pxFaxTcp,sizeof(x_IFX_CMGR_FaxParams));
		memset(pxFaxTcp,0,sizeof(x_IFX_CMGR_FaxParams));
	}
#endif
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetSipInfoCfgStatus
 *  Description     : This function get the SIP info configuration
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetSipInfoCfgStatus(
					 IN uchar8 ucLineId,
					 OUT boolean *pbEnabled,
					 OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_DtmfType eDtmfType;
	uint16 unDynPayNum = 0;
	*pbEnabled = IFX_FALSE ; 	
	eRet = IFX_CIF_VLDigitMethodGet(ucLineId, &eDtmfType,&unDynPayNum, peReason);
	if(IFX_DTMF_SIP_INFO == eDtmfType)
	{
		*pbEnabled = IFX_TRUE;
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCodecsForLine
 *  Description     : This function gets codecs for a VL.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCodecsForLine(
					 IN uint8 ucLineId,
					 OUT x_IFX_CMGR_CodecParams* pxCodecs,
					 OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	eRet = IFX_CIF_VLCodecInfoGet(ucLineId, pxCodecs, peReason);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCodecsForEndpt
 *  Description     : This function gets codecs for an endpoint id, if some
 *  						 codecs exist in the configuration for the endpoint.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCodecsForEndpt(
					 IN char8* szEndptId,
					 OUT x_IFX_CMGR_CodecParams* pxCodecs,
					 OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	eRet = IFX_CIF_EndptCodecListGet(szEndptId, pxCodecs, peReason);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToMissedCallReg
 *  Description     : This function adds an entry into the 
 											missed call register.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToMissedCallReg
														(IN uchar8 ucLineId,
														 IN x_IFX_CMGR_AddressInfo* pxAddr
														)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0 ;
	eRet = IFX_CIF_CallRegisterAdd(IFX_CR_MISSED,ucLineId,pxAddr,&eReason);		
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToPlcdCallReg
 *  Description     : This function adds an entry into the 
 											Placed call register.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToPlcdCallReg
														(IN uchar8 ucLineId,
														 IN x_IFX_CMGR_AddressInfo* pxAddr
														)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0 ;
	eRet = IFX_CIF_CallRegisterAdd(IFX_CR_DIALED,ucLineId,pxAddr,&eReason);		
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToRcvdCallReg
 *  Description     : This function adds an entry into the 
 											recieved call register.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToRcvdCallReg
														(IN uchar8 ucLineId,
														 IN x_IFX_CMGR_AddressInfo* pxAddr
														)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0 ;
	eRet = IFX_CIF_CallRegisterAdd(IFX_CR_RECEIVED,ucLineId,pxAddr,&eReason);		
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCidStatus
 *  Description     : This function finds if caller ID is to be supressed 
 											or not.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCidStatus
														(IN uchar8 ucLineId,
														 OUT boolean* pbEnableCid
														)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0 ;
	eRet = IFX_CIF_VLCidStatusGet(ucLineId,pbEnableCid, &eReason);		
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFaxFxsPort
 *  Description     : This function the default FAX FXS port
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFaxFxsPort(OUT char8* szEndptId)
{
	e_IFX_Return eRet = IFX_SUCCESS;
#ifdef FAX_SUPPORT
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	eRet = IFX_CIF_DefaultFaxPortGet(szEndptId, &eReason);
#endif
	return eRet;
}
