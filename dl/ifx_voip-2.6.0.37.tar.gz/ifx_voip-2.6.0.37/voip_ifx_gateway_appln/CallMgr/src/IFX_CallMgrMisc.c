/*****************************************************************************
 **   FILE NAME       : IFX_CallMgrMisc.c
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Call-Manager 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains the Misc functions needed by CMGR
 **   FUNCTIONS       :
 **   COMPILER        : mips-linux-gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <malloc.h>

#include "IFX_Config.h"
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_CallMgr_CfgIf.h"
#include "IFX_CallMgr.h"
#include "IFX_LineMgr.h"

#define printf(...)

/*! \brief Global static variable for the system*/
EXTERN x_IFX_CMGR_CallMgrInfo vxCmgrInfo;

EXTERN void IFX_CMGR_DeAllocCallLeg(x_IFX_CMGR_CallLeg* pxLeg);
EXTERN e_IFX_Return IFX_CMGR_AllocStruct(OUT void** ppvStruct,
					 OUT uint16* punIdx,
					 IN e_IFX_CMGR_StructType eType);

EXTERN e_IFX_Return IFX_CMGR_InvokeRemoteCallRelease
										(IN x_IFX_CMGR_CallLeg* pxLeg,
										 IN e_IFX_ReasonCode eReason,
										 IN x_IFX_CMGR_VoipAddr* pxFwdAddr
										 );
EXTERN void IFX_CMGR_SearchForDtmf(	IN x_IFX_CodecList* pxCodec,
												OUT uchar8* pucDynPt);
EXTERN e_IFX_Return  IFX_CMGR_IsIdValid(uint32 uiId, boolean bCallId);
STATIC boolean IFX_CMGR_IsRangeOk(x_IFX_CMGR_CallBackList* pxCB, 
					 						uint32 uiStartOff, 
											uint32 uiStopOff);
#define IFX_CMGR_IsCallCtrlCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList,pfnCallIncoming),\
			  		offsetof(x_IFX_CMGR_CallBackList, pfnRemoteCallRelease))

#define IFX_CMGR_IsMediaOfferAnswerCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList,pfnGetMediaParams),\
			  		offsetof(x_IFX_CMGR_CallBackList, pfnMediaNegRsp))

#define IFX_CMGR_TransferCB_NA_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList, pfnBlindTxReq),\
			  		offsetof(x_IFX_CMGR_CallBackList, pfnAttendedTxStatus))

#define IFX_CMGR_TransferCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList, pfnBlindTxReq),\
			  		offsetof(x_IFX_CMGR_CallBackList, pfnCallIdRep))

#define IFX_CMGR_IsRtpSessionCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList, pfnRtpSessionStart),\
			  		offsetof(x_IFX_CMGR_CallBackList,pfnRtpSessionModify))

#define IFX_CMGR_IsCfgAgentCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList, pfnRegisterRsp),\
			  		offsetof(x_IFX_CMGR_CallBackList, pfnVM_NtfnRcv ))

#define IFX_CMGR_IsNetworkAgentRegSubsCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList, pfnRegister),\
			  		offsetof(x_IFX_CMGR_CallBackList, pfnSubnStatus ))

#ifdef FAX_SUPPORT
#define IFX_CMGR_IsFaxSessionCB_Ok(pxCB) \
	IFX_CMGR_IsRangeOk(pxCB,\
			  offsetof(x_IFX_CMGR_CallBackList, pfnFaxSessionStart),\
			  		offsetof(x_IFX_CMGR_CallBackList,pfnFaxSessionStop))
#endif
/*****************************************************************************
 *  Function Name   : IFX_APP_GetCallCnxtPtr
 *  Description     : This function finds the Call Context from Call Id
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
x_IFX_CMGR_CallContext* IFX_CMGR_GetCallCnxtPtr(uint32 uiCallId)
{
	uint16 unCnxtIdx = 0;
	if(IFX_FAILURE == IFX_CMGR_IsIdValid(uiCallId,IFX_TRUE))
	{
		return NULL;
	}
  /* Fix: Return null if call ID is zero */
	if(!uiCallId)
	{
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"CallId is Zero");
		 return NULL;
	}

	unCnxtIdx = IFX_CMGR_GetCallCnxtIdx(uiCallId);
	if (unCnxtIdx > IFX_CMGR_MAX_CALL_CNXT)
		return NULL;
	else
		return &vxCmgrInfo.axCallCnxt[unCnxtIdx];
}

/*****************************************************************************
 *  Function Name   : IFX_APP_GetCallLegPtr
 *  Description     : This function finds the Call Leg from Call Id
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
x_IFX_CMGR_CallLeg* IFX_CMGR_GetCallLegPtr(uint32 uiCallId)
{
	uint16 unLegIdx = 0;
	if(!uiCallId)
	{
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"CallId is Zero");
		 return NULL;
	}
	if(IFX_FAILURE == IFX_CMGR_IsIdValid(uiCallId,IFX_TRUE))
	{
		return NULL;
	}
	unLegIdx = IFX_CMGR_GetCallLegIdx(uiCallId);
	return &vxCmgrInfo.axCallLeg[unLegIdx];
}

/*****************************************************************************
 *  Function Name   : IFX_APP_GetReqCnxtPtr
 *  Description     : This function finds the Request Context from Request Id
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
x_IFX_CMGR_ReqContext* IFX_CMGR_GetReqCnxtPtr(uint32 uiReqId)
{
	uint16 unCnxtIdx = 0;
	if(IFX_FAILURE == IFX_CMGR_IsIdValid(uiReqId,IFX_FALSE))
	{
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ReqId is Zero");
		return NULL;
	}
	unCnxtIdx = IFX_CMGR_GetReqCnxtIdx(uiReqId);
	if (unCnxtIdx > IFX_CMGR_MAX_REQ_CNXT)
		return NULL;
	else
	return &vxCmgrInfo.axReqCnxt[unCnxtIdx];
}

/*****************************************************************************
 *  Function Name   : IFX_APP_GetReqLegPtr
 *  Description     : This function finds the Request Leg from Request Id
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
x_IFX_CMGR_ReqLeg* IFX_CMGR_GetReqLegPtr(uint32 uiReqId)
{
	uint16 unLegIdx = 0;
	if(IFX_FAILURE == IFX_CMGR_IsIdValid(uiReqId,IFX_FALSE))
	{
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"CallLeg is Zero");
		return NULL;
	}
	unLegIdx = IFX_CMGR_GetReqLegIdx(uiReqId);
	if (unLegIdx > IFX_CMGR_MAX_REQ_LEGS)
		return NULL;
	else
	return &vxCmgrInfo.axReqLeg[unLegIdx];
}



/*!
	\brief Called at boot-up to allow CMGR to set its house in order 
	\param[in] ucDebugId is the Debug Id to be used by the Call Manager
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_Init(IN uint8 ucDebugId)
{	
	/*Clear the global struct*/
	memset(&vxCmgrInfo, 0 ,sizeof(x_IFX_CMGR_CallMgrInfo));
	vxCmgrInfo.ucDebugId = ucDebugId;
	return IFX_SUCCESS;
}

/*!
	\brief Called at system shut-down to clean up the CMGR 
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_Shut(void)
{
	uint16 i=0;
	/* Free any malloc memeory*/
	for(i=0;i<IFX_CMGR_MAX_AGENTS; i++)
	{
		if(vxCmgrInfo.axEndptInfo[i].pxCallBackInfo)
		{
			free(vxCmgrInfo.axEndptInfo[i].pxCallBackInfo);
		}
	}
	/*Clear the global struct*/	  
	memset(&vxCmgrInfo, 0 ,sizeof(x_IFX_CMGR_CallMgrInfo));
	return IFX_SUCCESS;
}

/*!
	\brief This function is used by an agent to transparently 
			 send a message to another agent.
	\param[in]	pxFrom address of the sending party
	\param[in]	pxTo address of the receiving party
	\param[in]	pvInfo Pointer to the transparent information
	\param[in]	unSize size of the information in the void pointer
	\param [out] peStatus is the status of the Req as given by the remote agent
	\param [out] peReason - incase of failure, this parameter provides the 
					 specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_InfoSnd( 
					 IN x_IFX_CMGR_AddressInfo* pxFrom,
					 IN x_IFX_CMGR_AddressInfo* pxTo,
					 IN void* pvInfo,
					 IN uint16 unSize,
					 OUT e_IFX_CMGR_Status *peStatus,
					 OUT e_IFX_ReasonCode *peReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallBackList* pxCB = NULL;
	
	if((IFX_CMGR_TYPE_VOIP == pxTo->eAddressType) || 
		(IFX_CMGR_TYPE_VOIP == pxFrom->eAddressType))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_MAX_REASON;
		return eRet;	
	}
	 
	/* Check if its a EXTN->FXO Request*/
	if((IFX_CMGR_TYPE_FXO == pxTo->eAddressType) &&
		(IFX_CMGR_TYPE_EXTN == pxFrom->eAddressType))
	{
		if(!strcasecmp(pxTo->uxAddressInfo.xFxoInfo.szFxoLineId,""))
		{
			/* Find the default FXO line for the EXTN*/
			eRet = IFX_LMGR_GetFxoLineForEndpt(pxFrom->uxAddressInfo.szEndptId, 
					pxTo->uxAddressInfo.xFxoInfo.szFxoLineId, peReason);	
			if((IFX_FAILURE == eRet)||
				(!strcasecmp(pxTo->uxAddressInfo.xFxoInfo.szFxoLineId,"")))
			{
				*peStatus = IFX_CMGR_STATUS_FAIL;
				return eRet;	
			}
		}
		/* Find the CB ptr from pxTo*/
		IFX_CMGR_GetCBList( pxTo->uxAddressInfo.xFxoInfo.szFxoLineId, &pxCB);
	}else
	/* Check if its a FXO->EXTN Request*/
	if((IFX_CMGR_TYPE_FXO == pxFrom->eAddressType) &&
		(IFX_CMGR_TYPE_EXTN == pxTo->eAddressType))
	{
		/* Find the CB ptr from pxTo*/
		IFX_CMGR_GetCBList( pxTo->uxAddressInfo.szEndptId, &pxCB);
	}	
	
	/* Invoke pfnInfoRcv on the pxTo*/
	if(pxCB && pxCB->pfnInfoRcv)
			  pxCB->pfnInfoRcv(pxFrom, pxTo, pvInfo,unSize,peStatus,peReason);
	else
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	return eRet; 	
}
					 				 
/*!
	\brief This API is used by an the FXO agent to send a CID type II info
			 to its peer agent, during a call.
	\param[in] uiCallId is the Call-Id of the Call,
	\param[in] szPhoneNumber is the number from which the CID was received
	\param[in] pxAddCidInfo is the additional CID information
   \return    IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_OffHkCidSnd( 
					 IN uint32 uiCallId,
					 IN char8* szPhoneNumber,
					 IN x_IFX_CMGR_CidInfo* pxAddCidInfo
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg  = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = pxLeg?pxLeg->pxPeer:NULL;
	
	if(!pxPeer || !pxPeer->uiCallId)
	{
		/* DEBUG*/
		return IFX_FAILURE;
	}
	/* Pass it to the peer agent*/
	if(pxPeer->pxCallBackList->pfnOffHkCidRcv)
		pxPeer->pxCallBackList->pfnOffHkCidRcv(pxPeer->uiCallId,
							 							szPhoneNumber,pxAddCidInfo );
	return eRet;
}
					 				 

/*!
	\brief This API is used by the NA agent to get a 
				VoIP line ID for a particular Req Id.
	\param[in] uiReqId is the Id for this Req
	\param[out] punLineId is the Line ID Reqed 
	\param[out] peReason - incase of failure, 
				  this parameter provides the specific reason
  \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_LineIdFromReqIdGet(
									IN uint32 uiReqId ,
									OUT uint16* punLineId ,
									OUT e_IFX_ReasonCode *peReason /*If Failure*/
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);		 
	x_IFX_CMGR_ReqContext* pxCnxt = IFX_CMGR_GetReqCnxtPtr(uiReqId);		 
	*punLineId = 0;	
	if(!pxLeg)
		return IFX_FAILURE;
	
	if(!pxCnxt)
		return IFX_FAILURE;

	switch(pxCnxt->eReqType)
	{
		case IFX_CMGR_REQ_SUBS_AUTO_REDIAL:
			*punLineId = pxCnxt->uxReqCnxt.xArdSubsInfo.unVoipLineId;
		break;
		case IFX_CMGR_REQ_SUBS_VOICE_MAIL:
			*punLineId = pxCnxt->uxReqCnxt.xVmSubsInfo.unVoipLineId;
		break;
		case IFX_CMGR_REQ_REG:
			*punLineId = pxCnxt->uxReqCnxt.xRegInfo.unVoipLineId;
		break;
#ifdef MESSAGE_SUPPORT		
		case IFX_CMGR_REQ_SMS:
		*punLineId = pxCnxt->uxReqCnxt.xSmsInfoInt.unVoipLineId;
		break;
#endif		
		case IFX_CMGR_REQ_CONF:
		default:
		break;
	}
	
	return eRet;
}

/*!
	\brief This API is used by the NA agent to get a 
				VoIP line ID for a particular Call Id.
	\param[in] uiCallId is the Call Id for this Call
	\param[out] punLineId is the Line ID Reqed 
	\param[out] peReason - incase of failure, 
				  this parameter provides the specific reason
  \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_LineIdFromCallIdGet(
					 				IN uint32 uiCallId ,
									OUT uint16* punLineId ,
									OUT e_IFX_ReasonCode *peReason /*If Failure*/
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);		 
	*punLineId = 0;	
	
	if(!pxLeg)
		eRet = IFX_FAILURE;
	else
		*punLineId = pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId;
	return eRet;
}

/*!
	\brief This API is called by the agent to get the private data from the Call Id
	\param[in]  uiCallId is the call-id for which private data is Requested.
	\param[out]	 ppvPrivateData is the pointer to pointer in which the 
					private data would be returned.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataFromCallIdGet( IN uint32 uiCallId,
					 				OUT void **ppvPrivateData)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);		 
	
	if(!pxLeg)
		eRet = IFX_FAILURE;
	else
		*ppvPrivateData = pxLeg->pvPrivateData;
	return eRet;
}

/*!
	\brief This API is called by the agent to set the private data to a Call Id
	\param[in]  uiCallId is the call-id for which private data attachment is Reqed.
	\param[in]	 pvPrivateData is the pointer to pointer in which the 
					private data would be returned.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataToCallIdSet( IN uint32 uiCallId,
					 				IN void *pvPrivateData)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);		 
	
	if(!pxLeg)
		eRet = IFX_FAILURE;
	else
		 pxLeg->pvPrivateData = pvPrivateData;
	return eRet;
}

/*!
	\brief This API is called by the agent to get the private data from the Call Id
	\param[in]  uiReqId is the call-id for which private data attachment is Reqed.
	\param[out]	 ppvPrivateData is the pointer to pointer in which the 
					private data would be returned.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_GetPrivateDataFromReqIdGet( IN uint32 uiReqId,
					 				OUT void **ppvPrivateData)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);		 
	
	if(!pxLeg)
		eRet = IFX_FAILURE;
	else
		*ppvPrivateData = pxLeg->pvPrivateData;
	return eRet;
}

/*!
	\brief This API is called by the agent to set the private data to a Call Id
	\param[in]  uiReqId is the Req-id for which private data attachment is Reqed.
	\param[in]	 pvPrivateData is the pointer to pointer in which the 
					private data would be returned.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataToReqIdSet( IN uint32 uiReqId,
					 				IN void *pvPrivateData)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);		 
	
	if(!pxLeg)
		eRet = IFX_FAILURE;
	else
		 pxLeg->pvPrivateData = pvPrivateData;
	return eRet;
}

/******************** Stuff Needed For Call- Back Registrations****************/

/*****************************************************************************
 *  Function Name   :IFX_CMGR_AllocCallBackInfoStruct 
 *  Description     : This function finds a free CB info struct from its array
 *  						 and also mallocs memory for the CB list ptr
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AllocCallBackInfoStruct(
					 OUT x_IFX_CMGR_CallBackInfo** ppxCB)
{
	e_IFX_Return eRet = IFX_SUCCESS;

	*ppxCB = (x_IFX_CMGR_CallBackInfo*)malloc(sizeof(x_IFX_CMGR_CallBackInfo));
	if(!(*ppxCB))
	{
		eRet = IFX_FAILURE;
	}
	else
	{
		memset(*ppxCB, 0, sizeof(x_IFX_CMGR_CallBackInfo));
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FreeCallBackInfoStruct
 *  Description     : This function frees and nulls the memory for 
 *  						 x_IFX_CMGR_CallBackInfo structure ptr
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_FreeCallBackInfoStruct(
					 OUT x_IFX_CMGR_CallBackInfo* pxCB)
{
	e_IFX_Return eRet = IFX_SUCCESS;	
	memset(pxCB, 0, sizeof(x_IFX_CMGR_CallBackInfo));
	free(pxCB);
	pxCB = NULL;
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FoundEndptInArray 
 *  Description     :The function searches through the EID list for the endpoint
 *  						ID	and returns a pointer to that endpoint
 *  					      
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_FoundEndptInArray(IN char8* szEndptId,
					 OUT x_IFX_CMGR_EndptInfo** ppxEndpt)
{
	boolean bRet=IFX_FALSE;
	x_IFX_CMGR_EndptInfo* pxEndptInfo= vxCmgrInfo.axEndptInfo;
	int32 i=0;
	
	*ppxEndpt = NULL;
	
	for(i=0;i<IFX_CMGR_MAX_AGENTS; i++)
	{
		if(!strcasecmp(pxEndptInfo[i].szEndptId, szEndptId))
		{
			/*Match Found*/
			(*ppxEndpt)=pxEndptInfo + i;
			bRet=IFX_TRUE;
			break;
		}
	}
	return bRet;
}

/*****************************************************************************
 *  Function Name   :IFX_CMGR_AreCallBacksOk 
 *  Description     :The function checks if the mendatory CBs for an agent are
 *  						being registered.
 *  					      
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_AreCallBacksOk(IN char8* szEndptId,
					 IN x_IFX_CMGR_CallBackList* pxCB)
{
	
	boolean bRet = IFX_TRUE;
	if(!strcasecmp(szEndptId, IFX_NA_ENDPT_ID))
	{
		/*if the EID passed is NA, check for NA params*/
		if(IFX_FALSE == IFX_CMGR_IsCallCtrlCB_Ok(pxCB))
			return IFX_FALSE;
		if(IFX_FALSE == IFX_CMGR_IsMediaOfferAnswerCB_Ok(pxCB))
			return IFX_FALSE;
		if(IFX_FALSE ==IFX_CMGR_TransferCB_NA_Ok(pxCB))
			return IFX_FALSE;
		if(IFX_FALSE ==IFX_CMGR_IsNetworkAgentRegSubsCB_Ok(pxCB))
			return IFX_FALSE;
	}
	else if (!strcasecmp(szEndptId, IFX_CFG_AGENT_ENDPT_ID))
	{
		/*if the EID passed is CFG agent, check for CFG params*/
		if(IFX_FALSE == IFX_CMGR_IsCfgAgentCB_Ok(pxCB))
			return IFX_FALSE;
	}
	else if (!strcasecmp( szEndptId, IFX_RTP_AGENT_ENDPT_ID ))
	{
		/*if the EID passed is RTP agent, check for RTP params*/
		if(IFX_FALSE == IFX_CMGR_IsRtpSessionCB_Ok(pxCB))
			return IFX_FALSE;
	}
#ifdef FAX_SUPPORT
	else if (!strcasecmp( szEndptId, IFX_FAX_AGENT_ENDPT_ID ))
	{
		/*if the EID passed is FAX agent, check for FAX params*/
		if(IFX_FALSE == IFX_CMGR_IsFaxSessionCB_Ok(pxCB))
			return IFX_FALSE;
	}
#endif
	else
	{
		/*If nothing else matches it must be an EXTN or FXO*/
		if(IFX_FALSE == IFX_CMGR_IsCallCtrlCB_Ok(pxCB))
			return IFX_FALSE;
		if(IFX_FALSE ==IFX_CMGR_TransferCB_Ok(pxCB))
			return IFX_FALSE;
	}
	return bRet;
}


/*!
	\brief	Will be invoked by an agent on behalf an endpoint it 
				serves to regsiter the various call-backs it implements 
	\param[in]	 aszEndptId is the array of identifier of the Endpoint(s)
	\param[in]   uiNumOfEndpt Number of Endpoints in the array above
	\param[in]	 pxCallBackList The list of function pointers
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallBacksRegister(
								IN char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
								IN uint32 uiNumOfEndpt,
								IN struct x_IFX_CMGR_CallBackList* pxCallBackList
								)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 i=0;
	uint16 unIdx = 0;
	x_IFX_CMGR_EndptInfo* pxTempEndptInfo = NULL;
	x_IFX_CMGR_EndptInfo** ppxTempEndptInfo = &pxTempEndptInfo;

	/* Find if the endpoint[i] already exists in the array. If so then
	 * reject the API with failure. Repeat this step for each of the endpoints.*/
	for(i=0; i<uiNumOfEndpt; i++)
	{
		if(IFX_TRUE == IFX_CMGR_FoundEndptInArray(
											aszEndptId[i],&pxTempEndptInfo))
		{
			/*Error - Endpt already exists - Reject API with IFX_FAILURE*/
			goto err;
		}
	}

	/* Check if the mandatory parameters are present*/
	if(IFX_TRUE != IFX_CMGR_AreCallBacksOk(aszEndptId[0], pxCallBackList))
	{
		/* Some essential CBs are missing - Reject API*/
		goto err;
	}
	
	for(i=0; i<uiNumOfEndpt; i++)
	{
		/*Allocate the Endpts structs one by one*/
		if(IFX_FAILURE==
				IFX_CMGR_AllocStruct((void**)ppxTempEndptInfo,
						  &unIdx,IFX_CMGR_ENDPT_INFO))
		{
			goto err; /*DEBUG - Major Error*/
		}
		memset(pxTempEndptInfo, 0, sizeof(x_IFX_CMGR_EndptInfo));
		pxTempEndptInfo->eStructStatus=IFX_CMGR_STRUCT_OCCUPIED;
		/*Copy the Endpt Id into this struct*/
		strncpy(pxTempEndptInfo->szEndptId, aszEndptId[i],IFX_MAX_ENDPOINTID_LEN-1);
		/*Malloc memory for the CB Info struct in the structure*/
		if(IFX_FAILURE == IFX_CMGR_AllocCallBackInfoStruct
							 (&pxTempEndptInfo->pxCallBackInfo))
		{
			goto err; /*DEBUG*/
		}
		/*Copy the members to the Call Back list struct*/
		memcpy(&pxTempEndptInfo->pxCallBackInfo->xCallBackList, 
							 pxCallBackList, sizeof(x_IFX_CMGR_CallBackList));
		
		/*Increment the reference count*/	
		++pxTempEndptInfo->pxCallBackInfo->ucRefCnt;
		
		/*Nullify pxTempEndptId*/
		pxTempEndptInfo = NULL;
	}

	return eRet;

err:
	eRet = IFX_FAILURE;
	return eRet;
}


void IFX_CMGR_FreeCB_Struct(IN struct x_IFX_CMGR_CallBackList* pxCB)
{
	memset(pxCB, 0, sizeof(x_IFX_CMGR_CallBackList));
}

void IFX_CMGR_FreeEndptInfoStruct(IN x_IFX_CMGR_EndptInfo* pxEndptInfo)
{
	memset(pxEndptInfo, 0, sizeof(x_IFX_CMGR_EndptInfo));
}

/*!
	\brief	Will be invoked by an agent on behalf an endpoint it 
				serves to un-regsiter the various call-backs it implements 
	\param[in]	aszEndptId is the array of identifier of the Endpoint(s)
	\param[in]   uiNumOfEndpt Number of Endpoints in the array above
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallBacksUnRegister(
								IN char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
								IN uint32 uiNumOfEndpt
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 i=0;
	x_IFX_CMGR_EndptInfo* pxEid = NULL;
	
	for(i=0; i<uiNumOfEndpt; i++)
	{
		/* Endpt found?*/
		if(IFX_TRUE == IFX_CMGR_FoundEndptInArray(aszEndptId[i],&pxEid))
		{
			if(pxEid->pxCallBackInfo->ucRefCnt > 1)
			{
				IFX_CMGR_CallsDiscForEndpt(aszEndptId[i]);
				/*Do not Free the CB structure - DeAlloc the EndptInfo structure*/
				IFX_CMGR_FreeEndptInfoStruct(pxEid);
			}
			else
			{
				/* Free the Dynamic memory of the CallBackInfo structure*/
				IFX_CMGR_FreeCallBackInfoStruct(pxEid->pxCallBackInfo);
				IFX_CMGR_FreeEndptInfoStruct(pxEid);
			}
		}
		else
		{
			/* DEBUG*/
			goto err;
		}
	}

	return eRet;

err:
	eRet = IFX_FAILURE;
	return eRet;
}

/*****************************************************************************
 *  Function Name   :IFX_CMGR_IsRangeOk
 *  Description     :The function checks if the uiStartOff to the uiStopOff
 *  						in the x_IFX_CMGR_CallBackList structure is non-null.
 *  					      
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsRangeOk(x_IFX_CMGR_CallBackList* pxCB, 
					 						uint32 uiStartOff, 
											uint32 uiStopOff)
{
	boolean bRet = IFX_TRUE;
	uint32 uiStartAddr = (uint32)pxCB + uiStartOff;
	uint32 uiStopAddr = ((uint32)pxCB) + uiStopOff + sizeof(uint32);
	uint32* puiTemp = (uint32*)uiStartAddr;
	
	while (((uint32)puiTemp) < (uiStopAddr))
	{
		/*Still less than the final value*/
		if(!(*puiTemp))
		{
			bRet = IFX_FALSE;
			break;
		}	
		else
			puiTemp++;
	}
	return bRet;
}
/*******************************************************************************
 * This section is only needed for the Configuration agent.  - START -
 *******************************************************************************/
/*!
	\brief Called by the Configuration agent to disconnect all the calls for 
			 a VoIP line in case a VoIP line was disbaled by some config mechanism
	\param[in] unLineId is the identification for the VOIP line
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallsDiscForLine(
					                 /*VoIP Line Info for which calls have to be released*/
					                               IN uint16 unLineId)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	x_IFX_CMGR_CallLeg* pxLeg = vxCmgrInfo.axCallLeg; 
	uint16 i = 0;
	
	for(i=0;i<IFX_CMGR_MAX_CALL_LEGS;i++)
	{
		if((IFX_CMGR_STRUCT_FREE==pxLeg[i].eStructStatus)||(!pxLeg[i].uiCallId))	
			continue;
		if((IFX_CMGR_TYPE_VOIP == pxLeg[i].xLegOwnerInfo.eOwnerType) && 
			(unLineId==pxLeg[i].xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId)) 
		{
			IFX_CMGR_InvokeRemoteCallRelease(&pxLeg[i], IFX_MAX_REASON, NULL);
			/*Release the Call Leg as if the release was invoked from the pxLeg*/		
			eRet = IFX_CMGR_CallRelease(pxLeg[i].uiCallId,
								 IFX_MAX_REASON, NULL, &eStatus, &eReason);							
			IFX_CMGR_DeAllocCallLeg(&pxLeg[i]);	
		}
	}
	return eRet;
}

/*!
	\brief Called by the Configuration agent to disconnect all the calls for 
			 an endpoint in case the endpoint-id was changed or the endpoint was disabled 
			 by some config mechanism
	\param[in] szEndptId	is the identification for the endpoint
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallsDiscForEndpt(
					                 /*Endpoint ID for which calls have to be released*/
					                                IN char8* szEndptId)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	x_IFX_CMGR_CallLeg* pxLeg = vxCmgrInfo.axCallLeg; 
	uint16 i = 0;
	
	for(i=0;i<IFX_CMGR_MAX_CALL_LEGS;i++)
	{
		if((IFX_CMGR_STRUCT_FREE==pxLeg[i].eStructStatus)||(!pxLeg[i].uiCallId))	
			continue;
		if(!strcasecmp(szEndptId, pxLeg[i].xLegOwnerInfo.szEndptId))
		{
			IFX_CMGR_InvokeRemoteCallRelease(&pxLeg[i], IFX_MAX_REASON, NULL);
			/*Release the Call Leg as if the release was invoked from the pxLeg*/		
			eRet = IFX_CMGR_CallRelease(pxLeg[i].uiCallId,
								 IFX_MAX_REASON, NULL, &eStatus, &eReason);							
			IFX_CMGR_DeAllocCallLeg(&pxLeg[i]);	
		}
	}
	return eRet;
}

/*!
	\brief Called by the Configuration agent to disconnect all the calls in the system 
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_AllCallsDisc(void)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	x_IFX_CMGR_CallLeg* pxLeg = vxCmgrInfo.axCallLeg; 
	uint16 i = 0;
	
	for(i=0;i<IFX_CMGR_MAX_CALL_LEGS;i++)
	{
		if((IFX_CMGR_STRUCT_FREE==pxLeg[i].eStructStatus)||(!pxLeg[i].uiCallId))	
			continue;

		IFX_CMGR_InvokeRemoteCallRelease(&pxLeg[i], IFX_MAX_REASON, NULL);
		/*Release the Call Leg as if the release was invoked from the pxLeg*/		
		eRet = IFX_CMGR_CallRelease(pxLeg[i].uiCallId,
						IFX_MAX_REASON, NULL, &eStatus, &eReason);						
		IFX_CMGR_DeAllocCallLeg(&pxLeg[i]);	
	}
	return eRet;
}

/*******************************************************************************
 * This section is only needed for the Configuration agent.  - END -
 *******************************************************************************/
/*!
	\brief	Will be an agent to send digits in the middle of 
				a call to the remote party.  
	\param[in]	 uiCallId is the identifier of the call
	\param[in]	 pxDgtInfo The digit string
	\param[out]	 peStatus is the status of the Req
	\param[out]	 peReason  incase of failure, this parameter provides the 
					 specific reason.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_DigitsInCallSnd(
							IN uint32 uiCallId, 
							IN x_IFX_CMGR_DgtInfo *pxDgtInfo,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg  = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = pxLeg?pxLeg->pxPeer:NULL;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg?pxLeg->pxCurrCnxt:NULL;
	uint8 ucLineId = 
				pxPeer?pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId:0;
	/*
	x_IFX_CMGR_VoipLegInfo *pxLegInfo = 
							pxPeer?&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo:NULL;
	uchar8 ucDynPt = 0;
	*/
	boolean bEnabled = IFX_FALSE;
	uint16 i=0;
	
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason = IFX_MAX_REASON;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg||!pxCnxt||!pxPeer)
	{
		return IFX_FAILURE;
	}

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "Digit String ",pxDgtInfo->szDigits);
	
	/* See who is giving digits - If its Voip - Drop them*/
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		/* DEBUG*/
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
										"Digits From NA dropped!");
		return eRet;
	}

	/* If the state of the caller is not CONV then drop the request*/
	if(IFX_CMGR_STATE_CONV != pxLeg->eCurrState)
	{
		/* DEBUG*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
										"Digits not in CONV state! - Dropped");
		return eRet;
	}

	/* Check the type of the peer party. If its Fxo the invoke MMGR to 
	 * send the digits to FXO (in case its analog FXO) */	
	if(IFX_CMGR_TYPE_FXO == pxPeer->xLegOwnerInfo.eOwnerType)
	{
		/* If the FXO agent has registered an CB then give it to it else
		 * give it to MMGR*/
		if(pxPeer->pxCallBackList->pfnDigitsInCallRcv)
		{
			eRet = pxPeer->pxCallBackList->pfnDigitsInCallRcv(pxPeer->uiCallId, 
								 						pxDgtInfo, pxPeer->pvPrivateData);
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															"Digits given to FXO agent!");
		}
		else
		{
			/* TO DO - Invoke MMGR to play digits on FXO*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															"Digits given to MMGR for FXO!");
			for(i=0;i<strlen(pxDgtInfo->szDigits);i++){
				IFX_MMGR_DtmfPlayRemote(pxCnxt->iResId, pxPeer->xLegOwnerInfo.szEndptId, 
				pxLeg->xLegOwnerInfo.szEndptId,pxDgtInfo->szDigits[i]);
			}
		}
	}
	else
	if(IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType)
	{	/* Its an extension - If registered give digits to them*/
		if(pxPeer->pxCallBackList->pfnDigitsInCallRcv)
		{
			eRet = pxPeer->pxCallBackList->pfnDigitsInCallRcv(pxPeer->uiCallId, 
									 						pxDgtInfo, pxPeer->pvPrivateData);
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															"Digits given to EXTN agent!");
		}
		else
		{
			/* TO DO - Invoke MMGR to play digits on EXTN*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
															"Digits given to MMGR for EXTN!");
			for(i=0;i<strlen(pxDgtInfo->szDigits);i++){
				IFX_MMGR_DtmfPlayRemote(pxCnxt->iResId, pxPeer->xLegOwnerInfo.szEndptId, 
				pxLeg->xLegOwnerInfo.szEndptId,pxDgtInfo->szDigits[i]);
			}
		}
	}
	else
	{	/* Its a Voip Party*/
		/* Call MMGR API to play digit tone on the VOIP end*/
			for(i=0;i<strlen(pxDgtInfo->szDigits);i++){
				IFX_MMGR_DtmfPlayRemote(pxCnxt->iResId, pxPeer->xLegOwnerInfo.szEndptId, 
				pxLeg->xLegOwnerInfo.szEndptId,pxDgtInfo->szDigits[i]);
			}
		/*Check for SIP info Configuration*/
		IFX_LMGR_GetSipInfoCfgStatus(ucLineId,&bEnabled,peReason);
		/* If SIP info is enabled then send the info message*/	
		if((IFX_TRUE == bEnabled) && pxPeer->pxCallBackList->pfnDigitsInCallRcv)
		{
			eRet = pxPeer->pxCallBackList->pfnDigitsInCallRcv(pxPeer->uiCallId, 
									 						pxDgtInfo, pxPeer->pvPrivateData);
		}
# if 0
		else 
		{
			/*Check the Codec list on the Voip Side for DTMF 2833. 
				If its present there then invoke MMGR to send digits with 2833*/
			if(pxLegInfo->xNegCodecInfo.unNoOfCodecs)
			{
				IFX_CMGR_SearchForDtmf(&pxLegInfo->xNegCodecInfo,&ucDynPt);
				if(ucDynPt)
				{
					/* TO DO - Invoke MMGR to send out RFC 2833 packets*/
					IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
																"Digits given to MMGR for Voip 2833!");
				}
			}
		}
#endif
	}	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return eRet;
}

# if 0
	//Function Entry info
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,__FILE__);

	//String Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "The string goes here");
	//Integer Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Info goes here",integer goes here);
	//String Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "Info Goes here",String goes here);

	//String Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "The string goes here");
	//Integer Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
             "Info goes here",integer goes here);

	//String Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
                 "Info Goes here",String goes here);
# endif
