/****************************************************************************
 **   FILE NAME       : IFX_CallMgr.c
 **   PROJECT         : DECT VOIP GW
 **   MODULES         : Call-Manager 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : DECT VoIP Application Team
 **   DESCRIPTION     : This file contains Code for Call Control  
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2007 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#ifdef UDP_REDIRECT
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
#endif
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "IFX_Config.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_CallMgr_CfgIf.h"
#include "IFX_CallMgr.h"
#include "IFX_LineMgr.h"
#include "IFX_Agents_CfgIf.h"

#define printf(...)

#ifndef CAT_IQ2_0
	#define CAT_IQ2_0
#endif
#define IFX_MAX_VOIP_LINES 3
#define IFX_PSTN_LINE (IFX_MAX_VOIP_LINES+1)
/*! \brief Global variable for the system*/
x_IFX_CMGR_CallMgrInfo vxCmgrInfo;

/*! \brief Macro to find the index on the Call Context array*/
#define IFX_CMGR_FindCallCnxtIdx(pxCnxt) (pxCnxt-vxCmgrInfo.axCallCnxt)

/*Macro to find the minimum of two numbers*/
#define IFX_CMGR_MIN_VAL(A,B) ((A<B)?A:B)

/*Macro to add 2833 to the bottom of the codec list*/
#define IFX_CMGR_AddDtmfToCodecList(pxCodecs,ucDynPt)\
	if((pxCodecs->unNoOfCodecs < IFX_MAX_CODECS) && (ucDynPt))\
	{\
		pxCodecs->axCodec[pxCodecs->unNoOfCodecs].uiCodec = IFX_DIGIT_2833;	\
		pxCodecs->axCodec[pxCodecs->unNoOfCodecs].ucDynPT = ucDynPt;\
		++pxCodecs->unNoOfCodecs;\
	}			 

/*Macro to do common actions on Transfer failure*/
#define IFX_CMGR_DoTxFailCommonActions(pxParent,pxChild,pxPeer,pxCnxt)\
{\
	pxCnxt->iResIdForTransfer = 0;\
	IFX_CMGR_DeAllocCallLeg(pxChild);\
	pxParent->pxChild = NULL;\
	pxCnxt->eTypeOfTransfer = 0;\
	IFX_CMGR_ChangeState(pxParent, pxParent->ePrevState, 0);\
	IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);\
}

/*Macro for Common Actions for Replaces Call Failure*/
#define IFX_CMGR_DoRepCallCommonActions()\
{\
		*peStatus = IFX_CMGR_STATUS_FAIL;\
		IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxNew, pxLeg);\
		IFX_CMGR_DeAllocCallLeg(pxNew);\
		IFX_CMGR_InvokeRemoteCallRelease(pxPeer, IFX_TERMINATED, NULL);\
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);\
		eRet = IFX_SUCCESS;\
		IFX_DBGA(vxCmgrInfo.ucDebugId,\
										IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No resources for call");\
}

/* Just TEMP....*/
EXTERN e_IFX_MMGR_Return IFX_MMGR_LecDisable(int32 iResourceId);
/*CoC Power savings changes - STARTS*/
#if 1
EXTERN e_IFX_MMGR_Return IFX_MMGR_MftdEnable(int32 iResourceId, boolean bEnable);
#endif
/*End*/
EXTERN e_IFX_Return 
IFX_CIF_EndptListGet(IN e_IFX_EndptType eEpType,
	                   IN_OUT uchar8* pucSize,
	                   OUT char8 aszEndpointList[][IFX_MAX_ENDPOINTID_LEN],
									   OUT e_IFX_ReasonCode* peReason);


STATIC boolean IFX_CMGR_MatchMediaParams
							( IN x_IFX_CMGR_CodecParams* pxLocCodecs,
							  IN x_IFX_CMGR_CodecParams* pxRemCodecs,
							  IN x_IFX_CMGR_RtpParams* pxLocRtp,
							  IN x_IFX_CMGR_RtpParams* pxRemRtp,
							  OUT x_IFX_CMGR_CodecParams* pxCommonCodecs,
							  OUT x_IFX_CMGR_RtpParams* pxNegRtp);

STATIC e_IFX_Return IFX_CMGR_SendRelToInCls(IN x_IFX_CMGR_CallLeg* pxOut, 
					 										IN x_IFX_CMGR_CallLeg* pxDontRelLeg);
STATIC e_IFX_Return IFX_CMGR_InsertCodecAtPos(
								IN_OUT x_IFX_CMGR_CodecParams *pxCodecList,
								IN uint32 uiOldPos, IN uint32 uiNewPos);
STATIC e_IFX_Return IFX_CMGR_ReOrderCodecsForWB(
								IN_OUT x_IFX_CMGR_CodecParams *pxCodecs1,
								IN_OUT x_IFX_CMGR_CodecParams *pxCodecs2,
								IN boolean bReOrderCodecs1);

STATIC e_IFX_Return IFX_CMGR_FreeMediaResource(
									IN int32 iResId,
									IN char8* szFrom,
									IN char8* szTo,
									OUT e_IFX_ReasonCode* peReason);

STATIC e_IFX_Return IFX_CMGR_ResumeCallIntVoip(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason);

STATIC e_IFX_Return IFX_CMGR_GetReqCnxtAndLegs(
					 IN uint8 ucSize,
					 IN void* pvPrivateData,
					 OUT x_IFX_CMGR_ReqContext** ppxCnxt, 
					 OUT e_IFX_ReasonCode* peReason);
STATIC e_IFX_Return IFX_CMGR_PrepReqCnxt
						(
							IN x_IFX_CMGR_ReqContext*  pxCnxt,
							IN char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
							IN uchar8 ucNumEndpts,
							OUT uchar8 *pucValidLegs
					 	);
STATIC e_IFX_Return IFX_CMGR_InvokeSubsToVmResp(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
						IN uint32 uiExpTime,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode);
STATIC e_IFX_Return IFX_CMGR_GetNewLeg(IN uint32*);
/*****************************************************************************
 *  Function Name   : IFX_CMGR_PrintCallIdList
 *  Description     : This function prints the exit value of a function
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_PrintCallIdList(const char8* pszFnName)
{
	int32 i = 0, iCnt = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_NONE,IFX_DBG_ATA_STRING_INFO,
                 "Call ID List for Function",pszFnName);

	for(i=0;i<IFX_CMGR_MAX_CALL_LEGS;i++)
	{
		if(vxCmgrInfo.auiCallIdList[i])
		{
			++iCnt;
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_NONE,IFX_DBG_ATA_INT_INFO,
    	         "CID",vxCmgrInfo.auiCallIdList[i]);
		}
	}
	if(!iCnt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_NONE,IFX_DBG_STR, "No Call ID Used");
	}
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_PrintExitInfo
 *  Description     : This function prints the exit value of a function
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_PrintExitInfo(e_IFX_Return eRet, 
					 								const char8* pcFunc, int32 iLine)
{
	if(IFX_FAILURE == eRet)
	{
	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
             "FAILURE from Line",iLine);
	}
	else
	{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Success from Line",iLine);
	}
}

/*****************************************************************************
 *  Function Name : IFX_CMGR_IsIdValid
 *  Description 	: The function checks if a call/req-ID given by agent is ok.
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_IsIdValid(IN uint32 uiId, IN boolean bCallId)
{
	e_IFX_Return eRet = IFX_FAILURE;
	uint32* puiId = NULL;
	uint32 i = 0;
	uint32 uiMax = 0;
	
	if(IFX_TRUE == bCallId)
	{
		puiId = vxCmgrInfo.auiCallIdList;
		uiMax = IFX_CMGR_MAX_CALLS;
	}
	else
	{
		puiId = vxCmgrInfo.auiReqIdList;
		uiMax = IFX_CMGR_MAX_REQ_LEGS; 
	}
	for(i=0;i<uiMax;i++)
	{
		if(uiId == puiId[i])
		{
			eRet = IFX_SUCCESS;
		 	break;	
		}
	}
	return eRet;
}
/*****************************************************************************
 *  Function Name : IFX_CMGR_AddToIdList
 *  Description 	: The function adds the call/req Id to the call Id List.
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_AddToIdList(IN uint32 uiId, IN boolean bCallId)
{
	e_IFX_Return eRet = IFX_FAILURE;
	uint32* puiId = NULL;
	uint32 i = 0;
	uint32 uiMax = 0;
	
	if(IFX_TRUE == bCallId)
	{
		puiId = vxCmgrInfo.auiCallIdList;
		uiMax = IFX_CMGR_MAX_CALLS;
	}
	else
	{
		puiId = vxCmgrInfo.auiReqIdList;
		uiMax = IFX_CMGR_MAX_REQ_LEGS; 
	}
	for(i=0;i<uiMax;i++)
	{
		if( 0 == puiId[i])
		{
			eRet = IFX_SUCCESS;
			puiId[i] = uiId; 
		 	break;	
		}
	}
	return eRet;
}
/*****************************************************************************
 *  Function Name : IFX_CMGR_RemoveFromIdList
 *  Description 	: The function removes a call/req Id from the Id List.
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_RemoveFromIdList(IN uint32 uiId,IN boolean bCallId)
{
	e_IFX_Return eRet = IFX_FAILURE;
	uint32* puiId = NULL;
	uint32 i = 0;
	uint32 uiMax = 0;
	
	if(IFX_TRUE == bCallId)
	{
		puiId = vxCmgrInfo.auiCallIdList;
		uiMax = IFX_CMGR_MAX_CALL_LEGS;
	}
	else
	{
		puiId = vxCmgrInfo.auiReqIdList;
		uiMax = IFX_CMGR_MAX_REQ_LEGS; 
	}
	for(i=0;i<uiMax;i++)
	{
		if( uiId == puiId[i])
		{
			eRet = IFX_SUCCESS;
			puiId[i] = 0; 
		 	break;	
		}
	}
	return eRet;
}
/*****************************************************************************
 *  Function Name : IFX_CMGR_IsMPC_WB
 *  Description 	: The function checks if a codec is the Most Prefered Codec
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE 
 *  Notes           :
 ****************************************************************************/
inline boolean IFX_CMGR_IsMPC_WB(x_IFX_CMGR_CodecParams* pxList)
{
	return ((pxList->axCodec[0].uiCodec==IFX_G722_64)?IFX_TRUE:IFX_FALSE);
}

/*****************************************************************************
 *  Function Name : IFX_CMGR_SetMediaCallbacks
 *  Description 	: The function sets pointers to RTP and FAX CallBacks
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_SetMediaCallbacks(
								IN x_IFX_CMGR_CallLeg* pxVoipLeg
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	/*Setup the RTP ptr also */
	if(IFX_FAILURE == IFX_CMGR_GetCBList(IFX_RTP_AGENT_ENDPT_ID,
											&pxVoipLeg->pxRtpCB))
	{
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
#ifdef FAX_SUPPORT
	/*Setup the Fax ptr also */
	if(IFX_CMGR_GetCBList(IFX_FAX_AGENT_ENDPT_ID,&pxVoipLeg->pxFaxCB)
								 																				== IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
#endif
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AddVoipAddrToMissedCallReg
 *  Description     : Function adds an Voip Entry into missed call register
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AddVoipAddrToMissedCallReg
		  (
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_VoipAddr* pxAddr
		  )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xAddr;
	uint8 ucVoipLineId = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	memset(&xAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
	xAddr.eAddressType = IFX_CMGR_TYPE_VOIP;	
	memcpy(&xAddr.uxAddressInfo.xVoipAddr, pxAddr, sizeof(x_IFX_CMGR_VoipAddr));	
	ucVoipLineId = pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId;
	IFX_LMGR_AddToMissedCallReg(ucVoipLineId, &xAddr);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeDtmfSdp
 *  Description     : This function is used to make SDP for NA regarding
 *  						 DTMF 2833. The function checks if the Local DTMF cfg is
 *  						 present and if so, it adds the 2833 at the bottom of the
 *  						 Offered/Negotaited Codec List
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_MakeDtmfSdp( IN x_IFX_CMGR_VoipLegInfo* pxLegInfo,
					 						 IN x_IFX_CMGR_CodecParams* pxCodecs)
					 						 
{
  int i=0, insPos = 0, iFlag =1;
	if(IFX_MAX_CODECS == pxCodecs->unNoOfCodecs)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "No Space Found!!");
		/*DEBUG*/ return;
	}
	
	if((IFX_MMGR_TEL_EVENT_VOICE_IN_BAND_RFC_2833 ==
							 pxLegInfo->xLocTelEvtInfo.eEventTransMode) || 
		(IFX_MMGR_TEL_EVENT_RFC_2833 == 
								 pxLegInfo->xLocTelEvtInfo.eEventTransMode))
	{
		pxCodecs->axCodec[pxCodecs->unNoOfCodecs].uiCodec = IFX_DIGIT_2833;
		pxCodecs->axCodec[pxCodecs->unNoOfCodecs].ucDynPT = 
			  								pxLegInfo->xLocTelEvtInfo.ucPayLoadTypeTx; 
		++pxCodecs->unNoOfCodecs;
   iFlag= 1;
	}
  
  if(!iFlag){
		return;
  }
/* FIX_2833 : To bring 2833 Codec ahead of T38 codec */

  for(i=0; i<pxCodecs->unNoOfCodecs; i++){
    if(pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP || 
        pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP)
    {
     insPos = i;
		}
  }
  if(insPos != 0) {
  IFX_CMGR_InsertCodecAtPos(pxCodecs,pxCodecs->unNoOfCodecs-1,insPos);
  }
/*FIX_2833 end*/
  return;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsCallConn
 *  Description     : This function check if the call has been formed or not?
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsCallConn(x_IFX_CMGR_CallLeg* pxLeg)
{
	boolean bRet = IFX_TRUE;
	if(((IFX_CMGR_RECV_RESP_PENDING == pxLeg->eCurrState) &&
			(IFX_CMGR_RESP_PEND_INVITE == pxLeg->eRespPendEvt)) ||
			(IFX_CMGR_STATE_RINGBACK == pxLeg->eCurrState) ||
			(IFX_CMGR_STATE_RINGING == pxLeg->eCurrState) ||
			((IFX_CMGR_SEND_RESP_PENDING == pxLeg->eCurrState) && 
			 (IFX_CMGR_RESP_PEND_INVITE == pxLeg->eRespPendEvt))
		)
		bRet = IFX_FALSE;
	return bRet;
}


/*****************************************************************************
 *  Function Name   :IFX_CMGR_GetMMGR_Codecs
 *  Description     : This function Converts common defs Codecs to MMGR Codecs
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_GetMMGR_Codecs(
										IN x_IFX_Codec* pxCodec,
										OUT x_IFX_MMGR_CodecInfo* pxMMGRCodec
										)
{
	boolean bReturn = IFX_FALSE;
	memset(pxMMGRCodec,0,sizeof(x_IFX_MMGR_CodecInfo));
	
	switch(pxCodec->uiCodec)
	{
		case IFX_G711_ALAW: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_ALAW;
			bReturn = IFX_TRUE;
			break;
		case IFX_G711_ULAW:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_MLAW;
			bReturn = IFX_TRUE;
			break;
		case IFX_G729_8:
			pxMMGRCodec->eCodecType =IFX_MMGR_CODEC_G729_AB ;
			bReturn = IFX_TRUE;
			break;
		case IFX_G729_E:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G729_E;
			bReturn = IFX_TRUE;
			break;
		case IFX_G723_5_3: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G723_5_3;
			bReturn = IFX_TRUE;
			break;
		case IFX_G723_6_3:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G723_6_3;
			bReturn = IFX_TRUE;
			break;
		case IFX_G728:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G728;
			bReturn = IFX_TRUE;
			break;
		case IFX_G726_16: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G726_16;
			bReturn = IFX_TRUE;
			break;
		case IFX_G726_24: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G726_24;
			bReturn = IFX_TRUE;
			break;
		case IFX_G726_32: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G726_32;
			bReturn = IFX_TRUE;
			break;
		case IFX_G726_40: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G726_40;
			bReturn = IFX_TRUE;
			break;
		case IFX_G722_64:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G722_64;
			bReturn = IFX_TRUE;
			break;
		case IFX_G722_1_24:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G722_1_24;
			bReturn = IFX_TRUE;
			break;
		case IFX_G722_1_32:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_G722_1_32;
			bReturn = IFX_TRUE;
			break;
		case IFX_ILBC: 
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_ILBC;
			bReturn = IFX_TRUE;
			break;
		case IFX_T38_UDP:
		case IFX_T38_TCP:
			pxMMGRCodec->eCodecType = IFX_MMGR_CODEC_T38;
			bReturn = IFX_TRUE;
			break;
		default:
			break;
	}

	if(IFX_FALSE != bReturn)
	{
		pxMMGRCodec->ucPacketLength = pxCodec->ucFrameSize;
		pxMMGRCodec->ucIANA_PayloadType = pxCodec->ucDynPT;
		if(pxCodec->ucDynPT > 127) {
			pxMMGRCodec->ucIANA_PayloadType = 0;
		}
	}
	return bReturn;

}

/*****************************************************************************
 *  Function Name   :IFX_CMGR_GetNA_Codecs
 *  Description     : This function Converts MMGR codecs tocommon defs Codecs
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
boolean IFX_CMGR_GetNA_Codecs(
										IN x_IFX_MMGR_CodecInfo* pxMMGRCodec,
										OUT x_IFX_Codec* pxCodec
										)
{
	boolean bReturn = IFX_FALSE;
	memset(pxCodec,0,sizeof(x_IFX_Codec));
	
	switch(pxMMGRCodec->eCodecType)
	{		
		case IFX_MMGR_CODEC_ALAW: 
			pxCodec->uiCodec = IFX_G711_ALAW ;
			bReturn = IFX_TRUE;
			break;
		case IFX_MMGR_CODEC_MLAW: 
			pxCodec->uiCodec = IFX_G711_ULAW ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G729_AB:
			pxCodec->uiCodec = IFX_G729_8 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G729_E: 
			pxCodec->uiCodec = IFX_G729_E ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G723_5_3: 
			pxCodec->uiCodec = IFX_G723_5_3 ;
			bReturn = IFX_TRUE;
			break;
  		case IFX_MMGR_CODEC_G723_6_3:
			pxCodec->uiCodec = IFX_G723_6_3 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G728: 
			pxCodec->uiCodec = IFX_G728 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G726_16: 
			pxCodec->uiCodec = IFX_G726_16 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G726_24: 
			pxCodec->uiCodec = IFX_G726_24 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G726_32:
			pxCodec->uiCodec = IFX_G726_32 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G726_40:
			pxCodec->uiCodec = IFX_G726_40 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G722_64:
			pxCodec->uiCodec = IFX_G722_64 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G722_1_24:
			pxCodec->uiCodec = IFX_G722_1_24 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_G722_1_32:
			pxCodec->uiCodec = IFX_G722_1_32 ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_ILBC:
			pxCodec->uiCodec = IFX_ILBC ;
			bReturn = IFX_TRUE;
			break;
   	case IFX_MMGR_CODEC_T38:
			pxCodec->uiCodec = IFX_T38_UDP ;
			bReturn = IFX_TRUE;
			break;
		default:break;
	}

	if(IFX_FALSE != bReturn)
	{
		pxCodec->ucFrameSize = pxMMGRCodec->ucPacketLength ;
		pxCodec->ucDynPT = pxMMGRCodec->ucIANA_PayloadType ;
	}

	return bReturn;

}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ConvertToMMGR_Codecs
 *  Description     : This function Converts NA codecs to MMGR codecs 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ConvertToMMGR_Codecs(
					 IN x_IFX_CodecList* pxCodecList,
					 OUT x_IFX_MMGR_CodecList* pxMmgrCodecList)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint16 i=0, j=0;
	boolean bT38_Added = IFX_FALSE;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	memset(pxMmgrCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	
	if(!pxCodecList || !pxCodecList->unNoOfCodecs)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}
	
	for(j=0,i=0;i<pxCodecList->unNoOfCodecs;i++,j++)
	{
		if(IFX_FALSE == IFX_CMGR_GetMMGR_Codecs(&pxCodecList->axCodec[i], 
							 			&pxMmgrCodecList->axCodecs[j]))
		{
			/* A non matching codec is found*/
			--j;
		}
#ifdef FAX_SUPPORT
		else
		{
			if((IFX_T38_UDP == pxCodecList->axCodec[i].uiCodec)||
				(IFX_T38_TCP == pxCodecList->axCodec[i].uiCodec))
			{
				/* Check if the T38 has been received already. If yes, then
				 * clear the current structure in the target array & reduce j.
				 * If no, then set flag to indicate that FAX T38 received.*/
				if(IFX_TRUE == bT38_Added)
				{
					memset(&pxMmgrCodecList->axCodecs[j],
										 0, sizeof(x_IFX_MMGR_CodecInfo));	  
					--j;
				}
				else
				{
					bT38_Added = IFX_TRUE;
				}
			}
		}
#endif
	}

	pxMmgrCodecList->ucNoOfCodecs = j;
		
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ConvertToNA_Codecs
 *  Description     : This function Converts MMGR codecs to NA codecs 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ConvertToNA_Codecs(
					 IN x_IFX_MMGR_CodecList* pxMmgrCodecList,
#ifdef FAX_SUPPORT
					 IN boolean bAddT38_UDP,
					 IN boolean bAddT38_TCP,
					 IN boolean bAddT38_TCP_Pref,
#endif	
					 OUT x_IFX_CodecList* pxCodecList)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint16 i=0, j=0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxMmgrCodecList)
		return IFX_FAILURE;

	memset(pxCodecList,0,sizeof(x_IFX_CodecList));
	
	for(j=0,i=0;i<pxMmgrCodecList->ucNoOfCodecs && i<IFX_MAX_CODECS-1;i++,j++)
	{
		if(IFX_FALSE == IFX_CMGR_GetNA_Codecs(
							 			&pxMmgrCodecList->axCodecs[i],
										&pxCodecList->axCodec[j]))
		{
			/* A non matching codec is found*/
			--j;
		}
#ifdef FAX_SUPPORT
		else
		if(IFX_MMGR_CODEC_T38 == pxMmgrCodecList->axCodecs[i].eCodecType)
		{
			/* T38 found*/
			if((IFX_TRUE == bAddT38_UDP) && (IFX_FALSE == bAddT38_TCP))
			{
				pxCodecList->axCodec[j].uiCodec = IFX_T38_UDP;
			}else
			if((IFX_TRUE == bAddT38_TCP) && (IFX_FALSE == bAddT38_UDP))
			{
				pxCodecList->axCodec[j].uiCodec = IFX_T38_TCP;
			}else
			if((IFX_TRUE == bAddT38_TCP) && (IFX_TRUE == bAddT38_UDP) && j<IFX_MAX_CODECS-1)
			{
				/* Check the pref flag*/
				if(IFX_TRUE == bAddT38_TCP_Pref)
				{
					pxCodecList->axCodec[j].uiCodec = IFX_T38_TCP;
					++j;
					pxCodecList->axCodec[j].uiCodec = IFX_T38_UDP;
				}else
				{
					pxCodecList->axCodec[j].uiCodec = IFX_T38_UDP;
					++j;
					pxCodecList->axCodec[j].uiCodec = IFX_T38_TCP;
				}
			}
		}
#endif	
	}
	pxCodecList->unNoOfCodecs = j;
	for(i=0;i<j;i++)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
    	         "SIP type Codec Id = ",  pxCodecList->axCodec[i].uiCodec);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

#ifdef FAX_SUPPORT
/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeFaxServerListen
 *  Description     : Invokes CB pfnFaxServerListen 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeFaxServerListen
									(	
									 	IN x_IFX_CMGR_CallLeg* pxLeg,
										IN boolean bStopListen
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_FaxAgentInfo xFaxInfo;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
				&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	memset(&xFaxInfo,0,sizeof(x_IFX_CMGR_FaxAgentInfo));
	
	xFaxInfo.uiCallId = pxLeg->uiCallId;		
	xFaxInfo.bStopListen = bStopListen;	
	if(IFX_TRPROTO_TCP == pxLegInfo->axFaxParams[0].xFaxCfg.uiTransportProtocol)
	{
		memcpy(&xFaxInfo.axFaxParams[0], &pxLegInfo->axFaxParams[0],
																					sizeof(x_IFX_CMGR_FaxParams));
	}
	else
	{
		memcpy(&xFaxInfo.axFaxParams[0], &pxLegInfo->axFaxParams[1],
																					sizeof(x_IFX_CMGR_FaxParams));
	}
	
	eRet = pxLeg->pxFaxCB->pfnFaxServerListen(&xFaxInfo);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeStartFaxSession
 *  Description     : Invokes CB pfnFaxSessionStart 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeStartFaxSession
									(	
									 	IN x_IFX_CMGR_CallLeg* pxLeg,
										IN char8* szCoderDeviceName
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_FaxAgentInfo xFaxInfo;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
					&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	memset(&xFaxInfo,0,sizeof(x_IFX_CMGR_FaxAgentInfo));
	
	xFaxInfo.uiCallId = pxLeg->uiCallId;	
	strncpy(xFaxInfo.szCoderDeviceName,
			szCoderDeviceName,IFX_CMGR_MAX_DEVICE_NAME_LEN-1);
	
	/* TO decide if the side is an initiator*/
	if(IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
														 	IFX_CMGR_FLAG_FAX_INITIATOR))
	{
		xFaxInfo.bFaxInitiator = IFX_TRUE;
	}
	memcpy(	xFaxInfo.axFaxParams, pxLegInfo->axFaxParams,
									IFX_MAX_FAX_PROTO*sizeof(x_IFX_CMGR_FaxParams));
	/* Put the second one in the first one if the second one is empty*/
	if(!xFaxInfo.axFaxParams[0].xFaxCfg.uiTransportProtocol)
	{
		memcpy(&xFaxInfo.axFaxParams[0], 
					&xFaxInfo.axFaxParams[1], sizeof(x_IFX_CMGR_FaxParams));
		/*Clear the second one*/
		memset(&xFaxInfo.axFaxParams[1],0,sizeof(x_IFX_CMGR_FaxParams));
	}
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "Channel Name For FAX ", szCoderDeviceName);
	if(IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
														 	IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
										"ERROR - FAX ALREADY RUNNING!!!");
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	eRet = pxLeg->pxFaxCB->pfnFaxSessionStart(&xFaxInfo);
	if(IFX_SUCCESS == eRet)
	{
		/*Set flag to indicate that Fax session has been started*/
		IFX_CMGR_SET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																		IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindFaxProtoPtr
 *  Description     : This function finds the pointer to the correct Fax 
 											structure based on the protocol passed to it
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC x_IFX_CMGR_FaxParams* 
					IFX_CMGR_FindFaxProtoPtr(IN x_IFX_CMGR_FaxParams* paxFaxParams,
														uint32 uiTransProto)
{
	x_IFX_CMGR_FaxParams* pxFaxPar = NULL;
		
	if(paxFaxParams[0].xFaxCfg.uiTransportProtocol == uiTransProto)
	{
		pxFaxPar = &paxFaxParams[0];
	}else
	if(paxFaxParams[1].xFaxCfg.uiTransportProtocol == uiTransProto)
	{
		pxFaxPar = &paxFaxParams[1];
	}
	return pxFaxPar;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsPrefCodecT38
 *  Description     : This function checks if the T.38 codec is the MPC
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsPrefCodecT38(IN x_IFX_CodecList* pxCodecList)
{
	boolean bRet = IFX_FALSE;
	if((pxCodecList->axCodec[0].uiCodec == IFX_T38_TCP) || 
						 (pxCodecList->axCodec[0].uiCodec == IFX_T38_UDP))
	{
		bRet = IFX_TRUE;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"T.38 is MPC");
	}
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_SearchForT38
 *  Description     : This function checks if T38 is present in the Codec list
 *  Input Values    : 
 *  Output Values	  : 
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_SearchForT38(
					IN x_IFX_CodecList* pxCodecs,
					IN boolean* pbIsT38_UDP_Present,
					IN boolean* pbIsT38_TCP_Present,
					IN	boolean* pbIsT38_TCP_Pref)
{
	uint16 i = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	*pbIsT38_UDP_Present = IFX_FALSE;
	*pbIsT38_TCP_Present = IFX_FALSE;
	*pbIsT38_TCP_Pref = IFX_FALSE;
	boolean bT38Found = IFX_FALSE;
	for(i=0;i<pxCodecs->unNoOfCodecs;i++)
	{
		if(IFX_T38_TCP == pxCodecs->axCodec[i].uiCodec)
		{
			*pbIsT38_TCP_Present = IFX_TRUE;
			if(IFX_FALSE == bT38Found)
			{
				*pbIsT38_TCP_Pref = IFX_TRUE;
				bT38Found = IFX_TRUE;
			}
		}else
		if(IFX_T38_UDP == pxCodecs->axCodec[i].uiCodec)
		{
			*pbIsT38_UDP_Present = IFX_TRUE;
			if(IFX_FALSE == bT38Found)
			{		
				*pbIsT38_TCP_Pref = IFX_FALSE;
				bT38Found = IFX_TRUE;
			}
		}
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_SaveNegFaxPar
 *  Description     : This function checks saves the negotiated fax params in
 											the Voip leg.
 *  Input Values    : 
 *  Output Values	  : 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_SaveNegFaxPar(
					IN x_IFX_CMGR_VoipLegInfo *pxLegInfo,
					IN x_IFX_CMGR_FaxParams *pxLocFaxParams,
					IN x_IFX_CMGR_FaxParams *pxRemFaxPar
					)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint16 i=0;
	uint16 j=0;
	uint16 unMaxBitRate = 0;
	uint16 unMaxUDPDatagramSize = 0;
	uint16 unMaxUDPBufferSize = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Copy the relevant params into the right places in the FAX info array*/
	for(i=0;i<IFX_MAX_FAX_PROTO;i++)
	{
		/* Find the Index from the FAX array which has the same protocol*/
		for(j=0; j < IFX_MAX_FAX_PROTO; j++)
		{
			if((pxLocFaxParams[j].xFaxCfg.uiTransportProtocol == 
														pxRemFaxPar[i].xFaxCfg.uiTransportProtocol)	&&
					(pxLocFaxParams[j].xFaxCfg.uiTransportProtocol))	
			{
				/* Copy the remote PORT/IP into the LOCAL place.*/
				strcpy((char8 *)pxLocFaxParams[j].szRemoteFaxIpAddr, 
																		(char8 *)pxRemFaxPar[i].szRemoteFaxIpAddr);

					pxLocFaxParams[j].uiRemoteFaxPort = 
																				pxRemFaxPar[i].uiRemoteFaxPort;

					/* Save the Local values in the temp vars*/
					unMaxBitRate = pxLocFaxParams[j].xFaxCfg.unMaxBitRate;
					unMaxUDPBufferSize = 
								pxLocFaxParams[j].xFaxCfg.unUDPMaxBufferSize;
					unMaxUDPDatagramSize = 
								pxLocFaxParams[j].xFaxCfg.unUDPMaxDatagramSize;

					/* Memcpy from the Remote to Local*/
					memcpy(&pxLocFaxParams[j].xFaxCfg, 
													&pxRemFaxPar[i].xFaxCfg, sizeof(x_IFX_FaxCfg));	
					
					/*Set the minimum values of the Buffer size, Bit rate and datagram*/
					pxLocFaxParams[j].xFaxCfg.unMaxBitRate = 
								IFX_CMGR_MIN_VAL(unMaxBitRate,pxRemFaxPar[i].xFaxCfg.unMaxBitRate);
					
					pxLocFaxParams[j].xFaxCfg.unUDPMaxBufferSize =
								IFX_CMGR_MIN_VAL(unMaxUDPBufferSize,pxRemFaxPar[i].xFaxCfg.unUDPMaxBufferSize);

					pxLocFaxParams[j].xFaxCfg.unUDPMaxDatagramSize = 
								IFX_CMGR_MIN_VAL(unMaxUDPDatagramSize,pxRemFaxPar[i].xFaxCfg.unUDPMaxDatagramSize);

				}
			}
	}				
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindT38andClear
 *  Description     : This function finds the presence of T.38 Codecs in a 
 											given codec list and clears the local info of the ones
											not present in the Codec list.
 *  Input Values    : 
 *  Output Values	  : 
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_FindT38andClear(
					IN x_IFX_CMGR_CodecParams* pxCodecs,
					IN x_IFX_CMGR_FaxParams* pxLocFaxPar,
					IN x_IFX_CMGR_CallLeg* pxLeg
					)
{
	boolean bT38Udp = IFX_FALSE;
	boolean bT38Tcp = IFX_FALSE;
	boolean bT38TcpPref = IFX_FALSE;
	x_IFX_CMGR_FaxParams *pxFax = NULL;	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/*Search for T.38 in the negotiated codec list*/
	IFX_CMGR_SearchForT38(pxCodecs,&bT38Udp,&bT38Tcp,&bT38TcpPref);
	if(IFX_FALSE == bT38Udp)
	{	
		/*Find the UDP FAX structure*/
		pxFax = IFX_CMGR_FindFaxProtoPtr(pxLocFaxPar,IFX_TRPROTO_UDP);	
		if(pxFax)
		{
			/*Free the Fax UDP port etc.*/
			IFX_LMGR_FreeMediaPort(pxFax->uiLocalFaxPort,IFX_TRPROTO_UDP);								
			/* Clear the FAX UDP local FAX params structure*/
			memset(pxFax,0,sizeof(x_IFX_CMGR_FaxParams));
		}	
	}

	if(IFX_FALSE == bT38Tcp)
	{
		/*Find the TCP FAX structure*/
		pxFax = IFX_CMGR_FindFaxProtoPtr(pxLocFaxPar,IFX_TRPROTO_TCP);	
		if(pxFax)
		{
			if(IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
														 	IFX_CMGR_FLAG_WAITING_FOR_TCP_FAX))
			{
				/* Invoke CB to stop listening on FAX TCP port*/
				IFX_CMGR_InvokeFaxServerListen(pxLeg,IFX_TRUE);
						
				/* Reset Flag*/		
				IFX_CMGR_RESET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
															 	IFX_CMGR_FLAG_WAITING_FOR_TCP_FAX);
			}
					
			/*Free the FAX TCP server port. */
			IFX_LMGR_FreeMediaPort(pxFax->uiLocalFaxPort,IFX_TRPROTO_TCP);								
			/* Clear the FAX TCP local FAX params structure*/
			memset(pxFax,0,sizeof(x_IFX_CMGR_FaxParams));
		}	
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Exit");
	return;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleFaxMediaNeg
 *  Description     : This function checks handles the Fax media negotiations
 *  Input Values    : 
 *  Output Values	  : 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleFaxMediaNeg(
					IN x_IFX_CMGR_CallLeg* pxLeg,
					IN x_IFX_CMGR_CodecParams* pxCodecs,
					IN x_IFX_CMGR_FaxParams* pxLocFaxPar,
					IN x_IFX_CMGR_FaxParams* pxRemFaxPar
					)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
				&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/*Clear info for the T.38 codecs not present in the codec list*/
	IFX_CMGR_FindT38andClear(pxCodecs, pxLocFaxPar, pxLeg);	
	/* Find the negotiated FAX params and save them in the Leg*/
	IFX_CMGR_SaveNegFaxPar(pxLegInfo,pxLocFaxPar,pxRemFaxPar);
	/* If FAX T.38 UDP/TCP is the MPC then set flag to 
	 indicate that FAX has to be started instead of RTP*/
	if(IFX_TRUE == IFX_CMGR_IsPrefCodecT38(pxCodecs))
	{
		IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_ENABLE_FAX);
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
#endif	
/*****************************************************************************
 *  Function Name   : IFX_CMGR_SearchForCodec
 *  Description     : This function checks if Codec is present in the Codec list
 *  Input Values    : 
 *  Output Values	  : 
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_SearchForCodec(	IN x_IFX_CodecList* pxCodec,
												IN uint32 uiCodec, 
												OUT int32* piIndex)
{
	boolean bRet = IFX_FALSE;
	uint32 i=0;
	*piIndex = -1;
	for(i=0;i < IFX_MAX_CODECS; i++)
	{
		if(uiCodec == pxCodec->axCodec[i].uiCodec)
		{
			*piIndex = i;
			bRet = IFX_TRUE;
			break;
		}
	}
	return bRet;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_SearchForDtmf
 *  Description     : This function checks if DTMF is present in the Codec list
 *  Input Values    : 
 *  Output Values	  : 
 *  Notes           :
 ****************************************************************************/
void IFX_CMGR_SearchForDtmf(	IN x_IFX_CodecList* pxCodec,
												OUT uchar8* pucDynPt)
{
	uint32 i=0;
	*pucDynPt = 0;
	/* Search for the RFC 2833 in the Codec List - add Flag in the uiOptions*/
	for(i=0;i < IFX_MAX_CODECS; i++)
	{
		if(IFX_DIGIT_2833 == pxCodec->axCodec[i].uiCodec)
		{
			*pucDynPt = pxCodec->axCodec[i].ucDynPT;
			break;
		}
	}
}


/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindCommonCodecs 
 *  Description     : The function takes in two Codec Lists and returns 
 *  						 the matching codecs.  It is used for both the DECT and 
 *  						 the VoIP codec lists.
 *  Input Values    : pxLocCodec List is the codec list that was offered 
 *  						 initially after asking the MMGR.
 *  						 pxRemCodec List is the answer from the remote party.
 *  Output Values	  : pxCommmonCodec The intersection between the above two
 *  						 lists is returned in this array.
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_FindCommonCodecs(IN x_IFX_CodecList* pxLocCodec,
					 								IN x_IFX_CodecList* pxRemCodec,
													OUT x_IFX_CodecList* pxCommonCodec)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	int32 i=0;
	int32 j=0;
	uint32 uiNumLoc=0;
	uint32 uiNumRem=0;
	
	/* Sanity Check */
	if((!pxLocCodec)||(!pxRemCodec)||(!pxCommonCodec))
			  return IFX_FAILURE;
	
	uiNumRem=pxRemCodec->unNoOfCodecs;
	uiNumLoc=pxLocCodec->unNoOfCodecs;
	memset(pxCommonCodec,0,sizeof(x_IFX_CodecList));
	
	if(!uiNumLoc)
	{/*No matching codecs since no codecs in the remote list.*/
		pxCommonCodec->unNoOfCodecs=0;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "NO Local Codecs");
	}else
	if(!uiNumRem)
	{/*No matching codecs since no codecs in the remote list.*/
		pxCommonCodec->unNoOfCodecs=0;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "NO Remote Codecs");
	}	
	else
	{
		/*!< Take first codec and try and find the correponding in the other 
		 * list. If its present in the other list, put it into pxCommonCodec[0].
	 	 * Continue with each of the others till the Remlist is completely empty.
	 	 * Any thing that is not found in the Loc List should not be used.
	 	 */

		/*bugfix SMS01391102*/
		for(i=0;(i<uiNumRem);i++)
		{
			for(j=0;(j<uiNumLoc);j++)
			{
				/*Match Codecs between 2 lists*/
				if(pxRemCodec->axCodec[i].uiCodec == pxLocCodec->axCodec[j].uiCodec)
				{
					if(!pxRemCodec->axCodec[i].uiCodec)
							  continue;
					/*Match found - Copy into output list*/
					memcpy(&pxCommonCodec->axCodec[pxCommonCodec->unNoOfCodecs],
						&pxRemCodec->axCodec[i],
							sizeof(x_IFX_Codec));
					pxCommonCodec->axCodec[pxCommonCodec->unNoOfCodecs].ucFrameSize = 
					pxLocCodec->axCodec[j].ucFrameSize ;
          pxCommonCodec->unNoOfCodecs++;
				}
			}
		}
	}	
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_GetAnsSdpMode
 *  Description     : Returns the right mode for the LOCAL RTP to run in.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : e_IFX_Mode
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Mode IFX_CMGR_GetAnsSdpMode(IN e_IFX_Mode eLocMode,
																				IN e_IFX_Mode eRemMode)
{	
	e_IFX_Mode eNewLocMode = IFX_SENDRECV;
	/*Double array to map the SDP mode*/
	STATIC e_IFX_Mode aeNewLocMode[IFX_INACTIVE+1][IFX_INACTIVE+1] = 
	{
  	{IFX_SENDRECV,IFX_RECVONLY,IFX_SENDONLY,IFX_INACTIVE,},
  	{IFX_SENDONLY,IFX_INACTIVE,IFX_SENDONLY,IFX_INACTIVE,},
  	{IFX_SENDRECV,IFX_RECVONLY,IFX_INACTIVE,IFX_INACTIVE,},
  	{IFX_SENDRECV,IFX_RECVONLY,IFX_SENDONLY,IFX_INACTIVE}   
	}; 

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	eNewLocMode = aeNewLocMode[eLocMode][eRemMode];
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return eNewLocMode;
}
/*****************************************************************************
 *  Function Name   :	IFX_CMGR_MakeCodecsForMediaPar 
 *  Description     : Re-arranges the codecs for use of NA when NA invokes
 											IFX_CMGR_MediaParamsGet
 *  Input Values    : pxLocCod - Codecs From Local List
 *  						 			pxSipCod - Codecs for SIP
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_MakeCodecsForMediaPar(
					 OUT x_IFX_CMGR_CodecParams* pxSipCod,
					 IN x_IFX_CMGR_CodecParams* pxLocCod
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 i = 0;
	int32 iDtmfPos = -1;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	
	if(!pxLocCod || !pxLocCod->unNoOfCodecs)
	{
		return IFX_FAILURE;
	}
	
	memset(pxSipCod,0,sizeof(x_IFX_CMGR_CodecParams));

	/*Fix: 18-07-08 Answer with MPC Voice codec and add 2833 in the end if supported. */
	/*memcpy(pxSipCod,pxLocCod,sizeof(x_IFX_CMGR_CodecParams));*/

	memcpy(&pxSipCod->axCodec[pxSipCod->unNoOfCodecs++],&pxLocCod->axCodec[i++],
	       sizeof(x_IFX_Codec));
							
	/*Search For DTMF*/
    if(IFX_TRUE==IFX_CMGR_SearchForCodec(pxLocCod,IFX_DIGIT_2833,&iDtmfPos))
	{
	  if(iDtmfPos > 0)
	  {
		if (pxSipCod->unNoOfCodecs > IFX_MAX_CODECS - 1)
			return IFX_FAILURE;
	    /*Add DTMF codec*/
		memcpy(&pxSipCod->axCodec[pxSipCod->unNoOfCodecs++],
					&pxLocCod->axCodec[iDtmfPos],sizeof(x_IFX_Codec));
	 }
    }	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   :	IFX_CMGR_MakeSdpForOutVoipCall 
 *  Description     : This function makes the SDP for an out-going Voip call
 *  Input Values    : pxVoipLeg  - Pointer to Voip leg Information in the CL
 *  						 pxIntLeg - Poimter to non-voip leg in the CL
 *  						 pxDectParams - Codecs for DECT Leg
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_MakeSdpForOutVoipCall(
					 IN x_IFX_CMGR_CallLeg* pxVoipLeg,
					 IN x_IFX_CMGR_CallLeg* pxIntLeg,
					 IN x_IFX_CMGR_CodecParams *pxDectCodecs
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
				&pxVoipLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	pxLegInfo->eNegStatus = IFX_CMGR_OFFER_SENT; /*set offer sent*/
	IFX_CMGR_MakeDtmfSdp(pxLegInfo, &pxLegInfo->xOfferedCodecInfo);			
	return eRet;
}
	
/*****************************************************************************
 *  Function Name   :	IFX_CMGR_MakeSdpForIncVoipCall 
 *  Description     : This function makes the SDP for an incoming Voip call
                        
 *  Input Values    : pxVoipLeg  - Pointer to Voip leg Information in the CL
 *  						 pxIntLeg - Pointer to non-voip leg in the CL
 *  						 pxRemCodecs - Codecs Received
 *  						 pxRemRtp - Rtp Received
 *  						 pxRemFax - Fax params array Received
 *  						 ucFaxArrLen - Fax Array Length
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_MakeSdpForIncVoipCall(
					 IN x_IFX_CMGR_CallLeg* pxVoipLeg,
					 IN x_IFX_CMGR_CallLeg* pxIntLeg,
					 IN x_IFX_CMGR_CodecParams *pxRemCodecs,
					 IN x_IFX_CMGR_RtpParams *pxRemRtp
#ifdef FAX_SUPPORT
					 ,IN x_IFX_CMGR_FaxParams* pxRemFax,
					 IN uint8 ucFaxArrLen
#endif
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
				&pxVoipLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	e_IFX_Mode eAnsMode = 
			  IFX_CMGR_GetAnsSdpMode(IFX_SENDRECV,pxRemRtp->eSdpMode);

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Add the DTMF Digit Codec at the bottom of the list*/
	IFX_CMGR_MakeDtmfSdp(pxLegInfo, &pxLegInfo->xOfferedCodecInfo);			
	/*Check if there is any codec list in the pxParams*/
	if(pxRemCodecs->unNoOfCodecs)
	{	
		/* Compare against the Local codecs to find an intersection*/
		if(IFX_CMGR_FindCommonCodecs(&pxLegInfo->xOfferedCodecInfo,
													pxRemCodecs, &pxLegInfo->xNegCodecInfo)
						==IFX_FAILURE) /*DEBUG - return the function with failure*/
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
		/*Save any RTP Info coming with the Offer into xNegRtpParams*/
		pxLegInfo->xNegRtpParams.eSdpMode = eAnsMode; /*set correct mode*/
		strcpy((char8 *)pxLegInfo->xNegRtpParams.szRemoteRtpIpAddr,
									 								(char8 *)pxRemRtp->szRemoteRtpIpAddr);
		strcpy((char8 *)pxLegInfo->xNegRtpParams.szRemoteRtcpIpAddr,
									 								(char8 *) pxRemRtp->szRemoteRtcpIpAddr);
		pxLegInfo->xNegRtpParams.uiRemoteRtpPort =  pxRemRtp->uiRemoteRtpPort;
		pxLegInfo->xNegRtpParams.uiRemoteRtcpPort =  pxRemRtp->uiRemoteRtcpPort;

		pxLegInfo->eNegStatus = IFX_CMGR_OFFER_RXD; /*set offer received*/
#ifdef FAX_SUPPORT
		eRet  = IFX_CMGR_HandleFaxMediaNeg(pxVoipLeg,&pxLegInfo->xNegCodecInfo,
																							pxLegInfo->axFaxParams,pxRemFax);
#endif
	}
	else
	{ /* means that empty SDP was received*/ 
		pxLegInfo->eNegStatus = IFX_CMGR_OFFER_SENT; /*set offer sent*/
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_DoesMediaMatch
 *  Description     : This function Checks the SDP for an incoming Voip call
 *  
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
boolean IFX_CMGR_DoesMediaMatch(IN_OUT x_IFX_CMGR_CodecParams* pxLocalCodecs,
																IN x_IFX_CMGR_CodecParams* pxRemCodecs)
{
	boolean bRet = IFX_TRUE;
	x_IFX_CMGR_CodecParams xCommonCodecs;
	if(!pxLocalCodecs->unNoOfCodecs)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Codecs");
		bRet = IFX_FALSE;
		return bRet;
	}
	if(!pxRemCodecs->unNoOfCodecs)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Empty SDP");
		memset(pxLocalCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
		return bRet;
	}
	memset(&xCommonCodecs,0,sizeof(x_IFX_CMGR_CodecParams));	
	IFX_CMGR_FindCommonCodecs(pxLocalCodecs, pxRemCodecs, &xCommonCodecs);
	memset(pxLocalCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
	if(!xCommonCodecs.unNoOfCodecs)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Mismatch");
		bRet = IFX_FALSE;
	}
	else
	{
		/* Copy the negotiated codecs in the Local codec list*/
		memcpy(pxLocalCodecs, &xCommonCodecs, sizeof(x_IFX_CMGR_CodecParams));
	}
	return bRet;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_GetCallLegPtrIdx 
 *  Description     : This function gets the pxLeg index from the Cnxt
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : Index of the CL
 *  Notes           :
 ****************************************************************************/
STATIC uint16 IFX_CMGR_GetCallLegPtrIdx
					(
					 IN x_IFX_CMGR_CallContext* pxCnxt,
					 IN x_IFX_CMGR_CallLeg* pxLeg
					 )
{
	uint8 i=0;
	for(i=0;i < IFX_CMGR_MAX_LEGS_PER_CNXT;i++)
	{
		if((pxCnxt->pxCallLegs[i]) == pxLeg)
			break;				  
	}
	return i;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindSameOwnerLeg 
 *  Description     : This function finds the CL whose owner is szEndptId in
 *  						 the context pxCnxt. The ppxLeg ptr points to the correct
 *  						 CL if case is successful.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    :
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_FindSameOwnerLeg
					(
					 IN x_IFX_CMGR_CallContext* pxCnxt,
					 IN char8* szEndptId,
					 OUT x_IFX_CMGR_CallLeg** ppxLeg
					 )
{
	uint8 i=0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	*ppxLeg = NULL;
	for(i=0;i<IFX_CMGR_MAX_LEGS_PER_CNXT;i++)
	{
		if(pxCnxt->pxCallLegs[i])
		{
			if(!strcasecmp(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,szEndptId))
			{
				*ppxLeg = pxCnxt->pxCallLegs[i];
				break;
			}
		}
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}

/*****************************************************************************
 *  Function Name   :IFX_CMGR_ShiftCallLegPtr 
 *  Description     : Makes the pointer in pxCnxt pointing to pxFrom point to
 *  						 pxTo
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_ShiftCallLegPtr(IN x_IFX_CMGR_CallContext* pxCnxt,
					 	IN x_IFX_CMGR_CallLeg* pxFrom,
						IN x_IFX_CMGR_CallLeg* pxTo)
{
	uint8 i=0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	for(i=0;i<IFX_CMGR_MAX_LEGS_PER_CNXT;i++)
	{
		if((pxCnxt->pxCallLegs[i]) == pxFrom)
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Call Leg Shifted");
			pxCnxt->pxCallLegs[i] = pxTo;
			break;
		}
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Exit");
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_NullCallLegPtr
 *  Description     : Nullifies the pointer to CL passed. The pointer is 
 *  						 present in pxCnxt.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_NullCallLegPtr
					(
					 IN x_IFX_CMGR_CallContext* pxCnxt,
					 IN x_IFX_CMGR_CallLeg* pxLeg
					 )
{
	uint16 Idx = IFX_CMGR_GetCallLegPtrIdx(pxCnxt,pxLeg);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(IFX_CMGR_MAX_LEGS_PER_CNXT > Idx)
	{
		pxCnxt->pxCallLegs[Idx] = NULL;
	}
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsAnyInClRinging 
 *  Description     : Finds if any CL is in ringing state in a forking 
 *  						 scenario. 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsAnyInClRinging
							(
							 IN x_IFX_CMGR_CallContext* pxCnxt
					 		)
{
	boolean bRet = IFX_TRUE;
	uint8 i=0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	for(i=1;i<IFX_CMGR_MAX_LEGS_PER_CNXT;i++)	
	{
		if(pxCnxt->pxCallLegs[i])
		{
			if(IFX_CMGR_STATE_RINGING == pxCnxt->pxCallLegs[i]->eCurrState)
			{
				bRet = IFX_TRUE;	
				break;
			}
		}
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsAnyInClActive 
 *  Description     : Finds if any CL is in active state in a forking 
 *  						 scenario. 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsAnyInClAlive
							(
							 IN x_IFX_CMGR_CallContext* pxCnxt,
							 IN x_IFX_CMGR_CallLeg *pxCurrLeg
					 		)
{
	boolean bRet = IFX_FALSE;
	uint8 i=0;
		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	for(i=1;i<IFX_CMGR_MAX_LEGS_PER_CNXT;i++)	
	{
		if(pxCnxt->pxCallLegs[i])
		{
			if(pxCurrLeg != (pxCnxt->pxCallLegs[i]))
			{
				if(IFX_CMGR_STATE_IDLE != pxCnxt->pxCallLegs[i]->eCurrState)
				{
					bRet = IFX_TRUE;	
					break;
				}
			}
		}
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CheckAndEnableConf 
 *  Description     : Finds if all the CL needed for the Conference to being
 *  						 in CONV state? IF yes, then it calls the MixingEnable
 *  						 API of the MMGR.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_CheckAndEnableConf(x_IFX_CMGR_ReqContext* pxReqCnxt)
{
	boolean bRet = IFX_FALSE;
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt;
	uint8 i=0;
	int32 aiResId[IFX_MAX_CONF_PARTIES] ;
	uint32 uiCallId = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");
	/*Check if the active count is equal to actual number of calls*/
	if(pxReqCnxt->uxReqCnxt.xConfInfo.ucNumCalls == 
			pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls)
	{
		for(i=0;i<pxReqCnxt->uxReqCnxt.xConfInfo.ucNumCalls;i++)
		{
			uiCallId = pxReqCnxt->uxReqCnxt.xConfInfo.auiCallsInConf[i];
			pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
			if(pxCnxt)
				aiResId[i] = pxCnxt->iResId;
			else
			{
				return IFX_FALSE;
			}

		}
		/* Call Enabled Mixing */
		eRet = IFX_MMGR_MixingEnable(pxReqCnxt->pxReqLegs[0]->szEndptId,
							 &pxReqCnxt->uxReqCnxt.xConfInfo.iConfId,
							 pxReqCnxt->uxReqCnxt.xConfInfo.ucNumCalls,
							 aiResId);
		if(IFX_SUCCESS == eRet)
		{	
			bRet = IFX_TRUE;
			pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled = IFX_TRUE;
		}
		else
			bRet = IFX_FALSE;
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"EXIT");
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_DisableMixing 
 *  Description     : Function calls the DisableMixing API of the MMGR.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_DisableMixing(x_IFX_CMGR_ReqContext* pxReqCnxt)
{
	x_IFX_CMGR_CallContext* pxCnxt;
	e_IFX_Return eRet = IFX_SUCCESS;
	uint8 i=0;
	int32 aiResId[IFX_MAX_CONF_PARTIES] ;
	uint32 uiCallId = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	for(i=0;i<pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls;i++)
	{
		uiCallId = pxReqCnxt->uxReqCnxt.xConfInfo.auiCallsInConf[i];
		pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
		if(pxCnxt)
			aiResId[i] = pxCnxt->iResId;
		else
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Invalid Call ID!!");

	}
	/* Call Mixing Disable*/
	eRet = IFX_MMGR_MixingDisable(
						pxReqCnxt->uxReqCnxt.xConfInfo.iConfId,
						pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls,
						aiResId);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CheckAndDisableConf 
 *  Description     : Finds if all the CL needed for the Conference to being
 *  						 in HELD state? IF yes, then it calls the DisableMixing
 *  						 API of the MMGR.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_CheckAndDisableConf(
					 x_IFX_CMGR_ReqContext* pxReqCnxt)
{
	boolean bRet = IFX_FALSE;
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*If there are no active calls & no call was active intially - disable*/
	if(-1 == pxReqCnxt->uxReqCnxt.xConfInfo.cActiveCallIndex)
	{
		if(!pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls)
		{
			/* Call DISABLE Mixing  - DEBUG */
			eRet = IFX_CMGR_DisableMixing(pxReqCnxt);
			if(IFX_SUCCESS == eRet)
			{
				pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled = IFX_FALSE;
				bRet = IFX_TRUE;
			}
		}
	}
	else
	{
		if(1 == pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls)
		{
			pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled = IFX_FALSE;
			bRet = IFX_TRUE;
			/* Call DISABLE Mixing  - DEBUG */
			eRet = IFX_CMGR_DisableMixing(pxReqCnxt);
			if(IFX_SUCCESS == eRet)
			{
				pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled = IFX_FALSE;
				bRet = IFX_TRUE;
			}
		}
	}
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ClearCallLegsConfInfo 
 *  Description     : Clears the Conference infomration maintained in CLs
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_ClearCallLegsConfInfo(x_IFX_CMGR_ReqContext* pxCnxt)
{
	uint8 i=0;
	x_IFX_CMGR_CallLeg* pxLeg;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	for(i=0; i < pxCnxt->uxReqCnxt.xConfInfo.ucNumCalls;i++)
	{
		pxLeg = IFX_CMGR_GetCallLegPtr(pxCnxt->uxReqCnxt.xConfInfo.auiCallsInConf[i]);
		if(pxLeg)
			pxLeg->uiConfReqId = 0;
		else
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Invalid Call id");

	}
	
	if(IFX_TRUE == pxCnxt->uxReqCnxt.xConfInfo.bConfEnabled)
	{
		/* TO DO - Maybe invoke Conf Status??*/
	}
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeReplaceCallId 
 *  Description     : Invokes CB pfnCallIdRep
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeReplaceCallId(
					 	IN x_IFX_CMGR_CallLeg* pxLeg,
					 	IN uint32 uiOldId,
						IN uint32 uiNewId)
{
			  
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	eRet = pxLeg->pxCallBackList->pfnCallIdRep(
							 uiOldId,uiNewId,&pxLeg->pvPrivateData); 
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeStartRtpSession 
 *  Description     : Invokes CB pfnRtpSessionStart 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeStartRtpSession
									(	
									 	IN x_IFX_CMGR_CallLeg* pxLeg,
										IN x_IFX_CMGR_RtpParams* pxRtp,
										IN x_IFX_MMGR_SessionInfo* pxSession
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_RtpAgentInfo xRtpInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Find if the Leg is a Voip Leg*/
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		/*Prepare RTP agent Info*/
		memset(&xRtpInfo,0,sizeof(x_IFX_CMGR_RtpAgentInfo));
		memcpy(&xRtpInfo.xRtpParams, pxRtp, sizeof(x_IFX_CMGR_RtpParams));
		xRtpInfo.uiSsrcNumber = pxSession->uiSSRC;
		xRtpInfo.uiSequenceNumber = pxSession->unSeqNo;
		strcpy(xRtpInfo.szCoderDeviceName, pxSession->szDevChannelName);		
		xRtpInfo.uiCallId = pxLeg->uiCallId;
		
		if(!IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,IFX_CMGR_FLAG_RTP_MEDIA_SESSION_ON))
		{
			/*find the pointer to the RTP Agent CB struct and invoke RtpSessionStart*/
			pxLeg->pxRtpCB->pfnRtpSessionStart(&xRtpInfo);
			/* Set flag to indicate that session is in progress*/	
			IFX_CMGR_SET_FLAG(pxLeg->pxCurrCnxt->unFlags,IFX_CMGR_FLAG_RTP_MEDIA_SESSION_ON);
		}
		else
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ERROR!!!");
	}
	else
	{
		eRet = IFX_FAILURE; /* else - return API with FAILURE*/
	}	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_StopMediaSession 
 *  Description     : Invokes CB pfnRtpSessionStop or the pfnFaxSessionStop
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_StopMediaSession
								(IN x_IFX_CMGR_CallLeg* pxLeg)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Find if the Leg is a Voip Leg*/
	if(pxLeg->xLegOwnerInfo.eOwnerType == IFX_CMGR_TYPE_VOIP)
	{
		/*find the pointer to the RTP Agent CB struct and invoke RtpSessionStop*/
		if(IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
														IFX_CMGR_FLAG_RTP_MEDIA_SESSION_ON))
		{
			/*Prepare RTP agent Info*/
			x_IFX_CMGR_RtpAgentInfo xRtpInfo;
			memset(&xRtpInfo,0,sizeof(x_IFX_CMGR_RtpAgentInfo));
			xRtpInfo.uiCallId = pxLeg->uiCallId;
			pxLeg->pxRtpCB->pfnRtpSessionStop(&xRtpInfo);
			IFX_CMGR_RESET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
											IFX_CMGR_FLAG_RTP_MEDIA_SESSION_ON);
#ifdef UDP_REDIRECT
			IFX_MMGR_QosStop(pxLeg->pxCurrCnxt->iResId,xRtpInfo.xRtpParams.uiLocalRtpPort);
#endif
		}
#ifdef FAX_SUPPORT
		else
		if(IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
														IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
		{
			x_IFX_CMGR_FaxAgentInfo xFaxInfo;
			/*Prepare FAX agent Info*/
			memset(&xFaxInfo,0,sizeof(x_IFX_CMGR_FaxAgentInfo));
			xFaxInfo.uiCallId = pxLeg->uiCallId;
			/* Check if the FAX call was disconnected due to an FXS on-hook?*/
			if(IFX_CMGR_GET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
																					IFX_CMGR_FLAG_FAX_FXS_ON_HK))
			{
				xFaxInfo.bFaxOnHk = IFX_TRUE;
				IFX_CMGR_RESET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
																					IFX_CMGR_FLAG_FAX_FXS_ON_HK);
			}
			/*Stop FAX session*/
			pxLeg->pxFaxCB->pfnFaxSessionStop(&xFaxInfo);
			/* Reset flag to indicate that Fax Session has been stopped*/
			IFX_CMGR_RESET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
											IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON);
			/*Reset flag to indicate that listening on FAX TCP port has stopped*/
			IFX_CMGR_RESET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
											IFX_CMGR_FLAG_WAITING_FOR_TCP_FAX);
		}
#endif
		else
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,\
																								"Already Stopped Media!");
		}
	}
	else
	{
		eRet = IFX_FAILURE; /* else - return API with FAILURE*/
	}	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeModifyRtpSession 
 *  Description     : Invokes CB pfnRtpSessionModify
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeModifyRtpSession
									(	
									 	IN x_IFX_CMGR_CallLeg* pxLeg,
										IN x_IFX_CMGR_RtpParams* pxRtp
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_RtpAgentInfo xRtpInfo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Find if the Leg is a Voip Leg*/
	if(pxLeg->xLegOwnerInfo.eOwnerType == IFX_CMGR_TYPE_VOIP)
	{
		/*Prepare RTP agent Info*/
		memset(&xRtpInfo,0,sizeof(x_IFX_CMGR_RtpAgentInfo));
		memcpy(&xRtpInfo.xRtpParams, pxRtp, sizeof(x_IFX_CMGR_RtpParams));
		xRtpInfo.uiCallId = pxLeg->uiCallId;
		/*Invoke Call back*/	
		pxLeg->pxRtpCB->pfnRtpSessionModify(&xRtpInfo);
	}
	else
	{
		eRet = IFX_FAILURE; /* else - return API with FAILURE*/
	}	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeRemoteCallRelease
 *  Description     : Invokes CB pfnRemoteCallRelease
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_InvokeRemoteCallRelease
										(IN x_IFX_CMGR_CallLeg* pxLeg,
										 IN e_IFX_ReasonCode eReason,
										 IN x_IFX_CMGR_VoipAddr* pxFwdAddr
										 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	if(!pxLeg || !pxLeg->pxCallBackList || 
							!pxLeg->pxCallBackList->pfnRemoteCallRelease)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	if((IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
		&& (IFX_TRUE == IFX_CMGR_IsCallConn(pxLeg)))
		eReason = IFX_TERMINATED;
		
	eRet = pxLeg->pxCallBackList->pfnRemoteCallRelease
		(pxLeg->uiCallId, eReason, pxFwdAddr, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeConfStatus 
 *  Description     : Invokes CB pfnConfStatus
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeConfStatus
									(	
									 	IN x_IFX_CMGR_CallLeg* pxLeg,
										IN e_IFX_CMGR_Status eStatus,
										IN e_IFX_ReasonCode eReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg *pxReqLeg = IFX_CMGR_GetReqLegPtr(pxLeg->uiConfReqId);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxReqLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Invalid Req Id");
		eRet = IFX_FAILURE; 
	}
	else
	{
		if(pxLeg->pxCallBackList->pfnConfStatus)
			eRet = pxLeg->pxCallBackList->pfnConfStatus(pxLeg->uiConfReqId, 
							 				eStatus, eReason, pxReqLeg->pvPrivateData);
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_APP_SearchCallFwdList
 *  Description     : This API enables the caller to search given number 
 *  						 in fwd list                        
 *  Return Values    : SUCCESS if found,FAIL if not found
 *                   
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_SearchCallFwdList
													(IN x_IFX_CMGR_VoipAddr *pxFwdList,
					 								IN uint8 ucCount,
					 								IN x_IFX_CMGR_VoipAddr *pxAddr)
{
	int32 iCnt=0;
	e_IFX_Return eRet=IFX_FAILURE;
	if(!pxFwdList || !pxAddr)
		return IFX_FAILURE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	for(iCnt=0;iCnt<ucCount;iCnt++)
	{
		/*Check for matching address and return success if match*/      	  	
		if(!strcasecmp(pxFwdList[iCnt].acUserName,pxAddr->acUserName))
  			if(!strcasecmp(pxFwdList[iCnt].acCalledAddr,pxAddr->acCalledAddr))
			{
				eRet = IFX_SUCCESS;
				break;
			}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
   return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_APP_CanCallBeFwd
 *  Description     : This function checks if a call forward is possible or not           
 *  Return Values    : IFX_TRUE or IFX_FALSE
 *                   
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_CanCallBeFwd(
					 			IN x_IFX_CMGR_VoipLegInfo *pxLegInfo,
					 			IN x_IFX_CMGR_VoipAddr *pxAddr)
{	
	boolean bRet = IFX_FALSE;
	if(IFX_FAILURE == IFX_CMGR_SearchCallFwdList(pxLegInfo->axCallFwdList, 
									pxLegInfo->ucCallFwdCount, pxAddr))
		bRet = IFX_TRUE;
	return bRet;
}


/*****************************************************************************
 *  Function Name   : IFX_APP_AddToCallFwdList
 *  Description     : This API enables the caller to add address to call Fwd 
 *  						 list
                        
 *  Input Values    : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *                    
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AddToCallFwdList(
					 IN x_IFX_CMGR_VoipAddr *pxFwdList,
					 IN x_IFX_CMGR_VoipAddr *pxAddr,
					 IN_OUT uint8* pucCount)
{
	e_IFX_Return eRet=IFX_FAILURE;
	
	if(!pxFwdList || !pxAddr)
		return IFX_FAILURE;

	if(*pucCount<IFX_MAX_CALL_FWD_LIST)
	{		  
		memcpy(&pxFwdList[(*pucCount)],pxAddr,sizeof(x_IFX_CMGR_VoipAddr));
		++(*pucCount);
		eRet = IFX_SUCCESS;
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_PrepareLegOwnerInfoForTx 
 *  Description     : Prepares Child Leg's information for BTX
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepareLegOwnerInfoForTx
						(
							IN x_IFX_CMGR_LegOwnerInfo* pxOld,
					 		IN x_IFX_CMGR_AddressInfo* pxTarget,
							OUT x_IFX_CMGR_LegOwnerInfo* pxNew
						)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_CallType eTarget = pxTarget->eAddressType;
	e_IFX_CMGR_CallType eNew = pxNew->eOwnerType;
	char8 szFxoLineId [IFX_MAX_ENDPOINTID_LEN];
	char8* pszEid = pxOld->szEndptId;
	e_IFX_ReasonCode eReason = 0;
	uchar8 ucVoipLineId = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	switch(eTarget)
	{
		case IFX_CMGR_TYPE_EXTN:
		{
			eNew = IFX_CMGR_TYPE_EXTN;
			pxNew->eOwnerType = eNew;
			/* Copy Endpt Id from the Target to New*/
			strcpy(pxNew->szEndptId, 
					pxTarget->uxAddressInfo.szEndptId);
			/* Find if the Endpt have any codecs*/
			IFX_LMGR_GetCodecsForEndpt(pxNew->szEndptId,
				&pxNew->uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo,
				&eReason);
		}
		break;
			
		case IFX_CMGR_TYPE_FXO:
		{
			eNew = IFX_CMGR_TYPE_FXO;
			memset(szFxoLineId, 0, IFX_MAX_ENDPOINTID_LEN);
			pxNew->eOwnerType = eNew;
			/* Invoke LMGR to find the default FXO line for the endpt in old*/
			IFX_LMGR_GetFxoLineForEndpt(pszEid,szFxoLineId,&eReason);
			/* Copy the same in the New Leg owner info*/
			strcpy(pxNew->szEndptId, szFxoLineId);
			strcpy(pxNew->uxLegOwnerInfo.xFxoLegInfo.szFxoLineId, szFxoLineId);
			strcpy(pxNew->uxLegOwnerInfo.xFxoLegInfo.szPhoneNumber, 
									pxTarget->uxAddressInfo.xFxoInfo.szPhoneNumber);
		}
		break;

		case IFX_CMGR_TYPE_VOIP:
		{
			boolean bIsReg;
			strcpy(pxNew->szEndptId, IFX_NA_ENDPT_ID);
			x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = /*Voip Leg owner Info*/
																&pxNew->uxLegOwnerInfo.xVoipLegInfo;		  
			/* Invoke LMGR to find the default Voip line for the endpt*/
			IFX_LMGR_GetEndptDefaultVoipLine(pszEid,&ucVoipLineId,&bIsReg,&eReason);
			if((IFX_FAILURE == eRet) || !ucVoipLineId)
			{
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				return IFX_FAILURE;
			}
			/* Get all the information needed for an OUT going Voip Call*/
			eRet = IFX_LMGR_GetInfoForVoipCall(ucVoipLineId, 
								 pxVoipLegInfo, &eReason);	
			if(IFX_FAILURE == eRet)
			{
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				return IFX_FAILURE;
			}
			pxNew->eOwnerType = IFX_CMGR_TYPE_VOIP;

			/* Add the DTMF Digit Codec at the bottom of the list*/
			IFX_CMGR_MakeDtmfSdp(pxVoipLegInfo, &pxVoipLegInfo->xOfferedCodecInfo);			
			
			/*Save the remote Voip address in the Leg info*/
			memcpy( &pxVoipLegInfo->xRemAddr,&pxTarget->uxAddressInfo.xVoipAddr,
				sizeof(x_IFX_CMGR_VoipAddr));
	
			/* Apply offer answer Logic for the Out going call*/
			pxVoipLegInfo->eNegStatus = IFX_CMGR_OFFER_SENT; /*set offer sent*/
		}
		break;
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_PrepareChildLegForTx 
 *  Description     : Prepares Child Leg's information for BTX
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepareChildLegForTx
									(
								 		IN x_IFX_CMGR_CallLeg*  pxParent,
								 		IN x_IFX_CMGR_CallLeg*  pxChild,
					 					IN x_IFX_CMGR_AddressInfo* pxTarget
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(!pxParent || !pxTarget || !pxChild)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE; /* DEBUG */
	}

	/*Prepare the Leg Owner Info for the Child CL*/
	if(IFX_CMGR_TYPE_VOIP != pxParent->xLegOwnerInfo.eOwnerType)	
	{
		/* Its a transfer initiated by an internal party*/
		if(IFX_CMGR_PrepareLegOwnerInfoForTx(&pxParent->xLegOwnerInfo, 
										pxTarget, &pxChild->xLegOwnerInfo) == IFX_FAILURE)
		{
			IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
			return IFX_FAILURE; /* DEBUG */
		}
	}
	else
	{	/* If its Voip initiated Tx*/
		if(IFX_CMGR_PrepareLegOwnerInfoForTx(&pxParent->pxPeer->xLegOwnerInfo, 
										pxTarget, &pxChild->xLegOwnerInfo) == IFX_FAILURE)
		{
			IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
			return IFX_FAILURE; /* DEBUG */
		}
	}
		
	/* Make Pointers to CB structs*/
	if(IFX_FAILURE == IFX_CMGR_GetCBList(pxChild->xLegOwnerInfo.szEndptId,
												&pxChild->pxCallBackList))
	{
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE; /*Major Error - DEBUG*/
	}

	if(IFX_CMGR_TYPE_VOIP == pxChild->xLegOwnerInfo.eOwnerType)
	{
		/*Generate RTP/FAX CBs*/
		if((eRet = IFX_CMGR_SetMediaCallbacks(pxChild)) == IFX_FAILURE)
		{
			/*Major Error - DEBUG*/
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
	}
	/*Set context to the current one*/
	pxChild->pxCurrCnxt = pxParent->pxCurrCnxt;

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_SetExtnLegInfo 
 *  Description     : Function populates the information for the Extn Leg using
 *  						the Endpoint id and the Call Params - Mainly used in case 
 *  						of DECT for codec population.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_SetExtnLegInfo(
					 								IN boolean bIncExtnCall,
													IN char8* szEndptId,
					 								OUT x_IFX_CMGR_ExtnLegInfo* pxLegInfo,
					 								IN_OUT x_IFX_CMGR_CallParams* pxPar,
								 					OUT e_IFX_ReasonCode* peReason
												)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CodecParams *pxRem = NULL;
	boolean bMatched = IFX_TRUE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxPar)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Fn invoked for an extension terminated call*/
	if(IFX_TRUE != bIncExtnCall) 
	{
		/* Invoke Function to know if the endpoint ID has any codecs associated 
		 * with it. If codecs are present, then save them in the offered codec 
		 * list.*/
		IFX_LMGR_GetCodecsForEndpt(szEndptId,
								 &pxLegInfo->xOfferedCodecInfo,peReason);
	}
	else /*Function invoked for an a Extn originated call*/
	{
		/* Check for the DECT codecs here - If they are present in pxPar then find
		 * the ones in the CFG. Put the ones in the CFG into the offered list and
		 * invoke MatchMediaParam after passing it the remote codecs. Save the 
		 * common codecs in the NegCodecList*/
		pxRem = &pxPar->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams;
		if(pxRem->unNoOfCodecs)
		{ /* Its a party which needs codec negotiation*/
			/* Get Codecs for this endpoint*/	
			IFX_LMGR_GetCodecsForEndpt(szEndptId,
								 &pxLegInfo->xOfferedCodecInfo,peReason);
			if(pxLegInfo->xOfferedCodecInfo.unNoOfCodecs)
			{
				/* codecs found - Must be a non-FXS party-Invoke MatchMediaParams*/
				bMatched = IFX_CMGR_MatchMediaParams(&pxLegInfo->xOfferedCodecInfo,
					pxRem, NULL, NULL, &pxLegInfo->xNegCodecInfo, NULL);
				if(IFX_TRUE != bMatched)
				{
					/* Should not happen - Its a BUG - DEBUG*/
					IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
					return IFX_FAILURE;
				}
			}
			else
			{	/*No codecs found */
				/* Should not happen - Its a BUG - DEBUG*/

				eRet = IFX_FAILURE;
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				return eRet;
			}
		}
		/* Doing Common Actions*/
		memcpy(&pxLegInfo->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));	
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AllocCallLegPtr 
 *  Description     : N.A.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return  IFX_CMGR_AllocCallLegPtr(
					 							IN x_IFX_CMGR_CallContext* pxCnxt,
					 								IN uchar8 ucNumCallLegs)
{
	uint8 i=0; 
	for(i = 0; i< IFX_CMGR_MAX_LEGS_PER_CNXT ;i++)
		pxCnxt->pxCallLegs[i] = NULL;
	return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_SearchStruct 
 *  Description     : Function to search for free structure in given array and 
 					  randomly pick on of the free struct
 *  Input Values    : pxSturctType - This argument can be ignored
 					  uiMax :- Max element in the array of struct
					  eType:-  Type of struct of be scanned
 *  Output Values	: piIndex : Index to randomly picked free location
 *  Return Value    : SUCCESS / FAILURE
 *  Notes           : earlier This was Macro.
 ****************************************************************************/
e_IFX_Return IFX_CMGR_SearchStruct(void *pxSturctType, 
		                           uint32 uiMax, 
								   uint16 *piIndex,
								   e_IFX_CMGR_StructType eType)
{
	uint32 j=0, aiFree[uiMax],uiTotalFree =0;
  *piIndex = 0;	
	switch(eType)
	{
	case IFX_CMGR_CALL_LEG:
			for(j=0;j<uiMax;j++)
	    {
		   if(IFX_CMGR_STRUCT_FREE == vxCmgrInfo.axCallLeg[j].eStructStatus)
		   {
		    aiFree[uiTotalFree++]=j;
		   }
      }
		  break;	
	case IFX_CMGR_CALL_CNXT:
			for(j=0;j<uiMax;j++)
	    {
		   if(IFX_CMGR_STRUCT_FREE == vxCmgrInfo.axCallCnxt[j].eStructStatus)
		   {
		    aiFree[uiTotalFree++]=j;
		   }
      }
			break;	
	case IFX_CMGR_REQ_LEG:
			for(j=0;j<uiMax;j++)
	    {
		   if(IFX_CMGR_STRUCT_FREE == vxCmgrInfo.axReqLeg[j].eStructStatus)
		   {
		    aiFree[uiTotalFree++]=j;
		   }
      }
			break;	
				
	case IFX_CMGR_REQ_CNXT:
			for(j=0;j<uiMax;j++)
	    {
		   if(IFX_CMGR_STRUCT_FREE == vxCmgrInfo.axReqCnxt[j].eStructStatus)
		   {
		    aiFree[uiTotalFree++]=j;
		   }
      }
		  break;
			
	case IFX_CMGR_ENDPT_INFO:
			for(j=0;j<uiMax;j++)
	    {
		   if(IFX_CMGR_STRUCT_FREE == vxCmgrInfo.axEndptInfo[j].eStructStatus)
		   {
		    aiFree[uiTotalFree++]=j;
		   }
      }
			break;
			
	default:
			return IFX_FAILURE;
  }  
	
	if(uiTotalFree==0)
	{
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "No free stucture found!!");
		return IFX_FAILURE;
	}
	j = (int32)((uiTotalFree-1) * (rand() / (RAND_MAX + 1.0)));
	*piIndex = aiFree[j];
	return IFX_SUCCESS;

}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AllocStruct 
 *  Description     : Function finds a free struct and allocates it for the 
 *  					    caller. The type of the struct is determined by the type 
 *  					    field. The valid types include Call Leg, Call Context, 
 *  					    Req Leg & Req Info structures.
 *  Output Values    : ppvStruct Pointer to the struct
 *  						 puiIdx Index of the structure in the global array
 *  Input Values	  : eType Type of the struct
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_AllocStruct(OUT void** ppvStruct,
					 OUT uint16* punIdx,
					 IN e_IFX_CMGR_StructType eType)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 uiMax = 0;
	if(!punIdx)
		return IFX_FAILURE;
		
	switch(eType)
	{
		case IFX_CMGR_CALL_LEG:
		{
			x_IFX_CMGR_CallLeg* pxStruct = vxCmgrInfo.axCallLeg;
			uiMax = IFX_CMGR_MAX_CALL_LEGS;
			if(IFX_CMGR_SearchStruct(pxStruct,uiMax,punIdx,IFX_CMGR_CALL_LEG)
					== IFX_FAILURE)
			{
				return IFX_FAILURE;
			}
			*((x_IFX_CMGR_CallLeg**)ppvStruct)= pxStruct + (*punIdx);
		}
		break;	
		case IFX_CMGR_CALL_CNXT:
		{
			x_IFX_CMGR_CallContext* pxStruct = vxCmgrInfo.axCallCnxt;
			uiMax = IFX_CMGR_MAX_CALL_CNXT;
			if(IFX_CMGR_SearchStruct(pxStruct,uiMax,punIdx,IFX_CMGR_CALL_CNXT)
				 == IFX_FAILURE)
			{
				return IFX_FAILURE;
			}
			*((x_IFX_CMGR_CallContext**)ppvStruct)=pxStruct + (*punIdx);
		}
		break;	
		case IFX_CMGR_REQ_LEG:
		{
			x_IFX_CMGR_ReqLeg* pxStruct = vxCmgrInfo.axReqLeg;
			uiMax = IFX_CMGR_MAX_REQ_LEGS;
			if(IFX_CMGR_SearchStruct(pxStruct,uiMax,punIdx,IFX_CMGR_REQ_LEG)
					== IFX_FAILURE)
			{
				return IFX_FAILURE;
			}
			*((x_IFX_CMGR_ReqLeg**)ppvStruct)=pxStruct + (*punIdx);
		}
		break;	
		case IFX_CMGR_REQ_CNXT:
		{
			x_IFX_CMGR_ReqContext* pxStruct = vxCmgrInfo.axReqCnxt;
			uiMax = IFX_CMGR_MAX_REQ_CNXT;
			if(IFX_CMGR_SearchStruct(pxStruct,uiMax,punIdx,IFX_CMGR_REQ_CNXT)
				 ==IFX_FAILURE)
			{
				return IFX_FAILURE;
			}
			*((x_IFX_CMGR_ReqContext**)ppvStruct)=pxStruct + (*punIdx);
		}
		break;
		case IFX_CMGR_ENDPT_INFO:
		{
			x_IFX_CMGR_EndptInfo* pxStruct = vxCmgrInfo.axEndptInfo;
			uiMax = IFX_CMGR_MAX_AGENTS;
			if(IFX_CMGR_SearchStruct(pxStruct,uiMax,punIdx,IFX_CMGR_ENDPT_INFO)
					==IFX_FAILURE)
			{
				return IFX_FAILURE;
			}
			*((x_IFX_CMGR_EndptInfo**)ppvStruct)=pxStruct + (*punIdx);
		}
		break;
		default:
			eRet=IFX_FAILURE;
		break;	
	}
	return eRet;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsCallAllowed
 *  Description     : Function if finds a call on the VL exists based on line mode multi/single.
 *  Output Values    :
 *
 *  Input Values    :
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
boolean IFX_CMGR_IsCallAllowed(IN uint8 ucLineId,
																IN char8 *szEndPtId)
{
  x_IFX_CMGR_CallLeg* pxLeg = vxCmgrInfo.axCallLeg;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
  boolean bRet = IFX_TRUE;
  uint8 i=0;
  x_IFX_CMGR_VoipLegInfo *pxLegInfo = NULL;

  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  if(!ucLineId)
    return IFX_FALSE;
  if(szEndPtId[0]!='\0'){
	  if( IFX_TRUE == IFX_CIF_IsLineTypeMulti(ucLineId)){
		  return IFX_TRUE;
	  }
  }

  for(i=0;i<IFX_CMGR_MAX_CALL_LEGS;i++)
  {
    pxLegInfo = &pxLeg[i].xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
    if(IFX_CMGR_STRUCT_OCCUPIED == pxLeg[i].eStructStatus)
    {
      if(pxLegInfo->ucLineId == ucLineId)
      {
				pxPeer = IFX_CMGR_GetPeerPtr(((x_IFX_CMGR_CallLeg*)&pxLeg[i]));
				if(pxPeer!=NULL){
          if(szEndPtId[0]=='\0'){
            strcpy(szEndPtId,pxPeer->xLegOwnerInfo.szEndptId);
            return IFX_TRUE;
          }
          else{				
					  if(strcmp(szEndPtId,pxPeer->xLegOwnerInfo.szEndptId)==0){
						  continue;
						}
          }
				}
        /* Call Found - Return True*/
        bRet = IFX_FALSE;
        IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Call on Line Found");
        break;
      }
    }
  }

  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
  return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnyCallOnVL
 *  Description     : Function if finds a call on the VL exists 
 *  Output Values    : 
 *  						 
 *  Input Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
boolean IFX_CMGR_AnyCallOnVL(IN uint8 ucLineId)
{
	x_IFX_CMGR_CallLeg* pxLeg = vxCmgrInfo.axCallLeg;
	boolean bRet = IFX_FALSE;
	uint8 i=0;
	x_IFX_CMGR_VoipLegInfo *pxLegInfo = NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!ucLineId)
		return bRet;
	
	for(i=0;i<IFX_CMGR_MAX_CALL_LEGS;i++)
	{
		pxLegInfo = &pxLeg[i].xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
		if(IFX_CMGR_STRUCT_OCCUPIED == pxLeg[i].eStructStatus)
		{
			if(pxLegInfo->ucLineId == ucLineId)	
			{
				/* Call Found - Return True*/
				bRet = IFX_TRUE;
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Call on Line Found");
				break;
			}
		}
	}

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ChangeState 
 *  Description     : Function used to change the state of the Call Leg
 *  Output Values    : 
 *  						 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ChangeState(IN x_IFX_CMGR_CallLeg* pxLeg,
					 						 IN e_IFX_CMGR_CallState eNewState,
											 IN e_IFX_CMGR_RespPendEvent ePendingFor)
{
	e_IFX_Return eRet=IFX_SUCCESS;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(eNewState == pxLeg->eCurrState)
			  return eRet;
	
	if((IFX_CMGR_SEND_RESP_PENDING!=pxLeg->eCurrState)&& 
		(IFX_CMGR_RECV_RESP_PENDING!=pxLeg->eCurrState))
	{
		/*Change the previous state to the current state*/
		pxLeg->ePrevState = pxLeg->eCurrState;	
	}
	else
	{
		/*Change the Rsp Pending  Event to 0*/
		pxLeg->eRespPendEvt = 0;
	}
	/*Save the NewState in the Current State*/	
	pxLeg->eCurrState = eNewState;
	/*Change the pending for value*/
	pxLeg->eRespPendEvt = ePendingFor;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "STATE CHANGED TO", eNewState);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name : IFX_CMGR_GetEidFromAddrInfo 
 *  Description 	: This Function finds the Endpoint Id from the address 
 *  					  Info structure
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetEidFromAddrInfo
									( IN x_IFX_CMGR_AddressInfo* pxAddr,
					 				  OUT char8* szEndptId
									)
{
	e_IFX_Return eRet=IFX_SUCCESS;
	//e_IFX_ReasonCode eReason;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxAddr)
	{
		goto err;
	}
	
	switch(pxAddr->eAddressType)
	{
		case IFX_CMGR_TYPE_VOIP:
			strcpy(szEndptId, IFX_NA_ENDPT_ID );		
		break;
		
		case IFX_CMGR_TYPE_FXO:
			/* If the EID in pxAddr is NULL*/
			if(strcasecmp(pxAddr->uxAddressInfo.xFxoInfo.szFxoLineId,""))
				strcpy(szEndptId,pxAddr->uxAddressInfo.xFxoInfo.szFxoLineId);	
			else
				goto err;
		break;

		case IFX_CMGR_TYPE_EXTN:
			//eReason=0;
			if(strcasecmp(pxAddr->uxAddressInfo.szEndptId,""))
				strcpy(szEndptId,pxAddr->uxAddressInfo.szEndptId);
			else
				goto err;
		break;
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;

err:
	eRet=IFX_FAILURE;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	memset(szEndptId,0, IFX_MAX_ENDPOINTID_LEN);
	return eRet;
}

/*****************************************************************************
 *  Function Name : IFX_CMGR_GetCBList 
 *  Description 	: The function searches through the EID list for the endpoint 
 *  					  ID and returns the pointer to the CB structure
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_GetCBList(IN char8* szEndptId,
					 									OUT x_IFX_CMGR_CallBackList** ppxCB)
{
	e_IFX_Return eRet=IFX_FAILURE;
	x_IFX_CMGR_EndptInfo* pxEndptInfo= vxCmgrInfo.axEndptInfo;
	int32 i=0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!szEndptId || !ppxCB || !strlen(szEndptId))
	{
		eRet=IFX_FAILURE;
		goto err;
	}
	
	*ppxCB = NULL;
	
	for(i=0;i<IFX_CMGR_MAX_AGENTS;i++)
	{
		if(!strcasecmp(pxEndptInfo[i].szEndptId, szEndptId))
		{
			/*Match Found*/
			(*ppxCB)=&pxEndptInfo[i].pxCallBackInfo->xCallBackList;
			eRet=IFX_SUCCESS;
			break;
		}
	}
err:
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetReqLeg 
 *  Description 	: The function searches through Request Leg array and 
 *  					 returns an empty one
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetReqLeg(	IN uint16 unCnxtIdx,
					 									OUT x_IFX_CMGR_ReqLeg** ppxLeg
														)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = NULL;
	uint16 unLegIdx = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!ppxLeg)
	{
		goto err;
	}
	/*Allocate a Call Leg*/
	if(IFX_FAILURE==
			IFX_CMGR_AllocStruct((void**)ppxLeg,&unLegIdx,IFX_CMGR_REQ_LEG))
	{
		goto err;
	}
	/*Nullify the Leg*/
	memset(*ppxLeg, 0, sizeof(x_IFX_CMGR_ReqLeg));
	/* Save value of leg in a local variable for further usage*/
	pxLeg=*ppxLeg;
	
	/* Change the status of the structure*/
	pxLeg->eStructStatus=IFX_CMGR_STRUCT_OCCUPIED;
	
	/*Set the Call Id in the Call Leg*/
	pxLeg->uiReqId = IFX_CMGR_GetReqId(unCnxtIdx,unLegIdx);
	/*Add req id to the Req ID list*/
	if(IFX_FAILURE == IFX_CMGR_AddToIdList(pxLeg->uiReqId,IFX_FALSE))
	{
		goto err;
	}
	
	return eRet;
	
err:
	eRet = IFX_FAILURE;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetCallLeg 
 *  Description 	: The function searches through Call Leg array and 
 *  					 returns an empty one
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetCallLeg(	IN uint16 unCnxtIdx,
					 									OUT x_IFX_CMGR_CallLeg** ppxLeg
														)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = NULL;
	uint16 unLegIdx = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!ppxLeg)
	{
		goto err;
	}
	/*Allocate a Call Leg*/
	if(IFX_FAILURE==
			IFX_CMGR_AllocStruct((void**)ppxLeg,&unLegIdx,IFX_CMGR_CALL_LEG))
	{
		goto err;
	}
	memset(*ppxLeg, 0, sizeof(x_IFX_CMGR_CallLeg));
	/* Save value of leg in a local variable for further usage*/
	pxLeg=*ppxLeg;
	
	/* Change the status of the structure*/
	pxLeg->eStructStatus=IFX_CMGR_STRUCT_OCCUPIED;
	
	/*Set the Call Id in the Call Leg*/
	pxLeg->uiCallId = IFX_CMGR_GetCallId(unCnxtIdx,unLegIdx);

	/*Add call id to the call ID list*/
	if(IFX_FAILURE == IFX_CMGR_AddToIdList(pxLeg->uiCallId,IFX_TRUE))
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
             "NO SPACE FOR ID ",pxLeg->uiCallId);
		goto err;
	}
	
	return eRet;
	
err:
	eRet = IFX_FAILURE;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_DeAllocReqLeg 
 *  Description 	: The function frees a request leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/
STATIC void IFX_CMGR_DeAllocReqLeg(x_IFX_CMGR_ReqLeg* pxLeg)
{
	if(!pxLeg)
			  return;
	if(pxLeg->uiReqId)
	{
		if(IFX_FAILURE == IFX_CMGR_RemoveFromIdList(pxLeg->uiReqId,IFX_FALSE))
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
      	           "Request ID not found",pxLeg->uiReqId);
		}
	}
	memset(pxLeg,0,sizeof(x_IFX_CMGR_ReqLeg));
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_DeAllocCallLeg 
 *  Description 	: The function frees a call leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    :
 *  Notes           :
 ****************************************************************************/
void IFX_CMGR_DeAllocCallLeg(x_IFX_CMGR_CallLeg* pxLeg)
{
	uint32 uiId = 0;
	uint32 i = 0;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo;
	e_IFX_TransportType eProt = IFX_TRPROTO_UDP;
	if(!pxLeg)
			  return;
	uiId = pxLeg->uiCallId;
	if(pxLeg->uiCallId)
	{
		if(IFX_FAILURE == IFX_CMGR_RemoveFromIdList(pxLeg->uiCallId,IFX_TRUE))
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
      	           "Call ID not found",pxLeg->uiCallId);
		}
		else
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
      	           "Call ID freed",uiId);
		}
	}
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		pxLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
		/*Free Media Port in case the Port is allocated*/
		if(pxLegInfo->xNegRtpParams.uiLocalRtpPort)
			IFX_LMGR_FreeMediaPort(pxLegInfo->xNegRtpParams.uiLocalRtpPort,eProt);
		if(pxLegInfo->xNegRtpParams.uiLocalRtcpPort)
			IFX_LMGR_FreeMediaPort(
							pxLegInfo->xNegRtpParams.uiLocalRtcpPort,eProt);
		if(pxLegInfo->xTempRtpParams.uiLocalRtpPort)
			IFX_LMGR_FreeMediaPort(
							pxLegInfo->xTempRtpParams.uiLocalRtpPort,eProt);
		if(pxLegInfo->xTempRtpParams.uiLocalRtcpPort)
			IFX_LMGR_FreeMediaPort(
							pxLegInfo->xTempRtpParams.uiLocalRtcpPort,eProt);
#ifdef FAX_SUPPORT
		for(i=0;i<IFX_MAX_FAX_PROTO;i++)
		{
			 eProt = pxLegInfo->axFaxParams[i].xFaxCfg.uiTransportProtocol
								==IFX_TRPROTO_TCP?IFX_TRPROTO_TCP:IFX_TRPROTO_UDP;
			if(pxLegInfo->axFaxParams[i].uiLocalFaxPort)
					IFX_LMGR_FreeMediaPort(
						pxLegInfo->axFaxParams[i].uiLocalFaxPort,eProt);
		}
#endif
	}
	memset(pxLeg,0,sizeof(x_IFX_CMGR_CallLeg));
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetBasicCallType 
 *  Description 	: The function finds the basic call type for this call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    :
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_GetBasicCallType
										(	IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					 	IN x_IFX_CMGR_AddressInfo* pxTo,
										 	OUT e_IFX_CMGR_BasicCallType* peBct
										)
{
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_CMGR_CallType eFrom = pxFrom->eAddressType;
	e_IFX_CMGR_CallType eTo= pxTo->eAddressType;
	x_IFX_CMGR_CallBackList* pxCallBackList = NULL;
	
	/* Set Initial value to NULL*/
	*peBct=0;
	
	switch(eFrom)
	{
		case IFX_CMGR_TYPE_VOIP:
			*peBct=IFX_CMGR_BCT_VOIP_INT;
			eRet=IFX_SUCCESS;
		break;
		
		case IFX_CMGR_TYPE_FXO:
			if(IFX_CMGR_GetCBList(pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId,
												&pxCallBackList) == IFX_FAILURE)
			{
				/*No such endpoint - return API with failure*/
				break;
			}

			if(IFX_CMGR_TYPE_VOIP == eTo)
				*peBct=IFX_CMGR_BCT_FXO_VOIP;
			else 
			{
				if(IFX_CMGR_TYPE_EXTN == eTo)
					*peBct=IFX_CMGR_BCT_FXO_EXTN;
				else
					eRet = IFX_FAILURE;
			}
			eRet = IFX_SUCCESS;
		break;

		case IFX_CMGR_TYPE_EXTN:
			if(IFX_CMGR_GetCBList(pxFrom->uxAddressInfo.szEndptId,
												&pxCallBackList) == IFX_FAILURE)
			{
				/*No such endpoint - return API with failure*/
				break;
			}
			if(IFX_CMGR_TYPE_VOIP == eTo)
				*peBct=IFX_CMGR_BCT_EXTN_VOIP;
			else 
			{
				if(IFX_CMGR_TYPE_FXO == eTo)
					*peBct=IFX_CMGR_BCT_EXTN_FXO;
				else
				{
					if(IFX_CMGR_TYPE_EXTN == eTo)
					{
						if(IFX_CMGR_GetCBList(pxTo->uxAddressInfo.szEndptId,
												&pxCallBackList) == IFX_FAILURE)
						{
							/*No such endpoint - return API with failure*/
							break;
						}
						*peBct=IFX_CMGR_BCT_EXTN_EXTN;
					}
					else
						eRet=IFX_FAILURE;
				}
			}		
			eRet = IFX_SUCCESS;
		break;
		default:
			eRet=IFX_FAILURE;
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetReqContext 
 *  Description 	: The function searches through Request Leg array and 
 *  					 returns an empty one
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetReqContext
								(  
								 	OUT x_IFX_CMGR_ReqContext** ppxCnxt,
									OUT uint16* punCnxtIdx
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqContext* pxCnxt=NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Sanity Check */
	if(!ppxCnxt)
		 return IFX_FAILURE;

	/* Search for an empty call context struture in the array*/
	if(IFX_FAILURE==
				IFX_CMGR_AllocStruct((void**)ppxCnxt,punCnxtIdx,IFX_CMGR_REQ_CNXT))
	{
		eRet = IFX_FAILURE;
	}
	else
	{
		memset(*ppxCnxt, 0, sizeof(x_IFX_CMGR_ReqContext));
		/*Use a local variable*/
		pxCnxt=*ppxCnxt;
		/*Set the context to busy*/
		pxCnxt->eStructStatus=IFX_CMGR_STRUCT_OCCUPIED;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetCallContext 
 *  Description 	: The function searches through Call Context array and 
 *  					 returns an empty one
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetCallContext
								(  
									IN  e_IFX_CMGR_BasicCallType eBasic,
								 	OUT x_IFX_CMGR_CallContext** ppxCnxt,
									OUT uint16* punCnxtIdx
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext *pxCnxt=NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Sanity Check */
	if(!ppxCnxt)
		 return IFX_FAILURE;

	/* Search for an empty call context struture in the array*/
	if(IFX_FAILURE==
				IFX_CMGR_AllocStruct((void**)ppxCnxt,punCnxtIdx,IFX_CMGR_CALL_CNXT))
	{
		eRet = IFX_FAILURE;
	}
	else
	{
		memset(*ppxCnxt, 0, sizeof(x_IFX_CMGR_CallContext));
		/*Use a local variable*/
		pxCnxt=*ppxCnxt;
		/*Set the context to busy*/
		pxCnxt->eStructStatus=IFX_CMGR_STRUCT_OCCUPIED;
		/* Add the basic call type*/
		pxCnxt->eBasicCallType = eBasic;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	:IFX_CMGR_DeAllocReqCnxt
 *  Description 	: Function frees all memory related to the Req context 
 *  					  and its request legs
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_DeAllocReqCnxt
				(IN x_IFX_CMGR_ReqContext* pxCnxt)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 i=0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Check the presence of non-NULL pointers and then free each Call leg*/
	if(pxCnxt) {
		for(i=0;i<IFX_CMGR_REQ_LEG_PER_CNXT;i++){
			if(pxCnxt->pxReqLegs[i]) 		{
				IFX_CMGR_DeAllocReqLeg(pxCnxt->pxReqLegs[i]);
				}
		}
	/* Memset the structure*/
	memset(pxCnxt,0,sizeof(x_IFX_CMGR_ReqContext));
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	:IFX_CMGR_DeAllocCallCnxt
 *  Description 	: Function frees all memory related to the Call context 
 *  					  and its call legs
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_DeAllocCallCnxt(IN x_IFX_CMGR_CallContext* pxCnxt)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	char8 szFromEid[IFX_MAX_ENDPOINTID_LEN];
	e_IFX_ReasonCode eReason = 0;
	uint32 i=0;
		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxCnxt)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	if(pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX])	
	{
		strcpy(szFromEid,
			pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX]->xLegOwnerInfo.szEndptId);
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             " NULL POINTER");
	}
	
	/*Check if the context has call legs - clear all call legs.*/	
	if(pxCnxt->ucNumCallLegs)
	{
		/*Check the presence of non-NULL pointers and then free each Call leg*/
		for(i=0;i<IFX_CMGR_MAX_LEGS_PER_CNXT;i++)
		{
			if(pxCnxt->pxCallLegs[i])
			{
				/* Check if there is a resource id*/
				if((pxCnxt->iResId)|| (pxCnxt->iResIdForTransfer))
				{
					/* Stop Session if the pointer exists*/	
					if(pxCnxt->pxCallLegs[i]->pxRtpCB)
					{
						/*Invoke Media Stop Session*/
						IFX_CMGR_StopMediaSession(pxCnxt->pxCallLegs[i]);
					}
					if(i != IFX_CMGR_OUT_CL_IDX)
					{
						eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId, szFromEid,
						pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId, &eReason);
					}
				}
				IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[i]);
				pxCnxt->pxCallLegs[i] = NULL;
				//IFX_CMGR_NullCallLegPtr(pxCnxt,pxCnxt->pxCallLegs[i]);
			}
		}
	}
	/* Memset the structure*/
	memset(pxCnxt,0,sizeof(x_IFX_CMGR_CallContext));
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/********************** Context Prep functions Start***************************/

/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtFxoExtn
 *  Description 	: Function prepares information needed for a Fxo to Extn call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtFxoExtn
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar,
										IN char8 aszEid[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNumEid
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
	uint8 i;
	uint8 ucNumEndptNotReg = 0;	
	uint8 ucValidLegs = 0; 
	x_IFX_CMGR_CallLeg *paxLocLeg[IFX_CMGR_MAX_LEGS_PER_CNXT];	

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/* Find EID for FXO Leg*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	/*Set the local ptr to NULL*/
	memset(paxLocLeg,0,IFX_CMGR_MAX_LEGS_PER_CNXT*sizeof(x_IFX_CMGR_CallLeg*));
	
	/*Set Information in FXO OUT CL*/
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_FXO;
	memcpy(&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
		&pxFrom->uxAddressInfo.xFxoInfo,sizeof(x_IFX_CMGR_FxoLegInfo));
	
	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/*Set the FXO Leg as the first valid leg*/ 
	paxLocLeg[0] = pxCnxt->pxCallLegs[0];
	ucValidLegs++;

	/*Save EID in the pxIn*/
	for(i=1;i<(ucNumEid + 1) && i<(IFX_CMGR_MAX_LEGS_PER_CNXT);i++)
	{

		memset(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
														0,sizeof(char)*IFX_MAX_ENDPOINTID_LEN);
		strncpy(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
																aszEid[i-1],IFX_MAX_ENDPOINTID_LEN-1);
		pxCnxt->pxCallLegs[i]->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
		
		if(IFX_FAILURE == 
			IFX_CMGR_GetCBList(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
												&pxCnxt->pxCallLegs[i]->pxCallBackList))
		{
				if(ucNumEndptNotReg == ucNumEid)
				{
					eRet = IFX_FAILURE;
					IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
					return eRet;
				}
				/*Clear the Call Leg*/
				IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[i]);
				/*Set the pointer to NULL*/
				pxCnxt->pxCallLegs[i] = NULL;	
				/*Reduce the number of call legs*/
				--pxCnxt->ucNumCallLegs;
				/*Increment the Not Registered count*/
				++ucNumEndptNotReg;
				/*move back to the loop*/
				continue;
		}
		paxLocLeg[ucValidLegs++] = pxCnxt->pxCallLegs[i];

		/*Populate the IN CL's Data - stuff like codecs*/
		eRet = IFX_CMGR_SetExtnLegInfo(IFX_FALSE,aszEid[i-1],
			&pxCnxt->pxCallLegs[i]->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo, 
				pxPar, &eReason);

		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"1");
		/*Set context to the current one*/
		pxCnxt->pxCallLegs[i]->pxCurrCnxt = pxCnxt;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"2");
	}

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"3");
	/*Copy the local one into the Context pointer*/
	memcpy(pxCnxt->pxCallLegs, paxLocLeg, 
									IFX_CMGR_MAX_LEGS_PER_CNXT*sizeof(x_IFX_CMGR_CallLeg*));
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"4");
	/*Set context to the current one*/
	pxOut->pxCurrCnxt = pxCnxt;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"5");

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtVoipExtn
 *  Description 	: Function prepares information needed for a Voip to Extn call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtVoipExtn
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar,
										IN char8 aszEid[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNumEid,
										IN uint8 ucVoipLineId
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_CallLeg *paxLocLeg[IFX_CMGR_MAX_LEGS_PER_CNXT];	
	uint8 i;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = /*Voip Leg owner Info*/
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		 
	uint8 ucNumEndptNotReg = 0;	
	uint8 ucValidLegs = 0; 
				 
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	/*Set the local ptr to NULL*/
	memset(paxLocLeg,0,IFX_CMGR_MAX_LEGS_PER_CNXT*sizeof(x_IFX_CMGR_CallLeg*));
	
	/* Find EID for VOIP Leg*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_VOIP;

	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/*Generate RTP/FAX CBs*/
	if((eRet = IFX_CMGR_SetMediaCallbacks(pxOut)) == IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	paxLocLeg[0] = pxCnxt->pxCallLegs[0];
	ucValidLegs++;
	
	for(i=1;i<(ucNumEid+1) && i<(IFX_CMGR_MAX_LEGS_PER_CNXT);i++)
	{
		/*Save EID in the pxIn*/
		memset(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
														0,sizeof(char)*IFX_MAX_ENDPOINTID_LEN);
		strncpy(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
																aszEid[i-1],IFX_MAX_ENDPOINTID_LEN-1);
		pxCnxt->pxCallLegs[i]->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
		
		if(IFX_CMGR_GetCBList(pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
												&pxCnxt->pxCallLegs[i]->pxCallBackList))
		{
				if(ucNumEndptNotReg == ucNumEid)
				{
					eRet = IFX_FAILURE;
					IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
					return eRet;
				}
				/*Clear the Call Leg*/
				IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[i]);
				/*Set the pointer to NULL*/
				pxCnxt->pxCallLegs[i] = NULL;	
				/*Reduce the number of call legs*/
				--pxCnxt->ucNumCallLegs;
				/*Increment the Not Registered count*/
				++ucNumEndptNotReg;
				/*move back to the loop*/
				continue;
		}
			
		paxLocLeg[ucValidLegs++] = pxCnxt->pxCallLegs[i];
		
		/*Populate the IN CL's Data - stuff like codecs*/
		eRet = IFX_CMGR_SetExtnLegInfo(IFX_FALSE,aszEid[i-1],
			&pxCnxt->pxCallLegs[i]->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo, 
				pxPar, &eReason);
		/*Set context to the current one*/
		pxCnxt->pxCallLegs[i]->pxCurrCnxt = pxCnxt;
	}
	/*Copy the local one into the Context pointer*/
	memcpy(pxCnxt->pxCallLegs, paxLocLeg, 
									IFX_CMGR_MAX_LEGS_PER_CNXT*sizeof(x_IFX_CMGR_CallLeg*));
	/* Get the Voip Line Information for the Line - save in the call leg*/
	if(IFX_FAILURE == 
		(eRet=IFX_LMGR_GetInfoForVoipCall(ucVoipLineId, pxVoipLegInfo, &eReason)))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Save the remote Voip address in the Leg info*/
	memcpy(&pxVoipLegInfo->xRemAddr,&pxFrom->uxAddressInfo.xVoipAddr,
																							 sizeof(x_IFX_CMGR_VoipAddr));	

	/*Set context to the current one*/
	pxOut->pxCurrCnxt = pxCnxt;

	/* Apply offer answer logic on the Leg*/
	IFX_CMGR_MakeSdpForIncVoipCall(pxOut, NULL, 
				&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams,
				&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xRtpParams
#ifdef FAX_SUPPORT
				,pxPar->uxCallParams.xVoipParams.xVoipMediaParams.axFaxParams,
				IFX_MAX_FAX_PROTO
#endif
				);

	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xRemAddr,  
											&pxVoipLegInfo->ucCallFwdCount);

	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xLocalVlAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
		
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_DefPrepCnxtVoipExtn
 *  Description 	: Function prepares information needed for a Voip to Extn call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_DefPrepCnxtVoipExtn
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar,
										IN char8 aszEid[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNumEid,
										IN uint8 ucVoipLineId
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_CallLeg* pxIn = pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs-1];
				 
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	
	/* Find EID for VOIP Leg*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_VOIP;

	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/*Generate RTP/FAX CBs*/
	if((eRet = IFX_CMGR_SetMediaCallbacks(pxOut)) == IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	/*Save EID in the pxIn*/
	memset(pxIn->xLegOwnerInfo.szEndptId,
														0,sizeof(char)*IFX_MAX_ENDPOINTID_LEN);
	strncpy(pxIn->xLegOwnerInfo.szEndptId,
																aszEid[0],IFX_MAX_ENDPOINTID_LEN-1);
	pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
		
	if(IFX_CMGR_GetCBList(pxIn->xLegOwnerInfo.szEndptId,
												&pxIn->pxCallBackList)){
		/*Clear the Call Leg*/
		IFX_CMGR_DeAllocCallLeg(pxIn);
		/*Set the pointer to NULL*/
		pxIn = NULL;	
		/*Reduce the number of call legs*/
		--pxCnxt->ucNumCallLegs;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
			
		
	/*Populate the IN CL's Data - stuff like codecs*/
	eRet = IFX_CMGR_SetExtnLegInfo(IFX_FALSE,aszEid[0],
			&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo, 
				pxPar, &eReason);

	/*Set context to the current one*/
	pxIn->pxCurrCnxt = pxCnxt;

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtVoipFxo
 *  Description 	: Function prepares information needed for a Voip to Fxo call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtVoipFxo
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar,
										IN char8* szFxoEid,
										IN uint8 ucVoipLineId
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason=0;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
	x_IFX_CMGR_CallLeg* pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = /*Voip Leg owner Info*/
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		 

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/* Find EID for VOIP Leg*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_VOIP;
	/*Save Fxo-id pxIn*/
	memset(pxIn->xLegOwnerInfo.szEndptId,0,IFX_MAX_ENDPOINTID_LEN);
	strncpy(pxIn->xLegOwnerInfo.szEndptId,szFxoEid,IFX_MAX_ENDPOINTID_LEN - 1);
	pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_FXO;

	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	/*Generate RTP/FAX CBs*/
	if((eRet = IFX_CMGR_SetMediaCallbacks(pxOut)) == IFX_FAILURE)
	{
		/*Major Error - DEBUG*/
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	if(IFX_CMGR_GetCBList(pxIn->xLegOwnerInfo.szEndptId,
											&pxIn->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	/*Populate the OUT & IN CL's addresses */
	strcpy(pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szFxoLineId,
						 					pxIn->xLegOwnerInfo.szEndptId);
	/* For Two stage dial set the number to Zero*/
	strcpy(pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szPhoneNumber,"");

	/* Get the Voip Line Information for the Line - save in the call leg*/
	if(IFX_FAILURE == 
		(eRet = IFX_LMGR_GetInfoForVoipCall(ucVoipLineId, pxVoipLegInfo, &eReason)))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Save the remote Voip address in the Leg info*/
	memcpy(&pxVoipLegInfo->xRemAddr,
									&pxFrom->uxAddressInfo.xVoipAddr,sizeof(x_IFX_CMGR_VoipAddr));	

	/* Apply offer answer logic on the Leg*/
	IFX_CMGR_MakeSdpForIncVoipCall(pxOut, pxIn, 
				&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams,
				&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xRtpParams
#ifdef FAX_SUPPORT
				,pxPar->uxCallParams.xVoipParams.xVoipMediaParams.axFaxParams,2
#endif
				);
	
	/* Add remote party to the call forward list*/	
	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xRemAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
	
	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xLocalVlAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
		
	/*Set context to the current one*/
	pxIn->pxCurrCnxt = pxCnxt;
	pxOut->pxCurrCnxt = pxCnxt;

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtExtnFxo
 *  Description 	: Function prepares information needed for a Extn to Fxo call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtExtnFxo
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
	x_IFX_CMGR_CallLeg* pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Find EID for EXTN*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
	/* IN CL is an FXO leg - Get FXO ID from the LMGR*/
	eRet=IFX_LMGR_GetFxoLineForEndpt(pxOut->xLegOwnerInfo.szEndptId,
										 pxIn->xLegOwnerInfo.szEndptId,&eReason);
	if(IFX_FAILURE == eRet)
	{
		return eRet;
	}
	pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_FXO;
	
	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	if(IFX_CMGR_GetCBList(pxIn->xLegOwnerInfo.szEndptId,
											&pxIn->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	/*Populate the OUT CL  */
	eRet = IFX_CMGR_SetExtnLegInfo(IFX_TRUE,pxOut->xLegOwnerInfo.szEndptId,
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo, 
				pxPar, &eReason);
	/*Populate the IN CL */
	memcpy(&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
		&pxTo->uxAddressInfo.xFxoInfo,sizeof(x_IFX_CMGR_FxoInfo));
	strcpy(pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szFxoLineId,
						 					pxIn->xLegOwnerInfo.szEndptId);
	if(IFX_FAILURE == eRet)
	{

		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /* Major Faliure -DEBUG*/
	}
	/*Set context to the current one*/
	pxIn->pxCurrCnxt = pxCnxt;
	pxOut->pxCurrCnxt = pxCnxt;

	/*Add to the Dialed Called List*/
	IFX_LMGR_AddToPlcdCallReg(IFX_PSTN_LINE,pxTo);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtExtnExtn
 *  Description 	: Function prepares information needed for a Extn to Extn call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtExtnExtn
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
	x_IFX_CMGR_CallLeg* pxIn = pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs-1];
	//x_IFX_CMGR_CallLeg* pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Find EID for EXTN 1*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	printf("cosicvoip, Endptid is %s\n",pxFrom->uxAddressInfo.szEndptId);
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
	/* Find the EID of the IN CL from the TO address*/
	IFX_CMGR_GetEidFromAddrInfo(pxTo,pxIn->xLegOwnerInfo.szEndptId);
	pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		printf("IFX_CMGR_PrepCnxtExtnExtn Fail Point 1\n");
		return IFX_FAILURE;
	}
	if(IFX_CMGR_GetCBList(pxIn->xLegOwnerInfo.szEndptId,
											&pxIn->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		printf("IFX_CMGR_PrepCnxtExtnExtn Fail Point 2\n");
		return IFX_FAILURE;
	}

	/*Populate the OUT CL  */
	eRet = IFX_CMGR_SetExtnLegInfo(IFX_TRUE,pxOut->xLegOwnerInfo.szEndptId,
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo, 
				pxPar, &eReason);
	if(IFX_FAILURE == eRet)
	{
		printf("IFX_CMGR_PrepCnxtExtnExtn Fail Point 3\n");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /* Major Faliure -DEBUG*/
	}

	/*Populate the IN CL */
	eRet = IFX_CMGR_SetExtnLegInfo(IFX_FALSE,pxIn->xLegOwnerInfo.szEndptId,
			&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo, 
				pxPar, &eReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		printf("IFX_CMGR_PrepCnxtExtnExtn Fail Point 4\n");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /* Major Faliure -DEBUG*/
	}
	/*Set context to the current one*/
	pxIn->pxCurrCnxt = pxCnxt;
	pxOut->pxCurrCnxt = pxCnxt;

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtFxoVoip
 *  Description 	: Function prepares information needed for a Fxo to Voip call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtFxoVoip
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar,
										IN e_IFX_CMGR_Status* peStatus,
										IN e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
	x_IFX_CMGR_CallLeg* pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	x_IFX_CMGR_VoipLegInfo *pxVoipLegInfo = 
		&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	//uint8 ucVoipLineId = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Find EID for Fxo*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	/*Set Information in FXO OUT CL*/
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_FXO;
	memcpy(&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
						 &pxFrom->uxAddressInfo.xFxoInfo,
			sizeof(x_IFX_CMGR_FxoLegInfo));
	
	/*Save the NA's VL ID in the Voip leg*/
	IFX_CMGR_GetEidFromAddrInfo(pxTo,pxIn->xLegOwnerInfo.szEndptId);
	
	/* Get the Voice Line Id*/
#if 0
	eRet = IFX_LMGR_GetFxoDefaultVoipLine(
						 pxOut->xLegOwnerInfo.szEndptId, &ucVoipLineId, peReason);
	if(!ucVoipLineId || (IFX_FAILURE == eRet))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_USER_NOT_FOUND; 
		eRet = IFX_SUCCESS;
		IFX_DBGA(vxCmgrInfo.ucDebugId,\
										IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Voip Line attached!");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}
#endif
	/* Get all the information needed for an OUT going Voip Call*/
	eRet = IFX_LMGR_GetInfoForVoipCall(pxTo->ucLineId/*ucVoipLineId*/, pxVoipLegInfo, peReason);	
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		eRet = IFX_SUCCESS;
		IFX_DBGA(vxCmgrInfo.ucDebugId,\
										IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No resources for call");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}
	/*Set the leg type as VOIP*/
	pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_VOIP;
	/*Save the remote Voip address in the Leg info*/
	memcpy(
			&pxVoipLegInfo->xRemAddr,
			&pxTo->uxAddressInfo.xVoipAddr,
			sizeof(x_IFX_CMGR_VoipAddr));
	
	/* Apply offer answer Logic for the Out going call*/
	eRet = IFX_CMGR_MakeSdpForOutVoipCall(pxIn, pxOut, NULL);		
	
	/*Add stuff to the call forward list*/
	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xRemAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xLocalVlAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
	
	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	if(IFX_CMGR_GetCBList(pxIn->xLegOwnerInfo.szEndptId,
											&pxIn->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	/*Generate RTP/FAX CBs*/
	if((eRet = IFX_CMGR_SetMediaCallbacks(pxIn)) == IFX_FAILURE)
	{
		/*Major Error - DEBUG*/
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	/*Set context to the current one*/
	pxIn->pxCurrCnxt = pxCnxt;
	pxOut->pxCurrCnxt = pxCnxt;

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
/*****************************************************************************
 *  Function Name	: IFX_CMGR_PrepCnxtExtnVoip
 *  Description 	: Function prepares information needed for a Extn to Voip call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepCnxtExtnVoip
									(
								 		IN x_IFX_CMGR_CallContext*  pxCnxt,
					 					IN x_IFX_CMGR_AddressInfo* pxFrom,
					 					IN x_IFX_CMGR_AddressInfo* pxTo,
										IN x_IFX_CMGR_CallParams* pxPar,
										IN e_IFX_CMGR_Status* peStatus,
										IN e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
  x_IFX_CMGR_CallLeg* pxIn = pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs-1];
  //x_IFX_CMGR_CallLeg *pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	x_IFX_CMGR_VoipLegInfo *pxVoipLegInfo = 
		&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	uint8 ucVoipLineId = 0;
	//boolean bIsReg;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Find EID for EXTN*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
	pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;

	/*Get the endpoint id of NA*/
	IFX_CMGR_GetEidFromAddrInfo(pxTo,pxIn->xLegOwnerInfo.szEndptId);
	pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_VOIP;

  ucVoipLineId = pxTo->ucLineId;

#if 0
	/* Get the default Voice Line Id of the Endpoint*/
	eRet = IFX_LMGR_GetEndptDefaultVoipLine(
						 pxOut->xLegOwnerInfo.szEndptId,&ucVoipLineId,&bIsReg,peReason);
	if((IFX_FAILURE == eRet) || !ucVoipLineId)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_USER_NOT_FOUND; 
		IFX_CMGR_PrintExitInfo(IFX_SUCCESS, __FUNCTION__, __LINE__);
		return IFX_SUCCESS; 
	}
#endif
#if 0
	 if( IFX_FALSE == IFX_CIF_IsLineTypeMulti(ucVoipLineId) &&
			 IFX_TRUE == IFX_CMGR_AnyCallOnVL(ucVoipLineId)) {
			*peStatus = IFX_CMGR_STATUS_FAIL;
			*peReason = IFX_ENDPOINT_BUSY; 
			IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Can't take second call on this line - fail");
			return IFX_SUCCESS; 
	 }
#else
   if( IFX_FALSE == IFX_CMGR_IsCallAllowed(ucVoipLineId,pxOut->xLegOwnerInfo.szEndptId)) {
      *peStatus = IFX_CMGR_STATUS_FAIL;
      *peReason = IFX_ENDPOINT_BUSY;
      IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Can't take second call on this line - fail");
      return IFX_SUCCESS;
   }

#endif
	/*Set Information in EXTN OUT CL*/
	eRet = IFX_CMGR_SetExtnLegInfo(IFX_TRUE,pxOut->xLegOwnerInfo.szEndptId,
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo,pxPar,peReason);

	/* Get all the information needed for an OUT going Voip Call*/
	eRet = IFX_LMGR_GetInfoForVoipCall(ucVoipLineId, pxVoipLegInfo, peReason);	
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		eRet = IFX_SUCCESS;
		IFX_DBGA(vxCmgrInfo.ucDebugId,\
										IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No resources for call");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}
	/*Save the remote Voip address in the Leg info*/
	memcpy( &pxVoipLegInfo->xRemAddr, &pxTo->uxAddressInfo.xVoipAddr,
			sizeof(x_IFX_CMGR_VoipAddr));
	
	/* Apply offer answer Logic for the Out going call*/
	eRet = IFX_CMGR_MakeSdpForOutVoipCall(pxIn, pxOut, NULL);		
	
	/*Add stuff to the call forward list*/
	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xRemAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
	IFX_CMGR_AddToCallFwdList(pxVoipLegInfo->axCallFwdList, 
										&pxVoipLegInfo->xLocalVlAddr,  
											&pxVoipLegInfo->ucCallFwdCount);
	
	/*Add to the Dialed Called List*/
	IFX_LMGR_AddToPlcdCallReg(ucVoipLineId,pxTo);	
	
	/* Make Pointers to CB structs*/
	if(IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,
												&pxOut->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	if(IFX_CMGR_GetCBList(pxIn->xLegOwnerInfo.szEndptId,
											&pxIn->pxCallBackList))
	{
		/*Major Error - DEBUG*/
		return IFX_FAILURE;
	}
	/*Generate RTP/FAX CBs*/
	if((eRet = IFX_CMGR_SetMediaCallbacks(pxIn)) == IFX_FAILURE)
	{
		/*Major Error - DEBUG*/
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	/*Set context to the current one*/
	pxIn->pxCurrCnxt = pxCnxt;
	pxOut->pxCurrCnxt = pxCnxt;

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/********************** Context Prep functions End*****************************/

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MakeCallParamsFxoExtn 
 *  Description 	: Function prepares call params for the Extn Leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallParamsFxoExtn
								(
									IN x_IFX_CMGR_CallLeg* pxIn,
									IN x_IFX_CMGR_CallParams* pxPar,
									OUT x_IFX_CMGR_CallParams* pxNewPar,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxIn);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_CodecParams* pxCodecs = 
			&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;
	x_IFX_CMGR_CodecParams* pxNewParCodecs =
		&pxNewPar->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/*Save the current params in the Leg*/
	memcpy(&pxOut->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));		
	/* Find the things that have to be copied from the pxPar into the pxNewPar*/
	/* Populate the pxNewPar with the stuff in the in call leg also*/
	if(pxCodecs->unNoOfCodecs)
	{
		memcpy(pxNewParCodecs,pxCodecs,sizeof(x_IFX_CMGR_CodecParams));
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MakeCallParamsVoipExtn 
 *  Description 	: Function prepares call params for the Extn Leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallParamsVoipExtn
								(
									IN x_IFX_CMGR_CallLeg* pxIn,
									IN x_IFX_CMGR_CallParams* pxPar,
									OUT x_IFX_CMGR_CallParams* pxNewPar,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;
	boolean bFwdEnabled = IFX_FALSE;
	x_IFX_CMGR_VoipAddr xFwdAddr;
	char8 ucRingCount = 0;
					
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");

	if (pxIn){    //aarif
		pxCnxt = IFX_CMGR_GetCurrCnxt(pxIn);
	}else{
		return IFX_FAILURE;
	}
	if (pxCnxt){
		pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	}else{
		return IFX_FAILURE;
	}
	if (pxOut){
		pxVoipLegInfo = &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	}else{
		return IFX_FAILURE;
	}
	/*Save the current params in the Leg*/
	memcpy(&pxOut->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));		
	/* Populate the new call params*/
	pxNewPar->eAgentType = IFX_CMGR_TYPE_EXTN;
	if(pxIn)
	{
		/* Copy codecs from the offered list in the IN Leg, into the new par*/
		memcpy(&pxNewPar->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams,
		&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo,
		sizeof(x_IFX_CMGR_CodecParams));		
	}
	/*Find the number of ring counts to give*/
	IFX_LMGR_GetCallFwdAddr(pxVoipLegInfo->ucLineId, 
					IFX_CALL_FWD_ON_NO_ANSWER, &bFwdEnabled, (uchar8 *)&ucRingCount, &xFwdAddr,peReason);
	/*If the ring count exists, then use it else use zero indicating default*/
	pxNewPar->uxCallParams.xExtnParams.cRingCount = (int8)ucRingCount;
  if(IFX_FALSE == bFwdEnabled){
	pxNewPar->uxCallParams.xExtnParams.cRingCount = 0;
  }
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MakeCallParamsExtnFxo
 *  Description 	: Function prepares call params for the Fxo Leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallParamsExtnFxo
								(
									IN x_IFX_CMGR_CallLeg* pxIn,
									IN x_IFX_CMGR_CallParams* pxPar,
									OUT x_IFX_CMGR_CallParams* pxNewPar,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxIn);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/*Save the current params in the Leg*/
	memcpy(&pxOut->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));		
	/* Find the things that have to be copied from the pxPar into the pxNewPar*/
	pxNewPar->uxCallParams.xFxoParams.bEmergency = 		
									pxPar->uxCallParams.xExtnParams.bEmergency;
	pxNewPar->eAgentType = IFX_CMGR_TYPE_FXO;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MakeCallParamsIntVoip 
 *  Description 	: Function prepares call params for the Voip Leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallParamsIntVoip
								(
									IN x_IFX_CMGR_CallLeg* pxIn,
									IN x_IFX_CMGR_CallParams* pxPar,
									OUT x_IFX_CMGR_CallParams* pxNewPar
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxIn);
	x_IFX_CMGR_VoipMediaParams* pxMediaPar;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_VoipLegInfo* pxLegInfo =    
			  &pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo; 
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(pxPar)
	{
		/*Save the current params in the Leg*/
		memcpy(&pxOut->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));		
	
		/* Find the things that have to be copied from the pxPar into pxNewPar*/
		if(IFX_CMGR_TYPE_EXTN == pxPar->eAgentType)
		{
			boolean bSupressId = IFX_FALSE;
			
			/*Check if Caller ID is enabled for this call*/
			if(IFX_CMGR_ENABLE == pxPar->uxCallParams.xExtnParams.eCallerIdStatus)
			{
				bSupressId = IFX_FALSE;
			}
			else
			if(IFX_CMGR_DISABLE == pxPar->uxCallParams.xExtnParams.eCallerIdStatus)
			{
				bSupressId = IFX_TRUE;
			}	
			else
			{
				/*Check the Line Value*/
				boolean bEnable = IFX_TRUE;
				IFX_LMGR_GetCidStatus( pxLegInfo->ucLineId,&bEnable);
				bSupressId = bEnable?IFX_FALSE:IFX_TRUE;
			}
			/*Set the final value in NewPar*/	
			pxNewPar->uxCallParams.xVoipParams.bSupressCallerId =  bSupressId;
		}
		else
		if(IFX_CMGR_TYPE_FXO == pxPar->eAgentType)
		{
			strcpy(pxNewPar->uxCallParams.xVoipParams.szPhoneNumber,
				pxOut->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szPhoneNumber);
		}
	}
	pxNewPar->eAgentType = IFX_CMGR_TYPE_VOIP;
	/* Add codecs from the offered codec list into pxNewPar*/
	pxMediaPar = &pxNewPar->uxCallParams.xVoipParams.xVoipMediaParams;	
	/*Copy Offered Codecs*/
	memcpy(&pxMediaPar->xCodecParams,
			&pxLegInfo->xOfferedCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
	/* Copy RTP params with local RTP Info*/
	memcpy(&pxMediaPar->xRtpParams,
			&pxLegInfo->xNegRtpParams,sizeof(x_IFX_CMGR_RtpParams));
#ifdef FAX_SUPPORT
	/* Copy Fax Information*/
	memcpy(pxMediaPar->axFaxParams,
		pxLegInfo->axFaxParams, IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
#endif
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MakeCallParamsExtnExtn 
 *  Description 	: Function prepares call params for the Extn Leg
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallParamsExtnExtn
								(
									IN x_IFX_CMGR_CallLeg* pxIn,
									IN x_IFX_CMGR_CallParams* pxPar,
									OUT x_IFX_CMGR_CallParams* pxNewPar,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxIn);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_CodecParams* pxCodecs = 
			&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;
	x_IFX_CMGR_CodecParams* pxNewParCodecs =
		&pxNewPar->uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");

	/*Save the current params in the Leg*/
	memcpy(&pxOut->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));		
	/* Find the things that have to be copied from the pxPar into the pxNewPar*/
	/* Populate the pxNewPar with the codecs to be offered in the Call Leg*/
	if(pxCodecs->unNoOfCodecs)
	{
		memcpy(pxNewParCodecs,pxCodecs,sizeof(x_IFX_CMGR_CodecParams));
	}

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Codecs Sent to the HS = ",pxCodecs->unNoOfCodecs);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/********************** MMGR Wrapper functions Start*****************************/

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MapMmgrReturn 
 *  Description 	: Function maps the return types of MMGR to those of CMGR
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_MapMmgrReturn
									(	IN e_IFX_MMGR_Return eMmgrRet,
										OUT e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_FAILURE;
	if(IFX_MMGR_NO_RESOURCE == eMmgrRet)
	{
		*peReason = IFX_NO_RESOURCE;
	}else
	if(eMmgrRet == IFX_MMGR_SUCCESS)
	{
		eRet = IFX_SUCCESS;
		*peReason = IFX_MAX_REASON;
	}
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_SetRtpModeOption 
 *  Description 	: See the current RTP SDP mode and the correct options for
 										MMGR to use
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_SetRtpModeOption(
									IN x_IFX_CMGR_RtpParams* pxRtp,
									OUT uint32* puiOptions
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	switch(pxRtp->eSdpMode)	
	{
		case IFX_SENDRECV:
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "ACTIVE MODE");
			*puiOptions |= IFX_MMGR_START_ENCODING;
		break;
	 case IFX_SENDONLY:
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													"SENDONLY MODE");
		 *puiOptions |= IFX_MMGR_START_ENCODING;
		 *puiOptions |= IFX_MMGR_STOP_DECODING;
	 break;
	 case IFX_RECVONLY:
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													"RECVONLY MODE");
		 *puiOptions |= IFX_MMGR_STOP_ENCODING;
	 break;
	 case IFX_INACTIVE:
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
													"INACTIVE MODE");
		 *puiOptions |= IFX_MMGR_STOP_ENCODING;
		 *puiOptions |= IFX_MMGR_STOP_DECODING;
	 break;
	 default:
	 	eRet = IFX_FAILURE;
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_StartMediaSession 
 *  Description 	: Function invokes Config Media with codecs and other 
 *  					 parameters and then invokes Rtp
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_StartMediaSession(
					 IN x_IFX_CMGR_CallLeg *pxLeg,
					 IN int32 iResId,
					 IN e_IFX_ReasonCode *peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet = 0;
	x_IFX_MMGR_MediaParams xMedia;
	x_IFX_MMGR_SessionInfo xSession;
	uint32 uiOptions = 0;
	int32 i = -1;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo =    
			  &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo; 
	x_IFX_CMGR_CodecParams *pxCodec = &pxLegInfo->xNegCodecInfo;
	x_IFX_CMGR_RtpParams* pxRtp = &pxLegInfo->xNegRtpParams;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	memset(&xMedia,0,sizeof(x_IFX_MMGR_MediaParams));
	memset(&xSession,0,sizeof(x_IFX_MMGR_SessionInfo));

	if(!iResId)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Just set it in as its mandatory*/	
	uiOptions |= IFX_MMGR_UPDATE_CODEC_LIST;

	/* Search for the RFC 2833 in the Codec List - add Flag in the uiOptions*/
	uiOptions |= IFX_MMGR_TELEPHONY_EVENT_CONFIG;
	/*Add Parameters for the Telephony Event Info*/
	xMedia.xTelEventInfo.eEventTransMode = 
					  pxLegInfo->xLocTelEvtInfo.eEventTransMode;
	if(IFX_TRUE == IFX_CMGR_SearchForCodec(pxCodec,IFX_DIGIT_2833,&i))
	{
			xMedia.xTelEventInfo.eAction = pxLegInfo->xLocTelEvtInfo.eAction;
			xMedia.xTelEventInfo.ucPayLoadTypeTx = pxCodec->axCodec[i].ucDynPT; 	
			xMedia.xTelEventInfo.ucPayLoadTypeRx = pxCodec->axCodec[i].ucDynPT; 	
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"2833 found and Cfg");
	}

	/*Enable VAD if configured*/
	if(IFX_TRUE == pxLegInfo->bSilenceSupEnabled)	
		uiOptions |= IFX_MMGR_SID_ACTIVATE;
#ifdef FAX_SUPPORT	
	/*Check if the Media Session to be started is for FAX.*/
	if(IFX_CMGR_GET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																									IFX_CMGR_FLAG_ENABLE_FAX))
	{
		/*Set mode to RTP mode to inactive*/
		pxRtp->eSdpMode = IFX_INACTIVE;
	 	/* Disable the LEC*/	
		eMmgrRet = IFX_MMGR_LecDisable(iResId);
		eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
		/*In case FAX is to be run, no need to update codecs & set 2833*/
		uiOptions &= ~IFX_MMGR_UPDATE_CODEC_LIST;
		uiOptions &= ~IFX_MMGR_TELEPHONY_EVENT_CONFIG;
		uiOptions &= ~IFX_MMGR_SID_ACTIVATE;
	}
#endif
	/*Prepare uiOptions based on the SDP mode*/
	IFX_CMGR_SetRtpModeOption(pxRtp,&uiOptions);
	/* Call Function to do codec conversion */
  
	
	IFX_CMGR_ConvertToMMGR_Codecs(pxCodec, &xMedia.xCodecList);	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Payload type for Codec# 0",pxCodec->axCodec[0].ucDynPT);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Codec# 0 type is ",pxCodec->axCodec[0].ucDynPT);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Payload type for Codec# 0 to MMGR",xMedia.xCodecList.axCodecs[0].ucIANA_PayloadType);

	/* Enable JB flag in uiOptions*/
	uiOptions |= IFX_MMGR_JB_CONFIGURE;
	memcpy(&xMedia.xJBCfg, &pxLegInfo->xJbInfo, sizeof(x_IFX_CMGR_JB_Info));
#ifdef UDP_REDIRECT
			uint32 uiSrcIp=0, uiDestIp=0;
			uiSrcIp = inet_addr((char8 *)pxRtp->szLocalRtpIpAddr);
			uiDestIp = inet_addr((char8 *)pxRtp->szRemoteRtpIpAddr);
			eRet = IFX_MMGR_QosStart(/*xSession.szDevChannelName*/iResId,uiSrcIp,pxRtp->uiLocalRtpPort,
						uiDestIp,pxRtp->uiRemoteRtpPort);
			eRet= IFX_MMGR_QosActivate(iResId,pxRtp->uiLocalRtpPort);//aarif
#endif
	/*Invoke ConfigMedia with the Codecs given*/
	xMedia.uiOptions = uiOptions;
	eMmgrRet = IFX_MMGR_MediaCfg(iResId, &xMedia, &xSession);
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Media Cfg Failed");
		
		/* TO DO - Send Release to both the legs*/
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Indicate the MediaCfg is done*/
	IFX_CMGR_SET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																	IFX_CMGR_FLAG_MEDIA_CFG_DONE);
#ifdef FAX_SUPPORT	
	if(!IFX_CMGR_GET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																									IFX_CMGR_FLAG_ENABLE_FAX))
	{
#endif
		/* Invoke Rtp Start Session */
		eRet = IFX_CMGR_InvokeStartRtpSession(pxLeg, pxRtp, &xSession);
#ifdef FAX_SUPPORT	
	}
	else
	{
		/* Invoke Fax Start Session*/
		eRet = IFX_CMGR_InvokeStartFaxSession(pxLeg,xSession.szDevChannelName);
		/* Reset flag to the ENABLE_FAX flag*/
		IFX_CMGR_RESET_FLAG(pxLeg->pxCurrCnxt->unFlags, IFX_CMGR_FLAG_ENABLE_FAX);
	}	
#endif
#ifdef UDP_REDIRECT
		if(IFX_SUCCESS != eRet) {
			IFX_MMGR_QosStop(iResId,pxRtp->uiLocalRtpPort);
		}
#endif

	/* Copy the channel number into the VoipLegInfo - For switching to Fax*/
	strcpy(pxLegInfo->szDevChannelName, xSession.szDevChannelName);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_ModifyMediaSession 
 *  Description 	: Function invokes Modify Media with codecs and other 
 *  					 parameters and then invokes RtpSessionModify if needed. 
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ModifyMediaSession(
					 IN x_IFX_CMGR_CallLeg *pxLeg,
					 IN x_IFX_CMGR_CallLeg* pxPeer,
					 IN int32 iResId,
					 IN boolean bModifyRtp,
					 OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	x_IFX_MMGR_MediaParams xMedia;
	uint32 uiOptions = 0;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo =  NULL; 
	x_IFX_CMGR_CodecParams *pxCodec = NULL; 
	x_IFX_CMGR_RtpParams* pxRtp = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	pxVoipLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo; 
	
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		pxRtp = &pxVoipLegInfo->xNegRtpParams;
		pxCodec = &pxVoipLegInfo->xNegCodecInfo;
	}
	else
	{
		/* DEBUG*/
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	memset(&xMedia,0,sizeof(x_IFX_MMGR_MediaParams));
#if 0 //Not needed because the of the restart of SEQ number after hold
	/* Search for the RFC 2833 in the Codec List - add Flag in the uiOptions*/
	uiOptions |= IFX_MMGR_TELEPHONY_EVENT_CONFIG;
	/*Add Parameters for the Telephony Event Info*/
	xMedia.xTelEventInfo.eEventTransMode = 
					  pxVoipLegInfo->xLocTelEvtInfo.eEventTransMode;
	if(IFX_TRUE == IFX_CMGR_SearchForCodec(pxCodec,IFX_DIGIT_2833,&i))
	{
			xMedia.xTelEventInfo.eAction = pxVoipLegInfo->xLocTelEvtInfo.eAction;
			xMedia.xTelEventInfo.ucPayLoadTypeTx = pxCodec->axCodec[i].ucDynPT; 	
			xMedia.xTelEventInfo.ucPayLoadTypeRx = pxCodec->axCodec[i].ucDynPT; 	
	}
#endif
	uiOptions |= IFX_MMGR_UPDATE_CODEC_LIST;
#ifdef FAX_SUPPORT	
	/*Check if the Media Session to be started is for FAX.*/
	if(IFX_CMGR_GET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																									IFX_CMGR_FLAG_ENABLE_FAX))
	{
		/*Set mode to RTP mode to inactive*/
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "RTP Mode set to inactive");
		pxRtp->eSdpMode = IFX_INACTIVE; 
		/* LEC Disable*/
		eMmgrRet = IFX_MMGR_LecDisable(iResId);
/*CoC Power savings changes - STARTS*/
#if 1 
		/* Added to test fax */
		eMmgrRet = IFX_MMGR_MftdEnable(iResId,IFX_FALSE);
#endif
			/*END*/
		eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);

		/*In case FAX is to be run, no need to update codecs & set 2833*/
		uiOptions &= ~IFX_MMGR_UPDATE_CODEC_LIST;
		uiOptions &= ~IFX_MMGR_TELEPHONY_EVENT_CONFIG;
		uiOptions &= ~IFX_MMGR_SID_ACTIVATE;
	}
#endif
	/*Prepare uiOptions based on the SDP mode*/
	if(pxRtp)
	{
		IFX_CMGR_SetRtpModeOption(pxRtp,&uiOptions);
	}
	/* Call Function to do codec conversion */
	IFX_CMGR_ConvertToMMGR_Codecs(pxCodec, &xMedia.xCodecList);
	
	/* Invoke Modify media*/
	xMedia.uiOptions = uiOptions;	
	eMmgrRet = IFX_MMGR_MediaModify(iResId, &xMedia);	
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Media Modify Failed!!");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* Invoke Modify Rtp Session */
	if(IFX_TRUE == bModifyRtp)
		eRet = IFX_CMGR_InvokeModifyRtpSession(pxLeg, pxRtp);	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_InvokeMediaSession 
 *  Description 	: Function invokes MediaCfg or MediaModify as per the flag
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_InvokeMediaSession( 
								IN x_IFX_CMGR_CallLeg *pxLeg,
					 			IN int32 iResId,
								IN boolean bRtpDiffer,
							 	OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg->pxCurrCnxt;
		
	if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),\
																IFX_CMGR_FLAG_MEDIA_CFG_DONE))
	{
		/*Start Session in this case*/
		eRet = IFX_CMGR_StartMediaSession(pxLeg,iResId,peReason);
	}
	else
	{
		/*Modify Session in this case*/
		eRet=IFX_CMGR_ModifyMediaSession(
							pxLeg,pxLeg->pxPeer,iResId,bRtpDiffer,peReason);
	}
	
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_XConnect 
 *  Description 	: Function invokes Config/Modify Media to make/break internal
 *  					  connections.
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_XConnect(
					 IN int32 iResId, 
					 IN boolean bConnect, 
					 IN  boolean bInitial,
					 OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	x_IFX_MMGR_MediaParams xMedia;
	x_IFX_MMGR_SessionInfo xSession;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Pass the right params into the MMGR Config/ModifyMedia API*/
	memset(&xMedia,0,sizeof(x_IFX_MMGR_MediaParams));
	memset(&xSession,0,sizeof(x_IFX_MMGR_SessionInfo));
	if(IFX_TRUE == bConnect)
		xMedia.uiOptions = IFX_MMGR_XCONNECT;
	else
		xMedia.uiOptions = IFX_MMGR_XDISCONNECT;

	if(IFX_TRUE == bInitial)
	{
		eMmgrRet = IFX_MMGR_MediaCfg(iResId,&xMedia,&xSession);
	}
	else
	{
		eMmgrRet = IFX_MMGR_MediaModify(iResId,&xMedia);
	}
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_MoveMediaResource 
 *  Description 	: Function invokes Move Resource API to move the coder 
 *  					  channel from one enpoint to another 
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MoveMediaResource(
									IN int32 iResId,
									IN char8* szFrom,
									IN char8* szTo,
					 				OUT e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Pass the right params into the MMGR MOVE RESOURCE API*/
	eMmgrRet = IFX_MMGR_ResMove(szFrom, szTo, iResId);

	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetAddMediaRes 
 *  Description 	: Function invokes ReserveResource for an additional resource
 *  					  needed for the purpose of Call transfer.
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetAddMediaRes(
					 				IN int32 iResId,
					 				IN x_IFX_CMGR_CallLeg *pxOut,
					 				IN x_IFX_CMGR_CallLeg *pxIn,
									OUT int32* piAddResId,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	e_IFX_MMGR_TypeOfCall eType = IFX_MMGR_CALL_EXTN_VOIP;
	x_IFX_MMGR_CodecList xMmgrCodecList,xMmgrIntCodecList,*pxMmgrInt=NULL;
	uint8 ucDynPt = 0;
#ifdef FAX_SUPPORT
	boolean bIsT38_UDP_Present = IFX_FALSE;
	boolean bIsT38_TCP_Present = IFX_FALSE;
	boolean bT38_TCP_Pref = IFX_FALSE;
#endif	
	
	x_IFX_CMGR_CodecParams *pxCodecs = 
		&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xOfferedCodecInfo;
	x_IFX_CMGR_CodecParams *pxIntCodecs = 
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;
					
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	*piAddResId = 0;
	memset(&xMmgrCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	memset(&xMmgrIntCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	
	/*Check the type of the new call*/
	if(IFX_CMGR_TYPE_FXO == pxOut->xLegOwnerInfo.eOwnerType)
	{
		eType = IFX_MMGR_CALL_FXO_VOIP;
		/*Set codecs for the internal side to NULL*/
		pxIntCodecs = NULL;
	}
	
	/*Convert Internal side codecs if party is Extn with codecs*/
	if(pxIntCodecs && pxIntCodecs->unNoOfCodecs)
	{
		IFX_CMGR_ConvertToMMGR_Codecs(pxIntCodecs, &xMmgrIntCodecList);
		pxMmgrInt = &xMmgrIntCodecList;	
	}
	else
	{
		pxIntCodecs = NULL;
	}

	/*Search for DTMF 2833 in the List*/
	IFX_CMGR_SearchForDtmf(pxCodecs,&ucDynPt);
	
#ifdef FAX_SUPPORT
	/*Find if any Fax related stuff is present and give its order */
	IFX_CMGR_SearchForT38(pxCodecs, &bIsT38_UDP_Present, 
						 				&bIsT38_TCP_Present, &bT38_TCP_Pref);	
#endif	
	/* Call Function to do codec conversion*/
	IFX_CMGR_ConvertToMMGR_Codecs(pxCodecs, &xMmgrCodecList);	
	
	/* Pass the right params into the MMGR ReserveResourceForCall API*/
	eMmgrRet = IFX_MMGR_ResReserveForCall(&iResId, piAddResId, IFX_TRUE,
		pxOut->xLegOwnerInfo.szEndptId,pxIn->xLegOwnerInfo.szEndptId, eType,
		pxMmgrInt,&xMmgrCodecList);

	/* Clear the currently running codecs*/
	memset(pxCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
	/* Generate the new negotiated list*/
	IFX_CMGR_ConvertToNA_Codecs(&xMmgrCodecList, 
#ifdef FAX_SUPPORT
		bIsT38_UDP_Present, bIsT38_TCP_Present, bT38_TCP_Pref, 
#endif	
	pxCodecs);
	/* Add the DTMF to the bottom of the List*/
	IFX_CMGR_AddDtmfToCodecList(pxCodecs,ucDynPt);			

/* FIX_2833 : To bring 2833 Codec ahead of T38 codec */
	if(ucDynPt){
		int i=0, insPos =0;
		for(i=0; i<pxCodecs->unNoOfCodecs; i++){
    	if(pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP || 
        pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP){
     insPos = i;
		}
  }
		
 		if(insPos != 0) {
    	IFX_CMGR_InsertCodecAtPos(pxCodecs,pxCodecs->unNoOfCodecs-1,insPos);
   	}
 }



	/*If the party is Extn then*/	
	if(pxMmgrInt)
	{
		/* Clear the currently running codecs on the internal side as well*/
		memset(pxIntCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
		/* Generate the new negotiated list on the extn*/
		IFX_CMGR_ConvertToNA_Codecs(pxMmgrInt, 
#ifdef FAX_SUPPORT
			IFX_FALSE, IFX_FALSE, IFX_FALSE, 
#endif	
			pxIntCodecs);
	}
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_FreeMediaResource 
 *  Description 	: Function invokes ResFree to free a media resource
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_FreeMediaResource(
									IN int32 iResId,
									IN char8* szFrom,
									IN char8* szTo,
									OUT e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Pass the right params into the MMGR FreeResourceForCall API*/
	eMmgrRet = IFX_MMGR_ResFreeForCall(iResId,szFrom,szTo);
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetCodecsForIncVoipCall 
 *  Description 	: Function selects the right kind of codecs for an inc voip
 *  					  call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : pointer to x_IFX_CMGR_CodecParams 
 *  Notes           :
 ****************************************************************************/
STATIC x_IFX_CMGR_CodecParams* IFX_CMGR_GetCodecsForIncVoipCall(
					 				IN x_IFX_CMGR_CallLeg *pxLeg)
{
	x_IFX_CMGR_CodecParams *pxCodecs = NULL;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
			 &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Check if the offer received status is set then that means that the
	 * codecs in the Negotiated codecs in the List are the ones to be taken*/
	if(IFX_CMGR_OFFER_RXD == pxLegInfo->eNegStatus)
	{
		pxCodecs = &pxLegInfo->xNegCodecInfo;
	}else
	if(IFX_CMGR_OFFER_SENT == pxLegInfo->eNegStatus)
	{
		pxCodecs = &pxLegInfo->xOfferedCodecInfo;
	}
	return pxCodecs;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetMediaResVoipInt 
 *  Description 	: Function reserves media resources for Voip to Internal call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetMediaResVoipInt(
					 				OUT int32* piResId,
					 				IN x_IFX_CMGR_CallLeg *pxOut,
					 				IN x_IFX_CMGR_CallLeg *pxIn,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	x_IFX_CMGR_CodecParams *pxCodecs = NULL, *pxIntCodecs = NULL;
	e_IFX_MMGR_TypeOfCall eType = IFX_MMGR_CALL_VOIP_EXTN;
	x_IFX_MMGR_CodecList xMmgrCodecList;
	x_IFX_MMGR_CodecList xMmgrIntCodecList;
	boolean bIsT38_UDP_Present = IFX_FALSE;
	boolean bIsT38_TCP_Present = IFX_FALSE;
	boolean bT38_TCP_Pref = IFX_FALSE;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
			 &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	uchar8 ucDynPt = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	memset(&xMmgrCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	memset(&xMmgrIntCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	
	if(IFX_CMGR_TYPE_FXO == pxIn->xLegOwnerInfo.eOwnerType)
		eType = IFX_MMGR_CALL_VOIP_FXO;
	else
	{	/*Its an extension party - Check for Codecs in the Offered List*/
		pxIntCodecs = 
			&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;
		if(pxIntCodecs->unNoOfCodecs)	
		{	/* Convert to the MMGR Format*/
			IFX_CMGR_ConvertToMMGR_Codecs(pxIntCodecs, &xMmgrIntCodecList);	
		}
	}
	
	/* Get codecs from the Voip leg*/
	pxCodecs = 	IFX_CMGR_GetCodecsForIncVoipCall(pxOut);
	if(!pxCodecs)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /*DEBUG*/
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Payload Type in the neg codec list",pxCodecs->axCodec[0].ucDynPT);
	}
	/* Search if any DTMF was present in the list*/
	IFX_CMGR_SearchForDtmf(pxCodecs, &ucDynPt);
#ifdef FAX_SUPPORT
	/*Find if any Fax related stuff is present and give its order */
	IFX_CMGR_SearchForT38(pxCodecs, &bIsT38_UDP_Present, 
						 				&bIsT38_TCP_Present, &bT38_TCP_Pref);	
#endif	
	/* Call Function to do Voip codec conversion*/
	IFX_CMGR_ConvertToMMGR_Codecs(pxCodecs, &xMmgrCodecList);	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
   "Payload Type in the neg codec list to MMGR",xMmgrCodecList.axCodecs[0].ucIANA_PayloadType);
	/* Pass the right params into the MMGR ReserveResourceForCall API*/
	eMmgrRet = IFX_MMGR_ResReserveForCall(piResId,NULL,IFX_FALSE,
		pxOut->xLegOwnerInfo.szEndptId,pxIn->xLegOwnerInfo.szEndptId, eType,
		&xMmgrCodecList,&xMmgrIntCodecList);
#if 1 //MFTD Enable not to be done here. It can cause issues during forking.
	/* Enable FAX tone detection*/	
	if(IFX_MMGR_MftdEnable(*piResId, IFX_TRUE))
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
											IFX_DBG_STR, "MFTD Enable Failed");
	}
#endif
	/* Clear the currently running codecs*/
	memset(pxCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
	/* Generate the new negotiated list*/
	IFX_CMGR_ConvertToNA_Codecs(&xMmgrCodecList, 
#ifdef FAX_SUPPORT
		bIsT38_UDP_Present, bIsT38_TCP_Present, bT38_TCP_Pref, 
#endif	
	pxCodecs);	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Payload Type in the neg codec list after MMGR",pxCodecs->axCodec[0].ucDynPT);
	/* Add the DTMF to the bottom of the List*/
	IFX_CMGR_AddDtmfToCodecList(pxCodecs,ucDynPt);

/* FIX_2833 : To bring 2833 Codec ahead of T38 codec */
//Bring DTMF ahead of T38 codec
	if(ucDynPt){
		int i=0, insPos =0;
		for(i=0; i<pxCodecs->unNoOfCodecs; i++){
    	if(pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP || 
        pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP){
     insPos = i;
		}
  }
/*FIX_2833 end*/		
 		if(insPos != 0) {
    	IFX_CMGR_InsertCodecAtPos(pxCodecs,pxCodecs->unNoOfCodecs-1,insPos);
   	}
 }

	/*Convert Internal codecs*/
	if(pxIntCodecs)
	{
		memset(pxIntCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
		/* Generate the new negotiated list*/
		IFX_CMGR_ConvertToNA_Codecs(&xMmgrIntCodecList,  
#ifdef FAX_SUPPORT
		IFX_FALSE, IFX_FALSE, IFX_FALSE, 
#endif	
		pxIntCodecs);	
	}
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);

	/* Before responding, make sure that the Offered and the Negotiated are the
	 * same, in case an offer was received from Voip*/
	if(IFX_CMGR_OFFER_RXD == 
				pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.eNegStatus)
	{
		memset(&pxLegInfo->xOfferedCodecInfo,0, sizeof(x_IFX_CMGR_CodecParams));
		memcpy(&pxLegInfo->xOfferedCodecInfo, 
							 pxCodecs, sizeof(x_IFX_CMGR_CodecParams));	
	}
	
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetMediaResIntVoip 
 *  Description 	: Function reserves media resources for Internal call to Voip
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetMediaResIntVoip(
					 				OUT int32* piResId,
					 				IN x_IFX_CMGR_CallLeg *pxOut,
					 				IN x_IFX_CMGR_CallLeg *pxIn,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet;
	e_IFX_MMGR_TypeOfCall eType = IFX_MMGR_CALL_EXTN_VOIP;
	x_IFX_MMGR_CodecList xMmgrCodecList,xMmgrIntCodecList;
	e_IFX_EndptType eEndptType;
#ifdef FAX_SUPPORT
	boolean bIsT38_UDP_Present = IFX_FALSE;
	boolean bIsT38_TCP_Present = IFX_FALSE;
	boolean bT38_TCP_Pref = IFX_FALSE;
#endif
	uchar8 ucDynPt = 0;
	x_IFX_CMGR_CodecParams *pxIntCodecs = NULL;
	x_IFX_CMGR_ExtnLegInfo *pxIntLegInfo = 
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
	x_IFX_CMGR_CodecParams *pxCodecs = 
		&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xOfferedCodecInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/* Zero the MMGR codecs*/
	memset(&xMmgrCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	memset(&xMmgrIntCodecList,0,sizeof(x_IFX_MMGR_CodecList));

	/* Check if there are any negotiated codecs in the Negotiated list - 
	 * only is its extn*/
	if((IFX_CMGR_TYPE_EXTN == pxOut->xLegOwnerInfo.eOwnerType) &&
		(pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo.unNoOfCodecs))
	{
		pxIntCodecs =
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;
		/* Call Function to do codec conversion */
		IFX_CMGR_ConvertToMMGR_Codecs(pxIntCodecs, &xMmgrIntCodecList);	
	}
	
	if(IFX_CMGR_TYPE_FXO == pxOut->xLegOwnerInfo.eOwnerType)
			eType = IFX_MMGR_CALL_FXO_VOIP;
	
#ifdef FAX_SUPPORT
	/*Find if any Fax related stuff is present and get its order */
	IFX_CMGR_SearchForT38(pxCodecs, &bIsT38_UDP_Present, 
						 				&bIsT38_TCP_Present, &bT38_TCP_Pref);
#endif	
	/* Search For DTMF*/
	IFX_CMGR_SearchForDtmf(pxCodecs, &ucDynPt);
	/* Call Function to do codec conversion */
	IFX_CMGR_ConvertToMMGR_Codecs(pxCodecs, &xMmgrCodecList);	
	
	/* Pass the right params into the MMGR ReserveResourceForCall API*/
	eMmgrRet = IFX_MMGR_ResReserveForCall(piResId,NULL,IFX_FALSE,
		pxOut->xLegOwnerInfo.szEndptId,pxIn->xLegOwnerInfo.szEndptId, eType,
		&xMmgrIntCodecList, &xMmgrCodecList);
/*CoC Power savings changes - STARTS*/
#if 1
	/*Enabling Multi Freq Tone Detector */
	eRet = IFX_CIF_EndptTypeGet(pxOut->xLegOwnerInfo.szEndptId,
                &eEndptType,peReason);
  if(IFX_EP_DECT != eEndptType){

		if(IFX_MMGR_MftdEnable(*piResId, IFX_TRUE)){
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
																		IFX_DBG_STR, "MFTD Enable Failed");
		} 
	}
#endif
/*END*/
	/* Clear the currently running codecs*/
	memset(pxCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
	/* Generate the new negotiated list*/
	IFX_CMGR_ConvertToNA_Codecs(&xMmgrCodecList, 
#ifdef FAX_SUPPORT
		bIsT38_UDP_Present, bIsT38_TCP_Present, bT38_TCP_Pref, 
#endif	
		pxCodecs);
	/* Add the DTMF to the bottom of the List*/
	IFX_CMGR_AddDtmfToCodecList(pxCodecs,ucDynPt); 
/* FIX_2833 : To bring 2833 Codec ahead of T38 codec */

	if(ucDynPt){
		int i=0, insPos =0;
		for(i=0; i<pxCodecs->unNoOfCodecs; i++){
    	if(pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP || 
        pxCodecs->axCodec[i].uiCodec == IFX_T38_UDP){
     insPos = i;
		}
  }
		
 		if(insPos != 0) {
    	IFX_CMGR_InsertCodecAtPos(pxCodecs,pxCodecs->unNoOfCodecs-1,insPos);
   	}
 }
/*FIX_2833 end*/
	/* Check for codecs on the internal side*/
	if(pxIntCodecs)
	{
		memset(pxIntCodecs, 0, sizeof(x_IFX_CMGR_CodecParams));
		IFX_CMGR_ConvertToNA_Codecs(&xMmgrIntCodecList,
#ifdef FAX_SUPPORT
		IFX_FALSE, IFX_FALSE, IFX_FALSE, 
#endif	
		pxIntCodecs);
		/* Make the Offered an Negotiated codecs same on the DECT side*/
		memset(&pxIntLegInfo->xOfferedCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
		memcpy(&pxIntLegInfo->xOfferedCodecInfo, 
							 pxIntCodecs, sizeof(x_IFX_CMGR_CodecParams));	
	}
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_GetMediaResIntInt 
 *  Description 	: Function reserves media resources for Internal 
 *  					  to Internal call
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetMediaResIntInt(
					 				OUT int32* piResId,
					 				IN x_IFX_CMGR_CallLeg *pxOut,
					 				IN x_IFX_CMGR_CallLeg *pxIn,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_MMGR_Return  eMmgrRet = IFX_SUCCESS;
	e_IFX_MMGR_TypeOfCall eType = IFX_MMGR_CALL_EXTN_EXTN;
	x_IFX_CMGR_CodecParams* pxInCodecs = 
				&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;
	x_IFX_CMGR_CodecParams* pxOutCodecs =
				&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;
	x_IFX_MMGR_CodecList xOutMmgrCodec, *pxOutMmgrCodec;
	x_IFX_MMGR_CodecList xInMmgrCodec, *pxInMmgrCodec;

	pxInMmgrCodec=&xInMmgrCodec;	
	pxOutMmgrCodec=&xOutMmgrCodec;	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
#if 0
return IFX_SUCCESS;
#endif
	if(IFX_CMGR_TYPE_EXTN == pxIn->xLegOwnerInfo.eOwnerType)
	{
		if(IFX_CMGR_TYPE_FXO == pxOut->xLegOwnerInfo.eOwnerType)
		{
			eType = IFX_MMGR_CALL_FXO_EXTN;
			/* FXO Cannot have codecs - hence NULL them*/
			pxOutCodecs = NULL;
		}
	}else
	if(IFX_CMGR_TYPE_FXO == pxIn->xLegOwnerInfo.eOwnerType)
	{
		if(IFX_CMGR_TYPE_EXTN == pxOut->xLegOwnerInfo.eOwnerType)
		{
			eType = IFX_MMGR_CALL_EXTN_FXO;
			/* FXO Cannot have codecs - hence NULL them*/
			pxInCodecs = NULL;
		}
	}

	/*Convert the codecs into MMGR redable form*/
	if(IFX_FAILURE == IFX_CMGR_ConvertToMMGR_Codecs(pxOutCodecs, pxOutMmgrCodec))
	{
		pxOutMmgrCodec = NULL;
	}	
	if(IFX_FAILURE == IFX_CMGR_ConvertToMMGR_Codecs(pxInCodecs, pxInMmgrCodec))
	{
		pxInMmgrCodec = NULL;
	}	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Invoke MMGR ResReserveForCall");
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
             "<FROM>Endpoint ID ",pxOut->xLegOwnerInfo.szEndptId);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
             "<TO>Endpoint ID ",pxIn->xLegOwnerInfo.szEndptId);
	#ifdef CVOIP_SUPPORT 
	if(atoi(pxIn->xLegOwnerInfo.szEndptId) >= 7 || atoi(pxOut->xLegOwnerInfo.szEndptId) >= 7){
		printf(" $$$$$ CVoIP Trying to Allocate Resource for FXS....\n");
	#endif
	eMmgrRet = IFX_MMGR_ResReserveForCall(piResId,NULL,IFX_FALSE,
			pxOut->xLegOwnerInfo.szEndptId,pxIn->xLegOwnerInfo.szEndptId,
		eType, pxOutMmgrCodec, pxInMmgrCodec);
	printf("CMGR-CV Resfd retunrde by MM %d\n",*piResId);
	/*Save the returned codec list into the Call Leg(s)*/
	if(pxOutMmgrCodec)
	{
		memset(pxOutCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
		memset(&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo,
										0,sizeof(x_IFX_CMGR_CodecParams));
		/* Generate the new negotiated list*/
		IFX_CMGR_ConvertToNA_Codecs(pxOutMmgrCodec, 
#ifdef FAX_SUPPORT
			IFX_FALSE, IFX_FALSE, IFX_FALSE, 
#endif	
			pxOutCodecs);
		/* Copy the same set of codecs into the offered list*/	
		memcpy(&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo,
										pxOutCodecs, sizeof(x_IFX_CMGR_CodecParams));
	}
	if(pxInMmgrCodec)
	{
		memset(pxInCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
		/* Generate the new negotiated list*/
		IFX_CMGR_ConvertToNA_Codecs(pxInMmgrCodec, 
#ifdef FAX_SUPPORT
			IFX_FALSE, IFX_FALSE, IFX_FALSE, 
#endif	
			pxInCodecs);
	}
	#ifdef CVOIP_SUPPORT
		}
	#endif
	
	/*Convert Return Types*/
	eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
		  
/********************** MMGR Wrapper functions End*******************************/

/*****************************************************************************
 *  Function Name	: IFX_CMGR_DoesRtpDiffer 
 *  Description 	: Function determines if two RTP params differ?
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE 
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_DoesRtpDiffer(
								 		IN x_IFX_CMGR_RtpParams* pxRtp1,
								 		IN x_IFX_CMGR_RtpParams* pxRtp2
					 					)
{
	boolean bRet = IFX_FALSE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	if(
	( pxRtp1->uiRemoteRtpPort != pxRtp2->uiRemoteRtpPort) ||
	( pxRtp1->uiRemoteRtcpPort != pxRtp2->uiRemoteRtcpPort) ||
	(strcasecmp((char8 *)pxRtp1->szRemoteRtpIpAddr,(char8 *)pxRtp2->szRemoteRtpIpAddr)) ||
	(strcasecmp((char8 *)pxRtp2->szRemoteRtcpIpAddr,(char8 *)pxRtp2->szRemoteRtcpIpAddr))
	)
		bRet = IFX_TRUE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Exit");
	return bRet;
}

/*****************************************************************************
 *  Function Name	: IFX_CMGR_IsMediaPresent 
 *  Description 	: Function determines if an incoming media request/response
 *  					  carries remote RTP params.
 *  Output Values  : 
 *  Input Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE 
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsMediaPresent(IN x_IFX_CMGR_RtpParams* pxRtp 
#ifdef FAX_SUPPORT
								,
								IN x_IFX_CMGR_FaxParams* pxFaxArr,
								IN uint16 unFaxArrSz
#endif
								)
{
	boolean bRet = IFX_FALSE;
	boolean abFaxFlags[IFX_MAX_FAX_PROTO] = {IFX_FALSE, IFX_FALSE};
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(pxRtp)	
		if(pxRtp->uiRemoteRtpPort)
			if(pxRtp->uiRemoteRtcpPort)
				if(strlen((char8 *)pxRtp->szRemoteRtpIpAddr))
					if(strlen((char8 *)pxRtp->szRemoteRtcpIpAddr))
							  bRet = IFX_TRUE;

	if(IFX_FALSE == bRet)
	{
#ifdef FAX_SUPPORT
		uint16 i=0;
		if(!unFaxArrSz)
			return bRet;
		for(i=0;i<unFaxArrSz;i++)
		{
			if(pxFaxArr[i].uiRemoteFaxPort)
				if(strcasecmp((char8 *)pxFaxArr[i].szRemoteFaxIpAddr,""))
					abFaxFlags[i] = IFX_TRUE;
		}

		if((IFX_TRUE == abFaxFlags[0]) || (IFX_TRUE == abFaxFlags[1]))
		{
			bRet = IFX_TRUE; 
		}
#endif
	}	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Exit");
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeGetMediaParams 
 *  Description     : Invokes CB pfnGetMediaParams
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeGetMediaParams
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		OUT x_IFX_CMGR_MediaParams* pxMedia
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Invoke pfnGetMediaParams*/
	if(pxLeg->pxCallBackList->pfnGetMediaParams)
		eRet = pxLeg->pxCallBackList->pfnGetMediaParams(pxLeg->uiCallId,
									pxMedia, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeMediaNegReq
 *  Description     : Invokes CB pfnMediaNegReq
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeMediaNegReq
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		OUT x_IFX_CMGR_MediaParams* pxMedia,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Invoke pfnGetMediaParams*/
	if(pxLeg->pxCallBackList->pfnMediaNegReq)
		eRet = pxLeg->pxCallBackList->pfnMediaNegReq(pxLeg->uiCallId,
									pxMedia,peStatus,peReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeMediaNegRsp 
 *  Description     : Invokes CB pfnMediaNegRsp
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeMediaNegRsp
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		IN x_IFX_CMGR_MediaParams* pxMedia,
								 		IN e_IFX_CMGR_Status eStatus,
										IN e_IFX_ReasonCode eReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/* Invoke pfnGetMediaParams*/
	if(pxLeg->pxCallBackList->pfnMediaNegRsp)
		eRet = pxLeg->pxCallBackList->pfnMediaNegRsp(pxLeg->uiCallId,
									pxMedia,&eStatus,&eReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeRemoteCallHold
 *  Description     : Invokes CB pfnRemoteCallHold
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeRemoteCallHold
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Invoke pfnRemoteCallHold*/
	eRet = pxLeg->pxCallBackList->pfnRemoteCallHold(pxLeg->uiCallId,
									peStatus, peReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeRemoteCallResume
 *  Description     : Invokes CB pfnRemoteCallResume
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeRemoteCallResume
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Invoke pfnRemoteCallHold*/
	eRet = pxLeg->pxCallBackList->pfnRemoteCallResume(pxLeg->uiCallId,
									peStatus, peReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallResumeRsp
 *  Description     : Invokes CB pfnCallResumeRsp
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallResumeRsp
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		IN e_IFX_CMGR_Status eStatus,
										IN e_IFX_ReasonCode eReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Invoke pfnRemoteCallHold*/
	eRet = pxLeg->pxCallBackList->pfnCallResumeRsp(pxLeg->uiCallId,
									eStatus, eReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallHoldRsp
 *  Description     : Invokes CB pfnCallHoldRsp
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallHoldRsp
									(
										IN x_IFX_CMGR_CallLeg* pxLeg,
								 		IN e_IFX_CMGR_Status eStatus,
										IN e_IFX_ReasonCode eReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Invoke pfnRemoteCallHold*/
	eRet = pxLeg->pxCallBackList->pfnCallHoldRsp(pxLeg->uiCallId,
									eStatus, eReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_DoExtnNegInTxAns
 *  Description     : Function does EXTN side negotiation if needed, in case of
 											an Voip_int_voip (ATx/Btx) or btx_int_int_voip scenario.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_DoExtnNegInTxAns(
																			 IN x_IFX_CMGR_CallLeg* pxPeer,
																			 IN x_IFX_CMGR_CodecParams* pxPeerNegCod,
																			 OUT e_IFX_CMGR_Status* peStatus,
																			 OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CodecParams* pxSendCodecs = NULL;
	x_IFX_CMGR_MediaParams xSendMedia;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxPeer);
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = 
					&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
					
	/*To find if Negotiation with the EXTN side is needed or not*/
	if((IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType) && 
			(pxExtnLegInfo->xNegCodecInfo.unNoOfCodecs > 0))
	{
		/*Copy Neg Codecs into the TEMP list*/	
		memcpy(&pxExtnLegInfo->xTempCodecInfo,&pxExtnLegInfo->xNegCodecInfo,
				sizeof(x_IFX_CMGR_CodecParams));
		/*Copy codecs from Local save to Neg List */
		memcpy(&pxExtnLegInfo->xNegCodecInfo,pxPeerNegCod,
																		sizeof(x_IFX_CMGR_CodecParams));
		
		/* Set the NO_PEER_NEG_RSP flag indicating that the other party
		 is not be informed of the response of this media request*/
		IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER);
	
		/*Set flag indicating the Media Neg Request in Progress*/
		IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
		
		memset(&xSendMedia,0,sizeof(x_IFX_CMGR_MediaParams));
		xSendMedia.eAgentType = IFX_CMGR_TYPE_EXTN;
		pxSendCodecs = &xSendMedia.uxMediaParams.xExtnMediaParams.xCodecParams;

		/* Copy Temp Codecs in the xSendMedia List*/
		memcpy(pxSendCodecs, 
			&pxExtnLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
		/*If the EXTN party is to be informed of the codec then 
		 invoke pfnMediaNegReq on the Peer with the temp codec list*/
		IFX_CMGR_InvokeMediaNegReq(pxPeer,&xSendMedia,peStatus,peReason);
		if(IFX_CMGR_STATUS_SUCCESS == *peStatus)
		{
			memcpy(&pxExtnLegInfo->xNegCodecInfo,
							&pxExtnLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
		}
		if(IFX_CMGR_STATUS_PENDING != *peStatus)
		{
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER);
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
			memset(&pxExtnLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
		}
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Negotiation Needed");
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallIncVoipFxo
 *  Description     : Invokes CB pfnCallIncoming for a Voip to Fxo call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallIncVoipFxo
									(
										IN x_IFX_CMGR_CallLeg* pxOut,
										IN x_IFX_CMGR_CallLeg* pxIn,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xFrom, xTo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xFrom.uxAddressInfo.xVoipAddr, 
				&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr, 
				sizeof(x_IFX_CMGR_CodecParams));

	/*	Form the pxTo*/
	memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xTo.eAddressType = IFX_CMGR_TYPE_FXO;


	strcpy(xTo.uxAddressInfo.xFxoInfo.szFxoLineId, /* Copy FXO EID*/ 
						 						pxIn->xLegOwnerInfo.szEndptId);
	if(strlen(pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szPhoneNumber))
	{
		strcpy(xTo.uxAddressInfo.xFxoInfo.szPhoneNumber, /* Copy PSTN number*/ 
							pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szPhoneNumber);
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
    	"Phone num to FXO ", pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo.szPhoneNumber);
	}
	else
	{
		strcpy(xTo.uxAddressInfo.xFxoInfo.szPhoneNumber,"");
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Phone number");
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Called Party: ",pxIn->uiCallId);
	/* Invoke pfnCallIncoming*/
	eRet = pxIn->pxCallBackList->pfnCallIncoming(pxIn->uiCallId,
						 &xFrom,&xTo,pxPar,peStatus,peReason,&pxIn->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallIncExtnFxo
 *  Description     : Invokes CB pfnCallIncoming for a Extn to Fxo call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallIncExtnFxo
									(
										IN x_IFX_CMGR_CallLeg* pxOut,
										IN x_IFX_CMGR_CallLeg* pxIn,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xFrom, xTo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_EXTN;
	strcpy(xFrom.uxAddressInfo.szEndptId, pxOut->xLegOwnerInfo.szEndptId);
	
	/*	From the pxTo*/
	memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xTo.eAddressType = IFX_CMGR_TYPE_FXO;
	
	memcpy(&xTo.uxAddressInfo.xFxoInfo,
		&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
		sizeof(x_IFX_CMGR_FxoInfo)); /* Copy the phone number etc.*/
	
	strcpy(xTo.uxAddressInfo.xFxoInfo.szFxoLineId, /* Copy FXO EID*/ 
						 						pxIn->xLegOwnerInfo.szEndptId);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Called Party: ",pxIn->uiCallId);
	/* Invoke pfnCallIncoming*/
	eRet = pxIn->pxCallBackList->pfnCallIncoming(pxIn->uiCallId,
						 &xFrom,&xTo,pxPar,peStatus,peReason,&pxIn->pvPrivateData);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallIncVoipExtn
 *  Description     : Invokes CB pfnCallIncoming for a Voip to Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallIncVoipExtn
									(
										IN x_IFX_CMGR_CallLeg* pxOut,
										IN x_IFX_CMGR_CallLeg* pxIn,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xFrom, xTo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xFrom.uxAddressInfo.xVoipAddr, 
				&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr, 
				sizeof(x_IFX_CMGR_CodecParams));

	/*	From the pxTo*/
	memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
	strcpy(xTo.uxAddressInfo.szEndptId, pxIn->xLegOwnerInfo.szEndptId);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Called Party: ",pxIn->uiCallId);
	/* Invoke pfnCallIncoming*/
  /* To give line Information to DECT agent */
  xTo.ucLineId = pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Line ID: ",xTo.ucLineId);
	eRet = pxIn->pxCallBackList->pfnCallIncoming(pxIn->uiCallId,
						 &xFrom,&xTo,pxPar,peStatus,peReason,&pxIn->pvPrivateData);
	
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallIncFxoExtn
 *  Description     : Invokes CB pfnCallIncoming for a Fxo to Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallIncFxoExtn
									(
										IN x_IFX_CMGR_CallLeg* pxOut,
										IN x_IFX_CMGR_CallLeg* pxIn,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xFrom, xTo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,__FILE__);

	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_FXO;
	memcpy(&xFrom.uxAddressInfo.xFxoInfo,
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
		sizeof(x_IFX_CMGR_FxoInfo)); /* Copy the phone number etc.*/
	strcpy(xFrom.uxAddressInfo.xFxoInfo.szFxoLineId, /* Copy FXO EID*/ 
						 						pxOut->xLegOwnerInfo.szEndptId);
	/*	Form the pxTo*/
	memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
	strcpy(xTo.uxAddressInfo.szEndptId, pxIn->xLegOwnerInfo.szEndptId);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Called Party: ",pxIn->uiCallId);

	eRet = pxIn->pxCallBackList->pfnCallIncoming(pxIn->uiCallId,
							 &xFrom,&xTo,pxPar,peStatus,peReason,&pxIn->pvPrivateData);

	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallIncIntVoip
 *  Description     : Invokes CB pfnCallIncoming for a Internal to Voip Call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallIncIntVoip
									(
										IN x_IFX_CMGR_CallLeg* pxOut,
										IN x_IFX_CMGR_CallLeg* pxIn,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xFrom, xTo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xFrom.uxAddressInfo.xVoipAddr, 
				&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr,
					sizeof(x_IFX_CMGR_VoipAddr));
	
	/*	From the pxTo*/
	memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xTo.uxAddressInfo.xVoipAddr, 
				&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr,
					sizeof(x_IFX_CMGR_VoipAddr));
		
	/*Save the pxPar in the In CL*/
	memcpy(&pxIn->xCallParams, pxPar, sizeof(x_IFX_CMGR_CallParams));
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Called Party: ",pxIn->uiCallId);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
  	"Codecs to NA: ",pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams.unNoOfCodecs);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
  	"Codec 0: ",pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams.axCodec[0].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
  	"Codec 1: ",pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams.axCodec[1].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
  	"Codec 2: ",pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams.axCodec[2].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
  	"Codec 0 Dyn PT: ",pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams.axCodec[2].ucDynPT);
	/* Invoke pfnCallIncoming*/
	eRet = pxIn->pxCallBackList->pfnCallIncoming(pxIn->uiCallId,
						 &xFrom,&xTo,pxPar,peStatus,peReason,&pxIn->pvPrivateData);
	
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeCallIncExtnExtn
 *  Description     : Invokes CB pfnCallIncoming for a Extn to Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeCallIncExtnExtn
									(
										IN x_IFX_CMGR_CallLeg* pxOut,
										IN x_IFX_CMGR_CallLeg* pxIn,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_AddressInfo xFrom, xTo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_EXTN;
	strcpy(xFrom.uxAddressInfo.szEndptId, pxOut->xLegOwnerInfo.szEndptId);
	
	/*	From the pxTo*/
	memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
	strcpy(xTo.uxAddressInfo.szEndptId, pxIn->xLegOwnerInfo.szEndptId);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Called Party: ",pxIn->uiCallId);
	printf("\nIFX_CMGR_InvokeCallIncExtnExtn Calling the Callback ... \n");
	/* Invoke pfnCallIncoming*/
	eRet = pxIn->pxCallBackList->pfnCallIncoming(pxIn->uiCallId,
						 &xFrom,&xTo,pxPar,peStatus,peReason,&pxIn->pvPrivateData);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/********************** Make Call  functions Start*****************************/

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeCallVoipExtn
 *  Description     : Makes Call from a Voip to an Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallVoipExtn
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = /*Voip Leg owner Info*/
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		  
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;
	x_IFX_CMGR_CallParams xInPar;
	uint8 ucNumLegs = pxCnxt->ucNumCallLegs;
	uint8 i;
	int32 iIdx = 0;
	boolean bOutClMpcWb = IFX_FALSE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/*Check and set flag for WB negotiation*/
	bOutClMpcWb = IFX_CMGR_IsMPC_WB(&pxVoipLegInfo->xNegCodecInfo);
	
	/*Change state of the OUT CL to SRP Invite*/
	IFX_CMGR_ChangeState(pxOut,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
	
	/*Repeat action for all the IN CLs*/
	for(i=1;(i<ucNumLegs) && i<(IFX_CMGR_MAX_LEGS_PER_CNXT) 
				&& (pxCnxt->pxCallLegs[i]);i++)
	{
	if (IFX_CMGR_GET_FLAG(pxCnxt->unSSCallFlag,IFX_CMGR_DEFLECTION_IN_PROGRESS)){
		if (i != ucNumLegs -1)
			continue;
	}

		pxExtnLegInfo = 
			&pxCnxt->pxCallLegs[i]->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		  
		/*Allocate the required resources for the call using MMGR*/	
		eRet = IFX_CMGR_GetMediaResVoipInt(&pxCnxt->iResId,pxOut,
							 		pxCnxt->pxCallLegs[i],peStatus, peReason);

		/*Check for WB related negotiations*/
		if(IFX_FALSE == bOutClMpcWb)
		{
			eRet = IFX_CMGR_ReOrderCodecsForWB(&pxVoipLegInfo->xNegCodecInfo,
						&pxExtnLegInfo->xOfferedCodecInfo, IFX_TRUE);	
			/*If the MPC is already G.722 or WB then set flag*/	
			bOutClMpcWb = IFX_CMGR_IsMPC_WB(&pxVoipLegInfo->xNegCodecInfo);
		}
		else
		{
			/*Since the OUT Voip CL's MPC is already a WB codec, Re-Order just the
			 Extn codecs*/
			IFX_CMGR_SearchForCodec(
				&pxExtnLegInfo->xOfferedCodecInfo,IFX_G722_64,&iIdx);
			if(-1 != iIdx)
			{
				/*Codec found - Re-Order to move it to pos of MPC i.e. 0*/
				IFX_CMGR_InsertCodecAtPos(&pxExtnLegInfo->xOfferedCodecInfo,iIdx,0);
			}
		}
		
#ifdef FAX_SUPPORT
		/* Check if the MPC is a T.38 codec.*/
		if(IFX_TRUE == IFX_CMGR_IsPrefCodecT38(&pxVoipLegInfo->xNegCodecInfo))
		{
			/* Its going to be a FAX call. Set the Flag to indicate that FAX
			 has to be started insted of RTP*/
			IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_ENABLE_FAX);
		}
		else
		{
			/* Reset flag if its not a FAX call*/
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_ENABLE_FAX);
		}
#endif
		
		/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
		memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
		eRet = IFX_CMGR_MakeCallParamsVoipExtn(
					pxCnxt->pxCallLegs[i],pxPar,&xInPar,peReason);

		/* change the state of IN CL to RRP (Invite)*/
		IFX_CMGR_ChangeState(pxCnxt->pxCallLegs[i],
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
		/*Invoke the InvokeCallIncoming function on the IN CL*/
		eRet = 
			IFX_CMGR_InvokeCallIncVoipExtn(pxOut,
					pxCnxt->pxCallLegs[i],&xInPar,peStatus,peReason);
		if(IFX_FAILURE == eRet)
		{
			*peStatus = IFX_CMGR_STATUS_FAIL;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;/* DEBUG*/
		}
	
		/*Check if the return type is STATUS PENDING & Reason RINGING*/
		if((IFX_CMGR_STATUS_PENDING == *peStatus)&&
					(IFX_ENDPOINT_RINGING == *peReason))
		{
			/*Change state of the OUT CL to RINGBACK and the IN CL to RINGING*/	
			IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_RINGBACK,0);
			IFX_CMGR_ChangeState(pxCnxt->pxCallLegs[i],IFX_CMGR_STATE_RINGING,0);
		}
		/* If return type is Status Fail then Clear the call leg and change the
		 * Decrement the num call legs by one.*/
		if(IFX_CMGR_STATUS_FAIL == *peStatus)
		{
			/* Free its resource id given by the MMGR*/
			IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxOut->xLegOwnerInfo.szEndptId, 
				pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId, 
				peReason);
			IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[i]);
			pxCnxt->pxCallLegs[i] = NULL;
			--pxCnxt->ucNumCallLegs;
		}
	}

	/*Find the final status/reason to return*/
	if(pxCnxt->ucNumCallLegs>1)
	{
		/* This means that at-least one call leg is still active. */
		if(IFX_TRUE == IFX_CMGR_IsAnyInClRinging(pxCnxt))
		{
			/* Find the right status & reason to return from the status*/
			*peReason = IFX_ENDPOINT_RINGING;
		}
		*peStatus = IFX_CMGR_STATUS_PENDING;
	}
	else
	{	
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeCallFxoExtn
 *  Description     : Makes Call from a Fxo to an Extncall
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallFxoExtn
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg *pxOut = IFX_CMGR_GetOutCl(pxCnxt); 
	x_IFX_CMGR_CallParams xInPar;
	uint8 ucNumLegs = pxCnxt->ucNumCallLegs;
	uint8 i;
	x_IFX_CMGR_CodecParams *pxCodecs = NULL;
	x_IFX_CMGR_CallLeg* pxTemp;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/*Change state of the OUT CL to SRP Invite*/
	IFX_CMGR_ChangeState(pxOut,
			IFX_CMGR_SEND_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	/*Repeat action for all the IN CLs*/
	for(i=1;i<ucNumLegs && i < (IFX_CMGR_MAX_LEGS_PER_CNXT);i++)
	{
		/*Allocate the required resources for the call using MMGR*/	
		eRet = IFX_CMGR_GetMediaResIntInt(&pxCnxt->iResId,pxOut,
							 			pxCnxt->pxCallLegs[i],peStatus, peReason);
		if(IFX_FAILURE == eRet)
		{
			IFX_CMGR_DeAllocCallCnxt(pxCnxt);	
			*peStatus = IFX_CMGR_STATUS_FAIL;
			return eRet;/* DEBUG*/
		}
		/*Re-Order all EXTN parties with codecs to use NB*/
		pxCodecs = &pxCnxt->pxCallLegs[i]->
				xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;
		if(pxCodecs->unNoOfCodecs)
		{
			IFX_CMGR_ReOrderCodecsForWB(NULL,pxCodecs,IFX_FALSE);
		}
		/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
		memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
		eRet = IFX_CMGR_MakeCallParamsFxoExtn( 
							 pxCnxt->pxCallLegs[i],pxPar,&xInPar,peReason);
		if(IFX_FAILURE == eRet)
		{
			*peStatus = IFX_CMGR_STATUS_FAIL;
			return eRet;/* DEBUG*/
		}
		
		/* change the state of IN CL to RRP (Invite)*/
		IFX_CMGR_ChangeState(pxCnxt->pxCallLegs[i],
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
		/*Invoke the InvokeCallIncoming function on the IN CL*/
		eRet = IFX_CMGR_InvokeCallIncFxoExtn(pxOut, 
								 pxCnxt->pxCallLegs[i],&xInPar,peStatus,peReason);
		if(IFX_FAILURE == eRet)
		{
			*peStatus = IFX_CMGR_STATUS_FAIL;
			return eRet;/* DEBUG*/
		}
	
		/*Check if the return type is STATUS PENDING & Reason RINGING*/
		if((IFX_CMGR_STATUS_PENDING == *peStatus) &&
					(IFX_ENDPOINT_RINGING == *peReason))
		{
			/*Change state of the OUT CL to RINGBACK and the IN CL to RINGING*/	
			IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_RINGBACK,0);
			IFX_CMGR_ChangeState( pxCnxt->pxCallLegs[i],IFX_CMGR_STATE_RINGING,0);
		}
		/* If return type is Status Fail then Clear the call leg and change the
		 * Decrement the num call legs by one.*/
		if(IFX_CMGR_STATUS_FAIL == *peStatus)
		{
			/* Free its resource id given by the MMGR*/
			pxTemp =  pxCnxt->pxCallLegs[i];
			IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxOut->xLegOwnerInfo.szEndptId, pxTemp->xLegOwnerInfo.szEndptId
				, peReason);
			IFX_CMGR_DeAllocCallLeg(pxTemp);
			pxCnxt->pxCallLegs[i] = NULL;
			--pxCnxt->ucNumCallLegs;
		}
	}

	/*Find the final status/reason to return*/
	if(pxCnxt->ucNumCallLegs>1)
	{
		/* This means that at-least one call leg is still active. */
		/* Find the right status & reason to return from the status*/
		if(IFX_TRUE == IFX_CMGR_IsAnyInClRinging(pxCnxt))
		{
			*peReason = IFX_ENDPOINT_RINGING;
		}
		*peStatus = IFX_CMGR_STATUS_PENDING;
	}
	else
	{
		/* No IN CL is left - Clear all resources */
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeCallVoipFxo
 *  Description     : Makes Call from a Voip to an Fxo call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallVoipFxo
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg *pxOut = IFX_CMGR_GetOutCl(pxCnxt); 
	x_IFX_CMGR_CallLeg *pxIn = IFX_CMGR_GetInClStart(pxCnxt); 
	x_IFX_CMGR_CallParams xInPar;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/*Allocate the required resources for the call using MMGR*/	
	eRet = IFX_CMGR_GetMediaResVoipInt(&pxCnxt->iResId, pxOut,
						 							pxIn, peStatus, peReason);
	if((IFX_FAILURE == eRet) || (!pxCnxt->iResId))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}
	
	/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
	memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
	xInPar.eAgentType = IFX_CMGR_TYPE_FXO;

	/*Change state of the OUT CL to SRP Invite and the IN CL to RRP (Invite)*/
	IFX_CMGR_ChangeState(pxOut,
				IFX_CMGR_SEND_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	IFX_CMGR_ChangeState(pxIn,
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	/*Invoke the InvokeCallIncoming function on the IN CL*/
	eRet = 
		IFX_CMGR_InvokeCallIncVoipFxo(pxOut,pxIn,&xInPar,peStatus,peReason);
	if((IFX_CMGR_STATUS_FAIL == *peStatus) || (IFX_FAILURE == eRet))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);	
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}

	/*If status was SUCCESS the set the reason as ANSWERED*/
	if((IFX_CMGR_STATUS_SUCCESS == *peStatus)||
			(IFX_CMGR_STATE_CONV == pxOut->eCurrState))
	{
		x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = /*Voip Leg owner Info*/
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		  
		/* If the Neg Status is OFFER_SENT then it means that an empty SDP was
		 * received - SO both SDPs are not present. Skip Media Session Starting*/
		if(pxVoipLegInfo->eNegStatus != IFX_CMGR_OFFER_SENT)
		{
			/* Invoke Start Session*/
			eRet = IFX_CMGR_StartMediaSession(pxOut,pxCnxt->iResId, peReason);	  
		}
		/*Set Reason to answered*/
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		*peReason = IFX_CALL_ANSWERED;
		/*Change OUT and IN states to CONV*/
		IFX_CMGR_ChangeState(pxIn,IFX_CMGR_STATE_CONV,0);
		IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_CONV,0);
		/* Set Peer pointers*/
		IFX_CMGR_SetPeerPtr(pxIn,pxOut);	
		IFX_CMGR_SetPeerPtr(pxOut,pxIn);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeCallExtnFxo
 *  Description     : Makes Call from a Extn to an Fxo call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallExtnFxo
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg *pxOut = IFX_CMGR_GetOutCl(pxCnxt); 
	x_IFX_CMGR_CallLeg *pxIn = IFX_CMGR_GetInClStart(pxCnxt); 
	x_IFX_CMGR_CallParams xInPar;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Allocate the required resources for the call using MMGR*/	
	eRet = IFX_CMGR_GetMediaResIntInt(&pxCnxt->iResId, pxOut,
						 							pxIn, peStatus, peReason);
	if(IFX_FAILURE==eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_NO_RESOURCE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}

	/*If OUT party is with codecs, it needs to be switched to NB*/
	IFX_CMGR_ReOrderCodecsForWB(NULL,
		&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo,IFX_FALSE);
	
	/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
	memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
	eRet = IFX_CMGR_MakeCallParamsExtnFxo(pxIn,pxPar,&xInPar,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}
		
	/*Change state of the OUT CL to SRP Invite and the IN CL to RRP (Invite)*/
	IFX_CMGR_ChangeState(pxOut,
				IFX_CMGR_SEND_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	IFX_CMGR_ChangeState(pxIn,
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	/*Invoke the InvokeCallIncoming function on the IN CL*/
	eRet = 
		IFX_CMGR_InvokeCallIncExtnFxo(pxOut,pxIn,&xInPar,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}
	
	/* If the status returned was FAILURE then DeAllocate the Call Context*/
	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);	
	}

	/*If status was SUCCESS the set the reason as ANSWERED*/
	if((IFX_CMGR_STATUS_SUCCESS == *peStatus)||
			(pxOut->eCurrState == IFX_CMGR_STATE_CONV))
	{
		/*Set Reason to answered*/
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		*peReason = IFX_CALL_ANSWERED;
		/*Invoke MMGR to Establish Media Path Between Internal Parties*/
		eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_TRUE, IFX_TRUE ,peReason);
		/*Change OUT and IN states to CONV*/
		IFX_CMGR_ChangeState(pxIn,IFX_CMGR_STATE_CONV,0);
		IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_CONV,0);
		/* Set Peer pointers*/
		IFX_CMGR_SetPeerPtr(pxIn,pxOut);	
		IFX_CMGR_SetPeerPtr(pxOut,pxIn);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeCallIntVoip
 *  Description     : Makes Call from a Internal to an Voip call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallIntVoip
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg *pxOut = IFX_CMGR_GetOutCl(pxCnxt); 
  x_IFX_CMGR_CallLeg* pxIn = pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs-1];
  //x_IFX_CMGR_CallLeg *pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 
				&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	x_IFX_CMGR_CodecParams *pxCodecs = &pxLegInfo->xOfferedCodecInfo;
	x_IFX_CMGR_CodecParams* pxOutCodecs = 
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;		 
	x_IFX_CMGR_CodecParams* pxOutOffCodecs = 
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;		 
#ifdef FAX_SUPPORT
	x_IFX_CMGR_FaxParams *pxLocFaxPar = pxLegInfo->axFaxParams;
#endif
	x_IFX_CMGR_CallParams xInPar;
	boolean bT38Udp = IFX_FALSE;
	boolean bT38Tcp = IFX_FALSE;
	boolean bT38TcpPref = IFX_FALSE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/*Allocate the required resources for the call using MMGR*/	
	eRet = IFX_CMGR_GetMediaResIntVoip(&pxCnxt->iResId, pxOut, 
						 								pxIn, peStatus, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}	

	/* Codecs Rxd */

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After Res Reserve - Codec Num : ", pxCodecs->unNoOfCodecs);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After Res Reserve - Codec 0 : ", pxCodecs->axCodec[0].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After Res Reserve - Codec 1 : ", pxCodecs->axCodec[1].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After Res Reserve - Codec 2 : ", pxCodecs->axCodec[2].uiCodec);
	
#ifdef FAX_SUPPORT
	/*Check if T.38 UDP/TCP is in the offered codeclist. If no, then free the
	 port allocated for T.38 UDP/TCP */
	IFX_CMGR_FindT38andClear(pxCodecs, pxLocFaxPar, pxIn);
	/*If FAX T.38 TCP is a part of the offered codec list then start listening*/
	IFX_CMGR_SearchForT38(pxCodecs,&bT38Udp,&bT38Tcp,&bT38TcpPref);
	if(IFX_TRUE == bT38Tcp)
	{
		IFX_CMGR_InvokeFaxServerListen(pxIn, IFX_FALSE);
		/*Set flag to indicate that the Fax agent is waiting for incoming T.38 TCP*/
		IFX_CMGR_SET_FLAG(pxCnxt->unFlags,\
															 	IFX_CMGR_FLAG_WAITING_FOR_TCP_FAX);
	}
#endif

	/* Apply logic to re-order the DECT/VOIP codec based on WB/NB. This is 
	needed because due the MMGR load calucations one side might have become WB
	and other side NB, even though earlier they might both have been WB.*/
	/*Order Codecs for WB if needed*/
	eRet = IFX_CMGR_ReOrderCodecsForWB(pxOutCodecs,pxCodecs,IFX_TRUE);		
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After ReOrder - Codec Num : ", pxCodecs->unNoOfCodecs);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After ReOrder - Codec 0 : ", pxCodecs->axCodec[0].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After ReOrder - Codec 1 : ", pxCodecs->axCodec[1].uiCodec);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "After ReOrder - Codec 2 : ", pxCodecs->axCodec[2].uiCodec);
	/* Make the offered and Negotiated Codecs same so that the WB 
		 change is also reflected in this one*/
	if((pxOutCodecs->unNoOfCodecs) && 
			(IFX_CMGR_TYPE_EXTN == pxOut->xLegOwnerInfo.eOwnerType))
		memcpy(pxOutOffCodecs,pxOutCodecs,sizeof(x_IFX_CMGR_CodecParams));
	
	/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
	memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
	eRet = IFX_CMGR_MakeCallParamsIntVoip(pxIn,pxPar,&xInPar);
		
	/*Change state of the OUT CL to SRP Invite and the IN CL to RRP (Invite)*/
	IFX_CMGR_ChangeState(pxOut,
				IFX_CMGR_SEND_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	IFX_CMGR_ChangeState(pxIn,
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);

	/*Invoke the InvokeCallIncoming function on the IN CL*/
	eRet = 
		IFX_CMGR_InvokeCallIncIntVoip(pxOut,pxIn,&xInPar,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InsertCodecAtPos
 *  Description     : Positions the Given Codec from Old Position to New One
 *  Input Values    : pxCodecList,uiOldPos, uiNewPos
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InsertCodecAtPos(
								IN_OUT x_IFX_CMGR_CodecParams *pxCodecList,
								IN uint32 uiOldPos, IN uint32 uiNewPos
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 i = 0;
	x_IFX_Codec* pxCodec = NULL;
	x_IFX_Codec xCodec;
 	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	memset(&xCodec,0,sizeof(x_IFX_Codec));
	if((uiNewPos < 0) || (uiOldPos < 0) || (uiOldPos == uiNewPos))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
#if 0	
	if(pxCodecList->unNoOfCodecs < 2)
	{	/*Not enough codecs to reorder*/
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Change in Codec ordering");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
#endif
	/*Check boundary conditions*/
	if((uiOldPos > IFX_MAX_CODECS) || (uiNewPos > IFX_MAX_CODECS))
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
					
	/*Get a pointer to the codec*/
	pxCodec = &pxCodecList->axCodec[uiOldPos];
	/*Copy the codec info into a temp loc*/	
	memcpy(&xCodec,pxCodec,sizeof(x_IFX_Codec));	

	/* We need to shift the codec upwards*/
	if(uiOldPos > uiNewPos)
	{
		for(i=uiOldPos;i>uiNewPos;i--)
		{
			if (i < 0 || i > IFX_MAX_CODECS-1)
				return IFX_FAILURE;
			pxCodecList->axCodec[i] = pxCodecList->axCodec[i-1];
		}
	}
	else /* We need to shift the codec downwards*/
	{
		for(i=uiOldPos;i<uiNewPos;i++)
		{
			if (i > IFX_MAX_CODECS-2)
				return IFX_FAILURE;
			pxCodecList->axCodec[i] = pxCodecList->axCodec[i+1];
		}
	}
	/*Copy the Codec into new Pos*/
	memcpy(&pxCodecList->axCodec[uiNewPos],&xCodec,sizeof(x_IFX_Codec));
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MoveCodec
 *  Description     : This function Removes the codec from "FromCodec" list
					  and appends  to "ToCodec" list.
 *					  Function checks for boundary conditions but DOES NOT
					  return Fail/Success. 
 *  Input Values    : 
 *  Output Values	: 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/

void IFX_CMGR_MoveCodec(x_IFX_CMGR_CodecParams *pxToCodecs,
						x_IFX_CMGR_CodecParams *pxFromCodecs,
						int32 iFromLocation)
{
	if(0 > iFromLocation || iFromLocation >= IFX_MAX_CODECS ||
	   pxToCodecs->unNoOfCodecs >= IFX_MAX_CODECS-1 ||
	   pxFromCodecs->unNoOfCodecs >= IFX_MAX_CODECS) {	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		"Error!! Ordering of Codecs may be WRONG");
		return;
	}
	/*Insert codec in "To Codec list"*/
	memcpy(&pxToCodecs->axCodec[pxToCodecs->unNoOfCodecs],
		   &pxFromCodecs->axCodec[iFromLocation], sizeof(x_IFX_Codec));
	pxToCodecs->unNoOfCodecs++;

	/*Remove codec from "FromCodec" list*/
	if(iFromLocation != pxFromCodecs->unNoOfCodecs-1){
		if (iFromLocation > IFX_MAX_CODECS-2)
			return;
			memmove(&pxFromCodecs->axCodec[iFromLocation],
					&pxFromCodecs->axCodec[iFromLocation+1],
					sizeof(x_IFX_Codec)* (pxFromCodecs->unNoOfCodecs -iFromLocation -1) );
	}
	if (pxFromCodecs->unNoOfCodecs > 0){
		memset(&pxFromCodecs->axCodec[pxFromCodecs->unNoOfCodecs-1],0,sizeof(x_IFX_Codec));
		pxFromCodecs->unNoOfCodecs--;
	}
	return;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_StripNonVoiceCodecs
 *  Description     : This fucntion strips NonVoice codecs such as
					  2833, T38-TCP , T38-UDP and copies into another
					  codec list. It also PRESERVES the order of the 
					  codecs. 
					  It 2833 is usally the LAST codec in m line followed
					  by T38 codecs.
					  Currently only 2833 and T38 are identified as Non-vocie
					  codecs.
 *
 *  Input Values    : Does not return SUCCESS/FAIL.
 *  Output Values	: 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/
void IFX_CMGR_StripNonVoiceCodecs(IN_OUT x_IFX_CMGR_CodecParams *pxAllCodecs,
								  OUT x_IFX_CMGR_CodecParams *pxNonVoiceCodecs)

{
	int32 i2833Idx =-1,iFirstT38 = -1, iSecondT38 = -1;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	memset(pxNonVoiceCodecs,0,sizeof(x_IFX_CMGR_CodecParams));

	IFX_CMGR_SearchForCodec(pxAllCodecs,IFX_DIGIT_2833,&i2833Idx);
	if(i2833Idx != -1){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Removing 2833");
		IFX_CMGR_MoveCodec(pxNonVoiceCodecs,pxAllCodecs,i2833Idx);
	}

	/*Search for T38 TCP and UDP*/
	IFX_CMGR_SearchForCodec(pxAllCodecs,IFX_T38_UDP,&iFirstT38);
	IFX_CMGR_SearchForCodec(pxAllCodecs,IFX_T38_TCP,&iSecondT38);

	/*Check if both UDP and TCP are present then preserve the order*/
	if(iFirstT38 != -1 && iSecondT38 != -1) {
		if(iFirstT38 > iSecondT38){
			/*swap vaules*/	
			i2833Idx = iFirstT38;
			iFirstT38 = iSecondT38;
			iSecondT38 = i2833Idx;
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"UDP-TCP Pos swapped");
		}
	}

	/*Copy First T38 Codec - if present in stripped codec list*/
	if(iFirstT38 != -1) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Removing FirstT38");
		IFX_CMGR_MoveCodec(pxNonVoiceCodecs,pxAllCodecs,iFirstT38);
		iSecondT38--; //Decreament Second T38 Codec location
	}
	
	if(iSecondT38 > -1) { /*SecondT38 Might be decremented*/
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Removing SecondT38");
		IFX_CMGR_MoveCodec(pxNonVoiceCodecs,pxAllCodecs,iSecondT38);
		
	}

  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
  return;	
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_AppendCodecs
 *  Description     : This fucntion copies codec from "From List" to
					  "ToCodec" list
 *  Input Values    : Does not return SUCCESS/FAIL.
 *  Output Values	: 
 *  Return Value    : 
 *  Notes           :
 ****************************************************************************/

void IFX_CMGR_AppendCodecs(OUT x_IFX_CMGR_CodecParams *pxToCodecs,
						   IN x_IFX_CMGR_CodecParams *pxFromCodecs)
{
  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  if(!pxToCodecs || !pxFromCodecs) {
  	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid List");
	return;
  }
	  if(pxFromCodecs->unNoOfCodecs != 0 && pxFromCodecs->unNoOfCodecs < IFX_MAX_CODECS){
    memcpy(&pxToCodecs->axCodec[pxToCodecs->unNoOfCodecs],
		 &pxFromCodecs->axCodec[0],
		 sizeof(x_IFX_Codec)*(pxFromCodecs->unNoOfCodecs));

    pxToCodecs->unNoOfCodecs = pxFromCodecs->unNoOfCodecs + pxToCodecs->unNoOfCodecs;
  }
  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Exit: NoOfToCodecs ",pxToCodecs->unNoOfCodecs);
  return;
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_ReOrderCodecsForWB
 *  Description     : Re-orders the first and second codec lists according to 
 *										WB logic
 *  Input Values    : pxOutCodecs, pxInCodecs
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           : Remove Non Voice related codecs befor applyin re-order logic.
					  Once Codecs are re-ordred append 2833 followed by T38 -If they were removed earlier.	
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ReOrderCodecsForWB(
								IN_OUT x_IFX_CMGR_CodecParams *pxCodecs1,
								IN_OUT x_IFX_CMGR_CodecParams *pxCodecs2,
								IN boolean bReOrderCodecs1)
{
	e_IFX_Return eRet = IFX_SUCCESS;
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
	int32 iIdx = -1, iIdx1 = -1;
	x_IFX_CMGR_CodecParams xLocalCodecs1, xLocalCodecs2;
	memset(&xLocalCodecs1,0,sizeof(x_IFX_CMGR_CodecParams));
	memset(&xLocalCodecs2,0,sizeof(x_IFX_CMGR_CodecParams));

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(pxCodecs1 && pxCodecs1->unNoOfCodecs){
		IFX_CMGR_StripNonVoiceCodecs(pxCodecs1,&xLocalCodecs1);
	}
	if(pxCodecs2 && pxCodecs2->unNoOfCodecs){
	IFX_CMGR_StripNonVoiceCodecs(pxCodecs2,&xLocalCodecs2);
	}
	/*If the out-CL has codecs?*/
	if(pxCodecs1 && pxCodecs1->unNoOfCodecs)
	{	
		/*Check if the out codec list contains a WB codec?*/
		IFX_CMGR_SearchForCodec(pxCodecs1,IFX_G722_64,&iIdx);
		if(-1 != iIdx)
		{
			/*Order the In CL's Codec list also*/
			if(pxCodecs2 && pxCodecs2->unNoOfCodecs)	
			{
				/*Check if the out codec list contains a WB codec?*/
				IFX_CMGR_SearchForCodec(pxCodecs2,IFX_G722_64,&iIdx1);
				if(-1 != iIdx1)
				{
					/*Move to the WB codec to the top of the list for both*/
					if(IFX_TRUE == bReOrderCodecs1)
					{
						IFX_CMGR_InsertCodecAtPos(pxCodecs1,iIdx,0);
					}
					IFX_CMGR_InsertCodecAtPos(pxCodecs2,iIdx1,0);
				}
			}
			else
			{
				if(IFX_TRUE == bReOrderCodecs1)
				{
					/*In this case there are no IN codecs - Make Out Codecs as NB*/
					IFX_CMGR_SearchForCodec(pxCodecs1,IFX_G722_64,&iIdx);
					if(0 == iIdx){
						if(pxCodecs1->unNoOfCodecs > 1){
							/* Make the MPC on the OUT List as a NON-WB codec*/
							IFX_CMGR_InsertCodecAtPos(pxCodecs1,iIdx,1);
						}
					}
				}
			}
		}
		else
		{
			/* This means that the OUT codec list does not have a WB codec as MPC*/
			if(pxCodecs2 && (pxCodecs2->unNoOfCodecs > 1) )	
			{	/*Check if the IN codec list contains a WB codec?*/
				IFX_CMGR_SearchForCodec(pxCodecs2,IFX_G722_64,&iIdx1);
				/*Does list contain a WB codec as the MPC ? */
				if(0 == iIdx1) {	
					/*Check if there are more than 2 codecs*/
					if(pxCodecs2->unNoOfCodecs > 1) {
							IFX_CMGR_InsertCodecAtPos(pxCodecs2,iIdx1,1);
					}
				}
			}
		}
	}

	else
	{	/* This means that the OUT codec list does not exist*/
		if(pxCodecs2 && (pxCodecs2->unNoOfCodecs > 1) )	
		{	/*Check if the IN codec list contains a WB codec?*/
			IFX_CMGR_SearchForCodec(pxCodecs2,IFX_G722_64,&iIdx1);
			/*Does list contain a WB codec as the MPC ? */
			if(0 == iIdx1)
			{	/*Check if there are only 2 codecs*/
				if(pxCodecs2->unNoOfCodecs > 1)
				{	/* Make the MPC on the IN List as a NON-WB codec 
						 since there are more than 2 codecs*/
					IFX_CMGR_InsertCodecAtPos(pxCodecs2,iIdx1,1);
				}
			}
		}
	}
	if(pxCodecs1 && xLocalCodecs1.unNoOfCodecs){
		IFX_CMGR_AppendCodecs(pxCodecs1,&xLocalCodecs1);
	}
	if(pxCodecs2 && xLocalCodecs2.unNoOfCodecs) {
		IFX_CMGR_AppendCodecs(pxCodecs2,&xLocalCodecs2);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
#endif
	return eRet;

}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MakeCallExtnExtn
 *  Description     : Makes Call from a Extn to an Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_MakeCallExtnExtn
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg *pxOut = IFX_CMGR_GetOutCl(pxCnxt); 
	x_IFX_CMGR_CallLeg* pxIn = pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs-1];
	//x_IFX_CMGR_CallLeg *pxIn = IFX_CMGR_GetInClStart(pxCnxt);
	x_IFX_CMGR_CallParams xInPar;
	x_IFX_CMGR_CodecParams* pxOutCodecs = 
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;		 
	x_IFX_CMGR_CodecParams* pxOutOffCodecs = 
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;		 
	x_IFX_CMGR_CodecParams* pxInCodecs = 
					&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;		 
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/*Allocate the required resources for the call using MMGR*/	
	eRet=IFX_CMGR_GetMediaResIntInt(&pxCnxt->iResId,pxOut,pxIn,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			printf("\n IFX_CMGR_MakeCallExtnExtn Point 1");
		return eRet;/* DEBUG*/
	}
	/*Order Codecs for WB if needed*/
	eRet = IFX_CMGR_ReOrderCodecsForWB(pxOutCodecs,pxInCodecs,IFX_TRUE);		
	/* Make the offered and Negotiated Codecs same so that the WB 
		 change is also reflected in this one*/
	if(pxOutCodecs->unNoOfCodecs)
	{	
		memcpy(pxOutOffCodecs,pxOutCodecs,sizeof(x_IFX_CMGR_CodecParams));
	}				
	/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
	memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
	eRet = IFX_CMGR_MakeCallParamsExtnExtn(pxIn,pxPar,&xInPar,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			printf("\n IFX_CMGR_MakeCallExtnExtn Point 2");
		return eRet;/* DEBUG*/
	}
	/*Change state of the OUT CL to SRP Invite and the IN CL to RRP (Invite)*/
	IFX_CMGR_ChangeState(pxOut,
				IFX_CMGR_SEND_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	IFX_CMGR_ChangeState(pxIn,
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	/*Invoke the InvokeCallIncoming function on the IN CL*/
	eRet = 
		IFX_CMGR_InvokeCallIncExtnExtn(pxOut,pxIn,&xInPar,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			printf("\n IFX_CMGR_MakeCallExtnExtn Point 3");
		return eRet;/* DEBUG*/
	}
	/*Check if the return type is STATUS PENDING & Reason RINGING*/
	if((IFX_CMGR_STATUS_PENDING == *peStatus)&&
				(IFX_ENDPOINT_RINGING == *peReason))
	{
		/*Change state of the OUT CL to RINGBACK and the IN CL to RINGING*/	
		IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_RINGBACK,0);
		IFX_CMGR_ChangeState(pxIn,IFX_CMGR_STATE_RINGING,0);
	}
	/* If the status returned was FAILURE then DeAllocate the Call Context*/
	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);	
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/********************** Make Call  functions End*******************************/

/*****************************************************************************
 *  Function Name   : IFX_CMGR_GetCallCnxtAndLegs
 *  Description     : Function generates the Context and Leg structure needed
 *  						 for a call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetCallCnxtAndLegs(
					 IN e_IFX_CMGR_BasicCallType eBasic,
					 IN uint8 ucSize,
					 IN void* pvPrivateData,
					 OUT e_IFX_ReasonCode* peReason,
					 OUT x_IFX_CMGR_CallContext** ppxCnxt 
					 )						
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	uint16 unCnxtIdx = 0; uint8 i;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");

	if((eRet=IFX_CMGR_GetCallContext(eBasic,ppxCnxt,&unCnxtIdx)) == IFX_FAILURE)
	{
		*peReason = IFX_NO_RESOURCE;/* Free CC not found, hence rejected-DEBUG*/
		return eRet;	
	}
	/* Save the basic call type in the CC get the call legs ptr*/
	if (ucSize > IFX_CMGR_MAX_LEGS_PER_CNXT)
		return IFX_FAILURE;
	if(IFX_FAILURE == IFX_CMGR_AllocCallLegPtr(*ppxCnxt, ucSize))
	{
		*peReason = IFX_NO_RESOURCE; 
		IFX_CMGR_DeAllocCallCnxt(*ppxCnxt);	
		return IFX_FAILURE;
	}
	pxCnxt = *ppxCnxt;
	pxCnxt->ucNumCallLegs = ucSize; /*Set number of call legs in the cnxt*/
	if(ucSize>IFX_CMGR_MIN_LEGS_PER_CNXT)/*Set forking flag in the context*/
		IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CNXT_IN_FORKING);
	
	/*Reserve the required number of call legs in the CL array for the call*/			
	for(i=0;i<(ucSize);i++)
	{
		if((eRet=IFX_CMGR_GetCallLeg(unCnxtIdx, &pxCnxt->pxCallLegs[i]))
							 													==IFX_FAILURE)
		{
			*peReason = IFX_NO_RESOURCE; /* Free CL not found, reject-DEBUG*/
			IFX_CMGR_DeAllocCallCnxt(pxCnxt);/*Clear resources*/	
			return eRet;/*Failure IFX_FAILURE and STATUS Fail*/	
		}
		if(0 == i) /* If the index is Zero then this is OUT CL-set eDir*/
			IFX_CMGR_SetLegDir(pxCnxt->pxCallLegs[i],IFX_CMGR_OUT);
		else /*For any other higher index - set direction as IN*/		
			IFX_CMGR_SetLegDir(pxCnxt->pxCallLegs[i],IFX_CMGR_IN);
	}
	pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX]->pvPrivateData = 
			  										pvPrivateData;/*set private data*/
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ForwardCall
 *  Description     : Function entertains a 301/302 on a Voip Call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ForwardCall (
					 IN x_IFX_CMGR_CallLeg* pxLeg, /*Call Leg on which release came*/
					 IN x_IFX_CMGR_CallLeg* pxOut,
					 IN x_IFX_CMGR_VoipAddr* pxFwdAddr,/*Addr to FWD call to*/
					 IN e_IFX_ReasonCode eReason,
					 OUT x_IFX_CMGR_CallLeg** ppxNew, /*New Call leg if formed*/
					 OUT e_IFX_CMGR_Status *peStatus
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxNew = NULL;
	boolean bAllow = IFX_TRUE;
	uint32 uiNewCallId = 0;
	x_IFX_CMGR_VoipLegInfo* pxInfo;
	e_IFX_ReasonCode eRes = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	*peStatus = IFX_CMGR_STATUS_PENDING;

	/*Invoke pfnCallFwdInfo on the OUT CL*/
	if(pxOut->pxCallBackList->pfnCallFwdInfo)
		eRet = pxOut->pxCallBackList->pfnCallFwdInfo
			(pxOut->uiCallId,IFX_CALL_FORWARD,pxFwdAddr,
			 								&bAllow,pxOut->pvPrivateData);
	if(IFX_FALSE == bAllow)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
										IFX_DBG_STR, "Call Forward not allowed by Agent");
		return eRet;
	}
	pxInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	/* Check if the Call Forward is allowed or not*/
	if((IFX_TRUE != IFX_CMGR_CanCallBeFwd(pxInfo, pxFwdAddr)))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
										IFX_DBG_STR, "Call Forward PING-PONG not permitted!");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Add to the Call Forward list*/
	IFX_CMGR_AddToCallFwdList(pxInfo->axCallFwdList,
						 pxFwdAddr,&pxInfo->ucCallFwdCount);		
	/* Allocate a new CL */
	eRet = IFX_CMGR_GetCallLeg(IFX_CMGR_FindCallCnxtIdx(pxCnxt),ppxNew);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxLeg, *ppxNew);
	pxNew = *ppxNew;
	uiNewCallId = pxNew->uiCallId;
	/* Copy Data From the pxLeg into the New CL*/
	memcpy(pxNew, pxLeg, sizeof(x_IFX_CMGR_CallLeg));
	/* Copy Data From the pxLeg into the New CL*/
	/* Put a pointer from the CL to the Cnxt*/
	pxNew->pxCurrCnxt = pxCnxt;
	pxNew->uiCallId = uiNewCallId;
	/* Get a pointer to the info leg*/
	pxInfo = &pxNew->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	/* Change the Remote address in the new CL to the FWD addr*/
	memcpy(&pxInfo->xRemAddr, pxFwdAddr, sizeof(x_IFX_CMGR_VoipAddr));
	
	/*Generate RTP agent info and invoke Stop Session*/
	eRet = IFX_CMGR_StopMediaSession(pxLeg);
	IFX_CMGR_DeAllocCallLeg(pxLeg);
	/* Change state of the new CL to RRP(Invite) */	
	IFX_CMGR_ChangeState(pxNew,
				IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
	
	/* Invoke the pfnCallIncoming on the new IN CL*/
	eRet = IFX_CMGR_InvokeCallIncIntVoip(pxOut,pxNew,
						 	&pxNew->xCallParams, peStatus,&eRes);
	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		/* The Call Forward Failed - Clear the leg */
		IFX_CMGR_InvokeRemoteCallRelease (pxOut, IFX_MAX_REASON, NULL);
		IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
			pxOut->xLegOwnerInfo.szEndptId, 
					pxNew->xLegOwnerInfo.szEndptId, &eRes);	
		IFX_CMGR_DeAllocCallLeg(pxNew);
		*ppxNew = NULL;
		return eRet;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
/********************* Create Call Function **********************************/

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CreateCallVoipInt
 *  Description     : Function is entry point for Voip to Internal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_CreateCallVoipInt
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = 0;
	uchar8 ucSize = IFX_CMGR_MAX_AGENTS;
	char8 aszEid[IFX_CMGR_MAX_AGENTS][IFX_MAX_ENDPOINTID_LEN];
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	uint8 ucVoipLineId = 0;
	boolean bReject = IFX_FALSE;
	boolean bFwdMode = IFX_TRUE;
	x_IFX_CMGR_CallLeg* pxOut = NULL;
	x_IFX_CMGR_CodecParams xCodecs;
	char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN]={'\0'};
  boolean bSecondCall; 	
#ifdef HANDLE_OPTIONS
  uint32 uiOptFlag = 0;
  if(*peReason == IFX_OPTION_ARRIVED){
		uiOptFlag =1;
  }
#endif
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	ucVoipLineId = pxTo->ucLineId;
	if (*peReason != IFX_DEFLECTION){

	/*Find the Voip line Id for the Call*/
	eRet = IFX_LMGR_GetVoipLineIdFromUrl(
		&pxTo->uxAddressInfo.xVoipAddr, &ucVoipLineId, peReason);
	if((IFX_FAILURE == eRet) || (!ucVoipLineId))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_USER_NOT_FOUND;
		return eRet;/*DEBUG*/
	}
  bSecondCall = IFX_CMGR_AnyCallOnVL(ucVoipLineId)?IFX_TRUE:IFX_FALSE;
	/*Check if the incoming call can be accepted*/
	eRet = IFX_LMGR_CanCallBeAccepted(ucVoipLineId, 
		&pxFrom->uxAddressInfo.xVoipAddr,
		(IFX_CMGR_AnyCallOnVL(ucVoipLineId)?IFX_FALSE:IFX_TRUE), &bReject, 
		&pxCallParams->uxCallParams.xVoipParams.xFwdAddr,
		peReason);
#ifdef HANDLE_OPTIONS
  if(uiOptFlag){
     IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"OptHanlding");
     if(IFX_TRUE == bReject || IFX_FAILURE == eRet ){
       *peStatus = IFX_CMGR_STATUS_FAIL;
       eRet = IFX_FAILURE;
     }
     else{
       *peStatus = IFX_CMGR_STATUS_SUCCESS;
       eRet = IFX_SUCCESS;
    }
	  IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
    return eRet;
  }
#endif
	if((IFX_TRUE == bReject) || (IFX_FAILURE == eRet) )
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		/*Add to Missed Call Register*/
		IFX_LMGR_AddToMissedCallReg(ucVoipLineId,pxFrom);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Find if the call is a VOIP_FXO or VOIP_EXTN call , the relevant endpoints 
	 * and the various CFWD related line features*/

  if(bSecondCall && (IFX_FALSE == IFX_CIF_IsLineTypeMulti(ucVoipLineId))){
    eRet = IFX_CMGR_IsCallAllowed(ucVoipLineId,szEndPtId);
    if(eRet== (e_IFX_Return) IFX_TRUE){
      strcpy(aszEid[0],szEndPtId);
      ucSize = 1;
      bFwdMode=IFX_TRUE;
    }
	}
  else{
	  eRet = IFX_LMGR_GetEndpointsForVoipLine(ucVoipLineId, 
						 					aszEid, &ucSize, &bFwdMode, peReason);

	  if(((e_IFX_Return) IFX_FAILURE == eRet) || (!ucSize))
	  {
		  *peStatus = IFX_CMGR_STATUS_FAIL;
		  *peReason = IFX_USER_NOT_FOUND;
		  IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		  return eRet;
	  }
  }

	/* Set the right type in the BCT parameter*/
	eBasic = (IFX_TRUE == bFwdMode)?IFX_CMGR_BCT_VOIP_EXTN:IFX_CMGR_BCT_VOIP_FXO;
	
	/* From LMGR find the Codecs*/
	memset(&xCodecs,0,sizeof(x_IFX_CMGR_CodecParams));	
	eRet = IFX_LMGR_GetCodecsForLine(ucVoipLineId, &xCodecs, peReason);
	/*Check for Media Mismatch*/
	if(IFX_FALSE == IFX_CMGR_DoesMediaMatch( &xCodecs,
			&pxCallParams->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams))
	{
		*peReason = IFX_MEDIA_MISMATCH;
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
    "Payload number for codec#0 from  NA",pxCallParams->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams.axCodec[0].ucDynPT);
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
    "Payload number for codec#0 from after matching",xCodecs.axCodec[0].ucDynPT);
	}
	
#ifdef FAX_SUPPORT
	/* Check if a Fax T.38 Codec is MPC in the negotiated codec List */
	if(IFX_TRUE == IFX_CMGR_IsPrefCodecT38(&xCodecs))
	{
		char8 szFaxFxsEid[IFX_MAX_ENDPOINTID_LEN];
		memset(szFaxFxsEid,0,IFX_MAX_ENDPOINTID_LEN * sizeof(char8));
		/* If yes then find the FAX FXS port to ring from the LMGR*/
		IFX_LMGR_GetFaxFxsPort(szFaxFxsEid);				
		/* If port does not exist then reject the call*/
		if(!strlen(szFaxFxsEid))
		{
		  *peReason = IFX_MEDIA_MISMATCH;
			*peStatus = IFX_CMGR_STATUS_FAIL;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		/* Set basic call type to VOIP_EXTN*/
		eBasic = IFX_CMGR_BCT_VOIP_EXTN;	
		/* Set ucSize to 1 and Memset aszEid. Set aszEid[0] to the EID for FAX*/
		memset(aszEid,0,sizeof(char8)*IFX_CMGR_MAX_AGENTS*IFX_MAX_ENDPOINTID_LEN);
		ucSize = 1;
		strcpy(aszEid[0],szFaxFxsEid);
	}
#endif
	
	/* Call can be accepted and all the info needed for the call is present
	 * Generate the call context and the number of Call legs needed for it*/
	}
	if ((*peReason == IFX_DEFLECTION) && *puiCallId ){
		if(IFX_SUCCESS != IFX_CMGR_GetNewLeg(puiCallId)){
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Could not get leg");
			return IFX_FAILURE;
		}else
		pxCnxt  = IFX_CMGR_GetCallCnxtPtr(*puiCallId);
		ucSize = 1;
		strcpy(aszEid[0],pxCnxt->szDeflecteeEid);
	}else
	if(IFX_CMGR_GetCallCnxtAndLegs(eBasic,ucSize+1,
			pvPrivateData, peReason, &pxCnxt) == IFX_FAILURE)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
	}
	
	if (pxCnxt){
		pxOut = IFX_CMGR_GetOutCl(pxCnxt);		
	}else{
		return IFX_FAILURE;
	}
	if (pxOut){
		*puiCallId = pxOut->uiCallId;
	}else{
		return IFX_FAILURE;
	}

	/* Populate data in the CC and its CLs as per the basic call type*/
	if(IFX_CMGR_BCT_VOIP_FXO == pxCnxt->eBasicCallType)
	{
		eRet=IFX_CMGR_PrepCnxtVoipFxo(pxCnxt,pxFrom,pxTo,
							 pxCallParams,aszEid[0], ucVoipLineId);
		if(IFX_FAILURE == eRet)
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			*peStatus = IFX_CMGR_STATUS_FAIL;
			return eRet;
		}
		/*All structure Population is done - Now invoke MakeCallVoipFxo*/
		eRet = IFX_CMGR_MakeCallVoipFxo(pxCnxt, pxCallParams, peStatus, peReason);
	}
	else /*For VOIP to EXTN calls*/
	{
	if ((*peReason == IFX_DEFLECTION) && *puiCallId ){
		eRet=IFX_CMGR_DefPrepCnxtVoipExtn(pxCnxt,pxFrom,pxTo,pxCallParams,
               aszEid,ucSize, ucVoipLineId);
	}else
		eRet=IFX_CMGR_PrepCnxtVoipExtn(pxCnxt,pxFrom,pxTo,pxCallParams,
							 aszEid,ucSize, ucVoipLineId);
		if(IFX_FAILURE == eRet)
		{
			eRet = IFX_SUCCESS;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			*peStatus = IFX_CMGR_STATUS_FAIL;
			*peReason = IFX_MAX_REASON;
			return eRet;
		}
		pxOut = IFX_CMGR_GetOutCl(pxCnxt);	
		/*All structure Population is done - Now invoke MakeCallVoipExtn*/
		eRet = IFX_CMGR_MakeCallVoipExtn(pxCnxt, pxCallParams, peStatus, peReason);
	}

	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = 	
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
		/* Check if call forward is needed? If so apply BUSY CFWD*/	  
		boolean bFwdEnabled = IFX_FALSE;
		
		eRet = IFX_LMGR_GetCallFwdAddr(pxVoipLegInfo->ucLineId, 
			IFX_CALL_FWD_BUSY, &bFwdEnabled,NULL, 
			&pxCallParams->uxCallParams.xVoipParams.xFwdAddr,peReason);
		/*Check if call can be FWD to this address*/
		if((IFX_TRUE == bFwdEnabled) && (IFX_TRUE == IFX_CMGR_CanCallBeFwd(
			pxVoipLegInfo, &pxCallParams->uxCallParams.xVoipParams.xFwdAddr)))
				*peReason = IFX_CALL_FORWARD;
		/* Return the call id as Zero*/
		*puiCallId = 0;
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CreateCallFxoExtn
 *  Description     : Function is entry point for Fxo to Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_CreateCallFxoExtn
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = IFX_CMGR_BCT_FXO_EXTN;
	uchar8 ucSize = IFX_CMGR_MAX_AGENTS;
	char8 aszEid[IFX_CMGR_MAX_AGENTS][IFX_MAX_ENDPOINTID_LEN];
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	memset(aszEid, 0, IFX_CMGR_MAX_AGENTS * IFX_MAX_ENDPOINTID_LEN);
	
	/* Understand if mode is forking or GW*/
	if(!strcasecmp(pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId, 
														pxTo->uxAddressInfo.szEndptId))
	{
		/* Find if the call is to be forked*/	
		if(eRet == 
			IFX_LMGR_FindEndptsFromFxoId(pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId,
			&ucSize, aszEid, peReason))
		if((IFX_FAILURE == eRet) || !ucSize)
		{
			*peStatus = IFX_CMGR_STATUS_FAIL;
			/*Add to Missed Call Register*/
			IFX_LMGR_AddToMissedCallReg(IFX_PSTN_LINE,pxFrom);
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet; /*Major VMPI type failure - Propogate to top -DEBUG*/
		}
	}
	else
	{
		/* It must be a GW mode call from FXO To EXTN*/
		strcpy(aszEid[0], pxTo->uxAddressInfo.szEndptId);
		ucSize = 1;
	}
	
	/* Generate the call context and the number of Call legs needed*/
	if(IFX_CMGR_GetCallCnxtAndLegs(eBasic,ucSize+1,
			pvPrivateData,peReason,&pxCnxt) == IFX_FAILURE)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /*Major failure - Propogate to top-DEBUG*/
	}
	pxOut = IFX_CMGR_GetOutCl(pxCnxt);		
	*puiCallId = pxOut->uiCallId;

	if(IFX_CMGR_PrepCnxtFxoExtn(pxCnxt,pxFrom,pxTo,pxCallParams,aszEid,ucSize)
						 ==IFX_FAILURE)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}

	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	/* Now everything is ready - Invoke MakeCallFxoExtn */
	eRet = IFX_CMGR_MakeCallFxoExtn(pxCnxt, pxCallParams, peStatus, peReason);
	
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
#if 0	
	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		/*Add to Missed Call Register*/
		IFX_LMGR_AddToMissedCallReg(0,pxFrom);
	}
#endif	
	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CreateCallExtnExtn
 *  Description     : Function is entry point for Extn to Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
 STATIC e_IFX_Return IFX_CMGR_CreateCallExtnExtn
		  						(	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = IFX_CMGR_BCT_EXTN_EXTN;
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;	
printf("\n IFX_CMGR_CreateCallExtnExtn ");
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Generate the call context and the number of Call legs needed for it*/
	if ((*peReason == IFX_DEFLECTION) && *puiCallId ){
		if(IFX_SUCCESS != IFX_CMGR_GetNewLeg(puiCallId)){
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Could not get leg");
			printf("\n IFX_CMGR_CreateCallExtnExtn Fail Point 1");
			return IFX_FAILURE;
		}else
		pxCnxt  = IFX_CMGR_GetCallCnxtPtr(*puiCallId);
	}else
		if(IFX_CMGR_GetCallCnxtAndLegs(eBasic, IFX_CMGR_MIN_LEGS_PER_CNXT,
				pvPrivateData,peReason,&pxCnxt) == IFX_FAILURE)
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			printf("\n IFX_CMGR_CreateCallExtnExtn Fail Point 2");
			return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
		}

	/*Return Call Id*/
	if (pxCnxt){
		pxOut = IFX_CMGR_GetOutCl(pxCnxt);		
	}else{
			printf("\n IFX_CMGR_CreateCallExtnExtn Fail Point 3");
		return IFX_FAILURE;
	}
	if (pxOut){
		*puiCallId = pxOut->uiCallId;
	}else{
			printf("\n IFX_CMGR_CreateCallExtnExtn Fail Point 4");
		return IFX_FAILURE;
	}
	/* Populate the call context with all the info needed*/	
	if(IFX_CMGR_PrepCnxtExtnExtn(pxCnxt,pxFrom,pxTo,pxCallParams)
						 ==IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			printf("\n IFX_CMGR_CreateCallExtnExtn Fail Point 5");
		return IFX_FAILURE; 
	}
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	/* Now everything is ready - Invoke MakeCallExtnExtn */
	eRet = IFX_CMGR_MakeCallExtnExtn(pxCnxt, pxCallParams, peStatus, peReason);
	
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CreateCallExtnFxo
 *  Description     : Function is entry point for Extn to Fxo call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_CreateCallExtnFxo
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = IFX_CMGR_BCT_EXTN_FXO;
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(IFX_CMGR_GetCallCnxtAndLegs(eBasic, IFX_CMGR_MIN_LEGS_PER_CNXT  ,
			pvPrivateData,peReason,&pxCnxt) == IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
	}

	pxOut = IFX_CMGR_GetOutCl(pxCnxt);		
	*puiCallId = pxOut->uiCallId;

	if(IFX_FAILURE == IFX_CMGR_PrepCnxtExtnFxo(pxCnxt,pxFrom,pxTo,pxCallParams))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE; 
	}

	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	/* Now everything is ready - Invoke MakeCallExtnFxo */
	eRet = IFX_CMGR_MakeCallExtnFxo(pxCnxt, pxCallParams, peStatus, peReason);
	
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CreateCallExtnVoip
 *  Description     : Function is entry point for Extn to Voip call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_CreateCallExtnVoip
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = IFX_CMGR_BCT_EXTN_VOIP;
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/* Call can be accepted and all the info needed for the call is present
	 * Generate the call context and the number of Call legs needed for it*/
	if ((*peReason == IFX_DEFLECTION) && *puiCallId ){
		if(IFX_SUCCESS != IFX_CMGR_GetNewLeg(puiCallId)){
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Could not get leg");
			return IFX_FAILURE;
		}else{
			pxCnxt  = IFX_CMGR_GetCallCnxtPtr(*puiCallId);
			if (pxCnxt){
				pxCnxt->eBasicCallType = eBasic;
			}else{
				return IFX_FAILURE;
			}
		}
	}else
	if(IFX_CMGR_GetCallCnxtAndLegs(eBasic,IFX_CMGR_MIN_LEGS_PER_CNXT ,
			pvPrivateData,peReason,&pxCnxt) == IFX_FAILURE)
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
	}
	
	pxOut = IFX_CMGR_GetOutCl(pxCnxt);		
	*puiCallId = pxOut->uiCallId;

	eRet = IFX_CMGR_PrepCnxtExtnVoip(pxCnxt,pxFrom,pxTo,
									pxCallParams, peStatus, peReason);
	if((IFX_CMGR_STATUS_FAIL == *peStatus)||(IFX_FAILURE == eRet))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	/* Now everything is ready - Invoke MakeCallExtnVoip */
	eRet = IFX_CMGR_MakeCallIntVoip(pxCnxt, pxCallParams, peStatus, peReason);
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_CreateCallFxoVoip
 *  Description     : Function is entry point for Fxo to Voip call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_CreateCallFxoVoip
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = IFX_CMGR_BCT_FXO_VOIP;
	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Call can be accepted and all the info needed for the call is present
	 * Generate the call context and the number of Call legs needed for it*/
	if(IFX_CMGR_GetCallCnxtAndLegs(eBasic, IFX_CMGR_MIN_LEGS_PER_CNXT  ,
			pvPrivateData,peReason,&pxCnxt) == IFX_FAILURE)
	{
		return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
	}
	
	pxOut = IFX_CMGR_GetOutCl(pxCnxt);		
	*puiCallId = pxOut->uiCallId;
	if(IFX_CMGR_PrepCnxtFxoVoip(pxCnxt,pxFrom,pxTo,
									pxCallParams,peStatus, peReason) ==IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE; 
	}
	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	/* Now everything is ready - Invoke MakeCallFxoVoip */
	eRet = IFX_CMGR_MakeCallIntVoip(pxCnxt, pxCallParams, peStatus, peReason);
	
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);

	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IgnoreCreateCall
 *  Description     : N.A.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_IgnoreCreateCall
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	/* ENTRY DEBUG */
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	*peStatus = IFX_CMGR_STATUS_FAIL;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*********************BASIC CALL CONTROL****************************/

/*! 
    \brief  This API is to be called by the Agent to get the parameters 
				needed for changing the Media during call establishment.
				It shall be invoked by the agent, after 
				pfn_IFX_CMGR_RemoteCallAccept or 
				pfn_IFX_CMGR_RemoteCallAnswer. Its also needed in the
				middle of Hold/Resume scenarios. Every time a local Req is
				issued to the DECT/NA, it should call this API to find the change
				in media params. Also every-time it gets a Rsp for a prev
				issued hold Req, the agent should call this API to find the 
				final Rsp for the media change.
    \param[in]  uiCallId is the identifier of the call
    \param[out] pxMediaParams is the reference to the media parameters.
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaParamsGet(
					 			IN uint32 uiCallId,
								OUT x_IFX_CMGR_MediaParams* pxMediaParams)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = NULL;
	x_IFX_CMGR_VoipMediaParams* pxVoipMedia =	
			  &pxMediaParams->uxMediaParams.xVoipMediaParams;
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;	
	x_IFX_CMGR_ExtnMediaParams* pxExtnMedia =	
			  &pxMediaParams->uxMediaParams.xExtnMediaParams;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	pxLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	pxExtnLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;

	memset(pxMediaParams, 0, sizeof(x_IFX_CMGR_MediaParams));
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)	
	{
		pxMediaParams->eAgentType = IFX_CMGR_TYPE_VOIP;
		switch(pxLeg->eCurrState)
		{
			case IFX_CMGR_STATE_RINGBACK:
			case IFX_CMGR_STATE_CONV:
			{
				if(IFX_CMGR_OFFER_SENT == pxLegInfo->eNegStatus)
				{
					IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
          										                   "OFFER SENT CASE");
#if 0       //Just for testing No Answer SDP
					IFX_CMGR_MakeCodecsForMediaPar(&pxVoipMedia->xCodecParams, 
													&pxLegInfo->xOfferedCodecInfo);	
#else
					memcpy(&pxVoipMedia->xCodecParams,
						&pxLegInfo->xOfferedCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
#endif			
					memcpy(&pxVoipMedia->xRtpParams, 
						&pxLegInfo->xNegRtpParams, sizeof(x_IFX_CMGR_RtpParams));
#ifdef FAX_SUPPORT
					memcpy(pxVoipMedia->axFaxParams, pxLegInfo->axFaxParams, 
						IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
#endif
				}else
				if(IFX_CMGR_OFFER_RXD == pxLegInfo->eNegStatus)
				{ 
					IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
          										                   "OFFER RXD CASE");
					IFX_CMGR_MakeCodecsForMediaPar(&pxVoipMedia->xCodecParams, 
													&pxLegInfo->xNegCodecInfo);
					
					memcpy(&pxVoipMedia->xRtpParams, 
						&pxLegInfo->xNegRtpParams, sizeof(x_IFX_CMGR_RtpParams));
					
#ifdef FAX_SUPPORT
					memcpy(pxVoipMedia->axFaxParams,
						pxLegInfo->axFaxParams, 
						IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
#endif
				}
			}
			break;
			case IFX_CMGR_RECV_RESP_PENDING:
			{
				if((IFX_CMGR_RESP_PEND_HOLD == pxLeg->eRespPendEvt)|| 
						(IFX_CMGR_RESP_PEND_RESUME == pxLeg->eRespPendEvt))
				{
					IFX_CMGR_MakeCodecsForMediaPar(&pxVoipMedia->xCodecParams, 
													&pxLegInfo->xTempCodecInfo);	
					memcpy(&pxVoipMedia->xRtpParams, 
						&pxLegInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
#ifdef FAX_SUPPORT
					memcpy(pxVoipMedia->axFaxParams,
						pxLegInfo->axFaxParams, 
						IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
#endif
				}

			}
			break;
			default:
			{
				if(pxLegInfo->xNegCodecInfo.unNoOfCodecs)
				{
					IFX_CMGR_MakeCodecsForMediaPar(&pxVoipMedia->xCodecParams, 
													&pxLegInfo->xNegCodecInfo);	
				}
				else
				if(pxLegInfo->xOfferedCodecInfo.unNoOfCodecs)
				{
#if 0       //Just for testing No Answer SDP
					IFX_CMGR_MakeCodecsForMediaPar(&pxVoipMedia->xCodecParams, 
													&pxLegInfo->xOfferedCodecInfo);	
#else
					memcpy(&pxVoipMedia->xCodecParams,
						&pxLegInfo->xOfferedCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
#endif			
				}
				memcpy(&pxVoipMedia->xRtpParams, 
					&pxLegInfo->xNegRtpParams, sizeof(x_IFX_CMGR_RtpParams));
#ifdef FAX_SUPPORT
				memcpy(pxVoipMedia->axFaxParams,
					pxLegInfo->axFaxParams, 
						IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
#endif
			}
			break;
		}
	}
	else
	{
		/*This is an Extension case*/
		if(pxExtnLegInfo->xNegCodecInfo.unNoOfCodecs)
		{
			memcpy(&pxExtnMedia->xCodecParams, &pxExtnLegInfo->xNegCodecInfo,		
						sizeof(x_IFX_CMGR_CodecParams));		
		}
		else
		if(pxExtnLegInfo->xOfferedCodecInfo.unNoOfCodecs)
		{
			memcpy(&pxExtnMedia->xCodecParams,  &pxExtnLegInfo->xOfferedCodecInfo, 
				sizeof(x_IFX_CMGR_CodecParams));	
		}
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
	/*
	 * Get Media Params is to be invoked  by the DECT/NA agents.
	 *
	 * 1) Check that the CL on which its invoked is a NA/DECT leg,
	 * 	else reject API.
	 * 2) Check the state of the CL. If the state is 
	 * 	2.1) RINGBACK - Check if the IFX_CMGR_OFFER_RXD  is set. If yes, then
	 * 		  return the codecs and the rtp in the Negotiated part. If 
	 * 		  IFX_CMGR_OFFER_SENT was set then it means that an empty SDP offer
	 * 		  was received and thus return the offered codecs and the negotaited
	 * 		  rtp (which contains only local params).
	 * 			
	 * 	2.2) CONV - Return the codecs in the negotaited list. Also return 
	 * 		  the negotaited RTP params (for NA).
	 * 		  
	 * 	2.3) RRP (Hold) - Take the media 
	 * 		  params stored in the temporary media params in the CL. Ensure that
	 * 		  the RTP mode being offered, is with SDP mode INACTIVE (if its 
	 * 		  invoked on an NA CL).
	 * 	2.4) RRP (Resume) - Take 
	 * 		  the media stored in the temporary Media Params in the CL. Ensure
	 * 		  that the RTP mode being offered is with mode ACTIVE and all
	 * 		  codecs are ones that were offered initially.
	 *		2.5) All other states - the accepted codecs/rtp if any. If not the
	 *			  offered if any. Else return NULL.
	 * */
}

/*! 
    \brief  This function is to be called by the Network Agent to set the media 
	 			parameters in case it receives the SDP answer with
				a PRACK or an ACK.
    \param[in]  uiCallId is the identifier of the call
    \param[in] pxMediaParams is the reference to the media parameters.
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaParamsSet(
					 			IN uint32 uiCallId,
								IN x_IFX_CMGR_MediaParams* pxMedia)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CodecParams* pxRecvCodecs;
	x_IFX_CMGR_CodecParams xCodec;
	x_IFX_CMGR_RtpParams* pxRecvRtp;
	x_IFX_CMGR_RtpParams xRtp;
	x_IFX_CMGR_FaxParams* pxRecvFax; 
	boolean bMatched = IFX_TRUE;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_VoipLegInfo* pxInfo = NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	pxInfo =
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		  
	if(IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Clear locals*/
	memset(&xCodec,0,sizeof(x_IFX_CMGR_CodecParams));
	memset(&xRtp,0,sizeof(x_IFX_CMGR_RtpParams));
	/* This function is only used for supporting NO-OFFER invite where the
	 * answer arrives with the ACK and INVITE received with 100 rel (w/o SDP)
	 * where the offer is made in 183 and the answer received with PRACK.*/
	pxRecvCodecs = &pxMedia->uxMediaParams.xVoipMediaParams.xCodecParams;
	pxRecvRtp = &pxMedia->uxMediaParams.xVoipMediaParams.xRtpParams;
	pxRecvFax = pxMedia->uxMediaParams.xVoipMediaParams.axFaxParams;

	if((IFX_CMGR_STATE_RINGBACK != pxLeg->eCurrState)&&
		(IFX_CMGR_STATE_CONV != pxLeg->eCurrState))
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}		  
	if((IFX_CMGR_OUT == pxLeg->eDirection) && 
		(IFX_CMGR_OFFER_SENT == pxInfo->eNegStatus))
	{	/* Try and match the media params */
		bMatched = IFX_CMGR_MatchMediaParams(&pxInfo->xOfferedCodecInfo, 
				pxRecvCodecs,&pxInfo->xNegRtpParams, pxRecvRtp,&xCodec,&xRtp);
		if(IFX_FALSE == bMatched)
		{
			eRet = IFX_FAILURE;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		/*Copy the accepted codecs & RTP into their right places*/
		memcpy(&pxInfo->xNegCodecInfo,
					&xCodec, sizeof(x_IFX_CMGR_CodecParams));
		memcpy(&pxInfo->xNegRtpParams,
					&xRtp, sizeof(x_IFX_CMGR_RtpParams));
		/*Get the Fax Params*/
#ifdef FAX_SUPPORT
			eRet  = IFX_CMGR_HandleFaxMediaNeg(pxLeg,
											&xCodec,pxInfo->axFaxParams,pxRecvFax);
			/* Set flag to indicate that this side was the initiator*/
			IFX_CMGR_SET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
															 	IFX_CMGR_FLAG_FAX_INITIATOR);
#endif
			
#if 0
		if(IFX_CMGR_STATE_RINGBACK == pxLeg->eCurrState)
		{	/*Indicates the presence of a PRACK - 
			Invoke Config Media & then pfnRemoteSessionStart*/
			eRet = 
				IFX_CMGR_InvokeMediaSession(pxLeg,pxCnxt->iResId,IFX_TRUE,&eReason);
		}else
#endif
		if(IFX_CMGR_STATE_CONV == pxLeg->eCurrState)
		{	
			/* Invoke Config Media & then pfnRemoteSessionStart*/
			eRet = 
				IFX_CMGR_InvokeMediaSession(pxLeg,pxCnxt->iResId,IFX_TRUE,&eReason);
		}
		else
		{
			/*There is no point invoking MEDIA CFG. SO just save the codecs & wait*/
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_PeerNegNeeded
 *  Description     : Function determines if peer negotiation is needed
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE 
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_PeerNegNeeded(
					 IN x_IFX_CMGR_CallLeg* pxLeg,
					 IN x_IFX_CMGR_CallLeg* pxPeer,
					 IN x_IFX_CMGR_MediaParams* pxMedia)
{
	boolean bRet = IFX_FALSE;
	int32 iIdx = -1;	
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;/*Extn Leg owner Info*/
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;/*Extn Leg owner Info*/
	x_IFX_CMGR_ExtnLegInfo* pxPeerLegInfo = NULL;/*Extn Leg owner Info*/
	e_IFX_CMGR_CallType eLegType = pxLeg->xLegOwnerInfo.eOwnerType;
	e_IFX_CMGR_CallType ePeerType = 0;
	x_IFX_CMGR_CodecParams* pxCodec = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxPeer || !pxMedia)
		return bRet;	

	ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
	if(IFX_CMGR_TYPE_VOIP == eLegType)
	{	
		if(IFX_CMGR_TYPE_EXTN == ePeerType)
		{	
			pxExtnLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
			pxVoipLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			pxCodec = &pxMedia->uxMediaParams.xVoipMediaParams.xCodecParams;
			if(pxExtnLegInfo->xNegCodecInfo.unNoOfCodecs && pxCodec->unNoOfCodecs)
			{
				/* Apply Logic for WB codec check*/
				if(IFX_TRUE == IFX_CMGR_IsMPC_WB(pxCodec))
				{
					if(IFX_FALSE == IFX_CMGR_IsMPC_WB(&pxVoipLegInfo->xNegCodecInfo))
					{
						if(IFX_FALSE == IFX_CMGR_IsMPC_WB(&pxExtnLegInfo->xNegCodecInfo))
						{
							IFX_CMGR_SearchForCodec(
													&pxExtnLegInfo->xOfferedCodecInfo,IFX_G722_64,&iIdx);
							if(-1 != iIdx)
							{
								bRet = IFX_TRUE;
							}
						}
					}	
				}
				else /*Requesting for a NB codec*/
				{	/*Currently running Codec on the Voip Side is an WB codec*/
					if(IFX_TRUE == IFX_CMGR_IsMPC_WB(&pxVoipLegInfo->xNegCodecInfo))
					{	/*Currently running Codec on the Extn Side is an WB codec*/
						if(IFX_TRUE == IFX_CMGR_IsMPC_WB(&pxExtnLegInfo->xNegCodecInfo))
						{
							if(pxExtnLegInfo->xOfferedCodecInfo.unNoOfCodecs > 1)
							{
								bRet = IFX_TRUE;
							}
						}
					}	
				}	
			}
		}
	}else
	if(IFX_CMGR_TYPE_EXTN == eLegType)
	{	
		if(IFX_CMGR_TYPE_EXTN == ePeerType)
		{
			pxCodec = &pxMedia->uxMediaParams.xExtnMediaParams.xCodecParams;
			pxPeerLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
			pxExtnLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
			
			if(pxExtnLegInfo->xNegCodecInfo.unNoOfCodecs && 
				pxPeerLegInfo->xNegCodecInfo.unNoOfCodecs && pxCodec->unNoOfCodecs)
			{
				/*Apply Logic for WB codec check - If the new MPC codec on the pxLeg side
				 is a WB codec & the current MPC is a NB codec, then check if the current
				 MPC on the peer side is a WB codec or not. */
				if(IFX_TRUE == IFX_CMGR_IsMPC_WB(pxCodec))
				{
					if(IFX_FALSE == IFX_CMGR_IsMPC_WB(&pxExtnLegInfo->xNegCodecInfo))
					{
						if(IFX_FALSE == IFX_CMGR_IsMPC_WB(&pxPeerLegInfo->xNegCodecInfo))
						{
							IFX_CMGR_SearchForCodec(
													&pxPeerLegInfo->xOfferedCodecInfo,IFX_G722_64,&iIdx);
							if(-1 != iIdx)
							{
								bRet = IFX_TRUE;
							}
						}
					}	
				}
				else
				{
					/*Requested Codec is NB*/
					if(IFX_TRUE == IFX_CMGR_IsMPC_WB(&pxExtnLegInfo->xNegCodecInfo))
					{
						if(IFX_TRUE == IFX_CMGR_IsMPC_WB(&pxPeerLegInfo->xNegCodecInfo))
						{
							if(pxPeerLegInfo->xOfferedCodecInfo.unNoOfCodecs > 1)
							{
								bRet = IFX_TRUE;
							}
						}
					}	
				}	
			}
		}else
		if(IFX_CMGR_TYPE_VOIP == ePeerType)
		{	
			pxExtnLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
			pxVoipLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			pxCodec = &pxMedia->uxMediaParams.xExtnMediaParams.xCodecParams;
			if(pxVoipLegInfo->xNegCodecInfo.unNoOfCodecs && pxCodec->unNoOfCodecs)
			{
				/* Apply Logic for WB codec check*/
				if(IFX_TRUE == IFX_CMGR_IsMPC_WB(pxCodec))
				{
					if(IFX_FALSE == IFX_CMGR_IsMPC_WB(&pxExtnLegInfo->xNegCodecInfo))
					{
						if(IFX_FALSE == IFX_CMGR_IsMPC_WB(&pxVoipLegInfo->xNegCodecInfo))
						{
							IFX_CMGR_SearchForCodec(
													&pxVoipLegInfo->xOfferedCodecInfo,IFX_G722_64,&iIdx);
							if(-1 != iIdx)
							{
								bRet = IFX_TRUE;
							}
						}
					}	
				}
				else
				{	/*The Requested Codec is an NB codec*/
					if(IFX_TRUE == IFX_CMGR_IsMPC_WB(&pxExtnLegInfo->xNegCodecInfo))
					{
						if(IFX_TRUE == IFX_CMGR_IsMPC_WB(&pxVoipLegInfo->xNegCodecInfo))
						{
							/*Also Check if there are any NB codecs in the system*/
							if(pxVoipLegInfo->xOfferedCodecInfo.unNoOfCodecs > 1)
							{
								bRet = IFX_TRUE;
							}
						}
					}	
				}	
			}
		}
	}
	if(IFX_TRUE == bRet)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
    	                         "Peer Neg is Needed");
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
    	                         "Peer Neg NOT Needed");
	}
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleIntVoipMediaNegReq
 *  Description     : Function handles a internal to Voip Media Neg Request
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleIntVoipMediaNegReq(
					 			IN x_IFX_CMGR_CallLeg* pxLeg,
								IN x_IFX_CMGR_CallLeg* pxPeer,
								IN_OUT x_IFX_CMGR_MediaParams* pxMedia,
								OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_CallType ePeerType =  0;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;/*Voip Leg owner Info*/
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;/*Extn Leg owner Info*/
	x_IFX_CMGR_CodecParams* pxRecvCodecs = NULL;
	x_IFX_CMGR_MediaParams xSendMedia;
	x_IFX_CMGR_CodecParams* pxSendCodecs = NULL;
	x_IFX_CMGR_RtpParams* pxSendRtp = NULL;
	boolean bMatched = IFX_TRUE;
				
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	*peStatus = IFX_CMGR_STATUS_PENDING;
	if(pxPeer)
		ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
	pxRecvCodecs = &pxMedia->uxMediaParams.xExtnMediaParams.xCodecParams;
	pxExtnLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	/*Invoke MatchMediaParams*/
	bMatched = IFX_CMGR_MatchMediaParams(&pxExtnLegInfo->xOfferedCodecInfo,
		pxRecvCodecs, NULL, NULL, &pxExtnLegInfo->xTempCodecInfo, NULL);
	
	if(IFX_TRUE != bMatched)
	{	/* No codecs matched*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet; 
	}	
	
	/* Check if the remote negotiation is needed?*/
	if(IFX_FALSE == IFX_CMGR_PeerNegNeeded(pxLeg, pxPeer, pxMedia))
	{
		/* Update the codecs in the pxMedia and return status SUCCESS*/
		memset(pxRecvCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
		memcpy(pxRecvCodecs, &pxExtnLegInfo->xTempCodecInfo,
							 				sizeof(x_IFX_CMGR_CodecParams));
		memset(&pxExtnLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		return eRet;
	}

	/* Negotiate with the remote VOIP side*/
	/* Populate the xSendMedia*/
	memset(&xSendMedia,0,sizeof(x_IFX_CMGR_MediaParams));
	xSendMedia.eAgentType = ePeerType;
	pxVoipLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		 
	pxSendCodecs = &xSendMedia.uxMediaParams.xVoipMediaParams.xCodecParams;
	pxSendRtp = &xSendMedia.uxMediaParams.xVoipMediaParams.xRtpParams;

	/* Copy the Offered codecs into the temp list*/
	memcpy(&pxVoipLegInfo->xTempCodecInfo, &pxVoipLegInfo->xOfferedCodecInfo,
						 									sizeof(x_IFX_CMGR_CodecParams));
	memcpy(&pxVoipLegInfo->xTempRtpParams, &pxVoipLegInfo->xNegRtpParams,
								 			sizeof(x_IFX_CMGR_RtpParams));
	/* Re-arrange the codec info in the temp list according to WB logic*/
	IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xTempCodecInfo,
																	&pxVoipLegInfo->xTempCodecInfo,IFX_FALSE);
	/* Copy Temp Codecs/ Neg Rtp in the xSendMedia List*/
	memcpy(pxSendCodecs, &pxVoipLegInfo->xTempCodecInfo,
								 													sizeof(x_IFX_CMGR_CodecParams));
	memcpy(pxSendRtp, &pxVoipLegInfo->xTempRtpParams,
								 														sizeof(x_IFX_CMGR_RtpParams));
	/* Invoke pfnMediaNegReq*/
	IFX_CMGR_InvokeMediaNegReq(pxPeer,&xSendMedia,peStatus,peReason);
	if((IFX_FAILURE == eRet) || (IFX_CMGR_STATUS_FAIL == *peStatus))
	{	/* DEBUG the problem*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleVoipIntMediaNegRsp
 *  Description     : Function handles Voip to Internal media neg response
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleVoipIntMediaNegRsp(
					 			x_IFX_CMGR_CallLeg* pxLeg,
								x_IFX_CMGR_CallLeg* pxPeer,
								IN x_IFX_CMGR_MediaParams* pxMedia,
								IN_OUT e_IFX_CMGR_Status* peStatus,
					 			IN_OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	e_IFX_CMGR_CallType ePeerType =  0;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;/*Voip Leg owner Info*/
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;/*Extn Leg owner Info*/
	x_IFX_CMGR_CodecParams* pxRecvCodecs = NULL;
	x_IFX_CMGR_RtpParams* pxRecvRtp = NULL;
	x_IFX_CMGR_FaxParams* pxRecvFax = NULL;
	x_IFX_CMGR_MediaParams xSendMedia;
	x_IFX_CMGR_CodecParams* pxSendCodecs = NULL;
	x_IFX_CMGR_CodecParams* pxCodecList = NULL;
	boolean bMatched = IFX_TRUE;
	boolean bRtpDiffer = IFX_FALSE;
	e_IFX_MMGR_Return eMmgrRet = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	pxExtnLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	pxVoipLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		 
	pxRecvCodecs = &pxMedia->uxMediaParams.xVoipMediaParams.xCodecParams;
	pxRecvRtp = &pxMedia->uxMediaParams.xVoipMediaParams.xRtpParams;
	pxRecvFax = pxMedia->uxMediaParams.xVoipMediaParams.axFaxParams;

	if(IFX_CMGR_STATUS_FAIL == *peStatus)
	{
		/* Invoke the pfnMediaNegRsp on the peer with status failure*/
		IFX_CMGR_InvokeMediaNegRsp(pxPeer, pxMedia, *peStatus, *peReason);
		memset( &pxExtnLegInfo->xTempCodecInfo, 0, 
							 sizeof(x_IFX_CMGR_CodecParams));
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Check if RTP differs*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(
								 &pxVoipLegInfo->xNegRtpParams,pxRecvRtp);
	/*Invoke MatchMediaParams*/
	bMatched = IFX_CMGR_MatchMediaParams(&pxVoipLegInfo->xTempCodecInfo,
		pxRecvCodecs, &pxVoipLegInfo->xTempRtpParams, pxRecvRtp, 
		&pxVoipLegInfo->xNegCodecInfo, &pxVoipLegInfo->xNegRtpParams);

	if(IFX_FALSE == bMatched)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "No Matching Codecs");
		*peStatus = IFX_CMGR_STATUS_FAIL;
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
		
	}
	
#ifdef FAX_SUPPORT
	pxCodecList = &pxVoipLegInfo->xNegCodecInfo;
	/* Check if the MPC is T.38*/		
	if(IFX_TRUE == IFX_CMGR_IsPrefCodecT38(pxCodecList))
	{
		/* FAX T.38 was accepted - Handle the negotiation part*/
		eRet  = IFX_CMGR_HandleFaxMediaNeg(pxLeg,pxCodecList,
															pxVoipLegInfo->axFaxParams,pxRecvFax);
		/* Update Codecs with T.38*/
		IFX_CMGR_ModifyMediaSession(pxLeg,pxPeer,
											pxCnxt->iResId, IFX_FALSE, peReason);
		/*LEC Disable*/
		eMmgrRet = IFX_MMGR_LecDisable(pxCnxt->iResId);
		eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
		if(IFX_SUCCESS!=eRet)
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "LEC DISABLE FAILED");
		}
		/* Stop RTP Session */ 
		IFX_CMGR_StopMediaSession(pxLeg);
		/*Start FAX session*/
		IFX_CMGR_InvokeStartFaxSession(pxLeg,pxVoipLegInfo->szDevChannelName);
		/* Reset the ENABLE_FAX flag*/
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_ENABLE_FAX);
		/* Return the API*/
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		*peReason = IFX_MAX_REASON;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
#endif
	
	/* Copy the codecs from the Peer Extn Leg into SEND Codecs and Neg Codecs*/
	if(pxPeer == NULL)
		return IFX_FAILURE;
	ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
	pxSendCodecs = &xSendMedia.uxMediaParams.xExtnMediaParams.xCodecParams;
	memset(&xSendMedia,0,sizeof(x_IFX_CMGR_MediaParams));
	xSendMedia.eAgentType = ePeerType;

	/*Check if the peer type is EXTN. ReOrder codecs on this logic.*/
	if(IFX_CMGR_TYPE_EXTN == ePeerType)
	{
		IFX_CMGR_ReOrderCodecsForWB(&pxVoipLegInfo->xNegCodecInfo,
																		&pxExtnLegInfo->xTempCodecInfo,IFX_FALSE);
	}
	
	memcpy(pxSendCodecs ,&pxExtnLegInfo->xTempCodecInfo,
						 			sizeof(x_IFX_CMGR_CodecParams));	
	memcpy( &pxExtnLegInfo->xNegCodecInfo ,&pxExtnLegInfo->xTempCodecInfo,
						 			sizeof(x_IFX_CMGR_CodecParams));	
	memset( &pxExtnLegInfo->xTempCodecInfo, 0, 
							 sizeof(x_IFX_CMGR_CodecParams));
	/* Invoke ModifyMedia*/
	eRet = IFX_CMGR_InvokeMediaSession(pxLeg,
									 pxCnxt->iResId, bRtpDiffer, peReason);
	IFX_CMGR_InvokeMediaNegRsp(pxPeer, pxMedia, *peStatus, *peReason);
	memset( &pxExtnLegInfo->xTempCodecInfo, 0, 
							 sizeof(x_IFX_CMGR_CodecParams));
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleVoipIntMediaNegReq
 *  Description     : Function handles Voip to Internal media negotiation req
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleVoipIntMediaNegReq(
					 			x_IFX_CMGR_CallLeg* pxLeg,
								x_IFX_CMGR_CallLeg* pxPeer,
								IN_OUT x_IFX_CMGR_MediaParams* pxMedia,
								OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	e_IFX_CMGR_CallType ePeerType =  0;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;/*Voip Leg owner Info*/
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;/*Extn Leg owner Info*/
	x_IFX_CMGR_CodecParams* pxRecvCodecs = NULL;
	x_IFX_CMGR_RtpParams* pxRecvRtp = NULL;
	x_IFX_CMGR_FaxParams* pxRecvFax = NULL;
	x_IFX_CMGR_MediaParams xSendMedia;
	x_IFX_CMGR_CodecParams* pxSendCodecs = NULL;
	boolean bMatched = IFX_TRUE;
	boolean bRtpDiffer = IFX_FALSE;
	x_IFX_CMGR_CodecParams* pxCodecList = NULL;
	e_IFX_MMGR_Return eMmgrRet = 0;
	uint8 ucVoipLineId = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	*peStatus = IFX_CMGR_STATUS_PENDING;
	
	if(pxPeer)
		ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
	
	pxVoipLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		 
	pxRecvCodecs = &pxMedia->uxMediaParams.xVoipMediaParams.xCodecParams;
	pxRecvRtp = &pxMedia->uxMediaParams.xVoipMediaParams.xRtpParams;
	pxRecvFax = pxMedia->uxMediaParams.xVoipMediaParams.axFaxParams;
	ucVoipLineId = pxVoipLegInfo->ucLineId;

	/*Check if RTP differs*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(
								 &pxVoipLegInfo->xNegRtpParams,pxRecvRtp);
	/*Invoke MatchMediaParams*/
	bMatched = IFX_CMGR_MatchMediaParams(&pxVoipLegInfo->xOfferedCodecInfo,
		pxRecvCodecs, &pxVoipLegInfo->xNegRtpParams, pxRecvRtp, 
		&pxVoipLegInfo->xTempCodecInfo, &pxVoipLegInfo->xTempRtpParams);
	
	if(IFX_TRUE == bMatched)
	{	
		/* Check if the remote negotiation is needed?*/
		if(IFX_FALSE == IFX_CMGR_PeerNegNeeded(pxLeg, pxPeer, pxMedia))
		{
			/*Copy the accepted codecs & RTP into their right places*/
			memcpy(&pxVoipLegInfo->xNegCodecInfo,
				&pxVoipLegInfo->xTempCodecInfo, sizeof(x_IFX_CMGR_CodecParams));
			memcpy(&pxVoipLegInfo->xNegRtpParams,
				&pxVoipLegInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
#ifdef FAX_SUPPORT
			/* Check if the MPC is a T.38 codec.*/
			pxCodecList = &pxVoipLegInfo->xTempCodecInfo;
			if(IFX_TRUE == IFX_CMGR_IsPrefCodecT38(pxCodecList))
			{	
				uint32 uiTrProto = 0;
				/* Get Info from CIF regarding FAX - Save in local Fax Params*/
				uiTrProto = (pxCodecList->axCodec[0].uiCodec == IFX_T38_TCP)?
																					IFX_TRPROTO_TCP:IFX_TRPROTO_UDP;	
				IFX_LMGR_GetFaxParams( ucVoipLineId, 
												uiTrProto, pxVoipLegInfo->axFaxParams);
				
				/* Start Handling the FAX media negotation*/
				eRet  = IFX_CMGR_HandleFaxMediaNeg(pxLeg,pxCodecList,
																	pxVoipLegInfo->axFaxParams,pxRecvFax);
				/* Start Listening on the FAX TCP local server port before 
					 giving a response to SIP, if the MPC is T.38 TCP*/
				if(IFX_T38_TCP == pxCodecList->axCodec[0].uiCodec)
				{
					IFX_CMGR_InvokeFaxServerListen(pxLeg, IFX_FALSE);
				}
				
				/*LEC Disable*/
				eMmgrRet = IFX_MMGR_LecDisable(pxCnxt->iResId);
				eRet = IFX_CMGR_MapMmgrReturn(eMmgrRet,peReason);
				/* Update Codecs with T.38*/
				IFX_CMGR_ModifyMediaSession(pxLeg,pxPeer,
												pxCnxt->iResId, IFX_FALSE, peReason);
				/* Stop RTP Session */ 
				IFX_CMGR_StopMediaSession(pxLeg);	
				/*Start FAX session*/
				IFX_CMGR_InvokeStartFaxSession(pxLeg,pxVoipLegInfo->szDevChannelName);
				/* Reset the ENABLE_FAX flag*/
				IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_ENABLE_FAX);
				/*Copy the Codecs in the return value*/	
			}else
#endif
			{
				/*Media Cfg only makes sense if the call is connected*/
				if((!IFX_CMGR_GET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CNXT_IN_FORKING)) 
					|| (IFX_TRUE == IFX_CMGR_IsCallConn(pxLeg)))
				{
					/*Invoke Start/Modify Media Session*/
					eRet = IFX_CMGR_InvokeMediaSession(pxLeg,
											 pxCnxt->iResId, bRtpDiffer, peReason);
					if(IFX_FAILURE == eRet)
					{	
						IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
						return eRet;
					}
				}
			}	
			/* Copy codecs into the pxMedia*/
			memset(pxRecvCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
			memset(pxRecvRtp,0,sizeof(x_IFX_CMGR_RtpParams));
			memset(pxRecvFax,0,IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
			memcpy(pxRecvCodecs, &pxVoipLegInfo->xTempCodecInfo,
								 												sizeof(x_IFX_CMGR_CodecParams));
			memcpy(pxRecvRtp, &pxVoipLegInfo->xTempRtpParams,
																	 				sizeof(x_IFX_CMGR_RtpParams));
#ifdef FAX_SUPPORT
			memcpy(pxRecvFax, pxVoipLegInfo->axFaxParams,
								 				IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));
#endif
			/*Return status as SUCCESS*/
			*peStatus = IFX_CMGR_STATUS_SUCCESS;
			/* Clear the temp codecs etc*/
			memset(&pxVoipLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
			memset(&pxVoipLegInfo->xTempRtpParams,0,sizeof(x_IFX_CMGR_RtpParams));
			/*Inform the NA about the status*/
			*peStatus = IFX_CMGR_STATUS_SUCCESS;
			*peReason = IFX_MAX_REASON;
		}
		else
		{	/* Remote Neg is needed*/
			if(IFX_CMGR_TYPE_EXTN == ePeerType)
			{	/* Populate the xSendMedia*/
				memset(&xSendMedia,0,sizeof(x_IFX_CMGR_MediaParams));
				xSendMedia.eAgentType = ePeerType;
				/* Prepare xSendMedia and populate with codecs in the NegExtnLeg/Offered
				 * Leg*/
				pxExtnLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
				pxSendCodecs = &xSendMedia.uxMediaParams.xExtnMediaParams.xCodecParams;
				/* Copy offered codecs into xSendMedia*/
				memcpy(&pxExtnLegInfo->xTempCodecInfo,	
					&pxExtnLegInfo->xOfferedCodecInfo, sizeof(x_IFX_CMGR_CodecParams));
				/* re-arrange order of codecs in xTempCodecInfo*/
				IFX_CMGR_ReOrderCodecsForWB(&pxVoipLegInfo->xTempCodecInfo,
																		&pxExtnLegInfo->xTempCodecInfo,IFX_FALSE);
				/*Copy codecs into the location that is to be offered*/
				memcpy(pxSendCodecs,	&pxExtnLegInfo->xTempCodecInfo,
									 						sizeof(x_IFX_CMGR_CodecParams));
				/*Invoke MediaNegReq*/			
				IFX_CMGR_InvokeMediaNegReq(pxPeer,&xSendMedia,peStatus,peReason);
				if(IFX_CMGR_STATUS_FAIL == *peStatus)
				{
					/*DEBUG -  Failed means that the peer did not accept ANY CODECS*/
					IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
					return eRet;
				}else
				if(IFX_CMGR_STATUS_SUCCESS == *peStatus)
				{
					/*ReOrder Temp Codecs on the Voip Side Looking at the Codecs Returned from
					 Extn*/
					IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xTempCodecInfo,
							&pxVoipLegInfo->xTempCodecInfo,IFX_FALSE);
					/*Copy Extn Side Codecs into Neg Codecs & clear Extn side temp codes*/
					memcpy(&pxExtnLegInfo->xNegCodecInfo,
						&pxExtnLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
					memset(&pxExtnLegInfo->xTempCodecInfo,
																				0,sizeof(x_IFX_CMGR_CodecParams));
					/*Copy the Temp Codecs on the Voip Side into the Neg Codecs*/
					memcpy(&pxVoipLegInfo->xNegCodecInfo,
						&pxVoipLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
					memset(&pxVoipLegInfo->xTempCodecInfo,
																				0,sizeof(x_IFX_CMGR_CodecParams));
					/*Copy into the pxRecvCodecs the Neg Voip Codecs*/
					memcpy(pxRecvCodecs,
						&pxVoipLegInfo->xNegCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
					/*Copy the accepted codecs & RTP into their right places*/
				  memcpy(&pxVoipLegInfo->xNegRtpParams,
				 	 			&pxVoipLegInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
					memcpy(pxRecvRtp,
									&pxVoipLegInfo->xTempRtpParams,sizeof(x_IFX_CMGR_RtpParams)); 
					memset(&pxVoipLegInfo->xTempRtpParams,0,sizeof(x_IFX_CMGR_RtpParams));
					
				 	/* Invoke Modify Media Params*/
				 	eRet = IFX_CMGR_InvokeMediaSession(pxLeg,
																 pxCnxt->iResId, bRtpDiffer, peReason);
				}
			}
		}
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Nothing Matching");
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleIntVoipMediaNegRsp
 *  Description     : Function handles  Internal to Voip media neg response
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleIntVoipMediaNegRsp(
					 			x_IFX_CMGR_CallLeg* pxLeg,
								x_IFX_CMGR_CallLeg* pxPeer,
								IN x_IFX_CMGR_MediaParams* pxMedia,
								IN_OUT e_IFX_CMGR_Status* peStatus,
					 			IN_OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	e_IFX_CMGR_CallType ePeerType =  0;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;/*Voip Leg owner Info*/
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = NULL;/*Extn Leg owner Info*/
	x_IFX_CMGR_CodecParams* pxRecvCodecs = NULL;
	x_IFX_CMGR_MediaParams xSendMedia;
	x_IFX_CMGR_CodecParams* pxSendCodecs = NULL;
	x_IFX_CMGR_RtpParams* pxSendRtp = NULL;
	//boolean bMatched = IFX_TRUE;
	boolean bRtpDiffer = IFX_FALSE;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	pxExtnLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	pxVoipLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		 
	pxRecvCodecs = &pxMedia->uxMediaParams.xExtnMediaParams.xCodecParams;
	pxSendCodecs = &xSendMedia.uxMediaParams.xVoipMediaParams.xCodecParams;
	pxSendRtp = &xSendMedia.uxMediaParams.xVoipMediaParams.xRtpParams;
	ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
			  
	if(IFX_CMGR_STATUS_SUCCESS == *peStatus)
	{			  
		/*Invoke MatchMediaParams*/
		/*bMatched =*/ IFX_CMGR_MatchMediaParams(&pxExtnLegInfo->xTempCodecInfo,
								pxRecvCodecs,NULL, NULL, &pxExtnLegInfo->xNegCodecInfo,NULL);
		memset(&pxExtnLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	}
	
	/*Check if the Flag for NO Response to PEER is set? If so then
	 return the API with status SUCCESS*/
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER))
	{
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
						
	/*Do some work for the VOIP leg also!*/
	/*Check if RTP differs*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(&pxVoipLegInfo->xNegRtpParams,
								 &pxVoipLegInfo->xTempRtpParams);
	/*Re-Order Codecs For WB*/
	IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xNegCodecInfo,
														&pxVoipLegInfo->xTempCodecInfo,IFX_FALSE);
	/*Copy the accepted codecs & RTP into their right places*/
	memcpy(&pxVoipLegInfo->xNegCodecInfo,
		&pxVoipLegInfo->xTempCodecInfo, sizeof(x_IFX_CMGR_CodecParams));
	memcpy(&pxVoipLegInfo->xNegRtpParams,
		&pxVoipLegInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
	/* Invoke Modify Media Params*/
	eRet = IFX_CMGR_ModifyMediaSession(pxPeer,pxLeg, 
							 pxCnxt->iResId, bRtpDiffer, peReason);
	/*Make the xSendMedia*/
	memset(&xSendMedia,0,sizeof(x_IFX_CMGR_MediaParams));
	xSendMedia.eAgentType = ePeerType;
	/* Inform the remote party with the final set of codecs / rtp*/
	memcpy(pxSendCodecs, 
		&pxVoipLegInfo->xNegCodecInfo, sizeof(x_IFX_CMGR_CodecParams));
	memcpy(pxSendRtp, 
		&pxVoipLegInfo->xNegRtpParams, sizeof(x_IFX_CMGR_RtpParams));
	/* Inform the peer*/	
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	IFX_CMGR_InvokeMediaNegRsp(pxPeer, pxMedia, *peStatus, *peReason);
	memset( &pxVoipLegInfo->xTempCodecInfo, 0, 
							 sizeof(x_IFX_CMGR_CodecParams));
	memset( &pxVoipLegInfo->xTempRtpParams, 0, 
							 sizeof(x_IFX_CMGR_RtpParams));
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleIntIntMediaNegReq
 *  Description     : Function handles Internal to Internal media neg request
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleIntIntMediaNegReq(
					 			x_IFX_CMGR_CallLeg* pxLeg,
								x_IFX_CMGR_CallLeg* pxPeer,
								IN_OUT x_IFX_CMGR_MediaParams* pxMedia,
								OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	boolean bMatched = IFX_FALSE;
	x_IFX_CMGR_MediaParams xSendMedia = {0};
	x_IFX_CMGR_CodecParams *pxLegCodecs,/**pxPeerCodecs,*/*pxRecvCodecs,*pxSendCodecs;
	pxLegCodecs = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.
																xExtnLegInfo.xOfferedCodecInfo;
	/*pxPeerCodecs = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.
																xExtnLegInfo.xOfferedCodecInfo;*/
	x_IFX_CMGR_ExtnLegInfo *pxExtnLegInfo, *pxPeerLegInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	pxExtnLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	pxPeerLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	pxRecvCodecs = &pxMedia->uxMediaParams.xExtnMediaParams.xCodecParams;
	pxSendCodecs = &xSendMedia.uxMediaParams.xExtnMediaParams.xCodecParams;

	/*Get the intersection of the codecs and save them into a temp location*/
	bMatched = IFX_CMGR_MatchMediaParams(pxLegCodecs,pxRecvCodecs,
								NULL,NULL, &pxExtnLegInfo->xTempCodecInfo,NULL);
	if(IFX_FALSE == bMatched)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Check if peer negotiation is needed or not?*/
	if(IFX_TRUE == IFX_CMGR_PeerNegNeeded(pxLeg,pxPeer,pxMedia))
	{
		/*Copy the codecs from Offered List into the Temp List on the peer leg*/
		memset(&pxPeerLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
		memcpy(&pxPeerLegInfo->xTempCodecInfo,
							&pxPeerLegInfo->xOfferedCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
		/*Re-Order the temp codecs in the Peer Leg so that the WB codec is on top*/
		IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xTempCodecInfo,
																	&pxPeerLegInfo->xTempCodecInfo,IFX_FALSE);
		/*Copy the Temp Codecs into the Media to be sent*/
		memcpy(pxSendCodecs,
							&pxPeerLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
		/*Initiate a Peer Neg procedure for the other extension*/
		IFX_CMGR_InvokeMediaNegReq(pxPeer,&xSendMedia,peStatus,peReason);	
	}
	else
	{
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		/*Copy the Temp codecs into the Negotiated Codecs list*/
		memset(&pxExtnLegInfo->xNegCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
		memcpy(&pxExtnLegInfo->xNegCodecInfo,
						&pxExtnLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
		/*Copy the same into the pxMedia for the initiator to use*/
		memset(pxRecvCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
		memcpy(pxRecvCodecs,
							&pxExtnLegInfo->xNegCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
		/*Clear the temp codecs*/
		memset(&pxExtnLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleIntIntMediaNegRsp
 *  Description     : Function handles Internal to Internal media neg response
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleIntIntMediaNegRsp(
					 			x_IFX_CMGR_CallLeg* pxLeg,
								x_IFX_CMGR_CallLeg* pxPeer,
								IN x_IFX_CMGR_MediaParams* pxMedia,
								IN_OUT e_IFX_CMGR_Status* peStatus,
					 			IN_OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	boolean bMatched = IFX_FALSE;
	x_IFX_CMGR_MediaParams xSendMedia = {0};
	x_IFX_CMGR_CodecParams /**pxLegCodecs,*pxPeerCodecs,*/*pxRecvCodecs,*pxSendCodecs;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	/*pxLegCodecs = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.
																xExtnLegInfo.xOfferedCodecInfo;
	pxPeerCodecs = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.
																xExtnLegInfo.xOfferedCodecInfo;*/
	x_IFX_CMGR_ExtnLegInfo *pxExtnLegInfo, *pxPeerLegInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	pxExtnLegInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	pxPeerLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		 
	pxRecvCodecs = &pxMedia->uxMediaParams.xExtnMediaParams.xCodecParams;
	pxSendCodecs = &xSendMedia.uxMediaParams.xExtnMediaParams.xCodecParams;
	/*Make Sure the status is Success/Failure */	
	if(IFX_CMGR_STATUS_PENDING == *peStatus)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Match the pxRecvCodecs against the pxLeg->TempCodecs*/
	bMatched = IFX_CMGR_MatchMediaParams(&pxExtnLegInfo->xTempCodecInfo,
								pxRecvCodecs,NULL,NULL,&pxExtnLegInfo->xNegCodecInfo,NULL);
	if((!pxRecvCodecs->unNoOfCodecs) || 
				(IFX_CMGR_STATUS_FAIL == *peStatus) || (IFX_FALSE == bMatched))	
	{
		eRet = IFX_FAILURE;
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Clear the Temp Codecs*/
	memset(&pxExtnLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	/*Check if the Flag for NO Response to PEER is set? If so then
	 return the API with status SUCCESS*/
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER))
	{
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/*Set values for the peer party*/
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason = IFX_MAX_REASON;

	/*Re Order the Temp Codecs before returning them to the Neg Initiator*/
	IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xNegCodecInfo,
																	&pxPeerLegInfo->xTempCodecInfo,IFX_FALSE);
	
	/*Return temp codecs in the peer leg after copying then into Neg codecs*/
	memset(&pxPeerLegInfo->xNegCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	memcpy(&pxPeerLegInfo->xNegCodecInfo,
						&pxPeerLegInfo->xTempCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
	memset(&pxPeerLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	memcpy(pxSendCodecs,
						&pxPeerLegInfo->xNegCodecInfo,sizeof(x_IFX_CMGR_CodecParams));
	/*Invoke the MediaNegRsp on the peer to inform it about the outcome*/
	IFX_CMGR_InvokeMediaNegRsp(pxPeer, &xSendMedia, *peStatus, *peReason);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*! 
    \brief  This API is to be called by the Agent is for an asynchronously
	 			triggered change in media params.
	 			This will be used by NA/DECT agent to change the media during
				a call. It could also be used to change the codecs during 
				reception of a SIP UPDATE Req. 
				In the middle of a call, when the DECT PP offers a new set 
				of codecs to the DECT agent should call this API before
				answering back to the DECT PP. Also used by the NA to start
				FAX.
    \param[in]  uiCallId is the identifier of the call
    \param[in,out] pxMediaParams is the reference to the media parameters.
	\param[out]	peStatus is the status of the Req SUCCESS/FAILED/PENDING
	\param[out]	peReason this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaNegReq(
					 			IN uint32 uiCallId,
								IN_OUT x_IFX_CMGR_MediaParams* pxMedia,
								OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer;
	x_IFX_CMGR_CallContext* pxCnxt;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/* Set initial values*/
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	*peStatus = IFX_CMGR_STATUS_PENDING;
	*peReason = IFX_MAX_REASON;
		
#ifdef FAX_SUPPORT
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
	{	/*If FAX session is going on the do not accept the request*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
#endif
	/*If a transfer is going on, then do not accept Negotiate Request. 
	 Just too tedious!*/
	if(pxCnxt->eTypeOfTransfer)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
										IFX_DBG_STR, "Cannot Neg during Txfer!!");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Check Flag to find if Negotiation is going on? If Flag is set then
	 return API with status FAIL. Else set flag*/
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;	
	}
	/*Set Flag to indicate the media negotiation is going on*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);

	/* the Re-negotiate request came from the Voip party*/
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{	
		eRet = IFX_CMGR_HandleVoipIntMediaNegReq(
							 pxLeg, pxPeer, pxMedia, peStatus, peReason);
	
		/*If status is NOT pending reset Flag to indicate that Negotiation
		 is complete.*/
		if(IFX_CMGR_STATUS_PENDING != *peStatus)
		{
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
		}
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* The intiator is an INT party*/
	if(!pxPeer)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		/*Reset Flag to indicate that Negotiation is complete.*/
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;	
	}
	
	if(IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
	{	/* Int->Voip Media neg*/
		eRet = IFX_CMGR_HandleIntVoipMediaNegReq(
							 pxLeg, pxPeer, pxMedia, peStatus, peReason);
	}
	else
	{	/* Int->Int Media neg*/
		eRet = IFX_CMGR_HandleIntIntMediaNegReq(
							 pxLeg, pxPeer, pxMedia, peStatus, peReason);
	}
	
	/* If status is NOT pending reset Flag to indicate that Negotiation
		is complete.*/
	if(IFX_CMGR_STATUS_PENDING != *peStatus)
	{
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*! 
    \brief  This API is to be called by the Agent to respond to a previously 
	 			done pfn_IFX_CMGR_NegotiateMediaReq. In this the agent has 
				to respond with the final codec(s) negotiated on its respective
				interface. It should be invoked by only the DECT/NA.
    \param[in] uiCallId is the identifier of the call
    \param[in] pxMediaParams is the reference to the media parameters.
	\param[in,out]	peStatus is the status of the Req SUCCESS/FAILED/PENDING
	\param[in,out]	peReason this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaNegRsp(
					 			IN uint32 uiCallId,
								IN x_IFX_CMGR_MediaParams* pxMedia,
								IN_OUT e_IFX_CMGR_Status* peStatus,
					 			IN_OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
	x_IFX_CMGR_CallContext* pxCnxt = NULL;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	/* Set initial values*/
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	/**peStatus = //Commented by Mahipati
		(*peStatus == IFX_CMGR_STATUS_FAIL)?IFX_CMGR_STATUS_FAIL:IFX_CMGR_STATUS_PENDING; */
	*peReason = IFX_MAX_REASON;
	
	/*Check Flag to see if any negotiaton is pending (Flag is set)? 
		If not then return API with status failure. If set the reset the FLAG.*/
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG))
	{
		/*Reset Flag to indicate the media negotiation is done*/
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
	}
	else
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;	
	}

	/* Response is from a Voip Party*/
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{	
		eRet = IFX_CMGR_HandleVoipIntMediaNegRsp(
							 pxLeg, pxPeer, pxMedia, peStatus, peReason);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* The response is from an INT party before the call went into CONV.*/
	if(!pxPeer)
	{	
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}		  
			  
	if(IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
	{	/* Int->Voip Media neg response*/
		eRet = IFX_CMGR_HandleIntVoipMediaNegRsp(
							 pxLeg, pxPeer, pxMedia, peStatus, peReason);
	}
	else
	{	/* Int->Int Media neg response*/
		eRet = IFX_CMGR_HandleIntIntMediaNegRsp(
							 pxLeg, pxPeer, pxMedia, peStatus, peReason);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleRepIncCall
 *  Description     : Function handles a replaces incoming call in C side ATX
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleRepIncCall(
					 OUT uint32 *puiCallId,
					 IN uint32 uiRepCallId,
					 IN x_IFX_CMGR_AddressInfo *pxFrom, 
					 IN x_IFX_CMGR_AddressInfo *pxTo, 
					 IN_OUT x_IFX_CMGR_CallParams *pxPar, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 IN void* pvPrivateData)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiRepCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallLeg* pxNew = NULL;
	//uint32 uiNewCallId = 0;
	uint8 ucVoipLineId =0 ;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;
	x_IFX_CMGR_CodecParams xCodecs;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	
	/*
	 * Check if the pxFrom is NA else return failure. Search for the CC/CL 
	 * pertaining to the Replaces Call-Id. If the CL's & its peer CL's state is not 
	 * CONV, then reject the call with status Failure. Call a FreeResource API
	 * and then call ReserveResource API with the new codec list that is the 
	 * intersection of the VLs codec list & one offered by the NA in the 
	 * CallParams. After determining the SDP params to answer with the current 
	 * IN CL has to be released. For doing so the CMGR
	 * finds the pfnRemCallRelease function from the IN CL's CB structure and 
	 * invokes it with reason IFX_CMGR_CALL_REPLACED. After doing this, a new 
	 * CL as to be populated with the new information of the new RV party & the
	 * RTP agent has to be invoked with the new RTP port/IP using RtpSessionStart.
	 * The Call-Id is used for this new leg. The CallInitiate API 
	 * is returned with STATUS success. This completes the C side ATx.
	 */
	if(!pxCnxt || !pxLeg || 
		(IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	if(
		//(IFX_CMGR_STATE_CONV != pxLeg->eCurrState)||
	(IFX_CMGR_STATE_CONV != pxPeer->eCurrState) // Bug number 4
					)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* From LMGR find the local Codecs*/
	memset(&xCodecs,0,sizeof(x_IFX_CMGR_CodecParams));
	ucVoipLineId = pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId;	
	eRet = IFX_LMGR_GetCodecsForLine(ucVoipLineId, &xCodecs, peReason);
	/*Check for Media Mismatch*/
	if(IFX_FALSE == IFX_CMGR_DoesMediaMatch( &xCodecs,
			&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams))
	{
		*peReason = IFX_MEDIA_MISMATCH;
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* Invoke Stop Session for this call*/
	IFX_CMGR_StopMediaSession(pxLeg);			
	/*Invoke Remote Call Release on the pxLeg*/
	IFX_CMGR_InvokeRemoteCallRelease(pxLeg, IFX_TERMINATED, NULL);
	
	if(IFX_CMGR_OUT == pxLeg->eDirection)
	{
		/* Free the Resource Id for this call*/
		eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
									pxLeg->xLegOwnerInfo.szEndptId, 
										pxPeer->xLegOwnerInfo.szEndptId, peReason);
	}
	else
	{
		/* Free the Resource Id for this call*/
		eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
									pxPeer->xLegOwnerInfo.szEndptId, 
									pxLeg->xLegOwnerInfo.szEndptId, 	peReason);
	}
	pxCnxt->iResId = 0;
	/* Get a new Call Leg*/
	eRet = IFX_CMGR_GetCallLeg(IFX_CMGR_FindCallCnxtIdx(pxCnxt),&pxNew);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_DoRepCallCommonActions();
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}				
	IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxLeg, pxNew);
	/* Copy all the information in the leg*/	
	//uiNewCallId = pxNew->uiCallId;
	pxNew->pxCallBackList = pxLeg->pxCallBackList;
	pxNew->pxRtpCB = pxLeg->pxRtpCB;
#ifdef FAX_SUPPORT
	pxNew->pxFaxCB = pxLeg->pxFaxCB;
#endif
	pxNew->xLegOwnerInfo.eOwnerType = 
			  pxLeg->xLegOwnerInfo.eOwnerType;
	pxNew->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId = 
			  pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId;
	ucVoipLineId = pxNew->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId;
	pxVoipLegInfo =
			&pxNew->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		  
	strcpy(pxNew->xLegOwnerInfo.szEndptId, pxLeg->xLegOwnerInfo.szEndptId);
	pxNew->pvPrivateData = pvPrivateData;	
	
	/*Set context to the current one*/
	pxNew->pxCurrCnxt = pxCnxt;
	IFX_CMGR_DeAllocCallLeg(pxLeg);

	/* Get the Voip Line Information for the Line - save in the call leg*/
	eRet = IFX_LMGR_GetInfoForVoipCall(ucVoipLineId, pxVoipLegInfo, peReason);	
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_DoRepCallCommonActions();
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}
	
	/*Set the peer pointers*/
	pxNew->pxPeer = pxPeer;
	pxPeer->pxPeer = pxNew;

	/*Save the remote Voip address in the Leg info*/
	memcpy(&pxVoipLegInfo->xRemAddr, &pxFrom->uxAddressInfo.xVoipAddr,
						 sizeof(x_IFX_CMGR_VoipAddr));	

	/* Apply offer answer logic on the Leg*/
	IFX_CMGR_MakeSdpForIncVoipCall(pxNew, pxPeer, 
				&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xCodecParams,
				&pxPar->uxCallParams.xVoipParams.xVoipMediaParams.xRtpParams
#ifdef FAX_SUPPORT
				,pxPar->uxCallParams.xVoipParams.xVoipMediaParams.axFaxParams,
				IFX_MAX_FAX_PROTO
#endif
				);
	
	/*Get new Media resource*/
	eRet = IFX_CMGR_GetMediaResVoipInt(&pxCnxt->iResId, pxNew,
						 							pxPeer, peStatus, peReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_DoRepCallCommonActions();
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}
	/* return with status success*/
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason = IFX_CALL_ANSWERED;

	/*Check if we recieved the Offer or not? If not then just 
		wait else start media*/
	if(pxVoipLegInfo->eNegStatus != IFX_CMGR_OFFER_SENT)
	{
		/*Start Media Sesison*/
		eRet = IFX_CMGR_StartMediaSession(pxNew, pxCnxt->iResId, peReason);
		if(IFX_FAILURE == eRet)
		{
			IFX_CMGR_DoRepCallCommonActions();
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet; 
		}
	}
	else
	{
		/*NO SDP OFFER - Reset flag to indicate the when both SDPs are available, 
			then Media Session has to be started*/
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE);
	}
	/*Change OUT and IN states to CONV*/
	IFX_CMGR_ChangeState(pxPeer,IFX_CMGR_STATE_CONV,0);
	IFX_CMGR_ChangeState(pxNew,IFX_CMGR_STATE_CONV,0);
	*puiCallId = pxNew->uiCallId;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

#ifdef MESSAGE_SUPPORT
x_IFX_Msg_Hndls vxMsgHndls[IFX_MAX_MSG_HDL];
/********************************************************************************
*Function Name: This funcitons retrives list of all lines,endpoint is attahced
								to. OUT parameter is reference to an array - ucahr8 acLineId[IFX_MAX_LINES]
*Parameters
*
*
*********************************************************************************/

e_IFX_Return IFX_CMGR_GetLineInfo(IN  char8 *pcEndPtId,
																  OUT uchar8 *pucLineId)
{

}

/********************************************************************************
*Function Name: All messages (INBOX/OUTBOX) would be retrived for the given 
								line. MsgInfo is reference to array of structure, 
								&xMsgInfo[IFX_MAX_MSG]. puiCount indicates total number of messages.
								received for that line.
*Parameters
*
*
*********************************************************************************/
e_IFX_Return IFX_CMGR_Msg_GetHdrs(IN  uchar8 uiLineId,
														      IN  e_IFX_MsgBox eBox,
															    OUT x_IFX_CMGR_Msg_Info	*pxMsgInfo,
															    OUT uint16* puiCount)
{
	 int32 i =0;
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
   if(!pxMsgInfo || !(IFX_MSG_IN ==eBox || IFX_MSG_OUT ==eBox) || !puiCount){
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
					     "Invalid Hdls");
		  return IFX_FAILURE;
	 }
	 
	 if(IFX_FAILURE == IFX_CFG_GetAllMsgHdrs(uiLineId,eBox,pxMsgInfo,puiCount)) {
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
					     "CFG GetAllMsgHdrs Failed");
			return IFX_FAILURE;
	 }
	 /*Debugs*/
#if 0
	 for(i=0; i< *puiCount;i++){
		  printf("SMS No [%d] ---> Read = %d,Handle = %d, From =%s, Hdr =%s \n",
					    i,pxMsgInfo[i].bMsgUnread,pxMsgInfo[i].uiMsgHdl,
							pxMsgInfo[i].acUserName,pxMsgInfo[i].szMsgBody);
	 }
#endif
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Success");
	 return IFX_SUCCESS;
}

/********************************************************************************
*Function Name: 
*Parameters
*
*
*********************************************************************************/

e_IFX_Return IFX_CMGR_Msg_Read(IN uchar8 uiLineId,
															 IN uint32 uiMsgHdl,
															 OUT x_IFX_CMGR_Msg_Info	*pxMsgInfo)

{
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entery");
   if(0==uiLineId || 0==uiMsgHdl || NULL==pxMsgInfo){
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
				      "Invalid Hdls");
		 return IFX_FAILURE;
	 }
	 
	 if(IFX_FAILURE == IFX_CFG_GetMsg(uiLineId,uiMsgHdl,pxMsgInfo)){
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
					     "Failed");
		 return IFX_FAILURE;
	 }
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Success");
	 return IFX_SUCCESS;
}

/********************************************************************************
*Function Name:
*Parameters
*
*
*********************************************************************************/

e_IFX_Return IFX_CMGR_Msg_Delete(IN uchar8 uiLineId,
																 IN uint32 uiMsgHdl)

{
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entery");
   if(0==uiLineId || 0==uiMsgHdl){
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
				      "Invalid Hdls");
		 return IFX_FAILURE;
	 }
	 if(IFX_FAILURE == IFX_CFG_DeleteMsg(uiLineId,uiMsgHdl)){
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
					     "Failed");
	 }
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Success");
	 return IFX_SUCCESS;
}
/********************************************************************************
*Function Name:
*Parameters
*
*
*********************************************************************************/

e_IFX_Return IFX_CMGR_Msg_CheckCapab(IN x_IFX_CMGR_AddressInfo *pxFrom,
																		 IN x_IFX_CMGR_AddressInfo *pxTo)
{
	x_IFX_CMGR_CallBackList* pxCallBackList = NULL;	 
/*	
	if(IFX_CMGR_GetCBList(pxFrom->uxAddressInfo.szEndptId,&pxCallBackList) 
		 == IFX_FAILURE ||(pxCallBackList->pfnMsgRcv==NULL)){
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No CallBack for FROM");
		  return IFX_FAILURE; 
	 }	 
	 
	if(IFX_CMGR_GetCBList(pxTo->uxAddressInfo.szEndptId,&pxCallBackList) 
			== IFX_FAILURE || (pxCallBackList->pfnMsgRcv==NULL)){
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No CallBack for TO");
		  return IFX_FAILURE;
	 } */
	return IFX_SUCCESS;
}


/*****************************************************************************
 *  Function Name   : Likely to be invoked by VoIP agent to notify that SMS status.
 											uiMsgHdl is generated  by CFG during store (OUTBOX). 
											Before proecssing ReqId needs to be retrived.
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/


e_IFX_Return  IFX_CMGR_Msg_Status(IN uint32 uiMsgHdl,
		                              IN e_IFX_CMGR_Status eStatus)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 uiReqId =0,i=0;
	x_IFX_CMGR_ReqLeg* pxLeg=NULL,  *pxPeer=NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
# if 0
	for(int i=0;i< IFX_MAX_MSG_HDL;i++){
		 if(uiMsgHdl == vxMsgHndls[i].uiMsgHdl){
			 uiReqId = vxMsgHndls[i].uiReqId;
			 break;
	}
#else
		uiReqId = uiMsgHdl;
#endif
	pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);
	if(!pxLeg || !uiMsgHdl){
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;	
	}
  
	if(IFX_CMGR_IsIdValid(uiReqId,IFX_FALSE)== IFX_FAILURE ||!(uiReqId)){
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				     "Invalid ReqId");
		return IFX_FAILURE;
	}	
	pxPeer = pxLeg->pxPeer;

	if(pxPeer->pxCallBackList->pfnMsgStatus){
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Invoking SMS Status CB");
		pxPeer->pxCallBackList->pfnMsgStatus(uiReqId,eStatus);
	}
	else{
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "NO SMS Status CB Found");
	}	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
  IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);		
	/*Free MsgHdls*/
#if 0	
	vxMsgHndls[i].uiMsgHdl = 0;
	vxMsgHndls[i].uiReqId = 0;
#endif	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : This API is used to send SMS from DECT/FXS to VoIP party. 
 											Currnetly FXS does not support IM. All messages sent to 
											VoIP line will be stored in Line's OUTBOX. Once SMS is sent 
											VoIP agent may notify SMS status asynchronously using MsgHld.
											Message Handle, generated by CFG during store OUTBOX should 
											be used to identify transaction. Since CFG does not provide 
											OUTBOX facility, so ReqId will be used.Upon receving response 
											from VoIP, Request Leg will be freed. ReqId is reference to 
											Request Leg structure. Receving Agent will also get LineId 
											on which SMS is received.							
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/


e_IFX_Return IFX_CMGR_Msg_ExtnVoipSend(	IN x_IFX_CMGR_AddressInfo *pxFrom,
																				IN x_IFX_CMGR_AddressInfo *pxTo,
														      			IN char8* szSmsBody,
																				OUT uint32* puiSmsId,
																				OUT e_IFX_CMGR_Status* peStatus,
																        OUT e_IFX_ReasonCode* peReason)

{
	e_IFX_Return eRet = IFX_FAILURE;
	boolean bIsReg = IFX_FALSE;
	
	uint8 ucVoipLineId = 0;
	uint8 ucNumReqLegs = 2;
	uint8 ucValidLegs = 0;	
  x_IFX_CMGR_Msg_Info xMsgInfo;	 
	char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN] = {"",IFX_NA_ENDPT_ID};

	x_IFX_CMGR_ReqContext* pxCnxt;
	x_IFX_CMGR_ReqLeg* 	pxOut,*pxIn;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	memset(&xMsgInfo,0,sizeof(x_IFX_CMGR_Msg_Info));
  *peReason = IFX_MAX_REASON;	
	*peStatus = IFX_PENDING;

	eRet = IFX_LMGR_GetEndptDefaultVoipLine(pxFrom->uxAddressInfo.szEndptId, 
				                                  &ucVoipLineId,&bIsReg, peReason);
  
	if((IFX_FAILURE == eRet) || !ucVoipLineId){
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				      "Could Not get default voip line for given Endpoint");
		return IFX_FAILURE;	 
	 } 
	 
	 if (IFX_CMGR_Msg_CheckCapab(pxFrom,pxTo) == IFX_FAILURE) {
		 IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		 return IFX_FAILURE;
	 }	
	 /* Call IFX_CMGR_GetReqCnxtAndLegs*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(
			               ucNumReqLegs,NULL,&pxCnxt, peReason)) {
		  IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		  return IFX_FAILURE;
	 }
	
	strcpy(aszEndptId[0],pxFrom->uxAddressInfo.szEndptId);
	
	if(IFX_FAILURE ==	IFX_CMGR_PrepReqCnxt(pxCnxt,aszEndptId, 
			              ucNumReqLegs,&ucValidLegs)){
		 IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		 return IFX_FAILURE;
	 }

	pxCnxt->eReqType = IFX_CMGR_REQ_SMS;
	pxCnxt->uxReqCnxt.xSmsInfoInt.unVoipLineId = ucVoipLineId;
	pxOut = IFX_CMGR_GetOutReqLeg(pxCnxt);
	pxIn = IFX_CMGR_GetInReqLeg(pxCnxt);

	/*Set Peer Pointers*/
	pxOut->pxPeer = pxIn;
	pxIn->pxPeer = pxOut;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Invoking SMS Send CB");
	if(pxIn->pxCallBackList->pfnMsgRcv){
	x_IFX_CMGR_VoipLegInfo xVoipLegInfo = {0};	
	x_IFX_CMGR_AddressInfo xFrom;
	
	eRet = IFX_LMGR_GetInfoForVoipCall(ucVoipLineId, &xVoipLegInfo, peStatus);
	if(IFX_FAILURE == eRet){
	   IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		 return IFX_FAILURE;
  }
	
	/* Form the pxFrom*/
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	xFrom.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xFrom.uxAddressInfo.xVoipAddr,&xVoipLegInfo.xLocalVlAddr,
  		   sizeof(x_IFX_CMGR_VoipAddr));
	/*TODO Store Outgoing Msg in OutBox*/
#if 1
	 strcpy(xMsgInfo.acUserName,pxFrom->uxAddressInfo.szEndptId);	
	 if(strlen(szSmsBody) < IFX_MSG_MAX_BODY_SZ){
	   strcpy(xMsgInfo.szMsgBody,szSmsBody);
	 }
	 else{
	  	strncpy(xMsgInfo.szMsgBody,szSmsBody,IFX_MSG_MAX_BODY_SZ -1);
	 }
	 if(IFX_FAILURE ==IFX_CFG_StoreMsg(ucVoipLineId,IFX_MSG_OUT,&xMsgInfo)) {
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "StoreMsg Failed");
	 }
	 /*Save Message handlers*/
	 puiSmsId = xMsgInfo.uiMsgHdl;
#endif

	eRet = pxIn->pxCallBackList->
		     pfnMsgRcv(&xFrom,pxTo,szSmsBody,
						       pxIn->uiReqId/*TODO xMsgInfo.uiMsgHdl*/,
									 ucVoipLineId,peReason);
	}																																																																               
	if(eRet == IFX_FAILURE){
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"SMS CB Failed ");
		 IFX_CMGR_DeAllocReqCnxt(pxCnxt);
#if 0
		 if(IFX_MAX_MSG_HDL< i) {
			  vxMsgHndls[i].uiMsgHdl =0;
			  vxMsgHndls[i].uiReqId = 0;
#endif 
		 return eRet;
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"SMS Sent");
	return eRet;
}

/*****************************************************************************
 *  Function Name   : This API is used to send SMS from VoIP party to DECT/FXS 
 											extention. Currnetly FXS does not support IM. All message 
											received from VoIP line will be stored in Line's inbox. 
											DECT Agent is expected to notify SMS status synchronously
										  by returning SUCCESS/FAILURE in Invoked Call backs. Request
											Leg will be freed immidiately and appropiate response would
											be sent out on network agent. MsgHdl is generated by VMAPI,
											which will be used across the agent for message retrvial. 
											ReqId is reference to Request Leg structure. Receving Agent
											will also get LineId on which SMS is received.											
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/


e_IFX_Return IFX_CMGR_Msg_VoipExtnSend(	IN x_IFX_CMGR_AddressInfo *pxFrom,
																				IN x_IFX_CMGR_AddressInfo *pxTo,
														      			IN char8* szSmsBody,
																				OUT uint32* puiSmsId,
																        OUT e_IFX_CMGR_Status* peStatus,
																        OUT e_IFX_ReasonCode* peReason)

{	
	e_IFX_Return eRet = IFX_SUCCESS;
	boolean bFwdMode = IFX_TRUE;
  
	uint8 ucSize = IFX_CMGR_MAX_AGENTS;
	uint8 i=0,ucValidLegs = 0,uflag=0;
	uint8 ucLineId = 0;	
	char8 aszEid[IFX_CMGR_MAX_AGENTS][IFX_MAX_ENDPOINTID_LEN];

	x_IFX_CMGR_ReqLeg* 	pxOut;
	x_IFX_CMGR_ReqContext* pxCnxt;
  x_IFX_CMGR_Msg_Info xMsgInfo = {0};	 
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");

	*puiSmsId = 0;
  *peReason = IFX_MAX_REASON;	
	*peStatus = IFX_PENDING;

	/* Analyze the pxTo to find the URL, VL ID and the endpoints associated*/	
	eRet = IFX_LMGR_GetVoipLineIdFromUrl(&pxTo->uxAddressInfo.xVoipAddr, 
			                                 &ucLineId,peReason);	
	if((IFX_FAILURE == eRet) || (!ucLineId)){
     IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	eRet = IFX_LMGR_GetEndpointsForVoipLine(ucLineId,aszEid, &ucSize, 
			                                    &bFwdMode, peReason);
	
	if(IFX_FAILURE == eRet){
     IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/* Add NA to the top of the list*/
	//strcpy(aszEid[0], IFX_NA_ENDPT_ID);
	
	/* Call IFX_CMGR_GetReqCnxtAndLegs*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(ucSize,NULL,
				            &pxCnxt, peReason)){
    IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* Call IFX_CMGR_PrepReqCnxt*/
	if(IFX_FAILURE == IFX_CMGR_PrepReqCnxt(pxCnxt, aszEid, 
				            ucSize,&ucValidLegs)){
     IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	pxCnxt->eReqType = IFX_CMGR_REQ_SMS;
	pxCnxt->uxReqCnxt.xSmsInfoInt.unVoipLineId  = ucLineId;
	
	/*Store SMS in InBox*/
  strcpy(xMsgInfo.acUserName,pxFrom->uxAddressInfo.xVoipAddr.acUserName);
	if(strlen(szSmsBody) < IFX_MSG_MAX_BODY_SZ){
	   strcpy(xMsgInfo.szMsgBody,szSmsBody);
	}
	else{
	  	strncpy(xMsgInfo.szMsgBody,szSmsBody,IFX_MSG_MAX_BODY_SZ -1);
	}
	if(IFX_FAILURE ==IFX_CFG_StoreMsg(ucLineId,IFX_MSG_IN,&xMsgInfo)) {
		 /*TODO
			1. Storing Failed - Return Failure
			2. Free ReqLeg*/
   }

	/*Store Request Id*/  
  #if 0
	for(i=0;i<IFX_MAX_MSG_HDL;i++){
		   if(0==  vxMsgHndls[i].uiMsgHdl){
		   vxMsgHndls[i].uiMsgHdl = xMsgInfo.uiMsgHdl;
		   vxMsgHndls[i].uiReqId =  pxCnxt->pxReqLegs[i]->uiReqId;
      }
	 }
	 if(IFX_MAX_MSG_HDL == i) {
		 /*TODO
			1. Could find free Msg Handler
			2. Deliver Message */
	 }
   #endif
	 

	/*Deliver Msg to All Registed EndPts*/ 
	for(i=0;i<ucValidLegs;i++){
     x_IFX_CMGR_AddressInfo xTo = {0};
		 strcpy(xTo.uxAddressInfo.szEndptId,pxCnxt->pxReqLegs[i]->szEndptId);
		 if(pxCnxt->pxReqLegs[i]->pxCallBackList->pfnMsgRcv){
	      IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					     "Invoking SMS Callback for EP");
			  eRet = pxCnxt->pxReqLegs[i]->pxCallBackList->pfnMsgRcv
				       (pxFrom,&xTo,szSmsBody,
								xMsgInfo.uiMsgHdl /*pxCnxt->pxReqLegs[i]->uiReqId OldReqId*/,
				        ucLineId /*New Change*/,
								peReason);
				uflag++;
		 }
		 else{
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					     "Not SMS Capable EndPt");
		}
	}
 /*Clear req legs*/
  IFX_CMGR_DeAllocReqCnxt(pxCnxt);
	/*TODO Free vxMsgHndls */
#if 0
	if(i<IFX_MAX_MSG_HDL) {
		vxMsgHndls[i].uiMsgHld =0;
		vxMsgHndls[i].uiReqId = 0;
	 }
#endif
  if(uflag){
	     IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"SMS Send Success");
			return IFX_SUCCESS;
	 }
	 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No SMS Capable EP found");
	 return IFX_FAILURE;
}


/*****************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_Msg_Send(	IN x_IFX_CMGR_AddressInfo *pxFrom,
																IN x_IFX_CMGR_AddressInfo *pxTo,
														    IN char8* szSmsBody,
																OUT uint32* puiSmsId,
																OUT e_IFX_CMGR_Status* peStatus,
																OUT e_IFX_ReasonCode* peReason)
{	
	e_IFX_Return eRet = IFX_FAILURE;
	boolean bIsReg = IFX_FALSE;
	e_IFX_CMGR_CallType eFrom = pxFrom->eAddressType;
	e_IFX_CMGR_CallType eTo= pxTo->eAddressType;
	

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	/* Sanity Check*/
	if(!puiSmsId || !pxFrom || !pxTo || !peStatus || !peReason)
	/*Just set the initial value*/
	*peStatus = IFX_CMGR_STATUS_PENDING;
	*peReason = IFX_MAX_REASON;
	*puiSmsId = 0;
	
	if(eFrom ==IFX_CMGR_TYPE_VOIP){
	   /*if(!(eTo == IFX_CMGR_TYPE_EXTN)){
	    *peStatus = IFX_CMGR_STATUS_FAIL;
			*peReason = IFX_USER_NOT_FOUND; 
		   IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return IFX_FAILURE;
		 }*/
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "SMS from VoIP");
		 eRet = IFX_CMGR_Msg_VoipExtnSend(pxFrom,pxTo,szSmsBody,puiSmsId,peStatus,peReason);

	}
	
	else if (eFrom == IFX_CMGR_TYPE_EXTN){ 
		if(!(eTo == IFX_CMGR_TYPE_VOIP)){    
			*peStatus = IFX_CMGR_STATUS_FAIL;
			*peReason = IFX_USER_NOT_FOUND; 
		   IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return IFX_FAILURE;
     } 
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "DECT to VoIP SMS");
		 eRet = IFX_CMGR_Msg_ExtnVoipSend(pxFrom,pxTo,szSmsBody,puiSmsId,peStatus,peReason);
		 IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		 return eRet;
 }
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

#endif /*MESSAGE_SUPPORT*/

/*****************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_StarDialling_PrepToList (
					IN char8* szFrom, 
					IN uint32 uiActiveCallId,
					OUT uchar8 *pucCount, 
					OUT char8 aszEpList[][IFX_MAX_ENDPOINTID_LEN])
{
  char8 szCurrentEndpt[IFX_MAX_ENDPOINTID_LEN] = "";	
  e_IFX_EndptType eEndptType =0;
  e_IFX_Return eRet;
  e_IFX_ReasonCode eReason;
  uchar8 ucCount = 0,i=0;
  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  if ( IFX_FAILURE == IFX_CIF_EndptListGet(IFX_EP_DECT, 
                   	  &ucCount,aszEpList,&eReason)){
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Endpts Found");
	return IFX_FAILURE;
  }
  if(uiActiveCallId) {
	x_IFX_CMGR_CallLeg *pxLeg  = IFX_CMGR_GetCallLegPtr(uiActiveCallId);	
	x_IFX_CMGR_CallLeg *pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Active CalID");
	if(!pxLeg || !pxPeer){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Leg Active CallId");
		return IFX_FAILURE;
	}
	eRet = IFX_CIF_EndptTypeGet(pxPeer->xLegOwnerInfo.szEndptId,
								&eEndptType,&eReason);
	if(IFX_SUCCESS == eRet && IFX_EP_DECT == eEndptType){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ActiveCall with DectHs ", 
				 pxPeer->xLegOwnerInfo.szEndptId);
		strcpy(szCurrentEndpt,pxPeer->xLegOwnerInfo.szEndptId);
	}
  }

  while(i < ucCount ) {
		if ( !strcmp(aszEpList[i], szFrom) ||
			 !strcmp(aszEpList[i], szCurrentEndpt) ) {
			 IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					 "Removing Endpt",aszEpList[i]);
			if((ucCount-1) > i ) {
				memmove(aszEpList[i],aszEpList[i+1],aszEpList[ucCount-1] - aszEpList[i]);
			} 
			strcpy(aszEpList[ucCount-1],"");
			ucCount --;
			continue;
		}
		i++;
  }
  if(!ucCount) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Insufficient EndtPts");
		return IFX_FAILURE;
  }	
  *pucCount = ucCount;
  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Returning");
  return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_StarDialling_MakeCall
 *  Description     : Makes Call from a Extn to an Extn call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_StarDialling_MakeCall
									(
										IN x_IFX_CMGR_CallContext* pxCnxt,
										IN x_IFX_CMGR_CallParams* pxPar,
								 		OUT e_IFX_CMGR_Status* peStatus,
										OUT e_IFX_ReasonCode* peReason
					 				)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint8 ucNumCallLegs = pxCnxt->ucNumCallLegs,i=0 ;
	x_IFX_CMGR_CallLeg *pxOut = IFX_CMGR_GetOutCl(pxCnxt); 
	x_IFX_CMGR_CallParams xInPar;
	x_IFX_CMGR_CodecParams* pxOutCodecs, *pxOutOffCodecs;
  uint32 uiIgnoreCall = IFX_TRUE;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxOut) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Param");
		return IFX_FAILURE;
	}
	pxOutCodecs =  &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;		 
	pxOutOffCodecs = &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;		 

	/*Change state of the OUT CL to SRP Invite and the IN CL to RRP (Invite)*/
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_SEND_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);

	if (ucNumCallLegs > IFX_CMGR_MAX_LEGS_PER_CNXT)
		return IFX_FAILURE;

	for(i=1; (i < ucNumCallLegs) && (pxCnxt->pxCallLegs[i]); i++) {
		x_IFX_CMGR_CallLeg *pxIn = pxCnxt->pxCallLegs[i];
		x_IFX_CMGR_CodecParams* pxInCodecs = 
		   &pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;

		/*Allocate the required resources for the call using MMGR*/	
		eRet=IFX_CMGR_GetMediaResIntInt(&pxCnxt->iResId,pxOut,pxIn,peStatus,peReason);
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,"Resource Id  ",pxCnxt->iResId);
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,"Endpoint  ",pxIn->xLegOwnerInfo.szEndptId);

		if(IFX_FAILURE == eRet) {
			*peStatus = IFX_CMGR_STATUS_FAIL;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;/* DEBUG*/
		}
		eRet = IFX_CMGR_ReOrderCodecsForWB(pxOutCodecs,pxInCodecs,IFX_TRUE);		
		if(pxOutCodecs->unNoOfCodecs){	
			memcpy(pxOutOffCodecs,pxOutCodecs,sizeof(x_IFX_CMGR_CodecParams));
		}

		/*Prepare call params for In leg and invoke pfnCallIncoming on it*/
		memset(&xInPar,0,sizeof(x_IFX_CMGR_CallParams));
		eRet = IFX_CMGR_MakeCallParamsExtnExtn(pxIn,pxPar,&xInPar,peReason);
		if(IFX_FAILURE == eRet) {
			*peStatus = IFX_CMGR_STATUS_FAIL;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;/* DEBUG*/
		}	
		eRet =  IFX_CMGR_InvokeCallIncExtnExtn(pxOut,pxIn,&xInPar,peStatus,peReason);
    if(IFX_CMGR_STATUS_FAIL != *peStatus){
      uiIgnoreCall = IFX_FALSE; 
    }
		if(IFX_FAILURE == eRet){//This block could be a problem
			// *peStatus = IFX_CMGR_STATUS_FAIL;
			 IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxOut->xLegOwnerInfo.szEndptId,
                pxIn->xLegOwnerInfo.szEndptId,
                peReason);
            IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[i]);
            pxCnxt->pxCallLegs[i] = NULL;
            --pxCnxt->ucNumCallLegs;
			continue;
		}

		/*change the state of IN CL to RRP (Invite)*/
    IFX_CMGR_ChangeState(pxIn,IFX_CMGR_RECV_RESP_PENDING,IFX_CMGR_RESP_PEND_INVITE);
		if((IFX_CMGR_STATUS_PENDING == *peStatus) && (IFX_ENDPOINT_RINGING == *peReason)) {
        	/*Change state of the OUT CL to RINGBACK and the IN CL to RINGING*/
        	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_RINGBACK,0);
        	IFX_CMGR_ChangeState(pxIn,IFX_CMGR_STATE_RINGING,0);
    	}
	}

  /* If all the IN Call Legs Ignore Call, send release to OUT Leg and free Call Context */
	if(IFX_TRUE == uiIgnoreCall)
	{
		 e_IFX_ReasonCode eReleaseReason = IFX_TERMINATED;
	   IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Sending Release to Star Dial Out Leg(Initiator)");
     eRet = IFX_CMGR_InvokeRemoteCallRelease(pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX], eReleaseReason, NULL);
		 IFX_CMGR_DeAllocCallCnxt(pxCnxt);	
		 IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
     return eRet;
	}

	eRet = IFX_FAILURE;
	if(pxCnxt->ucNumCallLegs >=  IFX_CMGR_MIN_LEGS_PER_CNXT) {
		eRet = IFX_SUCCESS;
		*peStatus = IFX_CMGR_STATUS_PENDING;
		if(IFX_TRUE == IFX_CMGR_IsAnyInClRinging(pxCnxt)){
			*peReason = IFX_ENDPOINT_RINGING;
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_StarDialling_PrepCntx (
					x_IFX_CMGR_CallContext* pxCnxt,
					x_IFX_CMGR_AddressInfo* pxFrom,
					x_IFX_CMGR_CallParams* pxCallParams,
                    char8 aszToEpList[][IFX_MAX_ENDPOINTID_LEN],
					char8 ucNoOfToEndpts,
					e_IFX_ReasonCode *peReason)


{	
	e_IFX_Return eRet = IFX_SUCCESS;
    x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_CallLeg *paxLocLeg[IFX_CMGR_MAX_LEGS_PER_CNXT] = {NULL};
    uint8 ucValidLegs = 0,i = 0;
    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	/*Prepare OutLeg*/
	IFX_CMGR_GetEidFromAddrInfo(pxFrom,pxOut->xLegOwnerInfo.szEndptId);
    pxOut->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;

    eRet = IFX_CMGR_GetCBList(pxOut->xLegOwnerInfo.szEndptId,&pxOut->pxCallBackList);
	if(IFX_FAILURE == eRet){
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
        return IFX_FAILURE;
    }

  	eRet = IFX_CMGR_SetExtnLegInfo(IFX_TRUE,pxOut->xLegOwnerInfo.szEndptId,
            &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo,pxCallParams, peReason);
    if(IFX_FAILURE == eRet)
    {
        IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
        return eRet; /* Major Faliure -DEBUG*/
    }
	paxLocLeg[0] = pxOut;
    ucValidLegs++;
	
	/*Prepare IN CLs*/
	if (ucNoOfToEndpts > IFX_CMGR_MAX_LEGS_PER_CNXT-1)
		return IFX_FAILURE;

	for(i=0; i < ucNoOfToEndpts; i++) {

		x_IFX_CMGR_CallLeg *pxIn = pxCnxt->pxCallLegs[i+1];

		memset(pxIn->xLegOwnerInfo.szEndptId,0,sizeof(char)*IFX_MAX_ENDPOINTID_LEN);	
	    strncpy(pxIn->xLegOwnerInfo.szEndptId, aszToEpList[i], IFX_MAX_ENDPOINTID_LEN-1);

		eRet = IFX_CMGR_GetCBList( pxIn->xLegOwnerInfo.szEndptId,&pxIn->pxCallBackList);

		if(IFX_SUCCESS == eRet) {
			pxIn->xLegOwnerInfo.eOwnerType = IFX_CMGR_TYPE_EXTN;
			eRet = IFX_CMGR_SetExtnLegInfo(IFX_FALSE,pxIn->xLegOwnerInfo.szEndptId,
					&pxIn->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo,
					pxCallParams, peReason);
			if( IFX_SUCCESS == eRet) {			
				paxLocLeg[ucValidLegs] = pxIn;
				ucValidLegs++;
				pxIn->pxCurrCnxt = pxCnxt;
				continue;
			}
		}
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Freeing IN CL");
		IFX_CMGR_DeAllocCallLeg(pxIn);
		pxCnxt->pxCallLegs[i+1] = NULL;
		--pxCnxt->ucNumCallLegs;
	 }
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,"ValidLeg Count  ",ucValidLegs);
	
	 if(ucValidLegs < IFX_CMGR_MIN_LEGS_PER_CNXT) {
		return IFX_FAILURE;
	 }
	 pxOut->pxCurrCnxt = pxCnxt;
	 memcpy(pxCnxt->pxCallLegs, paxLocLeg,IFX_CMGR_MAX_LEGS_PER_CNXT*sizeof(x_IFX_CMGR_CallLeg*));	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return IFX_SUCCESS;
	/*TODO pxIn->pxCurrCnxt = pxCnxt;*/

}

/*****************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_StarDialling_CreateCall(
					 OUT uint32 *puiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom, 
					 IN uint32 uiActiveCallId,
					 IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 IN void* pvPrivateData)

{
	e_IFX_EndptType eEndptType =0;
	e_IFX_Return eRet = IFX_FAILURE;
	uchar8 ucCount = 0;
	char8 aszEpList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN] = {""};

	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxOut = NULL;	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	
	if (!puiCallId || !pxFrom || !pxCallParams || 
		!peStatus || !peReason || 
		IFX_CMGR_TYPE_EXTN != pxFrom->eAddressType ) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid IN Params");
		return IFX_FAILURE;
	}
	*peStatus = IFX_CMGR_STATUS_FAIL;
	*peReason = IFX_NO_RESOURCE;
	eRet = IFX_CIF_EndptTypeGet(pxFrom->uxAddressInfo.szEndptId,&eEndptType,peReason);
	if (IFX_FAILURE == eRet || IFX_EP_DECT != eEndptType) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied: Initiated from Non DECT Endpt");
		return IFX_FAILURE;
	}
	eRet = IFX_CMGR_StarDialling_PrepToList(pxFrom->uxAddressInfo.szEndptId,
				uiActiveCallId,&ucCount,aszEpList);
	if(IFX_FAILURE == eRet){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied to prep to list");
		*peReason = IFX_USER_NOT_FOUND;
		return IFX_FAILURE;
	}

	if(IFX_CMGR_GetCallCnxtAndLegs(IFX_CMGR_BCT_EXTN_EXTN,ucCount+1,
        pvPrivateData, peReason, &pxCnxt) == IFX_FAILURE) {
        *peStatus = IFX_CMGR_STATUS_FAIL;
        IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
        return IFX_FAILURE;
    }

    pxOut = IFX_CMGR_GetOutCl(pxCnxt);
    *puiCallId = pxOut->uiCallId;                     
	
	 /* Populate the call context with all the info needed*/	
	if(IFX_CMGR_StarDialling_PrepCntx(pxCnxt,pxFrom,pxCallParams,aszEpList,
									 ucCount,peReason) == IFX_FAILURE)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied: PrepCntx");
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		return IFX_FAILURE; 
	}
	/* Set Flag to indicate that the Call intiate API has not been returned*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	IFX_CMGR_SET_FLAG(pxCnxt->unSSCallFlag,IFX_CMGR_STAR_DIAL_IN_PROGRESS);
	
	eRet = IFX_CMGR_StarDialling_MakeCall(pxCnxt, pxCallParams, peStatus, peReason);
	
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN);
	
	if( IFX_FAILURE == eRet ) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied: MakeCall");
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
 }

/*!	
   \brief      This API is to be called by the Agent whenever it wants to make 
					a call to any other agent.
	\param[out]	puiCallId is the identifier of the call
   \param[in]  pxTo is the address/extension number/PSTN Phone number 
					identifying the called party. For the FXS/DECT agents getting to 
					VoIP it is the user at domain form of address uri and type VoIP. 
					For FXS/DECT reaching to PSTN it shall be PSTN number. 
					For FXS/DECT reaching FXS/DECT it shall be the peer party's extn. 
					For FXO agent it shall be either be the remote VoIP URI (GW mode) 
					or the FXO line ID (own phone number).
					For NA it shall be the VoIP Line URI. 
   \param[in]  pxFrom is the address/endpoint Id/PSTN number identifying the 
					calling party.
					For FXS/DECT agents it shall be their own endpoint id and type
					extension. 
					For FXO agent it shall be its line id. The FXO agent shall 
					fill the PSTN number in the phone number parameter.
					For NA it shall be the address of the remote VoIP party and type
					as VoIP.
	\param[in] pxCallParams Contains extra parameters for the call. Every 
						agent has its own structure that it has to write to.
	\param[out]	peStatus is the status of the Req
	\param[out]	peReason - incase of failure, this parameter provides the 
					specific reason
	\param[in] pvPrivateData is a pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallInitiate(
					 OUT uint32 *puiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom, 
					 IN x_IFX_CMGR_AddressInfo *pxTo, 
					 IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 IN void* pvPrivateData)
{
	/* Local CC pointer to be used for the call*/
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_BasicCallType eBasic = 0;
	boolean bRestoreTo = IFX_FALSE;
	boolean bIsReg = IFX_FALSE;
	x_IFX_CMGR_AddressInfo xTempTo;	
	uint32 uiReplacesCallId = 0;
	uint32 uiDefCallId =0;
#ifdef HANDLE_OPTIONS
  uint32 uiOptFlag = 0;
#endif
if(pxFrom-> eAddressType == IFX_CMGR_TYPE_EXTN ){
	printf(" \nFrom %s & To %s address Info : ",pxFrom->uxAddressInfo.szEndptId,pxTo->uxAddressInfo.szEndptId);
}


	/* Array of pointers to functions*/
	pfn_IFX_CMGR_CreateCall pfnaCreateCall[IFX_CMGR_BCT_MAX] = 
										{  
											IFX_CMGR_IgnoreCreateCall,
											IFX_CMGR_CreateCallVoipInt,
											IFX_CMGR_CreateCallExtnFxo,
											IFX_CMGR_CreateCallExtnVoip,
											IFX_CMGR_CreateCallExtnExtn,
											IFX_CMGR_CreateCallFxoVoip,
											IFX_CMGR_CreateCallFxoExtn,
											IFX_CMGR_IgnoreCreateCall,
											IFX_CMGR_IgnoreCreateCall
										};
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

printf("Entry in to the Call Manager [IFX_CMGR_CallInitiate] .... \n");
	/* Sanity Check*/
	if (!peStatus || !peReason)
		return IFX_FAILURE;
	if(!puiCallId || !pxFrom || !pxTo)
  {
    *peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_INTERNAL_ERR;
		return IFX_FAILURE;
  }
	if (*peReason == IFX_DEFLECTION){
		uiDefCallId = *puiCallId;
	}
	/*Get the Value of the replaces Call ID*/	
	if (pxCallParams){
		uiReplacesCallId = pxCallParams->uxCallParams.xVoipParams.uiReplacesCallId;
	}
	/*Just set the initial value*/
#ifdef HANDLE_OPTIONS
  if(*peReason == IFX_OPTION_ARRIVED){
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Option Arrived");
  uiOptFlag = 1;
  }
#endif
	*peStatus = IFX_CMGR_STATUS_PENDING;
	*peReason = IFX_MAX_REASON;
	*puiCallId = 0;
	
	/*Check for a Replaces Call*/
	if(pxCallParams && uiReplacesCallId)
	{
		eRet =  IFX_CMGR_HandleRepIncCall(puiCallId, uiReplacesCallId, 
			pxFrom, pxTo, pxCallParams, peStatus, peReason, pvPrivateData);
		printf("\n<<<<<Initiate Call Failing after IFX_CMGR_HandleRepIncCall \n");
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return eRet;
	}
	/* Validate the Call Addresses and that the EIDs are right 
	 * and Get basic call type*/
	if(IFX_FAILURE == IFX_CMGR_GetBasicCallType(pxFrom,pxTo,&eBasic))
	{
		/*Return API with status Failure*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_USER_NOT_FOUND;
		*puiCallId=0;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		printf("\n<<<<<Initiate Call Failing after IFX_CMGR_GetBasicCallType \n");
		return eRet;
	}
  /*If Call is to/from VoIP - Check If Line is Registred*/
	if (uiDefCallId){
		if (pxTo->eAddressType == IFX_CMGR_TYPE_VOIP){
			if (IFX_LMGR_GetEndptDefaultVoipLine(
            pxFrom->uxAddressInfo.szEndptId,
            &pxTo->ucLineId,&bIsReg, peReason) != IFX_SUCCESS){
				*peStatus = IFX_CMGR_STATUS_FAIL;
				*peReason = IFX_USER_NOT_FOUND;
				*puiCallId=0;
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				printf("\n<<<<<Initiate Call Failing after IFX_CMGR_GetEndptDefaultVoipLine \n");
				return IFX_FAILURE;
			}
		}
	}else{
	if (IFX_CMGR_BCT_VOIP_INT == eBasic 
			|| IFX_CMGR_BCT_EXTN_VOIP == eBasic )
	{
		eRet = IFX_LMGR_GetEndptDefaultVoipLine(
						pxFrom->uxAddressInfo.szEndptId, 
            &pxTo->ucLineId,&bIsReg, peReason);
#ifdef __PSTN_ROUTE__
		if(IFX_FALSE == bIsReg && 
			 IFX_CMGR_BCT_EXTN_VOIP == eBasic)
		{
			/*Set Basic Call type to EXTN_FXO*/ 
			eBasic = IFX_CMGR_BCT_EXTN_FXO;
			memset(&xTempTo,0,sizeof(x_IFX_CMGR_AddressInfo));
			memcpy(&xTempTo,pxTo,sizeof(x_IFX_CMGR_AddressInfo));
			memset(pxTo,0,sizeof(x_IFX_CMGR_AddressInfo));
			pxTo->eAddressType = IFX_CMGR_TYPE_FXO; 
			/*Copy the User Name from the Temp loc into the Phone number space*/	
			strcpy(pxTo->uxAddressInfo.xFxoInfo.szPhoneNumber,
											xTempTo.uxAddressInfo.xVoipAddr.acUserName);
			bRestoreTo = IFX_TRUE;
		}	
		else
#endif 
 		if (IFX_FALSE == bIsReg)
		{
			*peStatus = IFX_CMGR_STATUS_FAIL;
			*peReason = IFX_USER_NOT_FOUND;
				printf("\n<<<<<Initiate Call Failing after bIsReg \n");
			return IFX_FAILURE; 
		}
		/*Check for call to own Number*/
		else if(IFX_TRUE == bIsReg &&
       IFX_CMGR_BCT_EXTN_VOIP == eBasic){
			x_IFX_CalledAddr xAddr;
			e_IFX_ReasonCode eReason;
			eRet=IFX_CIF_UrlFromVLGet(pxTo->ucLineId,&xAddr,&eReason);
    	if(IFX_FAILURE==eRet){
				*peStatus = IFX_CMGR_STATUS_FAIL;
				*peReason = IFX_USER_NOT_FOUND; 
				return IFX_FAILURE; 
			}
	  	if(!strcmp(xAddr.acUserName,pxTo->uxAddressInfo.xVoipAddr.
								 acUserName)){
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					"Calling own number not allowed");
				*peStatus = IFX_CMGR_STATUS_FAIL;
				*peReason = IFX_USER_NOT_FOUND; 
				return IFX_FAILURE; 
    	}
		}
 }	
 }
	
	/*Invoke the right kind of CreateCall function based on the Basic Call */
#ifdef HANDLE_OPTIONS
    if(uiOptFlag == 1){
    *peReason = IFX_OPTION_ARRIVED;
    }
    /*Since no resource is allocated this API can return success*/
#endif
	if (uiDefCallId){
		*peReason = IFX_DEFLECTION;
		*puiCallId = uiDefCallId;
	}
printf("\n<<<<<Initiate Before pfnaCreateCall Call  %d\n",eBasic);

	eRet = pfnaCreateCall[eBasic]
			(puiCallId,pxFrom,pxTo,pxCallParams,peStatus,peReason,pvPrivateData);
	if((IFX_FAILURE == eRet)||(IFX_CMGR_STATUS_FAIL == *peStatus))
	{
			printf("\n<<<<<Failing After pfnaCreateCall Call  %d\n",eBasic);
		/*Return API with status Failure*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		if(*puiCallId)
		{
			/*DeAllocate the context*/
			IFX_CMGR_DeAllocCallCnxt(IFX_CMGR_GetCallCnxtPtr(*puiCallId));
			*puiCallId=0;
		}
	}
	if(IFX_TRUE == bRestoreTo)
	{
			memcpy(pxTo,&xTempTo,sizeof(x_IFX_CMGR_AddressInfo));
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Call ID for Calling Party: ",*puiCallId);
	printf("\nCall ID for Calling Party: %d \n",*puiCallId);
	IFX_CMGR_PrintCallIdList(__FUNCTION__);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeRemCallAccept
 *  Description     : Invokes CB pfnRemoteCallAccept
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeRemCallAccept
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	eRet = pxLeg->pxCallBackList->pfnRemoteCallAccept(
						 pxLeg->uiCallId,pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AcceptCallInForking
 *  Description     : Function used to handle call-accept by a party involved 
 *  						 in a forking scenario.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AcceptCallInForking
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_RINGING,0);
	if(IFX_CMGR_STATE_RINGBACK != pxOut->eCurrState)
	{
		/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
		if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),\
										IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
		{
			eRet = IFX_CMGR_InvokeRemCallAccept(pxOut);
		}

		/*Change state of OUT CL to RINGBACK*/
		IFX_CMGR_ChangeState(pxOut, IFX_CMGR_STATE_RINGBACK, 0);
	}
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason = IFX_MAX_REASON;
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AcceptCallExtnInt
 *  Description     : Function used to handle a accept call by Internal party
 *  						 in a Extn to internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AcceptCallExtnInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  
  /* Star Dialing */  
	if(pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT) {
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Int Call forked");
			return IFX_CMGR_AcceptCallInForking(pxLeg,peStatus,peReason);
	}

	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg,IFX_CMGR_STATE_RINGING,0);

	/*Change state of OUT CL to RINGBACK*/
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_RINGBACK,0);
	
	/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
	if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
	{
		eRet = IFX_CMGR_InvokeRemCallAccept(pxOut);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_MatchMediaParams
 *  Description     : Function used to match media parameters between local &
 *  						 remote media params and save the output in pxCommonCodecs
 *  						 & pxNegRtp. If there is not match then fn returns
 *  						 IFX_FALSE.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_MatchMediaParams
							( IN x_IFX_CMGR_CodecParams* pxLocCodecs,
							  IN x_IFX_CMGR_CodecParams* pxRemCodecs,
							  IN x_IFX_CMGR_RtpParams* pxLocRtp,
							  IN x_IFX_CMGR_RtpParams* pxRemRtp,
							  OUT x_IFX_CMGR_CodecParams* pxCommonCodecs,
							  OUT x_IFX_CMGR_RtpParams* pxNegRtp
					 		)
{
	boolean bRet = IFX_TRUE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	IFX_CMGR_FindCommonCodecs(pxLocCodecs, pxRemCodecs, pxCommonCodecs);
	if(!pxCommonCodecs->unNoOfCodecs)
	{
		return IFX_FALSE;
	}
	else
	if(pxLocRtp && pxRemRtp)
	{
		/* Save Local Info first*/
		pxNegRtp->uiLocalRtpPort = pxLocRtp->uiLocalRtpPort;
		pxNegRtp->uiLocalRtcpPort = pxLocRtp->uiLocalRtcpPort;
		strcpy((char8 *)pxNegRtp->szLocalRtpIpAddr, (char8 *)pxLocRtp->szLocalRtpIpAddr);
		
		/*Save Remote RTP info*/
		pxNegRtp->uiRemoteRtpPort = pxRemRtp->uiRemoteRtpPort;	
		pxNegRtp->uiRemoteRtcpPort = pxRemRtp->uiRemoteRtcpPort;	
		strcpy((char8 *)pxNegRtp->szRemoteRtpIpAddr, (char8 *)pxRemRtp->szRemoteRtpIpAddr);
		strcpy((char8 *)pxNegRtp->szRemoteRtcpIpAddr, (char8 *)pxRemRtp->szRemoteRtcpIpAddr);

		/*Generate a Mode from the local and remote RTP modes*/
		/* The mode will be complimentary to current local mode. For example if the
		 local mode is SENDRECV and the remote mode is RECVONLY then the our mode is
		 SENDONLY. If the remote mode is INACTIVE, then our mode is also INACTIVE.
		 If the remote mode is SENDONLY then our mode is RECVONLY. If the remote
		 mode is SENDRECV only then can we also be in SENDRECV.*/
		pxNegRtp->eSdpMode = 
			IFX_CMGR_GetAnsSdpMode(pxLocRtp->eSdpMode,pxRemRtp->eSdpMode);
	}
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IgnoreAcceptCall
 *  Description     : N.A.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_IgnoreAcceptCall
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AcceptCallIntVoip
 *  Description     : Function used to handle a accept call by Voip party
 *  						 in a Internal to Voip call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AcceptCallIntVoip
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_MediaParams xMediaPar;
	x_IFX_CMGR_CodecParams xCodec;
	x_IFX_CMGR_RtpParams xRtp;
	boolean bMatched  = IFX_TRUE;

	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 	
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg,IFX_CMGR_STATE_RINGING,0);
	/* 
	 * Invoke pfnGetMediaParams - Check for the presence of
	 * Early media - If present then find the negotiated codecs
	 * and RTP params. Invoke ConfigMedia & the pfnRtpSessionStart.
	 * Set flag to indicate that Early media was received.
	 */
	memset(&xMediaPar,0,sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams (pxLeg,&xMediaPar);
	
	/*Check presence of any media parameters returned*/
	if(IFX_TRUE == IFX_CMGR_IsMediaPresent(
		&xMediaPar.uxMediaParams.xVoipMediaParams.xRtpParams
#ifdef FAX_SUPPORT
		,xMediaPar.uxMediaParams.xVoipMediaParams.axFaxParams, 
		IFX_MAX_FAX_PROTO
#endif
		))
	{ 
		memset(&xCodec,0,sizeof(x_IFX_CMGR_CodecParams));
		memset(&xRtp,0,sizeof(x_IFX_CMGR_RtpParams));
		/*Media is present - Invoke Config Media & Start Session*/
		bMatched = IFX_CMGR_MatchMediaParams(&pxLegInfo->xOfferedCodecInfo,
				&xMediaPar.uxMediaParams.xVoipMediaParams.xCodecParams,
				&pxLegInfo->xNegRtpParams,
				&xMediaPar.uxMediaParams.xVoipMediaParams.xRtpParams,&xCodec,&xRtp);
		
		if(IFX_TRUE == bMatched)
		{
#ifdef FAX_SUPPORT
			eRet  = IFX_CMGR_HandleFaxMediaNeg(pxLeg,
								&xCodec,pxLegInfo->axFaxParams,
									xMediaPar.uxMediaParams.xVoipMediaParams.axFaxParams);
#endif
			/*Copy the accepted codecs & RTP into their right places*/
			memcpy(&pxLegInfo->xNegCodecInfo,
					&xCodec, sizeof(x_IFX_CMGR_CodecParams));
			memcpy(&pxLegInfo->xNegRtpParams,&xRtp, sizeof(x_IFX_CMGR_RtpParams));
			/* Invoke Config Media & then pfnRemoteSessionStart*/
			eRet = IFX_CMGR_InvokeMediaSession(pxLeg, 
											pxCnxt->iResId, IFX_TRUE,peReason);
		}	
	}
	else
	{
		/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
		if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
		{
			eRet = IFX_CMGR_InvokeRemCallAccept(pxOut);
		}
	}
	/*Change state of OUT CL to RINGBACK*/
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_RINGBACK,0);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeAtxReq 
 *  Description     : Invokes CB pfnAttendedTxReq
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeAtxReq(
						IN x_IFX_CMGR_CallLeg* pxLeg,
						IN x_IFX_CMGR_CallLeg* pxAtxLeg,
						IN x_IFX_CMGR_AddressInfo* pxAddr,
						OUT e_IFX_TransferStatus* peStatus,
						OUT e_IFX_ReasonCode* peReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint32 uiRepCallId = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(pxAtxLeg)
			  uiRepCallId = pxAtxLeg->uiCallId;
	eRet = pxLeg->pxCallBackList->pfnAttendedTxReq(pxLeg->uiCallId, 
		uiRepCallId, pxAddr, peStatus, peReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeBtxReq 
 *  Description     : Invokes CB pfnBlindTxReq
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeBtxReq(
						IN x_IFX_CMGR_CallLeg* pxLeg,
						IN x_IFX_CMGR_AddressInfo* pxAddr,
						OUT e_IFX_TransferStatus* peStatus,
						OUT e_IFX_ReasonCode* peReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	eRet = pxLeg->pxCallBackList->pfnBlindTxReq(pxLeg->uiCallId,
									pxAddr, peStatus, peReason, pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeBtxStatus 
 *  Description     : Invokes CB pfnBlindTxStatus
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeBtxStatus(
						IN x_IFX_CMGR_CallLeg* pxLeg,
						IN e_IFX_TransferStatus eStatus,
						IN e_IFX_ReasonCode eReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY) &&
	   (IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)))
	{
		eRet = pxLeg->pxCallBackList->pfnBlindTxStatus(pxLeg->uiCallId,
										eStatus, eReason, pxLeg->pvPrivateData);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeAtxStatus 
 *  Description     : Invokes CB pfnAttendedTxStatus
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeAtxStatus(
						IN x_IFX_CMGR_CallLeg* pxLeg,
						IN e_IFX_TransferStatus eStatus,
						IN e_IFX_ReasonCode eReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY) &&
	   (IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)))
	{		
		eRet = pxLeg->pxCallBackList->pfnAttendedTxStatus(pxLeg->uiCallId,
				eStatus, eReason, pxLeg->pvPrivateData);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AcceptCallInBtx 
 *  Description     : Function handles accept call from child leg in BTX
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AcceptCallInBtx
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg->pxParent;
	x_IFX_CMGR_MediaParams xMedia;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Check if the current leg has a parent, else reject API with status FAIL*/
	if(!pxParent)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Change Parent state to Call_Leg_Tx*/
	IFX_CMGR_ChangeState(pxParent, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	/*Invoke pfnBlindTxStatus on the Parent*/
	eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
							 IFX_CMGR_TRANSFER_RINGING,*peReason); 		
	
	if((IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer) ||
						 (IFX_CMGR_BTX_INT_INT_VOIP == pxCnxt->eTypeOfTransfer))
	{
		/* Invoke Get Media Params */
		memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
		eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);
		/* TO DO - Compare Media Receieved with the offered Media. */
		/* DO NOT INVOKE START SESSION - IGNORE 183*/
	}
			
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AcceptCallInAtx 
 *  Description     : Function handles accept call from child leg in ATX
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AcceptCallInAtx
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg->pxParent;
	x_IFX_CMGR_MediaParams xMedia;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Check if the current leg has a parent, else reject API with status FAIL*/
	if(!pxParent)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Change Parent state to Call_Leg_Tx*/
	IFX_CMGR_ChangeState(pxParent, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	/*Invoke pfnATxStatus on the Parent*/
	eRet = IFX_CMGR_InvokeAtxStatus(pxParent, 
						 IFX_CMGR_TRANSFER_RINGING,*peReason); 		
	
	if(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer) 
	{
		/* Invoke Get Media Params */
		memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
		eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);
		/* TO DO - Compare Media Receieved with the offered Media. */
		/* DO NOT INVOKE START SESSION - IGNORE 183*/
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	Will be called to inform the call manager that the agent has 
				accepted the incoming call i.e. it is ringing
	\param[in]	 uiCallId is the identifier of the call
	\param[out]	peStatus is the status of the Req
	\param[out]	peReason - incase of failure, this parameter provides the 
					specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallAccept(
								IN uint32 uiCallId,
					 			OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
								)
{  e_IFX_Return eRet = IFX_SUCCESS; 
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);

	/* Array of pointers to functions*/
	pfn_IFX_CMGR_AcceptCall pfnaAcceptCall[IFX_CMGR_BCT_MAX] = 
										{  
											IFX_CMGR_IgnoreAcceptCall,
											IFX_CMGR_IgnoreAcceptCall,
											IFX_CMGR_AcceptCallExtnInt,
											IFX_CMGR_AcceptCallIntVoip,
											IFX_CMGR_AcceptCallExtnInt,
											IFX_CMGR_AcceptCallIntVoip,
											IFX_CMGR_AcceptCallInForking,
											IFX_CMGR_AcceptCallInForking,
											IFX_CMGR_IgnoreAcceptCall
										};

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason = IFX_MAX_REASON;
	
	
	/*Check State of the LEG*/
	if(!(((pxLeg->eCurrState == IFX_CMGR_RECV_RESP_PENDING) && 
			(pxLeg->eRespPendEvt == IFX_CMGR_RESP_PEND_INVITE ))
			|| (pxLeg->eCurrState == IFX_CMGR_STATE_RINGING)) )
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	
	/*Check for a Blind transfer related scenario*/
	if((pxCnxt->eTypeOfTransfer < IFX_CMGR_BTX_MAX_TYPE) &&
			(pxCnxt->eTypeOfTransfer > IFX_CMGR_BTX_INT_VOIP_VOIP))
			  return IFX_CMGR_AcceptCallInBtx(pxLeg, peStatus, peReason);

	/*Check for a Attended transfer related scenario*/
	if((pxCnxt->eTypeOfTransfer < IFX_CMGR_ATX_MAX_TYPE) &&
			(pxCnxt->eTypeOfTransfer > IFX_CMGR_ATX_INT_VOIP_VOIP))
			  return IFX_CMGR_AcceptCallInAtx(pxLeg, peStatus, peReason);
	
	
	eRet = pfnaAcceptCall[pxCnxt->eBasicCallType](pxLeg,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;			  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeRemCallAnswer 
 *  Description     : Invokes CB pfnRemoteCallAnswer
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeRemCallAnswer
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	eRet = pxLeg->pxCallBackList->pfnRemoteCallAnswer(
						 pxLeg->uiCallId,pxLeg->pvPrivateData);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IgnoreAnswerCall 
 *  Description     : N.A.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_IgnoreAnswerCall
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnswerCallExtnInt 
 *  Description     : Function handles a call answer from the Internal party in
 *  						 a Extn to Internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AnswerCallExtnInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_MediaParams xMediaPar;
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = 
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		  
	x_IFX_CMGR_ExtnLegInfo* pxOutLegInfo = 
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		  
	x_IFX_CMGR_CodecParams* pxRecvCodecs = 
		&xMediaPar.uxMediaParams.xExtnMediaParams.xCodecParams;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg,IFX_CMGR_STATE_CONV,0);

	/*Change state of OUT CL to Conversation*/
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_CONV,0);

	/*Is the IN Party an EXTN ?*/
	if(IFX_CMGR_TYPE_EXTN == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		/*Invoke pfnGetMediaParams on this to get the Codecs for this call*/
		memset(&xMediaPar,0,sizeof(x_IFX_CMGR_MediaParams));
		eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg,&xMediaPar);
		if(pxRecvCodecs->unNoOfCodecs && pxExtnLegInfo->xOfferedCodecInfo.unNoOfCodecs)
		{
			/* Save codecs in the Negotiated codecs list*/		
			if(IFX_FALSE == IFX_CMGR_MatchMediaParams(
					&pxExtnLegInfo->xOfferedCodecInfo,
					pxRecvCodecs, NULL, NULL, &pxExtnLegInfo->xNegCodecInfo, NULL))
			{
				eRet = IFX_FAILURE;
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				return eRet;
			}
			/*ReOrder Codecs for WB at the other end*/
			IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xNegCodecInfo,
															&pxOutLegInfo->xNegCodecInfo,IFX_FALSE);
		}
	}

	/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
	if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
	{
		eRet = IFX_CMGR_InvokeRemCallAnswer(pxOut);
	}

  /* Star Dialing */
	if (pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT) {	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Release In CLs :");
		eRet = IFX_CMGR_SendRelToInCls(pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX], pxLeg);
	}
	/*Reset Flag indicating that the context in no longer in Forking*/
    IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CNXT_IN_FORKING);

	/*Connect Paths*/
	IFX_CMGR_XConnect(pxCnxt->iResId,IFX_TRUE, IFX_TRUE,peReason);

	/* Set Peer pointers*/
	IFX_CMGR_SetPeerPtr(pxLeg,pxOut);	
	IFX_CMGR_SetPeerPtr(pxOut,pxLeg);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleMediaIntVoipAns
 *  Description     : Function handles a media matching in a Int-Voip call 
 *  						 where the Voip party answered.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleMediaIntVoipAns
							(	IN x_IFX_CMGR_CallLeg* pxLeg,
								IN x_IFX_CMGR_CallLeg* pxOut,
								IN int32 iResId,
								IN x_IFX_CMGR_VoipLegInfo* pxLegInfo,
								IN x_IFX_CMGR_MediaParams* pxMediaPar,
								OUT e_IFX_CMGR_Status* peStatus,
								OUT e_IFX_ReasonCode* peReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CodecParams xCodec;
	x_IFX_CMGR_RtpParams xRtp;
	boolean bMatched = IFX_TRUE;
	boolean bRtpDiffer = IFX_FALSE;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CodecParams *pxRecvCodecs =  
			&pxMediaPar->uxMediaParams.xVoipMediaParams.xCodecParams;
	x_IFX_CMGR_RtpParams* pxRecvRtp = 
			   &pxMediaPar->uxMediaParams.xVoipMediaParams.xRtpParams;
	x_IFX_CMGR_FaxParams* pxRecvFax = 
			   pxMediaPar->uxMediaParams.xVoipMediaParams.axFaxParams;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Check presence of any media parameters returned*/
	if(IFX_TRUE == IFX_CMGR_IsMediaPresent(pxRecvRtp
#ifdef FAX_SUPPORT
					,pxRecvFax, IFX_MAX_FAX_PROTO
#endif
													))
	{ 
		bRtpDiffer = IFX_CMGR_DoesRtpDiffer(pxRecvRtp, &pxLegInfo->xNegRtpParams);		  
		/*Media is present - Invoke Config Media & Start Session*/
		bMatched = IFX_CMGR_MatchMediaParams(
			&pxLegInfo->xOfferedCodecInfo,pxRecvCodecs,
			&pxLegInfo->xNegRtpParams, pxRecvRtp, &xCodec, &xRtp);
		
		if(IFX_TRUE == bMatched)
		{
#ifdef FAX_SUPPORT
			eRet  = IFX_CMGR_HandleFaxMediaNeg(pxLeg,
											&xCodec,pxLegInfo->axFaxParams,pxRecvFax);
			/* Set flag to indicate that this side was the initiator*/
			IFX_CMGR_SET_FLAG(pxLeg->pxCurrCnxt->unFlags,\
															 	IFX_CMGR_FLAG_FAX_INITIATOR);
#endif
			/*Copy the accepted codecs & RTP into their right places*/
			memcpy(&pxLegInfo->xNegRtpParams,
					&xRtp, sizeof(x_IFX_CMGR_RtpParams));
			
			memcpy(&pxLegInfo->xNegCodecInfo,
					&xCodec, sizeof(x_IFX_CMGR_CodecParams));

		/*
		Modify the order of the peer EXTN codecs if need be based on the logic
		if a WB codec is (not) the MPC on the VOIP side. Mostly needed to downgrade
 	  to a NB-NB codec scenario. Pass VOIP codec as the OUT codecs and the EXTN
		codec as the IN codec for the ReOrder Fn to work fine.	
 		*/
			if(IFX_CMGR_TYPE_EXTN == pxOut->xLegOwnerInfo.eOwnerType)					
			{
				IFX_CMGR_ReOrderCodecsForWB(&pxLegInfo->xNegCodecInfo,
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo,
					IFX_FALSE);		
			}
			/*Start Media Session*/		
			eRet = IFX_CMGR_InvokeMediaSession(pxLeg,iResId,bRtpDiffer,peReason);
		}
		else
		{	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
																		IFX_DBG_STR,"Media Mismatch in 200");
			eRet = IFX_FAILURE;
		}
	}
	else
	{	/* NO MEDIA IN 200 - Get Flag to indicate that the Early Media was Rxd*/
		if(!IFX_CMGR_GET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE))
		{
			/* DEBUG - NO EARLY MEDIA & NO SDP in 200 - PROBLEM*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
																						IFX_DBG_STR,"NO MEDIA IN 200");
			eRet = IFX_FAILURE;
		}
		else
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,\
																									"Media Cfg already done!");
		}
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}



/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnswerCallIntVoip
 *  Description     : Function handles a call answer from the Voip party in
 *  						 an Internal to Voip call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AnswerCallIntVoip
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_MediaParams xMediaPar;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 	
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg,IFX_CMGR_STATE_CONV,0);
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_CONV,0);

	/* Invoke pfnGetMediaParams - Check for the presence of Media*/
	memset(&xMediaPar,0,sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams (pxLeg,&xMediaPar);
	
	/* If Media is present then find negotiated codecs & RTP.
		 Invoke ConfigMedia & the pfnRtpSessionStart.*/
	if(IFX_FAILURE == IFX_CMGR_HandleMediaIntVoipAns(pxLeg, pxOut, 
				pxCnxt->iResId, pxLegInfo, &xMediaPar, peStatus, peReason))
	{
		/*DEBUG*/
		eRet = IFX_FAILURE;
		IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TERMINATED, NULL);
		IFX_CMGR_InvokeRemoteCallRelease(pxOut,IFX_TERMINATED, NULL);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}	
	/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
	if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
	{
		eRet = IFX_CMGR_InvokeRemCallAnswer(pxOut);
	}
	
	/* Set Peer pointers*/
	IFX_CMGR_SetPeerPtr(pxLeg,pxOut);	
	IFX_CMGR_SetPeerPtr(pxOut,pxLeg);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnswerCallFxoExtn
 *  Description     : Function handles a call answer from the Extn party in
 *  						 an Fxo to Extn call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AnswerCallFxoExtn
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	
	x_IFX_CMGR_MediaParams xMediaPar;
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = /*Extension Leg owner Info*/
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		  
	x_IFX_CMGR_CodecParams* pxRecvCodecs = 
		&xMediaPar.uxMediaParams.xExtnMediaParams.xCodecParams;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg,IFX_CMGR_STATE_CONV,0);
	/*Change state of OUT CL to Conversation*/
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_CONV,0);
	/*Add to the recieved calls list*/
	if(IFX_CMGR_TYPE_EXTN == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		x_IFX_CMGR_AddressInfo xAddr;
		memset(&xAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
		xAddr.eAddressType = IFX_CMGR_TYPE_FXO;
		memcpy(&xAddr.uxAddressInfo.xFxoInfo, 
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
				sizeof(x_IFX_CMGR_FxoInfo));
		IFX_LMGR_AddToRcvdCallReg(IFX_PSTN_LINE,&xAddr);	
	}
	/* Send pfnRemoteCallRelease to all other IN CLs. */
	if(pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT )
	{
		eRet = IFX_CMGR_SendRelToInCls(
							 pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX], pxLeg);
	}
	/*Reset Flag indicating that the context in no longer in Forking*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CNXT_IN_FORKING);
	/*Invoke pfnGetMediaParams on this to get the Codecs for this call*/
	memset(&xMediaPar,0,sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg,&xMediaPar);
	if(pxRecvCodecs->unNoOfCodecs)
	{
		/* Save negotiated codecs in the Negotiated codecs list*/		
		if(IFX_FALSE == IFX_CMGR_MatchMediaParams( 
				&pxExtnLegInfo->xOfferedCodecInfo,
				pxRecvCodecs, NULL, NULL, &pxExtnLegInfo->xNegCodecInfo, NULL))
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
	}
	/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
	if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
	{
		eRet = IFX_CMGR_InvokeRemCallAnswer(pxOut);
		/*Connect Paths*/
		IFX_CMGR_XConnect(pxCnxt->iResId,IFX_TRUE, IFX_TRUE,peReason);
	}
	/* Change ucNumCallLegs to IFX_CMGR_MIN_LEGS_PER_CNXT*/
	pxCnxt->ucNumCallLegs = IFX_CMGR_MIN_LEGS_PER_CNXT;
	/* Set Peer pointers*/
	IFX_CMGR_SetPeerPtr(pxLeg,pxOut);	
	IFX_CMGR_SetPeerPtr(pxOut,pxLeg);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnswerCallVoipInt
 *  Description     : Function handles a call answer from the Internal party 
 *  						 in a Voip to Internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AnswerCallVoipInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = /*Voip Leg owner Info*/
			&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;		  
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = /*Extension Leg owner Info*/
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;		  
	x_IFX_CMGR_MediaParams xMedia;
	x_IFX_CMGR_CodecParams* pxRecvCodecs = 
		&xMedia.uxMediaParams.xExtnMediaParams.xCodecParams;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason = IFX_MAX_REASON;
	/*Change the state of the CL*/
	IFX_CMGR_ChangeState(pxLeg,IFX_CMGR_STATE_CONV,0);

	/*Change state of OUT CL to Conversation*/
	IFX_CMGR_ChangeState(pxOut,IFX_CMGR_STATE_CONV,0);

	/*Add to the recieved calls list*/
	if(IFX_CMGR_TYPE_EXTN == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		x_IFX_CMGR_AddressInfo xAddr;
		memset(&xAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
		xAddr.eAddressType = IFX_CMGR_TYPE_VOIP;
		memcpy(&xAddr.uxAddressInfo.xVoipAddr,
						&pxVoipLegInfo->xRemAddr,sizeof(x_IFX_CMGR_VoipAddr));
		IFX_LMGR_AddToRcvdCallReg(pxVoipLegInfo->ucLineId,&xAddr);	
	}
	
	memset(&xMedia,0,sizeof(x_IFX_CMGR_MediaParams));
	/* Get media params from internal party*/
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);
	if(pxRecvCodecs->unNoOfCodecs)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "DECT ANSWERED VOIP CALL!!");
		/* Save codecs in the Negotiated codecs list*/		
		if(IFX_FALSE == IFX_CMGR_MatchMediaParams(
			&pxExtnLegInfo->xOfferedCodecInfo,
			pxRecvCodecs, NULL, NULL, &pxExtnLegInfo->xNegCodecInfo, NULL))
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
	}

	/*Check if the codecs returned from the EXTN is WB? If so then
	 change the Voip side to WB as well.*/
	IFX_CMGR_ReOrderCodecsForWB(&pxExtnLegInfo->xNegCodecInfo,
										&pxVoipLegInfo->xNegCodecInfo,IFX_FALSE);
		
	/* Invoke pfnRemoteCallAccept on the OUT CL if the Flag is not set*/
	if(!IFX_CMGR_GET_FLAG((pxCnxt->unFlags),IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN))
	{
		eRet = IFX_CMGR_InvokeRemCallAnswer(pxOut);
	}
	
	/* Send pfnRemoteCallRelease to all other IN CLs. */
	if(pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT )
	{
		eRet = IFX_CMGR_SendRelToInCls(
							 pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX], pxLeg);
	}
	/*Reset Flag indicating that the context in no longer in Forking*/
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_CNXT_IN_FORKING);
	/* Change ucNumCallLegs to IFX_CMGR_MIN_LEGS_PER_CNXT*/
	pxCnxt->ucNumCallLegs = IFX_CMGR_MIN_LEGS_PER_CNXT;
	/* Set Peer pointers*/
	IFX_CMGR_SetPeerPtr(pxLeg,pxOut);	
	IFX_CMGR_SetPeerPtr(pxOut,pxLeg);

	/*Start or Modify Session*/
	if((pxVoipLegInfo->eNegStatus == IFX_CMGR_OFFER_RXD) || (
			(pxVoipLegInfo->eNegStatus == IFX_CMGR_OFFER_SENT) && 
			(pxVoipLegInfo->xNegCodecInfo.unNoOfCodecs)))
	{	
		eRet = IFX_CMGR_InvokeMediaSession(pxOut,
											pxCnxt->iResId, IFX_TRUE, peReason);
/*CoC Power savings changes - STARTS*/
	#if 1
		/* Enable FAX tone detection*/
		if(IFX_MMGR_MftdEnable(pxCnxt->iResId, IFX_TRUE))
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
												IFX_DBG_STR, "MFTD Enable Failed");
		} 
	#endif
	/*END*/
	}
	
	if(IFX_SUCCESS !=eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ActUponAnswerCallInAtx
 *  Description     : Function does some repetetive actions in case of a call
 *  						 answer from CHILD CL.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ActUponAnswerCallInAtx
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg->pxParent;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Invoke the remote release function*/
	if(IFX_FALSE == pxParent->bByeRcvd)
	{
		/*Invoke pfnAttendedTxStatus on the Parent*/
			eRet = IFX_CMGR_InvokeAtxStatus(pxParent,
						 						IFX_CMGR_TRANSFER_ANSWERED,*peReason); 
		eRet = IFX_CMGR_InvokeRemoteCallRelease(pxParent,
							 					IFX_TRANSFER_SUCCESS,NULL);
	}
	else
	{
		/* At-least for one case STATUS is to be sent*/
		if(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)
				eRet = IFX_CMGR_InvokeAtxStatus(pxParent,
									IFX_CMGR_TRANSFER_ANSWERED,*peReason); 	
	}
	pxCnxt->eTypeOfTransfer = 0;
	pxCnxt->iResId = pxCnxt->iResIdForTransfer;
	pxCnxt->iResIdForTransfer = 0;
	IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxParent, pxLeg);
	pxLeg->pxParent = NULL;
	pxParent->pxPeer->pxPeer = pxLeg;
	pxLeg->pxPeer = pxParent->pxPeer;
	IFX_CMGR_DeAllocCallLeg(pxParent);
	/*Set new directions*/
	pxLeg->eDirection = IFX_CMGR_IN;
	pxLeg->pxPeer->eDirection = IFX_CMGR_OUT;
	/* Reset the Flag*/	
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ActUponAnswerCallInBtx
 *  Description     : Function does some repetetive actions in case of a call
 *  						 answer from CHILD CL in Blind transfer.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ActUponAnswerCallInBtx
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg->pxParent;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Invoke the remote release function*/
	if(IFX_FALSE == pxParent->bByeRcvd)
	{
		/*Invoke pfnBlindTxStatus on the Parent*/
		eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
						 						IFX_CMGR_TRANSFER_ANSWERED,*peReason); 
		eRet = IFX_CMGR_InvokeRemoteCallRelease(pxParent,
							 					IFX_TRANSFER_SUCCESS,NULL);
	}
	else
	{
		/* At-least for one case STATUS is to be sent*/
		if(IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)
			eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
						 						IFX_CMGR_TRANSFER_ANSWERED,*peReason); 
	}
	
	pxCnxt->eTypeOfTransfer = 0;
	pxCnxt->iResId = pxCnxt->iResIdForTransfer;
	pxCnxt->iResIdForTransfer = 0;
	IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxParent, pxLeg);
	pxLeg->pxParent = NULL;
	pxParent->pxPeer->pxPeer = pxLeg;
	pxLeg->pxPeer = pxParent->pxPeer;
	/*Set new directions*/
	pxLeg->eDirection = IFX_CMGR_IN;
	pxLeg->pxPeer->eDirection = IFX_CMGR_OUT;
	/* Reset the Flag*/	
	IFX_CMGR_RESET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY);
	IFX_CMGR_DeAllocCallLeg(pxParent);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnswerCallInAtx
 *  Description     : Function handles actions in case of a call answer from 
 *  						 Child CL.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AnswerCallInAtx
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg->pxParent;
	x_IFX_CMGR_MediaParams xMedia;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 	
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
	e_IFX_ReasonCode eReason  = IFX_MAX_REASON;
	x_IFX_CMGR_CodecParams xCodec ={0};
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/*Check if the current leg has a parent, else reject API with status FAIL*/
	if(!pxParent)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
		
	if(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)
	{
		/* InvokeStopRtpSession on the Old Call Leg*/
		IFX_CMGR_StopMediaSession(pxParent);			
	}

	if(IFX_CMGR_OUT == pxParent->eDirection)
	{
		/* Free the old resource Id*/
		eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
								pxParent->xLegOwnerInfo.szEndptId, 
									pxParent->pxPeer->xLegOwnerInfo.szEndptId,
									peReason);
	}else
	{
		eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
									pxParent->pxPeer->xLegOwnerInfo.szEndptId,
									pxParent->xLegOwnerInfo.szEndptId, 
									peReason);
	}
	/* Do some common actions*/
	eRet = IFX_CMGR_ActUponAnswerCallInAtx(pxLeg, peStatus, peReason);

	/* Invoke GetMediaParams */
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);

	/* Copy Peer leg neg codecs into a local temp place as they might 
		be over-written during IFX_CMGR_HandleMediaIntVoipAns*/
	memcpy(&xCodec,
		&pxLeg->pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo,
			sizeof(x_IFX_CMGR_CodecParams));

	/* start media*/	
	if(IFX_FAILURE == IFX_CMGR_HandleMediaIntVoipAns(pxLeg, pxLeg->pxPeer, 
				pxCnxt->iResId, pxLegInfo, &xMedia, peStatus, peReason))
	{
		/*DEBUG*/
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}	
	/*Change Leg state to Conv*/
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CONV, 0);

	/* Change parent's peer's state to Previous state*/
	IFX_CMGR_ChangeState(pxLeg->pxPeer, pxLeg->pxPeer->ePrevState, 0);

	/*Do Media Negotiation on the EXTN leg if needed*/	
	IFX_CMGR_DoExtnNegInTxAns(pxLeg->pxPeer,&xCodec,&eStatus,&eReason);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AnswerCallInBtx
 *  Description     : Function handles actions in case of a call answer from 
 *  						 Child CL.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AnswerCallInBtx
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg->pxParent;
	e_IFX_CMGR_Status eStatus=0;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = 	
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	x_IFX_CMGR_ExtnLegInfo* pxExtnLegInfo = 	
			&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Check if the current leg has a parent, else reject API with status FAIL*/
	if(!pxParent)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	
	if(IFX_CMGR_BTX_INT_INT_INT == pxCnxt->eTypeOfTransfer)
	{
		x_IFX_CMGR_MediaParams xMedia = {0};
		boolean bMatched = IFX_FALSE;
		x_IFX_CMGR_CodecParams *pxRem=NULL,*pxCod1=NULL,*pxCod2=NULL,xCodec={0};
		/* Free the old resource Id*/
		if(IFX_CMGR_OUT == pxParent->eDirection)
		{
			eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
								pxParent->xLegOwnerInfo.szEndptId, 
									pxParent->pxPeer->xLegOwnerInfo.szEndptId,
										peReason);
		}else
		{
			eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
									pxParent->pxPeer->xLegOwnerInfo.szEndptId,
									pxParent->xLegOwnerInfo.szEndptId, 
										peReason);
		}
	
		/*Is the pxLeg an extension party?*/
		if(IFX_CMGR_TYPE_EXTN == pxLeg->xLegOwnerInfo.eOwnerType)
		{
			/*Check if there are any codecs in its offered codec list?*/
			if(pxExtnLegInfo->xOfferedCodecInfo.unNoOfCodecs)
			{
				/*Invoke the GetMediaParams to get codecs for this endpoint*/
				eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);
				pxRem = &xMedia.uxMediaParams.xExtnMediaParams.xCodecParams;
				bMatched = IFX_CMGR_MatchMediaParams(&pxExtnLegInfo->xOfferedCodecInfo,
					pxRem, NULL, NULL, &pxExtnLegInfo->xNegCodecInfo, NULL);
				if(IFX_TRUE != bMatched)
				{
					/* Should not happen - Its a BUG - DEBUG*/
					IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
					return IFX_FAILURE;
				}
			}
		}
		
		/* Do some common actions*/
		eRet = IFX_CMGR_ActUponAnswerCallInBtx(pxLeg,peStatus,peReason);
		/*Connect Path*/
		eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_TRUE,IFX_TRUE,peReason);
		/*Change Leg state to Conv*/
		IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CONV,0);
		IFX_CMGR_ChangeState(pxLeg->pxPeer, pxLeg->pxPeer->ePrevState,0);
		
		/*If the new peer is an EXTN then that also may have 
			to negotiate a codec change at its end*/
		if(IFX_CMGR_TYPE_EXTN == pxLeg->pxPeer->xLegOwnerInfo.eOwnerType)
		{
			if(IFX_CMGR_TYPE_FXO != pxLeg->xLegOwnerInfo.eOwnerType)
			{
				pxCod1 = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;
			}
			else
			{
				pxCod1 = &xCodec;
			}
			pxCod2 = &pxLeg->pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;
			/*Re-Order Codecs on the peer side, if needed*/
			IFX_CMGR_ReOrderCodecsForWB(pxCod1,pxCod2,IFX_FALSE);
			/*Do common actions for Re-Neg*/	
			IFX_CMGR_DoExtnNegInTxAns(pxLeg->pxPeer,pxCod2,&eStatus,&eReason);
		}
	}else
	if(IFX_CMGR_BTX_INT_VOIP_INT == pxCnxt->eTypeOfTransfer)
	{
		/*TO DO -Invoke GetMediaParams on the Child to get media -DECT*/

		eRet = IFX_CMGR_MoveMediaResource(pxCnxt->iResId, 
							 pxParent->xLegOwnerInfo.szEndptId, 
							 pxLeg->xLegOwnerInfo.szEndptId, peReason);	
		if(IFX_FAILURE == eRet)
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet; /*DEBUG*/
		}
		eRet=IFX_CMGR_InvokeRemoteCallRelease(pxParent,IFX_TRANSFER_SUCCESS,NULL);
		eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
							 IFX_CMGR_TRANSFER_ANSWERED,*peReason); 	
		IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxParent, pxLeg);
		pxLeg->pxParent = NULL;
		pxLeg->pxPeer = pxParent->pxPeer;
		pxParent->pxPeer->pxPeer = pxLeg;
		IFX_CMGR_DeAllocCallLeg(pxParent);
		
		/* Invoke Call Resume on the Child - Change state of Child to HELD*/
		IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_HELD, 0);
		IFX_CMGR_ChangeState(pxLeg->pxPeer, pxLeg->pxPeer->ePrevState, 0);
		eRet = IFX_CMGR_ResumeCallIntVoip(pxLeg, &eStatus, peReason);	
	}
	else
	{
		/* This is BTX INT_INT_VOIP & BTX VOIP_INT_VOIP relate section*/
		x_IFX_CMGR_MediaParams xMedia;
		e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
		e_IFX_ReasonCode eReason  = IFX_MAX_REASON;
		x_IFX_CMGR_CodecParams xCodec = {0};	
		x_IFX_CMGR_CodecParams *pxCodecs = NULL; 
			
		if(IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)
		{
			/* InvokeStopRtpSession on the Old Call Leg*/
			IFX_CMGR_StopMediaSession(pxParent);
		}
		if(IFX_CMGR_OUT == pxParent->eDirection)
		{
			/* Free the old resource Id*/
			eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
								pxParent->xLegOwnerInfo.szEndptId, 
									pxParent->pxPeer->xLegOwnerInfo.szEndptId,
										peReason);
		}else
		{
			eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
									pxParent->pxPeer->xLegOwnerInfo.szEndptId,
									pxParent->xLegOwnerInfo.szEndptId, 
										peReason);
		}

		/* Do some common actions*/
		eRet = IFX_CMGR_ActUponAnswerCallInBtx(pxLeg, peStatus, peReason);
		/* Invoke GetMediaParams */
		eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);

		pxCodecs = 
			&pxLeg->pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;
		/* Copy Peer leg neg codecs into a local temp place as they might 
			be over-written during IFX_CMGR_HandleMediaIntVoipAns*/
		if((pxCodecs->unNoOfCodecs)&&
			(IFX_CMGR_TYPE_EXTN == pxLeg->pxPeer->xLegOwnerInfo.eOwnerType))
		{
			memcpy(&xCodec,pxCodecs,sizeof(x_IFX_CMGR_CodecParams));
		}
		
		/* start media*/
		if(IFX_FAILURE == IFX_CMGR_HandleMediaIntVoipAns(pxLeg, pxLeg->pxPeer, 
				pxCnxt->iResId, pxLegInfo, &xMedia, peStatus, peReason))
		{
			/*DEBUG*/
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}	
	
		/*Change Leg state to Conv*/
		IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CONV, 0);

		/* Change peer's state to Previous state*/
		IFX_CMGR_ChangeState(pxLeg->pxPeer, pxLeg->pxPeer->ePrevState, 0);
		
		/*Do Media Negotiation on the EXTN leg if needed*/	
		IFX_CMGR_DoExtnNegInTxAns(pxLeg->pxPeer,&xCodec,&eStatus,&eReason);
	}
			  
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	Will be called to inform the call manager that the agent 
					has answered the incoming call
	\param[in]	 uiCallId is the identifier of the call
	\param[out]	peStatus is the status of the Req
	\param[out]	peReason - incase of failure, this parameter provides the 
					specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallAnswer(
								IN uint32 uiCallId,
					 			OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);

	/* Array of pointers to functions*/
	pfn_IFX_CMGR_AnswerCall pfnaAnswerCall[IFX_CMGR_BCT_MAX] = 
										{  
											IFX_CMGR_IgnoreAnswerCall, /* For Zero*/
											IFX_CMGR_IgnoreAnswerCall,
											IFX_CMGR_AnswerCallExtnInt,
											IFX_CMGR_AnswerCallIntVoip,
											IFX_CMGR_AnswerCallExtnInt,
											IFX_CMGR_AnswerCallIntVoip,
											IFX_CMGR_AnswerCallFxoExtn,
											IFX_CMGR_AnswerCallVoipInt,
											IFX_CMGR_AnswerCallVoipInt
										};
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return IFX_FAILURE;
	}
	
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	*peReason =  IFX_MAX_REASON;
	
	/*Check State of the LEG*/
	if(!(((pxLeg->eCurrState == IFX_CMGR_RECV_RESP_PENDING) && 
			(pxLeg->eRespPendEvt == IFX_CMGR_RESP_PEND_INVITE ))
			|| (pxLeg->eCurrState == IFX_CMGR_STATE_RINGING)) )
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return eRet;
	}

	/* Check for blind transfer related scenarios*/
	if((pxCnxt->eTypeOfTransfer < IFX_CMGR_BTX_MAX_TYPE) &&
			(pxCnxt->eTypeOfTransfer >= IFX_CMGR_BTX_INT_VOIP_VOIP))
	{
		eRet = IFX_CMGR_AnswerCallInBtx(pxLeg, peStatus, peReason);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/* Check for attended transfer related scenarios*/
	if((pxCnxt->eTypeOfTransfer < IFX_CMGR_ATX_MAX_TYPE) &&
			(pxCnxt->eTypeOfTransfer >= IFX_CMGR_ATX_INT_VOIP_VOIP))
	{
		eRet = IFX_CMGR_AnswerCallInAtx(pxLeg, peStatus, peReason);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	eRet = pfnaAnswerCall[pxCnxt->eBasicCallType](pxLeg,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"After Answering");
	IFX_CMGR_PrintCallIdList(__FUNCTION__);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HoldCallVoipInt
 *  Description     : Function handles call hold request from Voip party in a 
 *  						 Voip-Internal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HoldCallVoipInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
	x_IFX_CMGR_VoipLegInfo* pxInfo = NULL;
		
	x_IFX_CMGR_MediaParams xMedia;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	if (pxLeg){
		pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
		pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
		pxInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	}else{
		return IFX_FAILURE;
	}
	if (!pxInfo || !pxCnxt || !pxPeer){
		return IFX_FAILURE;
	}
	/* Change state of this Leg to SRP (Hold) */
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_HOLD);
	
	/* If the state of the peer CL is CONV/HOLD change its state to RRP(Hold)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_HOLD);
	/*
	 * 	Invoke pfnGetMediaParams on the CL  If SDP is returned, then save them 
	 * 	in the temp Codecs/Rtp. Change the SDP mode to inactive/recv-only.
	 */
	memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia); 
	
	if(IFX_TRUE == IFX_CMGR_IsMediaPresent(
		&xMedia.uxMediaParams.xVoipMediaParams.xRtpParams
#ifdef FAX_SUPPORT
		,xMedia.uxMediaParams.xVoipMediaParams.axFaxParams, IFX_MAX_FAX_PROTO
#endif
		))
	{
		/* Copy Media into the Temp Space- Also add local media information*/
		IFX_CMGR_MatchMediaParams( &pxInfo->xOfferedCodecInfo,
			&xMedia.uxMediaParams.xVoipMediaParams.xCodecParams,
			&pxInfo->xNegRtpParams,
			&xMedia.uxMediaParams.xVoipMediaParams.xRtpParams,
			&pxInfo->xTempCodecInfo, &pxInfo->xTempRtpParams);

	}

	eRet = IFX_CMGR_InvokeRemoteCallHold(pxPeer, peStatus, peReason);	
	if(IFX_FAILURE == eRet)
	{
		/*Debug*/
		return IFX_FAILURE;
	}
	
	/*	Invoke pfnRemoteCallHold function on the CL and when it returns check
	 * its status. 
	 * a) If its SUCCESS, Change the state of the leg to HELD and the 
	 * 	the other CL to whatever it was before RRP. Also invoke ModifyMedia &
	 * 	RtpSessionModify (if needed) using the values in the temp variables. 
	 * 	Copy the same into the the accepted codecs and rtp params in the CL.
	 * b) If the status is FAILURE then change state back to what they were 
	 * 	before RRP and SRP. Return the API with status FAILURE.
	 *	c) If the status was PENDING, then do not change states and return 
	 *		API with status PENDING.
	 */
	switch(*peStatus)
	{
		case IFX_CMGR_STATUS_SUCCESS:
		{
			boolean bRtpDiffer = IFX_FALSE;
			IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_HELD, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
			
			/* Save temp codecs in the accepted codecs list*/
			if(pxInfo->xTempCodecInfo.unNoOfCodecs)	
				memcpy( &pxInfo->xNegCodecInfo, &pxInfo->xTempCodecInfo, 
							sizeof(x_IFX_CMGR_CodecParams));
			/* Check if the RTCP/RTP IP address/port changed
			 * then invoke the RTP Modify Session also*/
			bRtpDiffer = IFX_CMGR_DoesRtpDiffer(
				&pxInfo->xNegRtpParams, &pxInfo->xTempRtpParams);
			/*Copy the temp RTP values into the Negotaited RTP values*/
			memcpy( &pxInfo->xNegRtpParams,  
						&pxInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
			eRet = IFX_CMGR_ModifyMediaSession(pxLeg, pxPeer,
								 				pxCnxt->iResId,bRtpDiffer, peReason);
			if(IFX_FAILURE == eRet)
			{
				return eRet; /*DEBUG*/
			}
			memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));
			memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
		}
		break;

		case IFX_CMGR_STATUS_FAIL:
		{
			IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
			/* Clear the temp codecs/rtp params*/
			memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));
			memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
			
		}
		break;
		case IFX_CMGR_STATUS_PENDING:
		default:
		break;
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HoldCallSucIntVoip
 *  Description     : Function handles call hold response from Internal 
 *  						party in a Voip-Internal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HoldCallSucIntVoip
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
	x_IFX_CMGR_VoipLegInfo* pxInfo = NULL;
	boolean bRtpDiffer = IFX_FALSE;		
	x_IFX_CMGR_CallContext* pxCnxt = NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(pxLeg){
		pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
		if (pxPeer){
			pxInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
		}else{
			return IFX_FAILURE;
		}
		pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	}else{
		return IFX_FAILURE;
	}
	if (!pxInfo || !pxCnxt){
		return IFX_FAILURE;
	}
	/* Save temp codecs in the accepted codecs list*/
	if(pxInfo->xTempCodecInfo.unNoOfCodecs)	
		memcpy( &pxInfo->xNegCodecInfo, &pxInfo->xTempCodecInfo, 
							sizeof(x_IFX_CMGR_CodecParams));
	
	/* Check if the mode is the RTCP/RTP IP address/port changed
	 * then invoke the RTP Modify Session also*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(
			&pxInfo->xNegRtpParams, &pxInfo->xTempRtpParams);
	
	/*Copy the temp RTP values into the Negotaited RTP values*/
	memcpy( &pxInfo->xTempRtpParams,  
		&pxInfo->xNegRtpParams, sizeof(x_IFX_CMGR_RtpParams));

	/*Invoke RTP Modify session with the temp values*/
	eRet = IFX_CMGR_ModifyMediaSession(pxPeer, pxLeg,pxCnxt->iResId,
							 									bRtpDiffer, peReason);
	memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));
	memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HoldCallIntVoip
 *  Description     : Function handles call hold request from Int party in a 
 *  						 Internal-Voip call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HoldCallIntVoip
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
		
	x_IFX_CMGR_VoipLegInfo* pxPeerInfo = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	/*  If the state of the peer CL is not CONV/HOLD, then reject the API*/
	if (pxLeg){
		pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	}else{
		return IFX_FAILURE;
	}

	if (pxPeer){
		pxPeerInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	}else{
		return IFX_FAILURE;
	}

	if (!pxPeerInfo){
		return IFX_FAILURE;
	}

	if(((pxPeer->eCurrState != IFX_CMGR_STATE_CONV) &&
		(pxPeer->eCurrState != IFX_CMGR_STATE_HELD)))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/* Change state of this Leg to SRP (Hold) */
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_HOLD);
	
	/* If the state of the peer CL is CONV/HOLD change its state to RRP(Hold)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_HOLD);
	
	 /* Copy the accepted codecs/rtp into the temp codecs/rtp params. Change the
		 SDP mode in the temp RTP Params to INACTIVE. This will be used when the 
		 NA invokes GetMediaParams API. 
	 */
	memcpy(&pxPeerInfo->xTempCodecInfo, &pxPeerInfo->xNegCodecInfo, 
						 		sizeof(x_IFX_CMGR_CodecParams));
	memcpy(&pxPeerInfo->xTempRtpParams, &pxPeerInfo->xNegRtpParams, 
						 		sizeof(x_IFX_CMGR_RtpParams));
	pxPeerInfo->xTempRtpParams.eSdpMode = IFX_INACTIVE;
			  
	/*
	 *	Invoke pfnRemoteCallHold function on the CL and when it returns check
	 * its status.  If the status is FAILURE then change state back to what they were 
	 * before RRP and SRP. Clear the Temp Codecs/RTP in the peer leg.
	 * Return the API with status FAILURE.
	 */
	eRet = IFX_CMGR_InvokeRemoteCallHold(pxPeer, peStatus, peReason);	
	if((IFX_FAILURE == eRet)||(IFX_CMGR_STATUS_FAIL == *peStatus))
	{
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);

		memset(&pxPeerInfo->xTempRtpParams,0,sizeof(x_IFX_CMGR_RtpParams));
		memset(&pxPeerInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*****************************************************************************
 *  Function Name   : IFX_CMGR_HoldCallSucVoipInt
 *  Description     : Function handles call hold response from the Voip
 *  						party in a Voip -Internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HoldCallSucVoipInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_VoipLegInfo* pxInfo = 
		&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	x_IFX_CMGR_MediaParams xMedia;
	x_IFX_CMGR_CodecParams* pxRecvCodecs;
	x_IFX_CMGR_RtpParams* pxRecvRtp;
	boolean bRtpDiffer = IFX_TRUE;
	boolean bMatched = IFX_TRUE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	/* Invoke pfnGetMediaParams to find if any Rsp was media received with 
	 	the Hold Req. */
	memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);
			
	pxRecvCodecs = &xMedia.uxMediaParams.xVoipMediaParams.xCodecParams;
	pxRecvRtp = &xMedia.uxMediaParams.xVoipMediaParams.xRtpParams;
	
	/*Check if any imp RTP parameter differs*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(pxRecvRtp, &pxInfo->xTempRtpParams);
	
	/* Try and match media*/	
	bMatched = IFX_CMGR_MatchMediaParams(&pxInfo->xOfferedCodecInfo, pxRecvCodecs,
		&pxInfo->xTempRtpParams, pxRecvRtp, &pxInfo->xNegCodecInfo, 
		&pxInfo->xNegRtpParams);
	if(IFX_FALSE == bMatched)
	{
		memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));	
		memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
		/*DEBUG*/ 
		/* TO DO What to do?*/
	}
	/* Invoke ModifyMedia */
	eRet = IFX_CMGR_ModifyMediaSession(pxLeg, pxPeer,
						 pxCnxt->iResId, bRtpDiffer, peReason);

	memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));	
	memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HoldCallIntInt
 *  Description     : Function handles call hold request from Int party in a 
 *  						 Internal-Inetrnal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HoldCallIntInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	if (pxLeg){
		pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
		pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	}else{
		return IFX_FAILURE;
	}

	if (!pxCnxt || !pxPeer){
		return IFX_FAILURE;
	}

	/* Change state of this Leg to SRP (Hold) */
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_HOLD);
	/* If the state of the peer CL is CONV/HOLD change its state to RRP(Hold)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_HOLD);
	/*Inform the other side about the hold request*/	
	eRet = IFX_CMGR_InvokeRemoteCallHold(pxPeer, peStatus, peReason);	
	if(IFX_FAILURE == eRet)
	{
		/*Debug*/
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,\
												IFX_DBG_STR,"Call Hold FAILED!");
		eRet = IFX_SUCCESS;
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}
		
	/*
	 *	Invoke pfnRemoteCallHold function on the CL and when it returns check
	 * its status. 
	 *    	a) If its SUCCESS, Change the state of the leg to HELD and the 
	 *    		the other CL to whatever it was before RRP. 
	 *    		Also invoke ModifyMedia to cut the path.  
	 *    	b) If the status is FAILURE then change state back to what they were
	 *    	    before RRP and SRP. Return the API with status FAILURE.
	 *			c) If the status was PENDING, then do not change states and return
	 *			    API with PENDING.
	 * */

	switch(*peStatus)
	{
		case IFX_CMGR_STATUS_FAIL:
		{
			IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
		}
		break;

		case IFX_CMGR_STATUS_SUCCESS:
		{
			IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_HELD, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
			/* Invoke X Disconnect*/	
			eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_FALSE, IFX_FALSE,peReason);
		}
		break;
		case IFX_CMGR_STATUS_PENDING:
		default:
		break;
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HoldCallSucIntInt
 *  Description     : Function handles call hold response from the internal
 *  						party in a Internal -Internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HoldCallSucIntInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}
	
 	/*	Invoke MediaManager to break the connection.*/
	eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_FALSE, IFX_FALSE,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}



/*!
	\brief	Will be invoked by an agent when it wants to put an ongoing call to hold
	\param[in]	 uiCallId is the identifier of the call
	\param[out]	 peStatus is the status of the Req as given by the remote agent
	\param[out]	 peReason - incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallHold(
							IN uint32 uiCallId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason /*If Failure*/
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

#ifdef FAX_SUPPORT
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
	{
		/*If FAX session is going on the do not accept the request*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
#endif	
	/*If Call is already in Hold State - Return Success*/
	if(pxLeg->eCurrState == IFX_CMGR_STATE_HELD){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Already Held");
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		return IFX_SUCCESS;
	}
	/*Check State of the LEG*/
	if(pxLeg->eCurrState != IFX_CMGR_STATE_CONV)
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*  If the state of the peer CL is not CONV/HOLD, then reject the API*/
	if(((pxPeer->eCurrState != IFX_CMGR_STATE_CONV) &&
		(pxPeer->eCurrState != IFX_CMGR_STATE_HELD)))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	if( IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType)
	{
		/* Its a internal party*/
		if (IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
		{
			/*Its an INT to VOIP HOLD*/
			eRet = IFX_CMGR_HoldCallIntVoip(pxLeg, peStatus, peReason);
		}
		else
		{
			/* Its an Internal to Internal Hold*/
			eRet = IFX_CMGR_HoldCallIntInt(pxLeg, peStatus, peReason);
		}
	}
	else
	{
		/*Its a Voip Party  - so its a Voip -> Internal Hold*/
			eRet = IFX_CMGR_HoldCallVoipInt(pxLeg, peStatus, peReason);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;

	/*
	 * Call Hold API is used by an agent to Hold the call from its end. 
	 * 1) If the state of the CL is not CONV then reject the API.
	 * 2) Change the state of the CL to SRP(Hold). 
	 * 3) Invoke pfnGetMediaParams on the CL if the CL belongs to NA. If SDP
	 *    is returned then check if something has changed by comparing it 
	 *    against the Codecs/RTP maintained in the CL. If there is a change in
	 *    the Codecs then compare them against the offered & accepted codecs/rtp.
	 *    Save them in a temp accepted codecs/rtp list. Change the SDP mode to
	 *    inactive.
	 * 3) Using the peer pointer goto the peer CL.   
	 * 4) If the state of the peer CL is not CONV/HOLD, then reject the API
	 *    after changing the intiator CL's state back to CONV.
	 * 5) If the state of the peer CL is CONV/HOLD change its state to RRP(Hold)
	 * 	and then:
	 * 	5a) If the peer CL is NA leg then since the call is to be held, copy the
	 * 		 accepted codecs/rtp into the temp codecs/rtp params. Change the
	 * 	    SDP mode in the temp RTP Params to INACTIVE. This will be 
	 * 	    used when the NA invokes GetMediaParams API. 
	 * 6) Invoke pfnRemoteCallHold function on the CL and when it returns check
	 *    its status. 
	 *    	6a) If its SUCCESS, Change the state of the leg to HELD and the 
	 *    	the other CL to whatever it was before RRP. Also:
	 *    			1) If the CL on which the CallHold was
	 *    		 	invoked is a CL owned by NA then invoke ModifyMedia &
	 *    		 	RtpSessionModify using the values in the temp variables. Copy
	 *    		 	the same into the the accpeted codecs and rtp params in the CL.
	 *    		 	2) If its owned by a non-NA agent then invoke 
	 *    		 	only ModifyMedia to cut the path. 
	 *    	6b) If the status is FAILURE then change state back to what they were
	 *    	    before RRP and SRP. Return the API with status FAILURE.
	 *			6c) If the status was PENDING, then do not change states and return
	 *			    API with PENDING.
	 * */
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ResumeCallVoipInt
 *  Description     : Function handles call resume request from Voip party in a 
 *  						 Voip-Internal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ResumeCallVoipInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_VoipLegInfo* pxInfo = 
			  &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	boolean bMatched = IFX_TRUE;		
	x_IFX_CMGR_MediaParams xMedia;
	boolean bRtpDiffer = IFX_FALSE;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	/* Change state of this Leg to SRP (Resume) */
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_RESUME);
	
	/* change peer state to RRP(RESUME)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_RESUME);
	/*
	 * 	Invoke pfnGetMediaParams on the CL  If SDP is returned, then save them 
	 * 	in the temp Codecs/Rtp. Change the SDP mode to inactive/recv-only.
	 */
	memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia); 
	
	if(IFX_TRUE == IFX_CMGR_IsMediaPresent(
		&xMedia.uxMediaParams.xVoipMediaParams.xRtpParams
#ifdef FAX_SUPPORT
		,xMedia.uxMediaParams.xVoipMediaParams.axFaxParams, IFX_MAX_FAX_PROTO
#endif
		))
	{
		/* Copy Media into the Temp Space- Also add local media information*/
		bMatched = IFX_CMGR_MatchMediaParams(
				&pxInfo->xOfferedCodecInfo,
				&xMedia.uxMediaParams.xVoipMediaParams.xCodecParams,
				&pxInfo->xNegRtpParams,
				&xMedia.uxMediaParams.xVoipMediaParams.xRtpParams,
				&pxInfo->xTempCodecInfo, 
				&pxInfo->xTempRtpParams);
		if(IFX_FALSE == bMatched)
		{
			*peStatus = IFX_CMGR_STATUS_FAIL;
			*peReason = IFX_MEDIA_MISMATCH;
			return eRet;
		}
	}

	eRet = IFX_CMGR_InvokeRemoteCallResume(pxPeer, peStatus, peReason);	
	if(IFX_FAILURE == eRet)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	switch(*peStatus)
	{
		case IFX_CMGR_STATUS_SUCCESS:
		{
			IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CONV, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
			/* Save temp codecs in the accepted codecs list*/
			if(pxInfo->xTempCodecInfo.unNoOfCodecs)	
				memcpy( &pxInfo->xNegCodecInfo, &pxInfo->xTempCodecInfo, 
							sizeof(x_IFX_CMGR_CodecParams));
			/* Check if the RTCP/RTP IP address/port changed
			 * then invoke the RTP Modify Session also*/
			bRtpDiffer = IFX_CMGR_DoesRtpDiffer(
				&pxInfo->xNegRtpParams, &pxInfo->xTempRtpParams);
			/*Copy the temp RTP values into the Negotaited RTP values*/
			memcpy( &pxInfo->xNegRtpParams,  
						&pxInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
			eRet = IFX_CMGR_ModifyMediaSession(pxLeg, pxPeer,
								 pxCnxt->iResId,bRtpDiffer, peReason);
			if(IFX_FAILURE == eRet)
				return eRet; /*DEBUG*/
			memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));
			memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
		}
		break;

		case IFX_CMGR_STATUS_FAIL:
		{
			IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
			/* Clear the temp codecs/rtp params*/
			memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));
			memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
			
		}
		break;
		case IFX_CMGR_STATUS_PENDING:
		default:
		break;
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ResumeCallSucIntVoip
 *  Description     : Function handles call resume response from Internal 
 *  						party in a Voip-Internal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ResumeCallSucIntVoip
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
	x_IFX_CMGR_CallContext* pxCnxt = NULL;
	x_IFX_CMGR_VoipLegInfo* pxInfo = NULL;
	boolean bRtpDiffer = IFX_FALSE;		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	if (pxLeg){
		pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
		pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	}else{
		return IFX_FAILURE;
	}

	if (!pxPeer || !pxCnxt){
		return IFX_FAILURE;
	}

	pxInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;

	/* Save temp codecs in the accepted codecs list*/
	if(pxInfo->xTempCodecInfo.unNoOfCodecs)	
		memcpy( &pxInfo->xNegCodecInfo, &pxInfo->xTempCodecInfo, 
							sizeof(x_IFX_CMGR_CodecParams));
	/* Check if the RTCP/RTP IP address/port changed
	* then invoke the RTP Modify Session also*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(
		&pxInfo->xNegRtpParams, &pxInfo->xTempRtpParams);
	/*Copy the temp RTP values into the Negotaited RTP values*/
	memcpy( &pxInfo->xNegRtpParams,  
				&pxInfo->xTempRtpParams, sizeof(x_IFX_CMGR_RtpParams));
	eRet = IFX_CMGR_ModifyMediaSession(pxLeg, pxPeer,
						 pxCnxt->iResId,bRtpDiffer, peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ResumeCallIntVoip
 *  Description     : Function handles call resume request from Int party in a 
 *  						 Internal-Voip call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ResumeCallIntVoip
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
		
	x_IFX_CMGR_VoipLegInfo* pxPeerInfo = 
			  &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	/* Change state of this Leg to SRP (RESUME) */
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_RESUME);
	
	/*change peer state to RRP(Resume)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_RESUME);

	
	 /* Copy the accepted codecs/rtp into the temp codecs/rtp params. Change the
		 SDP mode in the temp RTP Params to right mode. This will be used when the 
		 NA invokes GetMediaParams API. 
	 */
	memcpy(&pxPeerInfo->xTempCodecInfo, &pxPeerInfo->xNegCodecInfo, 
						 		sizeof(x_IFX_CMGR_CodecParams));
	memcpy(&pxPeerInfo->xTempRtpParams, &pxPeerInfo->xNegRtpParams, 
						 		sizeof(x_IFX_CMGR_RtpParams));

	/*A right Mode has to used based on the current local mode. */
	if(IFX_CMGR_STATE_HELD == pxPeer->eCurrState)
	{
		if(IFX_INACTIVE == pxPeerInfo->xNegRtpParams.eSdpMode)
		{
			pxPeerInfo->xTempRtpParams.eSdpMode = IFX_RECVONLY;
		}
	}	
	else
	{
			/*Remote Party is not held*/
			pxPeerInfo->xTempRtpParams.eSdpMode = IFX_SENDRECV;
	}
	eRet = IFX_CMGR_InvokeRemoteCallResume(pxPeer, peStatus, peReason);	
	if((IFX_FAILURE == eRet)|| (*peStatus == IFX_CMGR_STATUS_FAIL))
	{
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);

		memset(&pxPeerInfo->xTempRtpParams,0,sizeof(x_IFX_CMGR_RtpParams));
		memset(&pxPeerInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ResumeCallSucVoipInt
 *  Description     : Function handles call resume response from the Voip
 *  						party in a Voip -Internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ResumeCallSucVoipInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_VoipLegInfo* pxInfo = 
		&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	boolean bRtpDiffer = IFX_FALSE;
	boolean bMatched = IFX_FALSE;
	x_IFX_CMGR_MediaParams xMedia;
	//x_IFX_CMGR_CodecParams* pxRecvCodecs;
	x_IFX_CMGR_RtpParams* pxRecvRtp;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	/* Invoke pfnGetMediaParams to find if any Rsp was media received with 
	 	the Resume Req. */
	memset(&xMedia, 0, sizeof(x_IFX_CMGR_MediaParams));
	eRet = IFX_CMGR_InvokeGetMediaParams(pxLeg, &xMedia);
	//pxRecvCodecs = &xMedia.uxMediaParams.xVoipMediaParams.xCodecParams;
	pxRecvRtp = &xMedia.uxMediaParams.xVoipMediaParams.xRtpParams;

	/*Check if any imp RTP parameter differs*/
	bRtpDiffer = IFX_CMGR_DoesRtpDiffer(pxRecvRtp, &pxInfo->xTempRtpParams);
	
	/* Try and match media*/	
	bMatched = IFX_CMGR_MatchMediaParams(
				&pxInfo->xOfferedCodecInfo,
				&xMedia.uxMediaParams.xVoipMediaParams.xCodecParams,
				&pxInfo->xTempRtpParams,
				&xMedia.uxMediaParams.xVoipMediaParams.xRtpParams,
				&pxInfo->xNegCodecInfo, 
				&pxInfo->xNegRtpParams);
	if(IFX_FALSE == bMatched)
	{
		memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));	
		memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
		/*DEBUG*/ 
		/* TO DO What to do?*/
	}
	/* Invoke ModifyMedia */
	eRet = IFX_CMGR_ModifyMediaSession(pxLeg,pxPeer,
						 pxCnxt->iResId, bRtpDiffer, peReason);

	memset(&pxInfo->xTempRtpParams, 0, sizeof(x_IFX_CMGR_RtpParams));	
	memset(&pxInfo->xTempCodecInfo, 0, sizeof(x_IFX_CMGR_CodecParams));
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ResumeCallIntInt
 *  Description     : Function handles resume request from Int party in a 
 *  						 Internal-Inetrnal call
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ResumeCallIntInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
		
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	/* Change state of this Leg to SRP (RESUME) */
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_RESUME);
	
	/* If the state of the peer CL is CONV/HOLD change its state to RRP(Resume)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_RESUME);
	
	eRet = IFX_CMGR_InvokeRemoteCallResume(pxPeer, peStatus, peReason);	
	if(IFX_FAILURE == eRet)
	{
		/*Debug*/
		return IFX_FAILURE;
	}

	/*Check the status and take appropriate action*/
	switch(*peStatus)
	{
		case IFX_CMGR_STATUS_FAIL:
		{
			IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
		}
		break;

		case IFX_CMGR_STATUS_SUCCESS:
		{
			/* Invoke X connect if the peer party is not in held state*/
			if(IFX_CMGR_STATE_HELD  != pxPeer->ePrevState)
				eRet = IFX_CMGR_XConnect(pxCnxt->iResId, IFX_TRUE, IFX_FALSE,peReason);
			IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CONV, 0);
			IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
		}
		case IFX_CMGR_STATUS_PENDING:
		default:
		break;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ResumeCallSucIntInt
 *  Description     : Function handles call resume response from the internal
 *  						party in a Internal -Internal call.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ResumeCallSucIntInt
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!pxPeer)
	{
		/*Debug*/
		return IFX_FAILURE;
	}
	
 	/*	Invoke MediaManager to make the connection.*/
	if(IFX_CMGR_STATE_HELD  != pxLeg->ePrevState)
		eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_TRUE,IFX_FALSE,peReason);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	Will be invoked by an agent when it wants to resume a held call
	\param[in]	 uiCallId is the identifier of the call
	\param[out]	 peStatus is the status of the Req as given by the remote agent
	\param[out]	 peReason - incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallResume(
								IN uint32 uiCallId,
								OUT e_IFX_CMGR_Status* peStatus,
								OUT e_IFX_ReasonCode* peReason /*If Failure*/
								)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	
#ifdef FAX_SUPPORT
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
	{
		/*If FAX session is going on the do not accept the request*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
#endif	
	/*Check State of the LEG*/
	if(pxLeg->eCurrState != IFX_CMGR_STATE_HELD)
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Check the state of the Peer Leg - If not CONV/HELD reject API*/
	if((pxPeer->eCurrState != IFX_CMGR_STATE_HELD) &&
		(pxPeer->eCurrState != IFX_CMGR_STATE_CONV))
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}

	/* Check the kid of resume function to be invoked*/
	if( IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType)
	{
		/* Its a internal party*/
		if (IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
		{
			/*Its an INT to VOIP Resume*/
			eRet = IFX_CMGR_ResumeCallIntVoip(pxLeg, peStatus, peReason);
		}
		else
		{
			/* Its an Internal to Internal Resume*/
			eRet = IFX_CMGR_ResumeCallIntInt(pxLeg, peStatus, peReason);
		}
	}
	else
	{
		/*Its a Voip Party  - so its a Voip -> Internal Resume*/
			eRet = IFX_CMGR_ResumeCallVoipInt(pxLeg, peStatus, peReason);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
	/*
	 * Call Resume API is used by an agent to resume the call from its end. 
	 * 1) If the state of the CL is not HELD then reject the API.
	 * 2) Change the state of the CL to SRP(RESUME). 
	 * 3) Invoke pfnGetMediaParams on the CL if the CL belongs to NA. If SDP
	 *    is returned then check if something has changed by comparing it 
	 *    against the Codecs/RTP maintained in the CL. If there is a change in
	 *    the Codecs then compare them against the offered & accepted codecs/rtp.
	 *    Save them in a temp accepted codecs/rtp list. 
	 * 3) Using the peer pointer goto the peer CL.   
	 * 4) If the state of the peer CL is not CONV/HOLD, then reject the API
	 *    after changing the intiator CL's state back to HELD.
	 * 5) If the state of the peer CL is CONV/HOLD change its state to RRP(Resume)
	 * 	and then:
	 * 	5a) If the peer CL is NA leg then since the call is to be resumed, copy 
	 * 		 offered codecs/rtp into the temp codecs/rtp params. Change the
	 * 	    SDP mode in the temp RTP Params to ACTIVE. This will be 
	 * 	    used when the NA invokes GetMediaParams API. 
	 * 6) Invoke pfnRemoteCallHold function on the CL and when it returns check
	 *    its status. 
	 *    	6a) If its SUCCESS, Change the state of the leg to CONV and the 
	 *    	the other CL to whatever it was before RRP. Also:
	 *    			1) If the CL on which the CallHold was
	 *    		 	invoked is a CL owned by NA then invoke ModifyMedia &
	 *    		 	RtpSessionModify using the values in the temp variables. Copy
	 *    		 	the same into the the accpeted codecs and rtp params in the CL.
	 *    		 	2) If its owned by a non-NA agent then invoke 
	 *    		 	only ModifyMedia to join the path. 
	 *    	6b) If the status is FAILURE then change state back to what they were
	 *    	    before RRP and SRP. Return the API with status FAILURE.
	 *			6c) If the status was PENDING, then do not change states and return
	 *			    API with PENDING.
	 * */
}

 
/*****************************************************************************
 *  Function Name   : IFX_CMGR_ActOnAtxIntVoipVoipSuccess
 *  Description     : Function does action on sucess completion of 
 *  						Internal-Voip-Voip type attended transfer.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ActOnAtxIntVoipVoipSuccess
						(
					 		IN x_IFX_CMGR_CallLeg* pxLeg,
					 		IN x_IFX_CMGR_CallLeg* pxPeer,
					 		IN x_IFX_CMGR_CallLeg* pxAtxLeg,
					 		IN x_IFX_CMGR_CallLeg* pxAtxPeer,
					 		IN e_IFX_TransferStatus eTxStatus
						)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxAtxCnxt = pxAtxLeg->pxCurrCnxt;
	x_IFX_CMGR_CallContext* pxCnxt = pxAtxCnxt->pxPeerAtxCnxt;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	
	if(IFX_TRUE != pxLeg->bByeRcvd)
	{
		/*Inform peer party about transfer success*/
		IFX_CMGR_InvokeAtxStatus(pxLeg, eTxStatus, IFX_TRANSFER_SUCCESS);
		IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TERMINATED, NULL);
	}
	if(IFX_TRUE != pxPeer->bByeRcvd)
		IFX_CMGR_InvokeRemoteCallRelease(pxPeer,IFX_TERMINATED, NULL);
	if(IFX_TRUE != pxAtxLeg->bByeRcvd)
		IFX_CMGR_InvokeRemoteCallRelease(pxAtxLeg,IFX_TERMINATED, NULL);
	if(IFX_TRUE != pxAtxPeer->bByeRcvd)
		IFX_CMGR_InvokeRemoteCallRelease(pxAtxPeer,IFX_TERMINATED, NULL);
	
	IFX_CMGR_StopMediaSession(pxPeer);
	IFX_CMGR_StopMediaSession(pxAtxPeer);
	
	IFX_CMGR_DeAllocCallCnxt(pxCnxt->pxPeerAtxCnxt);
	IFX_CMGR_DeAllocCallCnxt(pxCnxt);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ActOnAtxIntVoipVoipFailure
 *  Description     : Function does action on failure of 
 *  						Internal-Voip-Voip type attended transfer.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ActOnAtxIntVoipVoipFailure
						(
					 		IN x_IFX_CMGR_CallLeg* pxLeg,
					 		IN x_IFX_CMGR_CallLeg* pxPeer,
					 		IN x_IFX_CMGR_CallLeg* pxAtxLeg,
					 		IN x_IFX_CMGR_CallLeg* pxAtxPeer,
					 		IN e_IFX_TransferStatus eTxStatus
						)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxAtxCnxt = pxAtxLeg->pxCurrCnxt;
	x_IFX_CMGR_CallContext* pxCnxt = pxAtxCnxt->pxPeerAtxCnxt;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/*Release all Call legs*/
	if((IFX_TRUE == pxLeg->bByeRcvd) && (IFX_TRUE == pxAtxLeg->bByeRcvd))
	{
		IFX_CMGR_InvokeRemoteCallRelease(pxPeer,IFX_TERMINATED, NULL);
		IFX_CMGR_InvokeRemoteCallRelease(pxAtxPeer,IFX_TERMINATED, NULL);
		IFX_CMGR_DeAllocCallCnxt(pxCnxt->pxPeerAtxCnxt);
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	else
	{
		/*Inform peer party about transfer failure*/
		IFX_CMGR_InvokeAtxStatus(pxLeg, eTxStatus, IFX_TRANSFER_FAIL);
		/* Change state of all calls to previous ones*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
		IFX_CMGR_ChangeState(pxAtxLeg, pxAtxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxAtxPeer, pxAtxPeer->ePrevState,0);
		if(pxPeer->bByeRcvd != IFX_TRUE){
	     IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "Invoking CallRel on Peer party");

		IFX_CMGR_InvokeRemoteCallRelease(pxPeer,IFX_TERMINATED, NULL);
		}
		if(pxAtxPeer->bByeRcvd != IFX_TRUE){
	     IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "Invoking CallRel on ATX Peer");
		IFX_CMGR_InvokeRemoteCallRelease(pxAtxPeer,IFX_TERMINATED, NULL);
		}
		IFX_CMGR_DeAllocCallCnxt(pxCnxt->pxPeerAtxCnxt);
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleAtxIntVoipVoip
 *  Description     : Function handles Int-Voip-Voip type Atx once the second
 *  						 call is held
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleAtxIntVoipVoip(
					 IN x_IFX_CMGR_CallLeg* pxAtxLeg,
					 IN e_IFX_TransferStatus* peStatus,
					 IN e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxAtxCnxt = pxAtxLeg->pxCurrCnxt;
	x_IFX_CMGR_CallContext* pxCnxt = pxAtxCnxt->pxPeerAtxCnxt;
	x_IFX_CMGR_CallLeg* pxLeg = NULL;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
	x_IFX_CMGR_AddressInfo xAddr;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	IFX_CMGR_FindSameOwnerLeg(pxCnxt, pxAtxLeg->xLegOwnerInfo.szEndptId,&pxLeg);
	if(!pxLeg)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	pxPeer = pxLeg->pxPeer;
	
	/*Change state to Call_LEG_TX*/
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	
	/*Change state of the pxAtxLeg and pxAtxPeer to Disrupt wait*/
	IFX_CMGR_ChangeState(pxAtxLeg, IFX_CMGR_STATE_DISRUPT_WAIT, 0);
	IFX_CMGR_ChangeState(pxAtxLeg->pxPeer, IFX_CMGR_STATE_DISRUPT_WAIT, 0);
	
	/* Prepare the refer to address info*/
	memset(&xAddr, 0, sizeof(x_IFX_CMGR_AddressInfo));
	xAddr.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xAddr.uxAddressInfo.xVoipAddr,
		&pxAtxLeg->pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr, 
		sizeof(x_IFX_CMGR_VoipAddr));

	/*Invoke pfnAttendedTxReq on pxPeer*/
	eRet=IFX_CMGR_InvokeAtxReq(pxPeer,pxAtxLeg->pxPeer,&xAddr,peStatus,peReason);
	if((IFX_CMGR_TRANSFER_REJECTED == *peStatus)||
		(IFX_CMGR_TRANSFER_FAILED == *peStatus))
	{
		IFX_CMGR_ActOnAtxIntVoipVoipFailure(pxLeg,pxPeer,
							 			pxAtxLeg,pxAtxLeg->pxPeer,*peStatus);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*!
	\brief	Will be invoked by an agent when it wants to respond to a call hold
				Req
	\param[in]	 uiCallId is the identifier of the call
	\param[in,out]	 peStatus is the status of the Req as given by the remote agent
	\param[in,out]	 peReason - incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallHoldRsp(
									IN uint32 uiCallId,
									IN_OUT e_IFX_CMGR_Status* peStatus,
									IN_OUT e_IFX_ReasonCode* peReason /*If Failure*/
									)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_VoipLegInfo* pxInfo; 
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	
	/*Check State of the LEG*/
	if(!((pxLeg->eCurrState == IFX_CMGR_RECV_RESP_PENDING) && 
			(pxLeg->eRespPendEvt == IFX_CMGR_RESP_PEND_HOLD )))
			  /*Add for other stuff later*/
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/*Check if its a failure - Change state to previous state for both the CLs*/
	if(*peStatus == IFX_CMGR_STATUS_FAIL)	
	{
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);

		if(pxLeg->xLegOwnerInfo.eOwnerType == IFX_CMGR_TYPE_VOIP)
		{
			pxInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			memset(&pxInfo->xTempCodecInfo,0, sizeof(x_IFX_CMGR_CodecParams));
			memset(&pxInfo->xTempRtpParams,0, sizeof(x_IFX_CMGR_RtpParams));
			
		}
		if(pxPeer->xLegOwnerInfo.eOwnerType == IFX_CMGR_TYPE_VOIP)
		{
			pxInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			memset(&pxInfo->xTempCodecInfo,0, sizeof(x_IFX_CMGR_CodecParams));
			memset(&pxInfo->xTempRtpParams,0, sizeof(x_IFX_CMGR_RtpParams));
		}
		/*Check for conference case*/
		if(pxPeer->uiConfReqId)
		{
			x_IFX_CMGR_ReqContext* pxReqCnxt =  
				IFX_CMGR_GetReqCnxtPtr(pxPeer->uiConfReqId);
			if (pxReqCnxt == NULL)
				return IFX_FAILURE;
			IFX_CMGR_InvokeConfStatus(pxPeer, *peStatus, *peReason);
			IFX_CMGR_ClearCallLegsConfInfo(pxReqCnxt);
			IFX_CMGR_DeAllocReqCnxt(pxReqCnxt);
			pxPeer->uiConfReqId = 0; 
			return eRet;
		}
		
		/*Inform the peer party about the status*/
		if(!IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_HOLD_FOR_ATX))
			eRet = IFX_CMGR_InvokeCallHoldRsp(pxPeer, *peStatus, *peReason);	
		else /* Attended TX Case*/
		{	x_IFX_CMGR_CallLeg* pxAtxLeg = NULL;
			e_IFX_TransferStatus eTxStatus = IFX_CMGR_TRANSFER_FAILED;
			eRet = IFX_CMGR_InvokeCallHoldRsp(pxPeer, *peStatus, *peReason);	
			IFX_CMGR_FindSameOwnerLeg(pxCnxt->pxPeerAtxCnxt,
						pxPeer->xLegOwnerInfo.szEndptId, &pxAtxLeg);
			if (pxAtxLeg)
				IFX_CMGR_ActOnAtxIntVoipVoipFailure(pxAtxLeg,pxAtxLeg->pxPeer,
								 						pxLeg,pxPeer, eTxStatus);
		}
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
	}
	else
	if(*peStatus == IFX_CMGR_STATUS_SUCCESS)	
	{
		if( IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType)
		{
			/* Its a internal party*/
			if (IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
			{
				/*Its an INT to VOIP HOLD Rsp*/
				eRet = IFX_CMGR_HoldCallSucIntVoip(pxLeg, peStatus, peReason);
			}
			else
			{
				/* Its an Internal to Internal Hold Rsp*/
				eRet = IFX_CMGR_HoldCallSucIntInt(pxLeg, peStatus, peReason);
			}
		}
		else
		{
			/*Its a Voip Party  - so its a Voip -> Internal Hold Rsp*/
			eRet = IFX_CMGR_HoldCallSucVoipInt(pxLeg, peStatus, peReason);
		}
		
		/*Change State*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_HELD, 0);

		/*Check for Conference Related Info*/
		if(pxPeer->uiConfReqId)
		{
			x_IFX_CMGR_ReqContext* pxReqCnxt =  
				IFX_CMGR_GetReqCnxtPtr(pxPeer->uiConfReqId);
			if (pxReqCnxt == NULL)
				return IFX_FAILURE;
			--pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls;
			if(IFX_CMGR_CheckAndDisableConf(pxReqCnxt) == IFX_TRUE)
			{
				/*Invoke pfnConfStatus with Success*/
				eRet = IFX_CMGR_InvokeConfStatus(pxPeer, *peStatus, *peReason);
				/* For fixing bug for Philips Release Number 19*/
				IFX_CMGR_ClearCallLegsConfInfo(pxReqCnxt);
				IFX_CMGR_DeAllocReqCnxt(pxReqCnxt);
				pxPeer->uiConfReqId = 0; 
			}
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		
		/*Invoke Call Hold Rsp on the Peer CL*/
		if(!IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_HOLD_FOR_ATX))
			eRet = IFX_CMGR_InvokeCallHoldRsp(pxPeer, *peStatus, *peReason);
		else
		{
			e_IFX_TransferStatus eStatus = 0;
			/*Start Atx Procedure*/
			eRet = IFX_CMGR_HandleAtxIntVoipVoip(pxLeg->pxPeer, &eStatus,peReason);
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
/*
 * Call Hold Rsp API is used to respond to an pfnRemoteCallHold Req
 * issed by the CMGR on an agent. 
 *
 * A) The following steps are to be done if the status is returned as SUCCESS.
 * 1) If the state is not RRP(Hold)/ RRP(Hold for Conf Break) or RRP (Hold for 
 *    Atx) then reject the API.
 * 2) If the CL is a NA CL then invoke pfnGetMediaParams on it to find out the
 * 	Codecs/Rtp (mode etc) agreed upon. Save the mode in the temp SDP mode 
 * 	into the accepted RTP params.
 * 3) Invoke pfnCallHoldRsp on the peer CL.   
 * 4) Invoke MediaManager to break the connection and also the RTP agent if some
 * 	RTP parameter changes. Use values if any in the temp codecs/rtp if the any 
 * 	CL is a NA CL. Copy Values into the accepted rtp/codecs list.
 * 5) Change state of the peer CL to HELD and the CL's state to previous state.
 * 
 * B) If the status was returned as FAILURE then,
 * 1) Change the state of the CL back to previous state.
 * 2) Change the state of the peer CL to the previous state.
 * 3) Clear all the contents that were maintained for offer answer in the
 *    any CL (initiator or peer) was a NA leg.
 * 
*/
}

/*!
	\brief	Will be invoked by an agent when it wants to respond to a call resume
				Req
	\param[in]	 uiCallId is the identifier of the call
	\param[in,out]	 peStatus is the status of the Req as given by the remote agent
	\param[in,out]	 peReason - incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallResumeRsp
							(
							IN uint32 uiCallId,
							IN_OUT e_IFX_CMGR_Status* peStatus,
							IN_OUT e_IFX_ReasonCode* peReason /*If Failure*/
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_VoipLegInfo* pxInfo; 
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "ENTRY");
	if(!pxLeg || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	
	/*Check State of the LEG*/
	if(!((pxLeg->eCurrState == IFX_CMGR_RECV_RESP_PENDING) && 
			(pxLeg->eRespPendEvt == IFX_CMGR_RESP_PEND_RESUME )))
			  /*Add for other stuff later*/
	{
		/* API invoked in Invalid state - Reject API with status FAIL*/
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Check if its a failure - Change state to previous state for both the CLs*/
	if(*peStatus == IFX_CMGR_STATUS_FAIL)	
	{
		if(pxLeg->xLegOwnerInfo.eOwnerType == IFX_CMGR_TYPE_VOIP)
		{
			pxInfo = &pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			memset(&pxInfo->xTempCodecInfo,0, sizeof(x_IFX_CMGR_CodecParams));
			memset(&pxInfo->xTempRtpParams,0, sizeof(x_IFX_CMGR_RtpParams));
			
		}
		if(pxPeer->xLegOwnerInfo.eOwnerType == IFX_CMGR_TYPE_VOIP)
		{
			pxInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			memset(&pxInfo->xTempCodecInfo,0, sizeof(x_IFX_CMGR_CodecParams));
			memset(&pxInfo->xTempRtpParams,0, sizeof(x_IFX_CMGR_RtpParams));
		}
		/*Change states to the previous values*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer,pxPeer->ePrevState, 0);
		
		/*Check for conference case*/
		if(pxPeer->uiConfReqId)
		{
			x_IFX_CMGR_ReqContext* pxReqCnxt =  
				IFX_CMGR_GetReqCnxtPtr(pxPeer->uiConfReqId);
			if (pxReqCnxt == NULL)
				return IFX_FAILURE;
			IFX_CMGR_InvokeConfStatus(pxPeer, *peStatus, *peReason);
			IFX_CMGR_ClearCallLegsConfInfo(pxReqCnxt);
			IFX_CMGR_DeAllocReqCnxt(pxReqCnxt);
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		/*Inform the peer party about the status*/
		eRet = IFX_CMGR_InvokeCallResumeRsp(pxPeer, *peStatus, *peReason);	
	}
	else
	if(*peStatus == IFX_CMGR_STATUS_SUCCESS)	
	{
		if( IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType)
		{
			/* Its a internal party*/
			if (IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
			{
				/*Its an INT to VOIP Resume Rsp*/
				eRet = IFX_CMGR_ResumeCallSucIntVoip(pxLeg, peStatus, peReason);
			}
			else
			{
				/* Its an Internal to Internal Resume Rsp*/
				eRet = IFX_CMGR_ResumeCallSucIntInt(pxLeg, peStatus, peReason);
			}
		}
		else
		{
			/*Its a Voip Party  - so its a Voip -> Internal Resume Rsp*/
			eRet = IFX_CMGR_ResumeCallSucVoipInt(pxLeg, peStatus, peReason);
		}
		
		/*Change State*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_CONV, 0);
		/* Check for the conference case also*/	
		if(pxPeer->uiConfReqId)
		{
			x_IFX_CMGR_ReqContext* pxReqCnxt =  
				IFX_CMGR_GetReqCnxtPtr(pxPeer->uiConfReqId);
			if (pxReqCnxt == NULL)
				return IFX_FAILURE;
			++pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls;
			if(IFX_CMGR_CheckAndEnableConf(pxReqCnxt) == IFX_TRUE)
			{
				/*Invoke pfnConfStatus with Success*/
				eRet = IFX_CMGR_InvokeConfStatus(pxPeer, *peStatus, *peReason);
			}
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		/*Invoke Call Hold Rsp on the Peer CL*/
		if(IFX_CMGR_BTX_INT_VOIP_INT != pxCnxt->eTypeOfTransfer)
		{
			if(!IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_RESUME_FOR_ATX))
				eRet = IFX_CMGR_InvokeCallResumeRsp(pxPeer, *peStatus, *peReason);
			else
				IFX_CMGR_RESET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_RESUME_FOR_ATX);
		}
		else
		{
			 pxCnxt->eTypeOfTransfer = 0;
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
/*
 * Call Resume Rsp API is used to respond to an pfnRemoteCallResume Req
 * issed by the CMGR on an agent. 
 *
 * A) The following steps are to be done if the status is returned as SUCCESS.
 * 1) If the state is not RRP(Resume)/ RRP(Resume for Conf)/ RRP (Resume for CC)
 * 	reject API. 
 * 2) If the CL is a NA CL then invoke pfnGetMediaParams on it to find out the
 * 	Codecs/Rtp (mode etc) agreed upon. Save the mode in the temp SDP mode & 
 * 	codecs into the accepted RTP params.
 * 3) Invoke pfnCallHoldRsp on the peer CL.   
 * 4) Invoke MediaManager to join the connection and also the RTP agent if some
 * 	RTP parameter changes. Use values if any in the temp codecs/rtp if any  
 * 	CL is a NA CL. Copy Values into the accepted rtp/codecs list.
 * 5) Change state of the peer CL to CONV and the CL's state to previous state.
 * 
 * B) If the status was returned as FAILURE then,
 * 1) Change the state of the CL back to previous state.
 * 2) Change the state of the peer CL to the previous state.
 * 3) Clear all the contents that were maintained for offer answer in the
 *    any CL (initiator or peer) was a NA leg.
 * C) If the CL on which the API was invoke was in state RRP (Resume For CC)
 * 	then change state to previous state & find the peer CL. This CL has 
 * 	to be in CALL_LEG_TX. Check that the Transfer Type is 
 * 	BTX_EXTN_VOIP_EXTN_CC and then invoke pfnBlindTxStatus (Answered) and 
 * 	pfnRemoteCallRelease (Tx_Done) on this CL. Change the state
 * 	of this CL to Idle and using the pxChild Pointer make the Child CL as the
 * 	peer CL of the CL on which the API was invoked. Invoke ModifyMedia on the
 * 	CallLeg and then join the media for the two CLs. DO NOT Free the resource 
 * 	Id for the initial Call. 
 * 	
*/
}


/*****************************************************************************
 *  Function Name   : IFX_CMGR_SendRelToInCls
 *  Description     : Function releases all incoming call CLs except for the
 *  						 pxDontRelLeg,in case of a forking scenario.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_SendRelToInCls(IN x_IFX_CMGR_CallLeg* pxOut, 
					 										IN x_IFX_CMGR_CallLeg* pxDontRelLeg)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = pxOut->pxCurrCnxt;
	e_IFX_ReasonCode eReason = 0;
	uint8 i;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/* Find all the CLs one by one*/
	for(i=IFX_CMGR_IN_CL_START_IDX;i<IFX_CMGR_MAX_LEGS_PER_CNXT;i++)
	{
		/*Check if the CL exists*/
		if(pxCnxt->pxCallLegs[i])
		{
			/*Release only if Reqed by the Caller*/
			if(pxDontRelLeg != (pxCnxt->pxCallLegs[i]))
			{
				/*Free the Call Leg'sn Resources taken from the MMGR*/
				IFX_CMGR_FreeMediaResource(pxCnxt->iResId, 
					pxOut->xLegOwnerInfo.szEndptId, 
					pxCnxt->pxCallLegs[i]->xLegOwnerInfo.szEndptId,
					&eReason);	
				/*This is pointing to a location in the CL array*/ 
				/*Invoke pfnRemoteCallRelease*/
				eRet = IFX_CMGR_InvokeRemoteCallRelease(
						pxCnxt->pxCallLegs[i], IFX_MAX_REASON, NULL);
				/* Free the Leg*/
				IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[i]);		
				--pxCnxt->ucNumCallLegs;
				pxCnxt->pxCallLegs[i] = NULL;
				//IFX_CMGR_NullCallLegPtr(pxCnxt,pxCnxt->pxCallLegs[i]);
			}
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ReleaseCallInForking
 *  Description     : Function handles Call Release in a forking scenario.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ReleaseCallInForking(
					 			IN  x_IFX_CMGR_CallLeg* pxLeg,
                IN  e_IFX_ReasonCode eReleaseReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	x_IFX_CMGR_CallLeg* pxOut = IFX_CMGR_GetOutCl(pxCnxt);
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_AddressInfo xAddrInfo;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	memset(&xAddrInfo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xAddrInfo.eAddressType = pxLeg->xLegOwnerInfo.eOwnerType;	
	/* 
	 * Check for the agent which invoked call release. If release
	 * was invoked on the OUT CL, then release all the calls in the IN CL 
	 * one by one.  
	 */
	if( IFX_CMGR_OUT == pxLeg->eDirection)
	{
		/*Add to Missed Call Register*/
		if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)	
		{
			memcpy(&xAddrInfo.uxAddressInfo.xVoipAddr, 
				&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr,
				sizeof(x_IFX_CMGR_VoipAddr));
			IFX_LMGR_AddToMissedCallReg(
				pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId, &xAddrInfo);
		}else
		if(IFX_CMGR_TYPE_FXO == pxLeg->xLegOwnerInfo.eOwnerType)	
		{
			memcpy(&xAddrInfo.uxAddressInfo.xFxoInfo, 
				&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
				sizeof(x_IFX_CMGR_FxoInfo));
			IFX_LMGR_AddToMissedCallReg(IFX_PSTN_LINE, &xAddrInfo);
		}
		/* Release invoked on the OUT CL*/
		eRet = IFX_CMGR_SendRelToInCls(pxLeg, NULL);
		/* Set iResId to NULL*/
		pxCnxt->iResId = 0;
		/* Clear the Context*/
		eRet = IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	/* Else if release was invoked on one of the IN CLs then check if any other
	 * CL is alive using the Number of CLs. If any other Leg is alive just free 
	 * this leg. Else Free Context after invoking pfnRemoteCallRelease on the 
	 * peer agent. Invoke No answer Call Forward if set on the VL.
	 */
	else /*Its an IN CL*/
	{	
			x_IFX_CMGR_VoipAddr xAddr; 
			x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = 
					  &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			boolean bFwdEnabled = IFX_FALSE;
	    if( (IFX_ABNORMAL_RELEASE == eReleaseReason) && 
				  (IFX_TRUE == IFX_CMGR_IsAnyInClAlive(pxCnxt, pxLeg)) ){
					IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Abnormal Release");
					IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
          pxOut->xLegOwnerInfo.szEndptId,
          pxLeg->xLegOwnerInfo.szEndptId, &eReason);
      /* free the CL*/
      IFX_CMGR_DeAllocCallLeg(pxLeg);
      /* Reduce the number of calls legs*/
      --pxCnxt->ucNumCallLegs;
      IFX_CMGR_NullCallLegPtr(pxCnxt,pxLeg);

		}
		else { /*Relase all Call Legs as i/c call is Rejected*/
			if (IFX_CMGR_TYPE_VOIP == pxOut->xLegOwnerInfo.eOwnerType)	
			{	
				/* Add to  Rcvd Call Register*/
				memcpy(&xAddrInfo.uxAddressInfo.xVoipAddr, 
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr,
						sizeof(x_IFX_CMGR_VoipAddr));
				xAddrInfo.eAddressType = IFX_CMGR_TYPE_VOIP;
				IFX_LMGR_AddToRcvdCallReg(
					pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.ucLineId,&xAddrInfo);
				/*Find if there is any NO ANS/BUSY fwd is to be done?*/
        if((IFX_CMGR_STATE_RINGING == pxLeg->eCurrState)&&(eReleaseReason==IFX_TIMEOUT))
        { /* If state is ringing then apply no-answer call Fwd*/
          eRet = IFX_LMGR_GetCallFwdAddr(pxVoipLegInfo->ucLineId,
                 IFX_CALL_FWD_ON_NO_ANSWER, &bFwdEnabled, NULL, &xAddr,&eReason);
        }
        else{
				  eRet = IFX_LMGR_GetCallFwdAddr(pxVoipLegInfo->ucLineId, 
					       IFX_CALL_FWD_BUSY, &bFwdEnabled,NULL,&xAddr,&eReason);
        }
				/* Check if Call Fwd is allowed?*/
				if((IFX_TRUE == bFwdEnabled) && (IFX_TRUE == 
							IFX_CMGR_CanCallBeFwd(pxVoipLegInfo, &xAddr)))
					eReason = IFX_CALL_FORWARD;
				else
					eReason = IFX_ENDPOINT_BUSY;
				IFX_CMGR_InvokeRemoteCallRelease(pxOut, eReason,&xAddr);
			}
			else
			{
				/*Its an FXO forked call*/
				/* Add to missed Call Register*/
				memcpy(&xAddrInfo.uxAddressInfo.xFxoInfo, 
					&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
						sizeof(x_IFX_CMGR_FxoInfo));
				xAddrInfo.eAddressType = IFX_CMGR_TYPE_FXO;
				IFX_LMGR_AddToRcvdCallReg(IFX_PSTN_LINE, &xAddrInfo);
				/*Release call on the FXO OUT CL*/
				IFX_CMGR_InvokeRemoteCallRelease(pxOut, IFX_MAX_REASON, NULL);
			}	
			/* Release invoked on the In CL*/
			eRet = IFX_CMGR_SendRelToInCls(pxOut,pxLeg);
			/* Free Resources for this CL*/
			IFX_CMGR_FreeMediaResource(pxCnxt->iResId, 
						pxOut->xLegOwnerInfo.szEndptId, 
						pxLeg->xLegOwnerInfo.szEndptId, &eReason);	
			/* free the CL*/
			IFX_CMGR_DeAllocCallLeg(pxLeg);
			IFX_CMGR_DeAllocCallLeg(pxOut);
			/* Clear the Context*/
			eRet = IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		}

	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ReleaseCallInConf
 *  Description     : Function handles Call Release in a Conference scenario.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ReleaseCallInConf(
					 IN uint32 uiCallId,
					 IN e_IFX_ReasonCode eReleaseReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer;
	uint8 i=0;
	uint8 j=0;
	const uchar8 ucMinCallsForConf = 2;
	x_IFX_CMGR_ReqContext* pxReqCnxt;
	x_IFX_CMGR_ConfInfo* pxConfInfo;
	x_IFX_CMGR_CallLeg* pxTemp ;
	//char8 cActiveCallIndex = -1;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Check if the Call on which the Release was invoked, its peer 
	 * has a ConfReqId. 
	 * Check if the conf is actually on. If so then call Disable Mixing. 
	 * decrement the active calls count & number of calls. If the Call Leg 
	 * to be released has index equal to the cActiveCallIndex then it means 
	 * that the active call has been released. Re-arrange the auiCallId array 
	 * in the ConfInfo struct. 
	 * Check if the number of active calls left == 2. If so then call enable
	 * mixing again using these 2 calls. Invoke Remote Call Release on the 
	 * released CL's peer leg.
	 * If the number of active calls is < 2 then Invoke Remote Call Release
	 * on the CL and the pfnConfStatus. Invoke ConfStatus on the ReqId.
	 * Goto to the call leg that is left and clear the uiConfReqId. Also clear 
	 * the ReqContex. 
	 * */
	if(!pxLeg)
		return IFX_FAILURE;	
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);

	if(pxPeer && (pxPeer->uiConfReqId || pxLeg->uiConfReqId))
	{
		pxTemp =pxPeer;
		if(pxPeer->uiConfReqId == 0 ) {
			pxTemp = pxLeg;
			
		}
		pxReqCnxt = IFX_CMGR_GetReqCnxtPtr(pxTemp->uiConfReqId);
		if (pxReqCnxt == NULL)
			return IFX_FAILURE;
		pxConfInfo = &pxReqCnxt->uxReqCnxt.xConfInfo;
		if(pxConfInfo != NULL && IFX_TRUE == pxConfInfo->bConfEnabled)
		{
			/*Invoke Disable Mixing*/
			eRet = IFX_CMGR_DisableMixing(pxReqCnxt);
			if(IFX_SUCCESS == eRet)
				pxConfInfo->bConfEnabled = IFX_FALSE;
			else
			{
				/*DEBUG*/
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error!!");
				goto err;
			}
		}
		
		/*Search the Call Id for the call being released*/
		if (pxConfInfo != NULL && pxConfInfo->ucNumCalls > IFX_MAX_CONF_PARTIES)
			return IFX_FAILURE;

		for(i=0;pxConfInfo != NULL && i<pxConfInfo->ucNumCalls;i++)
		{
			if(pxTemp->uiCallId == pxConfInfo->auiCallsInConf[i])
			{
				--pxConfInfo->ucCurrActiveCalls;
				--pxConfInfo->ucNumCalls;
				if(pxConfInfo->cActiveCallIndex == i){
						  //cActiveCallIndex = -1;
					}
				/*Clear the location and re-arrange list*/	
				for(j=i;j<pxConfInfo->ucNumCalls;j++)
				{
					pxConfInfo->auiCallsInConf[j] =  
							  pxConfInfo->auiCallsInConf[j+1];	
				}
				break;
			}
		}
			
		if(pxConfInfo != NULL && pxConfInfo->ucCurrActiveCalls >= ucMinCallsForConf)
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Re-Enabling Conf");
			/* Let the conference still go on - Invoke Enable Mixing*/
			IFX_CMGR_CheckAndEnableConf(pxReqCnxt);
			/* Invoke Remote Call Release*/
			IFX_CMGR_InvokeRemoteCallRelease(pxTemp, eReleaseReason, NULL);
		}
		else
		{
			/* Conference is no longer valid*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Conference Disabled");
			/* Invoke Remote Call Release on pxTemp*/
			IFX_CMGR_InvokeRemoteCallRelease(pxPeer, eReleaseReason, NULL);
			/* Invoke Conf Status*/
			if(pxPeer->uiConfReqId != 0 ){
				IFX_CMGR_InvokeConfStatus(pxPeer,IFX_CMGR_STATUS_SUCCESS,eReleaseReason);
			}
			/* Clear the ConfReqId for the Call that is left in the Conf*/
			for(i=0;pxConfInfo != NULL && i<pxConfInfo->ucNumCalls;i++)
			{
				if(pxConfInfo->auiCallsInConf[i])
				{
					x_IFX_CMGR_CallLeg* pxCall = 
						IFX_CMGR_GetCallLegPtr(pxConfInfo->auiCallsInConf[i]);
					if(pxCall)
						pxCall->uiConfReqId = 0;
				}
			}
			/* Clear the conference Req Cnxt*/
			IFX_CMGR_DeAllocReqCnxt(pxReqCnxt);
		}
		/*Call XDisconnect if both are internal parties*/
		if((IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType) &&
				(IFX_CMGR_TYPE_VOIP != pxPeer->xLegOwnerInfo.eOwnerType))
		{
				/*Call X-Disconnect*/	
			IFX_CMGR_XConnect(pxLeg->pxCurrCnxt->iResId, 
															IFX_FALSE, IFX_FALSE, &eReleaseReason);
		}
		/*Free the Call Context*/
		IFX_CMGR_DeAllocCallCnxt(pxLeg->pxCurrCnxt);
	}
err:
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ActOnChildFailureInTxCnxtCh
 *  Description     : Function handles failure in call transfer in a context
 *  						change transfer scenario
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ActOnChildFailureInTxCnxtCh
							(
								IN x_IFX_CMGR_CallLeg* pxChild,
								IN x_IFX_CMGR_CallLeg* pxParent,
								IN x_IFX_CMGR_CallLeg* pxPeer
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt =  IFX_CMGR_GetCurrCnxt(pxParent);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	pxCnxt->iResIdForTransfer = 0;
	/*Clear Call Leg*/
	IFX_CMGR_DeAllocCallLeg(pxChild);
	pxParent->pxChild = NULL;
	/* Clear the Type of transfer*/
	pxCnxt->eTypeOfTransfer = 0;
	/*Change State of pxParent and pxPeer to Previous state*/
	IFX_CMGR_ChangeState(pxParent, pxParent->ePrevState, 0);
	IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_ActOnChildFailureInTx
 *  Description     : Function handles failure in call transfer in a non-context
 *  						change transfer scenario
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ActOnChildFailureInTx
							(
								IN x_IFX_CMGR_CallLeg* pxChild,
								IN x_IFX_CMGR_CallLeg* pxParent,
								IN x_IFX_CMGR_CallLeg* pxPeer
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallContext* pxCnxt =  IFX_CMGR_GetCurrCnxt(pxParent);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Free Transfer Resource Id*/
	IFX_CMGR_FreeMediaResource(pxCnxt->iResIdForTransfer,
		pxPeer->xLegOwnerInfo.szEndptId, pxChild->xLegOwnerInfo.szEndptId,
		&eReason);	
	pxCnxt->iResIdForTransfer = 0;
	/*Clear Call Leg*/
	IFX_CMGR_DeAllocCallLeg(pxChild);
	pxParent->pxChild = NULL;
	/* Clear the Type of transfer*/
	pxCnxt->eTypeOfTransfer = 0;
	/*Change State of pxParent and pxPeer to Previous state*/
	IFX_CMGR_ChangeState(pxParent, pxParent->ePrevState, 0);
	IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
	/* If bye has already been received from the parent then clear
	 * the call.*/
	if(IFX_TRUE == pxParent->bByeRcvd)
	{
		IFX_CMGR_InvokeRemoteCallRelease(pxPeer, IFX_TERMINATED, NULL);
		if(IFX_CMGR_TYPE_VOIP == pxParent->xLegOwnerInfo.eOwnerType)
		{
			IFX_CMGR_StopMediaSession(pxParent);
		}else
		if(IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
		{
			IFX_CMGR_StopMediaSession(pxPeer);
		}
		IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleRelInStCallLegTx
 *  Description     : Function handles call release in the Call Leg Tx state
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleRelInStCallLegTx
							(
								IN x_IFX_CMGR_CallLeg* pxLeg,
								IN e_IFX_ReasonCode eReleaseReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = pxLeg->pxPeer;
	x_IFX_CMGR_CallContext* pxCnxt =  IFX_CMGR_GetCurrCnxt(pxLeg);
	if(!pxCnxt){
	     return IFX_FAILURE;
    }		 
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(IFX_CMGR_BTX_INT_VOIP_VOIP == pxCnxt->eTypeOfTransfer)	
	{
		if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)	
		{
			/* Release the peer call leg.*/
			IFX_CMGR_InvokeRemoteCallRelease(pxPeer, IFX_TERMINATED, NULL);
			/* Stop the Rtp Session*/
			IFX_CMGR_StopMediaSession(pxPeer);
			/* DeAlloc Call Context*/
			IFX_CMGR_DeAllocCallCnxt(pxCnxt);
		}
		else
		{
			/* Set flag to indicate that the BYE has been received.*/
			pxLeg->bByeRcvd = IFX_TRUE;			
		}
	}else
	if((IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)||	
		(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)||	
		(IFX_CMGR_BTX_INT_INT_INT == pxCnxt->eTypeOfTransfer)||	
		(IFX_CMGR_BTX_INT_INT_VOIP == pxCnxt->eTypeOfTransfer))	
	{
		/* Set flag to indicate that the BYE has been received.*/
		pxLeg->bByeRcvd = IFX_TRUE;	
		if(((IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer) ||
				(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer))&&
				(IFX_REL_NO_NOTIFY == eReleaseReason))
		{
			/*Set the Flag indicating that no further *********HACK************* 
														Notify are to be sent on this call*/
			IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY);
		}	
	}else
	if(IFX_CMGR_ATX_INT_VOIP_VOIP == pxCnxt->eTypeOfTransfer)	
	{
		pxLeg->bByeRcvd = IFX_TRUE;			
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet; 
}


/*****************************************************************************
 *  Function Name   : IFX_CMGR_HandleChildRelInTx
 *  Description     : Function handles release from a Child call leg in case
 *  						 of transfer
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_HandleChildRelInTx
							(
								IN x_IFX_CMGR_CallLeg* pxChild,
								IN x_IFX_CMGR_VoipAddr* pxFwdAddr,			
								IN e_IFX_ReasonCode eReleaseReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxParent = pxChild->pxParent;
	x_IFX_CMGR_CallLeg* pxPeer = pxParent->pxPeer;
	x_IFX_CMGR_CallLeg* pxFwdLeg = NULL;
	x_IFX_CMGR_CallContext* pxCnxt =  IFX_CMGR_GetCurrCnxt(pxParent);
	e_IFX_CMGR_Status eStatus = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if((IFX_CMGR_BTX_INT_INT_INT == pxCnxt->eTypeOfTransfer)||
		(IFX_CMGR_BTX_INT_INT_VOIP == pxCnxt->eTypeOfTransfer)||
		(IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer))
	{
		if(pxFwdAddr)
		{	/* Try and FWD the call*/
			eRet = IFX_CMGR_ForwardCall(pxChild, pxChild, 
						pxFwdAddr, eReleaseReason, &pxFwdLeg, &eStatus);
			if(IFX_CMGR_STATUS_FAIL == eStatus)
			{
				eRet = IFX_CMGR_InvokeBtxStatus(pxParent, 
									 IFX_CMGR_TRANSFER_FAILED, eReleaseReason); 
				IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
			}
			else
			{
				pxParent->pxChild = pxFwdLeg;	
			}
		}
		else
		{/* Invoke BTX Status on the parent*/
			eRet = IFX_CMGR_InvokeBtxStatus(pxParent, 
								 IFX_CMGR_TRANSFER_FAILED, eReleaseReason); 
			IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY);
			if((IFX_CMGR_BTX_INT_INT_VOIP == pxCnxt->eTypeOfTransfer)||
			(IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer))
			{	/*Flag was reset before sending INVITE. Since invite failed, set it.*/
				IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_MEDIA_CFG_DONE);
			}
		}
	}else
	if(IFX_CMGR_BTX_INT_VOIP_INT == pxCnxt->eTypeOfTransfer)
	{
		/* Invoke BTX Status on the parent*/
		eRet = IFX_CMGR_InvokeBtxStatus(pxParent, 
							 IFX_CMGR_TRANSFER_FAILED, eReleaseReason); 
		IFX_CMGR_ActOnChildFailureInTxCnxtCh(pxChild, pxParent, pxPeer);
	}else
	if(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)
	{
		if(pxFwdAddr)
		{	/* Try and FWD the call*/
			eRet = IFX_CMGR_ForwardCall(pxChild, pxChild, 
						pxFwdAddr, eReleaseReason, &pxFwdLeg, &eStatus);
			if(IFX_CMGR_STATUS_FAIL == eStatus)
			{
				eRet = IFX_CMGR_InvokeAtxStatus(pxParent, 
									 IFX_CMGR_TRANSFER_FAILED, eReleaseReason); 
				IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
			}
			else
			{
				pxParent->pxChild = pxFwdLeg;	
			}
		}
		else
		{/* Invoke ATX Status on the parent*/
			eRet = IFX_CMGR_InvokeAtxStatus(pxParent, 
								 IFX_CMGR_TRANSFER_FAILED, eReleaseReason); 
			IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_DONT_SEND_NTFY);
			/*Flag was reset before sending INVITE. Since invite failed, set it.*/
			IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_MEDIA_CFG_DONE);
		}
	}else
	{
		eRet = IFX_FAILURE; /* DEBUG */
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsTxWithChild
 *  Description     : Function determines if the transfer scenario involves a
 *  						 child call-leg.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsTxWithChild(
					 IN e_IFX_CMGR_TypeOfTransfer eTypeOfTransfer)
{
	boolean bRet = IFX_FALSE;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if((IFX_CMGR_BTX_INT_INT_INT == eTypeOfTransfer)||
		(IFX_CMGR_BTX_INT_INT_VOIP == eTypeOfTransfer)||
		(IFX_CMGR_BTX_VOIP_INT_VOIP == eTypeOfTransfer)||
		(IFX_CMGR_ATX_VOIP_INT_VOIP == eTypeOfTransfer)||
		(IFX_CMGR_BTX_INT_VOIP_INT == eTypeOfTransfer)
		)
	{
		bRet = IFX_TRUE;
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Exit");
	return bRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindPeerPtr
 *  Description     : Function finds the peer pointer from a call leg
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : x_IFX_CMGR_CallLeg pointer 
 *  Notes           :
 ****************************************************************************/
STATIC x_IFX_CMGR_CallLeg* IFX_CMGR_FindPeerPtr(
					 IN x_IFX_CMGR_CallLeg*  pxLeg 
					 )
{
	x_IFX_CMGR_CallContext* pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxPeer = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(pxLeg)
	{
		uint8 i=0;
		if(pxLeg->pxPeer)
		{
			/* If there is already a peer*/
			pxPeer = pxLeg->pxPeer;
			return pxPeer;
		}
		pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
		if(!pxCnxt)
		{
			/* To protect against re-release*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "The call has been already released - ERROR!!!");
			return NULL;
		}
		for(i=0; i< IFX_CMGR_MAX_LEGS_PER_CNXT; i++)
		{
			if(pxCnxt->pxCallLegs[i])
			{
				if(pxLeg == pxCnxt->pxCallLegs[i])
						  continue;
				else
				{
					/* Peer Found*/
					pxPeer = pxCnxt->pxCallLegs[i];
					break;
				}
			}
		}
	}
	return pxPeer;
}

/*!
	\brief	Will be invoked by an agent when it wants 
				release an ongoing call or to reject an incoming call. 
	\param[in]	 uiCallId is the identifier of the call
	\param[in]	 eReleaseReason  provides the reason for call release, if any. 
	\param[in]	 pxFwdAddr the address to contact in case of incoming VoIP call 
					 rejection. Used only by the NA to inform a 301/302 received.
	\param[out]	peStatus is the status of the Req
	\param[out]	peStatusReason - incase of failure, this parameter provides the 
					specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallRelease(
							IN uint32 uiCallId,
							IN e_IFX_ReasonCode eReleaseReason,
							IN x_IFX_CMGR_VoipAddr* pxFwdAddr,			
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peStatusReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt=NULL;
	x_IFX_CMGR_CallContext* pxNewCnxt=NULL;
	x_IFX_CMGR_CallLeg* pxLeg=NULL;
	x_IFX_CMGR_CallLeg* pxPeer=NULL;
	x_IFX_CMGR_VoipAddr xFwdAddr; /* needed for sending a 302*/
	
	/*Check if the Context is in -
	 * 1) ATX
	 * 2) BTX
	 * 3) Forking - Check for the agent which invoked call release. If release
	 * 				 was invoked on the OUT CL, then release all the calls in the
	 * 				 IN CL one by one. 
	 * 				 Else if release was invoked on one of the IN CLs then check
	 * 				 if any other CL is alive using the Number of CLs. If any other
	 * 				 Leg is alive just fre this leg. Else Free Context after invoking
	 * 				 pfnRemoteCallRelease on the peer agent. 
	 *
	 * 4) Forwarding - Ifthe call was forwarded (only in case of Internal-Voip call)
	 * 	invoke IFX_CMGR_ForwardCall.
	 * 5) Conference - 
	 *
	 * If any of these special conditions are not present then invoke normal 
	 * Release procedure. Check the call type and see if its a Voip Call. 
	 * Invoke RtpSessionStop or FaxSessionStop as the case may be and then invoke
	 * pfnRemoteCallRelease on the peer agent
	 * */
	pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCallId);
	pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(!pxLeg || !pxCnxt)
	{
		eRet = IFX_FAILURE;
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peStatusReason = IFX_MAX_REASON;
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	if(pxLeg && !pxLeg->pxCurrCnxt)
	{
		/*This means that the leg has been released*/
		eRet = IFX_FAILURE;
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peStatusReason = IFX_MAX_REASON;
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/* Check for release in Transfer cases where there is a child
	 * This Function handles call release from the child*/
	if((pxLeg->pxParent) &&
		(IFX_TRUE == IFX_CMGR_IsTxWithChild(pxCnxt->eTypeOfTransfer)))
	{
			eRet = IFX_CMGR_HandleChildRelInTx(pxLeg, pxFwdAddr,eReleaseReason);
			IFX_CMGR_PrintCallIdList(__FUNCTION__);
			return eRet;
	}
	/*Check if release is from the a party in a Transfer scenario*/
	if(IFX_CMGR_STATE_CALL_LEG_TX == pxLeg->eCurrState)
	{
		eRet = IFX_CMGR_HandleRelInStCallLegTx(pxLeg, eReleaseReason);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return eRet;
	}		 
	/* Bye received in the Disrupt wait state Only used in case of
	 * ATX Int-Voip-Voip*/
	if(IFX_CMGR_STATE_DISRUPT_WAIT == pxLeg->eCurrState)
	{
		if(IFX_CMGR_ATX_INT_VOIP_VOIP == pxCnxt->eTypeOfTransfer)
		{
			/* Set a flag indicating that the release has been received*/
			pxLeg->bByeRcvd = IFX_TRUE;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			IFX_CMGR_PrintCallIdList(__FUNCTION__);
			return eRet;
		}
	}
			  
	/* If the release is from the A side in INT-VOIP-VOIP ATX*/
	if((IFX_CMGR_SEND_RESP_PENDING == pxLeg->eCurrState) && 
		(IFX_CMGR_RESP_PEND_ATX == pxLeg->eRespPendEvt))
	{
		if(IFX_CMGR_ATX_INT_VOIP_VOIP == pxCnxt->eTypeOfTransfer)
		{
			/* Set a flag indicating that the release has been received*/
			pxLeg->bByeRcvd = IFX_TRUE;
			IFX_CMGR_PrintCallIdList(__FUNCTION__);
			return eRet;
		}
	}
	
	/* If the Call Release is received with flag IFX_CMGR_FLAG_CALL_HOLD_FOR_ATX
	 * set, then its a release on the pxAtxLeg*/
	if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_HOLD_FOR_ATX))
	{
		/* Just set the flag to indicate that local release has been received*/
		pxLeg->bByeRcvd = IFX_TRUE;
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return eRet;
	}

  /* Call Reinjection */
  if(pxCnxt->pxPeerAtxCnxt && (pxCnxt->pxPeerAtxCnxt->ucNumCallLegs == IFX_CMGR_MIN_LEGS_PER_CNXT)){
    /* Save the pxPeerAtxCnxt before invoking RemoteCallRelease/InvokeRemoteCallRelease */
    pxNewCnxt = pxCnxt->pxPeerAtxCnxt;
  }

	/* Check for forking*/	 
	if(pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT)
	{
    /* Case during reinjection where one of the alerting HS rejects the call. Invoke IFX_CMGR_ReleaseCallInForking
       to send a release to each of the other IN legs as well as to the OUT leg*/
		eRet = IFX_CMGR_ReleaseCallInForking(pxLeg,eReleaseReason);
    if((!pxNewCnxt)||(IFX_ABNORMAL_RELEASE == eReleaseReason)){
		  IFX_CMGR_PrintCallIdList(__FUNCTION__);
		  return eRet;
     }
	}
  else{ /* Call Reinjection */
   if(pxCnxt->pxPeerAtxCnxt){
	   eRet = IFX_CMGR_InvokeRemoteCallRelease(pxPeer, eReleaseReason, &xFwdAddr);
	   IFX_CMGR_DeAllocCallCnxt(pxCnxt);
   }
  }

  if(pxNewCnxt){
    /* Proceed with releasing both the legs in pxPeerAtxCnxt i.e. both the legs of the held call */
    pxLeg = pxNewCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX];
    pxFwdAddr = NULL;
    pxCnxt = pxNewCnxt; 
		pxPeer = NULL;
  }

	/* Find the Peer*/
	if(!pxPeer)
		pxPeer = IFX_CMGR_FindPeerPtr(pxLeg);
	if(!pxPeer)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "NO PEER FOUND - Returning Failure");
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return IFX_FAILURE;
	}
	
	/*Check for Call Forwarding*/
	if(pxFwdAddr)
	{
		x_IFX_CMGR_CallLeg* pxFwdLeg = NULL;
		eRet = IFX_CMGR_ForwardCall(pxLeg, pxPeer, pxFwdAddr, 
								 				eReleaseReason, &pxFwdLeg, peStatus);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/*Check for a conference scenario*/
	
	if((pxLeg->pxPeer) && (pxLeg->pxPeer->uiConfReqId || pxLeg->uiConfReqId) )
	{
		eRet = IFX_CMGR_ReleaseCallInConf(uiCallId, eReleaseReason);
		IFX_CMGR_PrintCallIdList(__FUNCTION__);
		return eRet;
	}
	/* Check for a Child on the peer - this means that the new call 
	 * that was supposed to be made is now to be released as well*/
	if(pxPeer->pxChild)
	{	/* TO DO - Include Code for CONTEXT CHANGE peer on-hook*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      									                       "Release on B side");
		if(IFX_TRUE == IFX_CMGR_IsTxWithChild(pxCnxt->eTypeOfTransfer))
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      									                       "Child Found");
#ifndef BTX_FIX
			/*Terminate subscription with parent (REFER sender)*/
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      			   "Checkinf for BTX pending");
			if(IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer){
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      			   "Terminating Subn with Parent");
			IFX_CMGR_InvokeBtxStatus(pxPeer,IFX_CMGR_TRANSFER_FAILED,
															 IFX_500_RESP);

			}
#endif
			/* Free the resource ID for the CHILD*/		
			eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResIdForTransfer,
				pxPeer->xLegOwnerInfo.szEndptId, 
				pxPeer->pxChild->xLegOwnerInfo.szEndptId, peStatusReason);
			/* Clear Certain things*/
			pxCnxt->iResIdForTransfer = 0;
			/* Send Release to the CHILD - Clear its resources & information*/
			eRet = IFX_CMGR_InvokeRemoteCallRelease(pxPeer->pxChild, 
								 								IFX_TERMINATED, NULL);
			/*Clear Call Leg*/
			IFX_CMGR_DeAllocCallLeg(pxPeer->pxChild);
		}
	}

	/****************Else Its a Normal Call release procedure***********/	
	/*Release came from the Voip Party*/
	if(IFX_CMGR_TYPE_VOIP == pxLeg->xLegOwnerInfo.eOwnerType)
	{
		/* Stop the RTP Session*/
		IFX_CMGR_StopMediaSession(pxLeg);
		/*Check if the Release was before the Call was answered - 
			Add to Missed Call Register in that case*/
		if(IFX_CMGR_STATE_RINGING == pxPeer->eCurrState) // For BUG #8 in DECT_Oct07 pre-rel
		{
			IFX_CMGR_AddVoipAddrToMissedCallReg(pxLeg, 
				&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr);
		}
	}else
	/*Release came from the non-Voip Party in a Voip call*/
	if(IFX_CMGR_TYPE_VOIP == pxPeer->xLegOwnerInfo.eOwnerType)
	{
#ifdef FAX_SUPPORT
			/* Check if a FAX call was on*/
			if(IFX_CMGR_GET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
			{
				/* Set flag to indicate that the FAX session ended due to an FXS
				 on-hook event*/
				IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_FAX_FXS_ON_HK);
			}
#endif
		/* Stop if the media session is in progress*/
		IFX_CMGR_StopMediaSession(pxPeer);

		/* Check if any Call Fwd is to be applied?*/
		if((IFX_CMGR_OUT == pxPeer->eDirection) && 
						(IFX_FALSE == IFX_CMGR_IsCallConn(pxPeer)))
		{
			/* It was an incoming Voip Call - FWD may be needed*/
			boolean bFwdEnabled = IFX_FALSE;
			x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = 
				&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
			memset(&xFwdAddr,0,sizeof(x_IFX_CMGR_VoipAddr));
		
			if(IFX_CMGR_STATE_RINGING == pxLeg->eCurrState)	
			{	/* If state is ringing then apply no-answer call Fwd*/
				eRet = IFX_LMGR_GetCallFwdAddr(pxVoipLegInfo->ucLineId, 
					IFX_CALL_FWD_ON_NO_ANSWER, &bFwdEnabled, NULL, &xFwdAddr,peStatusReason);
			}
			else
			{	/* If state is ringing then apply busy call Fwd*/
				eRet = IFX_LMGR_GetCallFwdAddr(pxVoipLegInfo->ucLineId, 
								IFX_CALL_FWD_BUSY, &bFwdEnabled, NULL, &xFwdAddr,peStatusReason);
			}
			/* Check if call fwd is allowed?*/	
			if((IFX_TRUE == bFwdEnabled) && (IFX_TRUE == 
							IFX_CMGR_CanCallBeFwd(pxVoipLegInfo, &xFwdAddr)))
				eReleaseReason = IFX_CALL_FORWARD;
			else
			{
				if(IFX_CMGR_STATE_RINGING == pxLeg->eCurrState)	
					eReleaseReason = IFX_ENDPOINT_RINGING; //For Fixing BUG #10 Oct 2007 Pre-release. 
																				//It will ensure that instead of 486, 487 is sent
				else
					eReleaseReason = IFX_ENDPOINT_BUSY;
				/* Add the same to the missed call register*/
				IFX_CMGR_AddVoipAddrToMissedCallReg(pxPeer,&pxVoipLegInfo->xRemAddr);
			}						
		}
		else
		{
			eReleaseReason = IFX_TERMINATED;
		}
	}

	if((IFX_CMGR_TYPE_VOIP != pxLeg->xLegOwnerInfo.eOwnerType)&&
		 (IFX_CMGR_TYPE_VOIP != pxPeer->xLegOwnerInfo.eOwnerType))
	{
		/*Both ends are Non-Voip - Invoke XDisconnect*/
		if(IFX_TRUE == IFX_CMGR_IsCallConn(pxLeg))
		{
			IFX_CMGR_XConnect(pxCnxt->iResId, IFX_FALSE, IFX_FALSE, peStatusReason);
		}
		/*Check if the Call was an call From FXO and the 
			call was not answered then add to the missed call register*/
		if(IFX_FALSE == IFX_CMGR_IsCallConn(pxLeg))
		{
			x_IFX_CMGR_AddressInfo xAddrInfo;
			memset(&xAddrInfo,0,sizeof(x_IFX_CMGR_AddressInfo));
			xAddrInfo.eAddressType = IFX_CMGR_TYPE_FXO;
			if((IFX_CMGR_TYPE_FXO == pxLeg->xLegOwnerInfo.eOwnerType) && 
					(IFX_CMGR_OUT != pxPeer->eDirection) ) 
			{
				/*PSTN user disconnected the call could be answered at FXS*/
				memcpy(&xAddrInfo.uxAddressInfo.xFxoInfo, 
					&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
						sizeof(x_IFX_CMGR_FxoInfo));
				IFX_LMGR_AddToMissedCallReg(IFX_PSTN_LINE, &xAddrInfo);
			}
			else if((IFX_CMGR_TYPE_FXO == pxPeer->xLegOwnerInfo.eOwnerType)&&(
							 IFX_CMGR_OUT != pxLeg->eDirection))
			{
				/*FXS user did not answer the call and there was only one FXS user*/
				memcpy(&xAddrInfo.uxAddressInfo.xFxoInfo, 
					&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xFxoLegInfo,
						sizeof(x_IFX_CMGR_FxoInfo));
				IFX_LMGR_AddToMissedCallReg(IFX_PSTN_LINE, &xAddrInfo);
			}
		}
	}

	/*Apply Normal Release Procedure*/	
  /* Call Reinjection */
	if(pxCnxt && pxCnxt->pxPeerAtxCnxt)
	{
    if(pxCnxt->pxPeerAtxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT){
      /* Case where call is released by remote party during reinjection.Release out leg for the other Cnxt as well as 
         all the IN Call legs in forking. Proceed with releasing Peer Call Leg in Current Cnxt */
	    eRet = IFX_CMGR_InvokeRemoteCallRelease(pxCnxt->pxPeerAtxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX], eReleaseReason, &xFwdAddr);
		  eRet = IFX_CMGR_ReleaseCallInForking(pxCnxt->pxPeerAtxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX],eReleaseReason);
    }else{
      /* Proceed with releasing both the legs of the held(Atx) Cnxt when one of the alerting HS rejects the call */
	    eRet = IFX_CMGR_InvokeRemoteCallRelease(pxLeg, eReleaseReason, &xFwdAddr);
     }
	}
	eRet = IFX_CMGR_InvokeRemoteCallRelease(pxPeer, eReleaseReason, &xFwdAddr);
	IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	IFX_CMGR_PrintCallIdList(__FUNCTION__);
	return eRet;
}


/*!
	\brief	Will be called by agent to bring a number of its 
					calls into conference 
	\param[in]	puiCallId are the identifiers of the calls that have to 
					be brought into conference
	\param[in]	ucNumCallIds is the number of calls that have to be 
					brought into conf
	\param[out]	puiReqId the Req-id generated for this Req 
	\param[out]	peStatus the current status for this Req 
	\param[out]	peReason  incase of failure, this parameter provides 
					the specific reason
	\param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_ConfMake(
							IN uint32* puiCallId, 
							IN uint32 ucNumCallIds,
							OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status* peStatus,
							OUT e_IFX_ReasonCode* peReason, /*In case of failure*/  
							IN void* pvPrivateData
							)	
{
	e_IFX_Return eRet=IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxCallLeg[IFX_MAX_CONF_PARTIES];
	x_IFX_CMGR_ReqContext* pxReqCnxt = NULL;
	const uint8 ucMinNumCalls = 2;
	uint8 ucNumReqLegs = 1;
	uint8 ucActiveCnt = 0;
	const uint8 ucMaxActiveCalls = 1;
	int8 cActiveCallIdx = -1;
	uint8 i=0;
	char8 aszEndptId[2][IFX_MAX_ENDPOINTID_LEN];
	uint8 ucValidLegs = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");
	memset(aszEndptId, 0, sizeof(aszEndptId));
	/*Sanity Check*/	
	for(i=0;i<ucNumCallIds;i++)
	{
		pxCallLeg[i] = IFX_CMGR_GetCallLegPtr(puiCallId[i]);
		if(!pxCallLeg[i])
			return IFX_FAILURE;
	}
	/* Check the number of calls and allocate a Req Cnxt structure for it.*/
	if((ucNumCallIds < ucMinNumCalls) || 
						 (ucNumCallIds > IFX_MAX_CONF_PARTIES))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/* Check the states of all the calls in the Req. 
	 * If more than one is active then reject the Req.*/
	for(i=0;i<ucNumCallIds;i++)
	{
		if(IFX_CMGR_STATE_CONV == pxCallLeg[i]->eCurrState)
		{
			cActiveCallIdx = i;
			++ucActiveCnt;
			if(ucActiveCnt > ucMaxActiveCalls)
			{
				*peStatus = IFX_CMGR_STATUS_FAIL;
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				return eRet;
			}
		}
	}
	/*Allocate a ReqContext for this Conference Req*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(ucNumReqLegs,
							  				pvPrivateData,&pxReqCnxt, peReason))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* Copy the EID from the Call Leg number 1*/	
	strcpy(aszEndptId[0],pxCallLeg[0]->xLegOwnerInfo.szEndptId);	
	/* Call IFX_CMGR_PrepReqCnxt*/
	if(IFX_FAILURE == 
		IFX_CMGR_PrepReqCnxt(pxReqCnxt,aszEndptId,ucNumReqLegs,&ucValidLegs))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_DeAllocReqCnxt(pxReqCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Set the Req ID in the right places*/
	*puiReqId = pxReqCnxt->pxReqLegs[0]->uiReqId; 
		
	/* Set the information needed for Conference in the ReqCnxt and the CallLeg*/
	pxReqCnxt->eReqType = IFX_CMGR_REQ_CONF;
	pxReqCnxt->uxReqCnxt.xConfInfo.cActiveCallIndex = cActiveCallIdx;
	pxReqCnxt->uxReqCnxt.xConfInfo.ucNumCalls = ucNumCallIds;
	pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled = IFX_FALSE;
	pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls = ucActiveCnt;
	for(i=0;i<ucNumCallIds;i++)
	{
		/* Send the RESUME Req to all the locally HELD calls and  Also put
	  	Req Id generated in all the call legs participating the conf*/
		pxReqCnxt->uxReqCnxt.xConfInfo.auiCallsInConf[i] = puiCallId[i]; 
		pxCallLeg[i]->uiConfReqId = *puiReqId;
		
		/*Send Resume to all calls - except the already active call*/
		if(pxReqCnxt->uxReqCnxt.xConfInfo.cActiveCallIndex != i)
		{
			eRet = IFX_CMGR_CallResume(puiCallId[i], peStatus, peReason);
			if(IFX_CMGR_STATUS_FAIL == *peStatus)		
			{
				/*Clear Req Context and also the Req Id maintained in the CL*/
				pxCallLeg[i]->uiConfReqId = 0;
				IFX_CMGR_DeAllocReqCnxt(pxReqCnxt);
				break;
			}
			else 
			if(IFX_CMGR_STATUS_SUCCESS == *peStatus)
			{
        /* Fix: Fill Active Call ID appropriately */
				/*Increment active count*/
				++(pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls);
        if(pxReqCnxt->uxReqCnxt.xConfInfo.cActiveCallIndex == i+1){
           pxReqCnxt->uxReqCnxt.xConfInfo.auiCallsInConf[i+1] = puiCallId[i+1];
           pxCallLeg[i+1]->uiConfReqId = *puiReqId;
         }
				/*Check if conference can be enabled and if so enable it*/
				IFX_CMGR_CheckAndEnableConf(pxReqCnxt);	
			}
		}
	}
	/* Find the correct retrun value to return*/	
	if(pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled == IFX_FALSE)
	{
		if(IFX_CMGR_STATUS_FAIL != *peStatus)		
		{
			*peStatus = IFX_CMGR_STATUS_PENDING;
		}
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	Will be called by agent to disable a conference 
	\param[in]	uiReqId the Req-id for this conf
	\param[out]	peStatus the current status for this Req 
	\param[out]	peReason  incase of failure, this parameter provides 
					the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_ConfBreak(
							IN uint32 uiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason 
							)
{
	e_IFX_Return eRet=IFX_SUCCESS;
	x_IFX_CMGR_ReqContext *pxReqCnxt = IFX_CMGR_GetReqCnxtPtr(uiReqId);
	x_IFX_CMGR_CallLeg* pxCallLeg[IFX_MAX_CONF_PARTIES];
	x_IFX_CMGR_ConfInfo* pxConfInfo = 
					pxReqCnxt?&pxReqCnxt->uxReqCnxt.xConfInfo:NULL;
	uint8 i=0;
	*peStatus  = IFX_CMGR_STATUS_PENDING;
	*peReason  = IFX_MAX_REASON;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");
	if(!pxReqCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Req Id",uiReqId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/* 
	 * Find the index of the previously active call if any .
	 *	Send HOLD to all other calls except this call. Post Hold to all these
	 *	calls one by one. As the holds keep suceeding, keep disconnecting their 
	 *	paths. Also keep reducing the active call count. Once the Active call 
	 *	count is Zero or One (depending on if there was any call active 
	 *	initially), call disable mixing and with status success. 
	 */
	for(i=0; i < pxConfInfo->ucNumCalls; i++)
	{
		pxCallLeg[i] = IFX_CMGR_GetCallLegPtr(pxConfInfo->auiCallsInConf[i]);
		
		if(pxConfInfo->cActiveCallIndex != i)
		{
			/*Send Hold one by one*/
			eRet = IFX_CMGR_CallHold(pxConfInfo->auiCallsInConf[i], 
								 								peStatus, peReason);
			if(IFX_CMGR_STATUS_FAIL == *peStatus)		
			{
				/*--- DEBUG --- Major BUG */	
				IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
				return eRet;
			}
			else 
			if(IFX_CMGR_STATUS_SUCCESS == *peStatus)
			{
				/*Decrement active count*/
				--pxReqCnxt->uxReqCnxt.xConfInfo.ucCurrActiveCalls;
				/* Set the Conf request ID on the CL to zero*/
				if(pxCallLeg[i])
					pxCallLeg[i]->uiConfReqId = 0;
				IFX_CMGR_CheckAndDisableConf(pxReqCnxt);
			}
		}
	}
	/* Find the return status to give*/
	if(pxReqCnxt->uxReqCnxt.xConfInfo.bConfEnabled == IFX_TRUE)
	{
		if(IFX_CMGR_STATUS_FAIL != *peStatus)		
		{
			*peStatus = IFX_CMGR_STATUS_PENDING;
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*****************************************************************************
 *  Function Name   : IFX_CMGR_GetReqCnxtAndLegs
 *  Description     : Function generates the Context and Leg structure needed
 *  						 for a request
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_GetReqCnxtAndLegs(
					 IN uint8 ucSize,
					 IN void* pvPrivateData,
					 OUT x_IFX_CMGR_ReqContext** ppxCnxt, 
					 OUT e_IFX_ReasonCode* peReason
					 ) 
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqContext *pxCnxt = NULL;
	uint16 unCnxtIdx = 0; 
	uint8 i;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if((eRet=IFX_CMGR_GetReqContext(ppxCnxt,&unCnxtIdx)) == IFX_FAILURE)
	{
		*peReason = IFX_NO_RESOURCE;/* Free CC not found, hence rejected-DEBUG*/
		return eRet;	
	}
	pxCnxt = *ppxCnxt;

	/*Reserve the required number of Req legs in the REQ_LEG array for the call*/			
	for(i=0;i<(ucSize);i++)
	{
		if((eRet=IFX_CMGR_GetReqLeg(unCnxtIdx, &pxCnxt->pxReqLegs[i]))
							 													==IFX_FAILURE)
		{
			return eRet;/*Failure IFX_FAILURE and STATUS Fail*/	
		}
		if(!i)
			pxCnxt->pxReqLegs[i]->pvPrivateData = pvPrivateData;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_PrepReqCnxt
 *  Description     : Function prepares the request context and legs for a 
 *  						request  transaction.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_PrepReqCnxt
						(
							IN x_IFX_CMGR_ReqContext*  pxCnxt,
							IN char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
							IN uchar8 ucNumEndpts,
							OUT uchar8 *pucValidLegs
					 	)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg;
	uint8 i=0;
	uint8 ucNumEndptNotReg = 0;	
	uint8 ucValidLegs = 0; 
	x_IFX_CMGR_ReqLeg *paxLocLeg[IFX_CMGR_REQ_LEG_PER_CNXT];	
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	memset(paxLocLeg,0,IFX_CMGR_REQ_LEG_PER_CNXT*sizeof(x_IFX_CMGR_ReqLeg*));
	if (ucNumEndpts > IFX_CMGR_REQ_LEG_PER_CNXT)	
		return IFX_FAILURE;
	for(i=0;i<ucNumEndpts;i++)
	{
		pxLeg = pxCnxt->pxReqLegs[i];
		/* Make Pointers to CB structs*/
		if(IFX_CMGR_GetCBList(aszEndptId[i],&pxLeg->pxCallBackList))
		{
			if(i == 0)
			{
				/*Major Error - DEBUG*/
				IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
				return IFX_FAILURE;
			}
			else
			{
				if(ucNumEndptNotReg == (ucNumEndpts-1))
				{
					eRet = IFX_FAILURE;
					IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
					return eRet;
				}
				/*Clear the Call Leg*/
				IFX_CMGR_DeAllocReqLeg(pxCnxt->pxReqLegs[i]);
				/*Set the pointer to NULL*/
				pxCnxt->pxReqLegs[i] = NULL;	
				/*Increment the Not Registered count*/
				++ucNumEndptNotReg;
				/*move back to the loop*/
				continue;
			}
		}
		paxLocLeg[ucValidLegs++] = pxCnxt->pxReqLegs[i];
		memset(pxLeg->szEndptId,0,IFX_MAX_ENDPOINTID_LEN);
		strncpy(pxLeg->szEndptId, aszEndptId[i],IFX_MAX_ENDPOINTID_LEN-1);
		/*Set context to the current one*/
		pxLeg->pxCurrCnxt = pxCnxt;
	}
	/*Copy the local one into the Context pointer*/
	memcpy(pxCnxt->pxReqLegs, paxLocLeg, 
									IFX_CMGR_REQ_LEG_PER_CNXT*sizeof(x_IFX_CMGR_ReqLeg*));
	if(pucValidLegs)
		*pucValidLegs = ucValidLegs;
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeRegisterRsp 
 *  Description     : Invokes CB pfnRegisterRsp
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeRegisterRsp(
					 		IN x_IFX_CMGR_ReqLeg* pxLeg,
							IN uint32 uiExpVal,
							IN e_IFX_CMGR_Status eStatus,
							IN e_IFX_ReasonCode eReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	eRet = pxLeg->pxCallBackList->pfnRegisterRsp(
			pxLeg->uiReqId, uiExpVal ,eStatus, eReason, pxLeg->pvPrivateData);	
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************

 *  Function Name   : IFX_CMGR_InvokeRegister 
 *  Description     : Invokes CB pfnRegister
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeRegister(
					 		IN x_IFX_CMGR_ReqLeg* pxLeg,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(pxLeg)
	{
		x_IFX_CMGR_ReqContext* pxCnxt = pxLeg->pxCurrCnxt;
		uchar8 ucIndex = 	pxCnxt->uxReqCnxt.xRegInfo.ucIndex;
		x_IFX_CMGR_RegParams xRegParmas;
		memset(&xRegParmas,0,sizeof(xRegParmas));
		memcpy(&xRegParmas.xSrvrAddr, 
			   &pxCnxt->uxReqCnxt.xRegInfo.xReServer.axSrvrAddr[ucIndex],
			   sizeof(x_IFX_CalledAddr));
		xRegParmas.uiExpVal   = pxCnxt->uxReqCnxt.xRegInfo.xReServer.uiExpVal;
		xRegParmas.unLineId   = pxCnxt->uxReqCnxt.xRegInfo.xReServer.unLineId;
		xRegParmas.bRetryFlag = pxCnxt->uxReqCnxt.xRegInfo.bRetry;
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Index is  Expries = ",ucIndex,xRegParmas.uiExpVal);

		eRet = pxLeg->pxCallBackList->pfnRegister(&xRegParmas,pxLeg->uiReqId, 
				peStatus, peReason, &pxLeg->pvPrivateData);	
	}
	
	else{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Invalid Params");
		eRet = IFX_FAILURE;
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InitialSipRegister 
 *  Description     : Function handles the first time CFG agent wants to 
 *  						register with SIP registrar.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InitialSipRegister(
							IN x_IFX_CMGR_RegServerInfo *pxRegSrvrInfo,
							OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN void* pvPrivateData
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint8 ucNumReqLegs = 2;
	x_IFX_CMGR_ReqContext* pxCnxt;
	char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN] = {IFX_CFG_AGENT_ENDPT_ID, IFX_NA_ENDPT_ID};
	x_IFX_CMGR_ReqLeg* 	pxOut;
	x_IFX_CMGR_ReqLeg* 	pxIn;
	uint8 ucValidLegs = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/* Call IFX_CMGR_GetReqCnxtAndLegs*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(ucNumReqLegs,
							  				pvPrivateData,&pxCnxt, peReason))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		eRet= IFX_FAILURE;
		IFX_CMGR_DeAllocReqCnxt(pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Call IFX_CMGR_PrepReqCnxt*/
	if(IFX_FAILURE == 
		IFX_CMGR_PrepReqCnxt(pxCnxt, aszEndptId, ucNumReqLegs,&ucValidLegs))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		eRet= IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	pxCnxt->eReqType = IFX_CMGR_REQ_REG;
	pxCnxt->uxReqCnxt.xRegInfo.unVoipLineId = pxRegSrvrInfo->unLineId;
	pxOut = IFX_CMGR_GetOutReqLeg(pxCnxt);
	pxIn = IFX_CMGR_GetInReqLeg(pxCnxt);
	/*Set Peer Pointers*/
	pxOut->pxPeer = pxIn;
	pxIn->pxPeer = pxOut;	
	*puiReqId = pxOut->uiReqId;

	/*Copy Reg Info Detail*/
	memcpy (&pxCnxt->uxReqCnxt.xRegInfo.xReServer,pxRegSrvrInfo, sizeof(x_IFX_CMGR_RegServerInfo));
	pxCnxt->uxReqCnxt.xRegInfo.ucIndex = 0; /*Start with Primary*/


	/*Only Primary Server*/
	if(pxRegSrvrInfo->ucNoOfServer == 1) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
							"Only Primary server configured");
		pxCnxt->uxReqCnxt.xRegInfo.bRetry = IFX_TRUE;
		eRet = IFX_CMGR_InvokeRegister(pxIn,peStatus, peReason);
	}

	/*Primay and Backup Server*/
	else if (pxRegSrvrInfo->ucNoOfServer > 1){
		IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Both Server are Configured");
		pxCnxt->uxReqCnxt.xRegInfo.ucNoOfRetries = 0; /*To limit consecutive retries*/
		pxCnxt->uxReqCnxt.xRegInfo.bRetry = IFX_FALSE;
		eRet = IFX_FAILURE;

		while (IFX_FAILURE == eRet && 
			   	 pxCnxt->uxReqCnxt.xRegInfo.ucNoOfRetries < IFX_NO_OF_REG_SERVER) 
		{
			/*Avoid repeated continous retries */
			pxCnxt->uxReqCnxt.xRegInfo.ucNoOfRetries++;
			pxIn->pvPrivateData = NULL;
			eRet = IFX_CMGR_InvokeRegister(pxIn,peStatus, peReason);
			if(eRet==IFX_FAILURE){ 
				/*switch the server*/
				IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
								"Immidiate failures - Try Again");
				pxCnxt->uxReqCnxt.xRegInfo.ucIndex = (pxCnxt->uxReqCnxt.xRegInfo.ucIndex == 0) ? 1:0;
			}
		}
	}

	if(IFX_FAILURE == eRet) {
			IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Failing Something Fishy");
		IFX_CMGR_DeAllocReqCnxt(pxCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*To be invoked by the VMAPI agent and implemented by the CMGR*/

/*!
	\brief This API is used by the VMAPI agent to trigger a 
			 SIP registration/de-registration
	\param[in] unLineId is the VoIP Line ID needed for this Req. 
	\param [in] uiExpVal is the time for which registration is Reqed. 
				 If Zero it means that de-regsitration is Reqed
	\param [in,out] puiReqId is the Req if for this register/unregister 
						Req. If the above param is non-zero it is an OUT param 
						else it is an IN param.
	\param [out] peStatus is the status of the Req as given by the remote agent
	\param [out] peReason - incase of failure, this parameter provides the 
					 specific reason
	 \param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_CMGR_Register(
							IN x_IFX_CMGR_RegServerInfo *pxRegServerInfo,
							IN_OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN void* pvPrivateData)

{
	e_IFX_Return eRet = IFX_SUCCESS;
	int16 nDestroy = 0;
	if(*peReason == IFX_REL_NO_NOTIFY){
	  nDestroy =1;
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Could be destroy SrvPdr Req Leg will be freed");
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(!puiReqId || !pxRegServerInfo){		
		 IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Invlaid IN Params");
		  return IFX_FAILURE;
	}
	*peStatus = IFX_CMGR_STATUS_PENDING;

	if(!(*puiReqId))
	{	/* If its Zero then its a new - registration Req*/
		eRet = IFX_CMGR_InitialSipRegister(pxRegServerInfo,puiReqId,peStatus,peReason,pvPrivateData);
	}

	else
	{	/*Its an Re-register/UnReg Req*/
		x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(*puiReqId);
		x_IFX_CMGR_ReqContext* pxCnxt = IFX_CMGR_GetReqCnxtPtr(*puiReqId);
		uint32 uiExpVal = pxRegServerInfo->uiExpVal;
		if(pxCnxt){
			/* Invoke pfnRegister CB from the Voip leg */	
		pxCnxt->uxReqCnxt.xRegInfo.xReServer.uiExpVal = uiExpVal;
		eRet = IFX_CMGR_InvokeRegister(IFX_CMGR_GetPeerPtr(pxLeg),peStatus, peReason);
		}
		
		/*Check if it was an UnReg request and eRet fails, then inform the FXS/DECT Agent
		  and remove Request leg */
		if((eRet==IFX_FAILURE && uiExpVal == 0) || nDestroy /*Due to Destroy SrvPrd*/)
		{
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Freeing Reg ReqCntx");
		 if (pxLeg == NULL || (pxLeg != NULL && pxLeg->pxCurrCnxt == NULL))
		 	return eRet;
		 IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);		
		 return eRet;
	  	}

	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief This API is used by the NA agent to respond to a previous
			registration/de-registartion Req.
	\param[in] uiReqId is the Id for this regsitration Req
	\param[in] uiExpVal is the time for which registration is accepted. 
	\param[in] eStatus is the status of the Reqed operation
	\param[in] eReason - incase of failure, 
				  this parameter provides the specific reason
  \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_RegisterRsp(
							IN uint32 uiReqId,
							IN uint32 uiExpVal,
							IN e_IFX_CMGR_Status eStatus,
							IN e_IFX_ReasonCode eReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_Return eRet_1 = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	if(!pxLeg)	{
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;	
	}

	if(IFX_CMGR_IsIdValid(uiReqId,IFX_FALSE)== IFX_FAILURE 
			|| !(uiReqId) ) {
		  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid ReqId");
		return IFX_FAILURE;
	}
	
		
	if (uiExpVal  != 0 && IFX_CMGR_STATUS_FAIL == eStatus){	
		x_IFX_CMGR_ReqContext *pxCnxt = IFX_CMGR_GetReqCnxtPtr(uiReqId);
		eRet = IFX_FAILURE;
		IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Reg failed - Staring Again");

		if(pxCnxt && pxCnxt->uxReqCnxt.xRegInfo.xReServer.ucNoOfServer > 1) {
				pxCnxt->uxReqCnxt.xRegInfo.ucNoOfRetries = 0; /*Resetting Count*/
				
				while (IFX_FAILURE == eRet && 
					   pxCnxt->uxReqCnxt.xRegInfo.ucNoOfRetries < IFX_NO_OF_REG_SERVER) 
				{
						pxCnxt->uxReqCnxt.xRegInfo.ucNoOfRetries++;
						pxCnxt->uxReqCnxt.xRegInfo.ucIndex =	
								(pxCnxt->uxReqCnxt.xRegInfo.ucIndex == 0) ? 1:0;
						IFX_DBGC(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
										"Trying with Index ", pxCnxt->uxReqCnxt.xRegInfo.ucIndex);
						pxLeg->pvPrivateData = NULL;
						eRet = IFX_CMGR_InvokeRegister(pxLeg,&eStatus, &eReason);
				}
			}
	}
	eRet_1 = IFX_CMGR_InvokeRegisterRsp(pxLeg->pxPeer, uiExpVal, eStatus, eReason);

	if(IFX_FAILURE == eRet || 0 == uiExpVal) {
		IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);
	}
	IFX_CMGR_PrintExitInfo(eRet_1, __FUNCTION__, __LINE__);
	return eRet_1;	
}
/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeSubnSnd 
 *  Description     : Invokes CB pfnSubnSnd
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeSubnSnd(
							IN x_IFX_CMGR_AddressInfo *pxAddr,
					 		IN x_IFX_CMGR_ReqLeg* pxLeg,
							IN e_IFX_CMGR_SubsEvent eSubsEvt,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason
							)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqContext* pxCnxt = NULL;
	uint16 unLineId = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg)
		return IFX_FAILURE;
	/*Find the Current Context*/
	pxCnxt = pxLeg->pxCurrCnxt;
	if(IFX_CMGR_SUBS_AUTO_REDIAL == eSubsEvt)
		unLineId = pxCnxt->uxReqCnxt.xArdSubsInfo.unVoipLineId;
	else
	if(IFX_CMGR_SUBS_VOICE_MAIL == eSubsEvt)
		unLineId = pxCnxt->uxReqCnxt.xVmSubsInfo.unVoipLineId;
	
	eRet = pxLeg->pxCallBackList->pfnSubnSnd(pxAddr, unLineId, eSubsEvt,
		pxLeg->uiReqId, peStatus, peReason, &pxLeg->pvPrivateData);	
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InitialSipVmSubscribe
 *  Description     : Function handles the first time CFG agent wants to 
 *  						register with SIP Voice mail server.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InitialSipVmSubscribe(
					 		IN uint16 unLineId,
							IN uint32 uiExpVal,
							OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN void* pvPrivateData
							)
{
	e_IFX_Return eRet = IFX_FAILURE;
	uint8 ucNumReqLegs = 2;
	x_IFX_CMGR_ReqContext* pxCnxt;
	char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN] = {IFX_CFG_AGENT_ENDPT_ID,
																	IFX_NA_ENDPT_ID};
	x_IFX_CMGR_ReqLeg* 	pxOut;
	x_IFX_CMGR_ReqLeg* 	pxIn;
	uint8 ucValidLegs = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Call IFX_CMGR_GetReqCnxtAndLegs*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(ucNumReqLegs,
							  				pvPrivateData,&pxCnxt, peReason))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Call IFX_CMGR_PrepReqCnxt*/
	if(IFX_FAILURE == 
		IFX_CMGR_PrepReqCnxt(pxCnxt, aszEndptId, ucNumReqLegs,&ucValidLegs))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/*Save VM subs related information in the Req Context*/
	pxCnxt->eReqType = IFX_CMGR_REQ_SUBS_VOICE_MAIL;
	pxCnxt->uxReqCnxt.xVmSubsInfo.unVoipLineId = unLineId;
	pxOut = IFX_CMGR_GetOutReqLeg(pxCnxt);
	pxIn = IFX_CMGR_GetInReqLeg(pxCnxt);

	/*Set Peer Pointers*/
	pxOut->pxPeer = pxIn;
	pxIn->pxPeer = pxOut;
	
	/* Invoke pfnSubnSnd CB from the IN CL */	
	eRet = IFX_CMGR_InvokeSubnSnd(NULL, pxIn, IFX_CMGR_SUBS_VOICE_MAIL, 
						 													peStatus, peReason );
	/*Populate the Req ID*/
	*puiReqId = pxOut->uiReqId;
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief Called by the Configuration agent to allow the 
		to send subscribe for Voice Mail to the voice mail server
	\param[in] unLineId is the VoIP Line ID Reqed 
	\param[in] uiExpVal is the time for which subscription  is Reqed.
				  Zero for un-subscribe Req.
	\param [in,out] puiReqId is the Req id for this subscribe 
						Req.
	\param [ out]	 peStatus is the status of the Req as given by the remote agent
	\param [ out]	 peReason - incase of failure, this parameter provides the specific reason
	 \param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_VM_Subn(
					 		IN uint16 unLineId,
							IN uint32 uiExpVal,
							IN_OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN void* pvPrivateData)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uint16 nDestroy=0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!puiReqId)
			  return IFX_FAILURE;	
	
	/*Fix:2307 Put here to remove ReqCntx - instead waiting for response from NA*/
	if(*peReason == IFX_REL_NO_NOTIFY)
	{
	  nDestroy =1;
	  IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Could be destroy SrvPdr, Req Leg will be freed");
	}
	
	*peStatus = IFX_CMGR_STATUS_PENDING;

	if(!(*puiReqId))
	{	/* If its Zero then its a new - subscription Req*/
		eRet = IFX_CMGR_InitialSipVmSubscribe(unLineId,uiExpVal,puiReqId,
							 			peStatus,peReason,pvPrivateData);
	}
	else
	{	/*Its an re - subs Req*/
		/*Find the pxLeg*/
		x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(*puiReqId);
		
		/*Check for Invalid Request Id*/
		if(!pxLeg)
				return IFX_FAILURE;		
		
		/*Check if its an Un-subscribe Request*/
		if(!uiExpVal){
			 *peReason = IFX_UNSUBSCRIBE;
		}
		/* Invoke pfnSubnSnd CB from the Voip leg */
		if(IFX_CIF_VLVMStatusGet(unLineId) == IFX_SUCCESS){
	      IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Already subscribed so sending Unsubscribe");
		  eRet = IFX_CMGR_InvokeSubnSnd(NULL, pxLeg->pxPeer, 
							 	IFX_CMGR_SUBS_VOICE_MAIL, peStatus, peReason);	
		}
		
	 if(nDestroy)
	 {
	    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Freeing VMS Req Cnxt");
		IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);		
	 }
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}



/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeSubsToVmResp
 *  Description     : Invokes CB pfnVM_SubnRsp
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeSubsToVmResp(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
					 	IN uint32 uiExpTime,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	eRet = pxLeg->pxCallBackList->pfnVM_SubnRsp(pxLeg->uiReqId, 
						 uiExpTime, eSubsStatus, eRespCode, pxLeg->pvPrivateData);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;	  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_VoiceMailSubsStatus
 *  Description     : Handles the Voice mail status and informs the same to CFG
 *  						 agent.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_VoiceMailSubsStatus(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
						IN uint32 uiExpTime,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!pxLeg)
		return IFX_FAILURE;
	/* Inform the other party about the status*/		 
  if(IFX_CMGR_STATUS_FAIL == eSubsStatus)
	{				
		uiExpTime =0;	
	}
	eRet = IFX_CMGR_InvokeSubsToVmResp(IFX_CMGR_GetPeerPtr(pxLeg), 
						 						uiExpTime, eSubsStatus, eRespCode);
		
	/*Check if the status is a Failure then free the Req context and legs*/
	if(IFX_CMGR_STATUS_FAIL == eSubsStatus || 0==uiExpTime)
	{
		IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);		
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeArdSubsRsp
 *  Description     : Invokes CB pfnARD_Status
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeArdSubsRsp(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	if(!pxLeg)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;

	}
	
	if(!pxLeg->pxCallBackList)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;

	}
	
	if(!pxLeg->pxCallBackList->pfnARD_Status)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
	}
	
	if(!pxLeg->uiReqId)
	{
	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Zero Req ID");
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
	}
	
	if(!pxLeg->pvPrivateData)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Null Private Data!");
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
	}	
	
	if(pxLeg->pxCallBackList->pfnARD_Status)
		eRet = pxLeg->pxCallBackList->pfnARD_Status(pxLeg->uiReqId, 
						 eSubsStatus, eRespCode, pxLeg->pvPrivateData);

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;	  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_VoiceMailSubsStatus
 *  Description     : Handles auto redial status and informs the same to 
 *  						 agent.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_ArdSubsStatus(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
						IN uint32 uiExpTime, 
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Inform the other party about the status*/		  
	IFX_CMGR_InvokeArdSubsRsp(IFX_CMGR_GetPeerPtr(pxLeg), eSubsStatus, eRespCode);		
	/*Check if the expiry time is Zero - then free the Req context and legs*/
	if(IFX_CMGR_STATUS_FAIL == eSubsStatus)
	{
		IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);		
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*!
	\brief	The NA will call this API when the subscription is accepted/rejected
				by the remote party
 	\param[in]	uiReqId is the Req ID
	\param[in] uiExpTime is the time for which the subscription was accepted
	\param[in]  eSubsStatus is the status of the Reqed subscription
	\param[in]	eRespCode is the Rsp Code in case of failure
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_SubnStatus(
					 	IN uint32 uiReqId,
						IN uint32 uiExpTime,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqContext* pxCnxt = IFX_CMGR_GetReqCnxtPtr(uiReqId); 
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId); 
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	
	if(!uiReqId||!pxLeg||!pxCnxt)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Check the Type of the Req-id - VM or AutoRedial*/
	if(IFX_CMGR_REQ_SUBS_VOICE_MAIL  == pxCnxt->eReqType)
	{
		eRet = IFX_CMGR_VoiceMailSubsStatus(pxLeg,
							 uiExpTime, eSubsStatus, eRespCode);
	}
	else if(IFX_CMGR_REQ_SUBS_AUTO_REDIAL == pxCnxt->eReqType)
	{
		eRet = IFX_CMGR_ArdSubsStatus(pxLeg,uiExpTime,eSubsStatus, eRespCode);
	}
	else
	{
		/* Its an error - Not acceptable*/
		eRet = IFX_FAILURE;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeArdNtfyRcv
 *  Description     : Invokes CB pfnARD_NtfnRcv
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeArdNtfyRcv(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
						IN e_IFX_CMGR_Status eRemStatus,
						IN e_IFX_ReasonCode eRespCode)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Inform the other party about the status*/		 
 	if(pxLeg->pxCallBackList->pfnARD_NtfnRcv)	
		eRet = pxLeg->pxCallBackList->pfnARD_NtfnRcv(pxLeg->uiReqId,
						 eRemStatus, eRespCode, pxLeg->pvPrivateData);
			
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_InvokeVM_NtfnRcv 
 *  Description     : Invokes CB pfnVM_NtfnRcv
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_InvokeVM_NtfnRcv(
					 	IN x_IFX_CMGR_ReqLeg* pxLeg,
						IN x_IFX_CMGR_VoiceMailNotifyInfo* pxNotifyInfo
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	/* Inform the other party about the status*/		  
	eRet = pxLeg->pxCallBackList->pfnVM_NtfnRcv(
		pxLeg->uiReqId, pxNotifyInfo, pxLeg->pvPrivateData);
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

#ifdef CAT_IQ2_0 
/*!
	\brief	Voice Mail Notifiction for DECT handsets
	\param[in]  pxNotifyInfo is the Information carried in the NOTIFY message,
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return 
IFX_CMGR_NtfnRcv_NtfyEp(IN x_IFX_CMGR_NotifyInfo* pxNotifyInfo)
{
  e_IFX_Return eRet=IFX_FAILURE;
  x_IFX_CMGR_VoiceMailEPNotify xVMNotifyEp;
  char8 aszEid[IFX_CMGR_MAX_AGENTS][IFX_MAX_ENDPOINTID_LEN];
  x_IFX_CMGR_CallBackList *pxDectCBList = NULL;
  uchar8 ucLineId=0,ucSize=IFX_CMGR_MAX_AGENTS;
  e_IFX_ReasonCode eReason;
  int32 iVar=0;
		
  /* From the To address fetch the Line ID */
  if(IFX_SUCCESS != IFX_CIF_VLFromUrlGet(&pxNotifyInfo->xToAddress.
		         uxAddressInfo.xVoipAddr, &ucLineId, &eReason)){
    IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
    return IFX_SUCCESS;
  }
  /* From Line ID fetch the end point attached */
  eRet = IFX_CIF_VLEndptListGet(ucLineId, 0, &ucSize, aszEid, &eReason); 
  if((IFX_FAILURE == eRet) || (!ucSize)){
    IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return IFX_SUCCESS;
    /* No need to return assuming the case where profile exists
	 * but no lines */
  }
  /* Check if the endpoint has regd for this CB and invoke it */
  /* Note: Only DECT HS will Reg as of now */
	if (ucSize > IFX_CMGR_MAX_AGENTS)
		return IFX_FAILURE;
  for(iVar=0;iVar<ucSize;iVar++){
    if(IFX_FAILURE==IFX_CMGR_GetCBList(aszEid[iVar],&pxDectCBList)){
	  IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	  return eRet;
	}
    xVMNotifyEp.ucLineId = ucLineId;
    memcpy(xVMNotifyEp.acEndptId, aszEid[iVar],IFX_MAX_ENDPOINTID_LEN);
    if(pxDectCBList->pfnVM_NtfnRcv != NULL){
      eRet = pxDectCBList->pfnVM_NtfnRcv(0, 
						&pxNotifyInfo->uxNotifyInfo.xVmNtfyInfo, 
						(void*)&xVMNotifyEp);
      if(IFX_FAILURE == eRet){
	    eRet = IFX_SUCCESS;
	  }
	}
  }
  return IFX_SUCCESS;
}
#endif

/*!
	\brief	The NA will call this API when a NOTIFY is recived by it
 	\param[in,out]	puiReqId is the Req ID
	\param[in] uiExpTime is the time for which the subscription is still active
	\param[in]  pxNotifyInfo is the Information carried in the NOTIFY message,
	\param[out] peNotifyAccepted is the Rsp from the CMGR to indicate if
					a 200 for the notify is to be sent out or not. Needed for 
					un-solicited notifies.
	\param[out] peReason is the reason for possible rejection
	\param[in] pvPrivateData is the private data for use by the agent.
						This will be populated if the *puiReqId's value is Zero.
						This means that the NA is Requesting the CMGR to generate a
						new Req-Id for an un-solicited notify.
						The parameter SHOULD be NULL when a normal notify is being
						reported, as its on an already existing Req-id.
						
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_NtfnRcv(
					 	IN_OUT uint32* puiReqId,
						IN uint32 uiExpTime,
						IN x_IFX_CMGR_NotifyInfo* pxNotifyInfo,
						OUT e_IFX_CMGR_Status *peNotifyAccepted,
						OUT e_IFX_ReasonCode *peReason,
						IN void* pvPrivateData
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqContext* pxCnxt = IFX_CMGR_GetReqCnxtPtr(*puiReqId); 
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(*puiReqId);
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
	x_IFX_CMGR_CallBackList* pxCallBackList = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/* Check if this is an unsolicited NTFY*/
	if(!*puiReqId)
	{
		*peNotifyAccepted  = IFX_CMGR_STATUS_SUCCESS;
			
		/* Check if the Notify is a VM notify*/
		if(IFX_CMGR_SUBS_VOICE_MAIL != pxNotifyInfo->eSubsEvt)
		{
			*peNotifyAccepted  = IFX_CMGR_STATUS_FAIL;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		/* Find the CB Struct for the CFG agent and invoke pfnVM_NtfnRcv*/
		if(IFX_FAILURE==IFX_CMGR_GetCBList(IFX_CFG_AGENT_ENDPT_ID,&pxCallBackList))
		{
			*peNotifyAccepted  = IFX_CMGR_STATUS_FAIL;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
		/*Check if the setting for un-solicited notify is set - else  
		 * *peNotifyAccepted to FAIL */
		/* HACK - To avoid changing the header prototype ... */
		eRet = pxCallBackList->pfnVM_NtfnRcv(0, 
						&pxNotifyInfo->uxNotifyInfo.xVmNtfyInfo, (void*)pxNotifyInfo);
		if(IFX_FAILURE == eRet)
		{
			*peNotifyAccepted  = IFX_CMGR_STATUS_FAIL;
			eRet = IFX_SUCCESS;
		}
#ifdef CAT_IQ2_0 
        IFX_CMGR_NtfnRcv_NtfyEp(pxNotifyInfo);
#endif		
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Sanity Check*/	
	if(!pxCnxt || !pxLeg)
	{
		return IFX_FAILURE;
	}
	/*Check the Type of the Req-id - VM or AutoRedial*/
	else if(IFX_CMGR_REQ_SUBS_VOICE_MAIL  == pxCnxt->eReqType)
	{
		eRet = IFX_CMGR_InvokeVM_NtfnRcv(pxLeg->pxPeer, 
							 &pxNotifyInfo->uxNotifyInfo.xVmNtfyInfo);
		/*Check if Subsc is terminated by server (Notify with terminated),
		 if so, intimate CFG agent about it and free the Request leg*/
		if(0==uiExpTime)
		{
		 IFX_CMGR_InvokeSubsToVmResp(IFX_CMGR_GetPeerPtr(pxLeg), 						 						
		 0, IFX_CMGR_STATUS_SUCCESS, IFX_TERMINATED);				
		 IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);
		}
#ifdef CAT_IQ2_0 
        IFX_CMGR_NtfnRcv_NtfyEp(pxNotifyInfo);
#endif		
	}
	else if(IFX_CMGR_REQ_SUBS_AUTO_REDIAL == pxCnxt->eReqType)
	{
		if(IFX_FALSE == 
				pxNotifyInfo->uxNotifyInfo.xAutoNtfyInfo.bRemoteFree)
		{
			/* Its not set to FAILURE as it would cause an issue with the FXS agent*/
			eStatus = IFX_CMGR_STATUS_PENDING; 	
		}
		eRet = IFX_CMGR_InvokeArdNtfyRcv(pxLeg->pxPeer, eStatus, IFX_MAX_REASON);
		/* If the Expiry time is Zero or the Deactivation was requested*/
		if((!uiExpTime) || (IFX_TRUE == pxCnxt->uxReqCnxt.xArdSubsInfo.bDeActReq))
			IFX_CMGR_DeAllocReqCnxt(pxLeg->pxCurrCnxt);

	}
	else
	{
		/* Its an error - Not acceptable*/
		eRet = IFX_FAILURE;
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/* ****************************************************************************
 * API's that need to be invoked by Agents for Subscription manipulations
 * ****************************************************************************/

/* ****************************************************************************
 * API's & Callbacks for Transfers
 * ****************************************************************************/

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindAtxType 
 *  Description     : Function finds the type of attended call transfer to do.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : e_IFX_CMGR_TypeOfTransfer type 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_CMGR_TypeOfTransfer IFX_CMGR_FindAtxType
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_CallLeg* pxPeer,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiRepCallId
			)
{
	e_IFX_CMGR_TypeOfTransfer eRet  = 0;
	
	e_IFX_CMGR_CallType eInit = pxLeg->xLegOwnerInfo.eOwnerType;
	e_IFX_CMGR_CallType ePeer = pxPeer->xLegOwnerInfo.eOwnerType;
	x_IFX_CMGR_CallLeg* pxAtxLeg = NULL; 
	x_IFX_CMGR_CallLeg* pxAtxPeer = NULL;
	e_IFX_CMGR_CallType eTarget=0; 
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	pxAtxPeer = IFX_CMGR_GetPeerPtr(pxAtxLeg);
	
	switch(eInit)
	{
		case IFX_CMGR_TYPE_EXTN:
		case IFX_CMGR_TYPE_FXO:
			if(pxAtxPeer)
				eTarget = pxAtxPeer->xLegOwnerInfo.eOwnerType;
			else
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Atx Peer");

			if(IFX_CMGR_TYPE_VOIP == ePeer)
			{
				if(IFX_CMGR_TYPE_VOIP == eTarget)
				{
					eRet = IFX_CMGR_ATX_INT_VOIP_VOIP;
				}
				else /* Target is an internal party*/
				{
					eRet = IFX_CMGR_ATX_INT_VOIP_INT;
				}
			}
			else /*Peer Party is internal*/
			{
				if(IFX_CMGR_TYPE_VOIP == eTarget)
				{
					eRet = IFX_CMGR_ATX_INT_INT_VOIP;
				}
				else /* Target is an internal party*/
				{
					eRet = IFX_CMGR_ATX_INT_INT_INT;
				}
			}
		break;
		case IFX_CMGR_TYPE_VOIP:
			
			eTarget = pxTarget->eAddressType;
			if(IFX_CMGR_TYPE_VOIP != ePeer)
			{
				/*Its an internal party*/
				eRet = IFX_CMGR_ATX_VOIP_INT_VOIP;	
			}
		break;
	}

	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_FindBtxType 
 *  Description     : Function finds the type of blind call transfer to do.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : e_IFX_CMGR_TypeOfTransfer type 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_CMGR_TypeOfTransfer IFX_CMGR_FindBtxType
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_CallLeg* pxPeer,
				IN x_IFX_CMGR_AddressInfo* pxTarget
			)
{
	e_IFX_CMGR_TypeOfTransfer eRet  = 0;
	e_IFX_CMGR_CallType eTarget = pxTarget->eAddressType;
	e_IFX_CMGR_CallType eInit = pxLeg->xLegOwnerInfo.eOwnerType;
	e_IFX_CMGR_CallType ePeer = pxPeer->xLegOwnerInfo.eOwnerType;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	switch(eInit)
	{
		case IFX_CMGR_TYPE_EXTN:
		case IFX_CMGR_TYPE_FXO:
			if(IFX_CMGR_TYPE_VOIP == ePeer)
			{
				if(IFX_CMGR_TYPE_VOIP == eTarget)
				{
					eRet = IFX_CMGR_BTX_INT_VOIP_VOIP;
				}
				else /* Target is an internal party*/
				{
					eRet = IFX_CMGR_BTX_INT_VOIP_INT;
				}
			}
			else /*Peer Party is internal*/
			{
				if(IFX_CMGR_TYPE_VOIP == eTarget)
				{
					eRet = IFX_CMGR_BTX_INT_INT_VOIP;
				}
				else /* Target is an internal party*/
				{
					eRet = IFX_CMGR_BTX_INT_INT_INT;
				}
			}
		break;
		case IFX_CMGR_TYPE_VOIP:
			if(IFX_CMGR_TYPE_VOIP != ePeer)
			{
				/*Its an internal party*/
				eRet = IFX_CMGR_BTX_VOIP_INT_VOIP;	
			}
		break;
	}

	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsTransferAcceptable 
 *  Description     : Function decides if call transfer can happen.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : e_IFX_TransferStatus type 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_TransferStatus IFX_CMGR_IsTransferAcceptable
									(
										IN x_IFX_CMGR_CallLeg *pxLeg,
										IN x_IFX_CMGR_CallLeg* pxPeer,
										IN uint32 uiRepCallId,
										IN e_IFX_CMGR_TypeOfTransfer eType
									) 

{
	e_IFX_TransferStatus eRet = IFX_CMGR_TRANSFER_REJECTED;
	x_IFX_CMGR_CallLeg* pxAtxLeg;
	x_IFX_CMGR_CallLeg* pxAtxPeer;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
#ifdef FAX_SUPPORT
	/*Check if the call is a FAX call. Then  reject the transfer*/
	if(IFX_CMGR_GET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																		IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Exit");
		return IFX_CMGR_TRANSFER_REJECTED;	
	}
#endif
	switch(eType)
	{
		case IFX_CMGR_BTX_INT_VOIP_VOIP: 
		case IFX_CMGR_BTX_INT_VOIP_INT:
		case IFX_CMGR_BTX_INT_INT_VOIP:
		case IFX_CMGR_BTX_INT_INT_INT:
		{
			if(pxLeg->eCurrState == IFX_CMGR_STATE_HELD)
			{
				if(pxPeer->eCurrState == IFX_CMGR_STATE_CONV)
				{
					eRet = IFX_CMGR_TRANSFER_PENDING;
				}
			}
		}
		break;
		
		case IFX_CMGR_ATX_INT_VOIP_VOIP: 
		case IFX_CMGR_ATX_INT_VOIP_INT:
		case IFX_CMGR_ATX_INT_INT_VOIP:
		case IFX_CMGR_ATX_INT_INT_INT:
		{
			pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
			pxAtxPeer = IFX_CMGR_GetPeerPtr(pxAtxLeg);
			
			if(!pxAtxLeg || !pxAtxPeer)
			{
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Major Error!");
				return IFX_CMGR_TRANSFER_FAILED;
			}

			if(pxLeg->eCurrState == IFX_CMGR_STATE_HELD)
				if(pxPeer->eCurrState == IFX_CMGR_STATE_CONV)
					if(pxAtxLeg->eCurrState == IFX_CMGR_STATE_CONV)
						if(pxAtxPeer->eCurrState == IFX_CMGR_STATE_CONV)
							  eRet = IFX_CMGR_TRANSFER_PENDING;
#ifdef FAX_SUPPORT
			/*Check if the call is a FAX call. Then  reject the transfer*/
			if(IFX_CMGR_GET_FLAG((pxAtxLeg->pxCurrCnxt->unFlags),\
																				IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
			{
				eRet = IFX_CMGR_TRANSFER_REJECTED;	
			}
#endif
		}
		break;	
		case IFX_CMGR_ATX_VOIP_INT_VOIP:
		case IFX_CMGR_BTX_VOIP_INT_VOIP:
		{
			if((pxLeg->eCurrState == IFX_CMGR_STATE_HELD)||
					(pxLeg->eCurrState == IFX_CMGR_STATE_CONV))
			{
				if(pxPeer->eCurrState == IFX_CMGR_STATE_CONV)
				{
					eRet = IFX_CMGR_TRANSFER_PENDING;
				}
			}
		}
		break;
		case IFX_CMGR_ATX_MAX_TYPE: 
		case IFX_CMGR_BTX_MAX_TYPE: 
		default:
			eRet = IFX_CMGR_TRANSFER_REJECTED;
		break;
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Exit");
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_BtxIntVoipVoip 
 *  Description     : Function handles Internal-Voip-Voip type of Blind Tx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_BtxIntVoipVoip
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,
				OUT e_IFX_ReasonCode *peReason
			)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	/*Sanity Check*/
	if(!pxLeg || !pxPeer)
	{
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	/* Change state of the legs to SRP(Btx) and RRP(Btx)*/
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_BTX);
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_BTX);
		
	/* Invoke BtxReq on the Peer Leg*/
	eRet = IFX_CMGR_InvokeBtxReq(pxPeer, pxTarget, peStatus, peReason);
	if((IFX_CMGR_TRANSFER_REJECTED == *peStatus)||
		(IFX_CMGR_TRANSFER_FAILED == *peStatus))
	{
		/*Change State of pxLeg & pxPeer to Previous states*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
	}else
	if(IFX_CMGR_TRANSFER_PENDING == *peStatus)
	{		
		/*Do nothing - DEBUG */
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Transfer Pending");
	}
	else
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Wrong return Code");
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}


/*****************************************************************************
 *  Function Name   : IFX_CMGR_BtxVoipIntVoip 
 *  Description     : Function handles Voip-Internal-Voip type of Blind Tx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_BtxVoipIntVoip
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,
				OUT e_IFX_ReasonCode *peReason
			)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg->pxCurrCnxt;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallLeg* pxParent = pxLeg;
	x_IFX_CMGR_CallLeg* pxChild = pxLeg->pxChild;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	uint16 unCnxtIdx = IFX_CMGR_FindCallCnxtIdx(pxCnxt);
	x_IFX_CMGR_CallParams xPar;
	x_IFX_CMGR_CodecParams *pxExtnNegCodecs = NULL, *pxVoipOffCodecs = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	/* Change state of the pxLeg to SRP (Btx).*/
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_BTX);
	/* Change state of the peer leg to RRP (Btx)*/
	if (pxPeer == NULL)
		return IFX_FAILURE;
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_BTX);

	/*Prepare the child call leg*/
	IFX_CMGR_GetCallLeg(unCnxtIdx,&pxParent->pxChild);
	pxChild = pxParent->pxChild;
	eRet = IFX_CMGR_PrepareChildLegForTx(pxParent, pxChild, pxTarget);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_DeAllocCallLeg(pxChild);
		pxLeg->pxChild = NULL;
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		*peReason = IFX_MAX_REASON;
		IFX_CMGR_PrintExitInfo(IFX_SUCCESS, __FUNCTION__, __LINE__);
		return IFX_SUCCESS;
	}
	pxChild->pxParent = pxParent;
	
	/* Ask the peer party if it wants to allow transfer of the call?*/
	if((eRet = IFX_CMGR_InvokeBtxReq(pxPeer, pxTarget, peStatus, peReason))
						 																== IFX_FAILURE)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /*DEBUG*/
	}
	/* Check the return status of the BTx Req*/
	if(IFX_CMGR_TRANSFER_ACCEPTED == *peStatus)
	{
		/*Get Additional Media Resource for this call*/
		eRet = IFX_CMGR_GetAddMediaRes(pxCnxt->iResId, pxPeer, pxChild, 
							 &pxCnxt->iResIdForTransfer, &eStatus, peReason);
		if((IFX_FAILURE == eRet) || (!pxCnxt->iResIdForTransfer)
										)
		{
			IFX_CMGR_DeAllocCallLeg(pxChild);
			pxLeg->pxChild = NULL;
			*peStatus = IFX_CMGR_TRANSFER_REJECTED;
			*peReason = IFX_MAX_REASON;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;	/*DEBUG*/
		}
	
		/*Before Making the Child's Call Params, Re-Order the codecs on the both
		 ends in case the call is an EXTN-VOIP call where the EXTN has codecs.*/
		pxVoipOffCodecs = 
			&pxChild->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xOfferedCodecInfo;
		if(IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType)
		{
			pxExtnNegCodecs = 
				&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;	
		}
		/*Re-order codecs for WB/NB*/
		IFX_CMGR_ReOrderCodecsForWB(pxExtnNegCodecs,pxVoipOffCodecs,IFX_FALSE);	
		/* Populate the Call params for the Target Party*/
		memset(&xPar, 0, sizeof(x_IFX_CMGR_CallParams));
		xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
		/*Copy Codecs from the Call Leg into the Params*/	
		IFX_CMGR_MakeCallParamsIntVoip(pxChild,NULL,&xPar);
		/* Change state to RRP Invite*/
		IFX_CMGR_ChangeState(pxChild,
				IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
		IFX_CMGR_InvokeCallIncIntVoip(pxPeer, pxChild, &xPar, &eStatus, peReason);
		if(IFX_CMGR_STATUS_FAIL == eStatus)
		{
			*peStatus = IFX_CMGR_TRANSFER_FAILED;
			IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
		}
		else
		{	/*Status is pending - change state of the Parent and peer leg*/
			IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
			IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);
			/*Reset flag, so that MediaCfg is invoked on this leg*/
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE);
		}
	}else
	if(IFX_CMGR_TRANSFER_REJECTED == *peStatus)
	{
		IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;		  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_BtxIntVoipInt 
 *  Description     : Function handles Internal-Voip-Internal type of Blind Tx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_BtxIntVoipInt
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,
				OUT e_IFX_ReasonCode *peReason
			)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallLeg* pxChild = pxLeg->pxChild;
	x_IFX_CMGR_CallLeg* pxParent  = pxLeg;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg->pxCurrCnxt;
	uint16 unCnxtIdx = IFX_CMGR_FindCallCnxtIdx(pxCnxt);
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	x_IFX_CMGR_CallParams xPar;
	
	if (pxPeer == NULL)
		return IFX_FAILURE;
	e_IFX_CMGR_CallType ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
	e_IFX_CMGR_CallType eTargetType = pxTarget->eAddressType;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Entry");
	/* Change state of the pxLeg to Call_Leg_TX and peer to Tx_status_Wait*/
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);
	/* Do a IFX_CMGR_GetCallLeg and save the address in pxLeg->pxChild*/
	IFX_CMGR_GetCallLeg(unCnxtIdx,&pxLeg->pxChild);
	pxChild = pxLeg->pxChild;	
	/* Populate the Leg Owner Info of the target party in the Child Call leg*/
	eRet = IFX_CMGR_PrepareChildLegForTx(pxLeg, pxChild, pxTarget);
	if(IFX_FAILURE == eRet)
	{
		/* If the status is FAILURE, then reject the Transfer - Clear Child Call*/
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		*peReason = IFX_USER_NOT_FOUND;
		IFX_CMGR_ActOnChildFailureInTxCnxtCh(pxChild, pxParent, pxPeer);
		IFX_CMGR_PrintExitInfo(IFX_SUCCESS, __FUNCTION__, __LINE__);
		return IFX_SUCCESS;		  
	}
	/* Populate the Call params for the Target Party*/
	memset(&xPar, 0, sizeof(x_IFX_CMGR_CallParams));
	xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
	/*Make Pointer from Child to parent */
	pxChild->pxParent = pxLeg;
	
	/* Change state of the new call leg to RRP(Invite) */
	IFX_CMGR_ChangeState(pxChild,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
	
	/* InvokeCallIncoming on the Target party*/
	if((IFX_CMGR_TYPE_VOIP == ePeerType)&&(IFX_CMGR_TYPE_EXTN == eTargetType))
		eRet = IFX_CMGR_InvokeCallIncVoipExtn(pxPeer, pxChild, 
							 								&xPar, &eStatus, peReason);
	else 
	if((IFX_CMGR_TYPE_VOIP == ePeerType)&&(IFX_CMGR_TYPE_FXO == eTargetType))
		eRet = IFX_CMGR_InvokeCallIncVoipFxo(pxPeer, pxChild, 
							 								&xPar, &eStatus, peReason);
	/* Check the return status*/
	if((IFX_CMGR_STATUS_FAIL == eStatus) || (IFX_FAILURE == eRet))
	{
		/* If the status is FAILURE, then reject the Transfer - Clear Child Call*/
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		IFX_CMGR_ActOnChildFailureInTxCnxtCh(pxChild, pxParent, pxPeer);
	}
	else
	if(IFX_CMGR_STATUS_PENDING == eStatus)
	{
		if(*peReason == IFX_ENDPOINT_RINGING)
			*peStatus = IFX_CMGR_TRANSFER_ACCEPTED;
		else
			*peStatus = IFX_CMGR_TRANSFER_PENDING;
	}
	else
	{
		/* Status is SUCCESS as the Transfer is done. Return API with status 
		 * answered. Invoke MOVE RESOURCE API to move the coder from Parent
		 * to the Child. Invoke Remote Call Release on the  
		 * Parent. Set the Parent pointer in the Child to NULL. Clear the 
		 * Parent. Invoke Resume on the Peer Leg.*/
		*peStatus = IFX_CMGR_TRANSFER_ANSWERED;
		/*TO DO -Invoke GetMediaParams on the Child to get media -DECT*/

		eRet = IFX_CMGR_MoveMediaResource(pxCnxt->iResId, 
							 pxLeg->xLegOwnerInfo.szEndptId, 
							 pxChild->xLegOwnerInfo.szEndptId, peReason);	
		if(eRet == IFX_FAILURE)
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet; /*DEBUG*/
		}
		eRet = IFX_CMGR_InvokeRemoteCallRelease(pxParent,
							 					IFX_TRANSFER_SUCCESS,NULL);
		IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxParent, pxChild);
		pxChild->pxParent = NULL;
		pxChild->pxPeer = pxPeer;
		pxPeer->pxPeer = pxChild;
		IFX_CMGR_DeAllocCallLeg(pxParent);
		
		/* Invoke Call Resume on the Child - Change state of Child to HELD*/
		IFX_CMGR_ChangeState(pxChild, IFX_CMGR_STATE_HELD, 0);
		eRet = IFX_CMGR_ResumeCallIntVoip(pxChild, &eStatus, peReason);	
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;		  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_BtxIntIntVoip
 *  Description     : Function handles Internal-Internal-Voip type of Blind Tx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_BtxIntIntVoip
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,
				OUT e_IFX_ReasonCode *peReason
			)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallLeg* pxChild = pxLeg->pxChild;
	x_IFX_CMGR_CallLeg* pxParent = pxLeg;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg->pxCurrCnxt;
	uint16 unCnxtIdx = IFX_CMGR_FindCallCnxtIdx(pxCnxt);
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	x_IFX_CMGR_CallParams xPar;
	x_IFX_CMGR_VoipLegInfo* pxVoipLegInfo = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	if (pxPeer == NULL)
		return IFX_FAILURE;
	IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);

	/* Do a IFX_CMGR_GetCallLeg and save the address in pxLeg->pxChild*/
	IFX_CMGR_GetCallLeg(unCnxtIdx,&pxLeg->pxChild);
	pxChild = pxLeg->pxChild;
	/* Populate the Leg Owner Info of the target party in the Child Call leg*/

	/*Bug Fix:SMS01391071 - If both endpoints are not associated with VL then transfer should fail*/
	if((eRet=IFX_CMGR_PrepareChildLegForTx(pxParent, pxChild, pxTarget))
			== IFX_FAILURE) {
		*peStatus = IFX_CMGR_TRANSFER_FAILED;	
		IFX_CMGR_DoTxFailCommonActions(pxParent,pxChild,pxPeer,pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}

	/* Get Additional Resource for the new Call*/
	eRet = IFX_CMGR_GetMediaResIntVoip(&pxCnxt->iResIdForTransfer, pxPeer, 
						 							pxChild, &eStatus, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_TRANSFER_FAILED;	
		IFX_CMGR_DoTxFailCommonActions(pxParent,pxChild,pxPeer,pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; 
	}

	pxVoipLegInfo = &pxChild->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	
	/*Check the PEER party to see if the Currently running codec is a WB codec or not.
	 If its a WB codec then re-order the codecs in the CHILD leg to bring WB on the
	 top.*/
	if(IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType)
	{
			/*Re-Order the codecs in the Child leg*/
			IFX_CMGR_ReOrderCodecsForWB(
						&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo,
						&pxVoipLegInfo->xOfferedCodecInfo, IFX_FALSE);	
	}

	/* Populate the Call params for the Target Party*/
	memset(&xPar, 0, sizeof(x_IFX_CMGR_CallParams));
	xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
	IFX_CMGR_MakeCallParamsIntVoip(pxChild, &pxPeer->xCallParams,&xPar);
			  
	/*Make Pointer from Child to parent */
	pxChild->pxParent = pxLeg;
	pxParent = pxLeg;
	/* Change state of the new call leg to RRP(Invite) */
	IFX_CMGR_ChangeState(pxChild,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
	
	/* InvokeCallIncoming on the Target party*/
	eRet = IFX_CMGR_InvokeCallIncIntVoip(pxPeer, pxChild, 
							 								&xPar, &eStatus, peReason);
	if((IFX_FAILURE == eRet) ||
	(IFX_CMGR_STATUS_FAIL == eStatus))
	{
		/* If the status is FAILURE, then reject the Transfer - Clear Child Call*/
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
	}
	else
	{
		/*Reset flag, so that MediaCfg is invoked on this leg*/
		IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;		  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IgnoreTx
 *  Description     : N.A.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_IgnoreTx
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,
				OUT e_IFX_ReasonCode *peReason
			)
{
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	return IFX_SUCCESS;
}
			
/*****************************************************************************
 *  Function Name   : IFX_CMGR_BtxIntIntInt
 *  Description     : Function handles Internal-Internal-Internal type of Blind Tx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_BtxIntIntInt
			(
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,
				OUT e_IFX_ReasonCode *peReason
			)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallLeg* pxChild;
	x_IFX_CMGR_CallLeg* pxParent = pxLeg;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg->pxCurrCnxt;
	uint16 unCnxtIdx = IFX_CMGR_FindCallCnxtIdx(pxCnxt);
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	x_IFX_CMGR_CallParams xPar = {0};
	e_IFX_CMGR_CallType ePeerType = IFX_CMGR_TYPE_EXTN;
	e_IFX_CMGR_CallType eTargetType = pxTarget->eAddressType;
	x_IFX_CMGR_CodecParams* pxNewParCodecs, *pxCodecs = NULL, *pxCod2 = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	/* Then change state of pxLeg to Call_Leg_Tx*/
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
	if (pxPeer == NULL)
		return IFX_FAILURE;
	ePeerType = pxPeer->xLegOwnerInfo.eOwnerType;
	IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);
	
	/* Do a IFX_CMGR_GetCallLeg and save the address in pxLeg->pxChild*/
	IFX_CMGR_GetCallLeg(unCnxtIdx,&pxLeg->pxChild);
	pxChild = pxLeg->pxChild;
	/* Populate the Leg Owner Info of the target party in the Child Call leg*/
	eRet = IFX_CMGR_PrepareChildLegForTx(pxParent, pxChild, pxTarget);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		*peReason = IFX_USER_NOT_FOUND;
		IFX_CMGR_DoTxFailCommonActions(pxParent,pxChild,pxPeer,pxCnxt);
		IFX_CMGR_PrintExitInfo(IFX_SUCCESS, __FUNCTION__, __LINE__);
		return IFX_SUCCESS; /*DEBUG*/
	}
	/* Get Additional Resource for the new Call*/
	eRet = IFX_CMGR_GetMediaResIntInt(&pxCnxt->iResIdForTransfer, pxPeer, 
						 							pxChild, &eStatus, peReason);
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		*peReason = IFX_NO_RESOURCE;
		IFX_CMGR_DoTxFailCommonActions(pxParent,pxChild,pxPeer,pxCnxt);
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /*DEBUG*/
	}
	/*Make Pointer from Child to parent */
	pxChild->pxParent = pxLeg;
	pxParent = pxLeg;

	if((IFX_CMGR_TYPE_EXTN == pxChild->xLegOwnerInfo.eOwnerType) && 
	(pxChild->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo.unNoOfCodecs))
	{
		pxCodecs = 
			&pxChild->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xOfferedCodecInfo;
	}
	/*Assign codec pointer if the OUT party is EXTN with codecs*/
	if((IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType) && 
		(pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo.unNoOfCodecs))
	{
		pxCod2 = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo; 
	}
	/*Re-Order codecs on the IN EXTN side*/	
	if(IFX_CMGR_TYPE_EXTN == pxChild->xLegOwnerInfo.eOwnerType)
	{
		IFX_CMGR_ReOrderCodecsForWB(pxCod2,pxCodecs,IFX_FALSE);
	}
	/* Populate the Call params for the Target Party*/
	xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
	/* Populate the xPar with the codecs to be offered in the Call Leg*/
	if(pxCodecs) 
	{
		pxNewParCodecs=&xPar.uxCallParams.xExtnParams.xExtnMediaParams.xCodecParams;
		memcpy(pxNewParCodecs,pxCodecs,sizeof(x_IFX_CMGR_CodecParams));
	}

	/* Change state of the new call leg to RRP(Invite) */
	IFX_CMGR_ChangeState(pxChild,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
	
	/* InvokeCallIncoming on the Target party*/
	if((IFX_CMGR_TYPE_FXO == ePeerType)&&(IFX_CMGR_TYPE_EXTN == eTargetType))
		eRet = IFX_CMGR_InvokeCallIncFxoExtn(pxPeer, pxChild, 
							 								&xPar, &eStatus, peReason);
	else 
	if((IFX_CMGR_TYPE_EXTN == ePeerType)&&(IFX_CMGR_TYPE_EXTN == eTargetType))
		eRet = IFX_CMGR_InvokeCallIncExtnExtn(pxPeer, pxChild, 
							 								&xPar, &eStatus, peReason);
	else 
	if((IFX_CMGR_TYPE_EXTN == ePeerType)&&(IFX_CMGR_TYPE_FXO == eTargetType))
		eRet = IFX_CMGR_InvokeCallIncExtnFxo(pxPeer, pxChild, 
							 								&xPar, &eStatus, peReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;/* DEBUG*/
	}
	
	/* Check the return status*/
	if(IFX_CMGR_STATUS_FAIL == eStatus)
	{
		/* If the status is FAILURE, then reject the Transfer - Clear Child Call*/
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
	}
	else
	if(IFX_CMGR_STATUS_PENDING == eStatus)
	{
		if(*peReason == IFX_ENDPOINT_RINGING)
			*peStatus = IFX_CMGR_TRANSFER_ACCEPTED;
		else
			*peStatus = IFX_CMGR_TRANSFER_PENDING;
	}
	else
	{
		/* If the status is SUCCESS, then change Transfer status to transfer 
		 * done. Invoke Remote Call Release on pxLeg. Change state of the pxChild
		 * to the CONV state. Invoke XConnect. Free Resource for pxLeg and clear
		 * the leg. Make pointer to the pxCnxt->ppxCallLegs to the pxChild. Clear 
		 * the pxParent pointer in the new Call Leg. Set the peer pointers.
		 */
		*peStatus = IFX_CMGR_TRANSFER_ANSWERED;
		IFX_CMGR_ChangeState(pxChild, IFX_CMGR_STATE_CONV, 0);
		IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
		eRet = IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TRANSFER_SUCCESS,NULL);
		if(IFX_CMGR_OUT == pxLeg->eDirection)
			IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxLeg->xLegOwnerInfo.szEndptId, pxPeer->xLegOwnerInfo.szEndptId,
				peReason);
		else
			IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxPeer->xLegOwnerInfo.szEndptId,
				pxLeg->xLegOwnerInfo.szEndptId, 
				peReason);
				  
		pxCnxt->iResId = pxCnxt->iResIdForTransfer;
		pxCnxt->iResIdForTransfer = 0;
		IFX_CMGR_ShiftCallLegPtr(pxCnxt, pxLeg, pxChild);
		eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_TRUE, IFX_TRUE,peReason);
		IFX_CMGR_DeAllocCallLeg(pxLeg);
		pxChild->pxParent = NULL;
		pxChild->pxPeer = pxPeer;
		pxPeer->pxPeer = pxChild;
		pxCnxt->eTypeOfTransfer = 0;
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;		  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_IsTxTargetValid
 *  Description     : Function detemines if the Tarnsfer target in BTX is a 
 											valid address.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_TRUE or IFX_FALSE 
 *  Notes           :
 ****************************************************************************/
STATIC boolean IFX_CMGR_IsTxTargetValid(
				IN e_IFX_CMGR_TypeOfTransfer eType,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN x_IFX_CMGR_CallLeg* pxInitLeg,
				IN x_IFX_CMGR_CallLeg* pxPeerLeg,
				IN uint32 uiRepCallId
				)
{
	boolean bRet = IFX_TRUE;
	x_IFX_CMGR_CallLeg* pxAtxLeg = NULL;
	x_IFX_CMGR_CallLeg* pxAtxPeer = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	switch(eType)
	{
		case IFX_CMGR_BTX_INT_VOIP_VOIP: 
		{
			if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acUserName,
				pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acUserName))
			{
				if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acCalledAddr,
						pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acCalledAddr))
				{	
					bRet = IFX_FALSE;	
				}
			}	
			if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acUserName,
				pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acUserName))
			{
				if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acCalledAddr,
					pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acCalledAddr))
				{					
					bRet = IFX_FALSE;
				}
			}
		}
		break;
		case IFX_CMGR_BTX_INT_INT_VOIP:
		{
			bRet = IFX_TRUE;
		}
		break;
		case IFX_CMGR_BTX_INT_VOIP_INT:
		{
			/* Check if the party being requested is the same as the current party*/
			if(IFX_CMGR_TYPE_EXTN == pxTarget->eAddressType)
			{
				if(!strcasecmp(pxInitLeg->xLegOwnerInfo.szEndptId, 
														pxTarget->uxAddressInfo.szEndptId))
					bRet = IFX_FALSE;
			}else
			if(IFX_CMGR_TYPE_FXO == pxTarget->eAddressType)
			{
				if(!strcasecmp(pxInitLeg->xLegOwnerInfo.szEndptId, 
														pxTarget->uxAddressInfo.xFxoInfo.szFxoLineId))
					bRet = IFX_FALSE;
			}
		}
		break;
		
		case IFX_CMGR_BTX_INT_INT_INT:
		{
			if(IFX_CMGR_TYPE_EXTN == pxTarget->eAddressType)
			{
				if(!strcasecmp(pxInitLeg->xLegOwnerInfo.szEndptId, 
														pxTarget->uxAddressInfo.szEndptId))
				{
					bRet = IFX_FALSE;
				}
				if(!strcasecmp(pxPeerLeg->xLegOwnerInfo.szEndptId, 
															pxTarget->uxAddressInfo.szEndptId))
				{
					bRet = IFX_FALSE;
				}
			}else
			if(IFX_CMGR_TYPE_FXO == pxTarget->eAddressType)
			{
				if(!strcasecmp(pxInitLeg->xLegOwnerInfo.szEndptId, 
														pxTarget->uxAddressInfo.xFxoInfo.szFxoLineId))
				{
					bRet = IFX_FALSE;
				}
				if(!strcasecmp(pxPeerLeg->xLegOwnerInfo.szEndptId, 
															pxTarget->uxAddressInfo.xFxoInfo.szFxoLineId))
				{
					bRet = IFX_FALSE;
				}
			}
		}
		break;
		case IFX_CMGR_ATX_INT_VOIP_INT:
		case IFX_CMGR_ATX_INT_INT_VOIP:
		case IFX_CMGR_ATX_INT_INT_INT:
		{
			bRet = IFX_TRUE;
		}
		break;	
		case IFX_CMGR_ATX_VOIP_INT_VOIP:
		case IFX_CMGR_BTX_VOIP_INT_VOIP:
		{	
			if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acUserName,
				pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acUserName))
			{
				if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acCalledAddr,
						pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acCalledAddr))
				{	
					bRet = IFX_FALSE;	
				}
			}	
			if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acUserName,
				pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acUserName))
			{
				if(!strcasecmp(pxTarget->uxAddressInfo.xVoipAddr.acCalledAddr,
					pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acCalledAddr))
				{					
					bRet = IFX_FALSE;
				}
			}
		}
		break;
		case IFX_CMGR_ATX_INT_VOIP_VOIP:
		{
			pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
			if(!pxAtxLeg)
			{
				return IFX_FALSE;
			}
			pxAtxPeer = pxAtxLeg->pxPeer;
			/*Check if the B party and the C party are the same.*/
			if(!strcasecmp(
					pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acUserName,
						pxAtxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acUserName))
			{
				if(!strcasecmp(
					pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acCalledAddr,
					pxAtxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acCalledAddr))
				{					
					bRet = IFX_FALSE;
				}
			}
			/*Check if the C/B party is the same as the A party's VL address.*/
			if(!strcasecmp(
				pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acUserName,
					pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acUserName))
			{
				if(!strcasecmp(
					pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acCalledAddr,
					pxPeerLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acCalledAddr))
				{					
					bRet = IFX_FALSE;
				}
			}
			if(!strcasecmp(
				pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acUserName,
					pxAtxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acUserName))
			{
				if(!strcasecmp(
					pxInitLeg->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr.acCalledAddr,
					pxAtxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr.acCalledAddr))
				{					
					bRet = IFX_FALSE;
				}
			}
		}	
		break;
		case IFX_CMGR_ATX_MAX_TYPE: 
		case IFX_CMGR_BTX_MAX_TYPE:	
		default:
			bRet = IFX_FALSE;
		break;
	}
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Exit");
	return bRet;		  
}


/*!
	\brief This API is invoked by an Agent (say DECT/FXS/NA) when it needs  
	to transfer a call to the mentioned endpoint/address. The TargetAddress
	may contain a PSTN number if the call is being transferred to a PSTN number
	or it may contain the complete VoIP address.
	\param[in]	uiCallId is the Call-id of the call to transfer
	\param[in]	pxTargetAddr is the address and type of the target party. It could
					be a VoIP/PSTN/Extension address.
 	\param[out]	peTransferStatus contains an enum regarding if the Transfer was 
					Accepted or Not
 	\param[out]	peRespCode contains a Rsp code in case the transfer Req was
					not accepted
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_BlindTx(
					 	IN uint32 uiCallId,
						/*The Target party's address*/
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						/*Agent may get Accepted/Rejected*/ 
						OUT e_IFX_TransferStatus* peStatus,
						/*Agent may get Reason for Rejection*/ 
						OUT e_IFX_ReasonCode *peReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg?pxLeg->pxCurrCnxt:NULL;
	
	pfn_IFX_CMGR_BTx pfnaBlindTx[IFX_CMGR_BTX_MAX_TYPE] = 
										{  
											IFX_CMGR_IgnoreTx,
											IFX_CMGR_BtxIntVoipVoip,
											IFX_CMGR_BtxIntIntInt,
											IFX_CMGR_BtxIntVoipInt,
											IFX_CMGR_BtxIntIntVoip,
											IFX_CMGR_BtxVoipIntVoip
										};

	*peStatus = IFX_CMGR_TRANSFER_PENDING;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");
	if(!pxLeg || !pxPeer || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/*If transfer is already in progress then fail the API*/	
	if(pxCnxt->eTypeOfTransfer)
	{
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		return eRet;
	}

	/*Analyze the type of transfer*/
	pxCnxt->eTypeOfTransfer = IFX_CMGR_FindBtxType(pxLeg, pxPeer,
						 												pxTargetAddr);
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "eTxType", pxCnxt->eTypeOfTransfer);
	/* Check the Type of the remote party*/
	if(IFX_TRUE != IFX_CMGR_IsTxTargetValid(pxCnxt->eTypeOfTransfer,
												 			pxTargetAddr,pxLeg, pxPeer,0))
	{
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		*peReason = IFX_TRANSFER_FAIL;
		pxCnxt->eTypeOfTransfer = 0;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
		
	/*Check if transfer is possible as per the states etc. */	
	*peStatus = IFX_CMGR_IsTransferAcceptable(pxLeg, 
						 						pxPeer,0, pxCnxt->eTypeOfTransfer);	
	if(*peStatus != IFX_CMGR_TRANSFER_PENDING)
	{
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		*peReason = IFX_TRANSFER_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	eRet = pfnaBlindTx[pxCnxt->eTypeOfTransfer](pxLeg, pxTargetAddr,peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		//IFX_CMGR_DeAllocCallCnxt(pxCnxt);
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;	  
}


/*!
	\brief This API is invoked by an Agent (say DECT/FXS) when it needs 
			 wants to allow a call to be transferred. This API is used for 
			 accepting a REFER as well as on reception of a NOTIFY by 
			 the NA agent.
	\param[in]	uiCallId is the Call-id of the call in transfer i
	\param[in]	eTransferStatus is used for accepting/rejecting a 
					Transfer Req (Refer) before the transfer starts. 
					Its called by the B Party. 
					It is also used for notifying the CMGR about about reception 
					of Notify 180/Notify 200 events. - When called by B Side 
					in middle of transfer.
	\param[in] eRespCode is the reason for a possible tranfer Req rejection.
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_BlindTxStatus(
					 	IN uint32 uiCallId,
						IN e_IFX_TransferStatus eTxStatus,
						IN e_IFX_ReasonCode eRespCode
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;	  
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer= IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallLeg* pxChild= pxPeer?pxPeer->pxChild:NULL;
	x_IFX_CMGR_CallLeg* pxParent = pxPeer;
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg?pxLeg->pxCurrCnxt:NULL;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	e_IFX_ReasonCode eReason = 0;
	x_IFX_CMGR_CallParams xPar;
	x_IFX_CMGR_CodecParams *pxExtnNegCodecs = NULL, *pxVoipOffCodecs = NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"ENTRY");
	if(!pxLeg || !pxPeer || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/*Check if the state is RRP (BTx) */
	if(((IFX_CMGR_RECV_RESP_PENDING == pxLeg->eCurrState) && 
								(IFX_CMGR_RESP_PEND_BTX == pxLeg->eRespPendEvt))||
									(IFX_CMGR_STATE_CALL_LEG_TX == pxLeg->eCurrState))
	{
		if(IFX_CMGR_BTX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer)
		{
			if(IFX_CMGR_TRANSFER_ACCEPTED == eTxStatus)
			{
				eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
														eTxStatus,eRespCode); 	
				/*Get Additional Media Resource for this call*/
				eRet = IFX_CMGR_GetAddMediaRes(pxCnxt->iResId, pxLeg, pxChild, 
								 &pxCnxt->iResIdForTransfer, &eStatus, &eReason);
				if(IFX_FAILURE == eRet)
					return eRet;	/*DEBUG*/
				/*Before Making the Child's Call Params, Re-Order the codecs on the both
		 		ends in case the call is an EXTN-VOIP call where the EXTN has codecs.*/
				pxVoipOffCodecs = 
					&pxChild->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xOfferedCodecInfo;
				pxExtnNegCodecs = 
					&pxLeg->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;	
				if(IFX_CMGR_TYPE_EXTN == pxLeg->xLegOwnerInfo.eOwnerType)
				{
					/*Re-order codecs for WB/NB*/
					IFX_CMGR_ReOrderCodecsForWB(pxExtnNegCodecs,
																	pxVoipOffCodecs,IFX_FALSE);	
				}
				/* Populate the Call params for the Target Party*/
				memset(&xPar, 0, sizeof(x_IFX_CMGR_CallParams));
				xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
				/*Copy Codecs from the Call Leg into the Params*/	
				IFX_CMGR_MakeCallParamsIntVoip(pxChild,NULL,&xPar);
				IFX_CMGR_InvokeCallIncIntVoip(pxLeg, pxChild, &xPar, &eStatus, &eReason);
				if(IFX_CMGR_STATUS_FAIL == eStatus)
				{
					eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
											IFX_CMGR_TRANSFER_FAILED,eRespCode); 	
					IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxLeg);
				}
				else
				{
					/*Status is pending - change state of the Parent and peer leg*/
					IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_CALL_LEG_TX, 0);
					IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);
					/*Reset flag, so that MediaCfg is invoked on this leg*/
					IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE);
					eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
											IFX_CMGR_TRANSFER_ACCEPTED,eRespCode); 	
				}
			}else
			if(IFX_CMGR_TRANSFER_REJECTED == eTxStatus)
			{
				eRet = IFX_CMGR_InvokeBtxStatus(pxParent,
										eTxStatus,eRespCode); 	
				/*Change State of pxLeg to Previous state*/
				IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
				IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
				pxParent->pxChild = NULL;
				IFX_CMGR_FreeMediaResource(pxCnxt->iResIdForTransfer,
					pxPeer->xLegOwnerInfo.szEndptId, 
					pxChild->xLegOwnerInfo.szEndptId, &eReason);	
				IFX_CMGR_DeAllocCallLeg(pxChild);
				pxCnxt->eTypeOfTransfer = 0;
			}
		}else
		if(IFX_CMGR_BTX_INT_VOIP_VOIP == pxCnxt->eTypeOfTransfer)
		{
			/*Inform pxPeer about the Status of BTX*/
			IFX_CMGR_InvokeBtxStatus(pxPeer,eTxStatus,eRespCode); 		
			if((IFX_CMGR_TRANSFER_REJECTED == eTxStatus)||
				(IFX_CMGR_TRANSFER_FAILED == eTxStatus))
			{	/* Change states back to previous ones*/
				IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
				IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
				pxCnxt->eTypeOfTransfer = 0;
				if(IFX_TRUE == pxLeg->bByeRcvd)
				{
					/* If bye has alredy been received then clear the call's 
					 * remaining leg. Clear the Context*/
					IFX_CMGR_InvokeRemoteCallRelease(pxPeer, IFX_TRANSFER_FAIL, NULL);
					IFX_CMGR_DeAllocCallCnxt(pxCnxt);
				}
			}else
			if((IFX_CMGR_TRANSFER_ACCEPTED == eTxStatus)||
					(IFX_CMGR_TRANSFER_RINGING == eTxStatus)||
					(IFX_CMGR_TRANSFER_PROCEEDING == eTxStatus))
			{	/*Change states to reflect that the TX has been accepted*/
				IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
				IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_CALL_LEG_TX, 0);
			}else
			if(IFX_CMGR_TRANSFER_ANSWERED == eTxStatus)		
			{	/* Invoke RemoteCallRelease on both the pxPeer and pxLeg*/
				IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TRANSFER_SUCCESS,NULL);
				if(IFX_FALSE == pxLeg->bByeRcvd)
					IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TERMINATED,NULL);
				
				IFX_CMGR_InvokeRemoteCallRelease(pxPeer,IFX_TRANSFER_SUCCESS,NULL);
				/*Invoke Stop Rtp Session*/
				IFX_CMGR_StopMediaSession(pxLeg);
				/* DeAllocate the Call Context*/
				IFX_CMGR_DeAllocCallCnxt(pxCnxt);
			}
		}
	}
	else
	{
		/* The API has been invoked in wrong state - return with failure*/		  
		eRet = IFX_FAILURE;
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AtxVoipIntVoip
 *  Description     : Function handles Voip-Internal-Voip type of ATx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AtxVoipIntVoip
		  (
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiRepCallId,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallContext* pxCnxt;
	x_IFX_CMGR_CallLeg *pxPeer,*pxParent,*pxChild;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;
	uint16 unCnxtIdx = 0;
	x_IFX_CMGR_CallParams xPar;
	x_IFX_CMGR_CodecParams *pxExtnNegCodecs = NULL, *pxVoipOffCodecs = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg)
			return IFX_FAILURE;
	/*Get Basic Pointers*/
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxParent = pxLeg;
	pxChild = pxLeg->pxChild;
	/*Get Context Index*/
	unCnxtIdx = IFX_CMGR_FindCallCnxtIdx(pxCnxt);
	/* Change state of the pxLeg to SRP (Atx).*/
	IFX_CMGR_ChangeState(pxLeg,
			IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_ATX);
	/* Change state of the peer leg to RRP (Atx)*/
	IFX_CMGR_ChangeState(pxPeer,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_ATX);

	/*Prepare the child call leg*/
	IFX_CMGR_GetCallLeg(unCnxtIdx,&pxParent->pxChild);
	pxChild = pxLeg->pxChild;
	IFX_CMGR_PrepareChildLegForTx(pxParent, pxChild, pxTarget);
	pxChild->pxParent = pxParent;
	
	/* Ask the peer party if it wants to allow transfer of the call?*/
	if((eRet = IFX_CMGR_InvokeAtxReq(pxPeer, NULL, 
							pxTarget, peStatus, peReason)) == IFX_FAILURE)
	{
		return eRet; /*DEBUG*/
	}
	/* Check the return status of the Tx Req*/
	if(IFX_CMGR_TRANSFER_ACCEPTED == *peStatus)
	{
		/*Get Additional Media Resource for this call*/
		eRet = IFX_CMGR_GetAddMediaRes(pxCnxt->iResId, pxPeer, pxChild, 
							 &pxCnxt->iResIdForTransfer, &eStatus, peReason);
		if(IFX_FAILURE == eRet)
			return eRet;	/*DEBUG*/
		
		/*Before Making the Child's Call Params, Re-Order the codecs on the both
		 ends in case the call is an EXTN-VOIP call where the EXTN has codecs.*/
		pxVoipOffCodecs = 
			&pxChild->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xOfferedCodecInfo;
		if(IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType)
		{
			pxExtnNegCodecs = 
				&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;	
		}
		/*Re-order codecs for WB/NB*/
		IFX_CMGR_ReOrderCodecsForWB(pxExtnNegCodecs,pxVoipOffCodecs,IFX_FALSE);	
		/* Populate the Call params for the Target Party*/
		memset(&xPar, 0, sizeof(x_IFX_CMGR_CallParams));
		xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
		xPar.uxCallParams.xVoipParams.uiReplacesCallId = uiRepCallId; 
		/*Copy Codecs from the Call Leg into the Params*/	
		IFX_CMGR_MakeCallParamsIntVoip(pxChild,NULL,&xPar);
			  
		IFX_CMGR_ChangeState(pxChild,
				IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
		IFX_CMGR_InvokeCallIncIntVoip(pxPeer, pxChild, &xPar, &eStatus, peReason);
		if(IFX_CMGR_STATUS_FAIL == eStatus)
		{
			*peStatus = IFX_CMGR_TRANSFER_FAILED;
			IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
		}
		else
		{
			/*Status is pending - change state of the Parent and peer leg*/
			IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_CALL_LEG_TX, 0);
			IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);
			IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE);
		}
	}else
	if(IFX_CMGR_TRANSFER_REJECTED == *peStatus)
	{
		/*Change State of pxLeg to Previous state*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
		pxParent->pxChild = NULL;
		IFX_CMGR_FreeMediaResource(pxCnxt->iResIdForTransfer,
		pxPeer->xLegOwnerInfo.szEndptId, pxChild->xLegOwnerInfo.szEndptId, 
		peReason);	
		IFX_CMGR_DeAllocCallLeg(pxChild);
		return eRet;		  
	}
	
	/* Save the replaces call id for further usage with-in the call leg*/
	pxLeg->uiRepCallId = uiRepCallId;
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;		  
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AtxIntVoipVoip
 *  Description     : Function handles Internal-Voip-Voip type of ATx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AtxIntVoipVoip
		  (
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiRepCallId,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	x_IFX_CMGR_CallLeg* pxPeer;
	x_IFX_CMGR_CallContext *pxCnxt, *pxAtxCnxt;
	e_IFX_CMGR_Status eStatus = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	/*Sanity Check*/
	if(!pxLeg || !pxAtxLeg)
	{
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	/*Set basic pointers*/
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	pxAtxCnxt = IFX_CMGR_GetCurrCnxt(pxAtxLeg);

	/* Set pxPeerAtxCnxt pointers*/
	pxAtxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxCnxt;
	pxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxAtxCnxt;

	/*Change state of the pxLeg and pxPeer to SRP and RRP (ATX)*/
	IFX_CMGR_ChangeState(pxLeg, 
						 IFX_CMGR_SEND_RESP_PENDING, IFX_CMGR_RESP_PEND_ATX);
	IFX_CMGR_ChangeState(pxPeer, 
						 IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_ATX);
	
	/* Set flag indicating the HOLD is for ATX on the peer leg*/
	IFX_CMGR_SET_FLAG(pxAtxCnxt->unFlags, IFX_CMGR_FLAG_CALL_HOLD_FOR_ATX);
		
	/*Send Hold Req to the pxAtxCnxt */	
	eRet = IFX_CMGR_HoldCallIntVoip(pxAtxLeg, &eStatus ,peReason);
	if(IFX_CMGR_STATUS_FAIL == eStatus)
	{
		/* Change states to previous states*/
		IFX_CMGR_ChangeState(pxLeg, pxLeg->ePrevState, 0);
		IFX_CMGR_ChangeState(pxPeer, pxPeer->ePrevState, 0);
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;	
	}
	else
	{
		/* Return API with status pending*/
		*peStatus = IFX_CMGR_TRANSFER_PENDING;		  
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AtxIntVoipInt
 *  Description     : Function handles Internal-Voip-Internal type of ATx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AtxIntVoipInt
		  (
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiRepCallId,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	x_IFX_CMGR_CallLeg* pxPeer;
	x_IFX_CMGR_CallLeg* pxAtxPeer;
	x_IFX_CMGR_CallContext* pxCnxt;
	x_IFX_CMGR_CallContext* pxAtxCnxt;
	e_IFX_CMGR_Status eStatus = 0;
	uint32 uiLegId = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg || !pxAtxLeg)
	{
		return IFX_FAILURE;
	}

	/*Set Basic Pointers*/
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxAtxPeer = IFX_CMGR_GetPeerPtr(pxAtxLeg);
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	pxAtxCnxt = IFX_CMGR_GetCurrCnxt(pxAtxLeg);
	/* Set pxPeerAtxCnxt pointers*/
	pxAtxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxCnxt;
	pxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxAtxCnxt;

	/*Break Connection for Second Call*/
	eRet = IFX_CMGR_XConnect(pxAtxCnxt->iResId,IFX_FALSE, IFX_FALSE, peReason);

	/* Free the resource Id*/
	if(IFX_CMGR_OUT == pxAtxLeg->eDirection)
		eRet = IFX_CMGR_FreeMediaResource(pxAtxCnxt->iResId,
				pxAtxLeg->xLegOwnerInfo.szEndptId, 
				pxAtxPeer->xLegOwnerInfo.szEndptId, 
				peReason);
	else
		eRet = IFX_CMGR_FreeMediaResource(pxAtxCnxt->iResId,
					pxAtxPeer->xLegOwnerInfo.szEndptId, 
					pxAtxLeg->xLegOwnerInfo.szEndptId, 
					peReason);
	pxAtxCnxt->iResId = 0;
	
	/* Move Coder channel from pxLeg to pxAtxPeer*/
	eRet = IFX_CMGR_MoveMediaResource(pxCnxt->iResId, 
							 pxLeg->xLegOwnerInfo.szEndptId, 
							 pxAtxPeer->xLegOwnerInfo.szEndptId, peReason);	
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet; /*DEBUG*/
	}

	/*Save call id of the pxLeg in a temp space*/
	uiLegId = pxLeg->uiCallId;
	/*Invoke pfn Remote Call Release both the intitator legs*/
	IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TRANSFER_SUCCESS,NULL);
	IFX_CMGR_InvokeRemoteCallRelease(pxAtxLeg,IFX_TRANSFER_SUCCESS,NULL);
	/*memset the pxLeg*/
	memset(pxLeg,0,sizeof(x_IFX_CMGR_CallLeg));
	/*Copy all the information of the pxAtxPeer into the pxLeg*/
	memcpy(pxLeg, pxAtxPeer,sizeof(x_IFX_CMGR_CallLeg));
	
	/*Invoke Replace Call ID*/
	eRet=IFX_CMGR_InvokeReplaceCallId(pxLeg, pxLeg->uiCallId, uiLegId);
	pxLeg->uiCallId = uiLegId;	

	/* Set the peer pointers to the each other and also the Cnxt ptr */
	pxLeg->pxCurrCnxt = pxCnxt;
	pxLeg->pxPeer =  pxPeer;
	pxPeer->pxPeer =  pxLeg;
		
	pxAtxCnxt->pxPeerAtxCnxt = NULL;
	
	/* Deallcoate pxAtxCnxt*/
	IFX_CMGR_DeAllocCallCnxt(pxAtxCnxt);

	/* Set flag to indicate that the resume Rsp should not be 
	 * propogated back to the pxLeg*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags, IFX_CMGR_FLAG_CALL_RESUME_FOR_ATX);
	
	/* Change pxLeg state to Held*/
	IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_HELD, 0);
	pxCnxt->eTypeOfTransfer = 0;
	
	/*Invoke RemoteCallResume on the VoipLeg*/
	eRet = IFX_CMGR_ResumeCallIntVoip(pxLeg, &eStatus, peReason);	
	
	/* Return API with IFX_CMGR_TRANSFER_ANSWERED*/
	*peStatus = IFX_CMGR_TRANSFER_ANSWERED;
	*peReason = IFX_TRANSFER_SUCCESS;
	pxCnxt->pxPeerAtxCnxt = NULL;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CMGR_AtxIntIntVoip
 *  Description     : Function handles Internal-Internal-Voip type of ATx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AtxIntIntVoip
		  (
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiRepCallId,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	x_IFX_CMGR_CallLeg *pxPeer,*pxAtxPeer;
	x_IFX_CMGR_CallContext *pxCnxt, *pxAtxCnxt;
	uint32 uiAtxLegId = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	if(!pxLeg || !pxAtxLeg)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Set basic Pointers*/
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxAtxPeer = IFX_CMGR_GetPeerPtr(pxAtxLeg);
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	pxAtxCnxt = IFX_CMGR_GetCurrCnxt(pxAtxLeg);
	/* Set pxPeerAtxCnxt pointers*/
	pxAtxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxCnxt;
	pxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxAtxCnxt;

	/*Break Connection for first Call*/
	eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_FALSE, IFX_FALSE, peReason);
	
	/* Free the resource Id*/
	if(IFX_CMGR_OUT == pxLeg->eDirection)
		eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxLeg->xLegOwnerInfo.szEndptId, pxPeer->xLegOwnerInfo.szEndptId, 
				peReason);
	else
		eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
				pxPeer->xLegOwnerInfo.szEndptId, 
				pxLeg->xLegOwnerInfo.szEndptId, 
				peReason);

	pxCnxt->iResId = 0;
	
	/* Move Coder channel from pxAtxLeg to pxPeer*/
	eRet = IFX_CMGR_MoveMediaResource(pxAtxCnxt->iResId, 
							 pxAtxLeg->xLegOwnerInfo.szEndptId, 
							 pxPeer->xLegOwnerInfo.szEndptId, peReason);	
	if(IFX_FAILURE == eRet)
		return eRet; /*DEBUG*/

	/*Save call id of the pxAtxLeg in a temp space*/
	uiAtxLegId = pxAtxLeg->uiCallId;
	/*Invoke pfn Remote Call Release both the intitator legs*/
	IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TRANSFER_SUCCESS,NULL);
	IFX_CMGR_InvokeRemoteCallRelease(pxAtxLeg,IFX_TRANSFER_SUCCESS,NULL);

	/*memset the pxAtxLeg*/
	memset(pxAtxLeg,0,sizeof(x_IFX_CMGR_CallLeg));
	/*Copy all the information of the pxPeer into the pxAtxLeg*/
	memcpy(pxAtxLeg, pxPeer,sizeof(x_IFX_CMGR_CallLeg));

	/*Invoke Replace Call ID*/
	eRet=IFX_CMGR_InvokeReplaceCallId(pxAtxLeg, pxAtxLeg->uiCallId, uiAtxLegId);
	pxAtxLeg->uiCallId = uiAtxLegId;	
	/* Set the peer pointers to the each other and also the Cnxt ptr */
	pxAtxLeg->pxCurrCnxt = pxAtxCnxt;
	pxAtxLeg->pxPeer =  pxAtxPeer;
	pxAtxPeer->pxPeer =  pxAtxLeg;
		
	pxAtxCnxt->pxPeerAtxCnxt = NULL;
	pxAtxCnxt->eTypeOfTransfer = 0;

	/* Set the correct directions*/
	if(IFX_CMGR_OUT == pxAtxPeer->eDirection)
		pxAtxLeg->eDirection = IFX_CMGR_IN;
	else
		pxAtxLeg->eDirection = IFX_CMGR_OUT;

	/*Deallcoate pxCnxt*/
	IFX_CMGR_DeAllocCallCnxt(pxCnxt);

	/* Return API with IFX_CMGR_TRANSFER_ANSWERED*/
	*peStatus = IFX_CMGR_TRANSFER_ANSWERED;
	*peReason = IFX_TRANSFER_SUCCESS;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
	
/*****************************************************************************
 *  Function Name   : IFX_CMGR_AtxIntIntInt
 *  Description     : Function handles Internal-Internal-Internal type of ATx
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_AtxIntIntInt
		  (
				IN x_IFX_CMGR_CallLeg* pxLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiRepCallId,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	x_IFX_CMGR_CallLeg *pxAtxPeer, *pxPeer;
	x_IFX_CMGR_CallContext *pxCnxt, *pxAtxCnxt, *pxNewCnxt;
	e_IFX_CMGR_Status eStatus = 0;
	int32 iNewResId = 0;
	uint32 uiNewLegId = 0;
	uint32 uiNewPeerId = 0;
	e_IFX_CMGR_BasicCallType eBasic = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg || !pxAtxLeg)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Get Context & peer pointers*/
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxAtxPeer = IFX_CMGR_GetPeerPtr(pxAtxLeg);
	pxAtxCnxt = IFX_CMGR_GetCurrCnxt(pxAtxLeg);
	/*Put peer pointers*/
	pxAtxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxCnxt;
	pxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxAtxCnxt;

	/* Find the BCT of the new CNXT*/
	if(IFX_CMGR_TYPE_EXTN == pxAtxPeer->xLegOwnerInfo.eOwnerType)
	{
		if(IFX_CMGR_TYPE_FXO == pxPeer->xLegOwnerInfo.eOwnerType)
			eBasic = IFX_CMGR_BCT_FXO_EXTN;
		else
			eBasic = IFX_CMGR_BCT_EXTN_EXTN;
	}else
	if(IFX_CMGR_TYPE_FXO == pxAtxPeer->xLegOwnerInfo.eOwnerType)
	{
		if(IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType)
			eBasic = IFX_CMGR_BCT_EXTN_FXO;
	}	
	
	/* Break the path of the first call*/
	eRet = IFX_CMGR_XConnect(pxCnxt->iResId,IFX_FALSE, IFX_FALSE, peReason);
	/* Break the path of the second call*/
	eRet = IFX_CMGR_XConnect(pxAtxCnxt->iResId,IFX_FALSE, IFX_FALSE,peReason);
	/* Free Resource ID for both calls*/
	eRet = IFX_CMGR_FreeMediaResource(pxCnxt->iResId,
			pxLeg->xLegOwnerInfo.szEndptId, pxPeer->xLegOwnerInfo.szEndptId, 
				peReason);
	eRet = IFX_CMGR_FreeMediaResource(pxAtxCnxt->iResId,
			pxAtxLeg->xLegOwnerInfo.szEndptId, pxAtxPeer->xLegOwnerInfo.szEndptId, 
				peReason);
	pxCnxt->iResId	 = 0;
	pxAtxCnxt->iResId	 = 0;

	/* Allocate resource id for the new call*/
	eRet = IFX_CMGR_GetMediaResIntInt(&iNewResId, pxPeer,
						 							pxAtxPeer, &eStatus, peReason);
	
	/*Allocate a new call context for the new Internal Call to be formed*/
	if(IFX_CMGR_GetCallCnxtAndLegs(eBasic, IFX_CMGR_MIN_LEGS_PER_CNXT ,
			NULL,	peReason, &pxNewCnxt) == IFX_FAILURE)
		return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
	
	/* Save the new call Ids*/
	uiNewLegId = pxNewCnxt->pxCallLegs[0]->uiCallId;
	uiNewPeerId = pxNewCnxt->pxCallLegs[1]->uiCallId;
	
	/*Copy the pxPeer and the pxAtxPeer into the new locations*/	
	memcpy(pxNewCnxt->pxCallLegs[0], pxPeer, sizeof(x_IFX_CMGR_CallLeg));	
	memcpy(pxNewCnxt->pxCallLegs[1], pxAtxPeer, sizeof(x_IFX_CMGR_CallLeg));	
	
	/*Invoke pfnCallIdRep on the pxPeer and pxAtxPeer*/
	eRet=IFX_CMGR_InvokeReplaceCallId(pxPeer, pxPeer->uiCallId, uiNewLegId);
	eRet=IFX_CMGR_InvokeReplaceCallId(pxAtxPeer,pxAtxPeer->uiCallId,uiNewPeerId);
	/*Save the new call ids in the Legs*/
	pxNewCnxt->pxCallLegs[0]->uiCallId = uiNewLegId;
	pxNewCnxt->pxCallLegs[1]->uiCallId = uiNewPeerId;
#if 1	
	/* Invoke pfnRemCallRelease with tx done on pxLeg and pxAtxLeg*/
	IFX_CMGR_InvokeRemoteCallRelease(pxLeg,IFX_TRANSFER_SUCCESS,NULL);
	IFX_CMGR_InvokeRemoteCallRelease(pxAtxLeg,IFX_TRANSFER_SUCCESS,NULL);
#endif
	/* Free both the old Cnxts*/
	IFX_CMGR_DeAllocCallCnxt(pxCnxt);	
	IFX_CMGR_DeAllocCallCnxt(pxAtxCnxt);

	/*Set peer pointers*/
	 pxNewCnxt->pxCallLegs[0]->pxCurrCnxt = pxNewCnxt;
	 pxNewCnxt->pxCallLegs[1]->pxCurrCnxt = pxNewCnxt;
	 pxNewCnxt->pxCallLegs[0]->pxPeer =  pxNewCnxt->pxCallLegs[1];
	 pxNewCnxt->pxCallLegs[1]->pxPeer =  pxNewCnxt->pxCallLegs[0];
	 pxNewCnxt->pxCallLegs[0]->eDirection = IFX_CMGR_OUT;
	 pxNewCnxt->pxCallLegs[1]->eDirection =  IFX_CMGR_IN;

	/*Invoke XConnect to make new path*/
	pxNewCnxt->iResId = iNewResId;
	eRet = IFX_CMGR_XConnect(pxNewCnxt->iResId,IFX_TRUE, IFX_TRUE,peReason);

	/*Resume the new call*/
	eRet = IFX_CMGR_ResumeCallIntInt(
						 pxNewCnxt->pxCallLegs[0], &eStatus, peReason);

	/* Return API with IFX_CMGR_TRANSFER_ANSWERED*/
	*peStatus = IFX_CMGR_TRANSFER_ANSWERED;
	*peReason = IFX_TRANSFER_SUCCESS;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}




/*!
 	\brief This API is invoked by an Agent (say DECT/FXS/NA) when it needs 
	to transfer a call to the mentioned endpoint/address. The ReplacesCallId 
	contains the call-id to be sent in/received from the Replaces header. 
	The Refer has to be sent on the first call-id. 
	\param[in] uiCallId is the call on which Refer is to be sent/received
	\param[in] uiReplacesCallId is sent/received in the replaces header
	\param[in] pxTargetAddr is used by the NA to inform the CMGR 
				  about the target address
	\param[out] peTransferStatus Tranfer Req accpeted or not.
	\param[out] peRespCode Reason for transfer Req rejection.
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_AttendedTx(
					 	/*Call-id on which Refer is sent or received*/
					 	IN uint32 uiCallId,
					 	/*Call-id which is sent/received to/from the replaces header*/
						IN uint32 uiReplacesCallId,
						/*Only for use by NA - Not required by other agents*/
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						/*Agent may get Accepted/Rejected*/ 
						OUT e_IFX_TransferStatus* peStatus,
						/*Agent may get Reason for Rejection*/ 
						OUT e_IFX_ReasonCode *peReason
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg?pxLeg->pxCurrCnxt:NULL;

	pfn_IFX_CMGR_ATx 
		pfnaAttendedTx[IFX_CMGR_ATX_MAX_TYPE - IFX_CMGR_BTX_MAX_TYPE] = 
										{  
											IFX_CMGR_AtxIntVoipVoip,
											IFX_CMGR_AtxIntIntInt,
											IFX_CMGR_AtxIntVoipInt,
											IFX_CMGR_AtxIntIntVoip,
											IFX_CMGR_AtxVoipIntVoip
										};

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "ENTRY");
	if(!pxLeg || !pxPeer || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	if(!uiReplacesCallId)
	{
		*peStatus = IFX_CMGR_TRANSFER_FAILED;
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	*peStatus = IFX_CMGR_TRANSFER_PENDING;
	/*If transfer is already in progress then fail the API*/	
	if((pxCnxt->eTypeOfTransfer != IFX_CMGR_ATX_MAX_TYPE)&&((pxCnxt->eTypeOfTransfer)||(pxCnxt->pxPeerAtxCnxt)))//Call Reinjection 
	{
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Call Leg is in a conference / peer call leg 
	 * is in a conference, then reject Transfer*/
	if((pxLeg->uiConfReqId)||(pxPeer->uiConfReqId))
	{
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		*peReason = IFX_TRANSFER_FAIL;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/*Analyze the type of transfer*/
	pxCnxt->eTypeOfTransfer = IFX_CMGR_FindAtxType(pxLeg, pxPeer,
													pxTargetAddr, uiReplacesCallId);
	/*Check if transfer is possible as per the states etc. */	
	*peStatus = IFX_CMGR_IsTransferAcceptable(pxLeg, 
						 		pxPeer, uiReplacesCallId, pxCnxt->eTypeOfTransfer);	
	if(*peStatus != IFX_CMGR_TRANSFER_PENDING)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Check the target address to ensure that the TX is possible*/	
	if(IFX_TRUE != IFX_CMGR_IsTxTargetValid(pxCnxt->eTypeOfTransfer,
												 			pxTargetAddr,pxLeg, pxPeer, uiReplacesCallId))
	{
		*peStatus = IFX_CMGR_TRANSFER_REJECTED;
		*peReason = IFX_TRANSFER_FAIL;
		pxCnxt->eTypeOfTransfer = 0;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
					
	eRet = pfnaAttendedTx[pxCnxt->eTypeOfTransfer - IFX_CMGR_ATX_INT_VOIP_VOIP]
					(pxLeg, pxTargetAddr,uiReplacesCallId, peStatus,peReason);
	if(IFX_FAILURE == eRet)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;	/*DEBUG*/
	}

	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;	  
}

/*!
 	\brief	This API is invoked by an Agent (say DECT/FXS) when it needs 
				wants to allow a call to be transferred. This API is used for 
				accepting a REFER as well as on reception of a NOTIFY by an agent.
	\param[in]	uiCallId is the Call-id of the call in transfer
	\param[in]	eTransferStatus is used for accepting/rejecting a 
					Transfer Req (Refer) before the transfer starts. 
					Its called by the B Party. 
					It is also used for notifying the CMGR about about reception 
					of Notify 180/Notify 200 events. - When called by B Side 
					in middle of transfer.
 	\param[in]	eRespCode contains a Rsp code in case the transfer Req was
					not accepted
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_AttendedTxStatus(
					 	/*Call Id for the B side Call that was being transferred*/
					 	IN uint32 uiCallId,
						/* Used for accepting/rejecting a Transfer Req 
						 * (Refer) before the transfer starts -Called by the B Party.
						 * Used for notifying the CMGR about about 
						 * reception of Notify 180/Notify 200 events. - When called 
						 * by B Side in middle of transfer.*/
						IN e_IFX_TransferStatus eStatus,
						/*Reason for a possible Refer Rejection/Failure*/
						IN e_IFX_ReasonCode eRespCode 
					 )	
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxPeer = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetPeerPtr(pxPeer);
	x_IFX_CMGR_CallContext* pxCnxt = pxLeg?pxLeg->pxCurrCnxt:NULL;
	x_IFX_CMGR_CallContext* pxAtxCnxt = pxCnxt?pxCnxt->pxPeerAtxCnxt:NULL;
	x_IFX_CMGR_CallLeg* pxAtxLeg = NULL;
	//x_IFX_CMGR_CallLeg* pxAtxPeer;
	x_IFX_CMGR_CallLeg* pxChild= pxLeg?pxLeg->pxChild:NULL;
	x_IFX_CMGR_CallLeg* pxParent = pxLeg;
	x_IFX_CMGR_CallParams xPar;
	e_IFX_CMGR_Status eStat = 0;
	x_IFX_CMGR_CodecParams *pxExtnNegCodecs = NULL, *pxVoipOffCodecs = NULL;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "ENTRY");
	if(!pxLeg || !pxPeer || !pxCnxt)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	IFX_CMGR_FindSameOwnerLeg(pxAtxCnxt,pxLeg->xLegOwnerInfo.szEndptId,&pxAtxLeg);
	if(!pxAtxLeg)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	//pxAtxPeer = pxAtxLeg->pxPeer;

	if(IFX_CMGR_ATX_INT_VOIP_VOIP == pxCnxt->eTypeOfTransfer) 
	{
		/* Check the status.*/
		if((IFX_CMGR_TRANSFER_REJECTED == eStatus) || 
							 (IFX_CMGR_TRANSFER_FAILED == eStatus))
		{
			IFX_CMGR_ActOnAtxIntVoipVoipFailure(pxLeg,pxPeer,
							 			pxAtxLeg,pxAtxLeg->pxPeer,eStatus);
			
		}else
		if(IFX_CMGR_TRANSFER_ANSWERED == eStatus)		
		{
			IFX_CMGR_ActOnAtxIntVoipVoipSuccess(pxLeg,pxPeer,
							 			pxAtxLeg,pxAtxLeg->pxPeer,eStatus);
		}
	}else
	if(IFX_CMGR_ATX_VOIP_INT_VOIP == pxCnxt->eTypeOfTransfer) 
	{
		if(IFX_CMGR_TRANSFER_ACCEPTED == eStatus)
		{
			/*Get Additional Media Resource for this call*/
			eRet = IFX_CMGR_GetAddMediaRes(pxCnxt->iResId, pxPeer, pxChild, 
								 &pxCnxt->iResIdForTransfer, &eStat, &eRespCode);
			if(IFX_FAILURE == eRet)
				return eRet;	/*DEBUG*/
			/*Before Making the Child's Call Params, Re-Order the codecs on the both
		 	ends in case the call is an EXTN-VOIP call where the EXTN has codecs.*/
			pxVoipOffCodecs = 
				&pxChild->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xOfferedCodecInfo;
			if(IFX_CMGR_TYPE_EXTN == pxPeer->xLegOwnerInfo.eOwnerType)
			{
				pxExtnNegCodecs = 
					&pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xExtnLegInfo.xNegCodecInfo;	
			}
			/*Re-order codecs for WB/NB*/
			IFX_CMGR_ReOrderCodecsForWB(pxExtnNegCodecs,pxVoipOffCodecs,IFX_FALSE);	
			/* Populate the Call params for the Target Party*/
			memset(&xPar, 0, sizeof(x_IFX_CMGR_CallParams));
			xPar.eAgentType = pxChild->xLegOwnerInfo.eOwnerType;
			/* Add the Replaces Call Id*/
			xPar.uxCallParams.xVoipParams.uiReplacesCallId = pxLeg->uiRepCallId; 
			/*Copy Codecs from the Call Leg into the Params*/	
			IFX_CMGR_MakeCallParamsIntVoip(pxChild,NULL,&xPar);
			IFX_CMGR_ChangeState(pxChild,
			IFX_CMGR_RECV_RESP_PENDING, IFX_CMGR_RESP_PEND_INVITE);
			IFX_CMGR_InvokeCallIncIntVoip(pxPeer, pxChild, 
								 &xPar, &eStat, &eRespCode);
			if(IFX_CMGR_STATUS_FAIL != eStat)
			{
				/*Status is pending - change state of the Parent and peer leg*/
				IFX_CMGR_ChangeState(pxPeer, IFX_CMGR_STATE_CALL_LEG_TX, 0);
				IFX_CMGR_ChangeState(pxLeg, IFX_CMGR_STATE_TX_STATUS_WAIT, 0);
				/*Reset flag to indicate that Media Cfg needs to be done*/
				IFX_CMGR_RESET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_CFG_DONE);
				/*Inform the initiator about the status*/
				IFX_CMGR_InvokeAtxStatus(pxLeg, eStatus, 0);
			}
		}else
		if(IFX_CMGR_TRANSFER_REJECTED == eStatus)
		{
			/*Inform the initiator about the status*/
			IFX_CMGR_InvokeAtxStatus(pxLeg,eStatus, 0);
			/*Do common Actions*/
			IFX_CMGR_ActOnChildFailureInTx(pxChild, pxParent, pxPeer);
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/************************* Auto Redial Functions******************************/

/*****************************************************************************
 *  Function Name   : IFX_CMGR_DeActArd
 *  Description     : Function used to deactivate an auto-redial request
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
STATIC e_IFX_Return IFX_CMGR_DeActArd(	IN uint32 uiReqId,
						OUT e_IFX_CMGR_Status* peStatus,
						OUT e_IFX_ReasonCode* peReason)
{	
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);
	x_IFX_CMGR_ReqContext* pxCnxt = IFX_CMGR_GetReqCnxtPtr(uiReqId);
  if(pxLeg == NULL || pxCnxt == NULL){
		return IFX_FAILURE;
	}
	x_IFX_CMGR_AddressInfo xAddrInfo;
		
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Entry");
	memset(&xAddrInfo,0,sizeof(x_IFX_CMGR_AddressInfo));
	xAddrInfo.eAddressType = IFX_CMGR_TYPE_VOIP;
	memcpy(&xAddrInfo.uxAddressInfo.xVoipAddr, 
			&pxCnxt->uxReqCnxt.xArdSubsInfo.xAddr, sizeof(x_IFX_CMGR_VoipAddr));	

	/*Ask NA to Unsubscribe*/
	*peReason = IFX_UNSUBSCRIBE;
	if(pxLeg)
		eRet = IFX_CMGR_InvokeSubnSnd(&xAddrInfo, pxLeg->pxPeer, 
							 IFX_CMGR_SUBS_AUTO_REDIAL, peStatus, peReason );
	/*Set flasg to indicate that Un-subscription was requested.*/
	pxCnxt->uxReqCnxt.xArdSubsInfo.bDeActReq = IFX_TRUE;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	This function is invoked by an Agent (say DECT/FXS) when it needs 
				to enable automatic redial to a remote VoIP party. This function 
				should be invoked only by the FXS/DECT agent for out-going 
				subscription.
	\param[in]	pxTo is Remote Address to whom the previously failed call was 
					made.
	\param[in] pxFrom is the address of the Req intiator (only DECT/FXS)
	\param[in] bActivate flag indicates if the Req is for activation
					or de-activation of the feature.
 	\param[in,out]	puiReqId is the Req ID; For activation it
						will be OUT. For a subsequent de-activate Req
						it will be IN.
	\param[out] peStatus is the status - pending/success/failure
	\param[out]	peRespCode is the Rsp Code in case of failure
	 \param[in] pvPrivateData is the private data for use by the agent
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_ARD_Activate(
					 	IN x_IFX_CMGR_AddressInfo* pxTo,
					 	IN x_IFX_CMGR_AddressInfo* pxFrom,
						IN boolean bActivate,
						IN_OUT uint32* puiReqId,
						OUT e_IFX_CMGR_Status* peStatus,
						OUT e_IFX_ReasonCode* peReason,
						IN void* pvPrivateData
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqContext* pxCnxt;
	const uint8 ucNumReqLegs = 2;
	char8 aszEndptId[ucNumReqLegs][IFX_MAX_ENDPOINTID_LEN] ;
	x_IFX_CMGR_ReqLeg* 	pxOut;
	x_IFX_CMGR_ReqLeg* 	pxIn;
	//uint8 ucLineId = 0;
	//boolean bIsReg;
	uint8 ucValidLegs = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "ENTRY");
	/* Check if its for de-activation - If yes then invoke a different fn*/
	if(IFX_FALSE == bActivate)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "DeActivate ARD");
		if(IFX_FAILURE == IFX_CMGR_IsIdValid(*puiReqId,IFX_FALSE))
		{
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    													         					"Invalid Req Id",*puiReqId);
			IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
		return IFX_CMGR_DeActArd(*puiReqId, peStatus, peReason);
	}
	*puiReqId = 0;	
	*peStatus = IFX_CMGR_STATUS_PENDING;
	*peReason = IFX_MAX_REASON;
	/* Check if the pxTo is a VOIP address anf pxFrom is an EXTN type*/
	if((IFX_CMGR_TYPE_VOIP != pxTo->eAddressType)||
		(IFX_CMGR_TYPE_EXTN != pxFrom->eAddressType))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_MAX_REASON;
		/* return API witth status fail*/
		return eRet;
	}
	
	/* Populate the aszEid*/
	strcpy(aszEndptId[0], pxFrom->uxAddressInfo.szEndptId);
	strcpy(aszEndptId[1], IFX_NA_ENDPT_ID);

	/* Find the VL ID for the EID given*/
#if 0
	eRet = IFX_LMGR_GetEndptDefaultVoipLine(aszEndptId[0], &pxTo->ucLineId, &bIsReg,peReason);
	if((IFX_FAILURE == eRet) || !pxTo->ucLineId)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return IFX_SUCCESS;
	}
#endif	
	/* Call IFX_CMGR_GetReqCnxtAndLegs*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(ucNumReqLegs,
							  				pvPrivateData,&pxCnxt, peReason))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	/* Call IFX_CMGR_PrepReqCnxt*/
	if(IFX_FAILURE == 
		IFX_CMGR_PrepReqCnxt(pxCnxt, aszEndptId, ucNumReqLegs, &ucValidLegs))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}

	/* Populate the Line ID and the ARD info*/	
	pxCnxt->eReqType = IFX_CMGR_REQ_SUBS_AUTO_REDIAL;
	pxCnxt->uxReqCnxt.xArdSubsInfo.unVoipLineId = pxTo->ucLineId;//ucLineId;
	pxCnxt->uxReqCnxt.xArdSubsInfo.bIncReq  = IFX_FALSE;
	memcpy(&pxCnxt->uxReqCnxt.xArdSubsInfo.xAddr, 
				&pxTo->uxAddressInfo.xVoipAddr, sizeof(x_IFX_CMGR_VoipAddr));
	
	/* Set Ptrs*/
	pxOut = IFX_CMGR_GetOutReqLeg(pxCnxt);
	pxIn = IFX_CMGR_GetInReqLeg(pxCnxt);

	/*Set Peer Pointers*/
	pxOut->pxPeer = pxIn;
	pxIn->pxPeer = pxOut;
	
	/* Invoke pfnSubnSnd CB from the IN CL */	
	eRet = IFX_CMGR_InvokeSubnSnd(pxTo, pxIn, 
						 IFX_CMGR_SUBS_AUTO_REDIAL,peStatus, peReason );
	/*Populate the Req ID*/
	*puiReqId = pxOut->uiReqId;
	*peStatus = IFX_CMGR_STATUS_PENDING;
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	The NA will call this function when the subscription is received
				from the remote VoIP party
	\param[in]  eSubsEvt is the subscription event type
	\param[in]  pxFrom is the address of the remote party
	\param[in]  pxTo is the VL for which the subscription is received
 	\param[in,out]	puiExpTime is the Expiry Time accepted by the CMGR
	\param[in]	pvPrivateData is the private data for the use of the NA
	\param[out]	punLineId is the voice line id to be used for this transaction.
 	\param[in,out]	puiReqId is the Req ID. For Un-subscription requests 
							it will be an IN parameter.
	\param[out] peSubsStatus is the subscription Rsp by the destined party
	\param[out]	peRespCode is the Rsp Code in case of failure
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_SubnRcv(
						IN e_IFX_CMGR_SubsEvent eSubsEvt,
					 	IN x_IFX_CMGR_AddressInfo* pxFrom,
					 	IN x_IFX_CMGR_AddressInfo* pxTo,
						IN_OUT uint32* puiExpTime,
						IN void* pvPrivateData,
						OUT uint16 *punLineId,
					 	IN_OUT uint32* puiReqId,
						OUT e_IFX_CMGR_Status* peStatus,
						OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* 	pxOut;
	x_IFX_CMGR_ReqContext* pxCnxt;
	uint8 ucLineId = 0;
	char8 aszEid[IFX_CMGR_MAX_AGENTS][IFX_MAX_ENDPOINTID_LEN];
	boolean bFwdMode = IFX_TRUE;
	uint8 ucSize = IFX_CMGR_MAX_AGENTS;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_PENDING;
	uint8 i=0, j=0, ucValidLegs = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                							"ENTRY");
	*punLineId = 0;
	*peStatus = IFX_CMGR_STATUS_PENDING;
	*peReason = IFX_MAX_REASON;
	/* SUBS needs to be for Auto Redial*/
	if(IFX_CMGR_SUBS_AUTO_REDIAL != eSubsEvt)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	
	/* If the *puiExpTime is non zero then the Request ID is an OUT param*/
	if(*puiExpTime)
	{
		*puiReqId = 0; 
	}
	else
	{
		/*TO DO - Request Registration Disable to all FXS agents*/
		if(*puiReqId)
		{
			pxCnxt = IFX_CMGR_GetReqCnxtPtr(*puiReqId);
		//	pxOut = IFX_CMGR_GetReqLegPtr(*puiReqId);
			if(pxCnxt){
			IFX_CMGR_DeAllocReqCnxt(pxCnxt);
		 }
		}
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}

	/* Analyze the pxTo to find the URL, VL ID and the endpoints associated*/	
	eRet = IFX_LMGR_GetVoipLineIdFromUrl(
			&pxTo->uxAddressInfo.xVoipAddr, &ucLineId, peReason);	
	if((IFX_FAILURE == eRet) || (!ucLineId))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	eRet = IFX_LMGR_GetEndpointsForVoipLine(ucLineId, 
						 aszEid + 1, &ucSize, &bFwdMode, peReason);	
	if(IFX_FAILURE == eRet)
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	/*Save the Line Id*/
	*punLineId = ucLineId;
	/* Add NA to the top of the list*/
	strcpy(aszEid[0], IFX_NA_ENDPT_ID);
	
	/* Call IFX_CMGR_GetReqCnxtAndLegs*/
	if(IFX_FAILURE == IFX_CMGR_GetReqCnxtAndLegs(ucSize + 1,
							  				pvPrivateData,&pxCnxt, peReason))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	/* Call IFX_CMGR_PrepReqCnxt*/
	if(IFX_FAILURE == 
		IFX_CMGR_PrepReqCnxt(pxCnxt, aszEid, ucSize + 1,&ucValidLegs))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		return eRet;
	}
	/* Populate the Line ID and the ARD info*/	
	pxCnxt->eReqType = IFX_CMGR_REQ_SUBS_AUTO_REDIAL;
	pxCnxt->uxReqCnxt.xArdSubsInfo.unVoipLineId = ucLineId;
	pxCnxt->uxReqCnxt.xArdSubsInfo.bIncReq  = IFX_TRUE;
	memcpy(&pxCnxt->uxReqCnxt.xArdSubsInfo.xAddr, 
		&pxFrom->uxAddressInfo.xVoipAddr, sizeof(x_IFX_CMGR_VoipAddr));
		
	/* Set the right value in the OUT leg*/
	pxOut = IFX_CMGR_GetOutReqLeg(pxCnxt);
	/* Return the Req Id*/
	*puiReqId = pxOut->uiReqId;
	
	/* Ask all the EIDs about their status*/
	if (ucValidLegs > IFX_CMGR_REQ_LEG_PER_CNXT)
		return IFX_FAILURE;
	for(i=1; i<ucValidLegs;i++)
	{				
		/* Ask each party about its status*/
		if(pxCnxt->pxReqLegs[i]->pxCallBackList->pfnARD_Reg)
		{
			pxCnxt->pxReqLegs[i]->pxCallBackList->pfnARD_Reg(
				pxCnxt->pxReqLegs[i]->uiReqId, IFX_TRUE, 
				pxCnxt->pxReqLegs[i]->szEndptId, &eStatus,  
				&pxCnxt->pxReqLegs[i]->pvPrivateData);
		}

		if(IFX_CMGR_STATUS_SUCCESS == eStatus)
		{
			*peStatus = eStatus;
			*peReason = IFX_TERMINATED;
			/* inform all the previous parties to clear their subs*/
			for(j=1; j < i;j++)
			{
				if(pxCnxt->pxReqLegs[j]->pxCallBackList->pfnARD_Reg)
						pxCnxt->pxReqLegs[j]->pxCallBackList->pfnARD_Reg(
							pxCnxt->pxReqLegs[j]->uiReqId, IFX_FALSE, 
								pxCnxt->pxReqLegs[j]->szEndptId, &eStatus,  
									&pxCnxt->pxReqLegs[j]->pvPrivateData);
			}
			*puiReqId = 0;
			IFX_CMGR_DeAllocReqCnxt(pxCnxt);
			break;
		}
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	The function is invoked by the DECT/FXS agent to send a Notify for Auto
				 Redial in Rsp to pfn_IFX_CMGR_ARD_Register when 
				 the endpoint is free. Once the Agent calls this function, it can delete
				 the Req-id associated with the Req.
 	\param[in]	uiReqId is the Req ID
	\param[in]	eLocalStatus indicates if the local party free to take a 
					call or not
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_CMGR_ARD_Ntf(
					 	IN uint32 uiReqId,
						IN e_IFX_CMGR_Status eStatus 
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_ReqLeg* pxLeg = IFX_CMGR_GetReqLegPtr(uiReqId);
	x_IFX_CMGR_ReqContext *pxCnxt = IFX_CMGR_GetReqCnxtPtr(uiReqId);
	if(pxLeg == NULL || pxCnxt == NULL){
		return IFX_FAILURE;
	}
	x_IFX_CMGR_ReqLeg* pxOut = IFX_CMGR_GetOutReqLeg(pxCnxt);
	x_IFX_CMGR_NotifyInfo xNtfInfo;
	uint8 i=0;
	e_IFX_CMGR_Status eVoipStatus = 0;
	e_IFX_ReasonCode eReason = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");

	/*To Check if the ARD has already been de-activated*/	
	if(IFX_CMGR_STRUCT_FREE == pxCnxt->eStructStatus)
	{
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	
	/* If not free, why did agent invoke the fn - do nothing*/
	if(IFX_CMGR_STATUS_SUCCESS != eStatus)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"FXS not Free!!");
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	memset(&xNtfInfo, 0, sizeof(x_IFX_CMGR_NotifyInfo));
	xNtfInfo.uxNotifyInfo.xAutoNtfyInfo.bRemoteFree =  IFX_TRUE;
	/* Inform the NA with a Notify*/
	if(pxOut->pxCallBackList->pfnNtfnSnd)
		eRet = pxOut->pxCallBackList->pfnNtfnSnd(pxOut->uiReqId, 
				&xNtfInfo, &eVoipStatus, &eReason, pxOut->pvPrivateData);
	/* Clear subs with all other parties*/
	for(i=1;i<IFX_CMGR_REQ_LEG_PER_CNXT;i++)
	{
		if((pxCnxt->pxReqLegs[i]) && (pxLeg != pxCnxt->pxReqLegs[i]))
		{
				if(pxCnxt->pxReqLegs[i]->pxCallBackList->pfnARD_Reg)
						pxCnxt->pxReqLegs[i]->pxCallBackList->pfnARD_Reg(
							pxCnxt->pxReqLegs[i]->uiReqId, IFX_FALSE, 
								pxCnxt->pxReqLegs[i]->szEndptId, &eStatus,  
									&pxCnxt->pxReqLegs[i]->pvPrivateData);
		}
	}
	/* Clear the context*/
	IFX_CMGR_DeAllocReqCnxt(pxCnxt);
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	To be invoked by the RTP agent and implemented by the CMGR. 
				Informs the CMGR about any error that may have occured.
	\param[in]	 uiCallId is the identifier of the call
	\param[in]	 eErrCode incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_RtpMediaError(IN uint32 uiCallId,
					 					 IN e_IFX_ReasonCode eErrCode)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	e_IFX_CMGR_Status eStatus = 0;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	
	if(IFX_RTP_AGENT_CLOSE_IND == eErrCode)
	{
#if 1
		IFX_CMGR_InvokeRemoteCallRelease(pxLeg, eErrCode, NULL);
		/*Release the Call Leg as if the release was invoked from the pxLeg*/		
		eRet = IFX_CMGR_CallRelease(pxLeg->uiCallId,
							 eErrCode, NULL, &eStatus, &eErrCode);							
#endif
	}
	
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
/*!
	\brief	Will be called by FXS/FXO agent to switch a call to FAX 
	\param[in]	uiCallId the call-id for this call
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_FaxStart(
					 		IN uint32 uiCallId
					 )
{
	e_IFX_Return eRet = IFX_SUCCESS;
#ifdef FAX_SUPPORT
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason; 
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxPeer;
	x_IFX_CMGR_CallContext* pxCnxt;
	x_IFX_CMGR_VoipLegInfo* pxLegInfo = NULL; 
	boolean bT38Udp = IFX_FALSE;
	boolean bT38Tcp = IFX_FALSE;
	boolean bT38TcpPref = IFX_FALSE;
	boolean bG711u = IFX_FALSE;
	boolean bG711a = IFX_FALSE;
	int32 iG711uIdx = -1;
	int32 iG711aIdx = -1;
	uint16 i = 0,j = 0;		
	x_IFX_CMGR_MediaParams xSendMedia;
	x_IFX_CMGR_CodecParams* pxSendCodecs = NULL;
	x_IFX_CMGR_RtpParams* pxSendRtp = NULL;
	x_IFX_CMGR_FaxParams* pxSendFax = NULL;
	uint8 ucVoipLineId = 0;
	x_IFX_CMGR_CodecParams xCodecs;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	/*Sanity Check*/
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	pxPeer = IFX_CMGR_GetPeerPtr(pxLeg);
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	
	/* Check to see if FAX is already running*/
	if(IFX_CMGR_GET_FLAG((pxLeg->pxCurrCnxt->unFlags),\
																		IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON))
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/* Get pointer to the information in the Voip leg*/	
	pxLegInfo = &pxPeer->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo;
	ucVoipLineId = pxLegInfo->ucLineId;	
	
	/* Search for the presence of T.38 TCP/UDP or both in the Offered Codecs, 
	 i.e. the Local codecs. If present then make the T.38 codec into the MPC.
	 Call MediaNegReq CB to re-negotiate*/
	IFX_CMGR_SearchForT38(&pxLegInfo->xOfferedCodecInfo,
																					&bT38Udp,&bT38Tcp,&bT38TcpPref);
	/* Check for 7.11*/
	bG711u = IFX_CMGR_SearchForCodec(&pxLegInfo->xOfferedCodecInfo,
																									IFX_G711_ULAW,&iG711uIdx);	
	bG711a = IFX_CMGR_SearchForCodec(&pxLegInfo->xOfferedCodecInfo,
																									IFX_G711_ALAW,&iG711aIdx);
	/* Clear the temp codec list*/
	memset(&pxLegInfo->xTempCodecInfo,0,sizeof(x_IFX_CMGR_CodecParams));
	/* Check for presence of at-least T.38 or G.711*/
	if((IFX_FALSE == bT38Udp) && (IFX_FALSE == bT38Tcp))
	{
		/* Get local Capabilities */
		eRet = IFX_LMGR_GetCodecsForLine(ucVoipLineId, &xCodecs, &eReason);
		for (i=0; i<xCodecs.unNoOfCodecs; i++){
			if (xCodecs.axCodec[i].uiCodec == IFX_T38_UDP){
				bT38Udp = IFX_TRUE;
				break;
			}
		}
		if((IFX_FALSE == bT38Udp) && (IFX_FALSE == bG711u)&& (IFX_FALSE == bG711a)){
			eRet = IFX_FAILURE;
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return eRet;
		}
	}
	
	if(IFX_TRUE == bT38Udp)
	{
		/*Take data from CIF and populate it into the axFaxParams*/
		IFX_LMGR_GetFaxParams(ucVoipLineId ,IFX_TRPROTO_UDP,&pxLegInfo->axFaxParams[0]);	
		/* Add to MPC position in Temp Codec List*/
		pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec =  IFX_T38_UDP;
		pxLegInfo->xTempCodecInfo.unNoOfCodecs++;

		/* Set flag to indicate that this is the FAX initiator side*/
		IFX_CMGR_SET_FLAG(pxPeer->pxCurrCnxt->unFlags,\
															 	IFX_CMGR_FLAG_FAX_INITIATOR);
	}
	if(IFX_TRUE == bT38Tcp)
	{
		/* Take data from CIF and populate it into the axFaxParams*/
		if(!pxLegInfo->axFaxParams[0].xFaxCfg.uiTransportProtocol)
			IFX_LMGR_GetFaxParams(ucVoipLineId, IFX_TRPROTO_TCP,&pxLegInfo->axFaxParams[0]);	
		else
			IFX_LMGR_GetFaxParams(ucVoipLineId, IFX_TRPROTO_TCP,&pxLegInfo->axFaxParams[1]);	
					
		/* Invoke the CB to start listening on the FAX server port*/
		IFX_CMGR_InvokeFaxServerListen(pxPeer, IFX_FALSE);
		/* Set flag to indicate the same.*/
		IFX_CMGR_SET_FLAG(pxPeer->pxCurrCnxt->unFlags,\
															 	IFX_CMGR_FLAG_WAITING_FOR_TCP_FAX);
		if(IFX_FALSE == bT38TcpPref)
		{
			/* Add to MPC-1 in the list*/
			pxLegInfo->xTempCodecInfo.axCodec[1].uiCodec = IFX_T38_TCP;
		}
		else
		{
			/* Add to MPC in the List if the MPC loc is free else move the MPC pos into
			 MPC - 1 and save this in MPC*/
			if(!pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec)
			{
				pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec = IFX_T38_TCP;
			}
			else
			{
				pxLegInfo->xTempCodecInfo.axCodec[1].uiCodec = 
							pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec;
				pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec = IFX_T38_TCP;
					
			}
		}
		pxLegInfo->xTempCodecInfo.unNoOfCodecs++;
		/* Set flag to indicate that this is the FAX initiator side*/
		IFX_CMGR_SET_FLAG(pxPeer->pxCurrCnxt->unFlags,\
															 	IFX_CMGR_FLAG_FAX_INITIATOR);
	}

	/* If there are no T.38 codecs in the temp list then make G.711 A/U as the
	 MPC so that the fax call can at-least run on the RTP*/	
	if(!pxLegInfo->xTempCodecInfo.unNoOfCodecs)
	{
		/*Before copying codecs check if the PCM codecs are running the call? 
			If so then no need to re-negotiate.*/
		if((IFX_G711_ALAW == pxLegInfo->xNegCodecInfo.axCodec[0].uiCodec)||
			(IFX_G711_ULAW == pxLegInfo->xNegCodecInfo.axCodec[0].uiCodec))
		{
			IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
			return IFX_SUCCESS;
		}
		
		if(IFX_TRUE == bG711u)
		{
			/* Put in the MPC location in the list*/
			pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec = IFX_G711_ULAW;
			pxLegInfo->xTempCodecInfo.unNoOfCodecs++;
		}
		if(IFX_TRUE == bG711a)
		{
			if(!pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec)
			{
				pxLegInfo->xTempCodecInfo.axCodec[0].uiCodec = IFX_G711_ALAW;
			}	
			else
			{
				pxLegInfo->xTempCodecInfo.axCodec[1].uiCodec = IFX_G711_ALAW;
			}	
			pxLegInfo->xTempCodecInfo.unNoOfCodecs++;
		}
	}
	
	/* Add the other Codecs in the offered list into the temp list except 
		 for the T.38 ones. */
	if (pxLegInfo->xTempCodecInfo.unNoOfCodecs > IFX_MAX_CODECS)
		return IFX_FAILURE;
	i=pxLegInfo->xTempCodecInfo.unNoOfCodecs;
	/* Check for 7.11 in the temp codec list*/
	bG711u = IFX_CMGR_SearchForCodec(&pxLegInfo->xTempCodecInfo,
																									IFX_G711_ULAW,&iG711uIdx);	
	bG711a = IFX_CMGR_SearchForCodec(&pxLegInfo->xTempCodecInfo,
																									IFX_G711_ALAW,&iG711aIdx);
	/*Run loop till there are codecs in the offered list*/
	while(j < pxLegInfo->xOfferedCodecInfo.unNoOfCodecs)
	{
		if((pxLegInfo->xOfferedCodecInfo.axCodec[j].uiCodec != IFX_T38_TCP) && 
			(pxLegInfo->xOfferedCodecInfo.axCodec[j].uiCodec != IFX_T38_UDP) && 
			(pxLegInfo->xOfferedCodecInfo.axCodec[j].uiCodec != IFX_DIGIT_2833))
		{

			if(((IFX_FALSE == bG711u) && (pxLegInfo->xOfferedCodecInfo.axCodec[j].uiCodec == IFX_G711_ULAW)) || 
				((IFX_FALSE == bG711a) && (pxLegInfo->xOfferedCodecInfo.axCodec[j].uiCodec == IFX_G711_ALAW)))
			{
				/* Copy codec to current position in the Temp Codec List*/
				if (i > IFX_MAX_CODECS-1)
					break;
				pxLegInfo->xTempCodecInfo.axCodec[i] = 
								pxLegInfo->xOfferedCodecInfo.axCodec[j];	
				/* Increment the position in the temp list */	
				++i;
			}
		}
		/* Increment the offered list index */
		++j;
	}
	/* Set the value of the total codecs in the temp list from i*/
	pxLegInfo->xTempCodecInfo.unNoOfCodecs = i;  	
	
	/* Invoke CB to start media negotiation*/	
	memset(&xSendMedia,0,sizeof(x_IFX_CMGR_MediaParams));
	xSendMedia.eAgentType = IFX_CMGR_TYPE_VOIP;
	pxSendCodecs = &xSendMedia.uxMediaParams.xVoipMediaParams.xCodecParams;
	pxSendRtp = &xSendMedia.uxMediaParams.xVoipMediaParams.xRtpParams;
	pxSendFax = xSendMedia.uxMediaParams.xVoipMediaParams.axFaxParams;

	/* Copy Temp Codecs/ Neg Rtp /Fax params in the xSendMedia List*/
	memcpy(pxSendCodecs, &pxLegInfo->xTempCodecInfo,
								 			sizeof(x_IFX_CMGR_CodecParams));
	memcpy(pxSendRtp, &pxLegInfo->xNegRtpParams,
								 			sizeof(x_IFX_CMGR_RtpParams));
	memcpy(pxSendFax, pxLegInfo->axFaxParams,
								 			IFX_MAX_FAX_PROTO * sizeof(x_IFX_CMGR_FaxParams));

	/*Set Flag to indicate the media negotiation is going on*/
	IFX_CMGR_SET_FLAG(pxCnxt->unFlags,IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG);
	/* Invoke pfnMediaNegReq*/
	IFX_CMGR_InvokeMediaNegReq(pxPeer,&xSendMedia,&eStatus,&eReason);
#else
	eRet = IFX_FAILURE;	
#endif
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	This function provides the asynchronous error and status reporting 
	from the Fax Agent.  The Fax Agent invokes this function to report status and 
	errors when the Fax session is in progress.  A typical case of status reporting
	is the completion of fax reception.
	\param[in]	 uiCallId The identifier of the call
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_FaxSessionEnd(IN uint32 uiCallId)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	e_IFX_CMGR_Status eStatus = 0;
	e_IFX_ReasonCode eReason = 0;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
#ifdef FAX_SUPPORT
	/* Disconect the call and clear all resources*/
	IFX_CMGR_InvokeRemoteCallRelease(pxLeg, IFX_MAX_REASON, NULL);
	/*Release the Call Leg as if the release was invoked from the pxLeg*/		
	eRet = IFX_CMGR_CallRelease(pxLeg->uiCallId,
					IFX_MAX_REASON, NULL, &eStatus, &eReason);						
#endif
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*!
	\brief	To be invoked by the Fax agent and implemented by the CMGR. 
				Informs the CMGR about any error that may have occured.
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 eErrCode Incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_FaxMediaError(IN uint32 uiCallId,
					 					 IN e_IFX_ReasonCode eErrCode)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	e_IFX_CMGR_Status	eStatus = 0;
	e_IFX_ReasonCode eReason = 0;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "ENTRY");
	if(!pxLeg)
	{
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
    												         					"Invalid Call Id",uiCallId);
		IFX_CMGR_PrintExitInfo(IFX_FAILURE, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
#ifdef FAX_SUPPORT
	/* Disconect the call and clear all resources*/
	IFX_CMGR_InvokeRemoteCallRelease(pxLeg, IFX_MAX_REASON, NULL);
	/*Release the Call Leg as if the release was invoked from the pxLeg*/		
	eRet = IFX_CMGR_CallRelease(pxLeg->uiCallId,
					IFX_MAX_REASON, NULL, &eStatus, &eReason);						
#endif
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}

/*****************************************************************************  
 *  Function name   :
 *  description     
 *  input values    : 
 *  output values	  : 
 *  return value    : ifx_success or ifx_failure
 *  notes           :
 ****************************************************************************/
#ifndef LIST_ACCESS
e_IFX_Return IFX_CMGR_ListAccessNtfy(
												e_IFX_CMGR_LA_Type eLAType, 
												void *pxOld, 
												void *pxNew)
{

	uchar8 ucSize = 1,i=0;
	char8 aszEpList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
	e_IFX_ReasonCode eReason;
	x_IFX_CMGR_CallBackList* pxCallBackList = NULL;
	//x_IFX_CMGR_CallBackList* pxCallBack = NULL;
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");	 	

	if(IFX_FAILURE == IFX_CIF_EndptListGet(IFX_EP_DECT, 
                   		&ucSize,aszEpList,&eReason)){	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
						"Get EndPtList Failed");
		return IFX_FAILURE;
	}

	for(i=0;i<ucSize;i++) {

		 pxCallBackList = NULL;

  	 if(IFX_CMGR_GetCBList(aszEpList[i],&pxCallBackList)
     				== IFX_FAILURE){
      	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				    		"No CallBack Registerd");
				continue;
		 }
		 if((pxCallBackList == NULL ) || (pxCallBackList != NULL && pxCallBackList->pfnListAccess == NULL)){
				continue;
		 }else{
			 pxCallBackList->pfnListAccess(aszEpList[i],eLAType,pxOld,pxNew);
       //pxCallBack = pxCallBackList;
			}

	}
	IFX_CIF_FreeVmapiObj(eLAType,pxOld,pxNew);
#if 0
  if(pxCallBack && pxCallBack->pfnFreeVmapiObj != NULL){
		 pxCallBack->pfnFreeVmapiObj(eLAType,pxOld,pxNew);
  }
#endif
	return IFX_SUCCESS;
}
#endif

/*****************************************************************************  
 *  Function name   :
 *  description     
 *  input values    : 
 *  output values	  : 
 *  return value    : ifx_success or ifx_failure
 *  notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_DateTimeNtfy(void *pxOld, 
												           void *pxNew)
{

	uchar8 ucSize = 1,i=0;
	char8 aszEpList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
	e_IFX_ReasonCode eReason;
	x_IFX_CMGR_CallBackList* pxCallBackList = NULL;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");	 	

	if(IFX_FAILURE == IFX_CIF_EndptListGet(IFX_EP_DECT, 
                   		&ucSize,aszEpList,&eReason)){	
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
						"Get EndPtList Failed");
		return IFX_FAILURE;
	}

	for(i=0;i<ucSize;i++) {
		 pxCallBackList = NULL;

  	 if(IFX_CMGR_GetCBList(aszEpList[i],&pxCallBackList)
     				== IFX_FAILURE){
      	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				    		"No CallBack Registerd");
				continue;
		 }
		 if(pxCallBackList && pxCallBackList->pfnDateTime != NULL){
			 pxCallBackList->pfnDateTime(aszEpList[i],pxOld,pxNew);
		 }
	}
	return IFX_SUCCESS;
}

e_IFX_Return IFX_CMGR_SetAtxCnxt (
				IN uint32 uiCallId,
				IN uint32 uiRepCallId,
				OUT e_IFX_ReasonCode* peReason)
{
	e_IFX_Return eRet = IFX_SUCCESS;
	x_IFX_CMGR_CallLeg* pxLeg = IFX_CMGR_GetCallLegPtr(uiCallId);
	x_IFX_CMGR_CallLeg* pxAtxLeg = IFX_CMGR_GetCallLegPtr(uiRepCallId);
	x_IFX_CMGR_CallContext *pxCnxt, *pxAtxCnxt;
	
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	if(!pxLeg || !pxAtxLeg)
	{
		eRet = IFX_FAILURE;
		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
		return eRet;
	}
	/*Get Context & Atx Cnxt*/
	pxCnxt = IFX_CMGR_GetCurrCnxt(pxLeg);
	pxAtxCnxt = IFX_CMGR_GetCurrCnxt(pxAtxLeg);
	/*Set the Atx Cnxt*/
	pxAtxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxCnxt;
	pxLeg->pxCurrCnxt->pxPeerAtxCnxt = pxAtxCnxt;
	/*Set the transfer type*/
  pxCnxt->eTypeOfTransfer = pxAtxCnxt->eTypeOfTransfer = IFX_CMGR_ATX_MAX_TYPE;
  IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
  return IFX_SUCCESS;
}

# if 0
	//Function Entry info
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,__FILE__);

	//String Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "The string goes here");
	//Integer Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Info goes here",integer goes here);
	//String Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "Info Goes here",String goes here);

	//String Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "The string goes here");
	//Integer Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
             "Info goes here",integer goes here);

	//String Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
                 "Info Goes here",String goes here);
# endif

STATIC e_IFX_Return IFX_CMGR_GetNewLeg(IN uint32* puiCallId)
{
	x_IFX_CMGR_CallContext* pxCnxt = NULL;	
	x_IFX_CMGR_CallLeg* pxNew = NULL;	
	e_IFX_Return eRet = IFX_FAILURE;

	if (puiCallId && *puiCallId ){
		pxCnxt  = IFX_CMGR_GetCallCnxtPtr(*puiCallId);
		if (pxCnxt != NULL){
			if (IFX_CMGR_GetCallLeg(IFX_CMGR_FindCallCnxtIdx(pxCnxt),&pxNew) == IFX_FAILURE){
    		IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
    		return IFX_FAILURE; /*Major failure - Propogate to top -DEBUG*/
  		}
			IFX_CMGR_SetLegDir(pxNew,IFX_CMGR_IN);
			//pxCnxt->pxCallLegs[IFX_CMGR_IN_CL_START_IDX] = pxNew;
			printf("in get new leg, no of legsis %d\n",pxCnxt->ucNumCallLegs);
			pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs] = pxNew;
			pxCnxt->ucNumCallLegs++;
		}
	}
	return IFX_SUCCESS;
}
/*****************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS or IFX_FAILURE 
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CMGR_CallDeflect(
								IN uint32 uiCurrentCallId,
    						IN x_IFX_CMGR_AddressInfo *pxTo, 
   							OUT e_IFX_ReasonCode *peReason)

{
	e_IFX_EndptType eEndptType =0;
	e_IFX_Return eRet = IFX_FAILURE;

	x_IFX_CMGR_CallContext *pxCnxt = NULL;
	x_IFX_CMGR_CallLeg* pxLeg = NULL;	
	x_IFX_CMGR_CallLeg* pxOut = NULL;	
	e_IFX_CMGR_Status   eStatus ;
	uchar8 ucCount = 0;
	int32 iLocalResId = 0;
	int32 iLocalResId2 = 0;

	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	if (!uiCurrentCallId || !pxTo || !peReason) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid IN Params");
		return IFX_FAILURE;
	}



	if(uiCurrentCallId) {
  	pxLeg  = IFX_CMGR_GetCallLegPtr(uiCurrentCallId);
  	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Current CalID");
  	if(!pxLeg){
    	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Leg Current CallId");
    	return IFX_FAILURE;
  	}
	}else{
    IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Current CallId is zero");
    return IFX_FAILURE;
	}

	pxCnxt = IFX_CMGR_GetCallCnxtPtr(uiCurrentCallId);

	if (pxCnxt == NULL)
		return IFX_FAILURE;
	
	if (IFX_CMGR_GET_FLAG(pxCnxt->unSSCallFlag,IFX_CMGR_DEFLECTION_IN_PROGRESS)){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Deflection is already in progress");
		return IFX_FAILURE;
	}
	
	*peReason = IFX_NO_RESOURCE;
	eRet = IFX_CIF_EndptTypeGet(pxLeg->xLegOwnerInfo.szEndptId,&eEndptType,peReason);
	if (IFX_FAILURE == eRet || IFX_EP_DECT != eEndptType) {
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Initiated from Non DECT Endpt");
		return IFX_FAILURE;
	}

	pxOut = IFX_CMGR_GetOutCl(pxCnxt);

	if (!strcmp(pxLeg->xLegOwnerInfo.szEndptId,pxTo->uxAddressInfo.szEndptId)){
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Deflecter and Deflectee are same");
		return IFX_FAILURE;
	}

	if (((IFX_EP_FXS == eEndptType) || (IFX_EP_DECT == eEndptType)) 
			&& (!strcmp(pxOut->xLegOwnerInfo.szEndptId,pxTo->uxAddressInfo.szEndptId))){
		printf("eflect to caller is not possible\n");
		IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Deflect to caller is not possible");
		return IFX_FAILURE;
	}
	
	IFX_CMGR_SET_FLAG(pxCnxt->unSSCallFlag,IFX_CMGR_DEFLECTION_IN_PROGRESS);

	//In case of Forking, Release remaining call legs, 
	if (pxCnxt->ucNumCallLegs > IFX_CMGR_MAX_LEGS_PER_CNXT-1)
		return IFX_FAILURE;

	if (pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT){
		for (ucCount=1; ucCount < pxCnxt->ucNumCallLegs; ucCount++){  //get the leg's position in call context
			if(!strcmp(pxCnxt->pxCallLegs[ucCount]->xLegOwnerInfo.szEndptId,pxTo->uxAddressInfo.szEndptId)){
				break;	
			}
		}
		if (ucCount != pxCnxt->ucNumCallLegs){ //if call is presented to deflectee, release all inlegs except deflectee's leg
			if (IFX_SUCCESS != IFX_CMGR_SendRelToInCls(pxOut, pxCnxt->pxCallLegs[ucCount])){
				IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Could not release existing calls");
			}else
				return IFX_SUCCESS;  // Nothing to do, Call is already there between original initiater and deflectee, 
		}
	}

	x_IFX_CMGR_AddressInfo xFrom ={0};

	// fill xFrom struct 
	xFrom.eAddressType = pxOut->xLegOwnerInfo.eOwnerType;

	if (xFrom.eAddressType == IFX_CMGR_TYPE_VOIP){
		memcpy(&xFrom.uxAddressInfo.xVoipAddr,&pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xRemAddr,sizeof(x_IFX_CalledAddr));
		if (pxTo->eAddressType == IFX_CMGR_TYPE_VOIP){
			*peReason = IFX_MAX_REASON;//aaaaa
			if (IFX_SUCCESS != IFX_CMGR_SendRelToInCls(pxOut, NULL)){
        IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Could not release existing calls");
      }
	    return IFX_CMGR_InvokeRemoteCallRelease(pxOut, IFX_CALL_FORWARD, &pxTo->uxAddressInfo.xVoipAddr);
		}else{
			strcpy(pxCnxt->szDeflecteeEid,pxTo->uxAddressInfo.szEndptId);
			memcpy(&pxTo->uxAddressInfo.xVoipAddr, &pxOut->xLegOwnerInfo.uxLegOwnerInfo.xVoipLegInfo.xLocalVlAddr,sizeof(x_IFX_CalledAddr));
			IFX_CIF_VLFromUrlGet(&pxTo->uxAddressInfo.xVoipAddr,&pxTo->ucLineId,peReason);
		}
	}else{
		strcpy(xFrom.uxAddressInfo.szEndptId, pxOut->xLegOwnerInfo.szEndptId);
	}

	eStatus = IFX_CMGR_STATUS_FAIL;
	*peReason = IFX_DEFLECTION;
	*peReason = IFX_DEFLECTION;
		
	if (pxTo->eAddressType == IFX_CMGR_TYPE_VOIP && xFrom.eAddressType == IFX_CMGR_TYPE_EXTN){
		iLocalResId = pxCnxt->iResId;
		pxCnxt->iResId =0 ;
	}
	
	eRet = IFX_CMGR_CallInitiate( &pxOut->uiCallId, &xFrom,
              		pxTo, &pxOut->xCallParams, &eStatus, peReason, pxOut->pvPrivateData );

	if( IFX_SUCCESS != eRet ) {
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Call Deflection ");
			if (pxCnxt->ucNumCallLegs > 0)
				IFX_CMGR_DeAllocCallLeg(pxCnxt->pxCallLegs[pxCnxt->ucNumCallLegs-1]);
	}else if (pxCnxt->ucNumCallLegs > IFX_CMGR_MIN_LEGS_PER_CNXT){
		if(!ucCount){
			ucCount = 2;
		}
			
		if (iLocalResId){
			iLocalResId2 = pxCnxt->iResId;
			pxCnxt->iResId = iLocalResId;
		}
			
		if (IFX_SUCCESS != IFX_CMGR_SendRelToInCls(pxOut, pxCnxt->pxCallLegs[ucCount])){
			IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Could not release existing calls");
		}
			
		if (iLocalResId2){
			pxCnxt->iResId = iLocalResId2;
		}
		pxCnxt->pxCallLegs[1] = pxCnxt->pxCallLegs[ucCount];
		pxCnxt->pxCallLegs[ucCount] = NULL;
			
	}else{
			printf("Some problem: No of legs %d\n",pxCnxt->ucNumCallLegs);
	}
	IFX_CMGR_PrintExitInfo(eRet, __FUNCTION__, __LINE__);
	return eRet;
}
