/*****************************************************************************
 **   FILE NAME       :IFX_LMGR.h 
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : DECT VOIP GW Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **							exposed by the line manager to the Call manager
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_LMGR_H__
#define __IFX_LMGR_H__

/* Minimum value of the Dynamic Payload Type for RTP*/
#define IFX_CMGR_MIN_DYN_PT 96

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFaxParams 
 *  Description     : This function gets the FAX information from the VMAPI
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFaxParams(IN uint8 ucLineId,
								IN uint32 uiFaxTrProto,
									OUT x_IFX_CMGR_FaxParams *pxFax);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_FreeMediaPort 
 *  Description     : This fn frees a FAX/RTP port for re-use
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_FreeMediaPort(uint32 uiPort,e_IFX_TransportType eProto);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFxoLineForEndpt
 *  Description     : This function finds the default FXO line id for the 
 *  						 Endpoint Id given
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFxoLineForEndpt(IN char8* szEid, 
					 								OUT char8* szFxoLineId, 
								 					OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetEndptDefaultVoipLine
 *  Description     : This function finds the default Voip line id for the 
 *  						 Endpoint Id given
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetEndptDefaultVoipLine(
					 char8* szEndptId,
					 OUT uchar8* pucVoipLineId,
					 OUT boolean *pbIsReg,
					 OUT e_IFX_ReasonCode* peReason);

/*****************************************************************************
 *  Function Name   : IFX_LMGR_FindEndptsFromFxoId
 *  Description     : This function finds the endpoints attched to FXO line 
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_FindEndptsFromFxoId
								(
								 IN char8* szFxoLineId, 
								 IN_OUT uchar8* pucSize,
								 OUT char8 aszEid[][IFX_MAX_ENDPOINTID_LEN],
								 OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFxoDefaultVoipLine 
 *  Description     : This function finds the default Voip line attched to 
 *  						 the FXO port given.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFxoDefaultVoipLine(
					 char8* szFxoLineId,
					 OUT uchar8* pucVoipLineId,
					 OUT e_IFX_ReasonCode* peReason);

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetVoipLineIdFromUrl 
 *  Description     : This function finds the voip line id from a URL
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetVoipLineIdFromUrl(
					 IN x_IFX_CMGR_VoipAddr* pxAddress,
					 OUT uchar8* pucVoipLineId,
					 OUT e_IFX_ReasonCode* peReason);

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetEndpointsForVoipLine 
 *  Description     : This function finds the list of endpoints tied to a VL.
 *  						 It does so according to the mode of the VL.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetEndpointsForVoipLine(
		IN uint8 ucVoipLineId,
		OUT char8 aszEndptIdList[][IFX_MAX_ENDPOINTID_LEN],
		IN_OUT uchar8* pucSize,
		OUT boolean *pbFwdMode,
		OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCallFwdAddr 
 *  Description     : This function returns the call forward address of the 
 *  						 given type .
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCallFwdAddr(
		IN uint8 ucVoipLineId,
		IN e_IFX_CallForwardType eFwdType,
		OUT boolean* pbFwdEnabled,
		OUT uchar8* pucRingCount,
		OUT x_IFX_CMGR_VoipAddr* pxFwdAddr,
		OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_CanCallBeAccepted
 *  Description     : This function checks if an incoming Voip call can be 
 *  						 accepted or not after passing through checks like
 *  						 UCF and DND.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_CanCallBeAccepted(
		IN uint8 ucVoipLineId,
		IN x_IFX_CMGR_VoipAddr *pxFromAddr,
		IN boolean bFirstVoipCall,
		OUT boolean *pbReject,
		OUT x_IFX_CMGR_VoipAddr* pxFwdAddr,
		OUT e_IFX_ReasonCode* peReason);

/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetInfoForVoipCall 
 *  Description     : This function populates information for a Voip call,
 *  						 based on the VL id. It populates the Codecs, rtp, fax
 *  						 , URL etc.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetInfoForVoipCall
				(
					 IN uint8 ucVoipLineId,
					 OUT x_IFX_CMGR_VoipLegInfo* pxLineInfo,
					 OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToCallReg 
 *  Description     : This function adds an address to the call register
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToCallReg(
					 IN e_IFX_CallRegisterType eType,
					 IN uchar8 ucLineId,
					 IN x_IFX_CalledAddr* pxAddress,
					 OUT e_IFX_ReasonCode* peReason );
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCodecsForExtn
 *  Description     : This function gets codecs for an endpoint id, if some
 *  						 codecs exist in the configuration for the endpoint.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCodecsForEndpt(
					 IN char8* szEndptId,
					 OUT x_IFX_CMGR_CodecParams* pxCodecs,
					 OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToMissedCallReg
 *  Description     : This function adds an entry into the 
 											missed call register.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToMissedCallReg
														(IN uchar8 ucLineId,
														 IN x_IFX_CMGR_AddressInfo* pxAddr);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToPlcdCallReg
 *  Description     : This function adds an entry into the 
 											Placed call register.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToPlcdCallReg
														(IN uchar8 ucLineId,
														 IN x_IFX_CMGR_AddressInfo* pxAddr);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_AddToRcvdCallReg
 *  Description     : This function adds an entry into the 
 											recieved call register.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_AddToRcvdCallReg
														(IN uchar8 ucLineId,
														 IN x_IFX_CMGR_AddressInfo* pxAddr
														);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCidStatus
 *  Description     : This function finds if caller ID is to be supressed 
 											or not.
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCidStatus
														(IN uchar8 ucLineId,
														 OUT boolean* pbEnableCid
														);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetSipInfoCfgStatus
 *  Description     : This function get the SIP info configuration
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetSipInfoCfgStatus(
					 IN uchar8 ucLineId,
					 OUT boolean *pbEnabled,
					 OUT e_IFX_ReasonCode* peReason);
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetCodecsForLine
 *  Description     : This function gets codecs for a VL.
                        
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetCodecsForLine(
					 IN uint8 ucLineId,
					 OUT x_IFX_CMGR_CodecParams* pxCodecs,
					 OUT e_IFX_ReasonCode* peReason );
/*****************************************************************************
 *  Function Name   : IFX_LMGR_GetFaxFxsPort
 *  Description     : This function the default FAX FXS port
 *  Input Values    : 
 *  Return Value    : 
 *                    
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_LMGR_GetFaxFxsPort(OUT char8* szEndptId);
#endif /* __IFX_LMGR_H__*/
