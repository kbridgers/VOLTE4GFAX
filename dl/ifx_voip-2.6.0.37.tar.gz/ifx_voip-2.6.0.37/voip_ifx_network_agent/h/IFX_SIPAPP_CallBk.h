/**************************************************************************
**   FILE NAME    : IFX_SIPAPP_CallBk.h
**   PROJECT      : SIP
**   MODULES      : Event Package export  Function
**   SRC VERSION  : V2.0
**   DATE         : 15-08-2005
**   AUTHOR       : SIP Team
**   DESCRIPTION  : Endpoint data base.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_CALLBK_H__
#define __IFX_SIPAPP_CALLBK_H__

/*! \brief  Subscribes a user for Automatic CallBack service.
    \param[in] uiCBackId Automatic CallBack Request Id.
    \param[in] uiSrvPdrId Service Provider Id.
    \param[in] uiExpires Expiry time for request in seconds.
    \param[in] pxRouteParams Routing parameters for the SIP message.
    \param[out] ppvAppData Pointer to Pointer to NA's internal structure for
                this dialog.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SubscribeForCB(IN uint32 uiCBackId,
                          IN uint32 uiSrvPdrId,
                          IN uint32 uiExpires,
                          IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
                          OUT void **ppvAppData);

/*! \brief Unsubscribes a user from Automatic CallBack service.
    \param[in] uiCBackId Automatic CallBack Request Id.
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UnSubscribeForCB(IN uint32 uiCBackId,
                            IN void *pvAppData);

/*! \brief  Send Notify for Automatic CallBack Request.
    \param[in] uiCBackId Automatic CallBack Request Id.
    \param[in] eSubsState Present state of this subscription.
    \param[in] eReason Description of the reason for this NOTIFY.
    \param[in] bIsRemoteFree Whether the line is free to accept a call.
    \param[in] uiSrvPdrId service provider id.
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NotifyForCB(IN uint32 uiCBackId,
                       IN uint16 unSubsState,
                       IN e_IFX_ReasonCode eReason,
                       IN boolean bIsRemoteFree,
											 IN uint32 uiSrvPrdId,
                       IN void *pvAppData);

/*! \brief  Set the proxy settings for this dialog.
    \param[in] uiCBackId Automatic CallBack Request Id.
    \param[in] pxProxyAddr Outbound proxy's address.
    \param[in] pucProxyAddr Proxy Address
    \param[in] unProxyPort Proxy Port
    \param[in] eProxyTransport Transpot used to contact the proxy.
    \param[in] bIsOutboundProxy Whether proxy is an outbound proxy.
    \param[in] unLocalTcpPort Local TCP Port
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetNextHopAddressForCB(IN uint32 uiCBackId,
                                  IN char8 *pucProxyAddr,
                                  IN uint16 unProxyPort,
                                  IN e_IFX_SIP_Protocol eProxyTransport,
                                  IN boolean bIsOutboundProxy,
                                  IN uint16 unLocalTcpPort,
                                  IN void *pvAppData);

/*! \brief Set Authentication Data For Refer / NOTIFY.
    \param[in] uiCBackId Automatic CallBack Request Id.
    \param[in] pucUserName UserName
    \param[in] pucPasswd Password
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAuthDataForCB(IN uint32 uiCBackId,
                            IN char8 *pcUserName,
                            IN char8 *pcPasswd,
                            IN void *pvAppData);

/*! \brief Send Subscription status for SUBSCRIBE.
    \param[in] uiVMailId VoiceMail Subscription Request Id.
    \param[in] eSubscStatus Subscription status for request.
    \param[in] eRespCode Reason for the present request status.
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendSubscStatusForCB(IN uint32 uiCBackId,
                                IN uchar8 eSubscStatus,
                                IN e_IFX_ReasonCode eRespCode,
                                IN void *pvAppData);

/*! \brief Send Notify status for NOTIFY.
    \param[in] uiVMailId VoiceMail Subscription Request Id.
    \param[in] eSubscStatus Notification status for request.
    \param[in] eRespCode Reason for the present request status.
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendNotifyStatusForCB(IN uint32 uiCBackId,
                                 IN uchar8 eSubscStatus,
                                 IN e_IFX_ReasonCode eRespCode,
                                 IN void *pvAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CBPkgInit(uint32 uiStackHdl);

#endif /* __IFX_SIPAPP_CALLBK_H__*/
