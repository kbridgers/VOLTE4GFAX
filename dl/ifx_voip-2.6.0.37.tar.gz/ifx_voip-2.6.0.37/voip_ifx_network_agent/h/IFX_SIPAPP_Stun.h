/**************************************************************************
 * **   FILE NAME       : IFX_SIPAPP_STUN.h
 * **   PROJECT         : SIP
 * **   MODULES         : Transaction User
 * **   SRC VERSION     : V2.0
 * **   DATE            : 5-05-2005
 * **   AUTHOR          : 
 * **   DESCRIPTION     : Function Prototypes
 * **   COMPILER        : gcc
 * **   REFERENCE       : Coding guide lines
 * **   COPYRIGHT       : Copyright (c) 2004
 * **                     Infineon Technologies AG, st. Martin Strasse 53;
 * **                     81669 Munchen, Germany
 * **
 * **   Any use of this software is subject to the conclusion of a respective
 * **   License agreement. Without such a License agreement no rights to the
 * **   software are granted
 *
 * **  Version Control Section  **
 * **   $Author$
 * **   $Date$
 * **   $Revisions$
 * **   $Log$       Revision history
 * ***********************************************************************/
#ifdef STUN_SUPPORT

#ifndef __IFX_SIPAPP_STUN_H__
#define __IFX_SIPAPP_STUN_H__

#define IFX_SIPAPP_MAX_PORTS 4

#define IFX_SIPAPP_STUN_REG_QUERY      1
#define IFX_SIPAPP_STUN_OUTGOING_QUERY 2
#define IFX_SIPAPP_STUN_INCOMING_QUERY 3 
#define IFX_SIPAPP_MAX_STUN_PARAM 20

#define IFX_SIPAPP_STUN_SUCCESS 1
#define IFX_SIPAPP_STUN_FAIL    0
#define IFX_SIPAPP_MAX_URL 255
#define IFX_SIPAPP_MAX_IPV4 16

#define IFX_SIPAPP_NAT_NOT_DETECTED 0xFF 

typedef struct{
  uchar8  ucChannelId;
  int32   iNATType;
  int32   iSTUNId;
  uchar8  uacLocalIPAddr[IFX_SIPAPP_MAX_IPV4];
  uchar8  uacSTUNServerAddr[IFX_SIPAPP_MAX_URL];
  /* Giving the port number of Stun Server */
  uint16  unStunServPort;
  uchar8  ucNumofPorts;
  uint16  unLocalPort[IFX_SIPAPP_MAX_PORTS];
}x_IFX_SIPAPP_STUNInfo;

typedef struct{
 int32 iSrvPrdInst;
 int32  iNATType;
 int32  iSTUNId;
 uchar8 ucNumofPorts;
 uchar8 ucStunStatus;
 uchar8 uacMappedIPAddr[IFX_SIPAPP_MAX_IPV4]; 
 uint16 unMappedPorts[IFX_SIPAPP_MAX_PORTS][3];
}x_IFX_SIPAPP_STUN_FifoStr;

/* Stun Call back function and structure*/
typedef struct
{
  e_IFX_SIP_Return (*pfCallBackFunc)(void *,e_IFX_SIP_Return eStatus,
                                     x_IFX_SIPAPP_STUN_FifoStr *);
  char8 acCallBackParam[IFX_SIPAPP_MAX_STUN_PARAM];
  int32 iSTUNId;
}x_IFX_SIPAPP_StunCallBack;

EXTERN x_IFX_SIPAPP_StunCallBack *vpxStunHeadPtr;

e_IFX_SIP_Return IFX_SIPAPP_AddStunCallBack( IN int32 iStunId,
                                    IN void (*pfCallBackFunc) (void *,e_IFX_SIP_Return eStatus,x_IFX_SIPAPP_STUN_FifoStr *),
                                    IN void *pxCallBackParam,
                                    IN uint16 unSize);

e_IFX_SIP_Return IFX_SIPAPP_RemoveStunCallBack(IN int32 iStunId);

e_IFX_SIP_Return IFX_SIPAPP_STUNCrtProcess(IN x_IFX_SIPAPP_STUNInfo *pxstuninfo,
                                          IN e_IFX_SIP_Return (*pfCallBackFunc)
                                          (void *,e_IFX_SIP_Return eStatus,x_IFX_SIPAPP_STUN_FifoStr *),
                                          IN uint16 unSize,
                                          IN void *pCallBackParam,
                                          OUT int32 *piStunID);

e_IFX_SIP_Return
IFX_SIPAPP_STUN_RespHandler(x_IFX_SIPAPP_STUN_FifoStr *pxSTUNFifo);

e_IFX_SIP_Return
IFX_SIPAPP_STUNServerPortRsp(void *,
                          e_IFX_SIP_Return eStatus,
                          x_IFX_SIPAPP_STUN_FifoStr *pxSTUNFifo);

e_IFX_SIP_Return
IFX_SIPAPP_SendNATKeepAlivePacket(uchar8 *pucDestIp,
                                uchar8 *pucSrcIp,
                                uint16  unDestPort,
                                uint16  unSrcPort);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NATRTPPortTimeout(IN x_IFX_SIPAPP_UAAppData *pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NATFAXPortTimeout(IN x_IFX_SIPAPP_UAAppData *pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_STUNCallResp(IN void* pxCallBackParam,
                     IN e_IFX_SIP_Return eStatus,
                     IN x_IFX_SIPAPP_STUN_FifoStr *pxSTUNFifo);

#endif /* __IFX_SIPAPP_STUN_H__ */

#endif /* STUN_SUPPORT */
