/**************************************************************************
**   FILE NAME    : IFX_SIPAPP_VoiceMail.h
**   PROJECT      : SIP
**   MODULES      : Event Package export  Function
**   SRC VERSION  : V2.0
**   DATE         : 15-08-2005
**   AUTHOR       : SIP Team
**   DESCRIPTION  : Endpoint data base.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_VOICEMAIL_H__
#define __IFX_SIPAPP_VOICEMAIL_H__

/*! \brief  Subscribes a user for Voicemail service.
    \param[in] uiConnId Voicemail Request Id.
    \param[in] uiSrvPdrId Service Provider Id.
    \param[in] uiExpires Expiry time for request in seconds.
    \param[in] pxRouteParams Routing parameters for the SIP message.
    \param[out] ppvAppData Pointer to Pointer to NA's internal structure for
                this dialog.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_SIP_Return
IFX_SIPAPP_SubscribeForMWI(IN uint32 uiConnId,
                           IN uint32 uiSrvPdrId,
                           IN uint32 uiExpires,
                           IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
                           OUT void **ppvAppData);

/*! \brief Unsubscribes a user from Voicemail service.
    \param[in] uiConnId Voicemail Request Id.
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_SIP_Return
IFX_SIPAPP_UnSubscribeForMWI(IN uint32 uiConnId,
                             IN void *pvAppData);

/*! \brief Set Authentication Data For MWI
    \param[in] uiConnId Voicemail Request Id.
    \param[in] pucUserName UserName
    \param[in] pucPasswd Password
    \param[in] pvAppData Pointer to NA's internal structure for this dialog.
    \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAuthInfoMWI(IN uint32 uiConnId,
                             IN char8 *pcUserName,
                             IN char8 *pcPasswd,
                             IN void *pvAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_MWIPkgInit(uint32 uiStackHdl);
#endif /* __IFX_SIPAPP_VOICEMAILAPP_H__*/
