/****************************************************************************
**   FILE NAME     : IFX_SIPAPP_Registration.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains phone application inteface functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_SIPAPP_REGISTRATION_H__
#define __IFX_SIPAPP_REGISTRATION_H__

/*!  \brief     Send Register Request.
     \param[in] uiReqId is a Request Id
	 \parma[in] uiProfileId is profile Id.
	 \param[in] pxRouteParam is reference to Route parametes
	 \param[in] uiExpire is registration expiration time.
	 \param[in_out] ppvPvtData Pointer to NA's internal structure for this dialog.
	 \return IFX_SIP_FAILURE or IFX_SIP_SUCCESS
*/		  

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RegisterUser(IN uint32 uiReqId,
                        IN uint32 uiProfileId,
                        IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
                        IN uint32 uiExpire,
                        IN_OUT void **pvPvtData,
												IN boolean bRetry);



/*! \method IFX_SIPAPP_UnRegisterUser
    \brief API to be called for Unregistering the user
    \param[in] uiReqId is a request identifier
    \param[in] pvPvtData is pointer to internal structure for this transaction.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UnRegisterUser(IN uint32 uiReqId,
                          IN void* pvPvtData);

/*! \brief     Authenticates the challenged REGISTER request with given user/proxy credentials.
    \param[in] uiReqId is a request identifier.	 
	 \parma[in] pcUserName is reference to username string.
	 \param[in] pcPassword is reference to password for authentication.
	 \param[in] pxAppData is reference to internal structure for this dialog.
	 \return IFX_SIP_FAILURE or IFX_SIP_SUCCESS
*/		  
                      
e_IFX_SIP_Return
IFX_SIPAPP_SetAuthInfoREG(IN uint32 uiReqId,
					 			  IN char8* pcUserName,
								  IN char8* pcPassword,
								  IN void* pxAppData);                       
void
IFX_SIP_RegisterREGCallbacks(uint32 uiStackHdl);

void
IFX_SIPAPP_RemoveUserRegList();

void
IFX_SIPAPP_RemoveRegForSrvPdr(uint32 uiSrvPdr);


#endif                       

