/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_CallIf.h
**   PROJECT       : SIP
**   MODULES       : NetWorkAgent Call Interface Api's
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team.
**   DESCRIPTION   : Function prototypes NetworkAgent functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIPAPP_CallIf.h
    \brief This File contains the SIP Agent Call Interface Functions
*/
 /** \defgroup SIP Session APIs for call establishment
    \brief This section lists the APIs for maintaining a call session with the remote entity.
*/
/* @{ */

#ifndef __IFX_SIPAPP_CALLIF_H__
#define __IFX_SIPAPP_CALLIF_H__


/*! \brief Set Authentication Data
    \param[in] uiCallId CallIdentifier
	\param[in] szUserName UserName
	\param[in] szPasswd Password
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/ 
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAuthData(IN uint32 uiCallId,
					   IN char8 *szUserName,
					   IN char8 *szPasswd,
					   IN void *pvPrivateData);


/*! \brief  Create Call.
    \param[in] uiCallId Call Identifier.
	\param[in] uiSrvPdrId Service Provider ID
	\parma[in] pxRouteParams Call Route Params.
	\param[in] pxCallParams Call Specfic Params.
	\param[out] ppvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CreateCall(IN uint32 uiCallId,
					  IN uint32 uiSrvPdrId,
					  IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
					  IN x_IFX_SIPAPP_CallParams *pxCallParams,
					  OUT void **ppvPrivateData);

/*! \brief  Reject Call.
    \param[in] uiCallId Call Identifier.
	\parma[in] eReason Reason For Rejection.
	\param[in] pxFwdAddr Call Fwd Address (optional based on reason)
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RejectCall(IN uint32 uiCallId,
				  IN e_IFX_ReasonCode eReason,
				  IN x_IFX_CalledAddr *pxFwdAddr,
				  IN void *pvPrivateData);

/*! \brief  Answer Call sends 200 out.
    \param[in] uiCallId Call Identifier.
	\param[in] uiSrvPdrId Service Provider ID
	\param[in] pxMediaParams Media Params
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnswerCall(IN uint32 uiCallId,
					  IN uint32 uiSrvPdrId, 
					  IN x_IFX_MediaParams *pxMediaParams,
					  IN void *pvPrivateData);

/*! \brief  Accept Call sends 180 out.
    \param[in] uiCallId Call Identifier.
	\param[in] uiSrvPdrId Service Provider ID
	\param[in] pxMediaParams Media Params
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AcceptCall(IN uint32 uiCallId,
					  IN uint32 uiSrvPdrId,
					  IN x_IFX_MediaParams *pxMediaParams,
				      IN void *pvPrivateData);

/*! \brief  Release Call sends BYE/CANCEL based on call state.
    \param[in] uiCallId Call Identifier.
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ReleaseCall(IN uint32 uiCallId,IN void *pvPrivateData);


/*! \brief  Hold a Call .
    \param[in] uiCallId Call Identifier.
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HoldCall(IN uint32 uiCallId,IN void *pvPrivateData);

/*! \brief  Resume a Call.
    \param[in] uiCallId Call Identifier.
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ResumeCall(IN uint32 uiCallId, IN void *pvPrivateData);


/*! \brief Remote Hold/Resume Accept.
    \param[in] uiCallId Call Identifier.
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RemHoldResAccept(IN uint32 uiCallId,IN void *pvPrivateData);

/*! \brief  Remote Hold/Resume Reject.
    \param[in] uiCallId Call Identifier.
	\param[in] eReason Reason For Rejection.
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RemHoldResReject(IN uint32 uiCallId,
							IN e_IFX_ReasonCode eReason,
							IN void *pvPrivateData);


/*! \brief  Update Media params (sends ReInvite/UPDATE).
    \param[in] uiCallId Call Identifier.
	\param[in] pxMediaParams Media Params
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UpdateMediaParams(IN uint32 uiCallId,
					         IN x_IFX_MediaParams *pxMediaParams,
					         IN void *pvPrivateData);

/*! \brief  Accept to Remote Update Media params (sends  response to ReInvite/UPDATE).
    \param[in] uiCallId Call Identifier.
	\param[in] pxMediaParams
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AcceptUpdatedMediaParams(IN uint32 uiCallId,
					                IN x_IFX_MediaParams *pxMediaParams,
								    IN void *pvPrivateData);

/*! \brief  Reject to Remote Update Media params (sends  response to ReInvite/UPDATE).
    \param[in] uiCallId Call Identifier.
	\param[in] pxMediaParams
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RejectUpdatedMediaParams(IN uint32 uiCallId,
					                IN e_IFX_ReasonCode* peReason,
					                IN void *pvPrivateData);

/*! \brief  Get Media Params for the Call.
    \param[in] uiCallId Call Identifier.
	\param[in] *pxCodecParams Codec Params
	\param[in] *pxRtpParams Rtp Ports
	\param[in] pvPrivateData Private Data of Application
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetMediaParams(IN uint32 uiCallId,
						  OUT x_IFX_MediaParams *pxMediaParams,
                          IN void *pvPrivateData);


/*! \brief  Send out digits(sends INFO).
    \param[in] uiCallId Call Identifier.
	\param[in] pxDigitInfo Digits Params
	\param[in] pvPrivateData private Data
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendINFO(IN uint32 uiCallId,
					IN x_IFX_InfoMethod *pxDigitInfo,
                    IN void *pvPrivateData);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetNextHopAddr(IN void *pvPrivateData);

#endif /*__IFX_SIPAPP_CALLIF_H__*/

