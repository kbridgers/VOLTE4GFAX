/****************************************************************************
**   FILE NAME     : IFX_SIPAPP_App.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains phone application inteface functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_SIP_APP_H__
#define __IFX_SIP_APP_H__

#define IFX_SIPAPP_MAX_TOKEN 256
#define IFX_SIPAPP_ISSUE_RINGCMD_FLAG 0x00000001
#define IFX_SIPAPP_RTP_SESS_EXIST 0x00000002
#define IFX_SIPAPP_SDP_PRESENT 0x00000004
#define IFX_SIPAPP_LOCAL_HOLD 0x00000008
#define IFX_SIPAPP_LOCAL_RESUME 0x00000010
#define IFX_SIPAPP_REMOTE_RESUME_FLAG 0x00000020
#define IFX_SIPAPP_REMOTE_HOLD_FLAG 0x00000040
#define IFX_SIPAPP_SEND_REQ 0x00000080
#define IFX_SIPAPP_SEND_RESP 0x00000100
#define IFX_SIPAPP_STUN_RESP_AWAITED 0x00000200
#define IFX_SIPAPP_RTPREQ_ISSUED  0x00080000
#define IFX_SIPAPP_ORIGINATING     0x0000400 /* if call is originated */
#define IFX_SIPAPP_TERMINATING     0x0000800 /* if terminating End for a call */
#ifdef RFC_3262
#define IFX_SIPAPP_2XX_ANSWER 0x0001000
#define IFX_SIPAPP_DELAY_2XX 0x0002000
#define IFX_SIPAPP_PRACK_SUPPORT 0x0004000
#define IFX_SIPAPP_PRACK_PENDING 0x0008000
#define IFX_SIPAPP_2XX_PENDING 0x0010000
#endif
#ifdef FAX_SUPPORT
#define IFX_SIPAPP_FAX_TERMINATE 0x00400000
#define IFX_SIPAPP_FAX_ORIGINATE 0x00200000
/*
#define IFX_SIPAPP_SWITCH_TO_VOICE 0x00400000
#define IFX_SIPAPP_FAX_SESS_EXSIT 0x00800000
*/
#endif
#define IFX_SIPAPP_DNP_NOTRSP 0x0040000
#define IFX_SIPAPP_ACK_RECIVED 0x0080000
#define IFX_SIPAPP_MEDIA_UPDATE_SENT 0x0100000
#define IFX_SIPAPP_NOTIFY_RCVD 0x0200000

#ifdef  RFC_3311

#define   IFX_SIPAPP_OFFER_RECV            0x001     /* Set when Offer recieved Yet Not Replied*/
#define   IFX_SIPAPP_OFFER_SENT            0x002     /* Set when Offer send yet not recieve Ans*/
#define   IFX_SIPAPP_UPDATE_SDP_PRESENT    0x004     /* Set when Update is recieved with SDP*/
#define   IFX_SIPAPP_UPDATE                0x008     /* Set when UPDATE-Transaction  with SDP is over */

#endif

/*! \enum e_IFX_SIP_RespCodes
    \brief An Enumeration defining Response code for Sip Requests
*/
typedef enum{
  IFX_SIPAPP_1XX_RESP = 0,/*!<1xx */
  IFX_SIPAPP_2XX_RESP,/*!<  2XX */
  IFX_SIPAPP_3XX_RESP,/*!<  3xx */
  IFX_SIPAPP_4XX_RESP,/*!<  4xx */
  IFX_SIPAPP_5XX_RESP,/*!<  5xx */
  IFX_SIPAPP_6XX_RESP,/*!<  6xx */
} e_IFX_SIPAPP_RespCodes;

typedef enum
{
  IFX_SIPAPP_IFACE_OPENCONERR,
  IFX_SIPAPP_IFACE_MODIFYCONERR,
  IFX_SIPAPP_IFACE_CLOSECONERR,
  IFX_SIPAPP_IFACE_REQCAPERR,
  IFX_SIPAPP_IFACE_LOCKCODECERR,
  IFX_SIPAPP_IFACE_UNLOCKCODECERR,
  IFX_SIPAPP_IFACE_ENABLECONFERR
}e_IFX_SIPAPP_IFACEERR;

typedef enum
{
  IFX_SIPAPP_UA_CALL,
  IFX_SIPAPP_UA_REF,
  IFX_SIPAPP_UA_MWI,
  IFX_SIPAPP_UA_CB,
  IFX_SIPAPP_UA_OPTIONS,
  IFX_SIPAPP_UA_IMSG,
  IFX_SIPAPP_UA_MAX_HDLS  
}e_IFX_SIPAPP_UA_HdlTypes;

typedef enum{
  IFX_SIPAPP_OPEN_CONNRES_EVENT,
  IFX_SIPAPP_MODIFY_CONNRES_EVENT,
  IFX_SIPAPP_CLOSE_CONNRES_EVENT,
  IFX_SIPAPP_ENABLE_CONFRES_EVENT,
  IFX_SIPAPP_DIS_CONFRES_EVENT,
  IFX_SIPAPP_RTPERR_EVENT,
  IFX_SIPAPP_CLS_CONN_IND
}e_IFX_SIPAPP_RTPEvent;

typedef enum{
  IFX_SIPAPP_SETUP_FAX_CALL,
  IFX_SIPAPP_END_FAX_CALL,
  IFX_SIPAPP_SETUP_T38_RSP,
  IFX_SIPAPP_END_T38_RSP,
  IFX_SIPAPP_FAX_ERR_RSP
}e_IFX_SIPAPP_FaxEvent;


typedef struct{
  uint32 auiHdl[IFX_SIPAPP_UA_MAX_HDLS];/*!< Call Handle */
  uint32 iConnId;/*!< Connection Identifier */
  uint32 iConnId2;/*!< Replaces Connection Identifier */
  uint32 iProfileId;/*!< Profile Identifier */
	uint16 unLineId;/*Storeing lineid for bye challenge case*/
	boolean  bSupressCallerId;/*!< Suppress CallerId*/
	char8 szPhoneNumber[24];/*!< Remote party id*/
  x_IFX_SIPAPP_SdpInfo xSdpInfo;/*!< SDP Information */
  x_IFX_CodecList xCodecList;/*!<Codec List */
  x_IFX_FaxParams axFaxParams[IFX_MAX_FAX_PROTO];/*!<Fax Params */
  e_IFX_SIPAPP_IFACEERR eIFACE_Err;/*!< Interface Error */
  x_IFX_CalledAddr xTo;/*!< Destination Address/Call Fwd Address */
  x_IFX_CalledAddr xFrom;/*!< User Information */
  int32 iRtpParamModified;/*!< RTP parameters that are modified */
  uint32 uiDlgIdHdl;/*!< Replaces dialog Identifier */
  uint16 unLocalTcpPort;
  int32 iFlag;/*!< Flags storing some information pertaining to the state of call */
  int32 iStunId;
  uint32 uiSdpHdl;
  /* For storing Instant Msg -- to handle 3xx resp*/
  char8 *pcInstMsg;
  uint32 uiMsgExpires;
  e_IFX_SIP_BasicMethod eRefreshMethod;/*!< Refresh method used to refresh Session*/
  e_IFX_SIP_BasicMethod eMediaUpdateMethod;/* !< Method used to send updated media*/
  uint16 unNoNotifyId;
#ifdef RFC_4028
  uint32 uiSe;
  uint32 uiMinSe;
  uchar8 ucRefreshFlag;
  int32 iSessTimerId;
  int32 iRefreshSessTimerId;
  int32 iUasSessTimerId;
  uchar8 ucSessUpdate;
#endif
	uint16 unVMSubscAttempts;
#ifdef INFO_SUPPORT
  x_IFX_InfoMethod xInfoMethod;
#endif
#ifdef RFC_3311
  int32  iUpdateTimer;
  uint32 uiUpdateTimerId;
  int32  iUpdateFlag;
#endif
#ifdef IFX_INTERCOM_SUPPORT
  boolean bIsIntercomTypeCall;
#endif
 /*Added 3 fields for Replaces purpose*/
 char8 szCallId[IFX_SIPAPP_MAX_TOKEN];
 char8 szRemoteTag[IFX_SIPAPP_MAX_TOKEN];
 char8 szLocalTag[IFX_SIPAPP_MAX_TOKEN];

 /* Store Proxy Info*/
 char8 acProxyAddr[IFX_SIPAPP_MAX_TOKEN];
 uint16 unProxyPort;
 e_IFX_SIP_Protocol eProxyProtocol;
 uchar8 ucIsOutBoundProxy;
 uint32 uiCBExpires;
 uint32 uiNotifyDlgId;
 uchar8 ucNumDlgInNotifyBody;
 uint32 uiVMExpires;
#ifdef DARE_CUST
 char8 acDiversion[512];
 char8 acHistory[128];
#endif
}x_IFX_SIPAPP_UAAppData;

#define IFX_SIPAPP_REG_MAX_TOKEN  256

/*! \enum x_IFX_SIPAPP_UserRegistration
    \brief Structure maintained by the application for registrataion related data
*/
typedef struct 
{   uint32 uiReqId; 				/*<!Request ID received from the CMGR */
    uint32  uiProfileId; 		/*<!Profile Id to access profile configuration */
    uint32 uiRegClientHdl; 	/*<!Register Client Handle received from the Stack */
	 uint32 uiAuthRetry; 		/*<! Number of times REGISTER request is challenged*/
	 char8* pcAOR;   				/*<! Address of Record*/
	 char8* pcRegistrar; 		/*<! Registrar Address*/
	 uint32 uiExpire; 			/*<! Expires sent in Request or received in 2xx resonse*/
	 uint16 unRegTimerId; 		/*<! Registration Refresh timer id*/
	 uint16 unTcpPort; 			/*<! Local TCP port to be used*/
	 char8 *pcProxyAddr;			/*!< Proxy Address*/
    uint16 unProxyPort;			/*!< Proxy Port*/
    uchar8 eProxyProtocol;		/*!< Proxy Protocol*/
    uchar8 ucIsOutBoundProxy; /*!< Is Outbound Proxy*/	
	uchar8 ucMaxRetry;			/*!< Number of times registeration is retried*/
	boolean bRetry;
#ifdef DARE_CUST
	 uint16 unOptionsTimerId; 		/*<! Options timeout timer id*/
#endif
}x_IFX_SIPAPP_UserRegistration;

/* Endpoint package pool */
typedef struct
{
  int32 iMaxAppData;/*!< Maximum endpoints that can be created */
  int32 iAppDataCount;/*!< Endpoint Count */
  x_IFX_SIPAPP_UAAppData *pxAppDataHead;/*!< Head of Endpt List */
}x_IFX_SIPAPP_UAAppDataPool;


extern uchar8 vcSipAppModId;

extern x_IFX_SIPAPP_UAAppDataPool vxAppDataPool;

e_IFX_SIP_Return
IFX_SIPAPP_ValidateIPv4Addr(char8* pszBuff);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CreateNAddAppData(OUT x_IFX_SIPAPP_UAAppData **ppxAppData,
                             OUT e_IFX_SIP_Ecode *peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RemoveAppData(IN x_IFX_SIPAPP_UAAppData *pxAppData, 
                      IN e_IFX_SIPAPP_UA_HdlTypes eHdlType);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetAppData(IN uint32 uiConnId,
                   OUT x_IFX_SIPAPP_UAAppData **ppxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetConnId(IN char8 *pcCallId,
                     IN char8 *pcToTag,
                     IN char8 *pcFromTag,
                     OUT uint32 *puiConnId);                   

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleFAXPort(IN int32 iFlag,
                      OUT uint16 *punFAXPort);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleRTPPort(IN int32 iFlag,
                      OUT uint16 *punRTPPort);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AppDataInit(IN x_IFX_SIPAPP_UAAppData* pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AppDataFree(IN x_IFX_SIPAPP_UAAppData* pxAppData);

void IFX_SIPAPP_ConvCalAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                 OUT char8 *pcTo);


e_IFX_SIPAPP_RespCodes
IFX_SIPAPP_MapRespCode(int16 nStatusCode);


e_IFX_SIP_Return
IFX_SIPAPP_SetSupported(OUT uint32 uiMsgHdl);

e_IFX_SIP_Return
IFX_SIPAPP_SetContact(IN char8 *pcFrom,
                   OUT uint32 uiMsgHdl,
				   IN uint32 uiSrvPdrId);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAllow(OUT uint32 uiMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetContentDisposition(OUT uint32 uiMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetContentType(IN char8 *pcMType,
						  IN char8 *pcMSubtype,
                       OUT uint32 uiMsgHdl);
PUBLIC e_IFX_SIP_Return  
IFX_SIPAPP_SetAccept(OUT uint32 uiMsgHdl,
                     IN char8 *pcMType,
				     IN char8 *pcMSubtype);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAcceptLanguage(OUT uint32 uiMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetExpires(OUT uint32 uiMsgHdl,
                    IN uint32 uiExpires);

PUBLIC e_IFX_SIP_Return  
IFX_SIPAPP_SetEventHdr(OUT uint32 uiMsgHdl,
                       IN  char8 *pcdata);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetMinExpiresHdr(IN uint32 uiMsgHdl,
                         IN uint32 uiMinExpiry);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAllowEventsHdr(IN uint32 uiMsgHdl,
                          IN char8 *pcAllowEvents);
e_IFX_SIP_Return
IFX_SIPAPP_SetSubscState(OUT uint32 uiMsgHdl,
                      IN int32 eSubsState);
e_IFX_SIP_Return
IFX_SIPAPP_SetReplaces(OUT uint32 uiMsgHdl,
                    IN uint32 uiDlgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetUserAgent(uint32 uiMsgHdl,uint32 uiSrvPdrId);

void IFX_SIPAPP_ConvRegAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                 OUT char8 *pcTo);

#ifdef RFC_4028
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CheckTimerTag(IN uint32 uiMsgHdl);
#endif

void IFX_SIPAPP_ConvUsrCfgToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                OUT char8 *pcFrom);

void IFX_SIPAPP_ConvCalAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                            OUT char8 *pcTo);


#ifdef STUN_SUPPORT
e_IFX_SIP_Return IFX_SIPAPP_AddViaIfSTUNOn(uint32 uiMsgHdl, uint32 uiSrvPrd);
#endif /* STUN_SUPPORT */

void IFX_SIPAPP_ConvRegAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                 OUT char8 *pcTo);
#ifdef RFC_3311
PUBLIC void
IFX_SIPAPP_Handle491Update(IN x_IFX_SIPAPP_UAAppData *pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UpdateConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                       OUT uint32 uiMsgHdl,
                       OUT e_IFX_SIP_Ecode* peEcode);
#endif

e_IFX_SIP_Return 
IFX_SIPAPP_CCAppTimeOutOrError(IN e_IFX_SIP_TransErrorCode eErrorType,
                            IN uint32 uiCCHdl,
                            IN uint32 uiDlgHdl,
                            IN void *pvUserData);
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CopyToAddr(IN uint32 uiMsgHdl,
                      OUT x_IFX_CalledAddr *pxUserCfg);
e_IFX_SIP_Return
IFX_SIPAPP_CopyCalledAddr(IN uint32 uiMsgHdl,
                        OUT x_IFX_CalledAddr* pxCalledAddr);
e_IFX_SIP_Return
IFX_SIPAPP_CopyContactAddr(IN uint32 uiMsgHdl,
                        OUT x_IFX_CalledAddr* pxCalledAddr);
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleUpdate(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                        IN uint32 uiMsgHdl,
                        OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_ConstAddr(IN x_IFX_CalledAddr *pxCalledAddr,
					 IN x_IFX_SIPAPP_UAAppData* pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ModifyMedia(IN x_IFX_SIPAPP_UAAppData* pxAppData);

e_IFX_SIP_Return 
IFX_SIPAPP_RtpRespHandler(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN e_IFX_SIPAPP_RTPEvent eRtpRespType);
                          
e_IFX_SIP_Return
IFX_SIPAPP_CopyReferToAddr(IN uint32 uiMsgHdl,
                       OUT x_IFX_CalledAddr* pxCalledAddr);

void IFX_SIPAPP_ConvReferAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                   OUT char8 *pcTo);
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetExpires(uint32 uiMsgHdl, uint32 *puiExpires);

#endif
