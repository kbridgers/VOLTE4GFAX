/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
/* ====================================================================
 *
 * File Name: ifx_stun_api.h
 * Author: Eric Tsai
 * Date:
 *
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/api>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References:
 */

#ifndef __IFX_STUN_API_H__
#define __IFX_STUN_API_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NO_ERR                          0
#define INIT_SSL_ERR                    -100
#define LOAD_ROOTCA_ERR                 -105
#define SSL_NOT_INIT_YET                -110
#define STUN_SERVER_UNKNOWN             -115
#define TCP_CONNECT_FAIL                -120
#define CREATE_SSL_ERR                  -125
#define SSL_CONNECT_ERR                 -130
#define SSL_VERIFY_FAIL                 -135
#define STUN_SERVERID_ERR               -140
#define SHAREDSECRET_MSG_ERR            -145
#define GET_SHAREDSECRET_FAIL           -150
#define INTEGRITY_ERR                   -155
#define MISS_USERNAME                   -160

#define IFX_STUN_TYPE_OPEN		0x00
#define IFX_STUN_TYPE_FULL		0x01
#define IFX_STUN_TYPE_RESTRICT		0x02
#define IFX_STUN_TYPE_PORTRESTRICT	0x03
#define IFX_STUN_TYPE_SYMMETRIC		0x04
#define IFX_STUN_TYPE_FIREWALL		0x05
#define IFX_STUN_TYPE_BLOCK		0x06
#define IFX_STUN_TYPE_UNKNOWN		0x07
#define IFX_STUN_TYPE_HAIRPIN		0x08


typedef struct t_ifx_stun_otp
{
  char8 cUsername[128];
  int32 iUsernameSize;
  char8 cPassword[128];
  int32 iPasswordSize;
} T_IFX_STUN_OTP;

typedef struct t_ifx_stun_binding
{
  //int sock;
  int32 iSrcIP;
  int16 iSrcPort;
  int32 iMappedIP;
  int16 iMappedPort;
} T_IFX_STUN_BINDING;


int32 IFX_STUN_TLS_Init(char8 *pcRootca);
void IFX_STUN_Reset(void);
int32 IFX_STUN_SharedSecretNegotiate(char8 *pcServername, T_IFX_STUN_OTP *ptOTP);
int32 IFX_STUN_NAT_Detect(char8 *pcServername, T_IFX_STUN_OTP *ptOTP, T_IFX_STUN_BINDING *ptEntry, char8 bVerbose);
int32 IFX_STUN_NAT_GetBinding(T_IFX_STUN_BINDING * ptEntry);

#endif

/* ====================================================================
 * Revision History:
 *
 * $Log: ifx_stun_api.h,v $
 * Revision 1.3  2004/05/17 12:45:30  erict
 * Add definitions of error code
 *
 * ====================================================================
 */


