/**************************************************************************
**   FILE NAME       : IFX_SIP_PAIf.h
**   PROJECT         : SIP 
**   MODULES         : Transaction User
**   SRC VERSION     : V2.0
**   DATE            : 15-12-2004
**   AUTHOR          : SIP Team
**   DESCRIPTION     : Function prtotypes of phone application interface functions.
**   COMPILER        : gcc
**   REFERENCE       : Coding guide lines.
**   COPYRIGHT       : Copyright (c) 2004
**                     Infineon Technologies AG, st. Martin Strasse 53;
**                     81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIP_PAIF_H__
#define __IFX_SIP_PAIF_H__


char8 IFX_SIPAPP_PaIfInit();

e_IFX_SIP_Return IFX_SIPAPP_StateNotifer(IN_OUT uint32 *puiCallId,
                        IN e_SIPAPP_Events eEvent,
                        IN void *pxEventData);
#ifdef CALL_MGR
/*!
   \brief      This API is to be called by the Agent whenever it wants to make
               a call to any other agent.
   \param[out] puiCallId is the identifier of the call
   \param[in]  pxTo is the address/extension number/PSTN Phone number
               identifying the called party. For the FXS/DECT agents getting to
               VoIP it is the user at domain form of address uri and type VoIP.
               For FXS/DECT reaching to PSTN it shall be PSTN number.
               For FXS/DECT reaching FXS/DECT it shall be the peer party's extn.
               For FXO agent it shall be either be the remote VoIP URI (GW mode)
               or the FXO line ID (own phone number).
               For NA it shall be the VoIP Line URI.
   \param[in]  pxFrom is the address/endpoint Id/PSTN number identifying the
               calling party.
               For FXS/DECT agents it shall be their own endpoint id and type
               extension.
               For FXO agent it shall be its line id. The FXO agent shall
               fill the PSTN number in the phone number parameter.
               For NA it shall be the address of the remote VoIP party and type
               as VoIP.
   \param[in] pxCallParams Contains extra parameters for the call. Every
                  agent has its own structure that it has to write to.
   \param[out] peStatus is the status of the request
   \param[out] peReason - incase of failure, this parameter provides the
               specific reason
   \param[in] pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
char8 IFX_SIPAPP_CMGR_CreateCall(IN uint32 uiCallId, 
				            	 IN x_IFX_CMGR_AddressInfo *pxFrom,
					             IN x_IFX_CMGR_AddressInfo *pxTo, 
					             IN x_IFX_CMGR_CallParams *pxCallParams, 
					             OUT e_IFX_CMGR_Status* peStatus,
					             OUT e_IFX_ReasonCode* peReason,
					             OUT void** ppvPrivateData);

/*!
   \brief   Will be called to inform the call initiating agent that the
            called agent has accpeted the call and in ringing.
   \param[in]   uiCallId is the identifier of the call
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallAccept(
                        IN uint32 uiCallId,
                        IN void* pvPrivateData);

/*!
   \brief   Will be called to inform the call initiating agent that the
            called agent has answered the call and the call is now established
   \param[in]   uiCallId is the identifier of the call
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallAnswer(
                        IN uint32 uiCallId,
                        IN void* pvPrivateData);

 /*!
   \brief   Will be called by call manager to infrom the agent that the
            peer agent is requesting the call to be put on hold.
   \param[in]   uiCallId is the identifier of the call
   \param[out]  peStatus - current status of the request
   \param[out]  peReason - incase of failure, this parameter provides the
                specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallHold(
                     IN uint32 uiCallId,
                     OUT e_IFX_CMGR_Status* peStatus,
                     OUT e_IFX_ReasonCode* peReason,
                     IN void* pvPrivateData);
/*!
   \brief   Will be called by call manager to infrom the agent that the
            peer agent is requesting the held call to be resumed.
   \param[in]   uiCallId is the identifier of the call
   \param[out]  peStatus - current status of the request
   \param[out]  peReason - incase of failure, this parameter provides the
                specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallResume(
                        IN uint32 uiCallId,
                        OUT e_IFX_CMGR_Status* peStatus,
                        OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData);
/*!
   \brief   Will be called by call manager to tell the
            agent about remote agent has successfully served/failed to serve
            the hold request on the call
   \param[in]   uiCallId is the identifier of the call
   \param[in]  eStatus is the status of the request
   \param[in]  eReason - incase of failure, this parameter provides the
                  specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_CallHoldResponse(
                           IN uint32 uiCallId,
                           IN e_IFX_CMGR_Status eStatus,
                           IN e_IFX_ReasonCode eReason,
                           IN void* pvPrivateData);

/*!
   \brief   Will be called by call manager to tell the
            agent about remote agent has successfully served/failed to serve
            the resume call request on the call
   \param[in]   uiCallId is the identifier of the call
   \param[in]  eStatus is the status of the request
   \param[in]  eReason - incase of failure, this parameter provides the
                  specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_CallResumeResponse
                     (
                     IN uint32 uiCallId,
                     IN e_IFX_CMGR_Status eStatus,
                     IN e_IFX_ReasonCode eReason,
                     IN void* pvPrivateData );
/*!
   \brief   Will be called by call manager the to terminate current call
   \param[in]  uiCallId is the identifier of the call
   \param[in]  eReleaseReason parameter provides the reason for
               call disruption/rejection
   \param[in]  pxFwdAddr is the address that the call has to be forwarded to.
               It is only relevant for the NA.
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
 */
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallRelease(
                     IN uint32 uiCallId,
                     IN e_IFX_ReasonCode eReleaseReason,
                     IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
                     IN void* pvPrivateData);
/*!
   \brief   Used be called by CMGR  to send digits in the middle of
            a call to an agent.
   \param[in]  uiCallId is the identifier of the call
   \param[in]  pxDgtInfo The digit string and type of transmission method
   \param[out] peReason  incase of failure, this parameter provides the
               specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_RecvDigitsInCall(
                     IN uint32 uiCallId,
                     IN x_IFX_CMGR_DgtInfo *pxDigitInfo,
                     IN void* pvPrivateData);

/*!
    \brief     This call-back is to be called by the CMGR to get
               the media parameters. This is called after the invocation of
               the CallAccept API and the CallAnswer API. This call-back
               should only be registered by  agents which need some media
               negotiation i.e. NA or DECT agent. Will be needed in Hold/Resume
               Scenarios. In case of a hold request from a remote party the
               NA shall call  CallHold API in course of which the CMGR shall
               invoke this CB.
    \param[in]  uiCallId is the identifier of the call
    \param[out] pxMediaParams is the reference to the media parameters.
    \param[in] pvPrivateData is the private data for use by the agent
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_GetMediaParams(
                        IN uint32 uiCallId,
                        OUT x_IFX_CMGR_MediaParams* pxMediaParams,
                        IN void* pvPrivateData);

/*!
    \brief  This call-back is called by the agent to offer codecs to an agent
            when media change has been triggered by the peer agent asynchronously
            using the IFX_CMGR_NegotiateMediaRequest API.
            This will be invoked on the NA/DECT agent to change the media during
            a call. Only the DECT & NA should register it. On this the NA
            should send out a re-Invite with the prameters listed and the
            DECT agent should offer the codecs to the DECT PP.
    \param[in]  uiCallId is the identifier of the call
    \param[in,out] pxMediaParams is the reference to the media parameters.
   \param[out] peStatus is the status of the request SUCCESS/FAILED/PENDING
   \param[out] peReason this parameter provides the specific reason
    \param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_NegotiateMediaRequest(
                        IN uint32 uiCallId,
                        IN_OUT x_IFX_CMGR_MediaParams* pxMediaParams,
                        OUT e_IFX_CMGR_Status* peStatus,
                        OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData);

/*!
    \brief  This call-back is called by the CMGR to inform an  agent about
            the media change request it had initiated via the
            IFX_CMGR_NegotiateMediaRequest API.
            This will be invoked on the NA/DECT agent to respond with the
            final answer. It shall also be used by the NA to give an
            SDP answer to the UPADTE/Re-Invite it had received.
    \param[in]  uiCallId is the identifier of the call
    \param[in] pxMediaParams is the reference to the media parameters.
   \param[in,out] peStatus is the status of the request SUCCESS/FAILED/PENDING
   \param[in,out] peReason this parameter provides the specific reason
    \param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_NegotiateMediaResponse(
                        IN uint32 uiCallId,
                        IN x_IFX_CMGR_MediaParams* pxMediaParams,
                        IN_OUT e_IFX_CMGR_Status* peStatus,
                        IN_OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData);
#endif /*CALL_MGR*/
#endif
