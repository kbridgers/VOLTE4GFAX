/**************************************************************************
**   FILE NAME     : IFX_SIP_Info.h
**   PROJECT  	   : SIP
**   MODULES       : Transaction User(Call Control)
**   SRC VERSION   : V2.0 
**   DATE    	     : 
**   AUTHOR        : SIP team
**   DESCRIPTION   : This file contains the functions related to the INFO
**                   method. Though it is a part of call control it is not 
**                   included in the FSM as the state of the call remains 
**                   unchanged
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**
**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_INFO_H__
#define __IFX_SIPAPP_INFO_H__

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InfoConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  OUT uint32 uiMsgHdl,
                  OUT e_IFX_SIP_Ecode* peEcode);

e_IFX_SIP_Return
IFX_SIPAPP_SendInfo(IN x_IFX_SIPAPP_UAAppData *pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleInfo(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                     IN uint32 uiMsgHdl,
                     OUT e_IFX_SIP_Ecode* peEcode);

#endif
