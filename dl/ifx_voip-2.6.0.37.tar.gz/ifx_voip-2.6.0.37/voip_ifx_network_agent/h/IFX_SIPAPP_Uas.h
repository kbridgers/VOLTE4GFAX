/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_TUUas.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : Murali.
**   DESCRIPTION   : Function prototypes.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_SIP_TUUAS_H__
#define __IFX_SIP_TUUAS_H__

extern IFX_SIPAPP_HandleRequests pfnHandleSpecMsg[];
extern IFX_SIPAPP_SpecRespConst pfnSpecRespConst[];

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleInvite(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                     IN uint32 uiMsgHdl,
                     OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleCancel(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                     IN uint32 uiMsgHdl,
                     OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleAck(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  IN uint32 uiMsgHdl,
                  OUT e_IFX_SIP_Ecode* peEcode);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleBye(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  IN uint32 uiMsgHdl,
                  OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_1XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_2XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleReInvite(IN x_IFX_SIPAPP_UAAppData* pxAppData,
    IN uint32 uiMsgHdl,
    OUT e_IFX_SIP_Ecode* peEcode);



PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_3XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_4XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_5XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_6XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode);



#endif /*__IFX_SIP_TUUAS_H__*/
