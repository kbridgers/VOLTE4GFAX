/**************************************************************************
**   FILE NAME       : IFX_SIPAPP_Transceiver.h
**   PROJECT         : SIP 
**   MODULES         : Transaction User
**   SRC VERSION     : V2.0
**   DATE            : 15-12-2004
**   AUTHOR          : SIP Team
**   DESCRIPTION     : Enumerations  of response codes.
**   COMPILER        : gcc
**   REFERENCE       : Coding guide lines for VSS ,
**   COPYRIGHT       : Copyright (c) 2004
**                     Infineon Technologies AG, st. Martin Strasse 53;
**                     81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_TRANSCEIVER_H__
#define __IFX_SIPAPP_TRANSCEIVER_H__

typedef enum{
  IFX_SIPAPP_HANDLE_1XX,
  IFX_SIPAPP_HANDLE_2XX,
  IFX_SIPAPP_HANDLE_3XX,
  IFX_SIPAPP_HANDLE_4XX,
  IFX_SIPAPP_HANDLE_5XX,
  IFX_SIPAPP_HANDLE_6XX
} e_IFX_SIPAPP_RspType;

typedef enum{
  IFX_SIPAPP_100,
  IFX_SIPAPP_180,
  IFX_SIPAPP_181,
  IFX_SIPAPP_182,
  IFX_SIPAPP_183,
  IFX_SIPAPP_200,
  IFX_SIPAPP_202,
  IFX_SIPAPP_300,
  IFX_SIPAPP_301,
  IFX_SIPAPP_302,
  IFX_SIPAPP_305,/*10*/
  IFX_SIPAPP_380,
  IFX_SIPAPP_400,
  IFX_SIPAPP_401,
  IFX_SIPAPP_402,
  IFX_SIPAPP_403,
  IFX_SIPAPP_404,
  IFX_SIPAPP_405,
  IFX_SIPAPP_406,
  IFX_SIPAPP_407,
  IFX_SIPAPP_408,/*20*/
  IFX_SIPAPP_410,
  IFX_SIPAPP_413,
  IFX_SIPAPP_414,
  IFX_SIPAPP_415,
  IFX_SIPAPP_416,
  IFX_SIPAPP_420,
  IFX_SIPAPP_421,
  IFX_SIPAPP_423,
  IFX_SIPAPP_480,
  IFX_SIPAPP_481,/*30*/
  IFX_SIPAPP_482,
  IFX_SIPAPP_483,
  IFX_SIPAPP_484,
  IFX_SIPAPP_485,
  IFX_SIPAPP_486,
  IFX_SIPAPP_487,
  IFX_SIPAPP_488,
  IFX_SIPAPP_491,
  IFX_SIPAPP_493,
  IFX_SIPAPP_500,/*40*/
  IFX_SIPAPP_501,
  IFX_SIPAPP_502,
  IFX_SIPAPP_503,
  IFX_SIPAPP_504,
  IFX_SIPAPP_505,
  IFX_SIPAPP_513,
  IFX_SIPAPP_600,
  IFX_SIPAPP_603,
  IFX_SIPAPP_604,
  IFX_SIPAPP_606
} e_IFX_SIPAPP_RespCode;


typedef e_IFX_SIP_Return
( *IFX_SIPAPP_SpecReqConst)(
    IN x_IFX_SIPAPP_UAAppData*,
    IN uint32,
    OUT e_IFX_SIP_Ecode*);

typedef e_IFX_SIP_Return
( *IFX_SIPAPP_SpecRespConst)(
    IN e_IFX_SIP_BasicMethod,
    IN uint32,
    IN x_IFX_SIPAPP_UAAppData*,
    OUT e_IFX_SIP_Ecode*);

typedef e_IFX_SIP_Return
( *IFX_SIPAPP_HandleResponse)(
    IN x_IFX_SIPAPP_UAAppData*,
    IN uint32,
    OUT e_IFX_SIP_Ecode*);

typedef e_IFX_SIP_Return
( *IFX_SIPAPP_HandleRequests)(
    IN x_IFX_SIPAPP_UAAppData*,
    IN uint32,
    OUT e_IFX_SIP_Ecode*);

#endif /*__IFX_SIPAPP_TRANSCEIVER_H__*/



