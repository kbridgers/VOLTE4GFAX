/**************************************************************************
**   FILE NAME       : IFX_SIPAPP_TUNegotiate.h
**   PROJECT         : SIP 
**   MODULES         : Transaction User
**   SRC VERSION     : V2.0
**   DATE            : 15-12-2004
**   AUTHOR          : Murali
**   DESCRIPTION     : Function prototypes
**   COMPILER        : gcc
**   REFERENCE       : Coding guide line.
**   COPYRIGHT       : Copyright (c) 2004
**                     Infineon Technologies AG, st. Martin Strasse 53;
**                     81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_TUNEGOTIATE_H__
#define __IFX_SIPAPP_TUNEGOTIATE_H__

#define IFX_SIPAPP_MAX_ADDR                 50

#define IFX_RTP_MODE_SEND_ONLY    1
#define IFX_RTP_MODE_RECV_ONLY    2
#define IFX_RTP_MODE_SEND_RECV    3
#define IFX_RTP_MODE_INACTIVE     4   
#define IFX_RTP_MODE_CLOSE	5

typedef enum{
  IFX_SIPAPP_INACTIVE_DIR = 0,
  IFX_SIPAPP_SENDRECV
}e_IFX_SIPAPP_Direction;

typedef struct {
  /*e_IFX_SIP_CodecType	eCodecType;*/
  /* we support IPV4 and FQDN */
  char8	cRemoteRTPAddr[IFX_SIPAPP_MAX_ADDR];
  uint16	iRemoteRTPPort;
  uint16	iLocalRTPPort;
#ifdef FAX_SUPPORT  
  uint16	iRemoteFaxUdpPort;
  uint16	iLocalFaxUdpPort;
  uint16	iRemoteFaxTcpPort;
  uint16	iLocalFaxTcpPort;
#ifdef STUN_SUPPORT
  uint16        unMappedFAXUDPPort;
#endif
#endif
  uint32	ucSessId;
  uint32	ucConnId;
  uint16	iPayLoadType;
  /* Added for 3264 compliance */
  uint32 uiSessionId;
  uint32 uiSessionVer;
#ifdef RFC_4028
  uint32 uiRemoteSessionVer;
#endif
#ifdef STUN_SUPPORT  
  /*Timer Identifiers and Mapped ports */
  uint16 unNATKARTPPortId;
  uint16 unNATKAFAXPortId;
  uint16  unMappedRTPPort;
  uint16  unMappedRTCPPort;
#endif  
}x_IFX_SIPAPP_RtpInfo;

typedef struct {
  e_IFX_SDP_Mode eMode;
  uchar8 ucCodec;
  uint32 uiRmCodec;
  char8 cRTPAddr[IFX_SIPAPP_MAX_ADDR]; /* Assuming only IPV4 & FQDN */
  uint16 unRTPPort;
  char8 cRTCPAddr[IFX_SIPAPP_MAX_ADDR]; /* Assuming only IPV4 & FQDN */
  uint16 unRTCPPort;
}x_IFX_RemCapInfo;

typedef struct{
  int32 iProfileId;        
  int32 iCodecList;
  e_IFX_SIPAPP_Direction eDir;
  e_IFX_SDP_Mode eLocalMode;  
  uint32 uiSdpMsgHdl; /* For sending Answer */
  /* Remote capability information */
  uchar8 ucNumRemCap;
  x_IFX_RemCapInfo xRemCap[IFX_MAX_CODECS];
  /* Index to the selected codec */
  int16 nLockedCodecEntry;
  /* For Packet time */
  uchar8 ucPacketTime;
#ifdef FAX_SUPPORT 
  x_IFX_FaxParams   *pxT38Capab;
#endif
  /* DTMF information */
  uint16 unDtmfPT;
  char8 acDtmfFmt[IFX_SDPAPP_MAX_ATTR_VALUE];
  /* RTP Information */
  x_IFX_SIPAPP_RtpInfo	xRtpInfo;

  
  /*Connection address and Version flag*/
#define IFX_SIPAPP_USE_CONNADDR_FORHOLD 0x01
#define IFX_SIPAPP_USE_IP_HOLD 0x02
#define IFX_SIPAPP_SDP_SESSIONVER 0x04
#define IFX_SIPAPP_SET_MODE 0x08
/*for RFC 4028*/
#define IFX_SIPAPP_SDP_NOCHANGE 0x40

#ifdef FAX_SUPPORT
#define IFX_SIPAPP_FAX_SETUP 0x10
#define IFX_SIPAPP_SWITCH_TO_VOICE 0x20
#endif
  
  int32 iFlag;
  /*To be used to removed Dns callback id if call is canceled
  x_IFX_SIP_DnsData *pxRtpDnsData;
  x_IFX_SIP_DnsData *pxRtcpDnsData;*/
  char8 cRtpCallBackId;
  
}x_IFX_SIPAPP_SdpInfo;

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SupportDTMF(IN int32 iProfileId,
                    OUT uchar8* ucDynPT);
PUBLIC int32
IFX_SIPAPP_GetRTPMode(e_IFX_SDP_Mode eLocalMode,
                   e_IFX_SDP_Mode eRemoteMode);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NegotiateSdp(IN uint32 uiDecMsgHdl,
    OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
    OUT e_IFX_SIP_Ecode* peEcode);

e_IFX_SIP_Return
IFX_SIPAPP_StoreRemCap(OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
    IN uint32 uiMediaDescHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_StoreSdp(IN uint32 uiMsgHdl,
                 OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                 OUT e_IFX_SIP_Ecode* peEcode);

e_IFX_SIP_Return
IFX_SIPAPP_CheckCodecinFmt(IN uint32 uiMediaHdl,
    IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp);

PUBLIC void
IFX_SIPAPP_AnswerSelectedCodec(IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
    IN_OUT uint32 uiMediaDescHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnswerSdp(IN uint32 uiEncMsgHdl,
                     OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                     OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC void
IFX_SIPAPP_AddAvailableCodecs(IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                              IN_OUT uint32 uiMediaDescHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_OfferSdp(IN uint32 uiEncMsgHdl,
                    OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                    OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CopySdp(IN uint32 uiEncMsgHdl,
                   OUT uint32 uiSdpMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnswerOptionsSdp(IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                            OUT uint32 pxEncMsgHdl,
                            OUT uint32 uiDecMsgHdl,
                            OUT e_IFX_SIP_Ecode* peEcode);

e_IFX_SIP_Return IFX_SIPAPP_NegotiateCodec(IN int32* piCodecType,
                                         OUT uint32 uiMediaHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnswerSdpInactive(IN uint32 uiEncMsgHdl,
                             OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                             OUT e_IFX_SIP_Ecode* peEcode);

e_IFX_SIP_Return
IFX_SIPAPP_ResolveRtpAddress(IN  x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                             OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CheckifSupportedGetIndex(IN uint32 uiRMCodec,
                                    IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                                    OUT int32* piIndex);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetLockedCodecEntry(OUT int16 *pnLockedCodecEntry,
                               IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp);
e_IFX_SDP_Mode
IFX_SIPAPP_GetLocalMode(e_IFX_SDP_Mode eCurrLocalMode,
                        e_IFX_SDP_Mode eRemoteMode);

e_IFX_SIP_Return
IFX_SIPAPP_GetIanaCodec(IN  x_IFX_SIPAPP_SdpInfo* pxSdpInfo,
                        IN  uint32         uiCodec,
                        OUT uchar8*        pucIANAType);

#endif
