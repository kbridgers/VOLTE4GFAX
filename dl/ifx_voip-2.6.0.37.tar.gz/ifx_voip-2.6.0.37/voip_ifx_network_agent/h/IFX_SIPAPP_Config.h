/**************************************************************************
**   FILE NAME       : IFX_SIPAPP_Config.h
**   PROJECT         : SIP 
**   MODULES         : Transaction User
**   SRC VERSION     : V2.0
**   DATE            : 15-12-2004
**   AUTHOR          : SIP Team.
**   DESCRIPTION     : Web configuration data structures.
**   COMPILER        : gcc
**   REFERENCE       : Coding guide lines, 
**                     IFX_SIP-TUDIS
**   COPYRIGHT       : Copyright (c) 2004
**                     Infineon Technologies AG, st. Martin Strasse 53;
**                     81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_CONFIG_H__
#define __IFX_SIPAPP_CONFIG_H__

#define IFX_IPC_SIP_STUN  3

//#define IFX_SIP_DEFAULT_T1 500
//#define IFX_SIP_DEFAULT_PORT 5060
//#define IFX_SIP_DEFAULT_TLS_PORT 5061
#define IFX_SIPAPP_DEFAULT_REG_PORT 59998


/* Constants used to indicate configurations being made */
#define IFX_SIPAPP_CFG_DEBUG      0x01
#define IFX_SIPAPP_CFG_TIMERS     0x02
#define IFX_SIPAPP_CFG_DNSTIMER   0x04
#define IFX_SIPAPP_CFG_DSCPMARK   0x08
#define IFX_SIPAPP_CFG_COMPACTHDR 0x10
#define IFX_SIPAPP_CFG_SERVERPORT 0x20

/* Structure to hold mapping b/w service provider and stackInstnance*/
typedef struct
{
  uint32 uiSrvPrdId;
  uint32 uiStackHdl;
  uint32 uiPort;
  x_IFX_SIPAPP_ParamCfg xSipAppCfg;
  /* Internal Config values used in conjunction with STUN */
	char8 acStunIpAddr[16];
  char8 acMappedAddr[16];
  uint16 unSIPMappedPort;
  uint16 unNATKASignalId;
}x_IFX_SIPAPP_SrvPrd;

extern uint32 vuiNoOfSrvPdrs;
extern x_IFX_SIPAPP_SrvPrd *vpxSrvPdrData;

/* STUN Cfg MACROS*/
#define IFX_SIPAPP_IS_STUNON(uiCfgInst)\
	(strlen(vpxSrvPdrData[uiCfgInst].xSipAppCfg.acStunAddr)>0?1:0)

#define IFX_SIPAPP_GET_NATTYPE(uiCfgInst)\
	(vpxSrvPdrData[uiCfgInst].xSipAppCfg.iNATType)

#define IFX_SIPAPP_GET_STUNPORT(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.unStunPort        
   
#define IFX_SIPAPP_GET_STUNADDR(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.acStunAddr
    
#define IFX_SIPAPP_GET_MAPPEDPORT(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].unSIPMappedPort

#define IFX_SIPAPP_GET_MAPPEDADDR(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].acMappedAddr

#define IFX_SIPAPP_GET_MAPPEDSERVER_PORT(uiCfgInst)\
   vpxSrvPdrData[uiCfgInst].unSIPMappedPort

/*SIP Parameter Cfg MAcros*/
  
#define IFX_SIPAPP_GETPARAMCFG(uiCfgInst)\
       (vpxSrvPdrData[uiCfgInst].xSipAppCfg.pxParamCfg)
        
#define IFX_SIPAPP_GET_UAHDRLEN(uiCfgInst)\
    strlen(vpxSrvPdrData[uiCfgInst].xSipAppCfg.acUserAgentHdr)

#define IFX_SIPAPP_GET_UAHDR(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.acUserAgentHdr    
    
#define IFX_SIPAPP_GET_RTCPATTR(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.ucARtcp    
    
#define IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.unNatKeepAliveTime 
    
#define IFX_SIPAPP_GET_DNSQUERYTIMEOUT(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.unDnsQueryTimeOut     

#define IFX_SIPAPP_GET_REGRETRYTIMEOUT(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.unRegRetryTime    

#define IFX_SIPAPP_GET_REGRETRYATTEMPTS(uiCfgInst)\
    vpxSrvPdrData[uiCfgInst].xSipAppCfg.ucRegRetryAttempts

#define IFX_SIPAPP_GET_USECONNADDRFORHOLD(uiCfgInst)\
    (vpxSrvPdrData[uiCfgInst].xSipAppCfg.ucCallOnHold == IFX_USE_ZERO_ADDR_ONHOLD)

#define IFX_SIPAPP_GET_DNSTIMEOUT(uiCfgInst)\
    (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.unDnsQueryTimeOut)
    
#define IFX_SIPAPP_GET_T1(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.unT1)
        
#define IFX_SIPAPP_GET_TMAX(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.unTmax)
        
#define IFX_SIPAPP_GET_SERVERPORT(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.unServerPort)
        
#define IFX_SIPAPP_GET_SERVERTRANSPORT(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.ucTransportType)

#define IFX_SIPAPP_IS_ACCEPT_UNSOL_NOTIFY(uiCfgInst)\
  ((vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.ucAcceptUnSolNotify == IFX_ON)? IFX_SIP_TRUE:\
  IFX_SIP_FALSE)

#define IFX_SIPAPP_GET_DSCPCODE(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.ucDSCPMark)

/*Dbg Configuration*/
#define IFX_SIPAPP_GET_DBGTYPE(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.ucDbgType)
	
#define IFX_SIPAPP_GET_DBGLVL(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.ucDbgLvl)

#define IFX_SIPAPP_GET_T38CONN(uiCfgInst)\
   (vpxSrvPdrData[uiCfgInst].xSipAppCfg.xT38Cfg.ucT38Conn)

#define IFX_SIPAPP_GETARTCP(uiCfgInst)\
	(vpxSrvPdrData[uiCfgInst].xSipAppCfg.ucARtcp)
        
/* SIP Configuration Init to initialize all data*/
e_IFX_SIP_Return IFX_SIPAPP_CfgInit(uint32);

void IFX_SIPAPP_GetServerPort(uint32 uiSrvPdr,uint16* pnServPort);

#define IFX_SIPAPP_IS_PROXYON(pxAppData)\
	(strlen(pxAppData->acProxyAddr)>0?1:0)

#define IFX_SIPAPP_ISOUTBOUND(pxAppData)\
	(pxAppData->ucIsOutBoundProxy)

#define IFX_SIPAPP_GET_PROXYPORT(pxAppData)\
    (pxAppData->unProxyPort)

#define IFX_SIPAPP_GET_PROXYADDRESS(pxAppData)\
    (pxAppData->acProxyAddr)

#define IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData)\
    (pxAppData->eProxyProtocol)

#define IFX_SIPAPP_GET_REGTRANSPORT(pxRegAttr)\
	(pxRegAttr->ucTransport)

#define IFX_SIPAPP_GET_REGPORT(pxRegAttr)\
	(pxRegAttr->unPort)

#define IFX_SIPAPP_GET_REGADDR(pxRegAttr)\
	(pxRegAttr->pcRegistrar)

#define IFX_SIPAPP_GETMEDIACFG(pxAppData)\
	(&((x_IFX_SIPAPP_UAAppData*)pxAppData)->xCodecList)

#define IFX_SIPAPP_FAXCFG(pxAppData)\
	(((x_IFX_SIPAPP_UAAppData *)pxAppData)->axFaxParams)

#define IFX_SIPAPP_GET_FAX_TCP_PORT(pxAppData)\
	((x_IFX_SIPAPP_UAAppData *)pxAppData)->axFaxParams[1].uiLocalFaxPort

#define IFX_SIPAPP_GET_FAX_UDP_PORT(pxAppData)\
	((x_IFX_SIPAPP_UAAppData *)pxAppData)->axFaxParams[0].uiLocalFaxPort

#endif /* __IFX_SIP_CONFIG_H__ */

