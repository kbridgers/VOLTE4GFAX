/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Prack.h
**   PROJECT       : SIP
**   MODULES       : For all SIP modules.
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team
**   DESCRIPTION   : Function prototypes for PRACK handling.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines , DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_PRACK_H__
#define __IFX_SIPAPP_PRACK_H__

/*! \method     IFX_SIP_1xxRelConst
    \brief      This API contstructs reliable provisional response.
    \param[in]  uiMsgHdl is referecne to Sip Message.
    \param[in]  pxAppData is reference to Application Data.
    \param[out] peEcode is refernce to Error Code.
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_1xxRelConst(IN uint32 uiMsgHdl,
                    IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    OUT e_IFX_SIP_Ecode* peEcode);


/*! \method     IFX_SIP_101to199Handler
    \brief      This API Handles reliable/non-reliable provisional responses 
    \param[in]  pxAppData is reference to Application Data.
    \param[in]  uiMsgHdl is reference to Sip Message.
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_101to199Handler(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                        IN uint32 uiMsgHdl);


/*! \method     IFX_SIP_PRACKConst
    \brief      This API constructs PRACK request. 
    \param[in]  pxAppData is refernce to Application Data.
    \param[out] uiMsgHdl is refernce to Sip Message.
    \param[out] peEcode is refernce to Error Code.
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_PRACKConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                   OUT uint32 uiMsgHdl,
                   OUT e_IFX_SIP_Ecode* peEcode);

/*! \method     IFX_SIP_FinalPRACKHandling
    \brief      Applies rules for matching PRACK request handling.
    \param[in]  pxAppData is reference to Application Data.
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_FinalPRACKHandling(IN x_IFX_SIPAPP_UAAppData *pxAppData);


/*! \method     IFX_SIP_SetRequrie.
    \brief      This API encodes Require header field with 100rel Tag.
    \param[in]  pxAppData is reference to Application Data.
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/


e_IFX_SIP_Return
IFX_SIPAPP_SetRequire(OUT uint32 uiMsgHdl);

/*! \method     IFX_SIPAPP_HandlePrack.
    \brief      This API handles incoming PRACK request.
    \param[in]  pxAppData is reference to Application Data.
	\param[in]  uiMsgHdl incoming message handle
	\param[out]  peEcode error code
    \return     IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandlePrack(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                       IN uint32 uiMsgHdl,
                       OUT e_IFX_SIP_Ecode* peEcode);

#endif

