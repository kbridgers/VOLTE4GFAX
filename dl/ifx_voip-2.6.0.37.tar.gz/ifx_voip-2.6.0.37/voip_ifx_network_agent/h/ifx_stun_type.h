/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
/* ====================================================================
 *
 * File Name: ifx_stun_types.h
 * Author: Eric Tsai
 * Date:
 *
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/types>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References:
 */

#ifndef __IFX_STUN_TYPE_H__
#define __IFX_STUN_TYPE_H__
#if 0
typedef char			char8;
typedef unsigned char		uchar8;
typedef char			int8;
typedef unsigned char		uint8;
typedef short 			int16;
typedef unsigned short		uint16;
typedef int			int32;
typedef unsigned int		uint32;
typedef long long		int64;
typedef unsigned long long	uint64;
typedef float			float32;
typedef double			float64;
#endif
#endif
typedef char			Boolean;

/* ====================================================================
 * Revision History:
 *
 * $Log: ifx_stun_types.h,v $
 * Revision 1.2  2004/05/17 12:47:04  erict
 * Add file header comments
 *
 * ====================================================================
 */

