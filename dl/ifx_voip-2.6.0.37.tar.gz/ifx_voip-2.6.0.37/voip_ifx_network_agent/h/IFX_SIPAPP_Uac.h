/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Uac.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE     	   : 
**   AUTHOR        : 
**   DESCRIPTION   : This file contains transaction user client functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS ,  DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_UAC_H__
#define __IFX_SIPAPP_UAC_H__

extern IFX_SIPAPP_HandleResponse pfnHandleResponse[];
extern IFX_SIPAPP_SpecReqConst pfnSpecReqConst[];

typedef struct
{
  int32 iEndPtHdl;
  int32 iMsgHdl;
  int32 iAppHdl;
  int32 iDlgHdl;
  char8 szMethod;
}x_IFX_SE_TimerInfo;


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AppDataInit(IN x_IFX_SIPAPP_UAAppData* pxAppData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InviteConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    OUT uint32 uiMsgHdl,
                    OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AckConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT uint32 uiMsgHdl,
                 OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ByeConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT uint32 uiMsgHdl,
                 OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CancelConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    OUT uint32 uiMsgHdl,
                    OUT e_IFX_SIP_Ecode* peEcode);

e_IFX_SIP_Return 
IFX_SIPAPP_183RespHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                    IN uint32 uiMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle1XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle2XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle2XXInvite(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                        IN uint32 uiMsgHdl,
                        OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle3XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle4XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle5XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle6XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode);
e_IFX_SIP_Return
IFX_SIPAPP_183RespHdlr(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    IN uint32 uiMsgHdl);
#endif
