/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Platform.h
**   PROJECT       : SIP
**   MODULES       : For all SIP modules.
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team
**   DESCRIPTION   : Function prototypes for OS dependent functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines , DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIPAPP_PLATFORM_H__
#define __IFX_SIPAPP_PLATFORM_H__

#include <stdarg.h>
#ifdef __IMSENV__
#include <stdio.h>
#include "ifx_mmb_env.h"
#endif /*__IMSENV__*/

#ifdef __LINUX__
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <features.h>
#include <ctype.h>
#include <netdb.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <time.h>
#include <sys/param.h>
#include <sys/utsname.h>
#include <netdb.h>
#include <asm/socket.h>
#include <asm/ioctls.h>
#include<pthread.h>
#include<arpa/nameser.h>
#include<resolv.h>
#include<netdb.h>
#endif /* __LINUX__*/

#define IFX_SIPAPP_PROTOCOL_TCP 1
#define IFX_SIPAPP_PROTOCOL_UDP 2

#define IFX_SIPAPP_TCP_SOCKTYPE_CLIENT 1
#define IFX_SIPAPP_TCP_SOCKTYPE_SERVER 2

#define IFX_SIPAPP_MAX_UDP_MESG 8192
#define IFX_SIPAPP_INTERNAL_PORT 9090

#define IFX_IPC_SIPAPP_TIMER 2
#ifdef STUN_SUPPORT
#define IFX_IPC_SIPAPP_STUN  3
#endif


/*************String Funcitons ***********/
#define IFX_SIPAPP_Strcmp strcmp
#define IFX_SIPAPP_Strcpy strcpy
#define IFX_SIPAPP_Strncpy strncpy
#define IFX_SIPAPP_Strlen strlen
#define IFX_SIPAPP_Strcasecmp strcasecmp

/********** File Descriptor Operations **********/
#ifdef __LINUX__
typedef fd_set IFX_SIPAPP_fd_set;
#define IFX_SIPAPP_FdZero(pFdSet) FD_ZERO(pFdSet)
#define IFX_SIPAPP_FdIsSet(iFd, pFdSet) FD_ISSET(iFd, pFdSet)
#define IFX_SIPAPP_Read(iFd, pcRead, iSize) read(iFd, pcRead, iSize)
#define IFX_SIPAPP_Write(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)
#define IFX_SIPAPP_Close(Fd) close(Fd)
#endif /*__LINUX__*/





#ifdef __IMSENV__
typedef T_Mmb_SIfxSockFdSet IFX_SIPAPP_fd_set;
int32 IFX_SIPAPP_FdIsSet(int32 iFd, IFX_SIPAPP_fd_set *pFdSet);
int32 IFX_SIPAPP_Close(int32 Fd);
void IFX_SIPAPP_FdZero(T_Mmb_SIfxSockFdSet *pFdSet);
#endif/*__IMSENV__*/


void IFX_SIPAPP_FdSet(int32 iFd, IFX_SIPAPP_fd_set *pFdSet);
void IFX_SIPAPP_FdClear(int32 iFd, IFX_SIPAPP_fd_set *pFdSet);

void IFX_SIPAPP_AddToFDSet(int32 iSockFd,
                           IFX_SIPAPP_fd_set* pxFdSet);

void IFX_SIPAPP_RemoveFromFDSet(int32 iSockFd,
                                IFX_SIPAPP_fd_set* pxFdSet);

int32 IFX_SIPAPP_IsFDSet(int32 iSockFd,
                         IFX_SIPAPP_fd_set* pxFdSet);


/********** Memory Operations **********/

#define memset(pvDst, iChar, uiSize) memset(pvDst, iChar, uiSize)

#define memcpy(pvDst, pvSrc, uiSize) memcpy(pvDst, pvSrc, uiSize)

#define memcmp(pPtr1,pPtr2,uiSize) memcmp(pPtr1,pPtr2,uiSize)

#define memmove(pvDst,pvSrc,nBytes) memmove(pvDst,pvSrc,nBytes)




/********** String Operations **********/
#define strlen(pcPtr) strlen(pcPtr)
#define strcpy(pcDst,pcSrc) strcpy(pcDst,pcSrc)
#define strncpy(pcDst,pcSrc,nBytes) strncpy(pcDst,pcSrc,nBytes)
#define strcat(pcDst,pcSrc) strcat(pcDst,pcSrc)
#define strncat(pcDst,pcSrc,nBytes) strncat(pcDst,pcSrc,nBytes)
#define puts(pcString) puts(pcString)

int32
IFX_SIPAPP_strncasecmp(const char* pszString1,
                       const char* pszString2,
                       int32 iSize);
int32
IFX_SIPAPP_strcasecmp(const char* pszString1,
                      const char* pszString2);




/********** Network Operations **********/
PUBLIC char8
IFX_SIPAPP_GetHostIp(OUT char8 * pcHostIp);


void
IFX_SIPAPP_CloseSocket(int32 iSockFd);

PUBLIC char8
IFX_SIPAPP_SendSockMsg(IN int32 iFd, 
                IN uchar8 ucFrom, 
                IN uchar8 ucTo,   
                IN uint16 unMsgSize,
                IN uint32 uiReserved,
                IN char8 * pcMsg,
				IN char8 *pcHostIP);
PUBLIC char8
IFX_SIPAPP_RecvSockMsg(IN int32 iFd,
                OUT uchar8 * pucFrom,
                OUT uchar8 * pucTo,
                OUT uint16 * punMsgSize,
                OUT uint32 * puiReserved,
                OUT char8 * pcMsg,
                OUT char8 * pErr);
EXTERN int32
IFX_SIPAPP_CreateSocket(IN uchar8 ucProtocol,
                    IN uint16 unLocalPort,
                    IN uint16 unRemotePort,
                    IN char8 * pacLocalIpAddress,
                    IN char8 * pacRemoteIpAddress,
                    IN uchar8 ucTcpSocketType);

e_IFX_SIP_Return IFX_SIPAPP_SocketInit();




/*************** Memory Operations ***************/

#define IFX_SIPAPP_Malloc(iBytes) IFX_OS_Malloc(iBytes)
#define IFX_SIPAPP_Calloc(uiNum,iBytes) IFX_OS_Calloc(uiNum,iBytes)
#define IFX_SIPAPP_Free(pcFree) IFX_OS_Free(pcFree)

#ifdef MEM_DBG
#define IFX_OS_Calloc(iNum,iSize) IFX_OS_CallocDbg(iNum,iSize,__FILE__,__LINE__)

#define IFX_OS_Malloc(iSize)  IFX_OS_CallocDbg(1,iSize,__FILE__,__LINE__)

#define IFX_OS_Free(pcFree)  (IFX_OS_FreeDbg(pcFree,__FILE__,__LINE__))

#endif


/**************** Environment Functions **********************/
#ifdef __LINUX__
#define IFX_SIPAPP_GetEnv(pcEnvVarName) getenv(pcEnvVarName)
#endif /*__LINUX__*/



/***********************Thread**********************/
uint32 IFX_SIPAPP_CreateThread( void * (*start_routine)(void *),void* pvParam);

#ifdef __LINUX__
#define IFX_SIPAPP_ThreadExit(pRet)  pthread_exit(pRet)
#define IFX_SIPAPP_ThreadSelf() pthread_self()
#define IFX_SIPAPP_ThreadCleanUpPush(Pfn,Id) pthread_cleanup_push(Pfn,Id)
#define IFX_SIPAPP_ThreadCleanUpPop(x) pthread_cleanup_pop(x)
#endif /*__LIUX__*/


#ifdef __IMSENV__
void IFX_SIPAPP_ThreadExit(int iRet);
int32 IFX_SIPAPP_ThreadSelf(void);
IFX_SIPAPP_ThreadCleanUpPush(void *Pfn, short Id);
IFX_SIPAPP_ThreadCleanUpPop(int x);
int32 IFX_SIPAPP_Close(int32 Fd);
int32 IFX_SIPAPP_Time(int32 *t);
#endif /*__IMSENV__*/

uint32 IFX_SIPAPP_RandomNumber();

/****************************TIMER******************************/

#define IFX_SIPAPP_MAX_TIMER_BUFF 20

typedef struct {
  char8 cIsFree;
  uint16 unTimerId;
  void( *pfnCallBackFn)(void*);
  void* pCallBackFnParam;
  /* Added for carrying extra information */
  char8 acBuff[IFX_SIPAPP_MAX_TIMER_BUFF];
#ifdef __IMSENV__
  void* pvTimerId;
  int32 iFired;
#endif
}x_IFX_SIPAPP_TimerInfo;


PUBLIC e_IFX_SIP_Return IFX_SIPAPP_TimerInit();

PUBLIC void IFX_SIPAPP_ProcessTimerMsg(IN x_IFX_SIPAPP_TimerInfo *pxTimerInfo);

EXTERN PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_StartTimer(IN uint32 uiTimeOutValue, /* milli seconds */
    IN void* pfn_IFX_SIP_CallBackFn,
    IN void* pCallBackFnParam,
    OUT uint16* punTimerId,
    OUT uint32* peEcode);

EXTERN e_IFX_SIP_Return IFX_SIPAPP_StopTimer(uint16);

EXTERN void IFX_SIPAPP_StopAllTimers(void);

#endif /*__IFX_SIPAPP_PLATFORM_H__*/
