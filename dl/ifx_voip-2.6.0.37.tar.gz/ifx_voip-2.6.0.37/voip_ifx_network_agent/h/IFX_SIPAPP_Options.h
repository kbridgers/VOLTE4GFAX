/****************************************************************************
**   FILE NAME     : IFX_SIPAPP_Options.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains phone application inteface functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_SIPAPP_OPTIONS_H__
#define __IFX_SIPAPP_OPTIONS_H__

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendOptionsResp(IN void *pvPvtData,
                        IN int32 iFlag, IN int32 iReason,
                        IN x_IFX_CalledAddr *pxCalledAddr);
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_3xxOptionsHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                       IN uint32 uiMsgHdl);
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_4xxOptionsHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                       IN uint32 uiMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_OptionsHdlr(IN uint32 uiDlg,
                    IN uint32 uiOptionsHdl,
                    IN x_IFX_SIPAPP_UAAppData *pxAppData,
                    IN uint32 uiMsgHdl);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_OptionsRegCallbacks(uint32 uiStackHdl);
#endif
