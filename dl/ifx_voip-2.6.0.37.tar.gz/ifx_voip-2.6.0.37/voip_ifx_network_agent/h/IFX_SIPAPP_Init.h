/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Init.h
**   PROJECT       : SIP
**   MODULES       : NetworkAgent Init
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team.
**   DESCRIPTION   : Function prototypes NetworkAgent functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIPAPP_Init.h
    \brief This File contains the Network Agent Init and Configuration Functions, with
           few enumerations used within all SIP API's.
*/
 /** \defgroup NetAgent APIs for Network Agent configuration and initialization
    \brief This section lists the APIs for configuring the Network agent and Initializing it.
*/
/* @{ */

#ifndef __IFX_SIPAPP_INIT_H__
#define __IFX_SIPAPP_INIT_H__


/*! \brief  Initilzes NetAgent.
    \param[in] uiNoOfSrvPdr Number of Service Providers to be supported.
	\return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_Init(IN uint32 uiNoOfSrvPdr);


/*! \brief   Api to ShutDown the NetworkAgent
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_Shut(void);


/*! \brief  Creates a ServiceProvider.
    \param[in] uiSrvPdrId Service Provider Id.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_CreateSrvPdr(IN uint32 uiSrvPdrId);
			             

/*! \brief  Destroy ServiceProvider.
    \param[in] uiSrvPdrId Service Provider Id.
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE.
*/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_DestroySrvPdr(IN uint32 uiSrvPdrId);

/*! \brief  Get the Configuration instance for the ServiceProvider specified.
    \param[in] uiSrvPdrId Service Provider Id.
    \return index to the service provider instance.
*/
int32 IFX_SIPAPP_GetSrvPdrInst(uint32 uiSrvPdrId);

/*! \struct x_IFX_SIPAPP_ParamCfg
    \brief A structure defining configuration Parameters of Stack
 */
typedef struct
{
 x_IFX_SIP_StackParamCfg xParamCfg;/*!< Stack Config Values*/
 char8 acOrganization[128];/*!< Organisation header value*/
 char8 acUserAgentHdr[128];/*!< User Agent Header Value*/
 char8 ucTransportType;/*!< Server Transport Type*/
 char8 ucCallOnHold;/*!< Connection address to be used on hold*/
#ifdef STUN_SUPPORT
  char8 acStunAddr[128];/*!< Stun Server Address*/
  uint16 unStunPort;/*!< Stun Server Port Number*/
	uint16 unNatKeepAliveTime;/*!< Nat Keep alive Time*/
	uint32 iNATType;/*!< Nat Type*/
#endif
  uint16 unRegRetryTime;/*!< Registration retry timer*/
  uchar8 ucRegRetryAttempts;/*!< Registration Max Retries*/

}x_IFX_SIPAPP_ParamCfg;

/*!\define IFX_SIPAPP_STUNCFG
   \brief Change in Stun Configurations
*/
#define IFX_SIPAPP_STUNCFG 0x1

/*!\define IFX_SIPAPP_DBGCFG
   \brief Change in Debug Configurations
*/
#define IFX_SIPAPP_DBGCFG 0x2


/*!\define IFX_SIPAPP_STACKCFG
   \brief Change in SipStack Configurations
*/
#define IFX_SIPAPP_STACKCFG 0x4

/*!\define IFX_SIPAPP_DOMAIN
   \brief Change in Domain Configurations
*/
#define IFX_SIPAPP_DOMAIN 0x8


/*! \brief  Configure ServiceProvider.
    \param[in] uiSrvPdrId Service Provider Id.
    \param[in] ucOptions Options to indicate the change in config parameter
    \param[in] This is a variadic function and accepts pointer to struct x_IFX_SIPAPP_ParamCfg
	\note The third parameter is optional,due to configuration parameters may
	      be fetched from a configuration manager or provided directly by the application
		  based on the service provider identifer
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_CfgSrvPdr(IN uint32 uiSrvPdrId,
  		                                     IN uchar8 ucOptions,...);



/*! \struct x_IFX_SIPAPP_RouteParams
    \brief A structure defining Routing params for the SIP Request.
 */
typedef struct{
  x_IFX_CalledAddr *pxTo;/*!< To Address*/
  x_IFX_CalledAddr *pxFrom;/*!< From Details*/
  uint16 unLocalTcpPort;/*!< Local Tcp Port*/
  char8 *pcProxyAddr;/*!< Proxy Address*/
  uint16 unProxyPort;/*!< Proxy Port*/
  e_IFX_SIP_Protocol eProxyProtocol;/*!< Proxy Protocol*/
  uchar8 ucIsOutBoundProxy; /*!< Is Outbound Proxy*/
  boolean  bSupressCallerId;/*!< Supress Caller Identifer*/
}x_IFX_SIPAPP_RouteParams;

/*! \struct x_IFX_SIPAPP_CallParams
    \brief A structure defining application specific features to be included in SIP request.
 */
typedef struct{
  x_IFX_MediaParams xMediaParams;/*!< Media Parameters*/
  uint32 uiReplacesCallId;/*!< Replace Call Identifier*/
  boolean  bEmergency;/*!< Is Emergency Call*/
	char8 szPhoneNumber[32];/*Remote Party Phone Number*/
}x_IFX_SIPAPP_CallParams;

/*! \enum e_SIPAPP_Events
    \brief Signals given by the SIPAPP Module to the application.
*/
typedef enum
{
  IFX_INCOMINGCALL_SIGNAL =1,/*!< Incoming Call  */
  IFX_CALLPROG_SIGNAL,/*!< Call in progress state */
  IFX_ALERT_SIGNAL,/*!< Call in ringing */
  IFX_RELEASE_SIGNAL,/*!< Call released  */
  IFX_CONNECTED_SIGNAL,/*!< Call connected */
  IFX_STOPTONE_SIGNAL,/*!<  */
  IFX_CALL_AUTH_REQD,/*!< Call Authentication required */
  IFX_HOLD_SUCCESS,/*!< Local Hold was Success */
  IFX_HOLD_FAIL,/*!< Local Hold Failed */
  IFX_RESUME_SUCCESS,/*!< Local Resume Success  */
  IFX_RESUME_FAIL,/*!< Local Resume Fail */
  IFX_CALL_QUEUE,/*!<  Call In Queue*/
  IFX_CALL_FWD_ADDR,/*!< Call Redirected  */
  IFX_REMOTE_HOLD, /*!< Remote Held call */
  IFX_REMOTE_RESUME,/*!< Remote Resumed Call */
  IFX_EARLY_MEDIA,/*!< Media in 183 */

  IFX_REFER_RECV,/*!< Refer Req Arrived*/
  IFX_REFER_STATUS_RECV,/*!< Refer Request's response arrived*/
  IFX_REFER_NOTIFY_RECV,/*!< Notify for Refer request arrived*/
  IFX_REFER_NOTIFY_STATUS_RECV,/*!< Notify's response arrived*/
  IFX_REFER_AUTH_REQD,/*!< Authentication required for Refer*/

  /*REGISTER*/
  IFX_REG_STATUS,/*!< Registration Status */
  IFX_REG_AUTH_REQ,/*!< Registration authentication required */
  IFX_REG_TIME_OUT,/*!< Registration Time Out*/

  IFX_CALLBACK_SUBSC_RECV,/*!< Subscribe for Automatic Call Back Arrived */
  IFX_CALLBACK_SUBSC_STATUS_RECV,/*!< Response for Automatic Call Back Subscribe Arrived */
  IFX_CALLBACK_NOTIFY_RECV,/*!< Notify for Automatic Call Back Subscribe Arrived */
  IFX_CALLBACK_NOTIFY_STATUS_RECV,/*!< Response for Automatic Call Back Notify Arrived */
  IFX_CALLBACK_AUTH_REQD,/*!< Authentication required for Automatic Call Back */

  IFX_MWI_SUBSC_STATUS_RECV,/*!< Response for MWI Subscribe Arrived */
  IFX_MWI_NOTIFY_RECV,/*!< Notify for MWI Subscribe Arrived */
  IFX_MWI_AUTH_REQD,/*!< Authentication required for MWI */

  IFX_SUBSCRIBE,/*!< Subscription Request Arrived */
  IFX_SUBSCRIBE_STATUS,/*!< Sending Subcription Status  */
  IFX_NOTIFY,/*!< Notify Arrived */
  IFX_NOTIFY_STATUS,/*!< Sending Notify Status */
  IFX_OPTIONS,/*!<  Options Arrived*/
  IFX_OPTIONS_ACCEPT,/*!< Sending Options Success */
  IFX_OPTIONS_REJECT,/*!< Sending Option Request Failed */
#ifdef MESSAGE_SUPPORT
  IFX_MSG,/*!< Message Arrived */
  IFX_MSG_FAIL,/*!< Sending Message Failed */
  IFX_MSG_SUCCESS,/*!< Sending Message Success */
  IFX_MSG_AUTH_REQ,/*!< Authentication required */
#endif
#ifdef INFO_SUPPORT
  IFX_INFO,/*!<INFO Request Arrived */
  IFX_INFO_FAIL,/*!< Sending Info request Failed */
  IFX_INFO_SUCCESS,/*!< Sending Info Success */
#endif
  IFX_MEDIA_UPDATE,/*!< Media Update Arrived*/
  IFX_MEDIA_UPDATE_SUCCESS,/*!< Sending Media Update Success */
  IFX_MEDIA_UPDATE_FAILURE,/*!< Sending Media Update Fail */
  IFX_SDP_ANSWER,/*!< recived Answer of SDP in ACK/PRACK*/
  IFX_INIT_SUCCESS,/*!< Init Success */
  IFX_INIT_FAIL,/*!< Init Fail */
  IFX_MAX_SIGNAL
} e_SIPAPP_Events;


/*! \struct x_IFX_SIPAPP_IncomingCall
    \brief A structure defining Event Data to be provided to upper application.
	       On a Incomming Call
 */
typedef struct{
  x_IFX_CalledAddr xUserCfg;/*!< From address */
  x_IFX_CalledAddr xCalledAddr;/*!< To address */
  uint32 uiExpires;/*!< Session expires*/
  int32 iConnId2;/*!< If replaces exsits*/
  int32 iCodecList;/*!< Codec List*/
#ifdef IFX_INTERCOM_SUPPORT
  uchar8 ucIntercomCall;/*!< InterCom Call*/
#endif
  void *pvPrivateData;/*!< Application Private Data*/
}x_IFX_SIPAPP_IncomingCall;


/*! \struct x_IFX_SIPAPP_ReferRecvd
    \brief A structure defining Refer Data to be provided to upper application.
	       On a receiving Refer.
 */
typedef struct
{
  x_IFX_CalledAddr xTargetAddr; /*!< Pointer to transfer target's address */
  uint32 uiReplacesCallId; /*!< CallId in case Refer with Replaces arrived */
	void *pvAppData;/*!< Application Private Data*/
}x_IFX_SIPAPP_ReferRecvd;

/*! \struct x_IFX_SIPAPP_ReferStatus
    \brief A structure defining Refer Data to be provided to upper application.
	       On a receiving a Refer's response or a Notify or its response.
 */
typedef struct
{
  void *pvAppData;/*!< Application Private Data*/
  uchar8 eTransferStatus; /*!< State of the transfer */
  e_IFX_ReasonCode eReason; /*!< Reason */
	char8 ucIsAtx;/*!< is ATx */
}x_IFX_SIPAPP_ReferStatus;


/*! \struct x_IFX_SIPAPP_Register
    \brief A structure defining Event Data to be provided to upper application.
	       On a reciveing Registration.
 */
typedef struct{
  uint32 uiExpires;/*!< Registration Expiry */
  char8 cRegStatus;/*!< Registration Status, IFX_SIP_FAILURE/IFX_SIP_SUCCESS */
  e_IFX_ReasonCode eReason; /*!< Reason */
}x_IFX_SIPAPP_Register;


/*! \struct x_IFX_SIPAPP_CBSubscRecvd
    \brief A structure defining Event Data to be provided to upper application.
	       On a reciveing Subscribe.
 */
typedef struct{
  void *pvAppData;/*!< Application Private Data*/
  uchar8 eCBSubscStatus;/*!< Subscription Status*/
  e_IFX_ReasonCode eReason;/*!< Reason Code*/
	x_IFX_CalledAddr *pxTo;
	x_IFX_CalledAddr *pxFrom;
	uint32 uiExpires;
	uint32 uiReqId;
}x_IFX_SIPAPP_CBSubscRecvd;

/*! \struct x_IFX_SIPAPP_CBNotifyRecvd
    \brief A structure defining Event Data to be provided to upper application.
	       On a reciveing Notify.
 */
typedef struct
{
  void *pvAppData;/*!< Application Private Data*/
  uint32 uiExpires;/*!< Expires Recived in Notify*/
  uchar8 eCBSubscStatus;/*!< Subscription Status*/
  e_IFX_ReasonCode eReason;/*!< Reason Code*/	
	x_IFX_CalledAddr *pxTo;/*!< To Address*/
	x_IFX_CalledAddr *pxFrom;/*!< From Address*/	
  boolean bIsRemoteFree;/*!< is Remote Entity Free*/
}x_IFX_SIPAPP_CBNotifyRecvd;


/*! \struct x_IFX_SIPAPP_VMNotifyRecvd
    \brief A structure defining Event Data to be provided to upper application.
	       On a reciveing MWI Notify.
 */
typedef struct
{
  void *pvAppData;/*!< Application Private Data*/
  uint32 uiExpires;/*!< Expires in Notify Body*/
  uchar8 eSubscStatus;/*!< Subscription Status*/
  e_IFX_ReasonCode eReason;/*!< Reason Code*/
  x_IFX_CalledAddr *pxTo;/*!< To Address*/
	x_IFX_CalledAddr *pxFrom;/*!< From Address*/		
	boolean  bNewMsg; 
	uint16  unNumOfUnread;
	uint16  unTotalMsg; 					
}x_IFX_SIPAPP_VMNotifyRecvd;

/*! \struct x_IFX_SIPAPP_SubscNotifyStatus
    \brief A structure defining Event Data to be provided to upper application.
	       On a reciveing Subscribe or Notify response.
 */
typedef struct
{
  uchar8 eSubscStatus;/*!< Subscription Status*/
  e_IFX_ReasonCode eReason;/*!< Reason Code*/
  uint32 uiExpires;/*!< Expires in Notify Body*/
}x_IFX_SIPAPP_SubscNotifyStatus;


/*! \struct x_IFX_SIPAPP_AuthReqd
    \brief A structure defining Event Data to be provided to upper application.
	       On a reciveing a request for authentication.
 */
typedef struct
{
  uint32 uiHdl;
  uint32 uiDlgHdl;
  char8 *pcRealm;/*!< Realm*/
  uint32 uiSipMsgHdl;
  void *pvPvtData;/*!< Application Private Data*/
}x_IFX_SIPAPP_AuthReqd;

/*! \struct x_IFX_SIPAPP_Msg
    \brief A structure defining Event Data to be provided to upper application.
	       On a Message.
 */
#ifdef MESSAGE_SUPPORT
typedef struct{
  char8 *szTo;/*!< To Address */
  char8 *szFrom;/*!< From Address */
  uint32 uiExpires;/*!< Message Validity */
  char8 acMessg[100];/*!< For message bodies */
}x_IFX_SIPAPP_Msg;
#endif


/*! \enum e_IFX_INFO_METHOD_DTMF_Event
    \brief Info Event Type.
*/
typedef enum
{
	IFX_INFO_DTMF_RELAY_CONTENT,
	IFX_INFO_DTMF_CONTENT
} e_IFX_INFO_METHOD_DTMF_Event;


/*! \struct x_IFX_InfoMethod
    \brief A structure defining Info Event Type
 */
typedef struct
{
	e_IFX_INFO_METHOD_DTMF_Event eEvent;
	uchar8 ucDigit;
	uint16 unDuration;
}x_IFX_InfoMethod;


typedef void (*pfn_IFX_SIPAPP_FdCallback)(IN IFX_SIPAPP_fd_set *pxRdFdSet,
										                      IN IFX_SIPAPP_fd_set *pxWrFdSet,
                     										  IN IFX_SIPAPP_fd_set *pxExFdSet,
									                        IN int32 *piFd);

/*! \struct 
    \brief A structure defining Event to be provided to upper application.
	       
 */
typedef struct {
  e_IFX_SIP_Return (*pfStateNotifier)(IN_OUT uint32 *puiCallId,
                                      IN e_SIPAPP_Events eEvent,
                                      IN void *pxEventData); /*!< Sip Event Notifer*/

  e_IFX_SIP_Return (*pfAddFdToSelect)(int32 iFd,uchar8 ucFdType,
	                                  pfn_IFX_SIPAPP_FdCallback);/*!< Addition of FD notifer*/

  e_IFX_SIP_Return (*pfRemoveFdFromSelect)(int32 iFd,uchar8 ucFdType);/*!< Removal of FD notifier*/

}x_IFX_SIPAPP_Notifiers;



extern x_IFX_SIPAPP_Notifiers vpxNotifier;

/*! \brief Register State Notification
    \param[in] xNotifer Notify callbacks
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RegNotfiers(x_IFX_SIPAPP_Notifiers *pxNotifier);



#endif /*__IFX_SIPAPP_INIT_H__*/
