
#ifndef __IFX_SIPAPP_INSTMSG_H__
#define __IFX_SIPAPP_INSTMSG_H__

#ifdef CMGR
#define IFX_SIPAPP_MAX_MSG_SIZE IFX_VGS_CMGR_SMS_MAX_BODY_SZ

#else
#define IFX_SIPAPP_MAX_MSG_SIZE 160

#endif


/*! \struct x_IFX_Msg
    \brief Structure to notify Phone/Gateway application about new incoming message
*/

typedef struct
{
  x_IFX_CalledAddr xFrom; /*<! Message sender*/
  x_IFX_CalledAddr xTo;  /*<! Message receiver*/
  uint32 uiExpires;		/*<! Message expire time*/
  char8 acMessg[IFX_SIPAPP_MAX_MSG_SIZE]; /*<! Received message body>*/
  void *pvPrivateData; /*<! Reference to NA's internal data structure*/
}x_IFX_Msg;


/*! \enum e_IFX_SIPAPP_Msg
    \brief Reason code to be used if incoming message is rejected.
*/
typedef enum
{
	IFX_MSG_FWD,			/*<!Message Forwarded*/
	IFX_MSG_INBOX_FULL,	/*<! Inbox Full*/
	IFX_MSG_NOT_FOUND,   /*<! User Not found*/
}e_IFX_SIPAPP_Msg;		


/*!  \brief     API to send to Instant Message
     \param[in] uiMsgId is message identifier for MESSAGE transaction.
	 \parma[in] uiSrvPrdId is service provider's Id.
	 \param[in] pxRouteParam is reference to Route parametes
	 \param[in] pcMsg is reference to Message body.
	 \param[in_out] ppvPvtData Pointer to NA's internal structure for this dialog.
	 \return IFX_SIP_FAILURE or IFX_SIP_SUCCESS
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendInstMsg(IN uint32 uiMsgId,
			  		   IN uint32 uiSrvPdrId,
                       IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
                       IN char8* pcMsg,
                       IN uint32 uiExpire,
                       IN_OUT void **ppvPvtData);

/*!  \brief     API to accept the incoming message
     \param[in] uiMsgId is message identifier for MESSAGE transaction.
	  \param[in] pvPvtData Pointer to NA's internal structure for this dialog.
	 \return IFX_SIP_FAILURE or IFX_SIP_SUCCESS
*/
                       
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgAccept(IN uint32 uiMsgId,
  			                IN void* pvPvtData);

/*!  \brief     API to Reject the incoming message
     \param[in] uiMsgId is message identifier for MESSAGE transaction.
	  \param[in] eMsgReason is reason code for rejection of the message.
	  \param[in] pxFwdAddr is reference to forwarded address if the reason code is IFX_MSG_FWD
	  \param[in] pvPvtData Pointer to NA's internal structure for this dialog.
	 \return IFX_SIP_FAILURE or IFX_SIP_SUCCESS
*/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgReject(IN uint32 uiMsgId,
                         IN e_IFX_SIPAPP_Msg eMsgReason,
								 IN x_IFX_CalledAddr *pxFwdAddr,
                         IN void* pvPvtData);

/*!  \brief     API to authenticate the challanged MESSAGe request
     \param[in] uiMsgId is message identifier for MESSAGE transaction.
	  \parma[in] pcUserName is reference to username string.
	  \param[in] pcPassword is reference to password for authentication.
	  \param[in] pxAppData is reference to internal structure for this dialog.
	  \return IFX_SIP_FAILURE or IFX_SIP_SUCCESS
*/
e_IFX_SIP_Return
IFX_SIPAPP_SetAuthInfoMsg(IN uint32 uiMsgId,
	  		 			        IN char8* pcUserName,
                          IN char8* pcPassword,
                          IN void* pxAppData);


PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgRegCallbacks(uint32 uiStackHdl);

#endif
#if 0




e_IFX_SIP_Return 
IFX_SIPAPP_InstMsgMsgRespArrived(IN uint32 uiSipMsgHdl,
         			               IN uint32 uiInstMsgHdl,
                  			      IN void *pvUserData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_3xxInstMsgHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN uint32 uiMsgHdl);
IFX_SIPAPP_4xxInstMsgHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                       IN uint32 uiMsgHdl);

e_IFX_SIP_Return 
IFX_SIPAPP_InstMsgTimeOutOrError(IN e_IFX_SIP_TransErrorCode eErrorType,
                                 IN uint32 uiInstMsgHdl,
                                 IN void *pvUserData);

e_IFX_SIP_Return  IFX_SIPAPP_InstMsgMsgToEncode(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiInstMsgHdl,
                        IN void *pvUserData);
e_IFX_SIP_Return  
IFX_SIPAPP_InstMsgDnsResolved(IN uint32 uiInstMsgHdl,
                              IN void *pvUserData);
e_IFX_SIP_Return 
IFX_SIPAPP_InstMsgRequestArrived(IN uint32 uiSipMsgHdl,
                                 IN uint32 uiInstMsgHdl,
			                        IN uint32 uiDlgHdl,
                                 IN_OUT void **ppvUserData);

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgHdlr(IN uint32 uiDlg,
                    IN uint32 uiInstMsgHdl,
                    IN x_IFX_SIPAPP_UAAppData *pxAppData,
                    IN uint32 uiMsgHdl);
#endif
