/**************************************************************************
 **   FILE NAME       : IFX_SDPAPP_ParsePredefAttr.h
 **   PROJECT         : SIP signaling
 **   MODULES         : SDP DECODER
 **   SRC VERSION     : V2.0
 **   DATE            : 15-12-2004
 **   AUTHOR          : Murali
 **   DESCRIPTION     : Prototypes of functions defined in ParsePredefAttr.c
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines
 **   COPYRIGHT       : Copyright (c) 2004
 **                     Infineon Technologies AG, st. Martin Strasse 53;
 **                     81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_SDPAPP_PARSEPREDEFATTR_H__
#define __IFX_SDPAPP_PARSEPREDEFATTR_H__


#define IFX_SDPAPP_MAX_ATTR_VALUE 64
#define IFX_SDPAPP_MAX_ATTR_FIELD 32

/* List of all pre-defined attributes */
typedef enum{
  IFX_SDPAPP_ATTR_RTPMAP = 1,
  IFX_SDPAPP_ATTR_FMTP,
  IFX_SDPAPP_ATTR_QUALITY,
  IFX_SDPAPP_ATTR_CAT,
  IFX_SDPAPP_ATTR_FRAMERATE,
  IFX_SDPAPP_ATTR_LANG,
  IFX_SDPAPP_ATTR_SDPLANG,
  IFX_SDPAPP_ATTR_CHARSET,
  IFX_SDPAPP_ATTR_TYPE,
  IFX_SDPAPP_ATTR_ORIENT,
  IFX_SDPAPP_ATTR_PTIME,
  IFX_SDPAPP_ATTR_TOOL,
  IFX_SDPAPP_ATTR_KEYWDS,
  IFX_SDPAPP_ATTR_FAXVER,
  IFX_SDPAPP_ATTR_MBR,
  IFX_SDPAPP_ATTR_FILLBITREM,
  IFX_SDPAPP_ATTR_TRANSMMR,
  IFX_SDPAPP_ATTR_TRANSJBIG,
  IFX_SDPAPP_ATTR_RATEMGMT,
  IFX_SDPAPP_ATTR_MAXBUFF,
  IFX_SDPAPP_ATTR_MAXDGRAM,
  IFX_SDPAPP_ATTR_UDPEC,
  IFX_SDPAPP_ATTR_RTCP,
  IFX_SDPAPP_ATTR_OTHER /* This shoule be the last attibute */
}e_IFX_SDPAPP_AttrType;

/* Datastructures for predefined attributes */
typedef struct
{
    int32 iPayloadType;
    char8 acEncodingName[IFX_SDPAPP_MAX_ATTR_VALUE];
    int32 iClockRate;
    char8 acEncodingParams[IFX_SDPAPP_MAX_ATTR_VALUE];
}x_IFX_SDPAPP_AttrRtpMap;

typedef struct
{
    int32 iFormat;
    char8 acFmtpParams[IFX_SDPAPP_MAX_ATTR_VALUE];
}x_IFX_SDPAPP_AttrFmtp;

typedef struct
{
  uint16 unRtcpPort;
  e_IFX_SDP_Network eNetwork;
  e_IFX_SDP_AddrTrype eAddrType;
  /*x_IFX_SDPAPP_ConnAddr xConnAddr;*/
}x_IFX_SDPAPP_AttrRtcp;

typedef struct
{
    char8 acAttrField[IFX_SDPAPP_MAX_ATTR_FIELD];
    char8 acAttrValue[IFX_SDPAPP_MAX_ATTR_VALUE];
}x_IFX_SDPAPP_OtherAttr; 

typedef enum{
  IFX_SDPAPP_PORTRAIT,
  IFX_SDPAPP_LANDSCAPE,
  IFX_SDPAPP_SEASCAPE
}e_IFX_SDPAPP_AttrOrient;

typedef enum{
  IFX_SDPAPP_BROADCAST,
  IFX_SDPAPP_MEETING,
  IFX_SDPAPP_MODERATED,
  IFX_SDPAPP_TEST,
  IFX_SDPAPP_H332
}e_IFX_SDPAPP_AttrConfType;

typedef enum{
  IFX_SDPAPP_TRANSFERRED_TCF,
  IFX_SDPAPP_LOCAL_TCF
}e_IFX_SDPAPP_AttrFaxRtMgmt;

typedef enum{
  IFX_SDPAPP_T38UDPFEC,
  IFX_SDPAPP_T38UDPREDUNDANCY
}e_IFX_SDPAPP_AttrUdpEC;

typedef union
{
    int32 iQuality;
    int32 iFaxVersion;
    int32 iMaxBitRate;
    int32 iMaxBuffer;
    int32 iMaxDgram;
    int32 iPTime;
    char8 acCategory[IFX_SDPAPP_MAX_ATTR_VALUE];
    char8 acLang[IFX_SDPAPP_MAX_ATTR_VALUE];
    char8 acSdpLang[IFX_SDPAPP_MAX_ATTR_VALUE];
    char8 acKeywds[IFX_SDPAPP_MAX_ATTR_VALUE];
    char8 acToolInfo[IFX_SDPAPP_MAX_ATTR_VALUE];
    char8 acCharSet[IFX_SDPAPP_MAX_ATTR_VALUE];
    char8 acFrameRate[IFX_SDPAPP_MAX_ATTR_VALUE];
    e_IFX_SDPAPP_AttrOrient eOrient;  
    e_IFX_SDPAPP_AttrConfType eConfType;
    e_IFX_SDPAPP_AttrFaxRtMgmt eFaxRateMgmt;
    e_IFX_SDPAPP_AttrUdpEC eUdpEC;
    x_IFX_SDPAPP_AttrFmtp xFmtp;
    x_IFX_SDPAPP_AttrRtpMap xRtpMap;
    x_IFX_SDPAPP_AttrRtcp xRtcp;
    x_IFX_SDPAPP_OtherAttr xOtherAttr;
}ux_IFX_SDPAPP_Attributes;

typedef struct x_IFX_SDPAPP_Attributes
{
    e_IFX_SDPAPP_AttrType eAttrType;
    ux_IFX_SDPAPP_Attributes uxSdpAttr;
    struct x_IFX_SDPAPP_Attributes *pxNext;
}x_IFX_SDPAPP_Attributes; 




typedef char8
(*IFX_SDPAPP_DecPredefAttrVal)(char8*,
                             char8*,
                             x_IFX_SDPAPP_Attributes* pxSdpAttr);

#define IFX_SDPAPP_NUM_ATTR_FIELDS 26

char8 IFX_SDPAPP_DecodeTranscodingMMR(char8* pcStartIndex,
                                    char8* pcEndIndex,
                                    x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeTranscodingJBIG(char8* pcStartIndex,
                                     char8* pcEndIndex,
                                     x_IFX_SDPAPP_Attributes* pxSdpAttr);

char8 IFX_SDPAPP_DecodeFillBitRemoval(char8* pcStartIndex,
                                    char8* pcEndIndex,
                                    x_IFX_SDPAPP_Attributes* pxSdpAttr);

char8 IFX_SDPAPP_DecodeCategory(char8* pcStartIndex,
                              char8* pcEndIndex,
                              x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeKeywds(char8* pcStartIndex,
                            char8* pcEndIndex,
                            x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeTool(char8* pcStartIndex,
                          char8* pcEndIndex,
                          x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodePtime(char8* pcStartIndex,
                           char8* pcEndIndex,
                           x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeOrient(char8* pcStartIndex,
                            char8* pcEndIndex,
                            x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeConfType(char8* pcStartIndex,
                              char8* pcEndIndex,
                              x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeCharset(char8* pcStartIndex,
                             char8* pcEndIndex,
                             x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeSdplang(char8* pcStartIndex,
                             char8* pcEndIndex,
                             x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeRtpMap(char8* pcStartIndex,
                            char8* pcEndIndex,
                            x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_Decodelang(char8* pcStartIndex,
                          char8* pcEndIndex,
                          x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeFramerate(char8* pcStartIndex,
                               char8* pcEndIndex,
                               x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeQuality(char8* pcStartIndex,
                             char8* pcEndIndex,
                             x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeFmtp(char8* pcStartIndex,
                          char8* pcEndIndex,
                          x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeT38FaxVersion(char8* pcStartIndex,
                                   char8* pcEndIndex,
                                   x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeT38MaxBitRate(char8* pcStartIndex,
                                   char8* pcEndIndex,
                                   x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeT38FaxRateMgmt(char8* pcStartIndex,
                                    char8* pcEndIndex,
                                    x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeT38FaxMaxBuffer(char8* pcStartIndex,
                                     char8* pcEndIndex,
                                     x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeT38FaxMaxDgram(char8* pcStartIndex,
                                    char8* pcEndIndex,
                                    x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8 IFX_SDPAPP_DecodeT38FaxUdpEC(char8* pcStartIndex,
                                 char8* pcEndIndex,
                                 x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8
IFX_SDPAPP_DecodeRtcp(char8* pcStartIndex,
                    char8* pcEndIndex,
					x_IFX_SDPAPP_Attributes *pxSdpAttr);

char8 IFX_SDPAPP_DecodeDummy(char8* pcStartIndex,
                           char8* pcEndIndex,
                           x_IFX_SDPAPP_Attributes* pxSdpAttr);
char8
IFX_SDPAPP_DecodeSdpAttr(uint32 uiMediaDescHdl,
                      int32 iLoc,
                      x_IFX_SDPAPP_Attributes* pxSdpAttr);
#endif /*__IFX_SDPAPP_PARSEPREDEFATTR_H__*/
