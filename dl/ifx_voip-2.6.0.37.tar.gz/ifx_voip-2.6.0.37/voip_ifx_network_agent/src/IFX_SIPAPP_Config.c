/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Config.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains function related to the configuration.
**   COMPILER      : gcc
**   REFERENCE     :
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/

#include "ifx_common_defs.h"
#include "IFX_SIP_Stack.h"

#include "ifx_debug.h"
#include "ifx_os.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_Config.h"
#include "ifx_ipc.h"
#ifdef DMALLOC
#include <dmalloc.h>
#endif

extern uchar8 vcSipAppModId;
uint32 vuiNoOfSrvPdrs;
x_IFX_SIPAPP_SrvPrd *vpxSrvPdrData;
/******************************************************************
*  Function Name    :  IFX_SIPAPP_CfgInit
*  Description      :  this function Assigns all the Cfg Pointer  
*                      required
*  Input Values     :  void
*  Output Values    :  structure where to copy to
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_CfgInit(uint32 uiNoOfSrvPrds)
{
  /* Configure Service Provider Info*/
  vpxSrvPdrData = (x_IFX_SIPAPP_SrvPrd *)
	              IFX_SIPAPP_Malloc(sizeof(x_IFX_SIPAPP_SrvPrd)*uiNoOfSrvPrds);
  if(vpxSrvPdrData == NULL){
		 IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"MallocFailed\n");
	 return IFX_SIP_FAILURE;
  }
  vuiNoOfSrvPdrs = uiNoOfSrvPrds;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Configuration Database Initialized");
  
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_GetTimerVal_A
*  Description      : This function returns the configured timer value
*                     of timer A
*  Input Values     :   
*  Output Values    : uint32 *: Timer value of A
*  Return Value     : IFX_SIP_SUCCESS
*                     IFX_SIP_FAILURE
*********************************************************************/
void IFX_SIPAPP_GetTimerVal_A(uint32 uiSrvPdr,uint32 *puiTimerA)
{
  if(IFX_SIPAPP_GET_T1(uiSrvPdr)){
    *puiTimerA = IFX_SIPAPP_GET_T1(uiSrvPdr);
  }
  else{
    *puiTimerA = IFX_SIP_DEFAULT_T1;
  }
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_GetTimerVal_B
*  Description      : This function returns the configured timer value
*                     of timer B
*  Input Values     :   
*  Output Values    : uint32 *: Timer value of B
*  Return Value     : IFX_SIP_SUCCESS
*                     IFX_SIP_FAILURE
*********************************************************************/
void IFX_SIPAPP_GetTimerVal_B(uint32 uiSrvPdr,uint32 *puiTimerB)
{
  uint32 uiT1;
  uint32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(uiSrvPdr);
  IFX_SIPAPP_GetTimerVal_A(uiSrvPdr,&uiT1);
  
  if(IFX_SIPAPP_GET_TMAX(uiCfgInst)){
    *puiTimerB = IFX_SIPAPP_GET_TMAX(uiCfgInst);
  }
  else{
    *puiTimerB = 64 * uiT1;
  }
}

/*******************************************************************************
*  Function Name : IFX_SIPAPP_GetServerPort
*  Description   : Returns the configured server port or else the
*                  default port : 5060
*  Input Values  : None
*  Output Values : uint16*: Server Port
*  Return Value  : IFX_SIP_SUCCESS
*                  IFX_SIP_FAILURE
*******************************************************************************/
void IFX_SIPAPP_GetServerPort(uint32 uiSrvPdr,uint16* pnServPort)
{
  /* Access the config struct */
  if(IFX_SIPAPP_GET_SERVERPORT(uiSrvPdr)){
    *pnServPort = IFX_SIPAPP_GET_SERVERPORT(uiSrvPdr);
  }
  else{
    *pnServPort = IFX_SIP_DEFAULT_PORT;  
  }
}

/*******************************************************************************
*  Function Name : IFX_SIPAPP_GetMappedPort
*  Description   : 
*  Input Values  : None
*  Output Values : uint16*: Mapped Port
*  Return Value  : IFX_SIP_SUCCESS
*                  IFX_SIP_FAILURE
*******************************************************************************/
void IFX_SIPAPP_GetMappedPort(uint32 uiSrvPrd,uint16* pnMappedPort)
{
  if(vpxSrvPdrData[uiSrvPrd].unSIPMappedPort != 0){
      *pnMappedPort = vpxSrvPdrData[uiSrvPrd].unSIPMappedPort; 
  }
  else{
	  IFX_SIPAPP_GetServerPort(uiSrvPrd,pnMappedPort); 
  }
}
