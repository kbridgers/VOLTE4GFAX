/**************************************************************************
 **   FILE NAME     : IFX_SIPAPP_CallBk.c
 **   PROJECT       : SIP
 **   MODULES       : Transaction User
 **   SRC VERSION   : V2.0
 **   DATE          : 17-08-2005
 **   AUTHOR        : SIP Team
 **   DESCRIPTION   : This file uses the APIs provided by CB subs-notify
 **   COMPILER      : gcc
 **   REFERENCE     :
 **   COPYRIGHT     : Copyright (c) 2004
 **                   Infineon Technologies AG, st. Martin Strasse 53;
 **                   81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted
 **
 **   Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 ***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"

#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_RegApi.h"

#include "IFX_SIP_EvtPkg.h"
#include "IFX_SIP_DlgApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"

#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_CallBk.h"
#include "ifx_list.h"
#include "ixml.h"

extern uchar8 vcSipAppModId;
/************************************************************************
* Function Name    : IFX_SIPAPP_CB_PkgRecvSubscribe
* Description      : This function handles the incoming Subsribe request
*                    for the CallBack evnet.
* Input Values     :
* Output Values    : 
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CB_PkgRecvSubscribe(IN uint32 uiDecodedMsgHdl,
                               IN uint32 uiSubcsHdl,
                               IN uint32 uiDialogHdl,
                               IN_OUT void **ppvUserData)
{
  e_IFX_SIP_Ecode eEcode;
  x_IFX_SIPAPP_UAAppData *pxAppData;
  x_IFX_SIPAPP_CBSubscRecvd xCBSubscRecvd;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Received Subscribe Request");

  if(ppvUserData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  /* Check whether its a new Subscription, or part of an existing dialog */
  if(*ppvUserData == NULL)
  {
	  uint32 uiHdrHdl;
    if(IFX_SIP_GetHeaderByType(uiDecodedMsgHdl, IFX_SIP_EVENT, 1, &uiHdrHdl)
		 != IFX_SIP_SUCCESS)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 " Can't get Event Header");
      return IFX_SIP_FAILURE;
    }
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               " got Event Header");
    if(strcmp(IFX_SIP_Event_GetPackage(uiHdrHdl), "dialog"))
    {
      IFX_SIP_SubscRespond(uiSubcsHdl, 489, "Event Not Supported", 0);
      return IFX_SIP_FAILURE;
    }
    if(IFX_SIPAPP_CreateNAddAppData(&pxAppData, &eEcode) != IFX_SIP_SUCCESS)
    {
      return IFX_SIP_FAILURE;
    }
    pxAppData->auiHdl[IFX_SIPAPP_UA_CB]= uiSubcsHdl;
    pxAppData->uiNotifyDlgId = IFX_SIPAPP_RandomNumber();
    IFX_SIPAPP_CopyToAddr(uiDecodedMsgHdl, &pxAppData->xTo);
    IFX_SIPAPP_CopyCalledAddr(uiDecodedMsgHdl, &pxAppData->xFrom);
    *ppvUserData = (void *) pxAppData;
				
  }
  else
  {
    pxAppData = (x_IFX_SIPAPP_UAAppData *) *ppvUserData;
	  xCBSubscRecvd.uiReqId = pxAppData->iConnId;
  }
  xCBSubscRecvd.pvAppData = (void *) pxAppData;
  IFX_SIPAPP_GetExpires(uiDecodedMsgHdl, &pxAppData->uiCBExpires);
	xCBSubscRecvd.uiExpires = pxAppData->uiCBExpires;
  if(IFX_SIP_SubscGetState(uiSubcsHdl, uiDialogHdl) == IFX_SIP_SUBSC_TERMINATED)
  {
    xCBSubscRecvd.eCBSubscStatus = IFX_OFF;
    xCBSubscRecvd.eReason = IFX_TERMINATED;
  }
  else
  {
    xCBSubscRecvd.eCBSubscStatus = IFX_ON;
  }
  xCBSubscRecvd.pxTo =  &pxAppData->xTo;
	xCBSubscRecvd.pxFrom = &pxAppData->xFrom;
	
	/*Inform Gateway Application*/
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_CALLBACK_SUBSC_RECV,
                              &xCBSubscRecvd);
	
	pxAppData->iConnId = xCBSubscRecvd.uiReqId;
	 
  if(xCBSubscRecvd.eCBSubscStatus == IFX_OFF)
  {
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
  }

  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_CB_PkgRecvNotify
* Description      : This function handles the incoming Notify requsts
										 from the Subscribe server for CB event.
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CB_PkgRecvNotify(IN uint32 uiDecodedMsgHdl,
                            IN uint32 uiSubcsHdl,
                            IN uint32 uiDialogHdl,
                            IN_OUT void **ppvUserData)
{
  char8 *pcMsgBody = NULL;
  x_IFX_SIPAPP_UAAppData *pxAppData;
  x_IFX_SIPAPP_CBNotifyRecvd xCBNotifyRecvd={0};
  e_IFX_SIP_SUBSC_STATE eSubscState;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Received Notify Request");

  if(ppvUserData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  /* Handle an unsolicited Notify */
  if(*ppvUserData == NULL)
  {
    IFX_SIP_NotifyRespond(uiSubcsHdl, uiDialogHdl, 0, 403, NULL);
		return IFX_SIP_SUCCESS;
  }
  else
  {
    pxAppData = (x_IFX_SIPAPP_UAAppData *) *ppvUserData;
  }
  xCBNotifyRecvd.pvAppData = (void *) pxAppData;
  xCBNotifyRecvd.bIsRemoteFree = IFX_FALSE;
  xCBNotifyRecvd.pxFrom = &pxAppData->xFrom;
	xCBNotifyRecvd.pxTo = &pxAppData->xTo;
	xCBNotifyRecvd.uiExpires = 3600;
	eSubscState = IFX_SIP_SubscGetState(uiSubcsHdl, uiDialogHdl);
  if((eSubscState == IFX_SIP_SUBSC_PENDING)|| (eSubscState == IFX_SIP_SUBSC_ACTIVE))
  {
    xCBNotifyRecvd.eCBSubscStatus = IFX_ON;
    if((uiDecodedMsgHdl) &&
      ((pcMsgBody = IFX_SIP_GetMsgBody(uiDecodedMsgHdl)) != NULL))
    {
      IXML_Document *pxXmlDoc = NULL;
      IXML_NodeList *pxXmlNodeList = NULL;
      IXML_Node *pxXmlNode = NULL, *pxXmlFirstChildNode = NULL;
      int32 iRet=0;
      if((iRet = ixmlParseBufferEx(pcMsgBody, &pxXmlDoc)) != IXML_SUCCESS)
      {
        return IFX_SIP_NotifyRespond(uiSubcsHdl, uiDialogHdl, 0, 400, NULL);
      }
      pxXmlNodeList = ixmlDocument_getElementsByTagName(pxXmlDoc, "state");
      if(pxXmlNodeList == NULL)
      {
        /*Send to PA to initiate automatic calling*/
        xCBNotifyRecvd.bIsRemoteFree = IFX_TRUE;
      }
      else
      {
        uint32 uiCount = 0;

        if(pxAppData->ucNumDlgInNotifyBody > ixmlNodeList_length(pxXmlNodeList))
        {
          /*Send to PA to initiate automatic calling*/
          xCBNotifyRecvd.bIsRemoteFree = IFX_TRUE;
        }
        else
        {
          pxAppData->ucNumDlgInNotifyBody = 0;
          for(uiCount = 0; uiCount<ixmlNodeList_length(pxXmlNodeList); uiCount++)
          {
            pxXmlNode = ixmlNodeList_item(pxXmlNodeList, uiCount);
            pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
            if((ixmlNode_getNodeValue(pxXmlFirstChildNode) != NULL) 
								&& strcmp(ixmlNode_getNodeValue(pxXmlFirstChildNode), "terminated"))
            {
              pxAppData->ucNumDlgInNotifyBody++;
            }
            else
            {
              /*Send to PA to initiate automatic calling*/
              xCBNotifyRecvd.bIsRemoteFree = IFX_TRUE;
            }
          }
        }
      }
      ixmlNodeList_free(pxXmlNodeList);
      ixmlDocument_free(pxXmlDoc);
    }
  }
  else
  {
    xCBNotifyRecvd.eCBSubscStatus = IFX_OFF;
    xCBNotifyRecvd.eReason = IFX_TERMINATED;
		xCBNotifyRecvd.bIsRemoteFree = IFX_TRUE;
		xCBNotifyRecvd.uiExpires=0;
  }
	
  IFX_SIP_NotifyRespond(uiSubcsHdl, uiDialogHdl,0,200,NULL);
	vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_CALLBACK_NOTIFY_RECV,
                              &xCBNotifyRecvd);	
  return IFX_SIP_SUCCESS;
}

/***********************************************************************
* Function Name : IFX_SIPAPP_4xxNotifyCBHdlr
* Description   : This function is called when 4xx for Subsc is received
* Input Values  :
* Return Value  : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
static e_IFX_SIP_Return
IFX_SIPAPP_4xxNotifyCBHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                           IN uint32 uiMsgHdl,
                           IN uint32 uiDlgHdl)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 iAuthHdl = 0, iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  char8 *pcRealm = NULL;
  char8 acRealm[IFX_SIPAPP_MAX_TOKEN] = "";
  x_IFX_SIPAPP_AuthReqd xAuthReqd;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             " Subscribe 4xx Response received");

  /* The assignment below handles the case where iRespCode is neither
     401 nor 407. */
  eRetVal = IFX_SIP_FAILURE;

  if(iRespCode == 401)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_WWW_AUTHENTICATE, 1,
                                        &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 "Notify 4xx Response received but no www Auth header found");
    }
  }
  else if(iRespCode == 407)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_PROXY_AUTHENTICATE, 1,
                                        &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "Notify 4xx Response received but no www Auth header found");
    }
  }

  if(eRetVal == IFX_SIP_FAILURE)
  {
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_400_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_NOTIFY_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    return IFX_SIP_FAILURE;
  }

  /* Get the necessary information to search for proper credentials */
  pcRealm = IFX_SIP_Authentication_GetRealm(iAuthHdl);
  /* Since the Realm contains Quotes, the below logic is to remove the Quotes*/

	if (pcRealm != NULL){
  	strncpy(acRealm, pcRealm + 1, strlen(pcRealm) - 2);

  	xAuthReqd.uiHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_CB];
  	xAuthReqd.uiDlgHdl = uiDlgHdl;
  	xAuthReqd.pcRealm = acRealm;
  	xAuthReqd.uiSipMsgHdl = 0;
	}
  /* This callback should ensure that Authentication with credentials happens */
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_CALLBACK_AUTH_REQD,
    &xAuthReqd);

  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_CB_PkgRecvNotifyRsp
* Description      : This function handles the Notify response
*                    for CB event package
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CB_PkgRecvNotifyRsp(IN uint32 uiDecodedMsgHdl,
                               IN uint32 uiSubcsInfo,
                               IN uint32 uiDlgHdl,
                               IN void *pvUserData)
{
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiDecodedMsgHdl);
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvUserData;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "In IFX_SIP_CB_PkgRecvSubscRsp Hdlr ");

  if((nStatusCode >= 200) && (nStatusCode < 300))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "subscription status ON received 2xx");

    xSubscStatus.eSubscStatus =
      (IFX_SIP_SubscGetState(uiSubcsInfo, uiDlgHdl) ==
      IFX_SIP_SUBSC_TERMINATED) ? IFX_OFF : IFX_ON;
    xSubscStatus.eReason = IFX_200_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_NOTIFY_STATUS_RECV, &xSubscStatus);
    eRetVal = IFX_SIP_SUCCESS;
  }
  else if((nStatusCode >= 400) && (nStatusCode < 500))
  {
    eRetVal = IFX_SIPAPP_4xxNotifyCBHdlr(pxAppData,uiDecodedMsgHdl,uiDlgHdl);
  }
  else
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "subscription status OFF received 356xx");
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_500_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_NOTIFY_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    eRetVal = IFX_SIP_FAILURE;
  }

  return eRetVal;
}

/***********************************************************************
* Function Name : IFX_SIPAPP_3xxSubscCBHdlr
* Description   : This function is called when 3xx for Subsc is received
* Input Values  :
* Return Value  : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
static e_IFX_SIP_Return
IFX_SIPAPP_3xxSubscCBHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN uint32 uiMsgHdl,
                          IN uint32 uiDlgHdl)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiContactHdl;
  x_IFX_SIPAPP_RouteParams xRouteParams;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus;
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Subscribe 3xx Response received");

  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT,1,&uiContactHdl);
  if(eRetVal == IFX_SIP_FAILURE)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "CB Getting Contact header failed");
    return eRetVal;
  }

  /* if invalid 3xx response and Contact is not present return a failure */
  if((iRespCode != 302) && (iRespCode != 301) && (iRespCode != 305))
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               " Subscribe 3xx invalid request");
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_300_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_SUBSC_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    return IFX_SIP_FAILURE;
  }

  /* Update the target information in the xAppData */
  IFX_SIPAPP_CopyContactAddr(uiMsgHdl, &pxAppData->xTo);
  xRouteParams.pxTo = &pxAppData->xTo;
  xRouteParams.pxFrom = &pxAppData->xFrom;
  xRouteParams.unLocalTcpPort = pxAppData->unLocalTcpPort;
  xRouteParams.pcProxyAddr = pxAppData->acProxyAddr;
  xRouteParams.unProxyPort = pxAppData->unProxyPort;
  xRouteParams.eProxyProtocol = pxAppData->eProxyProtocol;
  xRouteParams.ucIsOutBoundProxy = pxAppData->ucIsOutBoundProxy;

  /* Try a resubscribe with teh new settings */
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Called IFX_SIPAPP_SubscribeForCB");
  eRetVal = IFX_SIPAPP_SubscribeForCB(pxAppData->iConnId, pxAppData->iProfileId,
              pxAppData->uiCBExpires, &xRouteParams, (void*)&pxAppData);

  if (eRetVal != IFX_SIP_SUCCESS)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Subscribe 3xx Request construction Fail");
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_300_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_SUBSC_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    return IFX_SIP_FAILURE;
  }
  return eRetVal;
}

/***********************************************************************
* Function Name : IFX_SIPAPP_4xxSubscCBHdlr
* Description   : This function is called when 4xx for Subsc is received
* Input Values  :
* Return Value  : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
static e_IFX_SIP_Return
IFX_SIPAPP_4xxSubscCBHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN uint32 uiMsgHdl,
                          IN uint32 uiDlgHdl)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 iAuthHdl = 0, iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  char8 *pcRealm = NULL;
  char8 acRealm[IFX_SIPAPP_MAX_TOKEN] = "";
  x_IFX_SIPAPP_AuthReqd xAuthReqd;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Subscribe 4xx Response received");

  /* The assignment below handles the case where iRespCode is neither
     401 nor 407. */
  eRetVal = IFX_SIP_FAILURE;

  if(iRespCode == 401)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_WWW_AUTHENTICATE,
                                        1, &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                " Subscribe 4xx Response has no www Auth header");
    }
  }
  else if(iRespCode == 407)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_PROXY_AUTHENTICATE,
                                        1, &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Subscribe 4xx Response has no www Auth header");
    }
  }
  else if(iRespCode == 423)
  {
    uint32 uiMinExpHdl;

    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_MIN_EXPIRES, 1,
                &uiMinExpHdl);
    if(eRetVal == IFX_SIP_SUCCESS)
    {
      x_IFX_SIPAPP_RouteParams xRouteParams;

      pxAppData->uiCBExpires = IFX_SIP_MinExpires_GetValue(uiMinExpHdl);
      xRouteParams.pxTo = &pxAppData->xTo;
      xRouteParams.pxFrom = &pxAppData->xFrom;
      xRouteParams.unLocalTcpPort = pxAppData->unLocalTcpPort;
      xRouteParams.pcProxyAddr = pxAppData->acProxyAddr;
      xRouteParams.unProxyPort = pxAppData->unProxyPort;
      xRouteParams.eProxyProtocol = pxAppData->eProxyProtocol;
      xRouteParams.ucIsOutBoundProxy = pxAppData->ucIsOutBoundProxy;

      eRetVal = IFX_SIPAPP_SubscribeForCB(pxAppData->iConnId, pxAppData->iProfileId,
              pxAppData->uiCBExpires, &xRouteParams, (void*)&pxAppData);
      if(eRetVal == IFX_SIP_SUCCESS)
      {
      	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
          " ReSubsc sent with (MinExpire)");
        return eRetVal;          
      }
    }
  }

  if(eRetVal == IFX_SIP_FAILURE)
  {
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_400_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_SUBSC_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    return eRetVal;
  }

  /* Get the necessary information to search for proper credentials */
  pcRealm = IFX_SIP_Authentication_GetRealm(iAuthHdl);
  /* Since the Realm will contain Quotes, this logic is to remove the Quotes*/

	if (pcRealm != NULL){
  	strncpy(acRealm, pcRealm + 1, strlen(pcRealm) - 2);

  	xAuthReqd.uiHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_CB];
  	xAuthReqd.uiDlgHdl = uiDlgHdl;
  	xAuthReqd.pcRealm = acRealm;
  	xAuthReqd.uiSipMsgHdl = 0;
	}

  /* This callback should ensure that Authentication with credentials happens */
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_CALLBACK_AUTH_REQD,
    &xAuthReqd);

  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_CB_PkgRecvSubscRsp
* Description      : This function handles the subscribe requests response
*                    for CB event package
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CB_PkgRecvSubscRsp(IN uint32 uiDecodedMsgHdl,
                              IN uint32 uiSubcsInfo,
                              IN uint32 uiDlgHdl,
                              IN void *pvUserData)
{
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiDecodedMsgHdl);
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus={0};
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvUserData;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "In IFX_SIP_CB_PkgRecvSubscRsp Hdlr ");

  if((nStatusCode >= 200) && (nStatusCode < 300))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "subscription status received: 2xx");
    
    /* Default values */
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_200_RESP;

    /* Update the expires if found */
    IFX_SIPAPP_GetExpires(uiDecodedMsgHdl, &pxAppData->uiCBExpires);
    if(pxAppData->uiCBExpires)
    {
      xSubscStatus.eSubscStatus = IFX_ON;
      xSubscStatus.uiExpires = pxAppData->uiCBExpires;
    }

    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_SUBSC_STATUS_RECV, &xSubscStatus);

    if(xSubscStatus.eSubscStatus == IFX_OFF)
    {
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    }
    eRetVal = IFX_SIP_SUCCESS;
  }
  else if((nStatusCode >= 300) && (nStatusCode < 400))
  {
    eRetVal = IFX_SIPAPP_3xxSubscCBHdlr(pxAppData, uiDecodedMsgHdl, uiDlgHdl);
  }
  else if((nStatusCode >= 400) && (nStatusCode < 500))
  {
    eRetVal = IFX_SIPAPP_4xxSubscCBHdlr(pxAppData, uiDecodedMsgHdl, uiDlgHdl);
  }
  else
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "subscription status OFF received 56xx");
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_500_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_CALLBACK_SUBSC_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
    eRetVal = IFX_SIP_FAILURE;
  }

  return eRetVal;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_CB_PkgRecvTimeOut
* Description      : This function will handle the transaction timeout while
*                    sending subscribe requests
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CB_PkgRecvTimeOut(IN e_IFX_SIP_TransErrorCode eErrorType,
                             IN uint32 uiSubscHdl,
                             IN uint32 uiDialogHdl,
                             IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvUserData;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " Received Timeout");
  if((eErrorType == IFX_SIP_SUBSCRIBER_TIMEOUT) ||(eErrorType == IFX_SIP_NOTIFIER_TIMEOUT) ){
		if(IFX_SIP_SubcsTryNextAddr(uiSubscHdl,uiDialogHdl) == IFX_SIP_SUCCESS){
				return IFX_SIP_SUCCESS;
		}
	}
  xSubscStatus.eSubscStatus = IFX_OFF;
  xSubscStatus.eReason = IFX_TIMEOUT;
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
                              IFX_CALLBACK_SUBSC_STATUS_RECV, &xSubscStatus);
  IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_SubscribeForCB
*  Description      : This function creates the subscription
*                     for Call back.
*  Input Values     :
*  Output Values    :
*  Return Value     : success or failure
*  Notes            :
*********************************************************************/
PUBLIC
e_IFX_SIP_Return IFX_SIPAPP_SubscribeForCB(IN uint32 uiCBackId,
                                           IN uint32 uiSrvPdrId,
                                           IN uint32 uiExpires,
                                           IN x_IFX_SIPAPP_RouteParams
                                                *pxRouteParams,
                                           OUT void **ppvAppData)
{
  e_IFX_SIP_Ecode eEcode;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData;
  char8 acTo[IFX_SIPAPP_MAX_TOKEN], acFrom[IFX_SIPAPP_MAX_TOKEN];

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Creating Subscription");

  if(!ppvAppData)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle ");
    return IFX_SIP_FAILURE;
  }
  if(!pxRouteParams)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " pxRouteParams is NULL ");
    return IFX_SIP_FAILURE;
  }
#if 0 //To provide *89 feature to unsubscribe for call back feature
  if(!uiExpires)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " Expires cannot be 0 for subscription ");
    return IFX_SIP_FAILURE;
  }
#endif
  /* Create App Data */
  if(*ppvAppData == NULL)
  {
    eRetVal = IFX_SIPAPP_CreateNAddAppData(&pxAppData, &eEcode);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
      return IFX_SIP_FAILURE;
    }
    pxAppData->uiNotifyDlgId = IFX_SIPAPP_RandomNumber();
    memcpy(&pxAppData->xTo, pxRouteParams->pxTo, sizeof(x_IFX_CalledAddr));
    memcpy(&pxAppData->xFrom, pxRouteParams->pxFrom, sizeof(x_IFX_CalledAddr));
    *ppvAppData = (void *) pxAppData;
  }
  else
  {
    pxAppData = (x_IFX_SIPAPP_UAAppData *) *ppvAppData;
  }
	/*Copy CallerId suppression*/
  pxAppData->bSupressCallerId = pxRouteParams->bSupressCallerId;
	if(pxAppData->bSupressCallerId){
		strcpy(pxAppData->xFrom.acUserName,"anonymous");
		strcpy(pxAppData->xFrom.acCalledAddr,"anonymous.invalid");
		strcpy(pxAppData->xFrom.acDisplayName,"anonymous");
	}
  /* Copy the necessary data to User Data */
	if(pxAppData->auiHdl[IFX_SIPAPP_UA_CB] == 0)
  {
    pxAppData->iConnId = uiCBackId;
    pxAppData->iProfileId = pxAppData->xSdpInfo.iProfileId = uiSrvPdrId;
    pxAppData->uiCBExpires = uiExpires;
    pxAppData->unLocalTcpPort = pxRouteParams->unLocalTcpPort;


    /* If Addr type is IP and port is zero copy default port */
    if((pxAppData->xTo.ucAddrType == IFX_IP_ADDR) &&
       (pxAppData->xTo.unPort == 0))
    {
      pxAppData->xTo.unPort = IFX_SIP_DEFAULT_PORT;
    }
    /* Create the subscription */
    eRetVal = IFX_SIP_SubscCreate(pxAppData,IFX_SIP_SUBSC_EXTN,
               &pxAppData->auiHdl[IFX_SIPAPP_UA_CB]);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Could not send SUBSCRIBE to VMS");
       /* Remove App data */
       IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
       return IFX_SIP_FAILURE;
    }
    
		if(pxRouteParams->pcProxyAddr)
    {
      /*strcpy(pxAppData->acProxyAddr, pxRouteParams->pcProxyAddr);
      pxAppData->unProxyPort = pxRouteParams->unProxyPort;
      pxAppData->eProxyProtocol = pxRouteParams->eProxyProtocol;
      pxAppData->ucIsOutBoundProxy = pxRouteParams->ucIsOutBoundProxy;*/
      IFX_SIPAPP_SetNextHopAddressForCB(uiCBackId, pxRouteParams->pcProxyAddr,
        pxRouteParams->unProxyPort, pxRouteParams->eProxyProtocol,
        pxRouteParams->ucIsOutBoundProxy, pxRouteParams->unLocalTcpPort,
        pxAppData);
    }
   
  }
  //IFX_SIP_SubscSetAutoRefresh(pxAppData->auiHdl[IFX_SIPAPP_UA_CB], 50, 1);

  /*Create Call, Fill Completely */	
	if(IFX_SIPAPP_ConstAddr(&pxAppData->xTo,pxAppData)!= IFX_SIP_SUCCESS){
      return IFX_SIP_FAILURE;
    }
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo, acTo);
  IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xFrom, acFrom);

  eRetVal = IFX_SIP_SubscSend(pxAppData->auiHdl[IFX_SIPAPP_UA_CB],
                0, acFrom, acTo, uiExpires, "dialog", 0,
                pxAppData->unLocalTcpPort);
	
  if(eRetVal != IFX_SIP_SUCCESS)
  {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Could not send SUBSCRIBE to VMS");
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
      return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_SendSubscStatusForCB
* Description      : This function will handle the response for the
*										 previously received Subsribe request.
*                    subscribe requests
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendSubscStatusForCB(IN uint32 uiCBackId,
                                IN uchar8 eSubscStatus,
                                IN e_IFX_ReasonCode eRespCode,
                                IN void *pvAppData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvAppData;
  uint16 unRespCode;

  if(!pxAppData)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle ");
    return IFX_SIP_FAILURE;
  }

  pxAppData->iConnId = uiCBackId;

  switch(eRespCode)
  {
    case IFX_100_RESP:
      unRespCode = 100;
      break;
    case IFX_202_RESP:
      unRespCode = 202;
      break;
    case IFX_200_RESP:
      unRespCode = 200;
      break;
    case IFX_TIMEOUT:
      unRespCode = 408;
      break;
    case IFX_415_RESP:
      unRespCode = 415;
      break;
    case IFX_REMOTE_UNAVAIL:
    case IFX_486_RESP:
      unRespCode = 486;
      break;
    case IFX_TERMINATED:
      unRespCode = 487;
      break;
    case IFX_488_RESP:
      unRespCode = 488;
      break;
    case IFX_REQ_PENDING:
      unRespCode = 491;
      break;
    case IFX_500_RESP:
    case IFX_INTERNAL_ERR:
    case IFX_MEDIA_ERROR:
       unRespCode = 500;
       break;
    case IFX_600_RESP:
      unRespCode = 600;
      break;
    default:
      unRespCode = 400;
  }
  return IFX_SIP_SubscRespond(pxAppData->auiHdl[IFX_SIPAPP_UA_CB], 
									            unRespCode,NULL, 0);
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_NotifyForCB
*  Description      : This function creates the subscription
*                     for Call back.
*  Input Values     :
*  Output Values    :
*  Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_NotifyForCB(IN uint32 uiCBackId,
                       IN uint16 unSubsState,
                       IN e_IFX_ReasonCode eReason,
                       IN boolean bIsRemoteFree,
											 IN uint32 uiSrvPdrId,
                       IN void *pvAppData)
{
  e_IFX_SIP_Ecode eEcode;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  e_IFX_SIP_SUBSC_STATE eSubscState = 
    (unSubsState == IFX_OFF) ? IFX_SIP_SUBSC_TERMINATED : IFX_SIP_SUBSC_ACTIVE;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvAppData;
  char8 acXml[2*IFX_SIPAPP_MAX_TOKEN] = "";
  uint32 uiDlgList = 0, uiDlgHdl = 0;
  char8 acEntity[IFX_SIPAPP_MAX_TOKEN] = "";
  uint32 uiSipMsg;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           " Inside IFX_SIP_NotifyForCB");
  /*Locate the User Data */
  if(pxAppData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle ");
    return IFX_SIP_FAILURE;
  }
	if(pxAppData->iProfileId == 0){
  	pxAppData->iProfileId = uiSrvPdrId;
	}

  /* Create a new SIP message */
  if(IFX_SIP_CreateMsg(&uiSipMsg) == IFX_SIP_FAILURE)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " Could not create message ");
    return IFX_SIP_FAILURE;
  }

  pxAppData->iConnId = uiCBackId;
  IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xTo, acEntity);
	
	/*To remove angel brackets*/
  acEntity[strlen(acEntity)-1]='\0';
	
  /* Prepare the XML body to be sent in the NOTIFY */
  sprintf(acXml, "<?xml version=\"1.0\"?>\r\n<dialog-info "  \
    "xmlns=\"urn:ietf:params:xml:ns:dialog-info\" "     \
    "version=\"0\" state=\"full\" entity=\"%s\">\r\n"  \
    "<dialog id=\"%d\">\r\n<state>%s</state>\r\n"      \
    "</dialog>\r\n</dialog-info>", &acEntity[1], pxAppData->uiNotifyDlgId,
    ((bIsRemoteFree) ? "terminated" : "confirmed"));

  if(IFX_SIP_AddMsgBody(uiSipMsg,strlen(acXml), acXml) == IFX_SIP_FAILURE)
  {
    IFX_SIP_FreeMsg(uiSipMsg);
    return IFX_SIP_FAILURE;
  }
	/*Add content type*/
	IFX_SIPAPP_SetContentType("application","dialog-info+xml",uiSipMsg);

  /* Send the NOTIFY to all branches of the subscription */
  IFX_SIP_SubscGetDlg(pxAppData->auiHdl[IFX_SIPAPP_UA_CB],&uiDlgList);
  IFX_SIP_DLG_GetDialogFromList(uiDlgList,&uiDlgHdl,&eEcode);
  while(uiDlgHdl)
  {
    /* Send NOTIFY request to peer */
    eRetVal = IFX_SIP_SendNotify(pxAppData->auiHdl[IFX_SIPAPP_UA_CB],
                uiDlgHdl, eSubscState, 0, uiSipMsg);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Could not send NOTIFY for callback");
      //IFX_SIP_FreeMsg(uiSipMsg);
      return IFX_SIP_FAILURE;
    }
    IFX_SIP_DLG_GetDialogFromList(uiDlgList, &uiDlgHdl, &eEcode);
  }
  //IFX_SIP_FreeMsg(uiSipMsg);
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_SendNotifyStatusForCB
* Description      : This function will handle the response for the
*                    notify requests
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC
e_IFX_SIP_Return 
IFX_SIPAPP_SendNotifyStatusForCB(IN uint32 uiCBackId,
                                 IN uchar8 eSubscStatus,
                                 IN e_IFX_ReasonCode  eReason,
                                 IN void *pvAppData)
{
  uint16 unRespCode;
  e_IFX_SIP_Ecode eEcode;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvAppData;
  uint32 uiDlgList = 0, uiDlgHdl = 0;

  if(pxAppData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle ");
    return IFX_SIP_FAILURE;
  }

  pxAppData->iConnId = uiCBackId;

  /* As this API is only called for an unsolicited Notify, we only need to
     search for the first Dialog */
  IFX_SIP_SubscGetDlg(pxAppData->auiHdl[IFX_SIPAPP_UA_CB], &uiDlgList);
  IFX_SIP_DLG_GetDialogFromList(uiDlgList, &uiDlgHdl, &eEcode);
  if(!uiDlgHdl)
  {
    return IFX_SIP_FAILURE;
  }

  if(eSubscStatus == IFX_ON)
  {
    unRespCode = 200;
  }
  else
  {
    switch(eReason)
    {
      case IFX_100_RESP:
        unRespCode = 100;
        break;
      case IFX_200_RESP:
        unRespCode = 200;
        break;
      case IFX_TIMEOUT:
        unRespCode = 408;
        break;
      case IFX_415_RESP:
        unRespCode = 415;
        break;
      case IFX_REMOTE_UNAVAIL:
      case IFX_486_RESP:
        unRespCode = 486;
        break;
      case IFX_TERMINATED:
        unRespCode = 487;
        break;
      case IFX_488_RESP:
        unRespCode = 488;
        break;
      case IFX_REQ_PENDING:
        unRespCode = 491;
        break;
      case IFX_500_RESP:
      case IFX_INTERNAL_ERR:
      case IFX_MEDIA_ERROR:
        unRespCode = 500;
        break;
      case IFX_600_RESP:
        unRespCode = 600;
        break;
      default:
        unRespCode = 400;
    }
  }
  return IFX_SIP_NotifyRespond(pxAppData->auiHdl[IFX_SIPAPP_UA_CB], uiDlgHdl,
           0, unRespCode, NULL);
}

/******************************************************************
*  Function Name    :  IFX_SIPAPP_UnSubscribeForCB
*  Description      :  This function send message to
*                      terminate the subscription.
*  Input Values     :
*  Output Values    :
*  Return Value     :  IFX_SIP_SUCCESS, IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_UnSubscribeForCB(IN uint32 uiCBackId,
                            IN void *pvAppData)
{
  e_IFX_SIP_Ecode eEcode;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvAppData;
  uint32 uiDlgList=0,uiDlgHdl=0;

  /* Locate the User Data */
  if(!pxAppData)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle ");
    return IFX_SIP_FAILURE;
  }
  
  /* Send the unsubscribe to all branches of the subscription */
  IFX_SIP_SubscGetDlg(pxAppData->auiHdl[IFX_SIPAPP_UA_CB],&uiDlgList);
  IFX_SIP_DLG_GetDialogFromList(uiDlgList,&uiDlgHdl,&eEcode);
  while(uiDlgHdl)
  {
    /* Send unsubscribe request to peer */
    eRetVal = IFX_SIP_SubscUnSubsc(pxAppData->auiHdl[IFX_SIPAPP_UA_CB],
                                   uiDlgHdl,0);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Could not send SUBSCRIBE to VMS");
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CB);
      return IFX_SIP_FAILURE;
    }
    IFX_SIP_DLG_GetDialogFromList(uiDlgList,&uiDlgHdl,&eEcode);
  }
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_SetNextHopAddressForCB
* Description      : This function will store proxy related settings for
*                    the dialog.
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetNextHopAddressForCB(IN uint32 uiCBackId,
                                  IN char8 *pucProxyAddr,
                                  IN uint16 unProxyPort,
                                  IN e_IFX_SIP_Protocol eProxyTransport,
                                  IN boolean bIsOutboundProxy,
                                  IN uint16 unLocalTcpPort,
                                  IN void *pvAppData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvAppData;

  /* Locate the User Data */
  if(pxAppData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  strcpy(pxAppData->acProxyAddr, pucProxyAddr);
  pxAppData->unProxyPort = unProxyPort;
  pxAppData->eProxyProtocol = eProxyTransport;
  pxAppData->ucIsOutBoundProxy = bIsOutboundProxy;
  pxAppData->unLocalTcpPort = unLocalTcpPort;
  IFX_SIP_SubscSetNextHopAddr(pxAppData->auiHdl[IFX_SIPAPP_UA_CB],
    pucProxyAddr, unLocalTcpPort, unProxyPort, eProxyTransport);
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_SetAuthDataForCB
* Description      : This function will
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAuthDataForCB(IN uint32 uiCBackId,
                            IN char8 *pcUserName,
                            IN char8 *pcPasswd,
                            IN void *pvAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_FAILURE;
  x_IFX_SIPAPP_AuthReqd *pxAuthReqd = (x_IFX_SIPAPP_AuthReqd *) pvAppData;

  if(pxAuthReqd)
  {
    eRetVal = IFX_SIP_SubscAuthorize(pxAuthReqd->uiHdl, pxAuthReqd->uiDlgHdl,
                pcUserName, pcPasswd, pxAuthReqd->uiSipMsgHdl);
  }
  else
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle!");
  }
  return eRetVal;
}
/************************************************************************
* Function Name    : IFX_SIP_CB_PkgEncode
* Description      : This function will add any headers/parameters to the
*                    outgoing message.
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CB_PkgEncode(IN uint32 uiSipMsgHdl,
                         IN uint32 uiSubscHdl,
                         IN uint32 uiDlgHdl,
                         IN void *pvUserData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *)pvUserData;
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN];

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Entering IFX_SIPAPP_CB_PkgEncode");

  IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xTo, acFrom);
  eRetVal = IFX_SIPAPP_SetContact(acFrom, uiSipMsgHdl,
                                  pxAppData->iProfileId); 
	if(eRetVal== IFX_SIP_FAILURE)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Seting Contact Failed");
    return IFX_SIP_FAILURE;
  }
#ifdef STUN_SUPPORT
  IFX_SIPAPP_AddViaIfSTUNOn(uiSipMsgHdl, 1);
#endif

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Leaving IFX_SIPAPP_CB_PkgEncode");
  return IFX_SIP_SUCCESS;
}


/************************************************************************
* Function Name    : IFX_SIPAPP_CBPkgInit
* Description      : This function will
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_CBPkgInit(uint32 uiStackHdl)
{
  x_IFX_SIP_SubscCallBks xCallBks = {0};
  xCallBks.pfnNotifyReqArrived = IFX_SIPAPP_CB_PkgRecvNotify;
  xCallBks.pfnNotifyRespArrived = IFX_SIPAPP_CB_PkgRecvNotifyRsp;
  xCallBks.pfnTimeOutOrError = IFX_SIPAPP_CB_PkgRecvTimeOut;
  xCallBks.pfnSubscRespArrived = IFX_SIPAPP_CB_PkgRecvSubscRsp;
  xCallBks.pfnSubscReqArrived = IFX_SIPAPP_CB_PkgRecvSubscribe;
	xCallBks.pfnMsgToEncode = IFX_SIPAPP_CB_PkgEncode;
	xCallBks.uiStackHdl =uiStackHdl;
  return  IFX_SIP_SubscRegisterCallBks(IFX_SIP_SUBSC_EXTN, 120, 10,
            &xCallBks);
}
