/****************************************************************************
**   FILE NAME     : IFX_SIPAPP_PAIf.c
**   PROJECT       : SIP
**   MODULES       : Application for SIP controlling stack,RTP,SDP
**   SRC VERSION   : V2.0 
**   DATE          : 
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains phone application inteface functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
#ifdef IFX_CALLMGR
#include "ifx_common_defs.h"
#include <ifx_debug.h>

#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_EvtPkg.h"


#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

#include "IFX_SIPAPP_PAIf.h"
#include "IFX_SIPAPP_CallIf.h"

#include "IFX_SIPAPP_VoiceMail.h"
#include "IFX_SIPAPP_Refer.h"
#include "IFX_SIPAPP_CallBk.h"
#include "IFX_SIPAPP_Registration.h"
#include "IFX_SIPAPP_Info.h"
#include "IFX_SIPAPP_Options.h"

#ifdef MESSAGE_SUPPORT
#include "IFX_SIPAPP_InstMsg.h"
#endif
#ifdef DARE_CUST
extern x_IFX_SIPAPP_UserRegistration* vpxUserRegistrationHeadptr;
e_IFX_SIP_Return IFX_SIPAPP_OptionsInfo(IN uchar8 ucLineId,
                      IN x_IFX_CMGR_AddressInfo* pxFrom,
                      OUT uchar8* pucIsfrmSrvr,
                      OUT x_IFX_SIPAPP_UserRegistration** ppxUserReg);
e_IFX_SIP_Return IFX_SIPAPP_SendRegister(x_IFX_SIPAPP_UserRegistration *pxUserReg);
#endif

/* External Functions used */
e_IFX_Return IFX_CIF_VLFromUrlGet(
                   IN x_IFX_CalledAddr* pxAddr,
                   OUT uchar8* pucVoiceLineId,
                   OUT e_IFX_ReasonCode* peReason  );
e_IFX_Return IFX_CIF_VLCodecInfoGet(
                   IN uchar8 ucVoiceLineId,
                   OUT x_IFX_CodecList* pxCodecParams,
                   OUT e_IFX_ReasonCode* peReason  );
e_IFX_SIP_Return
IFX_SIP_ValidateIPv4Addr(char8* pszBuff);
e_IFX_Return 
IFX_CIF_VLVMSubEventGet(IN uchar8 ucVoiceLineId,         
				        IN boolean bDepositAddr,
						OUT x_IFX_CalledAddr* pxAddr,
						OUT uint16* punSubExpiryTime);
																													  

extern uchar8 vcSipAppModId;
uint32 uiFdCount=0;
extern e_IFX_SIP_Return IFX_SIPAPP_RecvStunTimerMsgs( IN IFX_SIPAPP_fd_set *pxRdFdSet,
						                       IN IFX_SIPAPP_fd_set *pxWrFdSet,
                       						 IN IFX_SIPAPP_fd_set *pxExFdSet,
                      						 IN int32 *piNoFds);

e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallRelease(
                     IN uint32 uiCallId,
                     IN e_IFX_ReasonCode eReleaseReason,
                     IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
                     IN void* pvPrivateData);

e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallAnswer(
                        IN uint32 uiCallId,
                        IN void* pvPrivateData);

e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallAccept(
                        IN uint32 uiCallId,
                        IN void* pvPrivateData);

e_IFX_Return IFX_SIPAPP_CMGR_NegotiateMediaResponse(
                        IN uint32 uiCallId,
                        IN x_IFX_CMGR_MediaParams* pxCMgrMediaParams,
                        IN_OUT e_IFX_CMGR_Status* peStatus,
                        IN_OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData
                        );
e_IFX_Return 
IFX_SIPAPP_CMGR_SubnStatus (IN uint32 uiReqId, 
														IN uint32 uiExpTime, 
														IN e_IFX_CMGR_Status eSubsStatus, 
														IN e_IFX_ReasonCode eRespCode, 
														IN void *pvPrivateData); 

e_IFX_Return IFX_SIPAPP_CMGR_BlindTxStatus(
					 	IN uint32 uiCallId,
						IN e_IFX_TransferStatus eTransferStatus, 
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData);

e_IFX_Return IFX_SIPAPP_CMGR_CallResumeResponse
                     (
                     IN uint32 uiCallId,
                     IN e_IFX_CMGR_Status eStatus,
                     IN e_IFX_ReasonCode eReason,
                     IN void* pvPrivateData );

e_IFX_Return IFX_SIPAPP_CMGR_CallHoldResponse(
                           IN uint32 uiCallId,
                           IN e_IFX_CMGR_Status eStatus,
                           IN e_IFX_ReasonCode eReason,
                           IN void* pvPrivateData);

void IFX_SIPAPP_CopyFaxParams(IN x_IFX_MediaParams *pxMediaParams); 

extern e_IFX_Return IFX_CIF_VLFromUrlGet(
										IN x_IFX_CalledAddr* pxAddr,
										OUT uchar8* pucVoiceLineId,
										OUT e_IFX_ReasonCode* peReason);
extern e_IFX_Return IFX_CIF_VLCodecInfoGet(
                   IN uchar8 ucVoiceLineId,
                   OUT x_IFX_CodecList* pxCodecParams,
                   OUT e_IFX_ReasonCode* peReason);

/******************************************************************
*  Function Name    : IFX_SIPAPP_CopyFaxParams
*  Description      : Copy Fax udp params to 0th location and tcp to location 1
*  Input Values     : MediaParams
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
 void IFX_SIPAPP_CopyFaxParams(IN x_IFX_MediaParams *pxMediaParams)
{
#ifdef FAX_SUPPORT				
	x_IFX_FaxParams xFaxParams={{0}};
	if(pxMediaParams->axFaxParams[0].xFaxCfg.uiTransportProtocol == IFX_TRPROTO_TCP){
		memcpy(&xFaxParams,&pxMediaParams->axFaxParams[0],sizeof(x_IFX_FaxParams));
		memcpy(&pxMediaParams->axFaxParams[0],&pxMediaParams->axFaxParams[1],
					 sizeof(x_IFX_FaxParams));
		memcpy(&pxMediaParams->axFaxParams[1],&xFaxParams,
					sizeof(x_IFX_FaxParams));
	}
#endif	
}				
/******************************************************************
*  Function Name    : IFX_SIPAPP_GetProxyInfo
*  Description      : Get Proxy Info 
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
void
IFX_SIPAPP_GetProxyInfo(IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
						x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling)
{
//   pxRouteParams->ucIsOutBoundProxy =IFX_FALSE;
  if(pxProfileSignaling->acOutboundProxyAddr[0])/*  &&  
		(pxRouteParams->ucIsOutBoundProxy==IFX_TRUE) && 
		(pxProfileSignaling->bEnableProxy==IFX_TRUE))*/
  {
   pxRouteParams->ucIsOutBoundProxy=IFX_TRUE;
	 pxProfileSignaling->acOutboundProxyAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN-1]=0;
   pxRouteParams->pcProxyAddr=pxProfileSignaling->acOutboundProxyAddr;
   pxRouteParams->unProxyPort=pxProfileSignaling->unOutboundProxyPort ;
   pxRouteParams->eProxyProtocol=IFX_TRPROTO_UDP;
  }

  else if((pxProfileSignaling->acProxyAddr[0]) &&
		      (pxProfileSignaling->bEnableProxy==IFX_TRUE))
  {
	 pxProfileSignaling->acProxyAddr[IFX_VMAPI_MAX_TRANS_ADDR_LEN-1]=0;
   pxRouteParams->pcProxyAddr=pxProfileSignaling->acProxyAddr;
   pxRouteParams->unProxyPort=pxProfileSignaling->unProxyPort;
   pxRouteParams->eProxyProtocol=pxProfileSignaling->ucProxyProtocol; 
  }
	
  return; 
}


/******************************************************************
*  Function Name    : IFX_SIPAPP_GetAuthInfo
*  Description      : Get Proxy Info 
*  Input Values     : uiId is Call or Request identifier.
											unFlag,If it's 0 then second parameter is Callid
											       If it's 1 then second parameter is ReqId
											pcUserName must be NULL initially
							 				pcPassword must be NULL initially				
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_GetAuthInfo(IN uint32 uiId,
											 IN uint16 unFlag,
											 IN char8* pcRealm,
											 char8* pcUserName,
											 char8* pcPassword)
{
  uint16 unLineId =0;
  e_IFX_ReasonCode eReason=0;		
  x_IFX_VMAPI_LineSignaling xLineSignaling={{{{"\0"}}}};
	
	if(unFlag)    
	{
    if(IFX_CMGR_LineIdFromReqIdGet(uiId,&unLineId,&eReason)==IFX_FAILURE){
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied: Invalid Line");
		   return IFX_SIP_FAILURE;
		}
	}
	else 	
	{
		unLineId = uiId;
  }
  
	/*Use line id to fetch Line Signaling Info*/
  xLineSignaling.ucLineId = unLineId;      
	ifx_get_LineSignaling(&xLineSignaling,IFX_F_DEFAULT); 
	
	/*Retrive UserName and passowrd based on Realm*/
	//for(i=0;i<xLineSignaling.ucNoOfSipAuthCfg;i++) 
	if(xLineSignaling.pxAuthCfg != NULL) {
		strcpy(pcUserName,xLineSignaling.pxAuthCfg->acSipAuthUsrName);
		strcpy(pcPassword,xLineSignaling.pxAuthCfg->acSipAuthPasswd);
	}
#if 0
	while(xLineSignaling.pxAuthCfg != NULL)
	{
    if(!strcmp(xLineSignaling.pxAuthCfg->acRealm,pcRealm)) 				  
	  {
	    strcpy(pcUserName,xLineSignaling.pxAuthCfg->acSipAuthUsrName);
		  strcpy(pcPassword,xLineSignaling.pxAuthCfg->acSipAuthPasswd);
		  break;
		 }
		 __ifx_list_GetNext((void*)&xLineSignaling.pxAuthCfg);
	}
#endif
	 ifx_vmapi_freeObjectList(&xLineSignaling,IFX_VMAPI_VL_SIGNALING);
	 
	 if(pcUserName[0]=='\0' || pcPassword[0]=='\0'){	
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied: Invalid Username/Password");
		    return IFX_SIP_FAILURE;
   }
	 return IFX_SIP_SUCCESS;
}				

/******************************************************************
*  Function Name    : IFX_SIPAPP_CMGR_SubnRespHdlr
*  Description      : State notify handler
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
void
IFX_SIPAPP_CMGR_SubnRespHdlr(IN uint32 uiCallId,
														 IN void* pxEventData)
{
  x_IFX_SIPAPP_SubscNotifyStatus *pxSubscStatus =
	(x_IFX_SIPAPP_SubscNotifyStatus*)pxEventData;
	
	e_IFX_CMGR_Status  eSubsStatus=IFX_CMGR_STATUS_FAIL;			 
  if(pxSubscStatus->eReason==IFX_200_RESP)
   {
		 eSubsStatus=IFX_CMGR_STATUS_SUCCESS; 				 
	 }
   else{
		 pxSubscStatus->uiExpires = 0;			 
	 }	 
		IFX_CMGR_SubnStatus(uiCallId,pxSubscStatus->uiExpires,
										    eSubsStatus,0/*TODO*/);				
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_StateNotifer
*  Description      : State notify handler
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_StateNotifer(IN_OUT uint32 *puiCallId,
                        IN e_SIPAPP_Events eEvent,
                        IN void *pxEventData)
{
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	switch(eEvent){
	  case IFX_INCOMINGCALL_SIGNAL:
		  { 
			  x_IFX_SIPAPP_IncomingCall *pxIncCall = 
				  (x_IFX_SIPAPP_IncomingCall *)pxEventData;
				x_IFX_CMGR_AddressInfo xFrom;
				x_IFX_CMGR_AddressInfo xTo;
        x_IFX_CMGR_CallParams xCallParams={0};
        /* Copy From */ 
        xFrom.eAddressType = IFX_CMGR_TYPE_VOIP;
				memcpy(&xFrom.uxAddressInfo.xVoipAddr,&pxIncCall->xCalledAddr,
												sizeof(x_IFX_CalledAddr));
				/* Copy To */
        xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
				memcpy(&xTo.uxAddressInfo.xVoipAddr,&pxIncCall->xUserCfg,
								sizeof(x_IFX_CalledAddr));
				
			  IFX_SIPAPP_GetMediaParams(*puiCallId,
				  &xCallParams.uxCallParams.xVoipParams.xVoipMediaParams,
				  pxIncCall->pvPrivateData);

			  xCallParams.eAgentType = IFX_CMGR_TYPE_VOIP;
			  xCallParams.uxCallParams.xVoipParams.uiReplacesCallId = pxIncCall->iConnId2;
				IFX_CIF_VLFromUrlGet(&xTo.uxAddressInfo.xVoipAddr,&xTo.ucLineId,&eReason);//Dare
				e_IFX_ReasonCode eReason = IFX_MAX_REASON;
        IFX_CMGR_CallInitiate(puiCallId, &xFrom, &xTo,
                            &xCallParams, 
					                  &eStatus,&eReason,
                  				  pxIncCall->pvPrivateData);
			  if(eStatus == IFX_CMGR_STATUS_FAIL){
				  /* Call Initiate Fails Check reason and act accordingly */
					IFX_SIPAPP_CMGR_RemoteCallRelease(*puiCallId,eReason,
												&xCallParams.uxCallParams.xVoipParams.xFwdAddr,
												pxIncCall->pvPrivateData);
					return IFX_SIP_FAILURE;
			  }
			  else if(eStatus == IFX_CMGR_STATUS_SUCCESS){
					/* Call Initiate is successful, Answer the Call */	
					IFX_SIPAPP_CMGR_RemoteCallAnswer(*puiCallId,pxIncCall->pvPrivateData);
		    }
				else if((eStatus == IFX_CMGR_STATUS_PENDING) && (eReason == IFX_ENDPOINT_RINGING)){
					/* Call Initiate is successful, Accept the Call */	
				  IFX_SIPAPP_CMGR_RemoteCallAccept(*puiCallId,pxIncCall->pvPrivateData);
							
				}
		    break;
		  }
	  case IFX_CALLPROG_SIGNAL:
	  case IFX_ALERT_SIGNAL:
		  IFX_CMGR_CallAccept(*puiCallId,&eStatus,&eReason);
		  break;
	  case IFX_STOPTONE_SIGNAL:
	  case IFX_RELEASE_SIGNAL:
			if(*puiCallId != 0){
		    IFX_CMGR_CallRelease(*puiCallId,IFX_TERMINATED,NULL,&eStatus,&eReason);
				/* To Avoid multiple release signals to CMGR. Bye after cancel case */
				*puiCallId = 0;
			}
      break;
	  case IFX_CONNECTED_SIGNAL:
		  IFX_CMGR_CallAnswer(*puiCallId,&eStatus,&eReason);
		  break;
	  case IFX_CALL_AUTH_REQD:
	   {
		   char8 acUserName[512]="",acPassword[512]="";
			 x_IFX_SIPAPP_AuthReqd	*pxAuth=(x_IFX_SIPAPP_AuthReqd*)pxEventData;
	     x_IFX_SIPAPP_UAAppData *pxTemp=
				         (x_IFX_SIPAPP_UAAppData *)pxAuth->pvPvtData;		 
		   if(pxTemp == NULL){
				 return IFX_SIP_FAILURE;
			 }	 
			 if(pxTemp->unLineId ==0){ 
			   IFX_CMGR_LineIdFromCallIdGet(*puiCallId,
                &(pxTemp->unLineId),&eReason);
			 }
			 if(IFX_SIPAPP_GetAuthInfo(pxTemp->unLineId,
                                 0,pxAuth->pcRealm,
		 												     acUserName,acPassword)==IFX_SIP_FAILURE)
		   {
				   return IFX_SIP_FAILURE;
			 }
				
			 if(pxAuth->pvPvtData)
			 {
         return IFX_SIPAPP_SetAuthData(*puiCallId,acUserName,acPassword,
				                              pxAuth->pvPvtData);  
	     }
			 return IFX_SIP_FAILURE;
		 }	
		   break;
	  case IFX_HOLD_SUCCESS:
		  eStatus = IFX_CMGR_STATUS_SUCCESS;
		  IFX_CMGR_CallHoldRsp(*puiCallId,&eStatus,&eReason);
		  break;
	  case IFX_HOLD_FAIL:
		  eStatus = IFX_CMGR_STATUS_FAIL;
		  IFX_CMGR_CallHoldRsp(*puiCallId,&eStatus,&eReason);
		  break;
	  case IFX_RESUME_SUCCESS:
		  eStatus = IFX_CMGR_STATUS_SUCCESS;
		  IFX_CMGR_CallResumeRsp(*puiCallId,&eStatus,&eReason);
		  break;
	  case IFX_RESUME_FAIL:
      eStatus = IFX_CMGR_STATUS_SUCCESS;
		  IFX_CMGR_CallResumeRsp(*puiCallId,&eStatus,&eReason);
		  break;
	  case IFX_CALL_QUEUE:
		  break;
	  case IFX_CALL_FWD_ADDR:
		  IFX_CMGR_CallRelease(*puiCallId,IFX_CALL_FORWARD,
				     (x_IFX_CalledAddr *)pxEventData,&eStatus,&eReason);
		  break;
	  case IFX_REMOTE_HOLD:

      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "CMGR Call Hold Called");
		  IFX_CMGR_CallHold(*puiCallId,&eStatus,&eReason);
      IFX_SIPAPP_CMGR_CallHoldResponse(
                           *puiCallId,
                           eStatus,eReason,
                           pxEventData);
		  break;
	  case IFX_REMOTE_RESUME:
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "CMGR Call Resume Called");
		  IFX_CMGR_CallResume(*puiCallId,&eStatus,&eReason);
			IFX_SIPAPP_CMGR_CallResumeResponse(
                           *puiCallId,
                           eStatus,eReason,
                           pxEventData);
		  break;
	  case IFX_EARLY_MEDIA:
		  break;
	  case IFX_REFER_STATUS_RECV:
			{
				x_IFX_SIPAPP_ReferStatus *pxReferStatus = (x_IFX_SIPAPP_ReferStatus*)pxEventData;
				e_IFX_TransferStatus eTransferStatus = IFX_CMGR_TRANSFER_FAILED;
				e_IFX_ReasonCode eRespCode = IFX_MAX_REASON;
				if(pxReferStatus->eReason == IFX_200_RESP){
					eTransferStatus = IFX_CMGR_TRANSFER_ACCEPTED;			
				}
				if(pxReferStatus->ucIsAtx){
          IFX_CMGR_AttendedTxStatus(*puiCallId,eTransferStatus,
	                                   eRespCode);
				}
				else {
		      IFX_CMGR_BlindTxStatus(*puiCallId,eTransferStatus,
					                        eRespCode);
				}
			  break;
			}
		case IFX_REFER_NOTIFY_STATUS_RECV:
			{
				x_IFX_SIPAPP_ReferStatus *pxReferStatus =(x_IFX_SIPAPP_ReferStatus*)pxEventData;
				if(pxReferStatus->eReason != IFX_200_RESP){
            IFX_SIPAPP_ReleaseCall(*puiCallId,pxReferStatus->pvAppData);
            IFX_CMGR_CallRelease(*puiCallId,IFX_REL_NO_NOTIFY,NULL,&eStatus,&eReason);      
				}	
		    break;
			}
	  case IFX_REFER_RECV:
    {
			x_IFX_SIPAPP_ReferRecvd *pxReferRecvd = (x_IFX_SIPAPP_ReferRecvd *)pxEventData;
			e_IFX_TransferStatus eTransferStatus;
			e_IFX_ReasonCode eRespCode;
			x_IFX_CMGR_AddressInfo xTargetAddr;
			memset(&xTargetAddr, 0, sizeof(x_IFX_CMGR_AddressInfo));
			xTargetAddr.eAddressType = IFX_CMGR_TYPE_VOIP;	
			memcpy(&xTargetAddr.uxAddressInfo.xVoipAddr,
						&pxReferRecvd->xTargetAddr,sizeof(x_IFX_CalledAddr));
			if(pxReferRecvd->uiReplacesCallId == 0){
         IFX_CMGR_BlindTx(*puiCallId,&xTargetAddr,
			                 		&eTransferStatus,&eRespCode);
			}
			else{
          IFX_CMGR_AttendedTx(*puiCallId,pxReferRecvd->uiReplacesCallId,&xTargetAddr,
                  						&eTransferStatus,&eRespCode);
					
			}
		  IFX_SIPAPP_CMGR_BlindTxStatus(*puiCallId,eTransferStatus,
												 eRespCode,pxReferRecvd->pvAppData);

		  break;
		}
	  case IFX_REG_STATUS:
     {
       x_IFX_SIPAPP_Register *pxRegister = (x_IFX_SIPAPP_Register*)pxEventData;
			 uint32 uiExpires=0;
			 e_IFX_CMGR_Status eStatus=IFX_CMGR_STATUS_FAIL;
			 e_IFX_ReasonCode eReason=IFX_MAX_REASON;
       
			 if(pxRegister->cRegStatus == IFX_ON)
       {
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"REG Status ON");
				 uiExpires = pxRegister->uiExpires;
				 eStatus = IFX_CMGR_STATUS_SUCCESS;
				 eReason = IFX_200_RESP;
       }	
       else if(pxRegister->uiExpires== 0)
	     {
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"UNREG SUCCESS");
				 uiExpires = 0;
				 eStatus = IFX_CMGR_STATUS_SUCCESS;
				 eReason = IFX_200_RESP;

	     }
       else if(pxRegister->cRegStatus == IFX_PENDING || pxRegister->eReason== IFX_TIMEOUT)
	     {
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"REG Error Retry Timer started");
				 uiExpires = pxRegister->uiExpires;
				 eStatus = IFX_CMGR_STATUS_SUCCESS;
				 eReason = IFX_TIMEOUT;
	     
			 }
			 
			 else if(pxRegister->cRegStatus == IFX_OFF)
	     {
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Registration Failed - NO TIMER started");
				 uiExpires = pxRegister->uiExpires;
				 eStatus = IFX_CMGR_STATUS_FAIL;
				 eReason = IFX_TERMINATED;
			 }

	     return IFX_CMGR_RegisterRsp(*puiCallId,uiExpires,eStatus,eReason);				
		 }
		 break;
	  case IFX_REG_AUTH_REQ:
	   {
		   char8 acUserName[512]="",acPassword[512]="";		
			 x_IFX_SIPAPP_AuthReqd	*pxAuth=(x_IFX_SIPAPP_AuthReqd*)pxEventData;
			
			 if(IFX_SIPAPP_GetAuthInfo(*puiCallId,1,pxAuth->pcRealm,
		 												     acUserName,acPassword)==IFX_SIP_FAILURE)
		   {
   	    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
								 "Failure:No Matching Auth Info Found");
				 return IFX_SIP_FAILURE;
			 }
		  
			 if(pxAuth->pvPvtData)
			 {
		     return IFX_SIPAPP_SetAuthInfoREG(*puiCallId,acUserName,
											                 acPassword,pxAuth->pvPvtData);  
	     }
			 return IFX_SIP_FAILURE;
		 }		
		  break;
		case IFX_REFER_NOTIFY_RECV:
		 {
			e_IFX_TransferStatus eTxStatus;
      x_IFX_SIPAPP_ReferStatus *pxReferStatus = 
							(x_IFX_SIPAPP_ReferStatus*)pxEventData;			
		  switch(pxReferStatus->eReason){
        case IFX_100_RESP:
					eTxStatus = IFX_CMGR_TRANSFER_PROCEEDING;			
				break;
        case IFX_200_RESP:
					eTxStatus = IFX_CMGR_TRANSFER_ANSWERED;			
				break;
				default:
					eTxStatus = IFX_CMGR_TRANSFER_FAILED;			
			}
			if((eTxStatus == IFX_CMGR_TRANSFER_PROCEEDING)&&
											(pxReferStatus->eTransferStatus==IFX_OFF)){
				eTxStatus = IFX_CMGR_TRANSFER_ANSWERED;			
			}
			if(pxReferStatus->ucIsAtx){
        IFX_CMGR_AttendedTxStatus(*puiCallId,eTxStatus,IFX_MAX_REASON);
			}
			else{
        IFX_CMGR_BlindTxStatus(*puiCallId,eTxStatus,IFX_MAX_REASON);
			}
		}
		break;
		case IFX_MWI_SUBSC_STATUS_RECV:	
		case IFX_CALLBACK_SUBSC_STATUS_RECV:
			{
							//x_IFX_SIPAPP_SubscNotifyStatus *pxSubscStatus
				IFX_SIPAPP_CMGR_SubnRespHdlr(*puiCallId,pxEventData);			
				return IFX_SIP_SUCCESS;
			 
		  }
			break;				
		case IFX_MWI_NOTIFY_RECV:	
			{
	     x_IFX_SIPAPP_VMNotifyRecvd *pxVMNotify=
			 (x_IFX_SIPAPP_VMNotifyRecvd*)pxEventData;
			 e_IFX_CMGR_Status eStatus;
			 e_IFX_ReasonCode eReason;
			 e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
			 x_IFX_CMGR_NotifyInfo xNotifyInfo={0};
			 xNotifyInfo.eSubsEvt =IFX_CMGR_SUBS_VOICE_MAIL; 
			 
			 memcpy(&xNotifyInfo.xFromAddress.uxAddressInfo.xVoipAddr, 
						  pxVMNotify->pxFrom,sizeof(x_IFX_CalledAddr));
			 xNotifyInfo.xFromAddress.eAddressType =IFX_CMGR_TYPE_VOIP;  
			 
			 memcpy(&xNotifyInfo.xToAddress.uxAddressInfo.xVoipAddr, 
						  pxVMNotify->pxTo,sizeof(x_IFX_CalledAddr));
			 xNotifyInfo.xToAddress.eAddressType =IFX_CMGR_TYPE_VOIP;  
			 
       xNotifyInfo.uxNotifyInfo.xVmNtfyInfo.bNewMsg = pxVMNotify->bNewMsg;
			 xNotifyInfo.uxNotifyInfo.xVmNtfyInfo.unNumOfUnread =pxVMNotify->unNumOfUnread;
       xNotifyInfo.uxNotifyInfo.xVmNtfyInfo.unTotalMsg = pxVMNotify->unTotalMsg;			
			 eRetVal=IFX_CMGR_NtfnRcv(puiCallId,pxVMNotify->uiExpires,&xNotifyInfo,  
												   &eStatus,&eReason,pxVMNotify->pvAppData);				 
			 if(eStatus == IFX_CMGR_STATUS_FAIL || eRetVal == IFX_FAILURE)
				 return IFX_SIP_FAILURE;
			 
			 return IFX_SIP_SUCCESS;		
			 
			}
			break;
		case IFX_MWI_AUTH_REQD:	
			{
		   char8 acUserName[512]="",acPassword[512]="";		
			 x_IFX_SIPAPP_AuthReqd	*pxAuth=(x_IFX_SIPAPP_AuthReqd*)pxEventData;
			 if(IFX_SIPAPP_GetAuthInfo(*puiCallId,1,pxAuth->pcRealm,
		 												     acUserName,acPassword)==IFX_SIP_FAILURE)
		   {
				 return IFX_SIP_FAILURE;
			 }
		  
			 if(pxAuth->pvPvtData)
			 {
				 return IFX_SIPAPP_SetAuthInfoMWI(*puiCallId,acUserName,
												                   acPassword,pxAuth->pvPvtData);
	     }
			 return IFX_SIP_FAILURE;
				
			}
			break;

		case IFX_CALLBACK_SUBSC_RECV:
			{
			 x_IFX_SIPAPP_CBSubscRecvd* pxCBSubscRecvd =
       ( x_IFX_SIPAPP_CBSubscRecvd*)pxEventData;
			 e_IFX_CMGR_Status eStatus;
			 e_IFX_ReasonCode eReason;
			 x_IFX_CMGR_AddressInfo xTo, xFrom;
			 uint16 unLineId =0;

			 memcpy(&xFrom.uxAddressInfo.xVoipAddr, 
						  pxCBSubscRecvd->pxFrom,sizeof(x_IFX_CalledAddr));
			 xFrom.eAddressType =IFX_CMGR_TYPE_VOIP;  
			 
			 memcpy(&xTo.uxAddressInfo.xVoipAddr, 
						  pxCBSubscRecvd->pxTo,sizeof(x_IFX_CalledAddr));
			 
			 xTo.eAddressType =IFX_CMGR_TYPE_VOIP;  			 

			 IFX_CMGR_SubnRcv (IFX_CMGR_SUBS_AUTO_REDIAL,&xFrom,&xTo,
											   &pxCBSubscRecvd->uiExpires,pxCBSubscRecvd->pvAppData,&unLineId, 
												 &pxCBSubscRecvd->uiReqId, 
												 &eStatus,&eReason);
       eReason = unLineId; /*Slight fix since callmgr have wierd requirment*/
			 return IFX_SIPAPP_CMGR_SubnStatus(pxCBSubscRecvd->uiReqId,
					    pxCBSubscRecvd->uiExpires, eStatus,eReason,
							pxCBSubscRecvd->pvAppData);

			}
			break;
		case IFX_CALLBACK_AUTH_REQD:
			{
	      char8 acUserName[IFX_MAX_USR_NAME]="",acPassword[IFX_MAX_USR_NAME]="";
				x_IFX_SIPAPP_AuthReqd	*pxAuth=(x_IFX_SIPAPP_AuthReqd*)pxEventData;
				
			  if(IFX_SIPAPP_GetAuthInfo(*puiCallId,1,pxAuth->pcRealm,
														      acUserName,acPassword)==IFX_SIP_FAILURE)
			 
				   return IFX_SIP_FAILURE;			  
		    
				if(pxAuth->pvPvtData)
				{
				 return IFX_SIPAPP_SetAuthDataForCB(*puiCallId,acUserName,
												                    acPassword,pxAuth->pvPvtData);  
        }
				return IFX_SIP_FAILURE;

			}
	    break;

		case IFX_CALLBACK_NOTIFY_STATUS_RECV:
			{
				return IFX_SIP_SUCCESS;
			}
			break;
			
	  case IFX_CALLBACK_NOTIFY_RECV:
		 { 
			 x_IFX_SIPAPP_CBNotifyRecvd *pxCBNotify=
			 (x_IFX_SIPAPP_CBNotifyRecvd*)pxEventData;
			 e_IFX_CMGR_Status eStatus;
			 e_IFX_ReasonCode eReason;
       
			 x_IFX_CMGR_NotifyInfo xNotifyInfo={0};

			 xNotifyInfo.eSubsEvt =IFX_CMGR_SUBS_AUTO_REDIAL ; 
			 memcpy(&xNotifyInfo.xFromAddress.uxAddressInfo.xVoipAddr, 
						  pxCBNotify->pxFrom,sizeof(x_IFX_CalledAddr));
			 xNotifyInfo.xFromAddress.eAddressType =IFX_CMGR_TYPE_VOIP;  
			 
			 memcpy(&xNotifyInfo.xToAddress.uxAddressInfo.xVoipAddr, 
						  pxCBNotify->pxTo,sizeof(x_IFX_CalledAddr));
			 xNotifyInfo.xToAddress.eAddressType =IFX_CMGR_TYPE_VOIP;  
			 
			 xNotifyInfo.uxNotifyInfo.xAutoNtfyInfo.bRemoteFree = 
			 pxCBNotify->bIsRemoteFree;
			 return IFX_CMGR_NtfnRcv(puiCallId,pxCBNotify->uiExpires,&xNotifyInfo,  
												       &eStatus,&eReason,pxCBNotify->pvAppData);				 
			 
		 }		 
			break;
#ifdef INFO_SUPPORT
	case IFX_INFO:
		  IFX_CMGR_DigitsInCallSnd(*puiCallId,NULL,&eStatus,&eReason);
		  break;
#endif
	  case IFX_MEDIA_UPDATE:
		  {
			  x_IFX_MediaParams xMediaParams={{0}};
				x_IFX_CMGR_MediaParams xCmgrMediaParms={0};
			  IFX_SIPAPP_GetMediaParams(*puiCallId,&xMediaParams,pxEventData);//TODO
				memcpy(&xCmgrMediaParms.uxMediaParams.xVoipMediaParams,
							&xMediaParams,sizeof(x_IFX_MediaParams));
				xCmgrMediaParms.eAgentType = IFX_CMGR_TYPE_VOIP;
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "CMGR Media Update Called");
		    IFX_CMGR_MediaNegReq(*puiCallId,&xCmgrMediaParms,
                             &eStatus,&eReason);
         IFX_SIPAPP_CMGR_NegotiateMediaResponse(
                        *puiCallId,&xCmgrMediaParms,
												&eStatus,&eReason,pxEventData);

		    break;
		  }
	  case IFX_MEDIA_UPDATE_FAILURE:
		    eStatus = IFX_CMGR_STATUS_FAIL;
		    IFX_CMGR_MediaNegRsp(*puiCallId,NULL,
                             &eStatus,&eReason);
		     break;
	  case IFX_MEDIA_UPDATE_SUCCESS:
	  	{
			  x_IFX_MediaParams xMediaParams={{0}};
				x_IFX_CMGR_MediaParams xCmgrMediaParms={0};
			  IFX_SIPAPP_GetMediaParams(*puiCallId,&xMediaParams,pxEventData);
				memcpy(&xCmgrMediaParms.uxMediaParams.xVoipMediaParams,
							&xMediaParams,sizeof(x_IFX_MediaParams));
				xCmgrMediaParms.eAgentType = IFX_CMGR_TYPE_VOIP;
			  IFX_CMGR_MediaNegRsp(*puiCallId,&xCmgrMediaParms,
                            &eStatus,&eReason);
		     break;
		  }
	  case IFX_SDP_ANSWER:
		  {
			  x_IFX_MediaParams xMediaParams={{0}};
				x_IFX_CMGR_MediaParams xCmgrMediaParms={0};
			  IFX_SIPAPP_GetMediaParams(*puiCallId,&xMediaParams,pxEventData);
				memcpy(&xCmgrMediaParms.uxMediaParams.xVoipMediaParams,
							&xMediaParams,sizeof(x_IFX_MediaParams));
				xCmgrMediaParms.eAgentType = IFX_CMGR_TYPE_VOIP;
			  IFX_CMGR_MediaParamsSet(*puiCallId,&xCmgrMediaParms);
		  }
		break;
#ifdef MESSAGE_SUPPORT
	  case IFX_MSG:
			{
				x_IFX_Msg* pxMsg = (x_IFX_Msg*)pxEventData;
	      x_IFX_CMGR_AddressInfo xFrom,xTo;
				e_IFX_CMGR_Status eSmsStatus; 
				e_IFX_ReasonCode  eReason=0;
				uint16 unSmsId=0;
				
				memcpy(&pxMsg->xTo,&xTo.uxAddressInfo.xVoipAddr,sizeof(x_IFX_CalledAddr));				
	      xTo.eAddressType= IFX_CMGR_TYPE_VOIP;			
				
				memecpy(&xFrom.uxAddressInfo.xVoipAddr,&pxMsg->xFrom,sizeof(x_IFX_CalledAddr));				
	      xFrom.eAddressType= IFX_CMGR_TYPE_VOIP;			
				
				IFX_CMGR_SMS_SmsSnd (&xFrom,&xTo,pxMsg->acMessg,&unSmsId, 
														 &eSmsStatus, &eReason);

				*puiCallId = (uint32)unSmsId;
				if(eSmsStatus==IFX_CMGR_STATUS_FAIL)
				{
				 IFX_SIPAPP_InstMsgReject(*puiCallId,IFX_MSG_NOT_FOUND,				       
												 NULL, pxMsg->pvPrivateData);						
				 return IFX_SIP_SUCCESS;
				}				
				
				IFX_SIPAPP_InstMsgAccept (*puiCallId,pxMsg->pvPrivateData);						
				return IFX_SIP_SUCCESS;
				
			}
		  break;
	  case IFX_MSG_FAIL:
			{
			  IFX_CMGR_SMS_SmsStatusSet((uint16)*puiCallId,IFX_CMGR_STATUS_FAIL); 
			  return IFX_SIP_SUCCESS;									
			}
		  break;
	  case IFX_MSG_SUCCESS:
			{			 				
			  IFX_CMGR_SMS_SmsStatusSet((uint16)*puiCallId,IFX_CMGR_STATUS_SUCCESS); 
			  return IFX_SIP_SUCCESS;
			}
		  break;
		case IFX_MSG_AUTH_REQ:
			{
	      char8 acUserName[IFX_MAX_USR_NAME]="",acPassword[IFX_MAX_USR_NAME]="";
				x_IFX_SIPAPP_AuthReqd	*pxAuth=(x_IFX_SIPAPP_AuthReqd*)pxEventData;
				
			  if(IFX_SIPAPP_GetAuthInfo(*puiCallId,1,pxAuth->pcRealm,
														     acUserName,acPassword)==IFX_SIP_FAILURE)
			  {
				 return IFX_SIP_FAILURE;
			  }
		    
				if(pxAuth->pvPvtData)
				{
				 return IFX_SIPAPP_SetAuthInfoMsg(*puiCallId,acUserName,
												                 acPassword,pxAuth->pvPvtData);  
        }
				return IFX_SIP_FAILURE;
				
			}	
		break;
#endif
      case IFX_OPTIONS:
			{
#ifdef HANDLE_OPTIONS
				x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*) pxEventData;
				x_IFX_CMGR_AddressInfo xFrom;
				x_IFX_CMGR_AddressInfo xTo;
        x_IFX_CMGR_CallParams xCallParams={0};
				e_IFX_ReasonCode  eReason=IFX_OPTION_ARRIVED;
			  e_IFX_CMGR_Status eStatus;
        uint32 iFlag = IFX_OPTIONS_ACCEPT;
#ifdef DARE_CUST
				e_IFX_SIP_Ecode eEcode;
				uchar8 ucIsfrmSrvr = 0;
				x_IFX_SIPAPP_UserRegistration *pxUserReg = NULL;
#endif
        /* Copy From */ 
        xFrom.eAddressType = IFX_CMGR_TYPE_VOIP;
				memcpy(&xFrom.uxAddressInfo.xVoipAddr,&pxAppData->xFrom,
												sizeof(x_IFX_CalledAddr));
				/* Copy To */
        xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
				memcpy(&xTo.uxAddressInfo.xVoipAddr,&pxAppData->xTo,
								sizeof(x_IFX_CalledAddr));

				IFX_CIF_VLFromUrlGet(&xTo.uxAddressInfo.xVoipAddr,&xTo.ucLineId,&eReason);
				eReason=IFX_OPTION_ARRIVED;
				
			  IFX_SIPAPP_GetMediaParams(*puiCallId,
				  &xCallParams.uxCallParams.xVoipParams.xVoipMediaParams,
				  (void*)pxAppData);

			  xCallParams.eAgentType = IFX_CMGR_TYPE_VOIP;
        IFX_CMGR_CallInitiate(puiCallId, &xFrom, &xTo,
                              &xCallParams, 
					                    &eStatus,&eReason,
                  				    (void*)pxAppData);
				//*puiCallId = (uint32) pxEventData;
#ifdef DARE_CUST
			if ((eStatus!=IFX_CMGR_STATUS_FAIL) || (eStatus==IFX_CMGR_STATUS_FAIL && eReason != IFX_USER_NOT_FOUND)){
        if (IFX_SIP_SUCCESS != IFX_SIPAPP_OptionsInfo(xTo.ucLineId,&xFrom,&ucIsfrmSrvr,&pxUserReg)){
					IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Falied!!!");
				}
				
				else if(ucIsfrmSrvr && pxUserReg->unOptionsTimerId){

					//Once Dare proprietry objects are implemented, read timervalue and refresh timer, timervalue=5min for time being

					if (IFX_SIP_FAILURE == IFX_SIPAPP_StopTimer(pxUserReg->unOptionsTimerId)){
						IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Error:Could Not Stop OPTIONS Timer");
					}
						
					if (access("/tmp/options", F_OK ) == -1){
						if (IFX_SIP_FAILURE == IFX_SIPAPP_StartTimer(5*60*1000,
                                      (void*)IFX_SIPAPP_SendRegister,(void*) pxUserReg,
                                      &pxUserReg->unOptionsTimerId, &eEcode)){
							IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Error:Could Not Start OPTIONS Timer");
						}
					}
        }
			}
#endif
				if(eStatus==IFX_CMGR_STATUS_FAIL)
        {
         	iFlag = IFX_OPTIONS_REJECT;
        }
        else
				{
          IFX_CIF_VLCodecInfoGet(xTo.ucLineId,&pxAppData->xCodecList,&eReason);
        }
#if 0
				if(eStatus==IFX_CMGR_STATUS_FAIL)
				{
				 iFlag = IFX_OPTIONS_REJECT;
				}
        else{
          uchar8 ucLineId;
          IFX_CIF_VLFromUrlGet(&pxAppData->xTo,&ucLineId,&eReason);
          IFX_CIF_VLCodecInfoGet(ucLineId,&pxAppData->xCodecList,&eReason);
        }		
#endif
			  IFX_SIPAPP_SendOptionsResp((void*)pxAppData,iFlag,
				eReason,&xCallParams.uxCallParams.xVoipParams.xFwdAddr);
				return IFX_SIP_SUCCESS;
#else
/*To remove Option handling  send  FAILURE - Method not supported*/
			return IFX_SIP_FAILURE;
#endif
			}
			break;
		default:
			IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"NO STATE TO HANDLE");
			break;
	}
	return IFX_SIP_SUCCESS;
}
/*!
   \brief      This API is to be called by the Agent whenever it wants to make
               a call to any other agent.
   \param[out] puiCallId is the identifier of the call
   \param[in]  pxTo is the address/extension number/PSTN Phone number
               identifying the called party. For the FXS/DECT agents getting to
               VoIP it is the user at domain form of address uri and type VoIP.
               For FXS/DECT reaching to PSTN it shall be PSTN number.
               For FXS/DECT reaching FXS/DECT it shall be the peer party's extn.
               For FXO agent it shall be either be the remote VoIP URI (GW mode)
               or the FXO line ID (own phone number).
               For NA it shall be the VoIP Line URI.
   \param[in]  pxFrom is the address/endpoint Id/PSTN number identifying the
               calling party.
               For FXS/DECT agents it shall be their own endpoint id and type
               extension.
               For FXO agent it shall be its line id. The FXO agent shall
               fill the PSTN number in the phone number parameter.
               For NA it shall be the address of the remote VoIP party and type
               as VoIP.
   \param[in] pxCallParams Contains extra parameters for the call. Every
                  agent has its own structure that it has to write to.
   \param[out] peStatus is the status of the request
   \param[out] peReason - incase of failure, this parameter provides the
               specific reason
   \param[in] pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_CreateCall(IN uint32 uiCallId, 
				            	 IN x_IFX_CMGR_AddressInfo *pxFrom,
					             IN x_IFX_CMGR_AddressInfo *pxTo, 
					             IN x_IFX_CMGR_CallParams *pxCallParams, 
					             OUT e_IFX_CMGR_Status* peStatus,
					             OUT e_IFX_ReasonCode* peReason,
					             OUT void** ppvPrivateData)

{
  uint16 unSrvPdr ;
  e_IFX_ReasonCode eReason;
  x_IFX_VMAPI_VoiceLine xVoiceLine={{{{"\0"}}}};
  x_IFX_VMAPI_ProfileSignaling xVoiceProfile={{{{"\0"}}}};
  x_IFX_SIPAPP_CallParams xCallParams={{{0}}};
  x_IFX_SIPAPP_RouteParams xRouteParams={0};

	*peStatus = IFX_CMGR_STATUS_PENDING;
	*peReason = IFX_MAX_REASON;
	
  /*Get Profile Information*/
  IFX_CMGR_LineIdFromCallIdGet(uiCallId,&unSrvPdr,&eReason);
  xVoiceLine.ucLineId = unSrvPdr;
  ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT);
  xVoiceProfile.ucProfileId = xVoiceLine.ucProfileId;
  ifx_get_ProfileSignaling (&xVoiceProfile,IFX_F_DEFAULT);
	
  /* Route Params*/
  xRouteParams.pxTo = &pxTo->uxAddressInfo.xVoipAddr;
  xRouteParams.pxFrom = &pxFrom->uxAddressInfo.xVoipAddr;
  xRouteParams.unLocalTcpPort= 0;
  IFX_SIPAPP_GetProxyInfo(&xRouteParams,&xVoiceProfile);
						
  /*Get Call Params*/
  xCallParams.uiReplacesCallId = pxCallParams->uxCallParams.xVoipParams.uiReplacesCallId;
  xRouteParams.bSupressCallerId = pxCallParams->uxCallParams.xVoipParams.bSupressCallerId;
  if(xRouteParams.bSupressCallerId){
    xCallParams.szPhoneNumber[0]='\0';
	}
	else{
		strcpy(xCallParams.szPhoneNumber,
					pxCallParams->uxCallParams.xVoipParams.szPhoneNumber);
		IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
						 xCallParams.szPhoneNumber);
	}
  
	memcpy(&xCallParams.xMediaParams,
	     &pxCallParams->uxCallParams.xVoipParams.xVoipMediaParams,
		 sizeof(xCallParams.xMediaParams));
	
  IFX_SIPAPP_CopyFaxParams(&xCallParams.xMediaParams);
	
 	return IFX_SIPAPP_CreateCall(uiCallId,
                        xVoiceProfile.ucProfileId,
					    &xRouteParams,
						&xCallParams,
					    ppvPrivateData);

}

/*!
   \brief   Will be called to inform the call initiating agent that the
            called agent has accpeted the call and in ringing.
   \param[in]   uiCallId is the identifier of the call
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallAccept(
                        IN uint32 uiCallId,
                        IN void* pvPrivateData)
{
#ifdef RFC_3262
  x_IFX_CMGR_MediaParams xMediaParams={0};
#endif	
	e_IFX_ReasonCode eReason;
	uint16 unLineId =0;
  /*Get Profile Information*/
  x_IFX_VMAPI_VoiceLine xVoiceLine ={{{{"\0"}}}};
  IFX_CMGR_LineIdFromCallIdGet(uiCallId,&unLineId,&eReason);
	xVoiceLine.ucLineId = unLineId;
  ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT);
#ifdef RFC_3262
  IFX_CMGR_MediaParamsGet(uiCallId,&xMediaParams);

  IFX_SIPAPP_CopyFaxParams(&xMediaParams.uxMediaParams.xVoipMediaParams);

  return IFX_SIPAPP_AcceptCall(uiCallId,xVoiceLine.ucProfileId,
                               &xMediaParams.uxMediaParams.xVoipMediaParams,
	                           pvPrivateData);
#else
  return IFX_SIPAPP_AcceptCall(uiCallId,xVoiceLine.ucProfileId,
                               NULL,
	                           pvPrivateData);
#endif	
}

/*!
   \brief   Will be called to inform the call initiating agent that the
            called agent has answered the call and the call is now established
   \param[in]   uiCallId is the identifier of the call
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallAnswer(
                        IN uint32 uiCallId,
                        IN void* pvPrivateData)
{
  x_IFX_CMGR_MediaParams xMediaParams={0};
	e_IFX_ReasonCode eReason;
	uint16 unLineId=0;
  /*Get Profile Information*/
  x_IFX_VMAPI_VoiceLine xVoiceLine ={{{{"\0"}}}};
  IFX_CMGR_LineIdFromCallIdGet(uiCallId,&unLineId,&eReason);
	xVoiceLine.ucLineId = unLineId;
  ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT);
  IFX_CMGR_MediaParamsGet(uiCallId,&xMediaParams);
  IFX_SIPAPP_CopyFaxParams(&xMediaParams.uxMediaParams.xVoipMediaParams);
  return IFX_SIPAPP_AnswerCall(uiCallId,xVoiceLine.ucProfileId,
					  &xMediaParams.uxMediaParams.xVoipMediaParams,
				      pvPrivateData);
}

 /*!
   \brief   Will be called by call manager to infrom the agent that the
            peer agent is requesting the call to be put on hold.
   \param[in]   uiCallId is the identifier of the call
   \param[out]  peStatus - current status of the request
   \param[out]  peReason - incase of failure, this parameter provides the
                specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallHold(
                     IN uint32 uiCallId,
                     OUT e_IFX_CMGR_Status* peStatus,
                     OUT e_IFX_ReasonCode* peReason,
                     IN void* pvPrivateData)
{
	 *peStatus = IFX_CMGR_STATUS_PENDING;
   *peReason = IFX_MAX_REASON;	 
   return IFX_SIPAPP_HoldCall(uiCallId,pvPrivateData);
}
 /*!
   \brief   Will be called by call manager to infrom the agent that the
            peer agent is requesting the held call to be resumed.
   \param[in]   uiCallId is the identifier of the call
   \param[out]  peStatus - current status of the request
   \param[out]  peReason - incase of failure, this parameter provides the
                specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallResume(
                        IN uint32 uiCallId,
                        OUT e_IFX_CMGR_Status* peStatus,
                        OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData)
{
	*peStatus = IFX_CMGR_STATUS_PENDING;
  *peReason = IFX_MAX_REASON;	 
	return IFX_SIPAPP_ResumeCall(uiCallId,pvPrivateData);
}


/*!
   \brief   Will be called by call manager to tell the
            agent about remote agent has successfully served/failed to serve
            the hold request on the call
   \param[in]   uiCallId is the identifier of the call
   \param[in]  eStatus is the status of the request
   \param[in]  eReason - incase of failure, this parameter provides the
                  specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_CallHoldResponse(
                           IN uint32 uiCallId,
                           IN e_IFX_CMGR_Status eStatus,
                           IN e_IFX_ReasonCode eReason,
                           IN void* pvPrivateData)
{
	if(eStatus == IFX_CMGR_STATUS_SUCCESS){
		return IFX_SIPAPP_RemHoldResAccept(uiCallId,pvPrivateData);
	}
	else if(eStatus == IFX_CMGR_STATUS_FAIL){
		return IFX_SIPAPP_RemHoldResReject(uiCallId,eReason,pvPrivateData);
	}
	return IFX_SUCCESS;
}

/*!
   \brief   Will be called by call manager to tell the
            agent about remote agent has successfully served/failed to serve
            the resume call request on the call
   \param[in]   uiCallId is the identifier of the call
   \param[in]  eStatus is the status of the request
   \param[in]  eReason - incase of failure, this parameter provides the
                  specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_SIPAPP_CMGR_CallResumeResponse
                     (
                     IN uint32 uiCallId,
                     IN e_IFX_CMGR_Status eStatus,
                     IN e_IFX_ReasonCode eReason,
                     IN void* pvPrivateData )
{
	if(eStatus == IFX_CMGR_STATUS_SUCCESS){
		return IFX_SIPAPP_RemHoldResAccept(uiCallId,pvPrivateData);
	}
	else if(eStatus == IFX_CMGR_STATUS_FAIL){
		return IFX_SIPAPP_RemHoldResReject(uiCallId,eReason,pvPrivateData);
	}
	return IFX_SUCCESS;
}


/*!
   \brief   Will be called by call manager the to terminate current call
   \param[in]  uiCallId is the identifier of the call
   \param[in]  eReleaseReason parameter provides the reason for
               call disruption/rejection
   \param[in]  pxFwdAddr is the address that the call has to be forwarded to.
               It is only relevant for the NA.
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
 */
e_IFX_Return IFX_SIPAPP_CMGR_RemoteCallRelease(
                     IN uint32 uiCallId,
                     IN e_IFX_ReasonCode eReleaseReason,
                     IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
                     IN void* pvPrivateData)
{
	e_IFX_ReasonCode eReason=0;
  if((((x_IFX_SIPAPP_UAAppData *)pvPrivateData)->unLineId ==0) &&
			(uiCallId)){ 
			   IFX_CMGR_LineIdFromCallIdGet(uiCallId,
						&(((x_IFX_SIPAPP_UAAppData *)pvPrivateData)->unLineId),&eReason);
	}

	if(((x_IFX_SIPAPP_UAAppData *)pvPrivateData)->iFlag & IFX_SIPAPP_ORIGINATING){
	  return IFX_SIPAPP_ReleaseCall(uiCallId,pvPrivateData);
	}
	else
	{
		if(IFX_TERMINATED == eReleaseReason) /*Chaitanya*/
	  	return IFX_SIPAPP_ReleaseCall(uiCallId,pvPrivateData);
		else
			return IFX_SIPAPP_RejectCall(uiCallId,eReleaseReason,
					  			  pxFwdAddr,pvPrivateData);
	}
	
}

/*!
   \brief   Used be called by CMGR  to send digits in the middle of
            a call to an agent.
   \param[in]  uiCallId is the identifier of the call
   \param[in]  pxDgtInfo The digit string and type of transmission method
   \param[out] peReason  incase of failure, this parameter provides the
               specific reason
   \param[in]  pvPrivateData is a pointer to the private data needed by an
               agent. The CMGR shall maintain this pointer and return it to
               the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
#ifdef INFO_SUPPORT
e_IFX_Return IFX_SIPAPP_CMGR_RecvDigitsInCall(
                     IN uint32 uiCallId,
                     IN x_IFX_CMGR_DgtInfo *pxDigitInfo,
                     IN void* pvPrivateData)
{
	x_IFX_InfoMethod xDigitInfo={0};
	int32 iCount=0;
	for (iCount =0;iCount<strlen(pxDigitInfo->szDigits);iCount++){
    xDigitInfo.ucDigit = pxDigitInfo->szDigits[iCount];
	  xDigitInfo.eEvent = IFX_INFO_DTMF_CONTENT;
	  if(IFX_SIPAPP_SendINFO(uiCallId,&xDigitInfo,pvPrivateData) 
        != IFX_SUCCESS){
      return IFX_SIP_FAILURE;
    }
	}
	return IFX_SIP_SUCCESS;
}
#endif
/*!
    \brief     This call-back is to be called by the CMGR to get
               the media parameters. This is called after the invocation of
               the CallAccept API and the CallAnswer API. This call-back
               should only be registered by  agents which need some media
               negotiation i.e. NA or DECT agent. Will be needed in Hold/Resume
               Scenarios. In case of a hold request from a remote party the
               NA shall call  CallHold API in course of which the CMGR shall
               invoke this CB.
    \param[in]  uiCallId is the identifier of the call
    \param[out] pxMediaParams is the reference to the media parameters.
    \param[in] pvPrivateData is the private data for use by the agent
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_GetMediaParams(
                        IN uint32 uiCallId,
                        OUT x_IFX_CMGR_MediaParams* pxMediaParams,
                        IN void* pvPrivateData)
{
	pxMediaParams->eAgentType = IFX_CMGR_TYPE_VOIP;
	return IFX_SIPAPP_GetMediaParams(uiCallId,&pxMediaParams->uxMediaParams.xVoipMediaParams,pvPrivateData);
}


/*!
    \brief  This call-back is called by the agent to offer codecs to an agent
            when media change has been triggered by the peer agent asynchronously
            using the IFX_CMGR_NegotiateMediaRequest API.
            This will be invoked on the NA/DECT agent to change the media during
            a call. Only the DECT & NA should register it. On this the NA
            should send out a re-Invite with the prameters listed and the
            DECT agent should offer the codecs to the DECT PP.
    \param[in]  uiCallId is the identifier of the call
    \param[in,out] pxMediaParams is the reference to the media parameters.
   \param[out] peStatus is the status of the request SUCCESS/FAILED/PENDING
   \param[out] peReason this parameter provides the specific reason
    \param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_NegotiateMediaRequest(
                        IN uint32 uiCallId,
                        IN_OUT x_IFX_CMGR_MediaParams* pxCMgrMediaParams,
                        OUT e_IFX_CMGR_Status* peStatus,
                        OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData)
{
  x_IFX_CMGR_MediaParams xMediaParams={0};
	memcpy(&xMediaParams,pxCMgrMediaParams,sizeof(x_IFX_CMGR_MediaParams));
  IFX_SIPAPP_CopyFaxParams(&xMediaParams.uxMediaParams.xVoipMediaParams);
	return IFX_SIPAPP_UpdateMediaParams(uiCallId,&xMediaParams.uxMediaParams.xVoipMediaParams,pvPrivateData);
}

/*!
    \brief  This call-back is called by the CMGR to inform an  agent about
            the media change request it had initiated via the
            IFX_CMGR_NegotiateMediaRequest API.
            This will be invoked on the NA/DECT agent to respond with the
            final answer. It shall also be used by the NA to give an
            SDP answer to the UPADTE/Re-Invite it had received.
    \param[in]  uiCallId is the identifier of the call
    \param[in] pxMediaParams is the reference to the media parameters.
   \param[in,out] peStatus is the status of the request SUCCESS/FAILED/PENDING
   \param[in,out] peReason this parameter provides the specific reason
    \param[in] pvPrivateData is the private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_SIPAPP_CMGR_NegotiateMediaResponse(
                        IN uint32 uiCallId,
                        IN x_IFX_CMGR_MediaParams* pxCMgrMediaParams,
                        IN_OUT e_IFX_CMGR_Status* peStatus,
                        IN_OUT e_IFX_ReasonCode* peReason,
                        IN void* pvPrivateData
                        )
{  
  if(*peStatus == IFX_SUCCESS){
    x_IFX_CMGR_MediaParams xMediaParams={0};
	  memcpy(&xMediaParams,pxCMgrMediaParams,sizeof(x_IFX_CMGR_MediaParams));
    IFX_SIPAPP_CopyFaxParams(&xMediaParams.uxMediaParams.xVoipMediaParams);
	  return IFX_SIPAPP_AcceptUpdatedMediaParams(uiCallId,&xMediaParams.uxMediaParams.xVoipMediaParams,
								                  pvPrivateData);
  }
  else if(*peStatus == IFX_FAILURE){
	  return IFX_SIPAPP_RejectUpdatedMediaParams(uiCallId,peReason,
					                             pvPrivateData);
  }
  return IFX_SUCCESS; 
	
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_GetRouteInfo
*  Description      : Create call
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/

void
IFX_SIPAPP_GetRouteInfo(IN  uint16 unLineId,
												OUT x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling,
												OUT x_IFX_SIPAPP_RouteParams* pxRouteParams, 
												OUT x_IFX_CalledAddr *pxFrom,
												OUT uint32* puiProfileId)
{
    x_IFX_VMAPI_VoiceLine xVoiceLine={{{{"\0"}}}};
    x_IFX_VMAPI_LineSignaling xLineSignaling={{{{"\0"}}}};
    
		/*Get ServiceProvider Id based on line id*/
    xVoiceLine.ucLineId = unLineId;
    ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT);
    *puiProfileId = xVoiceLine.ucProfileId;
    /*Get Profile Signaling based on Profile ID*/
    pxProfileSignaling->ucProfileId = xVoiceLine.ucProfileId;
    ifx_get_ProfileSignaling (pxProfileSignaling,IFX_F_DEFAULT);
  
    /*Get LineSignaling Information*/
    xLineSignaling.ucLineId = unLineId;
    ifx_get_LineSignaling(&xLineSignaling,IFX_F_DEFAULT); 
  
    /*Get From Header*/
		if(pxFrom!=NULL)
		{
      strcpy(pxFrom->acDisplayName,xLineSignaling.acSipDispName);
      strcpy(pxFrom->acUserName,xLineSignaling.acSipUserName);
      strcpy(pxFrom->acCalledAddr,pxProfileSignaling->acUADomain);  
      pxFrom->ucAddrType=IFX_SIP_URL;
      if(IFX_SIP_ValidateIPv4Addr(pxFrom->acCalledAddr))
      {
	      pxFrom->ucAddrType=IFX_IP_ADDR;
      } 
      pxFrom->unPort=pxProfileSignaling->unUAPort;
      pxFrom->ucAddrProto=pxProfileSignaling->ucUAProtocol;	
		}
	 	ifx_vmapi_freeObjectList(&xLineSignaling,IFX_VMAPI_VL_SIGNALING);
    /*Get Proxy Info*/
    IFX_SIPAPP_GetProxyInfo(pxRouteParams,pxProfileSignaling);
		return;
}
#ifdef MESSAGE_SUPPORT
/******************************************************************
*  Function Name    : IFX_SIPAPP_CMGR_SendInstMsg
*  Description      : Create call
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
e_IFX_Return 
IFX_SIPAPP_CMGR_SendInstMsg(IN x_IFX_CMGR_AddressInfo *pxFrom,
														IN x_IFX_CMGR_AddressInfo *pxTo,
														IN char8* szSmsBody,
														IN boolean bUnread,
														IN uint16 unSmsId,
														OUT e_IFX_CMGR_Status* peStatus,
														OUT e_IFX_ReasonCode* peReason)
{			
  x_IFX_SIPAPP_RouteParams xRouteParams={0}; 
	uint32 uiPvtData = 0, uiProfileId;
  uint16 unLineId;	
  e_IFX_ReasonCode eReason;  					
  x_IFX_VMAPI_ProfileSignaling xProfileSignaling={{{"\0"}}};	
	
	if(IFX_CMGR_LineIdFromReqIdGet((uint32)unSmsId, &unLineId,&eReason)
     == IFX_FAILURE)
  {
    *peStatus = IFX_CMGR_STATUS_FAIL;
    *peReason = eReason;
    return IFX_FAILURE;
  }	 
	
	IFX_SIPAPP_GetRouteInfo(unLineId, &xProfileSignaling,
													&xRouteParams,NULL,&uiProfileId);

	if(pxTo->eAddressType==IFX_CMGR_TYPE_VOIP && 
		 pxFrom->eAddressType==IFX_CMGR_TYPE_VOIP)
	{
		xRouteParams.pxTo = &pxTo->uxAddressInfo.xVoipAddr;
	  xRouteParams.pxFrom =&pxFrom->uxAddressInfo.xVoipAddr;
    
		if(IFX_SIPAPP_SendInstMsg((uint32) unSmsId, uiProfileId,
					                    &xRouteParams, szSmsBody,0,(void**)&uiPvtData)
									            	== IFX_SIP_SUCCESS)
			{
				*peStatus = IFX_CMGR_STATUS_SUCCESS;
	   		*peReason =0 /*TODO*/;
	   		return IFX_SUCCESS;
			}
	 }
   *peStatus = IFX_CMGR_STATUS_FAIL;
	 *peReason =0 /*TODO*/;
	 return IFX_FAILURE;
}
#endif

/******************************************************************
*  Function Name    : IFX_SIPAPP_CMGR_Register
*  Description      : Create call
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
e_IFX_Return 
IFX_SIPAPP_CMGR_Register(IN x_IFX_CMGR_RegParams *pxRegParams, 
						 IN uint32 uiReqId, 
						 OUT e_IFX_CMGR_Status *peStatus, 
						 OUT e_IFX_ReasonCode *peReason, 
						IN_OUT void **pvPvtData) 


{
  e_IFX_SIP_Return eRet = IFX_SIP_FAILURE;
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entered");
  if(NULL == pxRegParams) {
  	IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"NULL Params");
	return eRet;
  }

  if(0 == pxRegParams->uiExpVal)
  {
   	if(!(*pvPvtData)) {				
    	IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Invalid UnReg Req");
	    return IFX_FAILURE;
		}
	 
   if(IFX_SIPAPP_UnRegisterUser(uiReqId,*pvPvtData)==IFX_FAILURE)  {
	  *peStatus = IFX_CMGR_STATUS_FAIL;
	  *peReason = 0;
      IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"UnReg Failed");
	  return IFX_FAILURE;
   }
  }
  
  else 
  {
		uint32 uiProfileId ;  
		uint32 uiExpVal = pxRegParams->uiExpVal;	
		uint16 unLineId = pxRegParams->unLineId;
    x_IFX_VMAPI_ProfileSignaling xProfileSignaling={{{{"\0"}}}};
    x_IFX_SIPAPP_RouteParams xRouteParams={0}; 
    x_IFX_CalledAddr xTo,xFrom;

    /*printf("Recvd Valued Expires = %d LineId = %d Server = %s RetryFlag = %d\n",
					pxRegParams->uiExpVal,pxRegParams->unLineId,
					pxRegParams->xSrvrAddr.acCalledAddr,
					pxRegParams->bRetryFlag);*/
		IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Registrar Address ",pxRegParams->xSrvrAddr.acCalledAddr);
		IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,"Retry flag ",pxRegParams->bRetryFlag);

		IFX_SIPAPP_GetRouteInfo(unLineId, &xProfileSignaling,&xRouteParams,&xFrom,&uiProfileId);

		memcpy(&xTo,&pxRegParams->xSrvrAddr,sizeof (x_IFX_CalledAddr));
    xRouteParams.pxTo = &xTo;
		xRouteParams.pxFrom = &xFrom;
  	IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Initiating Registration");

    eRet = IFX_SIPAPP_RegisterUser(uiReqId,uiProfileId,&xRouteParams,uiExpVal,pvPvtData,pxRegParams->bRetryFlag);
    
	}
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
  *peReason = IFX_REQ_PENDING;
  //*peReason = IFX_REQ_PENDING;
  
	if(eRet != IFX_SIP_SUCCESS)
	{	
		*peStatus = IFX_CMGR_STATUS_FAIL;
  	IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Failed");
  	return IFX_FAILURE;
	}
	return IFX_SUCCESS;

}

/******************************************************************
*  Function Name    : 
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return 
IFX_SIPAPP_CMGR_Notify(IN uint32 uiReqId,
											 IN x_IFX_CMGR_NotifyInfo *pxNotifyInfo, 
											 IN e_IFX_CMGR_Status *peStatus, 
											 OUT e_IFX_ReasonCode *peRespCode, 
											 IN void *pvPrivateData) 
{	
  uint16 unLineId =*peRespCode;
  /*Get Profile Information*/
  x_IFX_VMAPI_VoiceLine xVoiceLine ={{{{"\0"}}}};
  if(uiReqId!= 0){
   IFX_CMGR_LineIdFromReqIdGet(uiReqId,&unLineId,peRespCode);
	}
	xVoiceLine.ucLineId = unLineId;
  ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT);
  if(pxNotifyInfo->uxNotifyInfo.xAutoNtfyInfo.bRemoteFree){
	  return	IFX_SIPAPP_NotifyForCB(uiReqId,IFX_OFF,0,
          pxNotifyInfo->uxNotifyInfo.xAutoNtfyInfo.bRemoteFree,xVoiceLine.ucProfileId,				
				  pvPrivateData);
	}
  else {
	  return	IFX_SIPAPP_NotifyForCB(uiReqId,IFX_ON,0,
          pxNotifyInfo->uxNotifyInfo.xAutoNtfyInfo.bRemoteFree,xVoiceLine.ucProfileId,				
				  pvPrivateData);
  }
}
/******************************************************************
*  Function Name    : 
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return 
IFX_SIPAPP_CMGR_Subscribe	(	IN x_IFX_CMGR_AddressInfo *pxToAddr, 
														IN uint16 unLineId, 
														IN e_IFX_CMGR_SubsEvent eSubsEvt, 
														IN uint32 uiReqId, 
														OUT e_IFX_CMGR_Status *peStatus, 
														IN_OUT e_IFX_ReasonCode *peReason, 
														IN_OUT void **ppvPrivateData) 

{
	uint32 uiProfileId ;  
  x_IFX_VMAPI_ProfileSignaling xProfileSignaling={{{{"\0"}}}};
  x_IFX_SIPAPP_RouteParams xRouteParams={0}; 
  x_IFX_CalledAddr xFrom;  
	e_IFX_SIP_Return eRetVal= IFX_SIP_FAILURE;
	uint16 unSubExpTime=3600;

	/* Logic for unsubcribe*/
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entered");
	if(*peReason == IFX_UNSUBSCRIBE){
      IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Reason is unsubcribe");
			unSubExpTime=0;
	}
	else{
	  xRouteParams.pxFrom = &xFrom;		
	  IFX_SIPAPP_GetRouteInfo(unLineId, &xProfileSignaling,
	 										    &xRouteParams,&xFrom,&uiProfileId);
	}
  if(eSubsEvt==IFX_CMGR_SUBS_VOICE_MAIL){
		x_IFX_CalledAddr xTo;			
		/* Get VM deposit address */
		memset(&xTo,0,sizeof(x_IFX_CalledAddr));
		if(unSubExpTime == 0){
	
			IFX_SIPAPP_UnSubscribeForMWI(uiReqId,*ppvPrivateData);
		}
		else{
	    if((IFX_SUCCESS == IFX_CIF_VLVMSubEventGet(
													unLineId,IFX_TRUE, &xTo, &unSubExpTime))){
		    xRouteParams.pxTo=&xTo;	
        IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Calling SubscirbeMWI");
		    eRetVal=IFX_SIPAPP_SubscribeForMWI(uiReqId,uiProfileId, 
				  			unSubExpTime,&xRouteParams,(void**)ppvPrivateData);
		  }
		  else{
			  eRetVal = IFX_SIP_FAILURE;		
        IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Returning failure");
		  }
		}
	}
	else if(eSubsEvt==IFX_CMGR_SUBS_AUTO_REDIAL)
	{
			xRouteParams.pxTo = &pxToAddr->uxAddressInfo.xVoipAddr;
      IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Subscirbe for CallBack");
			if(unSubExpTime == 0){
				eRetVal=IFX_SIPAPP_UnSubscribeForCB(uiReqId,(void**)*ppvPrivateData);
			}else {
			eRetVal=IFX_SIPAPP_SubscribeForCB(uiReqId, uiProfileId,unSubExpTime,
												                &xRouteParams,(void**)ppvPrivateData);
      }
	}
	if(eRetVal==IFX_SIP_SUCCESS)
	{
    *peStatus = IFX_CMGR_STATUS_PENDING;
    *peReason = 0/*TODO*/;
    return IFX_SUCCESS;
	}     
	*peStatus = IFX_CMGR_STATUS_FAIL;
	*peReason =0 /*TODO*/;
	return IFX_FAILURE;
}
/******************************************************************
*  Function Name    : 
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return 
IFX_SIPAPP_CMGR_SubnStatus (IN uint32 uiReqId, 
														IN uint32 uiExpTime, 
														IN e_IFX_CMGR_Status eSubsStatus, 
														IN e_IFX_ReasonCode eRespCode, 
														IN void *pvPrivateData) 
{
e_IFX_ReasonCode eResponse;
 x_IFX_CMGR_NotifyInfo xNotifyInfo={0};
 switch(eSubsStatus)
 {			 
   case IFX_CMGR_STATUS_SUCCESS:
					 eResponse = IFX_200_RESP;
           xNotifyInfo.uxNotifyInfo.xAutoNtfyInfo.bRemoteFree=IFX_TRUE;
					 break;
   case IFX_CMGR_STATUS_PENDING:
					 eResponse = IFX_202_RESP;
           xNotifyInfo.uxNotifyInfo.xAutoNtfyInfo.bRemoteFree=IFX_FALSE;
					 break;					 
   case IFX_CMGR_STATUS_FAIL:
					 eResponse = IFX_500_RESP;
					 break;
	 default:
				return IFX_FAILURE;	 
 }		
 IFX_SIPAPP_SendSubscStatusForCB(uiReqId,IFX_ON,eResponse,pvPrivateData);
 if(eSubsStatus != IFX_CMGR_STATUS_FAIL){
   IFX_SIPAPP_CMGR_Notify(uiReqId,&xNotifyInfo,&eSubsStatus,&eRespCode,pvPrivateData); 
	 return IFX_SIP_FAILURE;
  }
 return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name    :IFX_SIPAPP_MSGRTR_FdCallback
*  Description      : Dummy function
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_SIPAPP_MSGRTR_FdCallback ( IN int32 iFd )
{
  IFX_SIPAPP_RecvStunTimerMsgs(NULL,NULL,NULL,NULL);
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :IFX_SIPAPP_CMGR_RegFd
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/

e_IFX_SIP_Return IFX_SIPAPP_CMGR_RegFd(int32 iFd,uchar8 ucFdType,pfn_IFX_SIPAPP_FdCallback pfunc)
{
	 x_IFX_MSGRTR_FdInfo xFdInfo={0};
   xFdInfo.eFdSetType = ucFdType;
   xFdInfo.uiFd = iFd;
   uiFdCount++;	 
	 if(pfunc == (pfn_IFX_SIPAPP_FdCallback)IFX_SIPAPP_RecvStunTimerMsgs){
		 return IFX_MSGRTR_FdCallBackRegister(&xFdInfo,1,
                                          IFX_SIPAPP_MSGRTR_FdCallback);
	 }
	 else{
		 return IFX_MSGRTR_SipFdCallBackRegister(&xFdInfo,(pfn_IFX_MSGRTR_SipFdCallback)pfunc);
	 }
}
/******************************************************************
*  Function Name    : IFX_SIPAPP_CMGR_UnRegFd
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_SIPAPP_CMGR_UnRegFd(int32 iFd,uchar8 ucFdType)
{
	 x_IFX_MSGRTR_FdInfo xFdInfo={0};
	 xFdInfo.eFdSetType = ucFdType;
	 xFdInfo.uiFd = iFd;
   uiFdCount--;	 
	 return IFX_MSGRTR_FdUnregister(&xFdInfo);
}
/*!
	\brief	This callback is invoked by a the CMGR to ask an Agent (say DECT/FXS) 
	if it wants to transfer a call to the mentioned endpoint/address. The TargetAddress
	may contain a PSTN number if the call is being transferred to a PSTN number 
	or it may contain the complete VoIP address.
	\param[in]	uiCallId is the Call-id of the call to transfer
	\param[in]	pxTargetAddr is the address of a voice-line or contains a PSTN number
					or it may also contain the remote party's extn number
 	\param[out]	peTransferStatus contains an enum regarding if the Transfer was 
					Accepted or Not
 	\param[out]	peRespCode contains a Rsp code in case the transfer Req was
					not accepted
	\param[in]  pvPrivateData is the private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_SIPAPP_CMGR_BlindTxReq(
					 	IN uint32 uiCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData
					 )
{
  *peTransferStatus = IFX_CMGR_TRANSFER_PENDING;	
	*peRespCode = IFX_MAX_REASON;
  return IFX_SIPAPP_SendReferReq(uiCallId,0,&pxTargetAddr->uxAddressInfo.xVoipAddr,
                        pvPrivateData);

}
/*!
	\brief This call-back is invoked by an the CMGR on an Agent (say DECT/FXS) when it 
			 needs to inform the agents that the call  transfer Reqed by it has 
			 suceeded/failed and also when a the NA is to be Reqed for sending of a
			 1XX/18X/2XX notification. Also can be invoked on the DECT/FXS agent to 
			 inform them about the remote party's state, in process of forming the new call.
	\param[in]	uiCallId is the Call-id of the call in transfer
	\param[in]	eTransferStatus is used for informing the transfer intitator about 
					the transferee's decision on accepting/rejecting the
					Transfer Req (Refer) before the transfer starts. Its also used
					to notify the agent about the state of the new call being formed,
					i.e. to send NOTIFY.
	\param[in] eRespCode is the reason for a possible tranfer Req rejection.
	\param[in]  pvPrivateData is the private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAIL
 */

e_IFX_Return IFX_SIPAPP_CMGR_BlindTxStatus(
					 	IN uint32 uiCallId,
						IN e_IFX_TransferStatus eTransferStatus, 
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 )
{
  
   x_IFX_VMAPI_VoiceLine xVoiceLine={{{{"\0"}}}};
   x_IFX_VMAPI_ProfileSignaling xVoiceProfile={{{{"\0"}}}};
   uint16 unLineId=0;
   x_IFX_CalledAddr xProxyAddr={0};	 
	 uchar8 ucIsOutBoundProxy=0;
   uint32 eReferStatus=0;	 
   
	 /*Get Profile Information*/
   IFX_CMGR_LineIdFromCallIdGet(uiCallId,&unLineId,&eRespCode);
   xVoiceLine.ucLineId = unLineId;
   ifx_get_VoiceLine(&xVoiceLine,IFX_F_DEFAULT);
   xVoiceProfile.ucProfileId = xVoiceLine.ucProfileId;
   ifx_get_ProfileSignaling (&xVoiceProfile,IFX_F_DEFAULT);
	 
   if(xVoiceProfile.acOutboundProxyAddr[0])
  {
     ucIsOutBoundProxy=IFX_TRUE;
     strcpy(xProxyAddr.acCalledAddr,xVoiceProfile.acOutboundProxyAddr);
     xProxyAddr.unPort =xVoiceProfile.unOutboundProxyPort ;
     xProxyAddr.ucAddrProto=IFX_TRPROTO_UDP;
  }
  else
  {
    ucIsOutBoundProxy =IFX_FALSE;
    strcpy(xProxyAddr.acCalledAddr,xVoiceProfile.acProxyAddr);
    xProxyAddr.unPort=xVoiceProfile.unProxyPort;
    xProxyAddr.ucAddrProto=xVoiceProfile.ucProxyProtocol; 
  }
	switch(eTransferStatus){
		case IFX_CMGR_TRANSFER_ANSWERED:
				eReferStatus = IFX_SIP_SUBSC_TERMINATED;
				eRespCode = IFX_200_RESP;
			break;
		case IFX_CMGR_TRANSFER_REJECTED:
		case IFX_CMGR_TRANSFER_FAILED:
				eReferStatus = IFX_SIP_SUBSC_TERMINATED;
				eRespCode = IFX_500_RESP;
			break;
		case IFX_CMGR_TRANSFER_PROCEEDING: 
		case IFX_CMGR_TRANSFER_ACCEPTED:
		case IFX_CMGR_TRANSFER_PENDING:
		case IFX_CMGR_TRANSFER_RINGING:
				eReferStatus = IFX_SIP_SUBSC_ACTIVE;
				eRespCode = IFX_100_RESP;
			break;
		default:
		 break;
	}
	
  return IFX_SIPAPP_SendNotifyForRefer(uiCallId,
                               eReferStatus,
                              eRespCode,
                              &xProxyAddr,
                              ucIsOutBoundProxy,
                              pvPrivateData);

}
/*!
	\brief	This callback is invoked by the CMGR to ask an Agent (say DECT/FXS) 
				if it wants to accept a transfer on the mentioned call-id. 
				The TargetAddress may contain a PSTN number if the call is being 
				transferred to a PSTN number or it may contain the complete VoIP 
				address. This same call-back is also used by the NA for sending 
				out a Refer with Replaces.
	\param[in] uiCallId is the call-id of the A to B call leg
	\param[in] uiReplacesCallId is sent/received in the replaces header. 
					Its only for needed for NA.
	\param[in] pxTargetAddr is used by DECT etc for display
	\param[out] peTransferStatus Tranfer Req accpeted or not.
	\param[out] peRespCode Reason for transfer Req rejection.
	\param[in]  pvPrivateData is the private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAIL
 */
e_IFX_Return IFX_SIPAPP_CMGR_AttendedTxReq(
					 	IN uint32 uiCallId,
						IN uint32 uiReplacesCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData
					 )
{
  *peTransferStatus = IFX_CMGR_TRANSFER_PENDING;	
	*peRespCode = IFX_MAX_REASON;
  return IFX_SIPAPP_SendReferReq(uiCallId,uiReplacesCallId,
									&pxTargetAddr->uxAddressInfo.xVoipAddr,
                        pvPrivateData);

}
/******************************************************************
*  Function Name    : IFX_SIPAPP_PaIfInit()
*  Description      : Create call
*  Input Values     : void
*  Output Values    : None
*  Return Value     : 0
*  Notes            :
*********************************************************************/
char8 IFX_SIPAPP_PaIfInit()
{
   x_IFX_CMGR_CallBackList xCallBackList={0};
   x_IFX_SIPAPP_Notifiers xStateNotifier;
	 char8 aszEndptId[1][IFX_MAX_ENDPOINTID_LEN] = {IFX_NA_ENDPT_ID};
   xCallBackList.pfnGetMediaParams = IFX_SIPAPP_CMGR_GetMediaParams;
   xCallBackList.pfnMediaNegReq = IFX_SIPAPP_CMGR_NegotiateMediaRequest;
   xCallBackList.pfnMediaNegRsp = IFX_SIPAPP_CMGR_NegotiateMediaResponse;
   xCallBackList.pfnCallIncoming = IFX_SIPAPP_CMGR_CreateCall;
   xCallBackList.pfnRemoteCallAccept = IFX_SIPAPP_CMGR_RemoteCallAccept;
   xCallBackList.pfnRemoteCallAnswer = IFX_SIPAPP_CMGR_RemoteCallAnswer;
   xCallBackList.pfnRemoteCallHold = IFX_SIPAPP_CMGR_RemoteCallHold;
   xCallBackList.pfnRemoteCallResume = IFX_SIPAPP_CMGR_RemoteCallResume;
   xCallBackList.pfnCallHoldRsp = IFX_SIPAPP_CMGR_CallHoldResponse;
   xCallBackList.pfnCallResumeRsp  = IFX_SIPAPP_CMGR_CallResumeResponse;
   xCallBackList.pfnRemoteCallRelease = IFX_SIPAPP_CMGR_RemoteCallRelease;
#ifdef INFO_SUPPORT
   xCallBackList.pfnDigitsInCallRcv  = IFX_SIPAPP_CMGR_RecvDigitsInCall;
#endif
	 /*Refer*/
   xCallBackList.pfnBlindTxReq = IFX_SIPAPP_CMGR_BlindTxReq;
   xCallBackList.pfnBlindTxStatus = IFX_SIPAPP_CMGR_BlindTxStatus;
   xCallBackList.pfnAttendedTxReq = IFX_SIPAPP_CMGR_AttendedTxReq;
   xCallBackList.pfnAttendedTxStatus = IFX_SIPAPP_CMGR_BlindTxStatus;

	 /*Subsribe Notify*/
	 xCallBackList.pfnSubnSnd=IFX_SIPAPP_CMGR_Subscribe; 	
	 xCallBackList.pfnNtfnSnd=IFX_SIPAPP_CMGR_Notify;
	 xCallBackList.pfnSubnStatus = IFX_SIPAPP_CMGR_SubnStatus;	
   xCallBackList.pfnRegister =IFX_SIPAPP_CMGR_Register;
	
	 /*Registration and InstMessaging*/
   xCallBackList.pfnRegister =IFX_SIPAPP_CMGR_Register;
  
   xStateNotifier.pfStateNotifier = IFX_SIPAPP_StateNotifer;
   xStateNotifier.pfAddFdToSelect = IFX_SIPAPP_CMGR_RegFd;
   xStateNotifier.pfRemoveFdFromSelect = (e_IFX_SIP_Return (*)(int32,uchar8))IFX_SIPAPP_CMGR_UnRegFd;
	 

   /* Register Call back of network agents to call CallMgt API's*/
   IFX_SIPAPP_RegNotfiers(&xStateNotifier);
   return IFX_CMGR_CallBacksRegister(aszEndptId,1,&xCallBackList);
  
}
#ifdef DARE_CUST
/******************************************************************
*  Function Name    : IFX_SIPAPP_OptionsInfo
*  Description      : Get OPTIONS related info
*  Input Values     : LineId, from 
*  Output Values    : pucIsfrmSrvr,ppxUserReg
*  Return Value     : 0
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_OptionsInfo(IN uchar8 ucLineId, 
											IN x_IFX_CMGR_AddressInfo* pxFrom, 
											OUT uchar8* pucIsfrmSrvr,
											OUT x_IFX_SIPAPP_UserRegistration** ppxUserReg)
{
	x_IFX_SIPAPP_UserRegistration *pxUserReg= vpxUserRegistrationHeadptr;
	uint16 unLineIdTemp = 0, i = 0;
	e_IFX_ReasonCode eReason=0;
	char8 *pcTemp = NULL;
	char8 *apcTemp[2] = {0};

	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	while(pxUserReg){
		//printf("\nReqId is %d and i/p LineId %d",pxUserReg->uiReqId,ucLineId);

		if (IFX_SIP_FAILURE == IFX_CMGR_LineIdFromReqIdGet(pxUserReg->uiReqId,&unLineIdTemp,&eReason)){
			IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Invalid ReqId");
			return IFX_SIP_FAILURE;
		}

		else if (ucLineId == unLineIdTemp){
			//printf("\nLineId matches, Registration client node is found");
			*ppxUserReg = pxUserReg;

			if (pxUserReg->pcRegistrar){
				pcTemp = pxUserReg->pcRegistrar;
			}
			else{
				IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: pcRegistrar is NULL");
				return IFX_SIP_FAILURE;
			}

			break;
		}

		__ifx_list_GetNext((void*)&pxUserReg);
	}

	if (!pxUserReg){
		IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Reg client node is NOT found for this line");
		return IFX_SIP_FAILURE;
	}

	/* Mark the start and point of registrar address in pcRegistrar string*/
	while (pcTemp){
		if (*pcTemp++ == ':')
			apcTemp[i++] = pcTemp;
		
		if (i==2)
			break;
	}

	if (apcTemp[0] == NULL || apcTemp[1] == NULL){
		IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed: Server Address is not found in pcRegistrar");
		return IFX_SIP_FAILURE;
	}

	else if (!strncmp(pxFrom->uxAddressInfo.xVoipAddr.acCalledAddr,apcTemp[0],apcTemp[1]-apcTemp[0]-1)){
		*pucIsfrmSrvr = 1;
		IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"OPTIONS Arrived from Registrar");
	}

	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
	return IFX_SIP_SUCCESS;
}
#endif
#endif
