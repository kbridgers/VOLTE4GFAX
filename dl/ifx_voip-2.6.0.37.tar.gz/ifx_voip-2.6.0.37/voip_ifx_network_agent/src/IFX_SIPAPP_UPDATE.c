/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Update.c
**   PROJECT       : SIP
**   MODULES       : User Agent
**   SRC VERSION   : V2.0
**   DATE          : 15-04-2006
**   AUTHOR        : SIP TEAM
**   DESCRIPTION   : This file contains functions required for UPDATE method.
**   COMPILER      : gcc
**   REFERENCE     :
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifdef RFC_3311
#include "ifx_common_defs.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"

#include "ifx_debug.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_CCApi.h"
#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_CallIf.h"
#include "ifx_list.h"



extern uchar8 vcSipAppModId;



/******************************************************************
*  Fucntion Name  : IFX_SIPAPP_UpdateConst
*  Description    : This function constructs  UPDATE  message
*  Input Values   : pxAppData
*  Output Values  : peEcode ,uiMsgHdl
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :  
********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UpdateConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                       OUT uint32 uiMsgHdl,
                       OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return  eRetVal = IFX_SIP_SUCCESS;
  char8 acFrom[256];

 IFX_DBGA(vcSipAppModId , IFX_DBG_LVL_HIGH , IFX_DBG_STR,
           "<SIPAPP> Update Construction");

 if(!(pxAppData->iUpdateFlag & 
     (IFX_SIPAPP_OFFER_RECV |IFX_SIPAPP_OFFER_SENT ))){

  /*add the allow header field depicting the methods supported*/
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
  if(IFX_SIPAPP_SetContact(acFrom,uiMsgHdl,pxAppData->iProfileId)==
      IFX_SIP_FAILURE){
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    //IFX_SIP_FreeMsg(uiMsgHdl);
    return IFX_SIP_FAILURE;
  }   

  /*add the allow header field depicting the methods supported*/
  if (IFX_SIPAPP_SetAllow(uiMsgHdl) == IFX_SIP_FAILURE){
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    //IFX_SIP_FreeMsg(uiMsgHdl);
    return IFX_SIP_FAILURE;
  }

  /*construct SDP info*/ 
  eRetVal = IFX_SIPAPP_OfferSdp(uiMsgHdl,&pxAppData->xSdpInfo,peEcode);
  if (eRetVal == IFX_SIP_FAILURE){
    //IFX_SIP_FreeMsg(uiMsgHdl);
    return eRetVal;
  }
 
  /* set content disposition */
  IFX_SIPAPP_SetContentDisposition(uiMsgHdl);

  /* set content type */
  IFX_SIPAPP_SetContentType("application","sdp",uiMsgHdl);

  /* Set the supported header */
  eRetVal =IFX_SIPAPP_SetSupported(uiMsgHdl);
  
  /* Setting The   Offer Send Flag */ 
   pxAppData->iUpdateFlag |= IFX_SIPAPP_OFFER_SENT;

  /* Clear Update Transaction with Sdp  Flag */ 
   pxAppData->iUpdateFlag &= ~IFX_SIPAPP_UPDATE ;  
 
   return eRetVal; 
 
  }
 else{
   IFX_DBGC(vcSipAppModId , IFX_DBG_LVL_HIGH , IFX_DBG_STR,
           "<SIPAPP> Offer Answer Incomplete");

   return IFX_SIP_FAILURE;
  }
} 
/******************************************************************
*  Function Name  : IFX_SIPAPP_HandleUpdate
*  Description    : This function processes the UPDATE request
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleUpdate(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                        IN uint32 uiMsgHdl,
                        OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiHdrHdl=0;
  char8 *pcHdr = NULL,*pcBody = NULL;
  int16 nEntry=0;
  int32 iModeChanged=0;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<SIPAPP> HandleUpdate");



  if(pxAppData->iUpdateFlag & IFX_SIPAPP_OFFER_SENT){
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<HandleUPDATE> Offer  Send ");

     IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                             0,491,"Request Pending",0,"UPDATE");

     return eRetVal;
   }

  if(pxAppData->iUpdateFlag & IFX_SIPAPP_OFFER_RECV){
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<HandleUPDATE> Offer  Recived");

     IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                         0,500,"Internal Server Error",0,"UPDATE");

     return eRetVal;
    }
 
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1,
                                      &uiHdrHdl);
    if(eRetVal != IFX_SIP_FAILURE){
 
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<HandleInvite>Get the CONTENT_TYPE Succesfully");

    /* set The Offer Recv Flag */
    pxAppData->iUpdateFlag |= IFX_SIPAPP_OFFER_RECV;

    pcHdr =IFX_SIP_ContType_GetMSubType(uiHdrHdl);
    /* check whether session description is there or not */
    pcBody = IFX_SIP_GetMsgBody(uiMsgHdl);
 
    if(!strcasecmp(pcHdr,"sdp")){
#ifdef RFC_4028
    if(IFX_SDP_GetHeaderByType(pxAppData->xSdpInfo.uiSdpMsgHdl,IFX_SDP_ORIGIN,
                                 1,&uiHdrHdl) == IFX_SDP_FAILURE) {
       pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;
	}
    else{
      if(pxAppData->xSdpInfo.xRtpInfo.uiRemoteSessionVer == 
                      (uint32)IFX_SDP_Origin_GetSessionVersion(uiHdrHdl)){
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                "<HandleUpdate>Set the Flag for NOCHANGE in Session Version");
        /*Set the flag to indicate that there is no change in sdp version*/
        pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_NOCHANGE;
        eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_SE,1,&uiHdrHdl);
        if(eRetVal != IFX_SIP_FAILURE){
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<HandleUpdate>Get the Session-Expire Succesfully");

          pxAppData->iSessTimerId = IFX_SIP_SE_GetTime(uiHdrHdl);
        }
        /* Send a 200 response */
        eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                             0,200,"OK",0,"UPDATE");

        return eRetVal;
      }
      else{
        pxAppData->xSdpInfo.xRtpInfo.uiRemoteSessionVer = (uint32)
                         IFX_SDP_Origin_GetSessionVersion(uiHdrHdl);
      }
	}
#endif /*RFC_4028 */


    /* check whether the offer is acceptable or not */
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<HandleInvite> Store SDP ");

    eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,&pxAppData->xSdpInfo,peEcode);
  
    if(eRetVal == IFX_SIP_SUCCESS){
    /* SDP answer needs to sent in the 2xx response */
    pxAppData->iUpdateFlag |= IFX_SIPAPP_UPDATE_SDP_PRESENT;
    }
    else{
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                    "<HandleInvite> Store SDP Failed");
      /* send 488 response..sdp not acceptable */
      IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
                              488,"Not Acceptable",0,"UPDATE");
    
	  /* set The Offer Recv Flag */
      pxAppData->iUpdateFlag &= ~IFX_SIPAPP_OFFER_RECV;

      *peEcode = IFX_SIP_RESPONSE_SENT;
      return IFX_SIP_FAILURE; /* SDP not acceptable */
    }

   

    /* Check for codec change */
    if(pxAppData->xSdpInfo.xRemCap[0].uiRmCodec !=
       pxAppData->xSdpInfo.xRemCap[1].uiRmCodec){
 
     /* Set Locked Codec Entry */
      IFX_SIPAPP_GetLockedCodecEntry(&nEntry,&pxAppData->xSdpInfo);
      pxAppData->xSdpInfo.nLockedCodecEntry = nEntry;
      if(nEntry != 1){
        if(pxAppData->xSdpInfo.xRemCap[0].uiRmCodec !=
           pxAppData->xSdpInfo.xRemCap[nEntry].uiRmCodec){
	       pxAppData->iRtpParamModified =1;

        }      
      }
      else{
	    pxAppData->iRtpParamModified =1;
 
      }      
    }
    else{
      nEntry = pxAppData->xSdpInfo.nLockedCodecEntry = 1;     
    }
    
    /* Check if mode is changed */
    if(pxAppData->xSdpInfo.xRemCap[0].eMode !=
       pxAppData->xSdpInfo.xRemCap[nEntry].eMode){
      pxAppData->iRtpParamModified =1;
      iModeChanged = 1;      
    }
    /* Check for connection address */
    if((strcmp(pxAppData->xSdpInfo.xRemCap[nEntry].cRTPAddr, "0.0.0.0") 
        == 0) || (strcmp(pxAppData->xSdpInfo.xRtpInfo.cRemoteRTPAddr, 
        "0.0.0.0") == 0)){
      iModeChanged = 1;
      pxAppData->xSdpInfo.xRemCap[nEntry].eMode = IFX_SDP_INACTIVE;
      pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_USE_CONNADDR_FORHOLD;
      pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_USE_IP_HOLD;
    }
    else{
      pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_USE_CONNADDR_FORHOLD;
      pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_USE_IP_HOLD;
    }    
    if(iModeChanged){
      if((pxAppData->xSdpInfo.xRemCap[nEntry].eMode == IFX_SDP_INACTIVE)||
         (pxAppData->xSdpInfo.xRemCap[nEntry].eMode == IFX_SDP_SENDONLY)){
        /* Set Remote Hold Flag */
        pxAppData->iFlag |= IFX_SIPAPP_REMOTE_HOLD_FLAG;      
      
        /* Post a message to application */
        vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REMOTE_HOLD,pxAppData);
        return IFX_SIP_SUCCESS;
       }
      else{      
        if( /*(pxAppData->iEndptFlag & IFX_SIPAPP_LOCAL_HOLD) ||*/ 
	  (pxAppData->iFlag & IFX_SIPAPP_REMOTE_HOLD_FLAG)){
          /* This case put for polycom problem */		
          if(pxAppData->iFlag & IFX_SIPAPP_LOCAL_HOLD){
            pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SET_MODE;
	  }		  
          /* Reset Remote Hold Flag */
          pxAppData->iFlag &= ~IFX_SIPAPP_REMOTE_HOLD_FLAG;      
          /* Set Remote Resume flag */
          pxAppData->iFlag |= IFX_SIPAPP_REMOTE_RESUME_FLAG;      
          /* Post Remote resume to application */
          vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REMOTE_RESUME, pxAppData);
          return IFX_SIP_SUCCESS;
        }      
      }
    }
   	vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MEDIA_UPDATE, 
                                pxAppData);
    return IFX_SIP_SUCCESS;
  }
  else if(pcBody == NULL){
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<HandleUpdate> pcBody == NULL ");
   
   /* offer the sdp */
   eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL]
                                                    ,0,200,"OK",0,"UPDATE");

   return eRetVal;
   }
 }
 else{
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<HandleUpdate>IFX_SIP_CONTENT_TYPE  Value is NULL");

   /* offer the sdp */
   eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL]
                                    ,0,200,"OK",0,"UPDATE");


   return eRetVal;
  }

 
 return eRetVal;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_Handle491Update
*  Description    : This function processes the UPDATE request
*  Input Values   : pxAppData - Application Data
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
*********************************************************************/
PUBLIC void
IFX_SIPAPP_Handle491Update(IN x_IFX_SIPAPP_UAAppData *pxAppData)
{
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<UPDATE> 491 Update Response Handling ");

  IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,0,"UPDATE");

  return ;
}

#endif
