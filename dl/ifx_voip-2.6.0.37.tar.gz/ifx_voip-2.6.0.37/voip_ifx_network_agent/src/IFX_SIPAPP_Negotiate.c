/**************************************************************************
**   FILE NAME         : IFX_SIPAPP_Negotiate.c
**   PROJECT           : SIP
**   MODULES           : Transaction User
**   SRC VERSION       : V2.0
**   DATE              : 15-12-2004
**   AUTHOR            : Murali 
**   DESCRIPTION       : This file contains all the functions relating to 
**                       SDP negotiation in the SIP transaction user
**   COMPILER          : gcc
**   REFERENCE         : Coding guide lines for VSS 
**   COPYRIGHT         : Copyright (c) 2004
**                       Infineon Technologies AG, st. Martin Strasse 53;
**                       81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history

***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"

#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_MsgApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Transceiver.h"
#include "IFX_SIPAPP_Uac.h"
#include "IFX_SIPAPP_Config.h"

#ifdef STUN_SUPPORT
#include "IFX_SIPAPP_Stun.h"
#endif

#ifdef DMALLOC
#include <dmalloc.h>
#endif

extern uint16 v_IFX_SIP_CodecType;
extern uchar8 vcSipAppModId;

e_IFX_SDP_Mode aeRTPMode[IFX_SDP_INACTIVE+1][IFX_SDP_INACTIVE+1] = 
{
  {IFX_SDP_SENDRECV,IFX_SDP_RECVONLY,IFX_SDP_SENDONLY,IFX_SDP_INACTIVE,},
  {IFX_SDP_SENDONLY,IFX_SDP_SENDONLY,IFX_SDP_SENDONLY,IFX_SDP_INACTIVE,},
  {IFX_SDP_RECVONLY,IFX_SDP_RECVONLY,IFX_SDP_RECVONLY,IFX_SDP_INACTIVE,},
  {IFX_SDP_INACTIVE,IFX_SDP_INACTIVE,IFX_SDP_INACTIVE,IFX_SDP_INACTIVE}  
};
  
e_IFX_SDP_Mode aeLocalMode[IFX_SDP_INACTIVE+1][IFX_SDP_INACTIVE+1] = 
{
  {IFX_SDP_SENDRECV,IFX_SDP_RECVONLY,IFX_SDP_SENDONLY,IFX_SDP_INACTIVE,},
  {IFX_SDP_SENDONLY,IFX_SDP_INACTIVE,IFX_SDP_SENDONLY,IFX_SDP_INACTIVE,},
  {IFX_SDP_SENDRECV,IFX_SDP_RECVONLY,IFX_SDP_INACTIVE,IFX_SDP_INACTIVE,},
  {IFX_SDP_SENDRECV,IFX_SDP_RECVONLY,IFX_SDP_SENDONLY,IFX_SDP_INACTIVE}   
}; 

/******************************************************************
*  Function Name    :  IFX_SIPAPP_GetRTPMode
*  Description      :  Given Local and Remote modes this function gets 
*                      the mode that has to be posted to RTP module 
*  Input Values     :  Local and remote modes
*  Output Values    :  None
*  Notes            :  
*********************************************************************/
int32
IFX_SIPAPP_GetRTPMode(e_IFX_SDP_Mode eLocalMode,
                    e_IFX_SDP_Mode eRemoteMode)
{ 
  e_IFX_SDP_Mode eRtpMode = aeRTPMode[eLocalMode][eRemoteMode];
  switch(eRtpMode)
  {
     case IFX_SDP_SENDRECV :
       return IFX_RTP_MODE_SEND_RECV;
     case IFX_SDP_RECVONLY:
       return IFX_RTP_MODE_RECV_ONLY; 
     case IFX_SDP_SENDONLY:
       return IFX_RTP_MODE_SEND_ONLY; 
     case IFX_SDP_INACTIVE:
       return IFX_RTP_MODE_INACTIVE; 
     default:
        return IFX_RTP_MODE_SEND_RECV; 
  }
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_GetLocalMode
*  Description      :  Given Current Local and Remote modes this function 
*                      gets the mode that has to be sent to remote party 
*  Input Values     :  Current Local and remote modes
*  Output Values    :  None
*  Notes            :  
*********************************************************************/
e_IFX_SDP_Mode
IFX_SIPAPP_GetLocalMode(e_IFX_SDP_Mode eCurrLocalMode,
                      e_IFX_SDP_Mode eRemoteMode)
{
  return aeLocalMode[eCurrLocalMode][eRemoteMode];      
}

/******************************************************************
*  Function Name    :  IFX_SIP_SupportDTMF
*  Description      :  this function checks if it supports DTMF and 
*                      return dynamic payload value if supported
*  Input Values     :  profile Id
*  Output Values    :  Dynamic RTP payload
*  Return Value     :  configured or not
*  Notes            :  
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SupportDTMF(IN int32 iProfileId,
                    OUT uchar8* pucDynPT)
{
  x_IFX_CodecList *pxCodecList;
  int32 iCount=0;
  pxCodecList = IFX_SIPAPP_GETMEDIACFG(iProfileId);
  /*Get DTMF type*/
  for(iCount =0;iCount<pxCodecList->unNoOfCodecs;iCount++)
  {
	if(pxCodecList->axCodec[iCount].uiCodec == IFX_DIGIT_2833){
		*pucDynPT = pxCodecList->axCodec[iCount].ucDynPT;
		return IFX_SIP_SUCCESS;
	}
  }
  return IFX_SIP_FAILURE;
}

/*******************************************************************************
*  Function Name : IFX_SIPAPP_GetDynamicPT
*  Description   : This function returns dynamic pay load type
*  Input Values  : None
*  Output Values : uint16*: Server Port
*  Return Value  : IFX_SIP_SUCCESS
*                  IFX_SIP_FAILURE
*******************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_GetDynamicPT(int32 iProfileId,
                     uint32 uiCodec,
                     uchar8 *pucIanaPT)
{
  int32 iIdx;
  x_IFX_CodecList *pxCodecList;
  pxCodecList = IFX_SIPAPP_GETMEDIACFG(iProfileId);
  for(iIdx = 0; iIdx < pxCodecList->unNoOfCodecs;
          iIdx++){
    if(pxCodecList->axCodec[iIdx].uiCodec == uiCodec){
      *pucIanaPT = pxCodecList->axCodec[iIdx].ucDynPT;
      return IFX_SIP_SUCCESS;
    }
  }
  return IFX_SIP_FAILURE;
}
/******************************************************************
*  Function Name    :  IFX_SIP_CheckifSupportedOptionsGetIndex
*  Description      :  this function Checks if a particular codec is
*                      configured locally, and gets the index in case
*                      it is supported
*  Input Values     :  unRMCodec - RM codec to be checked for
*  Output Values    :  Index to the codec index in configuration Database
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CheckifSupportedOptionsGetIndex(int32 iProfileId,
                                         IN uint32 uiRMCodec,
                                         OUT int32* piIndex)
{
  x_IFX_CodecList *pxCodecList;
  pxCodecList = IFX_SIPAPP_GETMEDIACFG(iProfileId);
  for(*piIndex = 0; *piIndex < IFX_MAX_CODECS 
			&& *piIndex < pxCodecList->unNoOfCodecs; (*piIndex)++){
    if (pxCodecList->axCodec[*piIndex].uiCodec == uiRMCodec) {
      return IFX_SIP_SUCCESS;
    }
  }
  return IFX_SIP_FAILURE;
}

/********************************************************************
*  Function Name    : IFX_SIPAPP_GetRemoteDynamicPT
*  Description      : This function is called to get the remote ends
*                     the dynamic payload type
*  Input Values     : pxSdpInfo.. SDP information
*                     uiCodec.. Local COdec Information
*  Output Values    : puiIANAType...IANA payload type
*  Return Value     : IFX_SIP_SUCCESS
*                     IFX_SIP_FAILURE
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_GetRemoteDynamicPT(IN  x_IFX_SIPAPP_SdpInfo* pxSdpInfo,
                            IN  uint32  uiCodec,
                            OUT uchar8* pucIANAType)
{
  int32 iCount;
  for(iCount = 1; iCount<IFX_MAX_CODECS && iCount <= pxSdpInfo->ucNumRemCap; iCount++){
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_SIP_ERR,
		         uiCodec,"Comapring with");
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_SIP_ERR,
             pxSdpInfo->xRemCap[iCount].uiRmCodec,"this value");
    if(uiCodec == pxSdpInfo->xRemCap[iCount].uiRmCodec){
      *pucIANAType = pxSdpInfo->xRemCap[iCount].ucCodec;
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_SIP_ERR,
             *pucIANAType,"Pay load type being used");
	    return IFX_SIP_SUCCESS;
    }
  }
  return IFX_SIP_FAILURE;
}
/******************************************************************
*  Function Name    : IFX_SIPAPP_GetIanaCodec
*  Description      : This function is called to get the IANA codec type or
*                     the dynamic payload type
*  Input Values     : uiRMCodec..RM Codec
*  Output Values    : puiIANAType...IANA payload type
*  Return Value     : IFX_SIP_SUCCESS
*                     IFX_SIP_FAILURE
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_GetIanaCodec(IN  x_IFX_SIPAPP_SdpInfo* pxSdpInfo,
                        IN  uint32 uiCodec,
                        OUT uchar8* pucIANAType)
{
  int32 iIndex;
  x_IFX_CodecList *pxCodecList;
  switch (uiCodec) {
    case IFX_G711_ULAW:
      *pucIANAType = 0;
      break;
    case IFX_G726_32:
      *pucIANAType = 2;
      /* If a dynamic payload was used in initial neg
       * use the same in reneg */
      if(pxSdpInfo != NULL){
        if(pxSdpInfo->ucNumRemCap != 0){
          if(IFX_SIPAPP_GetRemoteDynamicPT(pxSdpInfo,uiCodec,pucIANAType)
	     == IFX_SIP_SUCCESS){
             IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_SIP_ERR,
                      *pucIANAType,"PAYLOAD USED FOR G726");
	     return IFX_SIP_SUCCESS;
	  }
        }
      }
      else{
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "PxSdp Info is null");
      }
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_SIP_ERR,
               *pucIANAType,"PAYLOAD USED FOR G726");
      break;
    case IFX_G723_5_3:
    case IFX_G723:
    case IFX_G723_6_3:
      *pucIANAType = 4;
      break;
    case IFX_G711_ALAW:
      *pucIANAType = 8;
      break;
    case IFX_G722_64:
      *pucIANAType = 9;
      break;
    case IFX_G728:
      *pucIANAType = 15;
      break;
    case IFX_G729_8:
      *pucIANAType = 18;
      break;
    default:
      /* TBD: To be Reviewed properly */
      if(pxSdpInfo != NULL){
        pxCodecList = IFX_SIPAPP_GETMEDIACFG(pxSdpInfo->iProfileId);
        if(pxSdpInfo->ucNumRemCap != 0){
          if(IFX_SIPAPP_GetRemoteDynamicPT(pxSdpInfo,uiCodec,pucIANAType)
	     == IFX_SIP_SUCCESS){
	     return IFX_SIP_SUCCESS;
	  }
        }
        else{
          if(IFX_SIPAPP_CheckifSupportedOptionsGetIndex(pxSdpInfo->iProfileId,
                              uiCodec, &iIndex) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          *pucIANAType = pxCodecList->axCodec[iIndex].ucDynPT;
        }
      }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  :  IFX_SIPAPP_GenerateSessionId
*  Description    :  this function generates the branch id
*  Input Values   :  void
*  Output Values  :  piSessionId..pointer to session id
*  Return Value   :  void
*  Notes      	  : 
*********************************************************************/
PUBLIC void  IFX_SIPAPP_GenerateSessionId(IN char8 *pcSession,
										  OUT uint32* piSessionId)
{

  *piSessionId = IFX_SIPAPP_RandomNumber();
  sprintf(pcSession,"%d",*piSessionId);
}


/******************************************************************
*  Function Name  :  IFX_SIPAPP_GenerateSesVersion
*  Description    :  this function generates the session version
*  Input Values   :  void
*  Output Values  :  piSesVersion..pointer to session version
*  Return Value   :  void
*  Notes      	  : 
*********************************************************************/
PUBLIC void
IFX_SIPAPP_GenerateSesVersion(IN char8 *pcSession,
							  OUT uint32* piSesVersion)
{
  
 *piSesVersion = IFX_SIPAPP_RandomNumber();
 sprintf(pcSession,"%d",*piSesVersion);
}
/******************************************************************
*  Function Name  :  IFX_SIPAPP_AddGeneralSdp
*  Description    :  this function adds the general sdp info
*  Input Values   :  pxSdpInfo...pointer to SDP info 
*  Output Values  :  pxEncodedMsg..pointer to encoded data structure
*  Return Value   :  IFX_SIP_SUCCESS
*           		 IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC void
IFX_SIPAPP_AddGeneralSdp(IN x_IFX_SIPAPP_SdpInfo* pxSdpInfo,
                      OUT uint32 uiSdpHdl)
{
  uint32 uiOriginHdl,uiConnHdl,uiTimeHdl,uiTmp,uiSSHdl;
  uint32 uiCfgInst = 
	  IFX_SIPAPP_GetSrvPdrInst(((x_IFX_SIPAPP_UAAppData *)pxSdpInfo->iProfileId)->iProfileId);
  char8 acAddr[128] = {'\0'};
  char8 acSessionId[30]={'\0'};
  /* set the version */
  IFX_SDP_Version_SetVer(uiSdpHdl,0);
  
  /* Get Origin Field */
  IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_ORIGIN,&uiOriginHdl);
  /* fill the user name */
  IFX_SDP_Origin_SetUsername(uiOriginHdl,"-");
  if(pxSdpInfo->iFlag & IFX_SIPAPP_SDP_SESSIONVER){
    /* fill the session id */
    IFX_SIPAPP_GenerateSessionId(acSessionId,&uiTmp);
    IFX_SDP_Origin_SetSessionId(uiOriginHdl,(int32)acSessionId);
    /*Store the Session id for RFC_4028*/
    pxSdpInfo->xRtpInfo.uiSessionId = uiTmp;
    /* fill the session version */
    IFX_SIPAPP_GenerateSesVersion(acSessionId,&uiTmp);
    IFX_SDP_Origin_SetSessionVersion(uiOriginHdl,(int32)acSessionId);
    /*store the session version for RFC_4028*/
    pxSdpInfo->xRtpInfo.uiSessionVer = uiTmp;

  }
  else{
    /* use existing session id */
	sprintf(acSessionId,"%d",pxSdpInfo->xRtpInfo.uiSessionId);
    IFX_SDP_Origin_SetSessionId(uiOriginHdl,(int32)acSessionId);
    /* use existing version for RFC_4028 */
    if(!(pxSdpInfo->iFlag & IFX_SIPAPP_SDP_NOCHANGE))
    {
      pxSdpInfo->xRtpInfo.uiSessionVer++;
    }
	sprintf(acSessionId,"%d",pxSdpInfo->xRtpInfo.uiSessionVer);
    IFX_SDP_Origin_SetSessionVersion(uiOriginHdl,(int32)acSessionId);

  }

#if STUN_SUPPORT
  if (vpxSrvPdrData[uiCfgInst].acMappedAddr[0] != '\0') {
    strcpy(acAddr, vpxSrvPdrData[uiCfgInst].acMappedAddr);
  }
  else
#endif
  {          
    strcpy(acAddr,(char8 *)vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.acIPAddr);
  }

  /* fill the network type */
  IFX_SDP_Origin_SetNetworkType(uiOriginHdl,"IN");
  IFX_SDP_Origin_SetAddressType(uiOriginHdl,"IP4");
  IFX_SDP_Origin_SetAddress(uiOriginHdl,acAddr);

  /* fill the session field */
  IFX_SDP_SetSessionName(uiSdpHdl,"SIP Call");

  /* fill the connection field */
  IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_CONNECTION,&uiConnHdl);
  IFX_SDP_Connection_SetNwType(uiConnHdl,"IN");
  IFX_SDP_Connection_SetAddressType(uiConnHdl,"IP4");
  
  if(pxSdpInfo->iFlag& IFX_SIPAPP_USE_CONNADDR_FORHOLD) {
    if(pxSdpInfo->iFlag& IFX_SIPAPP_USE_IP_HOLD) {
      IFX_SDP_Connection_SetAddress(uiConnHdl,acAddr);	    
    }
    else {
      IFX_SDP_Connection_SetAddress(uiConnHdl,"0.0.0.0");	    
    }
  }
  else {
    IFX_SDP_Connection_SetAddress(uiConnHdl,acAddr);	    
  }
  /* fill the time field */
  IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_TIME,&uiTimeHdl);
  IFX_SDP_Time_SetParamByType(uiTimeHdl,IFX_SDP_TIME_STARTSTOP,&uiSSHdl);
  IFX_SDP_Time_StartStop_SetZero(uiSSHdl);
  return ;
}

/******************************************************************
*  Function Name    :  IFX_SIP_StoreRemCap
*  Description      :  this function store the remote capabilities
*  Input Values     :  pxLocalSdp..pointer to SDP Information
*  Output Values    :  pxMediaDesc..pointer to media Description
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_StoreRemCap(OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                    IN uint32 uiMediaDescHdl)
{
  uchar8 iCount,iCount1, ucFlag = 0;
  char8 acConnAddr[IFX_IP_ADDR_LEN]={'\0'};
  char8 acRtcpConnAddr[IFX_IP_ADDR_LEN]={'\0'};
  uint32 uiMedia,uiConnHdl;
  //e_IFX_SDP_Mode eTempMode;
  e_IFX_SDP_Mode eMode=IFX_SDP_SENDRECV;
  uint16 unRtcpPort = 0;
  char8 *pcAddr,*pcFmt;
  x_IFX_SDPAPP_Attributes xAttr; 
#ifdef FAX_SUPPORT
  char8 *pcProto=NULL;
  uint32 uiLoc=0;
#endif
  /* As this field is being used to check Multiple G.726 */
  pxLocalSdp->iCodecList = 0;
  IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_MEDIA,1,&uiMedia);

  /* Inittialize the number of remote capabilities */
  //eTempMode = pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode;
  if(IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_CONNECTION,1,
			  &uiConnHdl) == (e_IFX_SDP_Return) IFX_SIP_SUCCESS){
    pcAddr = IFX_SDP_Connection_GetAddress(uiConnHdl);
    if(pcAddr[0] != '\0'){
      strcpy(acConnAddr,pcAddr);	     
    }
    else{
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Connection address in Connection field is null");
    }    
  }
  else{
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "No per Media Connection");
  }
 
  iCount=1;
  while(IFX_SDPAPP_DecodeSdpAttr(uiMediaDescHdl,iCount,&xAttr) != 
        IFX_SIP_FAILURE){
    if(xAttr.eAttrType == IFX_SDPAPP_ATTR_RTCP){
      /* TODO: Copy Connection address	    
      strcpy(acRtcpConnAddr, xAttr.uxSdpAttr.xRtcp.xConnAddr.acConnAddr);*/
      unRtcpPort = xAttr.uxSdpAttr.xRtcp.unRtcpPort;
      ucFlag = 1;
      break;
    }
    iCount++;
  }
  
  iCount1 = 1;
  /* Get Mode from media descriptor */
  eMode = IFX_SDP_MediaDesc_GetMode(uiMediaDescHdl);
  while((pcFmt = IFX_SDP_MediaDesc_Media_GetFormat(uiMedia,iCount1)) != NULL){
    /* If RTCP Info present copy to the Rem cap */
    if(ucFlag == 1){
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTCPAddr,
             acRtcpConnAddr);
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTCPPort = unRtcpPort;
    }
    if (!strcmp(pcFmt, "0")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 0;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
        IFX_G711_ULAW;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G711_ULAW; 
    }
    else if (!strcmp(pcFmt, "2")) {
      if((pxLocalSdp->iCodecList&IFX_G726_32) == 0){
        pxLocalSdp->ucNumRemCap++;
        pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
        pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 2;
        pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
          IFX_G726_32;
        pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
          IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
        strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
               acConnAddr);
        pxLocalSdp->iCodecList |= IFX_G726_32;
      }
    }
    else if (!strcmp(pcFmt, "4")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 4;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
          IFX_G723_5_3;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G723_5_3; 
      /*---------To give both 5.3 and 6.3 */
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 4;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
          IFX_G723_6_3;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G723_6_3; 
		}
    else if (!strcmp(pcFmt, "8")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 8;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
        IFX_G711_ALAW;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G711_ALAW; 
    }
    else if (!strcmp(pcFmt, "9")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 9;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
        IFX_G722_64;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G722_64; 
    }
    else if (!strcmp(pcFmt, "15")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 15;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
        IFX_G728;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G728; 
    }
    else if (!strcmp(pcFmt, "18")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = 18;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
        IFX_G729_8;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
      pxLocalSdp->iCodecList |= IFX_G729_8; 
    }
#ifdef FAX_SUPPORT
    else if (!IFX_SIPAPP_strcasecmp(pcFmt, "t38")) {
      pxLocalSdp->ucNumRemCap++;
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
      if(pxLocalSdp->pxT38Capab == NULL){
         pxLocalSdp->pxT38Capab =
                    (x_IFX_FaxParams*)IFX_SIPAPP_Calloc(1,sizeof(x_IFX_FaxParams )*2);
        if(pxLocalSdp->pxT38Capab == NULL){
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_MEM_ALLOC_ERR,
             sizeof(x_IFX_FaxParams )*2);
          return IFX_SIP_FAILURE;
        }
      }
      pcProto = IFX_SDP_MediaDesc_Media_GetProtocol(uiMedia);
      if (pcProto) {
        if(!IFX_SIPAPP_strcasecmp(pcProto, "udptl")) {
          pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                             IFX_T38_UDP;
		      pxLocalSdp->iCodecList |= IFX_T38_UDP; 
			    pxLocalSdp->pxT38Capab[0].xFaxCfg.uiTransportProtocol = 
									    IFX_TRPROTO_UDP;
          uiLoc = 0;
        }
        else if (!IFX_SIPAPP_strcasecmp(pcProto, "TCP")) {
          pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                             IFX_T38_TCP;
		      pxLocalSdp->iCodecList |= IFX_T38_TCP; 
			    pxLocalSdp->pxT38Capab[1].xFaxCfg.uiTransportProtocol = 
									IFX_TRPROTO_TCP;
          uiLoc = 1;
        }
      }
      iCount=1;
			
			/*pxLocalSdp->pxT38Capab[0].xFaxCfg.uiTransportProtocol = IFX_TRPROTO_UDP;
			pxLocalSdp->pxT38Capab[1].xFaxCfg.uiTransportProtocol = IFX_TRPROTO_TCP;*/
							
      while(IFX_SDPAPP_DecodeSdpAttr(uiMediaDescHdl,iCount,&xAttr) != 
            IFX_SIP_FAILURE){
        switch (xAttr.eAttrType){
        case IFX_SDPAPP_ATTR_FAXVER:
          pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.ucVersion =
		  xAttr.uxSdpAttr.iFaxVersion;
          break;
        case IFX_SDPAPP_ATTR_MBR:
            pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.unMaxBitRate =
                  xAttr.uxSdpAttr.iMaxBitRate;
          break;
        case IFX_SDPAPP_ATTR_FILLBITREM:
          pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.uiBitOptions|=
            IFIN_FA_CAP_FL_OPT_FILL_BIT_REMOVAL;
          break;
        case IFX_SDPAPP_ATTR_TRANSMMR:
          pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.uiBitOptions |=
            IFIN_FA_CAP_FL_OPT_TRANSCODING_MMR;
          break;
        case IFX_SDPAPP_ATTR_TRANSJBIG:
          pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.uiBitOptions |=
            IFIN_FA_CAP_FL_OPT_TRANSCODING_JBIG;
          break;
        case IFX_SDPAPP_ATTR_RATEMGMT:
          switch (xAttr.uxSdpAttr.eFaxRateMgmt) {
          case IFX_SDPAPP_TRANSFERRED_TCF:
            pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.ucRateManagement |=
              IFIN_FA_CAP_FL_TCF_TRANSFERRED;
            break;
          case IFX_SDPAPP_LOCAL_TCF:
            pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.ucRateManagement |=
              IFIN_FA_CAP_FL_TCF_LOCAL;
            break;
          default:
            break;
          }
          break;
        case IFX_SDPAPP_ATTR_MAXBUFF:
          pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.unUDPMaxBufferSize =
            xAttr.uxSdpAttr.iMaxBuffer;
          break;
        case IFX_SDPAPP_ATTR_MAXDGRAM:
          pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.unUDPMaxDatagramSize =
            xAttr.uxSdpAttr.iMaxDgram;
          break;
        case IFX_SDPAPP_ATTR_UDPEC:
          switch (xAttr.uxSdpAttr.eUdpEC) {
          case IFX_SDPAPP_T38UDPFEC:
            pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.ucUDPErrCorrection |=
              IFIN_FA_CAP_FL_EC_FEC;
            break;
          case IFX_SDPAPP_T38UDPREDUNDANCY:
            pxLocalSdp->pxT38Capab[uiLoc].xFaxCfg.ucUDPErrCorrection|=
              IFIN_FA_CAP_FL_EC_REDUNDANCY;
            break;
          default:
            break;
          }
          break;
        default:
          break;
        }
        iCount++;
      }
      pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
        IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
      strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
             acConnAddr);
    }
#endif	/*  */
    else { 
      /* Check if it is a telephony event */
      int32 iPT=-1;
      x_IFX_SDPAPP_Attributes xAttr,xAttr1={0};
      int32 i=1,i1=0;
			char *pcTemp=IFX_SDP_MediaDesc_Media_GetFormat(uiMedia,iCount1);
			if(pcTemp != NULL){
        iPT = atoi(pcTemp);
			}
      while(IFX_SDPAPP_DecodeSdpAttr(uiMediaDescHdl,i,&xAttr) !=
		                 IFX_SIP_FAILURE) {
        /* Check for any dynamic payload types */
        if((xAttr.eAttrType == IFX_SDPAPP_ATTR_RTPMAP) &&
            (iPT == xAttr.uxSdpAttr.xRtpMap.iPayloadType)) {
          if(strcasecmp(xAttr.uxSdpAttr.xRtpMap.acEncodingName,
               "G729E") == 0) {
            pxLocalSdp->ucNumRemCap++;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = iPT;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                                   IFX_G729_E;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
                IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
            strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
                   acConnAddr);
            pxLocalSdp->iCodecList |= IFX_G729_E;
          }
          else if(strcasecmp(xAttr.uxSdpAttr.xRtpMap.
                    acEncodingName,"G726-40") == 0) {
            pxLocalSdp->ucNumRemCap++;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = iPT;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                                   IFX_G726_40;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
                IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
            strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
                   acConnAddr);
            pxLocalSdp->iCodecList |= IFX_G726_40;
          }
          else if(strcasecmp(xAttr.uxSdpAttr.xRtpMap.
                   acEncodingName, "G726-32") == 0) {
            if((pxLocalSdp->iCodecList & IFX_G726_32)==0){
              pxLocalSdp->ucNumRemCap++;
              pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
              pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = iPT;
              pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                                   IFX_G726_32;
              pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
                  IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
              strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
                     acConnAddr);
              pxLocalSdp->iCodecList |= IFX_G726_32;
            }
          }
          else if(IFX_SIPAPP_strcasecmp(xAttr.uxSdpAttr.xRtpMap.
                  acEncodingName,"G726-24") == 0) {
            pxLocalSdp->ucNumRemCap++;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = iPT;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                                   IFX_G726_24;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
                IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
            strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
                   acConnAddr);
            pxLocalSdp->iCodecList |= IFX_G726_24;
          }
          else if(IFX_SIPAPP_strcasecmp(xAttr.uxSdpAttr.xRtpMap.
                  acEncodingName, "G726-16") == 0) {
            pxLocalSdp->ucNumRemCap++;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].eMode = eMode;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].ucCodec = iPT;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].uiRmCodec =
                                   IFX_G726_16;
            pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].unRTPPort =
                IFX_SDP_MediaDesc_Media_GetPort(uiMedia);
            strcpy(pxLocalSdp->xRemCap[pxLocalSdp->ucNumRemCap].cRTPAddr,
                   acConnAddr);
            pxLocalSdp->iCodecList |= IFX_G726_16;
          }  
          else if(IFX_SIPAPP_strcasecmp(xAttr.uxSdpAttr.xRtpMap.
                  acEncodingName,"telephone-event") == 0){
	          i1=1;	  
            while(IFX_SDPAPP_DecodeSdpAttr(uiMediaDescHdl,i1,&xAttr1) !=
		                 IFX_SIP_FAILURE) {
              if((xAttr1.eAttrType == IFX_SDPAPP_ATTR_FMTP)
                  && (iPT == xAttr1.uxSdpAttr.xFmtp.iFormat)) {
                 /* Copy the set of allowable chars */
                strcpy(pxLocalSdp->acDtmfFmt,
                       xAttr1.uxSdpAttr. xFmtp.acFmtpParams);
		            i1 = 0;
                break;
              }
	            i1++;
            }
            /* if FMTP line is not present, allowable 0-15 */
            if(i1 == 0){
              strcpy(pxLocalSdp->acDtmfFmt, "0-15");
            }
            /* copy payload type */
            pxLocalSdp->unDtmfPT = iPT;
          }
        }
	i++;
      }
    }
    iCount1++;  
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name    :  IFX_SIP_StoreSdp
*  Description      :  this function stores the remote sdp info
*  Input Values     :  pxDecodedMsg..pointer to encoded data structure
*  Output Values    :  pxLocalSdp...pointer to SDP information stored
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_StoreSdp(IN uint32 uiMsgHdl,
                 OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  uchar8 iCount, ucChanged = 0;
  uint32 uiSdpHdl = pxLocalSdp->uiSdpMsgHdl;
  uint32 uiMediaDescHdl, uiMediaHdl, uiConnHdl, uiMediaConnHdl;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  if(IFX_SDP_GetHeaderByType(uiSdpHdl,IFX_SDP_CONNECTION,1,
	 &uiConnHdl) == (e_IFX_SDP_Return)IFX_SIP_FAILURE){
    return IFX_SIP_FAILURE;	  
  }
  /* Initialize the number of remote capabilities */
  pxLocalSdp->ucNumRemCap = 0;

  /* Reset DTMF payload type */
  pxLocalSdp->unDtmfPT = 0;
  iCount= 1;
  while(IFX_SDP_GetHeaderByType(uiSdpHdl,IFX_SDP_MEDIA_DESC,iCount,
	&uiMediaDescHdl) != (e_IFX_SDP_Return) IFX_SIP_FAILURE){

    eRetVal = IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_MEDIA,1,
		                           &uiMediaHdl);
    if(eRetVal == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }

    if(IFX_SDP_MediaDesc_Media_GetPort(uiMediaHdl) == 0){
      /* This check is to interoperate with D-Link */
      if(strcmp(IFX_SDP_Connection_GetAddress(uiConnHdl), "0.0.0.0") != 0){
        iCount++;
        continue;
      }
      iCount++;
      continue;
    }

    /* check whether the media type is acceptable or not audio or Image */
    if((IFX_SDP_MediaDesc_Media_GetMedia(uiMediaHdl) != IFX_SDP_AUDIO)
#ifdef FAX_SUPPORT
        && (IFX_SDP_MediaDesc_Media_GetMedia(uiMediaHdl) != IFX_SDP_IMAGE)
#endif
       ) {
      iCount++;
      continue;
    }

    /* check the transport protocol..shld be RTP/AVP or UDP */
    if (!(IFX_SIPAPP_strcasecmp(IFX_SDP_MediaDesc_Media_GetProtocol(uiMediaHdl),
        "RTP/AVP") || IFX_SIPAPP_strcasecmp(IFX_SDP_MediaDesc_Media_GetProtocol(
	uiMediaHdl),"udp")
#ifdef FAX_SUPPORT
        || IFX_SIPAPP_strcasecmp(IFX_SDP_MediaDesc_Media_GetProtocol(uiMediaHdl),
	"udptl") || IFX_SIPAPP_strcasecmp(IFX_SDP_MediaDesc_Media_GetProtocol(
	uiMediaHdl),"TCP")
#endif
        )) {
      iCount++;
      continue;
    }
    /* Handling Connections per m line */
    if(strlen(IFX_SDP_Connection_GetAddress(uiConnHdl)) == 0){
      if(IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_CONNECTION,1,
         &uiMediaConnHdl)!= (e_IFX_SDP_Return) IFX_SIP_FAILURE) {
        IFX_SDP_Connection_SetAddress(uiConnHdl,IFX_SDP_Connection_GetAddress(uiMediaConnHdl));        
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }

    if(IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_CONNECTION,1,
       &uiMediaConnHdl) == (e_IFX_SDP_Return) IFX_SIP_FAILURE) {
      ucChanged = 1;
      eRetVal = IFX_SDP_Media_SetParamByType(uiMediaDescHdl,
                    IFX_SDP_MEDIA_CONNECTION,&uiMediaConnHdl);
      if(eRetVal == IFX_SIP_FAILURE){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			"Set Media Conn Failed");
        return IFX_SIP_FAILURE;
      } 
      if(IFX_SDP_Connection_GetAddress(uiConnHdl) != NULL){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  IFX_SDP_Connection_GetAddress(uiConnHdl));  
      }
      eRetVal =IFX_SDP_Connection_SetAddress(uiMediaConnHdl,
		      IFX_SDP_Connection_GetAddress(uiConnHdl));
      if(eRetVal == IFX_SIP_FAILURE){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			"Set Media Conn Addr failed");
        return IFX_SIP_FAILURE;
      } 
    }

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "Store Remote Capabilites");
    if(IFX_SIPAPP_StoreRemCap(pxLocalSdp, uiMediaDescHdl) == IFX_SIP_FAILURE){
      iCount++;
      continue;
    }

    /*TODO: Restore the original value for later use */
    if (ucChanged == 1) {
      /*pxSdp->pxMediaDesc[iCount]->ucNumOfMediaConn = 0;*/
      ucChanged = 0;
    }

    /* store the remote ip adddress */
    strcpy(pxLocalSdp->xRtpInfo.cRemoteRTPAddr,
	   IFX_SDP_Connection_GetAddress(uiConnHdl));
	  	
    if(IFX_SDP_MediaDesc_Media_GetMedia(uiMediaHdl) == IFX_SDP_AUDIO){
       /* store the remote port number */
       pxLocalSdp->xRtpInfo.iRemoteRTPPort =
	       IFX_SDP_MediaDesc_Media_GetPort(uiMediaHdl);
     }
     iCount++;
	}
  /* If there is no capability */
  if (pxLocalSdp->ucNumRemCap == 0) {
    return IFX_SIP_FAILURE;
  }

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	         "Setting local sdp mode");
  /* Store the direction in case it is a terminating end */
  if (IFX_SIP_GetMessageType(uiMsgHdl) == IFX_SIP_REQUEST){
    pxLocalSdp->eDir = IFX_SIPAPP_INACTIVE_DIR;
    for (iCount = 1; iCount <= pxLocalSdp->ucNumRemCap; iCount++) {
      if (pxLocalSdp->xRemCap[iCount].eMode != IFX_SDP_INACTIVE) {
        pxLocalSdp->eDir = IFX_SIPAPP_SENDRECV;
        break;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name    :  IFX_SIPAPP_AddCodec
*  Description      :  this function adds the given codec to the list
*  Input Values     :  unRMCodec - Codec to be added
*                      pxT38Capab - pointer to codec related info(in ATA)
*  Output Values    :  pxMediaDesc - populated media description struct
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_AddCodec(IN uint32 uiRMCodec,
#ifdef FAX_SUPPORT
                 IN x_IFX_FaxParams *pxT38Capab,
#endif	/*  */
                 IN_OUT uint32 uiMediaDescHdl,
                 IN uchar8 ucDynPT)
{
  uint32 uiMediaHdl,uiAttrHdl;

  IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_MEDIA,1,&uiMediaHdl);
  switch (uiRMCodec) {
  case IFX_G711_ULAW:
    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"0");	  
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
    IFX_SDP_Attribute_SetValue(uiAttrHdl,"0 PCMU/8000");
    break;
  case IFX_G723_5_3:
  case IFX_G723:
  case IFX_G723_6_3:
    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"4");	  
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
    IFX_SDP_Attribute_SetValue(uiAttrHdl,"4 G723/8000");
    break;
  case IFX_G711_ALAW:
    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"8");	  
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
    IFX_SDP_Attribute_SetValue(uiAttrHdl,"8 PCMA/8000");
    break;
  case IFX_G722_64:
    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"9");	  
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
    IFX_SDP_Attribute_SetValue(uiAttrHdl,"9 G722/8000");
    break;
  case IFX_G728:
    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"15");	  
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
    IFX_SDP_Attribute_SetValue(uiAttrHdl,"15 G728/8000");
    break;
  case IFX_G729_8:
    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"18");	  
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
    IFX_SDP_Attribute_SetValue(uiAttrHdl,"18 G729/8000");
    break;
  case IFX_G729_E:
    {
      char8 acTemp[30];	     
      sprintf(acTemp, "%d", ucDynPT);
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);	  
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      sprintf(acTemp, "%d G729E/8000",ucDynPT);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
    }
    break;
  case IFX_G726_16:
    {
      char8 acTemp[30];	     
      sprintf(acTemp, "%d", ucDynPT);
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);	  
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      sprintf(acTemp, "%d G726-16/8000",ucDynPT);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
    }
    break;
  case IFX_G726_24:
    {
      char8 acTemp[30];	     
      sprintf(acTemp, "%d", ucDynPT);
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);	  
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      sprintf(acTemp, "%d G726-24/8000",ucDynPT);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
    }
    break;
  case IFX_G726_32:
    {
      char8 acTemp[30];	     
      sprintf(acTemp, "%d", ucDynPT);
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);	  
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      sprintf(acTemp, "%d G726-32/8000",ucDynPT);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
    }
    break;
  case IFX_G726_40:
    {
      char8 acTemp[30];	     
      sprintf(acTemp, "%d", ucDynPT);
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);	  
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      sprintf(acTemp, "%d G726-40/8000",ucDynPT);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
    }
    break;

#ifdef FAX_SUPPORT
  case IFX_T38_UDP:
    {
      char8 acTemp[30];	
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"t38");
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxVersion");
      sprintf(acTemp,"%d",pxT38Capab[0].xFaxCfg.ucVersion);
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);

      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxMaxDatagram");
      sprintf(acTemp,"%d",pxT38Capab[0].xFaxCfg.unUDPMaxDatagramSize);
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);

      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxMaxBuffer");
      sprintf(acTemp,"%d",pxT38Capab[0].xFaxCfg.unUDPMaxBufferSize);
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);

      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"T38MaxBitRate");
      sprintf(acTemp,"%d",pxT38Capab[0].xFaxCfg.unMaxBitRate);
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
      
      if(pxT38Capab[0].xFaxCfg.ucRateManagement & IFIN_FA_CAP_FL_TCF_LOCAL){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			&uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxRateManagement");
        IFX_SDP_Attribute_SetValue(uiAttrHdl,"localTCF");
      }
      else if(pxT38Capab[0].xFaxCfg.ucRateManagement & 
		      IFIN_FA_CAP_FL_TCF_TRANSFERRED){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			&uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxRateManagement");
        IFX_SDP_Attribute_SetValue(uiAttrHdl,"transferredTCF");
      }
      if(pxT38Capab[0].xFaxCfg.ucUDPErrCorrection & IFIN_FA_CAP_FL_EC_REDUNDANCY){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxUdpEC");
        IFX_SDP_Attribute_SetValue(uiAttrHdl,"t38UDPRedundancy");
      }
      else if(pxT38Capab[0].xFaxCfg.ucUDPErrCorrection& IFIN_FA_CAP_FL_EC_FEC){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxUdpEC");
        IFX_SDP_Attribute_SetValue(uiAttrHdl,"t38UDPFEC");
      }
      if(pxT38Capab[0].xFaxCfg.uiBitOptions & IFIN_FA_CAP_FL_OPT_TRANSCODING_MMR){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxTranscodingMMR");
      }
      if(pxT38Capab[0].xFaxCfg.uiBitOptions & IFIN_FA_CAP_FL_OPT_TRANSCODING_JBIG){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxTranscodingJBIG");
      }
      if(pxT38Capab[0].xFaxCfg.uiBitOptions & IFIN_FA_CAP_FL_OPT_FILL_BIT_REMOVAL){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxFillBitRemoval");
      }
    }
    break;
  case IFX_T38_TCP:
    {
      char8 acTemp[30];	    
      IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,"t38");	 
    
      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxVersion");
      sprintf(acTemp,"%d",pxT38Capab[1].xFaxCfg.ucVersion);
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);

      IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
      IFX_SDP_Attribute_SetName(uiAttrHdl,"T38MaxBitRate");
      sprintf(acTemp,"%d",pxT38Capab[1].xFaxCfg.unMaxBitRate);
      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
    
      if(pxT38Capab[1].xFaxCfg.ucRateManagement & IFIN_FA_CAP_FL_TCF_LOCAL){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
	     		             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxRateManagement");
        IFX_SDP_Attribute_SetValue(uiAttrHdl,"localTCF");
      }
      else if(pxT38Capab[1].xFaxCfg.ucRateManagement&IFIN_FA_CAP_FL_TCF_TRANSFERRED){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
		                     &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxRateManagement");
        IFX_SDP_Attribute_SetValue(uiAttrHdl,"transferredTCF");
      }
      if(pxT38Capab[1].xFaxCfg.uiBitOptions & IFIN_FA_CAP_FL_OPT_TRANSCODING_MMR){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
	                             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxTranscodingMMR");
      }
      if(pxT38Capab[1].xFaxCfg.uiBitOptions & IFIN_FA_CAP_FL_OPT_TRANSCODING_JBIG){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxTranscodingJBIG");
      }
      if(pxT38Capab[1].xFaxCfg.uiBitOptions & IFIN_FA_CAP_FL_OPT_FILL_BIT_REMOVAL){
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			             &uiAttrHdl);
        IFX_SDP_Attribute_SetName(uiAttrHdl,"T38FaxFillBitRemoval");
      }
    }
    break;
#endif	/*  */
  default:
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_CheckifSupportedGetIndex
*  Description      :  this function Checks if a particular codec is
*                      supported locally, and gets the index in case
*                      it is supported
*  Input Values     :  unRMCodec - type of codec to be checked for
*                      Pointer to Endpoint Information Base
*  Output Values    :  Index to the codec
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CheckifSupportedGetIndex(IN uint32 uiRMCodec,
                                 IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                                 OUT int32* piIndex)
{
  x_IFX_CodecList *pxCodecList= IFX_SIPAPP_GETMEDIACFG(pxLocalSdp->iProfileId);

  for(*piIndex = 0; (*piIndex < pxCodecList->unNoOfCodecs)&&
			(*piIndex < IFX_MAX_CODECS);(*piIndex)++){
        if(pxCodecList->axCodec[*piIndex].uiCodec == uiRMCodec){
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			           "Checking Configuration");
        return IFX_SIP_SUCCESS;
			}
			if(uiRMCodec == IFX_G723){
				if((pxCodecList->axCodec[*piIndex].uiCodec ==IFX_G723)||			
					 (pxCodecList->axCodec[*piIndex].uiCodec ==IFX_G723_5_3)||			
					 (pxCodecList->axCodec[*piIndex].uiCodec ==IFX_G723_6_3)){
           return IFX_SIP_SUCCESS;
				}
			}
			if(uiRMCodec == IFX_T38_TCP){
				if((pxCodecList->axCodec[*piIndex].uiCodec ==IFX_T38_UDP)||			
					 (pxCodecList->axCodec[*piIndex].uiCodec ==IFX_T38_TCP)){
           return IFX_SIP_SUCCESS;
				}
			}	
  }
  return IFX_SIP_FAILURE;
}

/******************************************************************
*  Function Name    :  IFX_SIPAPP_GetRmCodec
*  Description      :  this function maps IANA payload type to RM type
*  Input Values     :  pucIANAType - IANA payload type
*                      pxLocalSdp - Pointer to SDP stored localy
*  Output Values    :  punRMCodec - RM type for corresponding IANA type
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetRmCodec(IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                   IN uchar8* pucIANAType,
                   OUT uint32* puiRMCodec)
{
  uchar8 ucPT, ucIndex;
  ucPT = atoi((char8 *)pucIANAType);
  if (ucPT > 95) {
    /* search from Remote Capability List */
    for (ucIndex = 1; ((ucIndex <= pxLocalSdp->ucNumRemCap)&&
					(ucIndex<IFX_MAX_CODECS)); ucIndex++) {
      if (ucPT == pxLocalSdp->xRemCap[ucIndex].ucCodec) {
        *puiRMCodec = pxLocalSdp->xRemCap[ucIndex].uiRmCodec;
        return IFX_SIP_SUCCESS;
      }
    }
    return IFX_SIP_FAILURE;
  }
  else{
    if (strcmp((char8 *)pucIANAType,"0") == 0) {
      *puiRMCodec = IFX_G711_ULAW;
      return IFX_SIP_SUCCESS;
    }
    else if (strcmp((char8 *)pucIANAType,"8") == 0) {
      *puiRMCodec = IFX_G711_ALAW;
      return IFX_SIP_SUCCESS;
    }
    else if (strcmp((char8 *)pucIANAType, "18") == 0) {
      *puiRMCodec = IFX_G729_8;
      return IFX_SIP_SUCCESS;
    }
    else if (strcmp((char8 *)pucIANAType, "4") == 0) {
      *puiRMCodec = IFX_G723;
      return IFX_SIP_SUCCESS;
    }
    else if (strcmp((char8 *)pucIANAType, "9") == 0) {
      *puiRMCodec = IFX_G722_64;
      return IFX_SIP_SUCCESS;
    }
    else if (strcmp((char8 *)pucIANAType, "15") == 0) {
      *puiRMCodec = IFX_G728;
      return IFX_SIP_SUCCESS;
    }
#ifdef FAX_SUPPORT
    else if (strcmp((char8 *)pucIANAType, "t38") == 0) {
      *puiRMCodec = IFX_T38_UDP;
      return IFX_SIP_SUCCESS;
    }
#endif
  }
  for (ucIndex = 1;ucIndex<IFX_MAX_CODECS && ucIndex <= pxLocalSdp->ucNumRemCap; ucIndex++) {
    if (ucPT == pxLocalSdp->xRemCap[ucIndex].ucCodec) {
      *puiRMCodec = pxLocalSdp->xRemCap[ucIndex].uiRmCodec;
      return IFX_SIP_SUCCESS;
    }
  }
  return IFX_SIP_FAILURE;
}

/******************************************************************
*  Function Name    :  IFX_SIP_AnswerSdpInactive
*  Description      :  this function answer with the sdp info
*  Input Values     :  pxLocalSdp...pointer to SDP info
*  Output Values    :  pxEncodedMsg..pointer to encoded data structure
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnswerSdpInactive(IN uint32 uiMsgHdl,
                          OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                          OUT e_IFX_SIP_Ecode* peEcode)
{
  uint32 uiDecMediaDescHdl, uiDecMediaHdl,uiDecSdp = pxLocalSdp->uiSdpMsgHdl;
  uint32 uiMediaDescHdl, uiMediaHdl;
  uint32 uiSdpHdl=0;
  uint32 uiAttrHdl;
  uint32 uiTempCodec;
  int32 i, iCount, iAtleastOne = 0, iIndex, iDtmf = 0, iRtcp = 0;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  e_IFX_SDP_SdpMedia ePrevMedia = 0;
  uchar8 ucDynPT,ucIANAType;
  char8* pcTemp;
   
  if(uiDecSdp == 0){
    return IFX_SIP_FAILURE;
  }

  /* malloc memory for the sdp */
  IFX_SDP_CreateMsg(&uiSdpHdl);
  if (uiSdpHdl == 0){
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "SDP malloc fail");
    return IFX_SIP_FAILURE;
  }
  IFX_SIPAPP_AddGeneralSdp(pxLocalSdp, uiSdpHdl);

  /* fill the media field */
  i=1;
  while(IFX_SDP_GetHeaderByType(uiDecSdp,IFX_SDP_MEDIA_DESC,i,
			  &uiDecMediaDescHdl) != (e_IFX_SDP_Return) IFX_SIP_FAILURE){
    iAtleastOne = 0;
    if(IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_MEDIA_DESC,&uiMediaDescHdl)== (e_IFX_SDP_Return)
        IFX_SIP_FAILURE){
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      IFX_SDP_FreeMsg(uiSdpHdl);
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "SDP malloc 1 fail");
      return IFX_SIP_FAILURE;
    }
    IFX_SDP_Media_GetParamByType(uiDecMediaDescHdl,IFX_SDP_MEDIA_MEDIA,1,
		                 &uiDecMediaHdl);
    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_MEDIA,
  		                   &uiMediaHdl);
    if((IFX_SDP_MediaDesc_Media_GetMedia(uiDecMediaHdl) != IFX_SDP_AUDIO) &&
       (IFX_SDP_MediaDesc_Media_GetMedia(uiDecMediaHdl) != IFX_SDP_IMAGE)){ 
      /* copy as it is and set the port to 0 */
      /* copy one media line to other */
      IFX_SDP_Media_CopyMedia(uiDecMediaHdl,uiMediaHdl);
      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,0);
      /*TODO: API to set the mode to 0 
      pxMediaDesc->eMode = 0;*/
      i++;
      continue;
    }
    iCount = 1;
    while((pcTemp = IFX_SDP_MediaDesc_Media_GetFormat(uiDecMediaHdl,(uint8)iCount))
		    != NULL){
      eRetVal = IFX_SIPAPP_GetRmCodec(pxLocalSdp, (uchar8 *)pcTemp, &uiTempCodec);
      if(eRetVal != IFX_SIP_SUCCESS){
       iCount++;
        continue;
      }
#ifdef FAX_SUPPORT
      else if (uiTempCodec == IFX_T38_UDP) {
        /* set udp or tcp based on acproto */

        if(strcasecmp(IFX_SDP_MediaDesc_Media_GetProtocol(uiDecMediaHdl), "TCP") == 0) {
					
          uiTempCodec = IFX_T38_TCP;
        }
      }
#endif
      eRetVal =
        IFX_SIPAPP_CheckifSupportedGetIndex(uiTempCodec, pxLocalSdp, &iIndex);
      if (eRetVal != IFX_SIP_SUCCESS) {
        iCount++;
        continue;
      }
      if ((uiTempCodec >= IFX_G711_ALAW)
          && (uiTempCodec < IFX_T38_UDP)) {
        if (ePrevMedia != IFX_SDP_AUDIO) {
	  IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_AUDIO);
#ifdef STUN_SUPPORT          
          /* If STUN is ON and Got Mapped port copy mapped port */
          if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0){
	    IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,	  
                          pxLocalSdp->xRtpInfo.unMappedRTPPort);
          }
          else
#endif                  
          {
	    IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,	  
               pxLocalSdp->xRtpInfo.iLocalRTPPort);
          }
	  IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,
			  "RTP/AVP");
          if(pxLocalSdp->eDir == IFX_SIPAPP_INACTIVE_DIR) {
            IFX_SDP_MediaDesc_SetMode(uiMediaDescHdl,IFX_SDP_INACTIVE);
          }
          /* set the previous media type as Audio */
          ePrevMedia = IFX_SDP_AUDIO;
        }
        /* Fill the supported audio codecs 
         * Using single payload type for a given audio codec
         * Using the Dynamic Payload type offered by the remote end
         */
        IFX_SIPAPP_GetIanaCodec(pxLocalSdp, uiTempCodec, &ucIANAType);
        eRetVal = IFX_SIPAPP_AddCodec(uiTempCodec,
#ifdef FAX_SUPPORT 
                            NULL,
#endif	/*  */
                            uiMediaDescHdl,ucIANAType);
        if((pxLocalSdp->unDtmfPT != 0) && (iDtmf != 1)) {
          if(IFX_SIPAPP_SupportDTMF(pxLocalSdp->iProfileId,&ucDynPT) ==
              IFX_SIP_SUCCESS) {
            char8 acTemp[64];
            /* Using single payload type for sending and receiving 2833 pkts
             * Using the Payload type offered by the remote end
             */
            sprintf(acTemp, "%d", pxLocalSdp->unDtmfPT);
	    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);
	    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,
			    IFX_SDP_MEDIA_ATTRIBUTES, &uiAttrHdl);
	    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
	    sprintf(acTemp,"%d telephone-event/8000",pxLocalSdp->unDtmfPT);
	    IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);

	    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,
			    IFX_SDP_MEDIA_ATTRIBUTES, &uiAttrHdl);
	    IFX_SDP_Attribute_SetName(uiAttrHdl,"fmtp");
	    sprintf(acTemp,"%d 0-11",pxLocalSdp->unDtmfPT);
	    IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
            iDtmf = 1;
          }
          if((iRtcp == 0)){
            char8 acTemp[10];
	    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,
			    &uiAttrHdl);
	    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtcp");
            /* Fill the port details */
#ifdef STUN_SUPPORT            
            if(pxLocalSdp->xRtpInfo.unMappedRTCPPort != 0){
	          sprintf(acTemp,"%d",pxLocalSdp->xRtpInfo.unMappedRTCPPort);
			  IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
            }
            else
#endif                    
            {
	      sprintf(acTemp,"%d",pxLocalSdp->xRtpInfo.iLocalRTPPort+1);
	      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
            }
            iRtcp = 1;
          }    
        }
#ifdef FAX_SUPPORT
        else if ((uiTempCodec == IFX_T38_UDP) ||
                 (uiTempCodec == IFX_T38_TCP)) {
          x_IFX_FaxParams *pxT38Capab = NULL;
          iRtcp = 0;
	  IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_IMAGE);
          if(pxLocalSdp->eDir == IFX_SIPAPP_INACTIVE_DIR) {
            /* Fill the media attribute Info */
            IFX_SDP_MediaDesc_SetMode(uiMediaDescHdl,IFX_SDP_INACTIVE);
//            pxMediaDesc->eMode = IFX_SDP_INACTIVE;
          }
          if(uiTempCodec == IFX_T38_UDP){
            IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"udptl");
#ifdef STUN_SUPPORT          
            /* If STUN is ON and Got Mapped port copy mapped port */
            if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0){
	      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->
			      xRtpInfo.unMappedFAXUDPPort);
            }
            else
#endif                  
            {
	      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
			      iLocalFaxUdpPort);
            }
	        pxT38Capab = pxLocalSdp->pxT38Capab;
          }
          else {
            IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"TCP");
	    IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl, 
		    pxLocalSdp->xRtpInfo.iLocalFaxTcpPort);
          }
          pxT38Capab = pxLocalSdp->pxT38Capab;
          /* Add the fax codec */
          eRetVal = IFX_SIPAPP_AddCodec(uiTempCodec,pxT38Capab,uiMediaDescHdl,0);
          /* Set the previous Media type as Fax */
          ePrevMedia = IFX_SDP_IMAGE;
        }
#endif	/*  */
      }
#ifdef FAX_SUPPORT
      else if ((uiTempCodec == IFX_T38_UDP) ||
               (uiTempCodec == IFX_T38_TCP)) {
        IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_IMAGE);		
        iRtcp = 0;
        if(uiTempCodec == IFX_T38_UDP){
	        IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"udptl");
#ifdef STUN_SUPPORT  	    
            /* If STUN is ON and Got Mapped port copy mapped port */
	        if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0){
	          IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->
	                               xRtpInfo.unMappedFAXUDPPort);
			    }
	        else
#endif
			    {
	          IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
	                                       iLocalFaxUdpPort);
          }
        }
        else{
	        IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"TCP");
					printf("Setting port %d\n",pxLocalSdp->xRtpInfo.iLocalFaxTcpPort);
	        IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,
	                     pxLocalSdp->xRtpInfo.iLocalFaxTcpPort);
        }
        /* Add the fax codec */
	    if(!pxLocalSdp->pxT38Capab) /*Fix: To get default T38 Capab*/
	    {
	     pxLocalSdp->pxT38Capab =  IFX_SIPAPP_FAXCFG(pxLocalSdp->iProfileId);
	    }else{
          x_IFX_FaxParams *pxDefT38Capab = NULL;
					pxDefT38Capab = IFX_SIPAPP_FAXCFG(pxLocalSdp->iProfileId);

				if (!pxLocalSdp->pxT38Capab->xFaxCfg.unUDPMaxBufferSize)
					pxLocalSdp->pxT38Capab->xFaxCfg.unUDPMaxBufferSize = pxDefT38Capab->xFaxCfg.unUDPMaxBufferSize;
				if (!pxLocalSdp->pxT38Capab->xFaxCfg.unUDPMaxDatagramSize)
					pxLocalSdp->pxT38Capab->xFaxCfg.unUDPMaxDatagramSize = pxDefT38Capab->xFaxCfg.unUDPMaxDatagramSize;
				if (!pxLocalSdp->pxT38Capab->xFaxCfg.unMaxBitRate)
					pxLocalSdp->pxT38Capab->xFaxCfg.unMaxBitRate = pxDefT38Capab->xFaxCfg.unMaxBitRate;
				if (!pxLocalSdp->pxT38Capab->xFaxCfg.ucUDPErrCorrection)
					pxLocalSdp->pxT38Capab->xFaxCfg.ucUDPErrCorrection = pxDefT38Capab->xFaxCfg.ucUDPErrCorrection;
			}
        eRetVal = IFX_SIPAPP_AddCodec(uiTempCodec,pxLocalSdp->pxT38Capab, 
			                                uiMediaDescHdl, 0);
      }
#endif	/*  */
 
      if (eRetVal == IFX_SIP_SUCCESS) {
        iAtleastOne = 1;
      }
      else {
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 " <TUNegotiate>Add codec failed");
      }
      iCount++;
    }
    if (iAtleastOne == 0) {
      /* copy Media line given media desc */ 
      IFX_SDP_Media_CopyMedia(uiDecMediaHdl,uiMediaHdl);
      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,0);	    
      /*TODO: API to set the mode 
      pxMediaDesc->eMode = 0;*/
    }
    i++;
  }
  /* Encode the SDP message */
  {
    char8 *szSdpBuff;
    szSdpBuff = (char8*)IFX_SIPAPP_Malloc(5000);
		if(szSdpBuff ==NULL){
			return IFX_SIP_FAILURE;
		}
    if(IFX_SDP_EncodeMessage(uiSdpHdl,szSdpBuff)!= IFX_SIP_FAILURE){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, szSdpBuff);
      /* Add message Body to the message Handle */
      eRetVal = IFX_SIP_AddMsgBody(uiMsgHdl,strlen(szSdpBuff),szSdpBuff);
    }
    IFX_SIPAPP_Free(szSdpBuff);
  }
  IFX_SDP_FreeMsg(uiSdpHdl);

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name    :  IFX_SIPAPP_GetLockedCodecEntry
*  Description      :  this function will get the first locked codec entry
*  Input Values     :  lockedcodec Entry and SdpInfo
*  Output Values    :  lockedcodec Entry
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetLockedCodecEntry(OUT int16 *pnLockedCodecEntry,
                            IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp)
{ 
  int32 i,iIdx = 0;
  e_IFX_SIP_Return eRetval = IFX_SIP_SUCCESS;
  for(i = 1; ((i <= pxLocalSdp->ucNumRemCap)&&(i<IFX_MAX_CODECS)); i++){
    eRetval = IFX_SIPAPP_CheckifSupportedGetIndex(pxLocalSdp->xRemCap[i].
		    uiRmCodec, pxLocalSdp, &iIdx);
    if(eRetval != IFX_SIP_SUCCESS){
      continue;
    }
    *pnLockedCodecEntry = i;
    break;
  }
  if(i > pxLocalSdp->ucNumRemCap){
    *pnLockedCodecEntry = -1;
  } 
  return eRetval; 
}

/******************************************************************
*  Function Name    :  IFX_SIP_AnsSdp
*  Description      :  this function answer with the sdp info
*  Input Values     :  pxLocalSdp...pointer to SDP info
*  Output Values    :  pxEncodedMsg..pointer to encoded data structure
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnsSdp(IN uint32 uiMsgHdl,
               OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
               OUT e_IFX_SIP_Ecode* peEcode)
{
  uint32 uiDecSdp= pxLocalSdp->uiSdpMsgHdl,uiDecMediaDesc,uiMediaDesc,uiMediaHdl,
         uiDecMediaHdl;	
  uint32 uiTempCodec,uiAttrHdl, uiSdpHdl;
  int32 i, iCount, iAtleastOne = 0, iFlag = 0, /*iDtmf = 0,*/ iRtcp = 0;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uchar8 ucDynPT,ucIANAType;
  char8 *pcTemp;

  if(uiDecSdp == 0){
    return IFX_SIP_FAILURE;
  }

  /* malloc memory for the sdp */
  eRetVal = IFX_SDP_CreateMsg(&uiSdpHdl);
  if(eRetVal == IFX_SIP_FAILURE) {
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    return IFX_SIP_FAILURE;
  }
  IFX_SIPAPP_AddGeneralSdp(pxLocalSdp, uiSdpHdl);
 
  /* fill the media field */
  i=1;
  while(IFX_SDP_GetHeaderByType(uiDecSdp,IFX_SDP_MEDIA_DESC,i,&uiDecMediaDesc)
		  != (e_IFX_SDP_Return) IFX_SIP_FAILURE){
    eRetVal = IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_MEDIA_DESC,&uiMediaDesc); 
    if(eRetVal != IFX_SIP_SUCCESS){
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      return IFX_SIP_FAILURE;
    }
    IFX_SDP_Media_GetParamByType(uiDecMediaDesc,IFX_SDP_MEDIA_MEDIA,1,
		    &uiDecMediaHdl);
    IFX_SDP_Media_SetParamByType(uiMediaDesc,IFX_SDP_MEDIA_MEDIA,
  		                   &uiMediaHdl);
    if(((IFX_SDP_MediaDesc_Media_GetMedia(uiDecMediaHdl) != IFX_SDP_AUDIO) &&
        (IFX_SDP_MediaDesc_Media_GetMedia(uiDecMediaHdl) != IFX_SDP_IMAGE)) ||
        (iFlag == 1)|| (IFX_SDP_MediaDesc_Media_GetPort(uiDecMediaHdl)== 0)){
      IFX_SDP_Media_CopyMedia(uiDecMediaHdl,uiMediaHdl);
      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,0);
      IFX_SDP_MediaDesc_SetMode(uiMediaDesc, 0);
      i++;
      continue;
    }

    /* Check if that codec is supported at our end */
    iCount = 1;
    while((pcTemp = IFX_SDP_MediaDesc_Media_GetFormat(uiDecMediaHdl,(uint8)iCount))
          != NULL){
      eRetVal = IFX_SIPAPP_GetRmCodec(pxLocalSdp, (uchar8 *)pcTemp, &uiTempCodec);
      if(eRetVal != IFX_SIP_SUCCESS){
        iCount++;
        continue;
      }
			if((IFX_G723_5_3 == pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
			           uiRmCodec)||(IFX_G723_6_3 == pxLocalSdp->
								xRemCap[pxLocalSdp->nLockedCodecEntry].uiRmCodec)){
				pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
							                    uiRmCodec = IFX_G723;		
			}
#ifdef FAX_SUPPORT
      else if(uiTempCodec == IFX_T38_UDP){
        /* set udp or tcp based on acproto */
        if(strcmp(IFX_SDP_MediaDesc_Media_GetProtocol(uiDecMediaHdl),"TCP")
		       	== 0){
          uiTempCodec = IFX_T38_TCP;
        }
      }
#endif
      if(pxLocalSdp->nLockedCodecEntry == -1){
        break;
      }
      if (uiTempCodec == pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
                           uiRmCodec) {
        if ((uiTempCodec >= IFX_G711_ALAW) && (uiTempCodec < IFX_T38_UDP)){
          /* Malloc and fill the generic values */
	      IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_AUDIO);
#ifdef STUN_SUPPORT          
          /* If STUN is ON and Got Mapped port copy mapped port */
          if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0)
          {
	        IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->
			                                xRtpInfo.unMappedRTPPort);	  
          }
          else
#endif                  
          {
	        IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->
			                                xRtpInfo.iLocalRTPPort);	  
          }
	      IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"RTP/AVP");
          /*pxMediaDesc->eMode = pxLocalSdp->eLocalMode;*/      
          IFX_SDP_MediaDesc_SetMode(uiMediaDesc, pxLocalSdp->eLocalMode);
          /* Fill the supported audio codecs 
           * Using single payload type for a given audio codec
           * Using the Payload type offered by the remote end
           */
          IFX_SIPAPP_GetIanaCodec(pxLocalSdp, uiTempCodec, &ucIANAType);
          eRetVal = IFX_SIPAPP_AddCodec(uiTempCodec,
#ifdef FAX_SUPPORT 
                          pxLocalSdp->pxT38Capab,
#endif	/*  */
                          uiMediaDesc,ucIANAType);
          if (pxLocalSdp->unDtmfPT != 0) {
            if (IFX_SIPAPP_SupportDTMF(pxLocalSdp->iProfileId,&ucDynPT) ==
                IFX_SIP_SUCCESS) {
              char8 acTemp[64];
              /* Using single payload type for sending and receiving 2833 pkts
               * Using the Payload type offered by the remote end
               */
              sprintf(acTemp, "%d", pxLocalSdp->unDtmfPT);
	          IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl,acTemp);
	          IFX_SDP_Media_SetParamByType(uiMediaDesc,
	                           IFX_SDP_MEDIA_ATTRIBUTES,&uiAttrHdl);
	          IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
	          sprintf(acTemp,"%d telephone-event/8000",pxLocalSdp->unDtmfPT);
	          IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
	
              IFX_SDP_Media_SetParamByType(uiMediaDesc,
			      IFX_SDP_MEDIA_ATTRIBUTES, &uiAttrHdl);
              IFX_SDP_Attribute_SetName(uiAttrHdl,"fmtp");
              sprintf(acTemp,"%d 0-11",pxLocalSdp->unDtmfPT);
              IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
              //iDtmf = 1;
            }
          }
          if((iRtcp == 0)){
            char8 acTemp[10];
            IFX_SDP_Media_SetParamByType(uiMediaDesc,
			    IFX_SDP_MEDIA_ATTRIBUTES, &uiAttrHdl);
	    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtcp");
               /* Fill the port details */
#ifdef STUN_SUPPORT
            if(pxLocalSdp->xRtpInfo.unMappedRTCPPort != 0){
              sprintf(acTemp,"%d",pxLocalSdp->xRtpInfo.unMappedRTCPPort);                                IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
            }
            else
#endif
	    {
	      sprintf(acTemp,"%d",pxLocalSdp->xRtpInfo.iLocalRTPPort+1);
	      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
	    }
            iRtcp = 1;
          }    
        }
#ifdef FAX_SUPPORT
        else if ((uiTempCodec == IFX_T38_UDP) ||
                 (uiTempCodec == IFX_T38_TCP)) {
          IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_IMAGE);		
          iRtcp = 0;
          if(uiTempCodec == IFX_T38_UDP){
	        IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"udptl");
#ifdef STUN_SUPPORT  	    
            /* If STUN is ON and Got Mapped port copy mapped port */
	        if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0){
	          IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->
	                               xRtpInfo.unMappedFAXUDPPort);
			}
	        else
#endif
			{
	          IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
	                                       iLocalFaxUdpPort);
            }
          }
          else{
	       IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"TCP");
	       IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,
	                     pxLocalSdp->xRtpInfo.iLocalFaxTcpPort);
          }
          /* Add the fax codec */
          eRetVal = IFX_SIPAPP_AddCodec(uiTempCodec,pxLocalSdp->pxT38Capab, 
			             uiMediaDesc, 0);
        }
#endif	/*  */
  	    else{
          iCount++;
	      continue;
		}
        if(eRetVal == IFX_SIP_SUCCESS){
         iAtleastOne = 1;
         iFlag = 1;
		}
        if (iAtleastOne == 1) {
          break;
		}
      }
      iCount++;
    }
    if (iAtleastOne == 0) {
      /* Invalidate the m-line */
      IFX_SDP_Media_CopyMedia(uiDecMediaHdl,uiMediaHdl);
      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,0);
      IFX_SDP_MediaDesc_SetMode(uiMediaDesc, 0);
      i++;
      continue;
    }
    i++;
  }
  /* Encode the SDP message */
  {
    char8 *szSdpBuff;
    szSdpBuff = (char8*)IFX_SIPAPP_Malloc(1000);
    if(szSdpBuff == NULL){
      return IFX_SIP_FAILURE;
    }
    if(IFX_SDP_EncodeMessage(uiSdpHdl,szSdpBuff)!= IFX_SIP_FAILURE){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, szSdpBuff);
      /* Add message Body to the message Handle */
      eRetVal = IFX_SIP_AddMsgBody(uiMsgHdl,strlen(szSdpBuff),szSdpBuff);
    }
   IFX_SIPAPP_Free(szSdpBuff);
  }
  IFX_SDP_FreeMsg(uiSdpHdl);

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name    :  IFX_SIP_AnswerSdp
*  Description      :  this function answer with the sdp info
*  Input Values     :  pxLocalSdp...pointer to SDP info
*  Output Values    :  pxEncodedMsg..pointer to encoded data structure
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AnswerSdp(IN uint32 uiMsgHdl,
                   OUT x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                   OUT e_IFX_SIP_Ecode* peEcode)
{
  if(pxLocalSdp->uiSdpMsgHdl == 0) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "<TUNegotiate>SDP Info is null");
    return IFX_SIP_FAILURE;
  }

  IFX_SIPAPP_GetLockedCodecEntry(&pxLocalSdp->nLockedCodecEntry,pxLocalSdp);
  pxLocalSdp->eLocalMode = IFX_SIPAPP_GetLocalMode(pxLocalSdp->eLocalMode,
                            pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
                            eMode);
  /* This put for polycom problem */
  if(pxLocalSdp->iFlag & IFX_SIPAPP_SET_MODE){
    pxLocalSdp->eLocalMode = IFX_SDP_SENDONLY;
  }
  return IFX_SIPAPP_AnsSdp(uiMsgHdl,pxLocalSdp,peEcode);
}


#ifdef FAX_SUPPORT
/******************************************************************
*  Function Name    :  IFX_SIPAPP_AddFaxMLine
*  Description      :  this function Adds the required params for
                       m line of fax
*  Input Values     :  pxLocalSdp...pointer to SDP info
*  Output Values    :  pxEncodedMsg..pointer to encoded data structure
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AddFaxMLine(IN uint32 uiCodec,
                    IN uint32 uiSdpHdl,
                    IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                    OUT e_IFX_SIP_Ecode* peEcode)
{

  x_IFX_FaxParams *pxT38Capab=IFX_SIPAPP_FAXCFG(pxLocalSdp->iProfileId);
  uint32 uiMediaHdl = 0,uiMediaDescHdl=0;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "FAX Setup Adding T38 m line");

  eRetVal = IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_MEDIA_DESC,
			            &uiMediaDescHdl);
  if(eRetVal  == IFX_SIP_FAILURE){
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    IFX_SDP_FreeMsg(uiSdpHdl);
    eRetVal = IFX_SIP_FAILURE;
  }
  if (IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_MEDIA,
         		       &uiMediaHdl) == (e_IFX_SDP_Return) IFX_SIP_FAILURE) {
    IFX_SDP_FreeMsg(uiSdpHdl);
    return IFX_SIP_FAILURE;
  }
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Before copying T38 media discription");
	IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_IMAGE);
  if(uiCodec == IFX_T38_UDP) {
    IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl, "udptl");

#ifdef STUN_SUPPORT          
    /* If STUN is ON and Got Mapped port copy mapped port */
    if(pxLocalSdp->xRtpInfo.unMappedFAXUDPPort != 0){
      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl, pxLocalSdp->xRtpInfo.unMappedFAXUDPPort);

    }
    else
#endif                  
    {
      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl, pxLocalSdp->xRtpInfo.iLocalFaxUdpPort);
    }
  }
  else{
    IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl, "TCP");

    IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl, pxLocalSdp->xRtpInfo.iLocalFaxTcpPort);

  }
  /* Add the fax codec */
  IFX_SIPAPP_AddCodec(uiCodec, pxT38Capab, uiMediaDescHdl, 0); 


  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
          "After FAX Setup Adding T38 codec");

  return IFX_SIP_SUCCESS;
}
#endif

 
/******************************************************************
*  Function Name    :  IFX_SIP_OfferSdp
*  Description      :  this function offers the sdp info
*  Input Values     :  pxLocalSdp...pointer to SDP info
*  Output Values    :  pxEncodedMsg..pointer to encoded data structure
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_OfferSdp(IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SDP_SdpMedia ePrevMedia = 0;
  uint32 uiAttrHdl=0,uiMediaHdl=0,uiMediaDescHdl=0,uiSdpHdl=0;
  e_IFX_SDP_Mode eTempMode;
  x_IFX_CodecList *pxMediaCfg=IFX_SIPAPP_GETMEDIACFG(pxLocalSdp->iProfileId);
  x_IFX_CodecList *pxCodecList,xCodecList;
  int32 iFaxOfferFlag = 0;
  uchar8 ucDynPT;
  int32 i,iDtmf = 0, iRtcp = 0,iT38Supported=0,iUsingG711=0,iG711index=-1;
#ifdef FAX_SUPPORT
  x_IFX_FaxParams *pxT38Capab=IFX_SIPAPP_FAXCFG(pxLocalSdp->iProfileId);
#endif
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Inside Offer SDP");
#ifdef FAX_SUPPORT
   if(pxLocalSdp->iFlag & IFX_SIPAPP_FAX_SETUP){
      iFaxOfferFlag=1;	    
    }    
#endif /* FAX_SUPPORT */
  /* Check if already negotiated SDP is there */
  if((pxLocalSdp->uiSdpMsgHdl) 
#ifdef FAX_SUPPORT		  
       &&
       !(iFaxOfferFlag)
#endif
       ){
     
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Reinivte SDP");
    /* If SDP present then generate offer based on that */
    eTempMode = pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode;
    if (pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode ==
        IFX_SDP_RECVONLY) {
      pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode =
        IFX_SDP_SENDONLY;
    }
    else if (pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode ==
             IFX_SDP_SENDONLY) {
      pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode =
        IFX_SDP_RECVONLY;
    }
    
    if(IFX_SIPAPP_AnsSdp(uiEncMsgHdl, pxLocalSdp, peEcode) == 
                          IFX_SIP_FAILURE) {
      pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode = eTempMode;
      eRetVal = IFX_SIP_FAILURE;
    }
    pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].eMode = eTempMode;
    return eRetVal;
  }

  /* malloc memory for the sdp */
  eRetVal = IFX_SDP_CreateMsg(&uiSdpHdl);
  if(eRetVal != IFX_SIP_SUCCESS){
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    //IFX_SDP_FreeMsg(uiEncMsgHdl);
    return IFX_SIP_FAILURE;
  }
  /* add the general sdp info */
  IFX_SIPAPP_AddGeneralSdp(pxLocalSdp, uiSdpHdl);
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "After General SDP Construction");

  pxCodecList = &xCodecList;
  /* Make a copy  */
  memcpy(pxCodecList,pxMediaCfg,
         sizeof(x_IFX_CodecList));

  if(iFaxOfferFlag == 1){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "FAX Setup SDP Construction");
    for(i = 0; ((i < pxCodecList->unNoOfCodecs)&&
					(i<IFX_MAX_CODECS)); i++) {
      if((pxCodecList->axCodec[i].uiCodec == IFX_T38_UDP) ||
         (pxCodecList->axCodec[i].uiCodec == IFX_T38_TCP) ||
	  (pxCodecList->axCodec[i].uiCodec == IFX_T38_UDP)) {
         iT38Supported=1;
         pxCodecList->axCodec[i].uiCodec = IFX_T38_UDP;
      }	       
      if((pxCodecList->axCodec[i].uiCodec == IFX_G711_ULAW) ||
         (pxCodecList->axCodec[i].uiCodec == IFX_G711_ALAW)){
        iG711index=i;       
      }	   
    }    
    if((pxLocalSdp->xRemCap[0].uiRmCodec== IFX_G711_ULAW) ||
       (pxLocalSdp->xRemCap[0].uiRmCodec == IFX_G711_ALAW)){
      iUsingG711=1;
    }
    if(iT38Supported == 0){ 
      if((iUsingG711 == 0) && (iG711index != -1)){
	      x_IFX_Codec xCodec;      
	      iFaxOfferFlag =0;
        /* Re-order the codecs */
        memcpy(&xCodec,&pxCodecList->axCodec[0],sizeof(x_IFX_Codec));
        memcpy(&pxCodecList->axCodec[0],&pxCodecList->axCodec[iG711index],
			         sizeof(x_IFX_Codec));
        memcpy(&pxCodecList->axCodec[iG711index],&xCodec,sizeof(x_IFX_Codec));
      }
      else {
         IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "FAX Setup PASS THROUGH already using G711 or no PCMA,T38 codec");
	       return IFX_SIP_FAILURE;
      }
    }
    else{
      if(iG711index != -1){
        /* We have locked 711 already, add it at the end of local cap list */
        memcpy(&pxCodecList->axCodec[pxCodecList->unNoOfCodecs],
	       &pxCodecList->axCodec[iG711index],
	       sizeof(x_IFX_Codec));

    	pxCodecList->unNoOfCodecs++;
      }	      
    }    
  }
  
  /* Fill the required SDP information */
  for(i = 0; i < pxCodecList->unNoOfCodecs; i++) {
    if((pxCodecList->axCodec[i].uiCodec >= IFX_G711_ALAW) &&
       (pxCodecList->axCodec[i].uiCodec < IFX_T38_UDP)) {
      if (ePrevMedia != IFX_SDP_AUDIO){
        /* Malloc and fill the generic values */
	    eRetVal = IFX_SDP_SetHeaderByType(uiSdpHdl,IFX_SDP_MEDIA_DESC,
			                  &uiMediaDescHdl);      
        if(eRetVal  == IFX_SIP_FAILURE){
          *peEcode = IFX_SIP_TU_MEMORY_ERROR;
          IFX_SDP_FreeMsg(uiSdpHdl);
          eRetVal = IFX_SIP_FAILURE;
          break;
        }
	    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_MEDIA,
	  		&uiMediaHdl);
	    IFX_SDP_MediaDesc_Media_SetMedia(uiMediaHdl,IFX_SDP_AUDIO);
#ifdef FAX_SUPPORT
        if(iFaxOfferFlag == 1){
         if(pxLocalSdp->iFlag & IFX_SIPAPP_SWITCH_TO_VOICE){
	        IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
			   iLocalRTPPort);	 
         }
         else{
	       IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,0);	 
             iFaxOfferFlag = 0;
         }
        }
        else {
	      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
			   iLocalRTPPort);	 
          iFaxOfferFlag = 1;
        }
#ifdef STUN_SUPPORT        
        /* If STUN is ON and Got Mapped port copy mapped port */
        if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0){
	       IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
			  unMappedRTPPort);	 
        }
#endif                
#else	/*  */
#ifdef STUN_SUPPORT        
        /* If STUN is ON and Got Mapped port copy mapped port */
        if(pxLocalSdp->xRtpInfo.unMappedRTPPort != 0){
	      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
			  unMappedRTPPort);	 
        }
        else
#endif                
        {
	      IFX_SDP_MediaDesc_Media_SetPort(uiMediaHdl,pxLocalSdp->xRtpInfo.
			  iLocalRTPPort);	 
        }
#endif	/*  */
	    IFX_SDP_MediaDesc_Media_SetProtocol(uiMediaHdl,"RTP/AVP");	 
        IFX_SDP_MediaDesc_SetMode(uiMediaDescHdl, pxLocalSdp->eLocalMode);
        /*pxMediaDesc->eMode = pxLocalSdp->eLocalMode;*/
        /* set the previous media type as Audio */
        ePrevMedia = IFX_SDP_AUDIO;
      }

      /* Fill the supported audio codecs */
      IFX_SIPAPP_AddCodec(pxCodecList->axCodec[i].uiCodec,
#ifdef FAX_SUPPORT
                       pxT38Capab,
#endif	/*  */
                        uiMediaDescHdl, 
                        pxCodecList->axCodec[i].ucDynPT);
      if ((iDtmf == 0) &&
          (IFX_SIPAPP_SupportDTMF(pxLocalSdp->iProfileId, &ucDynPT) ==
           IFX_SIP_SUCCESS)) {
        char8 acTemp[64];
        sprintf(acTemp, "%d", ucDynPT);
	    IFX_SDP_MediaDesc_Media_SetFormat(uiMediaHdl, acTemp);
        IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,                            &uiAttrHdl);
	    IFX_SDP_Attribute_SetName(uiAttrHdl,"rtpmap");
        sprintf(acTemp, "%d telephone-event/8000", ucDynPT);
	    IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);

	    IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,                            &uiAttrHdl);
	    IFX_SDP_Attribute_SetName(uiAttrHdl,"fmtp");
	    sprintf(acTemp,"%d 0-11",ucDynPT);
	    IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
	    iDtmf = 1;
      }
      if((iRtcp == 0)){
	   char8 acTemp[10];
	   IFX_SDP_Media_SetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,                            &uiAttrHdl);
	   IFX_SDP_Attribute_SetName(uiAttrHdl,"rtcp");
#ifdef STUN_SUPPORT        
        if(pxLocalSdp->xRtpInfo.unMappedRTCPPort != 0){
          sprintf(acTemp,"%d",pxLocalSdp->xRtpInfo.unMappedRTCPPort);
	      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
        }
        else
#endif                
        {
	      sprintf(acTemp,"%d",pxLocalSdp->xRtpInfo.iLocalRTPPort+1);
	      IFX_SDP_Attribute_SetValue(uiAttrHdl,acTemp);
        }
        iRtcp = 1;
      }
    }
#ifdef FAX_SUPPORT
    if((pxCodecList->axCodec[i].uiCodec == IFX_T38_UDP)||
		(pxCodecList->axCodec[i].uiCodec == IFX_T38_TCP)) {
      eRetVal = IFX_SIPAPP_AddFaxMLine(pxCodecList->axCodec[i].uiCodec,uiSdpHdl,
                    pxLocalSdp,peEcode);
			if(eRetVal==IFX_SIP_FAILURE){
        IFX_SDP_FreeMsg(uiSdpHdl);
			}
      /* Set the previous Media type as Fax */
      ePrevMedia = IFX_SDP_IMAGE;
    }
#endif
  }
  /* Encode the SDP message */
  {
    char8 *szSdpBuff;
    szSdpBuff = (char8*)IFX_SIPAPP_Malloc(5000);
    if (szSdpBuff == NULL){
      eRetVal = IFX_SIP_FAILURE;
    }
    else {
      if(IFX_SDP_EncodeMessage(uiSdpHdl,szSdpBuff)!= IFX_SIP_FAILURE){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, szSdpBuff);
        /* Add message Body to the message Handle */
        eRetVal = IFX_SIP_AddMsgBody(uiEncMsgHdl,strlen(szSdpBuff),szSdpBuff);
      }
      IFX_SIPAPP_Free(szSdpBuff);
    }
  }
  IFX_SDP_FreeMsg(uiSdpHdl);
  return eRetVal;
}


/******************************************************************
*  Function Name    :  IFX_SIP_ResolveRtpAddress
*  Description      :  This function is called to resolve the RTP connection 
*                      address
*  Input Values     :  pxDecodedMsg..pointer to encoded data structure
*  Output Values    :  pxLocalSdp...pointer to SDP info
*                      peEcode..pointer to error code if any
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_ResolveRtpAddress(IN x_IFX_SIPAPP_SdpInfo* pxLocalSdp,
                           OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetval = IFX_SIP_SUCCESS;
#if 0        
  x_IFX_SIP_DnsInfo* pxDnsInfo, *pxDnsInfo1;
  int32 i, iIdx = 0;
  *peEcode = IFX_SIP_NO_ERROR;

  /* If codec not locked then locate the codec to be locked */
  if (pxLocalSdp->nLockedCodecEntry == -1) {
    for (i = 1; i <= pxLocalSdp->ucNumRemCap; i++) {
      eRetval =
        IFX_SIPAPP_CheckifSupportedGetIndex(pxLocalSdp->xRemCap[i]. uiRmCodec,
                                          pxLocalSdp, &iIdx);
      if (eRetval != IFX_SIP_SUCCESS) {
        i++;
        continue;
      }
      pxLocalSdp->nLockedCodecEntry = i;
      break;
    }
    if (i > pxLocalSdp->ucNumRemCap) {
      return IFX_SIP_FAILURE;
    }
  }

  /* Check if RTP address is a domain name */
  if (IFX_SIP_IdentifyType(pxLocalSdp->
      xRemCap[pxLocalSdp->nLockedCodecEntry].cRTPAddr) == IFX_SIP_HOSTNAME){
    pxDnsInfo = malloc(sizeof(x_IFX_SIP_DnsInfo));
    if (pxDnsInfo == NULL) {
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDnsInfo->cDomainName,
           pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
           cRTPAddr);
    pxDnsInfo->uiProtocol = UDP;
    pxDnsInfo->unPort =
      pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].unRTPPort;
    pxDnsInfo->eUriType = IFX_SIP_DNS_URI;
    pxDnsInfo->unTimeOutVal = 30; /* Only one RTP Connection address used */

    /* Get the Ip Address */
    eRetval = IFX_SIP_DnsCreateThread(pxDnsInfo);

    /* Get the Ip Address */
    if (eRetval == IFX_SIP_FAILURE) {
	  free(pxDnsInfo);
      return eRetval;
    }

    /* Do a DNS resolution */
    if (pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTP_INDEX] == NULL) {
      /* Malloc for the DNS Info */
      pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTP_INDEX] =
        malloc(sizeof(x_IFX_SIP_DnsDB));
      if (pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTP_INDEX] == NULL) {
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR,
                 IFX_DBG_MEM_ALLOC_ERR,
                 sizeof(x_IFX_SIP_DnsInfo));
		free(pxDnsInfo);
        return IFX_SIP_FAILURE;
      }
    }
    memset(pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTP_INDEX], 0, 
					sizeof(x_IFX_SIP_DnsDB));
    pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTP_INDEX]->iDnsId
      = eRetval;
    *peEcode = IFX_SIP_RTP_QUERY;
  }

  /* Resolve RTCP Address */
  if (pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].unRTCPPort != 0) {
    /* a=rtcp:  attribute present in SDP */
    if (strcmp(pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].cRTCPAddr,
         pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].cRTPAddr)) {
      /* RTCP attribute present and different from RTP address */
      if (IFX_SIP_IdentifyType(pxLocalSdp->xRemCap
                                [pxLocalSdp->nLockedCodecEntry].
                                cRTCPAddr) == IFX_SIP_HOSTNAME) {

        /* Resolve RTCP address if it is a domain name */
        pxDnsInfo1 = malloc(sizeof(x_IFX_SIP_DnsInfo));
        if (pxDnsInfo1 == NULL) {
          return IFX_SIP_FAILURE;
        }
        strcpy(pxDnsInfo1->cDomainName,
               pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
               cRTCPAddr);
        pxDnsInfo1->uiProtocol = UDP;
        pxDnsInfo1->unPort =
          pxLocalSdp->xRemCap[pxLocalSdp->nLockedCodecEntry].
          unRTCPPort;
        pxDnsInfo1->eUriType = IFX_SIP_DNS_URI;

        /* Only one RTP Connection address used */
        pxDnsInfo1->unTimeOutVal = 30;

        /* Get the Ip Address */
        eRetval = IFX_SIP_DnsCreateThread(pxDnsInfo1);

        /* Get the Ip Address */
        if (eRetval == IFX_SIP_FAILURE) {
		  free(pxDnsInfo1);
          return eRetval;
        }

        /* Do a DNS resolution */
        if (pxLocalSdp->xDns.
            pxDnsResolvDb[IFX_SIP_DNS_RTCP_INDEX] == NULL) {

          /* Malloc for the DNS Info */
          pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTCP_INDEX] =
            malloc(sizeof(x_IFX_SIP_DnsDB));
          if (pxLocalSdp->xDns.
              pxDnsResolvDb[IFX_SIP_DNS_RTCP_INDEX] == NULL) {
            IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR,
                     IFX_DBG_MEM_ALLOC_ERR,
                     sizeof(x_IFX_SIP_DnsInfo));
		    free(pxDnsInfo1);
            return IFX_SIP_FAILURE;
          }
        }
        memset(pxLocalSdp->xDns.pxDnsResolvDb
               [IFX_SIP_DNS_RTCP_INDEX], 0,
               sizeof(x_IFX_SIP_DnsDB));
        pxLocalSdp->xDns.pxDnsResolvDb[IFX_SIP_DNS_RTCP_INDEX]->
        iDnsId = eRetval;
        *peEcode = IFX_SIP_RTP_QUERY;
      }
    }
  }
#endif  
  return eRetval;
}



