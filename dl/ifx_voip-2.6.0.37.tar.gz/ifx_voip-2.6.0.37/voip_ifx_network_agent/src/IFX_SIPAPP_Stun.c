/**************************************************************************
 * FILE NAME       : IFX_SIPAPP_Stun.c
 * PROJECT         : SIP
 * MODULES         : Transaction User
 * SRC VERSION     : V2.0
 * DATE            : 08-05-2005
 * AUTHOR          : 
 * DESCRIPTION     : Function Prototypes
 * COMPILER        : gcc
 * REFERENCE       : Coding guide lines
 * COPYRIGHT       : Copyright (c) 2004
 *                   Infineon Technologies AG, st. Martin Strasse 53;
 *                   81669 Munchen, Germany
 * 
 * Any use of this software is subject to the conclusion of a respective
 * License agreement. Without such a License agreement no rights to the
 * software are granted
 *
 * Version Control Section  **
 * $Author$
 * $Date$
 * $Revisions$
 * $Log$       Revision history
 * ***********************************************************************/
#ifdef STUN_SUPPORT

#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sched.h>
#include <fcntl.h>
#include <pthread.h>
/*#define __USE_BSD*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#define __FAVOR_BSD
#include <netinet/udp.h>
#include <unistd.h>
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "ifx_ipc.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_DlgApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Config.h"
#include "ifx_list.h"
#include "IFX_SIPAPP_Stun.h"
#include "ifx_stun_api.h"

#ifdef IFX_CALLMGR
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#endif

#ifdef DMALLOC
#include <dmalloc.h>
#endif

EXTERN void IFX_SIP_SendRegisterReq();
EXTERN void IFX_SIPAPP_AddFDToSelect(IN int32 iSipSockFd,
                                     IN int32 iTypeofFDSet);

EXTERN void IFX_SIPAPP_RemoveFDToSelect(IN int32 iSipSockFd,
                                        IN int32 iTypeofFDSet);
EXTERN int32 viAppRdFd;
EXTERN uchar8 vcSipAppModId;
EXTERN int32 viStackMode;
x_IFX_SIPAPP_StunCallBack *vpxStunHeadPtr = NULL;

/* TODO: Put this in proper place*/
void IFX_SIPAPP_StackInitStatus(e_IFX_SIP_Return eStatus){
		
		return;
}

#define IFX_SIPAPP_MALLOC(x) calloc(1,x)
#define IFX_SIPAPP_FREE free

/*************************************************************************
*  Function Name:  IFX_STUN_WriteToSipFIFO
*  Description  :  This function writes to sip fifo
*  Input Values :  x_IFX_SIPAPP_STUN_FifoStr *pxStunfifo
*  Output Values:
*  Return Value :  void
***************************************************************************/
static void
IFX_STUN_WriteToSipFIFO(x_IFX_SIPAPP_STUN_FifoStr *pxStunfifo)
{
  char8 acHostIp[128];				
  IFX_SIPAPP_GetHostIp(acHostIp);
  if(IFX_SIPAPP_SendSockMsg(viAppRdFd, IFX_IPC_APP_ID_SIP,IFX_IPC_APP_ID_SIP,
                     sizeof(x_IFX_SIPAPP_STUN_FifoStr), IFX_IPC_SIPAPP_STUN,
                     (char8 *)pxStunfifo,acHostIp)== IFX_IPC_FAIL){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Write to FIFO failed");
      /* Return FAIL */
  }
  return ;
}

/**************************************************************************
*  Function Name: IFX_SIPAPP_GetMappedAddr
*  Description  : This function calls the STUN client API's to get the 
                  mapped address from the STUN server and write in to the 
                  SIP FIFO.
*  Input Values : x_IFX_SIPAPP_STUNInfo *pxSTUNInfo
*  Output Values:
*  Return Value :  void
***************************************************************************/
void IFX_SIPAPP_GetMappedAddr(x_IFX_SIPAPP_STUNInfo *pxSTUNInfo)
{
  int32 iLoop,iRetVal;
  uint32 uiTemp,uiIPAddr;
  uchar8 uacIPNoDot[4],uacIPAddr[IFX_SIPAPP_MAX_IPV4],uacTempPort[7];
  T_IFX_STUN_BINDING xStunBinding; 
  x_IFX_SIPAPP_STUN_FifoStr xStunfifo;
  memset(&xStunfifo,0,sizeof(x_IFX_SIPAPP_STUN_FifoStr)); 
 
  /* Copy the local IP address */
  /* Convert the IP string format to int */
  iRetVal=inet_pton(AF_INET,pxSTUNInfo->uacLocalIPAddr,&uiIPAddr);
  if(iRetVal <= 0){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
           "inet_pton fail");
    IFX_SIPAPP_FREE(pxSTUNInfo);
    return;
  }
#ifdef __BIG_ENDIAN
  xStunBinding.iSrcIP=htonl(uiIPAddr);
#else
  xStunBinding.iSrcIP=uiIPAddr;
#endif
  /*Copy the Channel Number,threadid and Number of ports in to FIFO struct*/
  xStunfifo.iSTUNId=pthread_self();
  xStunfifo.ucNumofPorts=pxSTUNInfo->ucNumofPorts;
 
  /* First Copy the Local Ports in to FIFO Struct */ 
  for(iLoop=0;((iLoop<pxSTUNInfo->ucNumofPorts)&&
				(iLoop<IFX_SIPAPP_MAX_PORTS));iLoop++){
    xStunfifo.unMappedPorts[iLoop][0]= pxSTUNInfo->unLocalPort[iLoop];
  }
  
  for(iLoop=0;((iLoop<pxSTUNInfo->ucNumofPorts)&&
				(iLoop<IFX_SIPAPP_MAX_PORTS));iLoop++)
  {
    /* Copy the Source port in to STUN struct */
    xStunBinding.iSrcPort=pxSTUNInfo->unLocalPort[iLoop];
    /* Add : and port num to it */
    sprintf(uacTempPort,":%d",pxSTUNInfo->unStunServPort);
    strcat(pxSTUNInfo->uacSTUNServerAddr,uacTempPort); 
    
    /* If NAT type not detected call this API */
    if(pxSTUNInfo->iNATType == IFX_SIPAPP_NAT_NOT_DETECTED)
    {
      xStunfifo.iNATType=IFX_STUN_NAT_Detect(pxSTUNInfo->uacSTUNServerAddr,
                                             NULL,&xStunBinding,0);
	  /* We are not taking any action if the NAT does not
	   *  supports hairpining of media  So reset  the HAIRPIN */
      xStunfifo.iNATType &=~IFX_STUN_TYPE_HAIRPIN;
	  
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
               xStunfifo.iNATType, "RetVal of IFX_STUN_NAT_Detect");

      if( (xStunfifo.iNATType == IFX_STUN_TYPE_FIREWALL) ||
          (xStunfifo.iNATType == IFX_STUN_TYPE_OPEN) ||
          (xStunfifo.iNATType == IFX_STUN_TYPE_UNKNOWN) ||
          (xStunfifo.iNATType == IFX_STUN_TYPE_BLOCK) ||
          (xStunfifo.iNATType == IFX_STUN_TYPE_SYMMETRIC)
        )
      {  
        xStunfifo.ucStunStatus=IFX_SIP_FAILURE;
        break;
      }
      else
      {
        /* Copy the Source port along with the mapped port and IP Address in 
         * FIFO struct
         */
        /* Convert IP Address from int format to string format */  
        uiTemp=xStunBinding.iMappedIP;
        uacIPNoDot[3]=(uiTemp & 0x000000ff);
        uacIPNoDot[2]=(uiTemp & 0x0000ff00) >> 8;
        uacIPNoDot[1]=(uiTemp & 0x00ff0000) >> 16;
        uacIPNoDot[0]=(uiTemp & 0xff000000) >> 24;
        sprintf((char*)uacIPAddr,"%d.%d.%d.%d",uacIPNoDot[0],
                uacIPNoDot[1],uacIPNoDot[2],uacIPNoDot[3]);
        strcpy((char*)xStunfifo.uacMappedIPAddr,(char*)uacIPAddr);
        xStunfifo.ucStunStatus=IFX_SIP_SUCCESS;
        xStunfifo.unMappedPorts[iLoop][1]= xStunBinding.iMappedPort;
      }           
    }
    else
    {
      /*
      If in case of NAT Detected directly call the
      the STUN API to get the bindings
      */
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Calling IFX_STUN_NAT_Detect");  
      /* Changed according to new stun library RAMU*/
      /* Copy here because After this Function the STUN Client should not 
       * change this NAT type */
      xStunfifo.iNATType=pxSTUNInfo->iNATType; 
      
      IFX_STUN_NAT_Detect(pxSTUNInfo->uacSTUNServerAddr,
                          NULL,&xStunBinding,0x02);
      /*if(iRetVal == 0)*/
      {
        /*Since this Function will not return NAT Type 
         * Copy the NAT type which received from SIP */
        /*xStunfifo.iNATType=pxSTUNInfo->iNATType; */

        /* Convert IP Address from int format to string format */  
        uiTemp=xStunBinding.iMappedIP;
        uacIPNoDot[3]=(uiTemp & 0x000000ff);
        uacIPNoDot[2]=(uiTemp & 0x0000ff00) >> 8;
        uacIPNoDot[1]=(uiTemp & 0x00ff0000) >> 16;
        uacIPNoDot[0]=(uiTemp & 0xff000000) >> 24;
        sprintf((char*)uacIPAddr,"%d.%d.%d.%d",uacIPNoDot[0],uacIPNoDot[1],
                uacIPNoDot[2],uacIPNoDot[3]);
        strcpy((char*)xStunfifo.uacMappedIPAddr,(char*)uacIPAddr);
        xStunfifo.ucStunStatus=IFX_SIP_SUCCESS;
        xStunfifo.unMappedPorts[iLoop][1]= xStunBinding.iMappedPort;
      }
      /*else
      {
        xStunfifo.cSTUNResponse=IFX_SIP_FAILURE;
        break;
      }
      */      
    }
  }
  /* Write into the SIP FIFO */
  
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Got Mapped Address and response");  
  /* 
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
           xStunfifo.cSTUNResponse,xStunfifo.uacMappedIPAddr); 
  */	   
  IFX_STUN_WriteToSipFIFO(&xStunfifo);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Sent STUN status to SIP"); 
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Exiting from STUN thread"); 
  IFX_SIPAPP_FREE(pxSTUNInfo);
  return;
}
/*************************************************************************
*  Function Name:  IFX_SIP_AddStunCallBack
*  Description  :  API to Registrar a call back function for a known Stun Node
*  Input Values :  pxDnsData,call back func,callback param,size
*  Output Values:  None
*  Return Value :  IFX_SIP_SCUCCESS/IFX_SIP_FILURE
***************************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_StunAddCallBack(
            IN int32 iStunId,
            IN e_IFX_SIP_Return (*pfCallBackFunc) (void *,e_IFX_SIP_Return,
                                                   x_IFX_SIPAPP_STUN_FifoStr *),
            IN void *pxCallBackParam,
            IN uint16 unSize)
{
   x_IFX_SIPAPP_StunCallBack *pxCallBackptr;
   int32 uiErrorCode;
   
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Stun callback function");

   if ( unSize > IFX_SIPAPP_MAX_STUN_PARAM)
   {
      
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Stun callback param size is more than declared");
      
      return IFX_SIP_FAILURE;
   }
   else 
   {
      __ifx_list_add_front((void *)&vpxStunHeadPtr,
                           (void *)&pxCallBackptr,
                           sizeof(x_IFX_SIPAPP_StunCallBack),
                           &uiErrorCode);
			if(pxCallBackptr == NULL){
        return IFX_SIP_FAILURE;
			}
      pxCallBackptr->pfCallBackFunc = pfCallBackFunc;
      
      memcpy(&pxCallBackptr->acCallBackParam,
             pxCallBackParam,unSize);
      
      pxCallBackptr->iSTUNId = iStunId;
      
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Stun call back function registered and usagecount incremented");
      
      return IFX_SIP_SUCCESS;   
   }
   
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Stun invalid parameters");
   
   return IFX_SIP_FAILURE;
}
/*************************************************************************
*  Function Name:  IFX_SIP_nRemoveStunCallBack
*  Description  :  This function removes the call back function from the stun
*  Input Values :  Dns Data and Call back function
*  Output Values:   
*  Return Value :  IFX_SIP_SCUCCESS/IFX_SIP_FILURE
***************************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_RemoveStunCallBack(IN int32 iStunId)
{
  x_IFX_SIPAPP_StunCallBack *pxCallBackptr = vpxStunHeadPtr;
  while(pxCallBackptr != NULL)
  {
     if(pxCallBackptr->iSTUNId == iStunId)
     {
        __ifx_list_del((void *)&vpxStunHeadPtr,
                       (void *)pxCallBackptr);
          
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Stun call back list cleared");
           
        return IFX_SIP_SUCCESS;
    }
    __ifx_list_GetNext((void *)&pxCallBackptr);
  }
     
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Stun call back function not found");
     
  return IFX_SIP_FAILURE;
   
}


/**************************************************************************
*  Function Name: IFX_SIP_STUNProcess
*  Description  : This function creates STUN thread.
*  Input Values : x_IFX_SIPAPP_STUNInfo *pxSTUNInfo
*  Output Values:
*  Return Value :  void
***************************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_STUNCrtProcess(IN x_IFX_SIPAPP_STUNInfo *pxstuninfo,
                  IN e_IFX_SIP_Return (*pfCallBackFunc)(void *,e_IFX_SIP_Return,
                                       x_IFX_SIPAPP_STUN_FifoStr *),
                  IN uint16 unSize,
                  IN void *pCallBackParam,
                  OUT int32 *piStunID)
{
  int32 iRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_STUNInfo *pxSTUNTmpInfo;
  pthread_t iThreadId;
  pthread_attr_t xAttrib;

  pxSTUNTmpInfo= (x_IFX_SIPAPP_STUNInfo *)IFX_SIPAPP_MALLOC(sizeof 
                 (x_IFX_SIPAPP_STUNInfo));
  if(pxSTUNTmpInfo== NULL)
  {
    return IFX_SIP_FAILURE;
  }
  memcpy(pxSTUNTmpInfo,pxstuninfo,sizeof(x_IFX_SIPAPP_STUNInfo));
  iRetVal = pthread_attr_init(&xAttrib);
  iRetVal = pthread_attr_setdetachstate(&xAttrib, PTHREAD_CREATE_DETACHED);
  if((iRetVal =
     pthread_create(&iThreadId, &xAttrib, (void *)IFX_SIPAPP_GetMappedAddr,
                       pxSTUNTmpInfo)) != 0) 
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Creating STUN thread failed");
    return IFX_SIP_FAILURE;
  }
  *piStunID = iThreadId;
  iRetVal = IFX_SIPAPP_StunAddCallBack(iThreadId,pfCallBackFunc,
                                     pCallBackParam, unSize);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Stun Thread created");
  
  return iRetVal;
}

/***********************************************************************
 * Function Name : IFX_SIP_SendSTUNToCM
 * Description   : This is the send the Set Req of STUN to CM
 * Input Values  : None
 * Output Values : None
 * Return Values : IFX_SIP_SUCCESS/IFX_SIP_FAILURE
 * ************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SendSTUNToCM()
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;

  /*IFX_CM_SetCfgData(0,IFX_CM_SIP_CFG_STUN,&xStunCfg);*/
  return eRetVal;
}

/***********************************************************************
 * Function Name : IFX_SIPAPP_SendNATKeepAlivePacket
 * Description   : This is the send NAT Keep alive packets using RAW socket
 * Input Values  : 
 * Output Values : None
 * Return Values : IFX_SIP_SUCCESS/IFX_SIP_FAILURE
************************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_SendNATKeepAlivePacket(uchar8 *pucDestIp,
                                uchar8 *pucSrcIp, 
                                uint16  unDestPort,
                                uint16  unSrcPort) 
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  static int32 iSockfd, iOn=1,iFlag;
  static char8 acPayload[] = "0xFF"; 
  static char8 acMsg[sizeof(struct ip)+sizeof(struct udphdr)+sizeof(acPayload)];
  struct ip *pxIP;         
  struct udphdr *pxUDP;
  struct sockaddr_in xSock;

  /* Mark the Start of IP and UDP headers */
  pxIP = (struct ip *)acMsg;
  pxUDP = (struct udphdr *) (sizeof(struct ip) + acMsg);
  
  if(iFlag == 0){
    /* Clear the IP information */		
    memset((char *)pxIP, '\0', sizeof(struct ip));
    /* Copy the Payload */
    strcat((acMsg+sizeof(struct udphdr)+sizeof(struct ip)), acPayload);
    /* Create a raw socket */	
    iSockfd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    /* Set the IP header include option */	
    if((setsockopt(iSockfd, IPPROTO_IP, IP_HDRINCL, &iOn, sizeof(iOn)) == -1)){
      return -1;
    }
    /* Fill the IP header */
   pxIP->ip_hl = 5;
	 pxIP->ip_v = 4;	
	 pxIP->ip_tos = 0;
	 pxIP->ip_len = sizeof(struct ip)+sizeof(struct udphdr)+sizeof(acPayload);
	 pxIP->ip_id = htonl(1234);
	 pxIP->ip_off = 0;
	 pxIP->ip_ttl = 255;
	 pxIP->ip_p = 17;
	 pxIP->ip_sum = 0;

    iFlag = 1;
  }

  /* Fill the destination address and port */	
  xSock.sin_family = AF_INET;
  xSock.sin_port = htons(unDestPort);
  xSock.sin_addr.s_addr = inet_addr(pucDestIp);
	
  /* Fill the IP source and destination */
  pxIP->ip_src.s_addr = inet_addr (pucSrcIp);
  pxIP->ip_dst.s_addr = inet_addr(pucDestIp);
	
  /* Fill the UDP header */	
  pxUDP->uh_sport = htons(unSrcPort);
  pxUDP->uh_dport = htons(unDestPort);
  pxUDP->uh_ulen = htons(0x0007);
  pxUDP->uh_sum = 0;				
	
  if(sendto(iSockfd, acMsg, sizeof(acMsg), 0,(struct sockaddr *)&xSock,
     sizeof(xSock)) != sizeof(acMsg)){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Could not send keepalive packet from:");
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
             unSrcPort, pucSrcIp);
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "To:");
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
             unDestPort, pucDestIp);
    return -1;
  }
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Sent keepalive packet from:");
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
           unSrcPort, pucSrcIp);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "To:");
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
           unDestPort, pucDestIp);
  return eRetVal;
}
/***********************************************************************
 * Function Name : IFX_SIPAPP_NATSignalTimeout
 * Description   : This is the function called to handle NAT Keep alive
 *                 timeout
 * Input Values  : Channel Number
 * Output Values : IFX_SIP_SUCCESS or IFX_SIP_FAILURE
* ************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NATSignalTimeout(uint32 uiCfgInst)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eCode;
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
          "IFX_SIPAPP_NATSignalTimeout Called");
  
  /* Send NAT Keep Alive packet to the STUN Server using RAW socker */
  IFX_SIPAPP_SendNATKeepAlivePacket(vpxSrvPdrData[uiCfgInst].xSipAppCfg.acStunAddr,
                                 vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.acIPAddr,
                                 vpxSrvPdrData[uiCfgInst].xSipAppCfg.unStunPort,
                                 vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.unServerPort);
  /* Start the Timer Again */
  IFX_SIPAPP_StartTimer(IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiCfgInst) * 1000,
                      (void*)IFX_SIPAPP_NATSignalTimeout,(void*)uiCfgInst,
                      &vpxSrvPdrData[uiCfgInst].unNATKASignalId, 
                      &eCode);
  return (eRetVal);
}
/***********************************************************************
 * Function Name : IFX_SIPAPP_NATRTPPortTimeout
 * Description   : This is the function called to handle NAT Keep alive
 *                 timeout
 * Input Values  : pxAppData - pointer to the Endpt Information Database 
 * Output Values : IFX_SIP_SUCCESS or IFX_SIP_FAILURE
* ************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NATRTPPortTimeout(IN x_IFX_SIPAPP_UAAppData* pxAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eCode;
  uint16 unTempPort = 0;
  uint32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);
  uchar8 uacLocalIP[IFX_SIPAPP_MAX_IPV4];
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "IFX_SIPAPP_NATRTPPortTimeout Called \n");
  if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
    strcpy(uacLocalIP,vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.acIPAddr);
    /* Send NAT Keep Alive packet to the Peer using RAW socker */
    IFX_SIPAPP_SendNATKeepAlivePacket(pxAppData->xSdpInfo.
                    xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].cRTPAddr, uacLocalIP,
                pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].unRTPPort, 
                pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort);
    /* For RTCP */
    unTempPort = pxAppData->xSdpInfo.
			     xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].unRTCPPort;
    if(unTempPort == 0){
      unTempPort = pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].
                     unRTPPort + 1;
    }  
    if(pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].
					cRTCPAddr[0] == '\0'){
      IFX_SIPAPP_SendNATKeepAlivePacket(pxAppData->xSdpInfo.
                      xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].cRTPAddr, uacLocalIP, unTempPort, 
              pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort + 1);
    }
    else{
      IFX_SIPAPP_SendNATKeepAlivePacket(pxAppData->xSdpInfo.
                      xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].cRTCPAddr, uacLocalIP, unTempPort, 
           pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort + 1);
    }
    /*Start the Timer Again */
    IFX_SIPAPP_StartTimer(IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiCfgInst)* 1000,
                       (void*)IFX_SIPAPP_NATRTPPortTimeout,(void*)pxAppData,
                       &pxAppData->xSdpInfo.xRtpInfo.unNATKARTPPortId, &eCode);
  }
  return (eRetVal);
}
/***********************************************************************
 * Function Name : IFX_SIPAPP_NATFAXPortTimeout
 * Description   : This is the function called to handle NAT Keep alive
 *                 timeout
 * Input Values  : pxAppData - pointer to the Endpt Information Database 
 * Output Values : IFX_SIP_SUCCESS or IFX_SIP_FAILURE
* ************************************************************************/

#ifdef FAX_SUPPORT
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_NATFAXPortTimeout(IN x_IFX_SIPAPP_UAAppData* pxAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eCode;
  uint32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);
  uchar8 uacLocalIP[IFX_SIPAPP_MAX_IPV4];
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "IFX_SIP_NATRTPFAXTimeout Called \n");
  if(pxAppData->xSdpInfo.xRemCap[0].uiRmCodec == IFX_T38_UDP ||
     pxAppData->xSdpInfo.xRemCap[0].uiRmCodec == IFX_T38_TCP)
  {
    strcpy(uacLocalIP,vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.acIPAddr);
    /* Send NAT Keep Alive packet to the Peer using RAW socker */
    IFX_SIPAPP_SendNATKeepAlivePacket(pxAppData->xSdpInfo.xRemCap
                [pxAppData->xSdpInfo.nLockedCodecEntry].cRTPAddr, uacLocalIP,
                pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].
                unRTPPort,pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort);
    /*Start the Timer Again */
    IFX_SIPAPP_StartTimer(IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiCfgInst)* 1000,
                       (void*)IFX_SIPAPP_NATRTPPortTimeout,(void*)pxAppData,
                       &pxAppData->xSdpInfo.xRtpInfo.unNATKAFAXPortId,&eCode);
  }
  return (eRetVal);
}
#endif
 
/***********************************************************************
 * Function Name : IFX_SIP_STUN_RespHandler
 * Description   : This is the function called when there is Response form STUN
 * Input Values  : x_IFX_SIPAPP_STUN_FifoStr *
 * Output Values : None
 * Return Values : IFX_SIP_SUCCESS/IFX_SIP_FAILURE
 * ************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_STUN_RespHandler(x_IFX_SIPAPP_STUN_FifoStr *pxSTUNFifo)
{
  x_IFX_SIPAPP_StunCallBack *pxCallBk = vpxStunHeadPtr;
  
  /* TODO Store the NAT Type given by the STUN Server */
  IFX_SIPAPP_GET_NATTYPE(0) = pxSTUNFifo->iNATType;

   #ifdef IFX_CALLMGR
  x_IFX_VMAPI_VoiceProfile xVoiceProfile={{{"\0"}}};
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
          "Updating NAT type in VMAPI");
  xVoiceProfile.ucProfileId = pxSTUNFifo->iSrvPrdInst;
  ifx_get_VoiceProfile(&xVoiceProfile,IFX_F_DEFAULT);
	xVoiceProfile.xStunConfig.iNatType = pxSTUNFifo->iNATType;
  ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProfile,IFX_F_DEFAULT);
 #endif
	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
           pxSTUNFifo->iSTUNId, "Recvd response from stun Msg from stun");
  
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
           pxSTUNFifo->iNATType, "NAT type");

  while (pxCallBk != NULL)
  {
      if (pxCallBk->iSTUNId == pxSTUNFifo->iSTUNId)
      {
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Stun calling the call back function");
         
         pxCallBk->pfCallBackFunc(pxCallBk->acCallBackParam,
                                  pxSTUNFifo->ucStunStatus,pxSTUNFifo);

        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Stun removed the call back from the list");
        
        __ifx_list_del((void *)&vpxStunHeadPtr,
                      (void *)pxCallBk); 
        
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Stun called all call backs successfully");

        return IFX_SIP_SUCCESS;

      }

      __ifx_list_GetNext((void *)&pxCallBk);
  }
  return IFX_SIP_FAILURE; 
}

/***********************************************************************
 * Function Name : IFX_SIP_STUNServerPort
 * Description   : This is the function called when there is Response form STUN
 *                 Client is received
 * Input Values  : x_IFX_SIPAPP_UAAppData
 *                 x_IFX_SIPAPP_STUN_FifoStr *
 *                 e_IFX_SIP_Return
 *                  
 * Output Values : None
 * Return Values : IFX_SIP_SUCCESS/IFX_SIP_FAILURE
 * ************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_STUNServerPortRsp(void *pxEpInfo,
                          e_IFX_SIP_Return eStatus,
                          x_IFX_SIPAPP_STUN_FifoStr *pxSTUNFifo)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eCode;
  int32 i;
  uint32 uiSrvPrd = *((uint32 *)pxEpInfo);
  x_IFX_SIP_SyncCallBks	xSyncCallbks;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Rsp from STUN - Stack initialization\n"); 
  IFX_SIP_StackConfig(vpxSrvPdrData[uiSrvPrd].uiStackHdl,
	               &vpxSrvPdrData[uiSrvPrd].xSipAppCfg.xParamCfg);

  if(eStatus == IFX_SIP_SUCCESS){
    /* Copy the mapped addr and port */
    strcpy(vpxSrvPdrData[uiSrvPrd].acMappedAddr,
          pxSTUNFifo->uacMappedIPAddr);
    for(i=0;i<pxSTUNFifo->ucNumofPorts;i++){
      if(IFX_SIPAPP_GET_SERVERPORT(uiSrvPrd)== 
         pxSTUNFifo->unMappedPorts[i][0]){
         vpxSrvPdrData[uiSrvPrd].unSIPMappedPort = 
                        pxSTUNFifo->unMappedPorts[i][1];
      }
    }
  }  
  else {
    /* Post a message to the Phone application stating init success */
    return IFX_SIP_FAILURE;
  }

  /* Init the Stack in Async Mode */
  if(viStackMode == IFX_SIP_ASYNC_MODE ){					
    if(IFX_SIP_Init(vpxSrvPdrData[uiSrvPrd].uiStackHdl,IFX_SIPAPP_StackInitStatus) == IFX_SIP_FAILURE) {
      /* timer failed..critical...return */
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "Stack Init Failed");
      return 0;
    }
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Stack Init success");
  }
  /* Init the Stack in Sync Mode */
  else if( viStackMode == IFX_SIP_SYNC_MODE){
    memset(&xSyncCallbks,0,sizeof(x_IFX_SIP_SyncCallBks));
    xSyncCallbks.pfnAddFDToSelect = IFX_SIPAPP_AddFDToSelect;
    xSyncCallbks.pfnRemoveFDToSelect = IFX_SIPAPP_RemoveFDToSelect;
    if(IFX_SIP_Init_Sync(vpxSrvPdrData[uiSrvPrd].uiStackHdl,IFX_SIPAPP_StackInitStatus,&xSyncCallbks) ==
       IFX_SIP_FAILURE) {
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "Stack Init Failed");
      return 0;
    }
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Stack Init success");
  }
  /* Start Timer For for sending NAT keep Alive packet for 
   * Signalling binding
  */
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,
          IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiSrvPrd), "NAT Keepalive Timer");
  IFX_SIPAPP_StartTimer(IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiSrvPrd)* 1000,
                        (void*)IFX_SIPAPP_NATSignalTimeout,(void*)uiSrvPrd,
                        &vpxSrvPdrData[uiSrvPrd].unNATKASignalId,
                        &eCode);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "<SIP-TUMain> Stack Init success");
  return eRetVal;
}
#endif
