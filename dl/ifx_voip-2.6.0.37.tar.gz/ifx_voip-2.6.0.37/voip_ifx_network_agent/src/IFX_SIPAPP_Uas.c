/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Uas.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : Narendra VP
**   DESCRIPTION   : This file contains the transaction user server functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS ,  DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#include "ifx_common_defs.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIPAPP_Platform.h"

#include "IFX_SDP_GetSet.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "ifx_debug.h"

#include "IFX_SDP_GetSet.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIP_DlgApi.h"

#include "IFX_SIPAPP_Transceiver.h"
#include "IFX_SIPAPP_Uas.h"
#include "IFX_SIPAPP_Uac.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_CCApi.h"
#include "IFX_SIPAPP_CallIf.h"
#include "ifx_list.h"

#include "IFX_SIPAPP_Config.h"
#ifdef STUN_SUPPORT
#include "ifx_stun_api.h"
#include "IFX_SIPAPP_Stun.h"
#endif
#ifdef DMALLOC
#include <dmalloc.h>
#endif
#ifdef RFC_3262
#include "IFX_SIPAPP_PRACK.h"
#endif


#ifdef INFO_SUPPORT
#include "IFX_SIPAPP_Info.h"
#endif
extern uchar8 vcSipAppModId;
IFX_SIPAPP_HandleRequests pfnHandleSpecMsg[] =
  {
    IFX_SIPAPP_HandleInvite, 
    IFX_SIPAPP_HandleAck, 
    IFX_SIPAPP_HandleBye, 
    IFX_SIPAPP_HandleCancel,
#ifdef RFC_3262
    IFX_SIPAPP_HandlePrack,
#endif
#ifdef RFC_3311
    IFX_SIPAPP_HandleUpdate,
#endif
#ifdef INFO_SUPPORT
    IFX_SIPAPP_HandleInfo
#endif    
  };

IFX_SIPAPP_SpecRespConst pfnSpecRespConst[] =
  {
    IFX_SIPAPP_1XXConst, IFX_SIPAPP_2XXConst, IFX_SIPAPP_3XXConst,
    IFX_SIPAPP_4XXConst, IFX_SIPAPP_5XXConst, IFX_SIPAPP_6XXConst};


/***********************************************************************
* Function Name : IFX_SIP_AddReplacesConnId
* Description   : This is the function called when there is an incoming 
*                 INVITE for an endpoint deemed to be in the trying 
*                 state by the SIP TU.It returns a success or failure.
* Input Values  : pxAppData - pointer to the Endpt Information Database 
*                 pSipMessage - pointer to the Decoded Data Structure
* Output Values : None
************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AddReplacesConnId(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                          IN uint32 uiMsgHdl,
                          OUT int32 *piReplacesConnId)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  char8 *pcCallId=NULL, *pcTo=NULL,*pcFrom=NULL;
  uint32 uiHdrHdl,uiDlgHeadHdl,uiDlgHdl;
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  x_IFX_SIPAPP_UAAppData* pxTmp = vxAppDataPool.pxAppDataHead;
  *piReplacesConnId = 0;
  /* Locate the AppData and Get the Connection ID */
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_REPLACES,1,&uiHdrHdl);
  if(eRetVal != IFX_SIP_FAILURE){
    pcCallId = IFX_SIP_Replaces_GetCallId(uiHdrHdl);
    pcTo = IFX_SIP_Replaces_GetTagParam(uiHdrHdl,"From-Tag");
    pcFrom = IFX_SIP_Replaces_GetTagParam(uiHdrHdl,"To-Tag");
  }
  if(pcCallId && pcTo && pcFrom){
    while(pxTmp != NULL){
      if(pxTmp->auiHdl[IFX_SIPAPP_UA_CALL] != 0){
        eRetVal = IFX_SIP_CC_GetDialogHead(pxTmp->auiHdl[IFX_SIPAPP_UA_CALL],
                                           &uiDlgHeadHdl);
        if(eRetVal != IFX_SIP_SUCCESS){
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "Dialog head is null");
          __ifx_list_GetNext((void *)&pxTmp); 
          continue;
        }
        eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                                     &uiDlgHdl, &eEcode);
        if(eRetVal != IFX_SIP_SUCCESS){
          IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "No Confirmed dialog");
          __ifx_list_GetNext((void *)&pxTmp); 
          continue;
        }
        if((strcmp(pcCallId,IFX_SIP_DLG_GetCallId(uiDlgHdl)) == 0)&&
           (strcmp(pcTo,IFX_SIP_DLG_GetToTag(uiDlgHdl)) == 0)&&
           (strcmp(pcFrom,IFX_SIP_DLG_GetFromTag(uiDlgHdl)) == 0)){
          *piReplacesConnId = pxTmp->iConnId;
          break;
        }
      }
      __ifx_list_GetNext((void *)&pxTmp); 
    }
    if(pxTmp == NULL){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "AppData is NULL");
      return IFX_SIP_FAILURE;
    }    
  }
  return IFX_SIP_SUCCESS;
}
#ifdef DARE_CUST
/******************************************************************
*  Function Name  : IFX_SIPAPP_GetDiversionHdrValue
*  Description    : 
*  Input Values   : 
*           	    
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_Return
IFX_SIPAPP_GetDiversionHdrValue (IN uint32 uiMsgHdl,
																 OUT x_IFX_SIPAPP_UAAppData *pxAppData)
{
	uint32 uiHdrHdl = 0;
	e_IFX_Return eRet;
	memset (pxAppData->acDiversion,'\0',sizeof(pxAppData->acDiversion));
	eRet = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_DIVERSION,1,&uiHdrHdl);
	if(uiHdrHdl){
		IFX_SIP_Diversion_GetValue(uiHdrHdl,pxAppData->acDiversion);
  	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Found");
	}
	return eRet;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_GetHistoryInfoHdrValue
*  Description    : 
*  Input Values   : 
*           	    
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_Return
IFX_SIPAPP_GetHistoryInfoHdrValue (IN uint32 uiMsgHdl,
                                 OUT x_IFX_SIPAPP_UAAppData *pxAppData)
{
	uint32 uiHdrHdl;
  char8 *pcHdrValue = NULL;
	e_IFX_Return eRet;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Entry");
	memset (pxAppData->acHistory,'\0',sizeof(pxAppData->acHistory));
  eRet = IFX_SIP_GetHeaderByName(uiMsgHdl,"History-Info",1,&uiHdrHdl);
	if(uiHdrHdl){
    pcHdrValue = IFX_SIP_Extension_GetHdrValue(uiHdrHdl);
    if (pcHdrValue){
      strcpy(pxAppData->acHistory,pcHdrValue);
  		IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Found");
    }
  }
	return eRet;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_SetHistoryInfoVal
*  Description    : 
*  Input Values   : 
*           	    
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_Return
IFX_SIPAPP_SetHistoryInfoVal(IN uint32 uiMsgHdl,
														IN char8* pcHdrValue )
{
  uint32 uiHdrHdl;
	e_IFX_Return eRet;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Entry");
  eRet = IFX_SIP_SetHeaderByName(uiMsgHdl,"History-Info",&uiHdrHdl);
	if(uiHdrHdl){
    IFX_SIP_Extension_SetHdrValue(uiHdrHdl,pcHdrValue);
  }
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Exit");
	return eRet;
}
#endif
/******************************************************************
*  Function Name  : IFX_SIP_HandleInvite
*  Description    : This function processes the invite request
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleInvite(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                     IN uint32 uiMsgHdl,
                     OUT e_IFX_SIP_Ecode* peEcode)
{

  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
#ifdef RFC_4028
  int32 iSessTimer=0;
  uint32 uiMinse=0;
  e_IFX_SIP_CC_RefPrefType eRefPref=IFX_SIP_REFRESH_UAC;
#endif
  uint32 uiHdrHdl=0;
  char8 *pcHdr=NULL;
  int32 iInsideDlg=0;
  x_IFX_SIPAPP_IncomingCall xIncCall={{'\0'}};

  /* check for the to tag */
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_TO,1,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
  }
  pcHdr =IFX_SIP_To_GetTag(uiHdrHdl);
  if (pcHdr != NULL) {
    iInsideDlg = 1;
  }
 #ifdef RFC_3311
  /* set The Offer Recv Flag */
   pxAppData->iUpdateFlag |= IFX_SIPAPP_OFFER_RECV;
 #endif

  if(iInsideDlg == 1){
#ifdef RFC_4028
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SDP_NOCHANGE;
#endif
    /*  check whether the request is a mid dialog request..handling of this
     *  request follows 12.2.2 and 14 */
    eRetVal = IFX_SIPAPP_HandleReInvite(pxAppData,uiMsgHdl,peEcode);
    return eRetVal;
  }
  else {
#ifdef RFC_4028
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<HandleInvite>Before checking Session-Expires");
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_SE,1, &uiHdrHdl);
    if(eRetVal != IFX_SIP_FAILURE) {
      eRefPref = IFX_SIP_SE_GetRefresherParam(uiHdrHdl);
      if(eRefPref == 0){
        eRefPref = IFX_SIP_REFRESH_UAS;      
      }
      iSessTimer = IFX_SIP_SE_GetTime(uiHdrHdl);
      eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_MIN_SE,1, &uiHdrHdl);
      if(eRetVal != IFX_SIP_FAILURE){
        uiMinse = IFX_SIP_MIN_SE_GetTime(uiHdrHdl);
      }      
      /* Call the Stack API to set the session refresh params */
      IFX_SIP_CC_SetSessionRefreshParam(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                        iSessTimer,uiMinse,eRefPref);
    }
    
    if(IFX_SDP_GetHeaderByType(pxAppData->xSdpInfo.uiSdpMsgHdl,IFX_SDP_ORIGIN,
                                 1,&uiHdrHdl) == (e_IFX_SDP_Return) IFX_SIP_SUCCESS) {
      if(pxAppData->xSdpInfo.xRtpInfo.uiRemoteSessionVer == 
                      pxAppData->xSdpInfo.xRtpInfo.uiSessionVer){
        pxAppData->xSdpInfo.xRtpInfo.uiRemoteSessionVer = 
                     (uint32)IFX_SDP_Origin_GetSessionVersion(uiHdrHdl);
      }
    }
#endif /*RFC_4028*/

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<HandleInvite>Before checking SDP");

    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1,
                                      &uiHdrHdl);
    if (eRetVal != IFX_SIP_FAILURE) {
      pcHdr =IFX_SIP_ContType_GetMSubType(uiHdrHdl);
      if(!strcasecmp(pcHdr,"sdp")){
        /* If there is no m= line offer sdp in 200 */
        if(IFX_SDP_GetHeaderByType(pxAppData->xSdpInfo.uiSdpMsgHdl,IFX_SDP_MEDIA_DESC,
                                 1,&uiHdrHdl) == (e_IFX_SDP_Return) IFX_SIP_FAILURE) {
          pxAppData->xSdpInfo.eDir = IFX_SIPAPP_INACTIVE_DIR;
          pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;
        }
        else{
          IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<HandleInvite>Before Store SDP");
          /* check whether the offer is acceptable or not */
          eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,&pxAppData->xSdpInfo,peEcode);
          if(eRetVal == IFX_SIP_SUCCESS) {
            /* SDP answer needs to sent in the 2xx response */
            pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;
          }
          else {
            IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                     "<HandleInvite> Store SDP Failed");
            IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,488,
                                  "Not Acceptable Here");
            *peEcode = IFX_SIP_RESPONSE_SENT;
            return IFX_SIP_FAILURE; /* SDP not acceptable */
          }
        }
      }
    }
    else{
      if(IFX_SIP_GetMsgBody(uiMsgHdl) != NULL){
        IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,488,
                              "Not Acceptable Here");
        *peEcode = IFX_SIP_RESPONSE_SENT;
        return IFX_SIP_FAILURE; /* SDP not acceptable */
      }
      else{
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite> Invite without SDP");
      }
    }
    /* Inform the application */
    /* Copy the To address */
    IFX_SIPAPP_CopyToAddr(uiMsgHdl,&pxAppData->xFrom);

    /* Take the user from Req-Uri */
    uiHdrHdl = IFX_SIP_Request_GetAddrSpec(uiMsgHdl);
    uiHdrHdl =IFX_SIP_Addrspec_GetSipUri(uiHdrHdl);
    if((pcHdr =IFX_SIP_SipUri_GetUser(uiHdrHdl))!=NULL){
      strcpy(pxAppData->xFrom.acUserName,pcHdr);
    }
	/*Copy Private Data*/
    xIncCall.pvPrivateData = pxAppData;
    memcpy(&xIncCall.xUserCfg,&pxAppData->xFrom,
           sizeof(x_IFX_CalledAddr));

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<HandleInvite> Getting Expires hdr");

    /* Copy the expires header if present */
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_EXPIRES,1,
                                      &uiHdrHdl);
    if (eRetVal != IFX_SIP_FAILURE) {
      xIncCall.uiExpires  = IFX_SIP_Expires_GetValue(uiHdrHdl);
    }
  }

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<HandleInvite> before Copied Called Address");

  /* Copy Called Address */
  IFX_SIPAPP_CopyCalledAddr(uiMsgHdl,&(pxAppData->xTo));
  memcpy(&xIncCall.xCalledAddr,&(pxAppData->xTo),
          sizeof(x_IFX_CalledAddr));

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite> Copied Called Address");
  /* Check if the Replaces dialog Exists */
  eRetVal = IFX_SIPAPP_AddReplacesConnId(pxAppData,uiMsgHdl,&(xIncCall.iConnId2));
  if(eRetVal != IFX_SIP_SUCCESS){
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_SIP_PA_IF,
             eRetVal, "AddReplaces failed");
    return eRetVal;
  }
  /* Copy the codec list */
  xIncCall.iCodecList = pxAppData->xSdpInfo.iCodecList;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite>Added Codec list to PA msg");
#ifdef RFC_3262
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite> RFC 3262 supported");
  eRetVal = IFX_SIP_Response_IsReliable(uiMsgHdl);
  if(eRetVal == IFX_SIP_SUCCESS)
  {
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite>100RelTag Present");
   pxAppData->iFlag |= IFX_SIPAPP_PRACK_SUPPORT;
  }
#endif /*RFC_3262*/
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite> before issuing INCOMING signal to PA");
  /* Set the ring cmd issued flag to true */
  pxAppData->iFlag |= IFX_SIPAPP_ISSUE_RINGCMD_FLAG;
  pxAppData->iFlag |= IFX_SIPAPP_SEND_RESP;
#ifdef IFX_INTERCOM_SUPPORT
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_TO,1,&uiHdrHdl);
  pcHdr = NULL;
  pcHdr = IFX_SIP_ToFrom_GetGenericParam(uiHdrHdl, 1, "intercom");
  if (pcHdr && !strcmp(pcHdr, "true")) {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
             "<HandleInvite> incoming intercom call");
    xIncCall.xCalledAddr.ucIntercomCall = IFX_SIP_TRUE;
  }
#endif

#ifdef DARE_CUST 
	/*Get Diversion Header Value - As string*/
	IFX_SIPAPP_GetDiversionHdrValue(uiMsgHdl,pxAppData);
	IFX_SIPAPP_GetHistoryInfoHdrValue(uiMsgHdl,pxAppData);
#endif
  eRetVal = vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_INCOMINGCALL_SIGNAL,
                          &xIncCall);
  if(eRetVal != IFX_SIP_SUCCESS){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_SIP_PA_IF,
             eRetVal, "<TUEndptFSM> SIP_TO_PA return Fail");
    /* TODO: Clear the App data and the call handle */
  }
  return eRetVal;
}

/******************************************************************
*  Function Name  : IFX_SIP_HandleReInvite
*  Description    : this function handles invite request within
*         	    a confirmed dialog
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode...pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleReInvite(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                       IN uint32 uiMsgHdl,
                       OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiHdrHdl=0;
  char8 *pcHdr = NULL,*pcBody = NULL;
  int16 nEntry=0;
  int32 /*iCodecChanged=0,*/iModeChanged=0/*,iRTPAddrChange=0*/;
#ifdef RFC_4028
  uint32 uiMinse=0;
  int32 iSessTimer=0;
  e_IFX_SIP_CC_RefPrefType eRefPref=IFX_SIP_REFRESH_UAC;
  if(IFX_SDP_GetHeaderByType(pxAppData->xSdpInfo.uiSdpMsgHdl,IFX_SDP_ORIGIN,
                                 1,&uiHdrHdl) == (e_IFX_SDP_Return) IFX_SIP_FAILURE) {
       pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;
  }
  else{
      if(pxAppData->xSdpInfo.xRtpInfo.uiRemoteSessionVer == 
                         (uint32)IFX_SDP_Origin_GetSessionVersion(uiHdrHdl)){
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                "<HandleReInvite>Set the Flag for NOCHANGE in Session Version");
        /*Set the flag to indicate that there is no change in sdp version*/
        pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_NOCHANGE;
        /* Set the session refresh parameters appropriately */
        eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_SE,1, &uiHdrHdl);
        if(eRetVal != IFX_SIP_FAILURE) {
          eRefPref = IFX_SIP_SE_GetRefresherParam(uiHdrHdl);
          if(eRefPref == 0){
            eRefPref = IFX_SIP_REFRESH_UAS;      
          }
          iSessTimer = IFX_SIP_SE_GetTime(uiHdrHdl);
          eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_MIN_SE,1, &uiHdrHdl);
          if(eRetVal != IFX_SIP_FAILURE){
            uiMinse = IFX_SIP_MIN_SE_GetTime(uiHdrHdl);
          }      
          /* Call the Stack API to set the session refresh params */
          IFX_SIP_CC_SetSessionRefreshParam(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                            iSessTimer,uiMinse,eRefPref);
        }
	    /* Send a 200 response */
        eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
                                          200,"OK",0,"INVITE");	
      }
      else{
        pxAppData->xSdpInfo.xRtpInfo.uiRemoteSessionVer = 
                        (uint32) IFX_SDP_Origin_GetSessionVersion(uiHdrHdl);
      }
  }
#endif /*RFC_4028 */

    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1,
                                    &uiHdrHdl);
    if (eRetVal == IFX_SIP_FAILURE) {
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
    }
    pcHdr =IFX_SIP_ContType_GetMSubType(uiHdrHdl);

  /* check whether session description is there or not */
  pcBody = IFX_SIP_GetMsgBody(uiMsgHdl);
  if(!strcasecmp(pcHdr,"sdp")){
    /* check whether the offer is acceptable or not */
    eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl, &pxAppData->xSdpInfo, peEcode);
    if(eRetVal != IFX_SIP_SUCCESS){

      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "Store SDP Failed sending 488");
      /* send 488 response..sdp not acceptable */
      eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
		                488,"Not Acceptable",0,"INVITE");
      return IFX_SIP_FAILURE; 
    }
    /* SDP answer needs to sent in the 2xx response */
    pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;	
    /* Check for codec change */
    if(pxAppData->xSdpInfo.xRemCap[0].uiRmCodec !=
       pxAppData->xSdpInfo.xRemCap[1].uiRmCodec){
      /* Set Locked Codec Entry */
      IFX_SIPAPP_GetLockedCodecEntry(&nEntry,&pxAppData->xSdpInfo);
      pxAppData->xSdpInfo.nLockedCodecEntry = nEntry;
      if((nEntry != 1)&&(nEntry<IFX_MAX_CODECS)){
        if(pxAppData->xSdpInfo.xRemCap[0].uiRmCodec !=
           pxAppData->xSdpInfo.xRemCap[nEntry].uiRmCodec){
	       pxAppData->iRtpParamModified =1;
           //iCodecChanged = 1;
        }      
      }
      else{
	    pxAppData->iRtpParamModified =1;
        //iCodecChanged = 1;
      }      
    }
    else{
      nEntry = pxAppData->xSdpInfo.nLockedCodecEntry = 1;     
    }
    
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "Nlocked codec Entry set");
		if(nEntry>=IFX_MAX_CODECS){
      return IFX_SIP_FAILURE;      
		}
		
    /* Check if mode is changed */
    if(pxAppData->xSdpInfo.xRemCap[0].eMode !=
       pxAppData->xSdpInfo.xRemCap[nEntry].eMode){
       pxAppData->iRtpParamModified =1;
      iModeChanged = 1;      
    }
	if((strcmp(pxAppData->xSdpInfo.xRemCap[0].cRTPAddr, "0.0.0.0") 
        == 0)&& !(strcmp(pxAppData->xSdpInfo.xRemCap[nEntry].cRTPAddr, "0.0.0.0") 
        == 0)){
       pxAppData->iRtpParamModified =1;
      iModeChanged = 1;      
    }
		/* Check for connection address */
    if((strcmp(pxAppData->xSdpInfo.xRemCap[nEntry].cRTPAddr, "0.0.0.0") 
        == 0) || (strcmp(pxAppData->xSdpInfo.xRtpInfo.cRemoteRTPAddr, 
        "0.0.0.0") == 0)){
      iModeChanged = 1;
      pxAppData->xSdpInfo.xRemCap[nEntry].eMode = IFX_SDP_INACTIVE;
      pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_USE_CONNADDR_FORHOLD;
      pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_USE_IP_HOLD;
    }
    else{
      pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_USE_CONNADDR_FORHOLD;
      pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_USE_IP_HOLD;
    }
		/*Fix added by radvajesh to fix hold from both sides & there was no modeChanged set*/
    if((pxAppData->xSdpInfo.xRemCap[nEntry].eMode == IFX_SDP_INACTIVE)&&
			 (pxAppData->xSdpInfo.xRemCap[0].eMode == IFX_SDP_INACTIVE)){
				iModeChanged = 1;
		}
    /* Check for RTP connection address Change*/
    if(strcmp(pxAppData->xSdpInfo.xRemCap[0].cRTPAddr,pxAppData->xSdpInfo.
                            xRemCap[nEntry].cRTPAddr)){
       //iRTPAddrChange = 1;
    }

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "mode Address of remote set");
    if(iModeChanged){

      /* Murali Check */
      pxAppData->xSdpInfo.eLocalMode = IFX_SIPAPP_GetLocalMode(pxAppData->
                    xSdpInfo.eLocalMode,pxAppData->xSdpInfo.
                    xRemCap[nEntry].eMode);

      if((pxAppData->xSdpInfo.xRemCap[nEntry].eMode == IFX_SDP_INACTIVE)||
         (pxAppData->xSdpInfo.xRemCap[nEntry].eMode == IFX_SDP_SENDONLY)){
        /* Set Remote Hold Flag */
        pxAppData->iFlag |= IFX_SIPAPP_REMOTE_HOLD_FLAG;      
        /* Post a message to application */

        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		             "sending Remote Hold to Application");
        vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REMOTE_HOLD, 
                        pxAppData);
        return IFX_SIP_SUCCESS;      
      }
      else{      
        if( /*(pxAppData->iEndptFlag & IFX_SIPAPP_LOCAL_HOLD) ||*/ 
        	  (pxAppData->iFlag & IFX_SIPAPP_REMOTE_HOLD_FLAG)){
          /* This case put for polycom problem */		
          if(pxAppData->iFlag & IFX_SIPAPP_LOCAL_HOLD){
            pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SET_MODE;
	        }		  
          /* Reset Remote Hold Flag */
          pxAppData->iFlag &= ~IFX_SIPAPP_REMOTE_HOLD_FLAG;      
          /* Set Remote Resume flag */
          pxAppData->iFlag |= IFX_SIPAPP_REMOTE_RESUME_FLAG;      
          /* Post Remote resume to application */
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		             "sending Remote Resume to Application");
          vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REMOTE_RESUME, 
                          pxAppData);
          return IFX_SIP_SUCCESS;      
        }      
      }
    }

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "sending Media Update to application");
	  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MEDIA_UPDATE, 
                               pxAppData);
  }
  else if(pcBody == NULL){
    /* offer the sdp */
    eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
                        200,"OK",0,"INVITE");
  }
  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_HandleCancel
*  Description    : This function processes the cancel request
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleCancel(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                     IN uint32 uiMsgHdl,
                     OUT e_IFX_SIP_Ecode* peEcode)
{
  //e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  if(1/* TODO:Check if the call has been accepted already or not*/){	
    /* Msg to Encode response will take care of this */   
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_STOPTONE_SIGNAL,pxAppData);
    /*eRetVal =*/ IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,487,
		                   "Request Terminated");
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_HandleAck
*  Description    : This function processes the ack request
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleAck(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  IN uint32 uiMsgHdl,
                  OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;
  char8 *pcHdr=NULL,*pcBody=NULL;
#ifdef RFC_3262
  if(!(pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT))
	{
#endif					
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "ACK Handling in Application started\n");
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1,
                                    &uiHdrHdl);
  if (eRetVal != IFX_SIP_FAILURE) 
	{
    pcHdr =IFX_SIP_ContType_GetMSubType(uiHdrHdl);

    if(pxAppData->iFlag & IFX_SIPAPP_SDP_PRESENT)
		{
      if(strcasecmp(pcHdr,"sdp"))
			{
        /* Send Bye */
        IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,0,"BYE");
        /* Indicate to PA */
        vpxNotifier.pfStateNotifier(&pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                    IFX_RELEASE_SIGNAL,(void *)IFX_INTERNAL_ERR);
      }
    }
  }
  pcBody = IFX_SIP_GetMsgBody(uiMsgHdl);
  if((pcBody == NULL) &&
      (pxAppData->iFlag& IFX_SIPAPP_SDP_PRESENT)) 
	{
    pxAppData->iFlag &= ~IFX_SIPAPP_SDP_PRESENT;
    /*TODO:To be verified by murali*/

    /* Call RTP Handler */
    /* Mode would have changed because of remote Information
       so set the mode change flag */
    IFX_SIPAPP_GetLockedCodecEntry(&pxAppData->xSdpInfo.nLockedCodecEntry,
                                   &pxAppData->xSdpInfo);
    pxAppData->iRtpParamModified = 1;
		/* Fixed by radvajesh, since ack for hold was sending hold_success*/
		pxAppData->iFlag |= IFX_SIPAPP_ACK_RECIVED;
    IFX_SIPAPP_ModifyMedia(pxAppData);
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SET_MODE;

    return (IFX_SIP_SUCCESS);
  }
  else if((pcBody == NULL) ||
          ((pcHdr !=NULL)&&(strcasecmp(pcHdr,"sdp"))))
	{
    return IFX_SIP_FAILURE;
  }
  else 
	{
		if(IFX_SDP_FAILURE == IFX_SDP_CreateMsg(&pxAppData->xSdpInfo.uiSdpMsgHdl)) {
	    return IFX_SIP_FAILURE;
	  }
    eRetVal = IFX_SDP_DecodeMessage(pcBody,pcBody+strlen(pcBody),
									       pxAppData->xSdpInfo.uiSdpMsgHdl,peEcode);
	  if(eRetVal != IFX_SIP_SUCCESS)
		{
      IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
      return IFX_SIP_SUCCESS;
    }
		
    /* If we r here then other end is an obselete implementation */
    /* check whether the offer is acceptable or not */
    eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl, &pxAppData->xSdpInfo, peEcode);
    if(eRetVal != IFX_SIP_SUCCESS)
		{
      IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
      return IFX_SIP_SUCCESS;
    }
    pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;
    /* Post Modify Response to RTP */
    IFX_SIPAPP_GetLockedCodecEntry(&pxAppData->xSdpInfo.nLockedCodecEntry,
                                   &pxAppData->xSdpInfo);
    /* Call RTP Handler */
    /* Mode would have changed because of remote Information
       so set the mode change flag */
    pxAppData->iRtpParamModified =1;
    IFX_SIPAPP_ModifyMedia(pxAppData);
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SET_MODE;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_SDP_ANSWER,pxAppData);
  }
#ifdef RFC_3262					
	}
  else {
#endif	
	
    /* Call RTP Handler */
    /* Mode would have changed because of remote Information
       so set the mode change flag */
    IFX_SIPAPP_GetLockedCodecEntry(&pxAppData->xSdpInfo.nLockedCodecEntry,
                                   &pxAppData->xSdpInfo);
    pxAppData->iRtpParamModified = 1;
    IFX_SIPAPP_ModifyMedia(pxAppData);
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SET_MODE;
#ifdef RFC_3262					
	}
#endif	
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"ACK Handling in Application completed\n");
  return eRetVal;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_HandleBye
*  Description    : This function processes the bye request
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleBye(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  IN uint32 uiMsgHdl,
                  OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiCallIdBk=0; /* take callid backup if appdata reference count is more than 1*/
  int32 iCount=0;
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       "BYE Handling in Application started\n");
#ifdef FAX_SUPPORT
  if(pxAppData->xSdpInfo.iFlag & IFX_SIPAPP_FAX_SETUP)
  {
    pxAppData->iFlag &= ~IFX_SIPAPP_FAX_ORIGINATE;
    pxAppData->iFlag &= ~IFX_SIPAPP_FAX_TERMINATE;
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_FAX_SETUP;
  }
#endif
  /* Logic to store CallId if muliple modules still acessing appdata*/
  for (iCount=0; iCount<IFX_SIPAPP_UA_MAX_HDLS; iCount++) {
    if(pxAppData->auiHdl[iCount] != 0){
	  uiCallIdBk++;
    }
  }
  if(uiCallIdBk >1){
   uiCallIdBk = pxAppData->iConnId;
  }else{
   uiCallIdBk = 0;
  }
  
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL, (void *)IFX_TERMINATED);
  
  /* Restoring if more than one module accessing appdata*/
  if(uiCallIdBk >0){
    pxAppData->iConnId = uiCallIdBk;
  }
  
  eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,200,
                                    "OK",0,"BYE");
  if (eRetVal == IFX_SIP_FAILURE) {
    return eRetVal;
  }
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       "BYE Handling in Application completed\n");
  /* Close the RTP connection if it exists */
  if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
    pxAppData->iRtpParamModified = 0;
    pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
  }
  IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_CALL);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       "BYE Handling in Application completed2\n");
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIP_1XXConst
*  Description    : This function constructs the 1xx response
*  Input Values   : eRespType - Response Type
*                   uiDecMsgHdl - Decoded Message Handle
*                   uiEncMsgHdl - Encoded Message Handle
*                   pxAppData - User Agent application data
*                   peEcode - Error Code if any 
*  Output Values  : uiEncMsgHdl - Updated Encoded message handle
*                   peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_1XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                  IN uint32 uiEncMsgHdl,
                  IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  OUT e_IFX_SIP_Ecode* peEcode)
{
	int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiEncMsgHdl);
#ifdef DARE_CUST
	if((nStatusCode > 179 && nStatusCode < 190) && 
			'\0' != pxAppData->acDiversion[0]){
		uint32 uiHdrHdl = 0;
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Setting Diversion ");
		IFX_SIP_SetHeaderByType(uiEncMsgHdl,IFX_SIP_DIVERSION,&uiHdrHdl);
		if(uiHdrHdl) {
				IFX_SIP_Diversion_SetValue(uiHdrHdl,pxAppData->acDiversion);					
		}
	}

	if((nStatusCode > 179 && nStatusCode < 190) &&
			'\0' != pxAppData->acHistory[0]){
		 IFX_SIPAPP_SetHistoryInfoVal(uiEncMsgHdl,pxAppData->acHistory);
	}
#endif

	switch(nStatusCode){
	  case 180:
		  {
            char8 acFrom[IFX_SIPAPP_MAX_TOKEN];
           IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
           if(IFX_SIPAPP_SetContact(acFrom,uiEncMsgHdl,pxAppData->iProfileId) ==
              IFX_SIP_FAILURE) {
             *peEcode = IFX_SIP_TU_MEMORY_ERROR;
             //IFX_SIP_FreeMsg(uiEncMsgHdl);
             return IFX_SIP_FAILURE;
		   }
           return IFX_SIP_SUCCESS;
		 }
	  case 183:
	     {
       #ifdef RFC_3262
           e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
           char8 acFrom[IFX_SIPAPP_MAX_TOKEN];
           IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
           if(IFX_SIPAPP_SetContact(acFrom,uiEncMsgHdl,pxAppData->iProfileId) ==
              IFX_SIP_FAILURE) {
              *peEcode = IFX_SIP_TU_MEMORY_ERROR;
              //IFX_SIP_FreeMsg(uiEncMsgHdl);
              return IFX_SIP_FAILURE;
		   }
           if(pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT){
              IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       "<183Const> Calling 1xxRelConst");
              /* TODO(Chintan) Modify parameters */
              eRetVal = IFX_SIPAPP_1xxRelConst(uiEncMsgHdl,pxAppData,peEcode);
              if(eRetVal ==  IFX_SIP_FAILURE){
                 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                          "<183Const>Error in 1xxRelConst");
                 return IFX_SIP_FAILURE;
			  }
		   }
       #endif
           return IFX_SIP_SUCCESS;
	     }
	  default:
     return IFX_SIP_SUCCESS;
	}
}
#ifdef RFC_4028
/******************************************************************
*  Function Name  : IFX_SIPAPP_SetTimerTag
*  Description    : This function sets Require header filed with timer
*										tag - Only in case of Session Expires header is set
*										and refresher type is UAC
*  Input Values   : Message Handle
*                   
*  Notes          : 
*********************************************************************/
void
IFX_SIPAPP_SetTimerTag(uint32 uiMsgHdl)
{
  e_IFX_SIP_CC_RefPrefType eRefPref;
	e_IFX_Return eRetVal;
	uint32 uiHdrHdl;
	
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_SE,1, &uiHdrHdl);
  if(eRetVal != (e_IFX_Return) IFX_SIP_FAILURE) {
      eRefPref = IFX_SIP_SE_GetRefresherParam(uiHdrHdl);
      if(eRefPref == IFX_SIP_REFRESH_UAC){
				 uiHdrHdl = 0;
      	 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Setting Require");
				 
			   IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_REQUIRE,&uiHdrHdl);
    		IFX_SIP_SetOptionTag(uiHdrHdl,"timer");

      }
  }
  return;  
}
#endif
/******************************************************************
*  Function Name  : IFX_SIP_2XXConst
*  Description    : This function constructs the 2XX response
*  Input Values   : eRespType - Response Type
*                   uiDecMsgHdl - Decoded Message Handle
*                   uiEncMsgHdl - Encoded Message Handle
*                   pxAppData - User Agent application data
*                   peEcode - Error Code if any 
*  Output Values  : uiEncMsgHdl - Updated Encoded message handle
*                   peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_2XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiDlgHeadHdl =0, uiDlgHdl =0;
  e_IFX_SIP_Ecode eEcode;
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN];
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiEncMsgHdl);
  if(nStatusCode != 200){
	  return IFX_SIP_SUCCESS;
  }

  if(eRespType == IFX_SIP_INVITE) {
    /* should contain the allow header field */
    if (IFX_SIPAPP_SetAllow(uiEncMsgHdl) == IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "SET Allow Failed ");
      return IFX_SIP_FAILURE;
    }

    /* add content disposition header field */
    if (IFX_SIPAPP_SetContentDisposition(uiEncMsgHdl) == IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "SET Content Disposition Failed ");
      
      return IFX_SIP_FAILURE;
    }

    /* set content type */
    if (IFX_SIPAPP_SetContentType("application","sdp",uiEncMsgHdl) ==
        IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "SET Content type Failed ");
      return IFX_SIP_FAILURE;
    }

    /* add a contact header field */
    IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
    if(IFX_SIPAPP_SetContact(acFrom,uiEncMsgHdl,pxAppData->iProfileId) ==
        IFX_SIP_FAILURE) {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "SET Contact Failed ");
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
   
      return IFX_SIP_FAILURE;
    }
  
    /* Set the supported header */
    if(IFX_SIPAPP_SetSupported(uiEncMsgHdl)== IFX_SIP_FAILURE){
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "SET Supported Failed ");
      
      return IFX_SIP_FAILURE;
    }
    /* Get Confirmed dialog */
    eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                       &uiDlgHeadHdl);
    if(eRetVal != IFX_SIP_SUCCESS){  
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Dialog head is null");
      return eRetVal;
    } 
    eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                     &uiDlgHdl, &eEcode);
    if(eRetVal != IFX_SIP_SUCCESS){  
      pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_SESSIONVER;
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "No Confirmed dialog");
    }
    else
    {
       pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SDP_SESSIONVER;
#ifdef RFC_4028
		IFX_SIPAPP_SetTimerTag(uiEncMsgHdl);
#endif /*RFC_4028 */

    }
#ifdef RFC_3311
		/* Don't send SDP in following Cases
			- Early Dialog and Answer was sent in 200 of UPDATE*/
    if(!((pxAppData->iUpdateFlag & IFX_SIPAPP_UPDATE) && 
				(pxAppData->xSdpInfo.iFlag & IFX_SIPAPP_SDP_SESSIONVER)) ){
#endif
    if((pxAppData->iFlag & IFX_SIPAPP_SDP_PRESENT) &&
       (pxAppData->xSdpInfo.eDir == IFX_SIPAPP_SENDRECV)){
      /* 200 response shld carry the answer */
      if (IFX_SIPAPP_AnswerSdpInactive(uiEncMsgHdl,&pxAppData->xSdpInfo,peEcode) == 
            IFX_SIP_FAILURE) {
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "ANS SDP Failed ");
	      		  
        return IFX_SIP_FAILURE;
      }
    }
    else if(pxAppData->iFlag& IFX_SIPAPP_SDP_PRESENT){ 
      /* offer has to be made in the 2xx response */
      if(IFX_SIPAPP_AnswerSdpInactive(uiEncMsgHdl, 
         &pxAppData->xSdpInfo, peEcode) == IFX_SIP_FAILURE) {
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "ANS SDP INACTIVE Failed ");
       		  
        return IFX_SIP_FAILURE;
      }
    }
    else{
#ifdef RFC_3262
		/* if remote supports prack 183 shall contain offer otherwise offer here*/
		if(!(pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT)){
          /* construct SDP info */
          eRetVal = IFX_SIPAPP_OfferSdp(uiEncMsgHdl,&(pxAppData->xSdpInfo),
                                  peEcode);
          if (eRetVal == IFX_SIP_FAILURE) {
            IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "OFFER SDP  Failed ");
             return eRetVal;
		  }
		}
#endif		
	}
#ifdef RFC_3311
  }
   /* Clear Offer Recv Flag */
   pxAppData->iUpdateFlag &= ~IFX_SIPAPP_OFFER_RECV;
#endif
  }
#ifdef RFC_3262
  else if(eRespType == IFX_SIP_PRACK )
  {
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<200Const>Constructing 200 for PRACK");
    if(pxAppData->iFlag & IFX_SIPAPP_2XX_ANSWER)
    {
      /* 200 response shld carry the answer */
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<200ConstPRACK> PRACK constains offer - Answer in 200");
      if(IFX_SIPAPP_AnswerSdp(uiEncMsgHdl,&pxAppData->xSdpInfo,peEcode) ==
            IFX_SIP_FAILURE) {
            IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "ANS SDP  Failed ");
        //IFX_SIP_FreeMsg(uiEncMsgHdl);
        return IFX_SIP_FAILURE;
      }
    }
#ifdef RFC_3311
    /* clear Offer Recv Flag */
    pxAppData->iUpdateFlag &= ~IFX_SIPAPP_OFFER_RECV;
#endif
   }
#endif /*RFC_3262*/
#ifdef RFC_3311
  else if (eRespType == IFX_SIP_UPDATE){
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<SIPAPP>200Const UPDATE");

 /* should contain the allow header field */
    if (IFX_SIPAPP_SetAllow(uiEncMsgHdl) == IFX_SIP_FAILURE){
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "SET ALLOWED  Failed ");
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
    }

       /* add content disposition header field */
    if (IFX_SIPAPP_SetContentDisposition(uiEncMsgHdl) == IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "SET Content Disp  Failed ");
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
    }

    /* add a contact header field */
    IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
    if(IFX_SIPAPP_SetContact(acFrom,uiEncMsgHdl,pxAppData->iProfileId) ==
        IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "SET Contact  Failed ");
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
    }

    /* Set the supported header */
    if(IFX_SIPAPP_SetSupported(uiEncMsgHdl)== IFX_SIP_FAILURE){
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "SET Supported Failed ");
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
    }


     /* clear Offer Recv Flag */
     pxAppData->iUpdateFlag &= ~IFX_SIPAPP_OFFER_RECV;

    if((pxAppData->iUpdateFlag & IFX_SIPAPP_UPDATE_SDP_PRESENT)&&
       (pxAppData->xSdpInfo.eDir == IFX_SIPAPP_SENDRECV )){
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<200Const>UPDATE Carrying the Answer SDP");

     /*Set Flag for Successfull Update Completion */
     pxAppData->iUpdateFlag  |= IFX_SIPAPP_UPDATE;

      /* 200 response shld carry the answer */
     if(IFX_SIPAPP_AnswerSdp(uiEncMsgHdl,&pxAppData->xSdpInfo,peEcode) ==
        IFX_SIP_FAILURE) {
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "ANS SDP Failed ");
        //IFX_SIP_FreeMsg(uiEncMsgHdl);
        return IFX_SIP_FAILURE;
      }
       /* set content type */
     if (IFX_SIPAPP_SetContentType("application","sdp",uiEncMsgHdl) ==
        IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
    }
   }
#ifdef RFC_4028
	 IFX_SIPAPP_SetTimerTag(uiEncMsgHdl);
#endif /*RFC_4028*/
  }
#endif
  else if (eRespType == IFX_SIP_BYE) {}
  else if (eRespType == IFX_SIP_CANCEL) {}
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name  :  IFX_SIP_3XXConst
*  Description    : this function constructs the 3XX response
*  Input Values   : eRespType - Response Type
*                   uiDecMsgHdl - Decoded Message Handle
*                   uiEncMsgHdl - Encoded Message Handle
*                   pxAppData - User Agent application data
*                   peEcode - Error Code if any 
*  Output Values  : uiEncMsgHdl - Updated Encoded message handle
*                   peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_3XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  x_IFX_CalledAddr* pxCalledAddr;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;
  char8 acTo[256];
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiEncMsgHdl);
  if(nStatusCode != 302){
	  return IFX_SIP_SUCCESS;
  } 
  /* Format it as called address */
  pxCalledAddr = &pxAppData->xTo;

  /* set the bit */
  eRetVal = IFX_SIP_SetHeaderByType(uiEncMsgHdl,IFX_SIP_CONTACT,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
     //IFX_SIP_FreeMsg(uiEncMsgHdl);
     return eRetVal;
  }

  uiHdrHdl = IFX_SIP_Contact_GetAddressType(uiHdrHdl);
  IFX_SIPAPP_ConvCalAddrToStr(pxCalledAddr,acTo);
  eRetVal = IFX_SIP_AddrType_SetValue(uiHdrHdl,acTo);
  return eRetVal;
}


/******************************************************************
*  Function Name  :  IFX_SIP_4XXConst
*  Description    : this function constructs the 4XX response
*  Input Values   : eRespType - Response Type
*                   uiDecMsgHdl - Decoded Message Handle
*                   uiEncMsgHdl - Encoded Message Handle
*                   pxAppData - User Agent application data
*                   peEcode - Error Code if any 
*  Output Values  : uiEncMsgHdl - Updated Encoded message handle
*                   peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_4XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                  IN uint32 uiEncMsgHdl,
                  IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  OUT e_IFX_SIP_Ecode* peEcode)
{
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiEncMsgHdl);
  if(nStatusCode == 405){
    /* method not allowed response */
    /* should contain the allow header field */
    if (IFX_SIPAPP_SetAllow(uiEncMsgHdl) == IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
	}
    return IFX_SIP_SUCCESS;
  }
  else if(nStatusCode ==415)
  {
    /* unsupported media type */
    /* send response with accept header...appln/sdp */
    if (IFX_SIPAPP_SetAccept(uiEncMsgHdl,"application","sdp") == IFX_SIP_FAILURE) {
      *peEcode = IFX_SIP_TU_MEMORY_ERROR;
      //IFX_SIP_FreeMsg(uiEncMsgHdl);
      return IFX_SIP_FAILURE;
	}
    return IFX_SIP_SUCCESS;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIP_5XXConst
*  Description    : this function constructs the 5XX response
*  Input Values   : eRespType - Response Type
*                   uiEncMsgHdl - Encoded Message Handle
*                   pxAppData - User Agent application data
*                   peEcode - Error Code if any 
*  Output Values  : uiEncMsgHdl - Updated Encoded message handle
*                   peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_5XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIP_6XXConst
*  Description    : this function constructs the 6XX response
*  Input Values   : eRespType - Response Type
*                   uiEncMsgHdl - Encoded Message Handle
*                   pxAppData - User Agent application data
*                   peEcode - Error Code if any 
*  Output Values  : uiEncMsgHdl - Updated Encoded message handle
*                   peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_6XXConst(IN e_IFX_SIP_BasicMethod eRespType,
                 IN uint32 uiEncMsgHdl,
                 IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  return IFX_SIP_SUCCESS;
}

