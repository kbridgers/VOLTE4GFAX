/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Registration.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 06-10-2005
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains function related to the registration.
**   COMPILER      : gcc
**   REFERENCE     :
**   COPYRIGHT     : Copyright (c) 2005
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include "ifx_os.h"

#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_RegApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"

#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"

#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_Registration.h"
#include "ifx_list.h"


#define IFX_SIPAPP_REG_NUM_CHALLENGES_ACCEPT  2
extern uchar8 vcSipAppModId;

/* Head pointer of the registrations */
x_IFX_SIPAPP_UserRegistration* vpxUserRegistrationHeadptr = NULL;



/******************************************************************************
*  Function Name  : IFX_SIPAPP_RemoveUserRegistration
*  Description    : This function removes the reg'n app data from the list
*  Input Values   : pxUserReg - address of the app data to be removed
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS, always.
*  Notes          : 
******************************************************************************/
void
IFX_SIPAPP_RemoveUserRegistration(IN x_IFX_SIPAPP_UserRegistration *pxUserReg)
{
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "IFX_SIPAPP_RemoveUserRegistration-removing app data");
  /* Stop the refresh timer */
	if(pxUserReg && pxUserReg->unRegTimerId)
  	IFX_SIPAPP_StopTimer(pxUserReg->unRegTimerId);
#ifdef DARE_CUST
	if (pxUserReg && pxUserReg->unOptionsTimerId){
    IFX_SIPAPP_StopTimer(pxUserReg->unOptionsTimerId);
		pxUserReg->unOptionsTimerId = 0;
	}
#endif

  if(pxUserReg && pxUserReg->pcRegistrar)
  IFX_SIPAPP_Free(pxUserReg->pcRegistrar);

  if(pxUserReg && pxUserReg->pcAOR)
  IFX_SIPAPP_Free(pxUserReg->pcAOR);

  if(pxUserReg && pxUserReg->pcProxyAddr)
     IFX_SIPAPP_Free(pxUserReg->pcProxyAddr);
	
	if(pxUserReg)
	{
	 memset(pxUserReg,0,sizeof(x_IFX_SIPAPP_UserRegistration));
   __ifx_list_del((void *)&vpxUserRegistrationHeadptr, (void *)pxUserReg);
  }
  return;
}
/******************************************************************************
*  Function Name  : IFX_SIPAPP_RemoveUserRegList
*  Description    : This function removes the reg'n app data from the list
*  Input Values   : pxUserReg - address of the app data to be removed
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS, always.
*  Notes          : 
******************************************************************************/
PUBLIC void
IFX_SIPAPP_RemoveUserRegList()
{
 x_IFX_SIPAPP_UserRegistration *pxUserReg= vpxUserRegistrationHeadptr,
 *pxTemp=NULL;
 while(pxUserReg)
 {
   pxTemp=pxUserReg;
	__ifx_list_GetNext((void*)&pxUserReg);
	 IFX_SIPAPP_RemoveUserRegistration(pxTemp);
 }	
 return;		  
}
/******************************************************************************
*  Function Name  : IFX_SIPAPP_RemoveRegForSrvPdr
*  Description    : This function removes the reg'n app data from the list
*  Input Values   : pxUserReg - address of the app data to be removed
*  Output Values  :
*  Return Value   : IFX_SIP_SUCCESS, always.
*  Notes          :
******************************************************************************/
PUBLIC void
IFX_SIPAPP_RemoveRegForSrvPdr(uint32 uiSrvPdr)
{
 x_IFX_SIPAPP_UserRegistration *pxUserReg= vpxUserRegistrationHeadptr,
 *pxTemp=NULL;
 IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entered");
 while(pxUserReg)
 {
   pxTemp=pxUserReg;
  __ifx_list_GetNext((void*)&pxUserReg);
  if(pxTemp->uiProfileId == uiSrvPdr)
  {
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Destroying RegClient");
   IFX_SIP_RegClientDestroy(pxTemp->uiRegClientHdl); 
   IFX_SIPAPP_RemoveUserRegistration(pxTemp);
  }
 }
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_SendRegister
*  Description    : This function sends REGISTER requst based on information
*  					  provided in UserRegistration sturcture.
*
*  Input Values   : pxUserReg is reference to Registration database.
*  Return  Value  : IFX_SIPAPP_SUCCESS
*                   IFX_SIPAPP_FAILURE
*  Notes          :
***********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SendRegister(x_IFX_SIPAPP_UserRegistration *pxUserReg)
{
	uint32 uiCfgInst;
  x_IFX_SIPAPP_UserRegistration *pxUserReg1= vpxUserRegistrationHeadptr,
  *pxTemp=NULL;
  char8 cFound = 0;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entered");

 while(pxUserReg1)
 {
   pxTemp=pxUserReg1;
	__ifx_list_GetNext((void*)&pxUserReg1);
	if (pxUserReg == pxTemp){
		cFound = 1;
		break;
	}
 }
 if (cFound == 0){
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"IFX_SIPAPP_SendRegister: Reg Node NOT found ");
	return IFX_SIP_FAILURE;
 }

  if(pxUserReg->unRegTimerId)
  {
      IFX_SIPAPP_StopTimer(pxUserReg->unRegTimerId);
  }
#ifdef DARE_CUST
	if (pxUserReg->unOptionsTimerId){
    IFX_SIPAPP_StopTimer(pxUserReg->unOptionsTimerId);
		pxUserReg->unOptionsTimerId = 0;
	}
#endif

  /*Store Reg Attributes*/
  pxUserReg->unRegTimerId  = 0;	
	uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxUserReg->uiProfileId);
	/*Associate StackHdl and Interface Hdl */
	IFX_SIP_AssociateRegClient((uint32)pxUserReg->uiRegClientHdl,
			                       vpxSrvPdrData[uiCfgInst].uiStackHdl,
														 0);


  if((pxUserReg->pcProxyAddr != NULL)&&(pxUserReg->ucIsOutBoundProxy))
  {	
     IFX_SIP_SetRegClientNextHopAddr(pxUserReg->uiRegClientHdl, 
		                            pxUserReg->pcProxyAddr,
									pxUserReg->unTcpPort, 
									pxUserReg->unProxyPort,
									pxUserReg->eProxyProtocol);
	  
  }

  /*Call SIP Toolkit to send REGISTER*/
  if(IFX_SIP_SendRegisterRequest(pxUserReg->uiRegClientHdl, 0/*MsgHdl*/,
                                 pxUserReg->uiExpire,pxUserReg->pcRegistrar,
                                 pxUserReg->pcAOR,0/*TCP Port Number*/)
						==IFX_SIP_FAILURE)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"IFX_SIPAPP_RegisterHdlr failed ");
	 return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
 }

/******************************************************************
*  Function Name  : IFX_SIPAPP_RegTimeOutHdlr
*  Description    : Function to be reigstered with timer library once REGISTER
*  					  request times out. 
*
*  Input Values   : pxUserReg is reference to registration database.
*  Return  Value  : IFX_SIPAPP_SUCCESS
*                   IFX_SIPAPP_FAILURE
*  Notes          :
***********************************************************************/
void
IFX_SIPAPP_RegTimeOutHdlr(x_IFX_SIPAPP_UserRegistration *pxUserReg)
{ 
	x_IFX_SIPAPP_Register xRegister ={0};
  x_IFX_SIPAPP_UserRegistration *pxUserReg1= vpxUserRegistrationHeadptr,
  *pxTemp=NULL;
  char8 cFound = 0;

 	while(pxUserReg1)
 	{
   	pxTemp=pxUserReg1;
		__ifx_list_GetNext((void*)&pxUserReg1);
		if (pxUserReg == pxTemp){
			cFound = 1;
			break;
		}
 	}
 	if (cFound == 0){
  	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"IFX_SIPAPP_SendRegister: Reg Node NOT found ");
		return;
 	}

 /*After TimeOut if REG request sent successfully - Then wait for the final response
	 to arrive.*/
	if(pxUserReg->bRetry == IFX_FALSE) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Retry is Disabled");
	 xRegister.cRegStatus = IFX_OFF;
	 xRegister.uiExpires = 3600;
   xRegister.eReason= IFX_TERMINATED;
		
	 vpxNotifier.pfStateNotifier(&pxUserReg->uiReqId, IFX_REG_STATUS, (void*)&xRegister);
	 IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
	 /*No need to destroy reg client handle*/
	 return;
	}
   if(IFX_SIP_CreateRegisterClient((void *)pxUserReg,&pxUserReg->uiRegClientHdl)
	                               ==IFX_SIP_SUCCESS)
   {
    if(IFX_SIPAPP_SendRegister(pxUserReg)==IFX_SIP_SUCCESS)
	     return;
	 
   else
   {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "IFX_SIPAPP_RegTimeOutHRetry - Sending REG Request failed \n");
   }
  } 
#ifdef IFX_SIPAPP_AUTO
 {
	/*If CreatRegClient/SendRegister fails 
	 1.SendRegister could faild when network cable is unplugged
	 2.Start re-reg timer*/ 
   
	 e_IFX_SIP_Ecode eEcode;
	 e_IFX_SIP_Return eRetVal=IFX_SIP_FAILURE;
	 uint32 uiRetryTimer = IFX_SIPAPP_GET_REGRETRYTIMEOUT(IFX_SIPAPP_GetSrvPdrInst(pxUserReg->uiProfileId));

	 /*Set Registration state to PENDING*/
	 xRegister.cRegStatus = IFX_PENDING;
	 xRegister.uiExpires = 3600;
   xRegister.eReason=IFX_TERMINATED;
	 pxUserReg->uiAuthRetry=0;
   eRetVal = IFX_SIPAPP_StartTimer(uiRetryTimer * 1000,(void*)IFX_SIPAPP_RegTimeOutHdlr,
                                   (void*) pxUserReg, &pxUserReg->unRegTimerId,
                                   &eEcode);

		 if(eRetVal == IFX_SIP_FAILURE)
		 {
          IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Error starting the registration retry timer");
	        xRegister.cRegStatus = IFX_OFF;
          xRegister.eReason=IFX_TERMINATED;
		 }

		 /*Following flags indicates client is UNREG*/
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Informig APP ");
	   vpxNotifier.pfStateNotifier(&pxUserReg->uiReqId, IFX_REG_STATUS, (void*)&xRegister);
		 /*If Retry StartTimer fails - Remove App data*/
		 if(xRegister.cRegStatus==IFX_OFF)
			{
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Removing RegAppData ");
		   /*No need to destroy reg client handle*/
			  IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
			}
  }
#endif
 return;

 
}
					  
/******************************************************************************
*  Function Name  : IFX_SIP_RegisterUser
*  Description    : API for the user to request for registration
*  Input Values   : uiReqId is a Request Id
*                   uiProfileId is profile Id
*                   pxRouteParam is reference to Route parametes
*                   uiExpire is registration expiration time
*                   ppvPvtData Pointer to NA's internal structure for this dialog  
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :  vpxUserRegistrationHeadptr
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RegisterUser(IN uint32 uiReqId,
                        IN uint32 uiProfileId,
                        IN x_IFX_SIPAPP_RouteParams *pxRouteParam,
                        IN uint32 uiExpire,
                        IN_OUT void **ppvPvtData,
												IN boolean bRetry)
{
  	x_IFX_SIPAPP_UserRegistration *pxUserReg;
  	char8 acTemp[1024];
  	int32 iErrorCode;
		e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
#ifdef IFX_SIPAPP_AUTO 
  e_IFX_SIP_Ecode eEcode;
#endif  
 

  	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entering");
	
	/*Check for the bad pointer*/
 	if(!ppvPvtData)
	{ 				
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "PrivateData pointer is NULL \n");
	  return IFX_SIP_FAILURE;   
	}
	pxUserReg = *ppvPvtData;
	
	if(!uiExpire)
	{
  	 if(pxUserReg == NULL || pxUserReg->uiReqId!=uiReqId)
	   {      
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "IFX_SIPAPP_RegisterUser Request ID mismatch \n");
	    return IFX_SIP_FAILURE;
	 }
	 if(pxUserReg==NULL)
	 return IFX_SIPAPP_UnRegisterUser(uiReqId,pxUserReg);
	}
  
   /*Creat new UesrReg and add it into list*/
  	else if (pxUserReg==NULL)
  	{
    __ifx_list_add_to_tail((void*)&vpxUserRegistrationHeadptr,(void*)&pxUserReg,
	                      sizeof(x_IFX_SIPAPP_UserRegistration),&iErrorCode);
	
    if(iErrorCode < 0)
     	return IFX_SIP_FAILURE; 
   
    memset(pxUserReg,0,sizeof(x_IFX_SIPAPP_UserRegistration));
    if(IFX_SIP_CreateRegisterClient((void *)pxUserReg,&pxUserReg->uiRegClientHdl)
	   ==IFX_SIP_FAILURE)
    {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Creating Register client failed");
     IFX_SIPAPP_RemoveUserRegistration(pxUserReg);    
     return IFX_SIP_FAILURE;
    }
    /*Store the private data*/
    *ppvPvtData = (void*) pxUserReg;
    pxUserReg->uiReqId=uiReqId;	
   }
   
	/*Get Registrar URI*/
  IFX_SIPAPP_ConvRegAddrToStr(pxRouteParam->pxTo,acTemp);
  pxUserReg->pcRegistrar = (char8*)IFX_SIPAPP_Malloc(IFX_SIPAPP_Strlen(acTemp)+1);
  if(!(pxUserReg->pcRegistrar))
  {
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Destroying RegClient");
   IFX_SIP_RegClientDestroy(pxUserReg->uiRegClientHdl); 
   IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
	  return IFX_SIP_FAILURE;
  }
  IFX_SIPAPP_Strcpy(pxUserReg->pcRegistrar,acTemp);

  /*Get Addresss of Record URI*/
  memset(acTemp,0,IFX_SIPAPP_Strlen(acTemp));
  IFX_SIPAPP_ConvUsrCfgToStr(pxRouteParam->pxFrom,acTemp);
  pxUserReg->pcAOR = (char8*)IFX_SIPAPP_Malloc(IFX_SIPAPP_Strlen(acTemp)+1);
  if(!(pxUserReg->pcAOR))
  {
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Destroying RegClient");
   IFX_SIP_RegClientDestroy(pxUserReg->uiRegClientHdl); 
     IFX_SIPAPP_RemoveUserRegistration(pxUserReg);    
	  return IFX_SIP_FAILURE;
  }
  
	IFX_SIPAPP_Strcpy(pxUserReg->pcAOR,acTemp);

  /*Stor Reg Info*/
  pxUserReg->uiProfileId=uiProfileId;
  pxUserReg->uiExpire=uiExpire;
	pxUserReg->bRetry = bRetry;
  if(pxRouteParam->pcProxyAddr)  
  {
  
   pxUserReg->pcProxyAddr = (char8*)IFX_SIPAPP_Malloc(
	                       IFX_SIPAPP_Strlen(pxRouteParam->pcProxyAddr)+1);
   if(!(pxUserReg->pcProxyAddr))
	  return IFX_SIP_FAILURE;
   
	 IFX_SIPAPP_Strcpy(pxUserReg->pcProxyAddr,pxRouteParam->pcProxyAddr);
   pxUserReg->eProxyProtocol=pxRouteParam->eProxyProtocol;
   pxUserReg->unProxyPort=pxRouteParam->unProxyPort;
   pxUserReg->ucIsOutBoundProxy=pxRouteParam->ucIsOutBoundProxy;
  }
   
    /*Send Register Request*/
  if(IFX_SIPAPP_SendRegister(pxUserReg) == IFX_SIP_FAILURE)
	 {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"SendReg Failed");
#ifdef IFX_SIPAPP_AUTO
		 if(uiExpire ) {
	     /* Start the registration retry timer */
		   uint32 uiRetryTimer = IFX_SIPAPP_GET_REGRETRYTIMEOUT(
		   IFX_SIPAPP_GetSrvPdrInst(pxUserReg->uiProfileId));
		   pxUserReg->uiAuthRetry=0;
		   pxUserReg->ucMaxRetry=1;
       eRetVal = IFX_SIPAPP_StartTimer(uiRetryTimer * 1000,
                                        (void*)IFX_SIPAPP_RegTimeOutHdlr,
                                        (void*) pxUserReg,
                                        &pxUserReg->unRegTimerId,
                                         &eEcode);

		   if(eRetVal == IFX_SIP_FAILURE)
		   {
          IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Error starting the registration retry timer");
					IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
					return IFX_SIP_FAILURE;
		   }
		   return IFX_SIP_SUCCESS;
	  }
#else
		return IFX_SIP_FAILURE;
#endif
	 }
	  return IFX_SIP_SUCCESS;
}
/******************************************************************************
*  Function Name  : IFX_SIP_UnRegisterUser
*  Description    : API for Unregistering the user.
*  Input Values   : uiReqId is a Request Id
*                   pvPvtData Pointer to NA's internal structure for this dialog
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UnRegisterUser(IN uint32 uiReqId,
					 			  IN void *pvPvtData)
{ 
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entered");
  if(pvPvtData)
  {
   x_IFX_SIPAPP_UserRegistration *pxUserReg= 
   (x_IFX_SIPAPP_UserRegistration *)pvPvtData;		  
   if((pxUserReg)&& pxUserReg->uiReqId!=uiReqId)
   {	   
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "IFX_SIP_UnRegisterUser Request Id Mismacth");
     return IFX_SIP_FAILURE;
   } 
   pxUserReg->uiExpire = 0;
   /*User is not registerd*/
	 if(pxUserReg->ucMaxRetry)
	 {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"User not Registerd");
 	  IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
	  return IFX_SIP_FAILURE;
	 }
	 /*If UNREG fails remove AppData and Inform Application
		 Otherwise wait for the final response */
   if(IFX_SIPAPP_SendRegister(pxUserReg) == IFX_SIP_FAILURE)
   {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Send UNREG Failed");
	   IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
	   return IFX_SIP_FAILURE;
   }
	  return IFX_SIP_SUCCESS;
  }
 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid APP Data");
 return IFX_SIP_FAILURE;
}

/******************************************************************************
*  Function Name  : IFX_SIPAPP_SetAuthInfoReg
*  Description    : Authenticates the challenged REGISTER request with given user/proxy credentials
*  Input Values   : uiReqId is a request identifier
*  					  pcUserName is reference to username string
*  					  pcPassword is reference to password for authentication.
*  					  pxAppData is reference to internal structure for this dialog		
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS, always.
*  Notes          : 
******************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetAuthInfoREG(IN uint32 uiReqId,
					 			  IN char8* pcUserName,
								  IN char8* pcPassword,
								  IN void* pxAppData)
{    
 if(pxAppData)
 {
  x_IFX_SIPAPP_UserRegistration* pxUserReg =
  (x_IFX_SIPAPP_UserRegistration*)pxAppData; 

  uint32 uiRegClientHdl = pxUserReg->uiRegClientHdl;

  x_IFX_SIPAPP_Register xRegister ={0};
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
		    "Calling IFX_SIP_RegAuthenticate");
  if(IFX_SIP_RegAuthenticate(uiRegClientHdl,pcUserName, pcPassword, 0)
	  == IFX_SIP_FAILURE)
  {
    xRegister.cRegStatus=IFX_OFF;
	vpxNotifier.pfStateNotifier(&pxUserReg->uiReqId, IFX_REG_STATUS, 
                                    (void*)&xRegister);
 	IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
  }
  return IFX_SIP_SUCCESS;
 }
 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Failed");
 return IFX_SIP_FAILURE;
}
/******************************************************************************
*  Function Name  : IFX_SIP_RegistrationStateHdlr
*  Description    : This function is the registration state handler.
*  Input Values   : eRegClientState - state on which the action is to be taken
*                   uiRegClientHdl - Registration Client data
*                   pvUserData - User reg'n app data
*  Out put Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
* 
* 
IFX_ON : Implies that Registration in ON
IFX_OFF with uiExpires = 0 impilies that  UNREGISTER Request - send success to APP
IFX_OFF with Terminated means failure - Clear App data and Send FAIL to APP
IFX_PENDING and IFX_TIMEOUT means Registartion has failed, Retry timer is running. Send Success to APP
******************************************************************************/
PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_REGStateHdlr(IN e_IFX_SIP_RegisterClientState eRegClientState,
                        IN uint32 uiRegClientHdl,
                        IN void* pvUserData)
{
  x_IFX_SIPAPP_UserRegistration *pxUserReg = 
  (x_IFX_SIPAPP_UserRegistration *)pvUserData;
  x_IFX_SIPAPP_Register xRegister={0};
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiMsgHdl=IFX_SIP_RegGetDecodedMsg(uiRegClientHdl);
#ifdef IFX_SIPAPP_AUTO 
  e_IFX_SIP_Ecode eEcode;
#endif  
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entered");
	xRegister.uiExpires=pxUserReg->uiExpire;
  pxUserReg->ucMaxRetry=0;
  
	switch(eRegClientState) 
  {
    case IFX_SIP_REG_CLIENT_REGISTERING:
    case IFX_SIP_REG_CLIENT_UNREGISTERING:
         break;
    case IFX_SIP_REG_CLIENT_REGISTERED:
      {
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"2XX Recvd");
		   if(pxUserReg->uiExpire==0)
       {
        /*Send Prviously blocked unregister*/
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"REGStateHdlr Sending blocked UNREG");
        IFX_SIPAPP_SendRegister(pxUserReg);
        return IFX_SIP_SUCCESS;
	     }
	    else
	    {
				pxUserReg->uiAuthRetry=0;
        xRegister.cRegStatus = IFX_ON;	  
        xRegister.eReason=IFX_200_RESP;
	      xRegister.uiExpires=pxUserReg->uiExpire;
				uint32 uiExpiry = 0;
        
				vpxNotifier.pfStateNotifier(&pxUserReg->uiReqId, IFX_REG_STATUS, (void*)&xRegister);
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR, pxUserReg->uiExpire, "(sec) expires");
				
      #ifdef IFX_SIPAPP_AUTO 
			if(pxUserReg->uiExpire < 150){
				pxUserReg->uiExpire = 150;
			}
			if(pxUserReg->uiExpire < 1500){
        uiExpiry = pxUserReg->uiExpire /2;
      }
			else{
				uiExpiry = pxUserReg->uiExpire - 900;
			}
				
       eRetVal= IFX_SIPAPP_StartTimer(uiExpiry*1000,
                                      (void*)IFX_SIPAPP_SendRegister,(void*) pxUserReg,
  			                              &pxUserReg->unRegTimerId, &eEcode);
        if(eRetVal == IFX_SIP_FAILURE)
        {
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Error starting the registration refresh timer");
          return IFX_SIP_SUCCESS;
        }
       #endif 
#ifdef DARE_CUST
		/* once Dare proprietry object is implemented get timer value from rc.conf 
				and start timer to handle OPTIONS timeout for the line that just got registered */
		//printf("\nLine is Registered, OPTIONS timer started, ReqId %d",pxUserReg->uiReqId);

		if(pxUserReg->unOptionsTimerId) {
			IFX_SIPAPP_StopTimer(pxUserReg->unOptionsTimerId);
		}
		if (access("/tmp/options", F_OK ) == -1){
			eRetVal= IFX_SIPAPP_StartTimer(5*60*1000,
                                   (void*)IFX_SIPAPP_SendRegister,(void*) pxUserReg,
                                   &pxUserReg->unOptionsTimerId, &eEcode);
			if(eRetVal == IFX_SIP_FAILURE)
			{
				IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Error starting the OPTIONS timeout timer");
			}
		}
#endif
				return IFX_SIP_SUCCESS;
       }
     }                            
     break;
    
		case IFX_SIP_REG_CLIENT_UNREGISTERED:
      {
				uint32 uiReqId = pxUserReg->uiReqId;
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_SIP_ERR,"Client Unregistered");
        
				/* Inform the application */
        xRegister.cRegStatus = IFX_OFF; 			  
				xRegister.uiExpires = 0;
        xRegister.eReason=IFX_200_RESP;
        IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
        vpxNotifier.pfStateNotifier(&uiReqId, IFX_REG_STATUS,(void*)&xRegister);
				return IFX_SIP_SUCCESS;

      }
      break;

    case IFX_SIP_REG_CLIENT_PROXY_AUTH_REQD:
    case IFX_SIP_REG_CLIENT_USER_AUTH_REQD:
      {
        int32   iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
        char8  *pcRealm=NULL,acRealm[IFX_SIPAPP_REG_MAX_TOKEN]={'\0'};
        x_IFX_SIPAPP_AuthReqd xAuthReqd = {0};
        uint32  uiAuthHdl;        
        xRegister.cRegStatus = IFX_PENDING;	  
        xRegister.eReason=IFX_TIMEOUT;
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Auth Info Required");
     
        /* Accept challenge IFX_SIPAPP_REG_NUM_CHALLENGES_ACCEPT times */
        if (pxUserReg->uiAuthRetry >= IFX_SIPAPP_REG_NUM_CHALLENGES_ACCEPT) 
        {
         IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Challenges exceed limit");
			   goto fail_handler;
        }
        ++pxUserReg->uiAuthRetry;

        if(iRespCode == 401) 
        {
          eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_WWW_AUTHENTICATE,1, &uiAuthHdl);
         if(eRetVal == IFX_SIP_FAILURE)
         {
   	      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"No www Auth header found");
			    goto fail_handler;
         }
        }
        
				else 
        {
         eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_PROXY_AUTHENTICATE,1, &uiAuthHdl);
         if(eRetVal == IFX_SIP_FAILURE)
         {
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"No Proxy-Authenticate  header found"); 
          goto fail_handler;
         }
        }

        pcRealm = IFX_SIP_Authentication_GetRealm(uiAuthHdl);
        if(pcRealm == NULL){
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"No Proxy-Authenticate  header found"); 
          goto fail_handler;
        }

        /* Since the Relm contain Quots, the below logic is to remove the Quots*/
        IFX_SIPAPP_Strncpy(acRealm,pcRealm+1,IFX_SIPAPP_Strlen(pcRealm)-2);		  
        /*Get Username/Password from Application*/
        xAuthReqd.pcRealm = acRealm;
        xAuthReqd.pvPvtData = pxUserReg;
   	    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Informing PhonApp - RegAuth Required");
        vpxNotifier.pfStateNotifier(&pxUserReg->uiReqId, IFX_REG_AUTH_REQ, (void*)&xAuthReqd);
		    return IFX_SIP_SUCCESS;		 
      
			}
      break;

    case IFX_SIP_REG_CLIENT_REDIRECTED:
      {
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"REGISTER request Re-Directed");
				if(!pxUserReg->uiExpire){
           IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"UNREG Re-Directed");
				   xRegister.uiExpires = 0;
				}
        xRegister.cRegStatus = IFX_OFF;	  
        xRegister.eReason= IFX_TERMINATED;
		    goto fail_handler;
      }
      break; 

    case IFX_SIP_REG_CLIENT_FAILED:
      {
   	     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"REG State Failed");
         xRegister.cRegStatus = IFX_PENDING;	  
         xRegister.eReason=IFX_TIMEOUT;

				 /*If  UNREG fails  Corner case*/
				 if(!pxUserReg->uiExpire)
				 {
          IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"UNREG Failed");
          xRegister.cRegStatus = IFX_OFF;	  
          xRegister.eReason=IFX_TERMINATED;
				  xRegister.uiExpires = 0;
					goto fail_handler;

				 }
			  if(uiMsgHdl != 0){
          uint32   iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
          /*If RespCode==423 then Get MinExpire and send new Reigster with "expire > Min Expire"*/
          if(iRespCode==423)
          {
	          uint32 uiMinExpHdl;
	          if(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_MIN_EXPIRES,1,&uiMinExpHdl)==IFX_SIP_SUCCESS)																			          
	          {
		          uint32 uiMinEx=IFX_SIP_MinExpires_GetValue(uiMinExpHdl);
		          pxUserReg->uiExpire=uiMinEx + 10;
		          if(IFX_SIPAPP_SendRegister(pxUserReg)==IFX_SIP_FAILURE)
		          {
							/*Could Reach here If 423 is recvied and then n/w cable is unplugged - Keep Trying*/	
			           goto fail_handler;	 
		          }
              IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"ReREG sent with (MinExpire)");
              pxUserReg->uiAuthRetry=0;
		          return IFX_SIP_SUCCESS;	    
		       }	
				 }
			 }
			 
	      /*Dns query failed , required to set the expire flag to zero so that app clears regclient
         please dont remove it*/
			  //xRegister.uiExpires =0;
				xRegister.uiExpires =3600;/* added to support retry of registration*/
        goto fail_handler;
			}
			break;
     
     case IFX_SIP_REG_CLIENT_TIMEOUT:
      {
			 /*If Registrar server is not reachable OR Invalid REG Address*/	
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"REGISTER request timeout");
		   pxUserReg->ucMaxRetry = 1;
       
			 xRegister.cRegStatus = IFX_PENDING;	  
       xRegister.eReason=IFX_TIMEOUT;
			 
			 if(!pxUserReg->uiExpire)
			 {
         IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Response to UNREG not received");
			   xRegister.cRegStatus = IFX_OFF;	  
         xRegister.eReason=IFX_TERMINATED;
				 xRegister.uiExpires = 0;
				 goto fail_handler;
       }

			 if(!xRegister.uiExpires)
				  xRegister.uiExpires =3600;
			 
       IFX_SIPAPP_StopTimer(pxUserReg->unRegTimerId);
			 goto fail_handler;	 
			}
			break;

		 default :
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid state");
			 break;

	}
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Returning success");
	return IFX_SIP_SUCCESS;
	   /*If Last requst was UNREG or CMGR has invoked UNREG then ignore timeout event*/
fail_handler:		
   {
		 e_IFX_Return eRetVal = IFX_SIP_SUCCESS;
		 uint32 uiRetryTimer = IFX_SIPAPP_GET_REGRETRYTIMEOUT(IFX_SIPAPP_GetSrvPdrInst(pxUserReg->uiProfileId));
   	 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"fail handler");

		 pxUserReg->uiAuthRetry=0;
#ifdef IFX_SIPAPP_AUTO
		 /*Start timer only in case of REG Request*/
		 if(xRegister.uiExpires) {
   	    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Startin Retry timer");
        eRetVal = IFX_SIPAPP_StartTimer(uiRetryTimer * 1000,(void*)IFX_SIPAPP_RegTimeOutHdlr,
                                     (void*) pxUserReg, &pxUserReg->unRegTimerId, &eEcode);
		 }
#endif

		 if(eRetVal == ( e_IFX_Return ) IFX_SIP_FAILURE)
		 {
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Error starting the registration retry timer");
			 xRegister.cRegStatus = IFX_OFF;	  
       xRegister.eReason=IFX_TERMINATED;
		 }
	   
		 vpxNotifier.pfStateNotifier(&pxUserReg->uiReqId, IFX_REG_STATUS, (void*)&xRegister);
     
		 if(xRegister.cRegStatus == IFX_OFF)
		 {
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Current Reg Status is OFF");
       IFX_SIPAPP_RemoveUserRegistration(pxUserReg);
		 }
     return IFX_SIP_SUCCESS;
	}

}
/***********************************************************************
* Function Name   : IFX_SIPAPP_MatchContactHdrToHostIp
* Description     : If 2XX response receives more than one contact header, then
                    loop through, all contact headers and find the correct matching 
		    contact header based on WAN/HostIP address.
		    Use that contact header for expires value.
*
* Return Value    :
* Output Values   : None
**************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_MatchContactHdrToHostIp(uint32 uiContactHdr)
{
  int32 uiHdrHdl=0,uiHdl=0;
  char8 acLocaIp[128] = "",*pcRcvdAddr = NULL;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Entered");
  IFX_OS_GetHostIp(acLocaIp);
  uiHdrHdl=IFX_SIP_Contact_GetAddressType(uiContactHdr);

  if((uiHdl =IFX_SIP_AddressType_GetAddrSpec(uiHdrHdl)) ==0)
		return IFX_SIP_FAILURE;

  if((uiHdrHdl=IFX_SIP_Addrspec_GetSipUri(uiHdl)) == 0)
		return IFX_SIP_FAILURE;
	
	if((pcRcvdAddr=IFX_SIP_SipUri_GetHost(uiHdrHdl))==NULL)
		return IFX_SIP_FAILURE;
  
  if(strcmp(acLocaIp,pcRcvdAddr))
		return IFX_SIP_FAILURE;
	
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Success");
	return IFX_SIP_SUCCESS;
}
/***********************************************************************
* Function Name   : IFX_SIPAPP_GetExpires
* Description     :
*
* Return Value    :
* Output Values   : None
**************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_GetExpires(uint32 uiMsgHdl, uint32 *puiExpires)
{
  uint32 uiHdl = 0, uiExpires = 0,iFound=0,i=0;
  e_IFX_SIP_Return eRet;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Entered");
  while(!iFound){
    i++;	
    eRet=IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT, i,&uiHdl);
    if(IFX_SIP_FAILURE == eRet){
	break;
    }
    if(IFX_SIP_SUCCESS ==IFX_SIPAPP_MatchContactHdrToHostIp(uiHdl)){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR,IFX_DBG_INT,
     "Matchin contact found at location",i);
    iFound =1;		
    }
  }

  if(iFound && uiHdl != 0)
  {
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Expires in Contact");
    if ((uiExpires = IFX_SIP_Contact_GetExpire(uiHdl)) == IFX_SIP_FAILURE)
    {
      if(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_EXPIRES,1,&uiHdl) !=
           IFX_SIP_FAILURE)
      {
        uiExpires = IFX_SIP_Expires_GetValue(uiHdl);
      }
      else
      {
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "No Expires value found in the message");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else if(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_EXPIRES,
          1,&uiHdl) != IFX_SIP_FAILURE)
  {
    uiExpires=IFX_SIP_Expires_GetValue(uiHdl);
  }
  else
  {
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "No Expires value found in the message");
    return IFX_SIP_FAILURE;
  }
  *puiExpires = uiExpires;
  return IFX_SIP_SUCCESS;
}


/******************************************************************
 * Function Name  : IFX_SIP_CCAppRespArrived
 * Description    : Call Back registered to be called on reception of
 *                  the response
 * Input Values   : uiMsgHdl - Message  Handle
 *                  uiRegClientHdl - Registration  Handle
 *                  pvUserData - UserData
 * Output  Values : None
 * Return  Value  : IFX_SIP_SUCCESS
 *                  IFX_SIP_FAILURE
 * Notes          :
 ************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_REGRespArrived( IN uint32 uiMsgHdl,
          		           IN uint32 uiRegClientHdl,
			               IN void *pvUserData)
{
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  
  x_IFX_SIPAPP_UserRegistration* pxUserReg =
  (x_IFX_SIPAPP_UserRegistration*)pvUserData;

  e_IFX_SIP_RegisterClientState eRegClientState =
  IFX_SIP_GetRegClientState(uiRegClientHdl);
  
  if((iRespCode >199 && iRespCode < 300))
  {
   /*If sent request is not UNREG*/
   if(pxUserReg->uiExpire!=0)
   {
    /* Store expires value chosen by registrar */
    IFX_SIPAPP_GetExpires(uiMsgHdl, &pxUserReg->uiExpire);

    if(!(pxUserReg->uiExpire))
      eRegClientState =  IFX_SIP_REG_CLIENT_UNREGISTERED;
   
   }
  IFX_SIPAPP_REGStateHdlr(eRegClientState,uiRegClientHdl, pvUserData);
  return IFX_SIP_SUCCESS;    
  }

  
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Non-2xx Registration resp...IGNORED");
    return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_REGMsgToEncode
*  Description    : Call Back registered to be called for adding the
*                   additional headers if necessary during encoding
*                   of REGISTER requests and responses.
*  Input Values   : uiMsgHdl - Message  Handle
*                   uiRegClientHdl - Registration  Handle
*                   pvUserData - UserData
*  Output  Values : None
*  Return  Value  : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
***********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_REGMsgToEncode( IN uint32 uiMsgHdl,
		                   IN uint32 uiRegClientHdl,
			               IN void *pvPvtData)
{
  uint32 uiHdrHdl;
  char8 *pcTemp = NULL;
  x_IFX_SIPAPP_UserRegistration *pxReg =(x_IFX_SIPAPP_UserRegistration*)pvPvtData;
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Entering IFX_SIPAPP_REGMsgToEncode");
  IFX_SIPAPP_SetUserAgent(uiMsgHdl,pxReg->uiProfileId);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Added user Agent");
  IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_FROM, 1, &uiHdrHdl);
  uiHdrHdl = IFX_SIP_From_GetAddressType(uiHdrHdl);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Get From address type");
  pcTemp = IFX_SIP_AddrType_GetValue(uiHdrHdl);
  
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Get address Value");
  IFX_SIPAPP_SetContact(pcTemp, uiMsgHdl,pxReg->uiProfileId);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Added Contact");
  if(pcTemp)
  {
     IFX_SIPAPP_Free(pcTemp);
  }

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "After Free");

#ifdef STUN_SUPPORT
  IFX_SIPAPP_AddViaIfSTUNOn(uiMsgHdl,pxReg->uiProfileId);
#endif
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Leaving IFX_SIPAPP_REGMsgToEncode");
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_REGDnsResolved
*  Description    : Call Back registered to be called 
*  Input Values   : uiRegClientHdl - Register Client handle
*                   pvUserData - User Reg'n app data
*  Output  Values : None
*  Return  Value  : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
 ***********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_REGDnsResolved( IN uint32 uiRegClientHdl,
                           IN void *pvUserData)
{
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "IFX_SIPAPP_REGDnsResolved Entering");
  return  IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_REGTimeOutOrError
*  Description    : This function is called on Registration timeout
*  Input Values   : eErrorType - error type
*                   uiRegClientHdl - Register Client handle
*                   pvUserData - User reg'n app data
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_REGTimeOutOrError( e_IFX_SIP_TransErrorCode eErrorType,
                              IN uint32 uiRegClientHdl,
                              IN void *pvUserData)
{
  x_IFX_SIPAPP_UserRegistration *pxUserReg = (x_IFX_SIPAPP_UserRegistration *)
                                              pvUserData;
  
  
    /* Invoke application registered callback */
    return IFX_SIP_RegSendReqToNxtAddr(pxUserReg->uiRegClientHdl, 0);
  
  
}

/******************************************************************
**  Function Name  : IFX_SIP_RegisteCCCB
**  Description    : This function Registers the call control call backs
**                   with the stack
**  Input Values   : None
**  Output Values  : None
**  Return Value   : void
**  Notes          :
**********************************************************************/
void
IFX_SIP_RegisterREGCallbacks(uint32 uiStackHdl)
{
  x_IFX_SIP_RegClient_CallBk xRegCB;
  /* Initialize the call backs */
  xRegCB.pfnTimeOutOrError  =  IFX_SIPAPP_REGTimeOutOrError;
  xRegCB.pfnMsgToEncode     =  IFX_SIPAPP_REGMsgToEncode;
  xRegCB.pfnRespArrived     =  IFX_SIPAPP_REGRespArrived;
  xRegCB.pfnDnsResolved     =  IFX_SIPAPP_REGDnsResolved;
  xRegCB.pfnStateChanged    =  IFX_SIPAPP_REGStateHdlr;
	xRegCB.uiStackHdl =uiStackHdl;
  /* Register the call backs */
  IFX_SIP_RegClientRegisterCallBks(&xRegCB);

  return;
}
