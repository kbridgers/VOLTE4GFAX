/****************************************************************************
**   FILE NAME     : IFX_SIP_AppPublish.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains phone application inteface functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include "ifx_common_defs.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"

#include "ifx_debug.h"
#include "IFX_SIP_TranscApi.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIP_MsgApi.h"

e_IFX_SIP_Return fnTranscRequestArrived(
                        IN uint32 uiMsgHdl,
                        IN int32 iTransID,
                        IN uint32 uiDlgHdl,
                        IN_OUT void **ppvUserData)/*!< Called on Request arrival */
{
  int32 x=5;
  
  #ifdef MsgApi_Testing
  
  #endif /*MsgApi_Testing*/
  *ppvUserData =&x;
  IFX_SIP_TranscRespond(iTransID,0,200,"My reason");
  return IFX_SIP_SUCCESS;
}

e_IFX_SIP_Return fnTimeOutOrError(
                        IN e_IFX_SIP_TransErrorCode eErrorType,
                        IN int32 iTransID,
                        IN_OUT void *pvUserData)/*!< Called on Timeout or transport Error */
{
  return IFX_SIP_SUCCESS;
}

e_IFX_SIP_Return  fnMsgToEncode(
                        IN uint32 uiMsgHdl,
                        IN int32 iTransID,
                        IN_OUT void *pvUserData)/*!< Called before  message is encoded */
{
  #ifdef MsgApi_Testing
  x_IFX_SIP_SipMessage *pxMessage = (x_IFX_SIP_SipMessage*) uiMsgHdl;
  x_IFX_SIP_Date *pxDate;
  
  char8 *pcWeekDay = "FRIDAY", *pcWeekDay1;
  uchar8 ucDay = 20, ucDay1;  
  int16 iYear = 2006, iYear1	  ;
  char8 pcMonth[10]= "MARCH", *pcMonth1;
  
  uchar8 sec=15, sec1;
  uchar8 min=5, min1;
  uchar8 hour=6, hour1;
  
  if(IFX_SIP_SetHeaderByType(pxMessage,IFX_SIP_DATE, &pxDate) == IFX_SIP_SUCCESS)
  {	  
  IFX_SIP_Date_SetWeekDay (pxDate,pcWeekDay);
  IFX_SIP_Date_SetDay (pxDate, ucDay);
  IFX_SIP_Date_SetYear (pxDate,2006 );
  IFX_SIP_Date_SetMonth (pxDate,pcMonth);
  IFX_SIP_Date_SetHours (pxDate,4);
  IFX_SIP_Date_SetMinutes (pxDate,40);  
  IFX_SIP_Date_SetSeconds (pxDate,10);  

  if( IFX_SIP_GetHeaderByType(pxMessage,IFX_SIP_DATE,1, &pxDate) == IFX_SIP_SUCCESS)
  {	  
  pcWeekDay1 = IFX_SIP_Date_GetWeekDay (pxDate);

  iYear1 = IFX_SIP_Date_GetYear (pxDate);

  pcMonth1 = IFX_SIP_Date_GetMonth (pxDate);

  sec1 = IFX_SIP_Date_GetSeconds (pxDate);

  hour1 = IFX_SIP_Date_GetHours (pxDate);
  }
  else
  {
  }
  
  
  }

  
  #endif /*MsgApi_Testing*/
  return IFX_SIP_SUCCESS;
}
e_IFX_SIP_Return fnMsgRespArrived(
                        IN uint32 uiMsgHdl,
                        IN int32 iTransID,
                        IN void *pvUserData)/*!< Called on Response Arrival */
{
  e_IFX_SIP_Return eRet=IFX_SIP_SUCCESS;  
  uint16 unRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  if (unRespCode == 401 ||unRespCode == 407 ) 
  {
    eRet = IFX_SIP_TranscAuthenticate(&iTransID,0,
	         	               "1","admin");
  }
  if(eRet != IFX_SIP_SUCCESS)
  {
  }
  return IFX_SIP_SUCCESS;
}

e_IFX_SIP_Return  fnDnsResolved(
                        IN uint32 uiMsgHdl,
                        IN int32 iTransID,
                        IN void *pvUserData)/*!<Called on resolving DNS address */
{
  char8 x;
  scanf("%c",&x);
  return IFX_SIP_SUCCESS;
}
x_IFX_SIP_TransCallBks xCallBk;

void IFX_SIP_TransTest(void)
{
  int32 iTranscID=0;
  int32 userData =5;
  char8 acTo[IFX_SIPAPP_MAX_TOKEN];
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN];
  strcpy(acTo,"hello<sip:1@172.20.22.50:5061;transport=udp>");

  strcpy(acFrom,"hello<sip:2@172.20.22.80:5060;transport=udp>");
 
  xCallBk.pfnMsgToEncode =fnMsgToEncode;
  xCallBk.pfnMsgRespArrived =fnMsgRespArrived;
  xCallBk.pfnDnsResolved = fnDnsResolved;
  xCallBk.pfnTimeOutOrError = fnTimeOutOrError;
  xCallBk.pfnRequestArrived =fnTranscRequestArrived;

  
  IFX_SIP_TranscRegisterCallBks(IFX_SIP_EXT_METHOD,&xCallBk);
  
  IFX_SIP_TranscCreate(&iTranscID,(void *)&userData);

  /*IFX_SIP_TranscSetNextHopAddr(iTranscID,"172.20.22.50",5060,
		               5060,IFX_SIP_PROTO_UDP);*/
  IFX_SIP_TranscSendRequest(iTranscID,"PUBLISH",
                            0,acTo,acFrom,0); 
  
}

