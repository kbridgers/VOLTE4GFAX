/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Main.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : Narendra VP
**   DESCRIPTION   : This file contains SIP Init functions. 
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS ,  DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include "ifx_os.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"

#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_TranscApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_CallIf.h"
#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_VoiceMail.h"
#include "IFX_SIPAPP_Refer.h"
#include "IFX_SIPAPP_InstMsg.h"
#include "IFX_SIPAPP_CallBk.h"
#include "IFX_SIPAPP_Registration.h"
#include "ifx_list.h"
#ifdef IFX_CALLMGR
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#endif
#include "IFX_SIPAPP_PAIf.h"
#ifdef STUN_SUPPORT
#include "IFX_SIPAPP_Stun.h"
#endif
#include "IFX_SIPAPP_Options.h"

/*SipApp Module Id*/
uchar8 vcSipAppModId;

/* Stack Mode */
int32 viStackMode,viAppRdFd;

/*Number Of Service Provider*/
uint32 vuiNoOfSrvPrd;

/*State Notifier*/
x_IFX_SIPAPP_Notifiers vpxNotifier;

void IFX_SIPAPP_AddFDToSelect(IN int32 iSipSockFd,IN int32 iTypeofFDSet);
void IFX_SIPAPP_RemoveFDToSelect(IN int32 iSipSockFd,IN int32 iTypeofFDSet);
extern void IFX_SIPAPP_RegisterCCCB(uint32 uiStackHdl);
extern x_IFX_SIPAPP_UAAppDataPool vxAppDataPool;
/************************************************************************
 * Function Name  : IFX_SIPAPP_DbgInit
 * Description    : This function will Init Debug Library
 * Input Values   : void
 * Output Values  : None
 * Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
 * Notes          :
 * *************************************************************************/
void IFX_SIPAPP_DbgInit(uchar8 ucDbgLvl, uchar8 ucDbgType)
{
  static char8 ucOneTimeFlag =1;
  char8 cRet;	
  if(ucOneTimeFlag ==1){
    IFX_DBG_Init(IFX_IPC_APP_NAME_SIPAPP,ucDbgType,ucDbgLvl,
                 &vcSipAppModId,&cRet); 
	   ucOneTimeFlag =0;
  }
  else {
	  IFX_DBG_Set(IFX_IPC_APP_NAME_SIPAPP,
            vcSipAppModId,ucDbgType,ucDbgLvl);
  }
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Debug module Initlized/Set");
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_RecvStunTimerMsgs 
*  Description      :  This recives Stun Messages.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
void IFX_SIPAPP_RecvStunTimerMsgs( IN IFX_SIPAPP_fd_set *pxRdFdSet,
						                       IN IFX_SIPAPP_fd_set *pxWrFdSet,
                       						 IN IFX_SIPAPP_fd_set *pxExFdSet,
                      						 IN int32 *piNoFds)
{
   uchar8 ucFrom,ucTo;
	 char8 cErrCode;
   uint16 unMsgSize;
   uint32 iReserved;
   union{
#ifdef STUN_SUPPORT    
    x_IFX_SIPAPP_STUN_FifoStr xSTUNRsp;
#endif
	x_IFX_SIPAPP_TimerInfo *pxTimerInfo;
  }uxMessage;
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"Entered IFX_SIPAPP_RecvStunTimerMsgs");
   if(IFX_SIPAPP_RecvSockMsg(viAppRdFd, &ucFrom, &ucTo, &unMsgSize,
                      &iReserved, (char*)&uxMessage,
                      &cErrCode) == IFX_IPC_FAIL){ 
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR,
                IFX_DBG_FIFO_READ_ERR, "PA RX");
       return;      
   }
   if(ucTo != IFX_IPC_APP_ID_SIP) {
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR,
                 IFX_DBG_STR, "Wrong TO ID in the received message from FIFO");
        return;
   }
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Received message on SIP FIFO");
   switch(ucFrom){
     case IFX_IPC_APP_ID_SIP:
       switch(iReserved){
	     case IFX_IPC_SIPAPP_TIMER:
	          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
	                   "Received message from Timer");
			  IFX_SIPAPP_ProcessTimerMsg(uxMessage.pxTimerInfo);
              break;
#ifdef STUN_SUPPORT
	     case IFX_IPC_SIPAPP_STUN:
	          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
	                   "Received message from STUN");
	          IFX_SIPAPP_STUN_RespHandler(&uxMessage.xSTUNRsp);
	          break;
#endif
	     default:
	          break;
	   }
     default:          
       break;
   }

   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Exiting from IFX_SIPAPP_RecvStunTimerMsgs");
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_RecvStackMsgs 
*  Description      :  This is the Call back function which is 
*  					:  responsible for Forwarding the Stack Msgs
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
void IFX_SIPAPP_RecvStackMsgs(
						 IN IFX_SIPAPP_fd_set *pxRdFdSet,
						 IN IFX_SIPAPP_fd_set *pxWrFdSet,
						 IN IFX_SIPAPP_fd_set *pxExFdSet,
						 IN int32 *piNoFds)
{
  uint32 uiCount;
  int32 iNoOfFd=*piNoFds;

	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered IFX_SIPAPP_RecvStackMsgs");
  for(uiCount=0;uiCount<vuiNoOfSrvPrd;uiCount++){
    IFX_SIP_SyncReceiveMsg(uiCount,pxRdFdSet,pxWrFdSet,pxExFdSet,&iNoOfFd);
  }
	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Exiting IFX_SIPAPP_RecvStackMsgs");
  return;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_AddFDToSelect 
*  Description      :  This is the Call back function which is 
*					:  responsible for adding the internal socket 
*					:  fd provided by sip stack o the read fd set
*					:  in Sync Mode.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
void IFX_SIPAPP_AddFDToSelect(IN int32 iSipSockFd,IN int32 iTypeofFDSet)
{

 IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Add FD to Select Called");

  vpxNotifier.pfAddFdToSelect(iSipSockFd,iTypeofFDSet,
                   (pfn_IFX_SIPAPP_FdCallback)IFX_SIPAPP_RecvStackMsgs);
	return;
		
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_RemoveFDToSelect 
*  Description      :  This is the Call back function which is 
*  					:  responsible for removing the internal socket 
*  	                :  fd provided by sip stack o the read fd set
*  					:  in Sync Mode.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
void IFX_SIPAPP_RemoveFDToSelect(IN int32 iSipSockFd,IN int32 iTypeofFDSet)
{
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	       "Remove FD to Select Called");
  vpxNotifier.pfRemoveFdFromSelect(iSipSockFd,(uchar8)iTypeofFDSet);
  return;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_GetSrvPdrInst 
*  Description      :  This function return Service provider instance index.
*  Input Values     :  Service Provider ID
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
int32 IFX_SIPAPP_GetSrvPdrInst(uint32 uiSrvPdrId)
{  uint32 uiCount=0;
   for(uiCount =0; uiCount<vuiNoOfSrvPrd;uiCount++){
	  if(vpxSrvPdrData[uiCount].uiSrvPrdId == uiSrvPdrId ){
        return uiCount;
	  }
   }
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	       "Service Provider Not Found");
   return -1;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_Init 
*  Description      :  This is Init Function of NetworkAgent.
*  Input Values     :  NoOf Service Providers
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_Init(IN uint32 uiNoOfSrvPdr)
{
#ifdef IFX_CALLMGR
  x_IFX_VMAPI_SystemDebugSettings xDbgSet;
#endif
  
  vxAppDataPool.iMaxAppData = 100;
#ifdef IFX_CALLMGR
  /* initilze CallMgr Interface*/
  if(IFX_SIPAPP_PaIfInit() != IFX_SIP_SUCCESS){
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
		        "Init Call Mgr Callbacks Failed");
    return IFX_SIP_FAILURE;
  }

  ifx_get_DbgSettings(&xDbgSet,IFX_F_DEFAULT);
  IFX_SIPAPP_DbgInit(xDbgSet.xSipDbg.ucDbgLvl,
	                   xDbgSet.xSipDbg.ucDbgType);

#endif

  /* Initialize the configuration module */
  if(IFX_SIPAPP_CfgInit(uiNoOfSrvPdr) != IFX_SIP_SUCCESS){
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		         "Service Provider Data Initilization Failed");
    return IFX_SIP_FAILURE;
  }

  if(IFX_SIPAPP_SocketInit() == IFX_SIP_FAILURE){
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,  
		         "<SIP-TUMain> FIFO Init Failed");
    return IFX_SIP_FAILURE;
  }

  viStackMode = IFX_SIP_SYNC_MODE;
  /* Configure Stack about the Instance required*/
  if(IFX_SIP_CfgStackInstances(uiNoOfSrvPdr,1)!= IFX_SIP_SUCCESS){
		IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Creating Stack Instance Failed");
    return IFX_SIP_FAILURE;
  }
  /*Timer Intilization*/
  IFX_SIPAPP_TimerInit();


  vuiNoOfSrvPrd = uiNoOfSrvPdr;
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_Shut 
*  Description      :  This is shuts down NetworkAgent.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_Shut(void)
{
  int32 iCount=0;
  /*Shut STACK*/
  if(IFX_SIP_Shut() != IFX_SIP_SUCCESS){
	  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Stack Shut Failed");
	  return IFX_SIP_FAILURE;
  }

  /* Clear All App Data*/
  while(vxAppDataPool.iAppDataCount!=0){
    x_IFX_SIPAPP_UAAppData *pxTemp = vxAppDataPool.pxAppDataHead;
    for (iCount=0; iCount<IFX_SIPAPP_UA_MAX_HDLS; iCount++) {
		if(pxTemp->auiHdl[iCount] != 0){
  	      IFX_SIPAPP_RemoveAppData(pxTemp,iCount); 
		}                     
    }
  }
  /* Clear All REgistration Data*/
  /*TODO*/
  IFX_SIPAPP_Free(vpxSrvPdrData);
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Shut Success");
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_CreateSrvPdr 
*  Description      :  This is Creates Stack Instance.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_CreateSrvPdr(IN uint32 uiSrvPdrId)
{
  int32 uiCount= IFX_SIPAPP_GetSrvPdrInst(uiSrvPdrId);
#ifdef STUN_SUPPORT
  x_IFX_SIPAPP_STUNInfo xstuninfo;
  int32 iStunId;
	e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
#endif
  x_IFX_SIP_SyncCallBks	xSyncCallbks;
#ifdef IFX_CALLMGR
  x_IFX_VMAPI_VoiceProfile xVoiceProfile;
  x_IFX_VMAPI_ProfileSignaling xVoiceSignaling;
  x_IFX_VMAPI_SystemDebugSettings xDbgSet;
  xVoiceSignaling.ucProfileId = uiSrvPdrId;
  xVoiceProfile.ucProfileId = uiSrvPdrId;
#ifdef QOS_SUPPORT
	static int iIntPortInitialized = 0;
  char acCommand[512]="";
#endif	
  memset(&xDbgSet,0,sizeof(x_IFX_VMAPI_SystemDebugSettings));
  ifx_get_VoiceProfile (&xVoiceProfile,IFX_F_DEFAULT);
  ifx_get_ProfileSignaling(&xVoiceSignaling,IFX_F_DEFAULT);
  ifx_get_DbgSettings(&xDbgSet,IFX_F_DEFAULT);

  /* If the server port is 0 use the default port */
  if(xVoiceSignaling.unUAPort == 0){
		xVoiceSignaling.unUAPort = 5060;			
  }
  
  for(uiCount =0; uiCount<vuiNoOfSrvPrd;uiCount++){
    if((vpxSrvPdrData[uiCount].uiPort == xVoiceSignaling.unUAPort)&&
	   (!strcmp((char8 *)vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.acIPAddr,
	            xVoiceSignaling.acUADomain))){
	     return IFX_SIP_FAILURE;
    }
  }
  for(uiCount =0; uiCount<vuiNoOfSrvPrd;uiCount++){
    if(vpxSrvPdrData[uiCount].uiSrvPrdId ==0 ){
	     break;
	  }
	}	
  vpxSrvPdrData[uiCount].xSipAppCfg.unRegRetryTime =xVoiceSignaling.unRegRetryTime;

  /*Create Stack Instance*/
  if(uiCount >= vuiNoOfSrvPrd){
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
		          "Number of Service Provider Creation Exceded");
	   return IFX_SIP_FAILURE;
  }

  vpxSrvPdrData[uiCount].uiPort = xVoiceSignaling.unUAPort;
  vpxSrvPdrData[uiCount].uiSrvPrdId = uiSrvPdrId;
  if(IFX_SIP_GetStackInstance(&vpxSrvPdrData[uiCount].uiStackHdl)
     !=IFX_SIP_SUCCESS){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
		"Getting Stack Instance Failed");
    vpxSrvPdrData[uiCount].uiSrvPrdId = 0;
    return IFX_SIP_FAILURE;
  }

  /*Configure Stack Instance*/
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Config Stack Instance ");
#ifdef STUN_SUPPORT
  strcpy(vpxSrvPdrData[uiCount].xSipAppCfg.acStunAddr,xVoiceProfile.xStunConfig.acStunServer);
  vpxSrvPdrData[uiCount].xSipAppCfg.unStunPort = xVoiceProfile.xStunConfig.unStunPort;
  vpxSrvPdrData[uiCount].xSipAppCfg.unNatKeepAliveTime = xVoiceProfile.xStunConfig.unNatKeepAliveTime;
#endif     
  strcpy(vpxSrvPdrData[uiCount].xSipAppCfg.acOrganization,xVoiceSignaling.acOrg);
  strcpy(vpxSrvPdrData[uiCount].xSipAppCfg.acUserAgentHdr,xVoiceSignaling.acUserAgentHdr);
	
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.ucOptions = 0xFF;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unServerPort = xVoiceSignaling.unUAPort;
  vpxSrvPdrData[uiCount].xSipAppCfg.ucTransportType = xVoiceSignaling.ucUAProtocol;
	IFX_OS_GetHostIp((char8 *)vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.acIPAddr);
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.ucDbgLvl = xDbgSet.xSipDbg.ucDbgLvl;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.ucDbgType = xDbgSet.xSipDbg.ucDbgType;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.ucDSCPMark = xVoiceSignaling.ucSipDscp;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.ucUseCompactHdrs=xVoiceSignaling.bUseCompactHdrs;
#ifdef RFC_4028
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.uiMinSe=xVoiceSignaling.unInvExpires;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.uiSRNot=5;
#endif	
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unDnsQueryTimeOut=xVoiceSignaling.unDnsQueryTimeOut ;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unServerPort=xVoiceSignaling.unUAPort;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unT1=xVoiceSignaling.unT1;
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unTmax=xVoiceSignaling.unTb;
#ifdef TLS_SUPPORT
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unTlsPort=;
#endif
  vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unLocalIPCPort=IFX_SIPAPP_INTERNAL_PORT;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Configuring Stack");

#ifdef QOS_SUPPORT
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invoking SIP QoS Start");
   sprintf(acCommand,"/etc/rc.d/sip.sh start %s %d  tcp 2> /dev/null",
           vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.acIPAddr, xVoiceSignaling.unUAPort);
   system(acCommand);
   sprintf(acCommand,"/etc/rc.d/sip.sh start %s %d  udp 2> /dev/null",
           vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.acIPAddr,
           vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.unServerPort);
   system(acCommand);
#endif
#ifdef FIREWALL_DRILL
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invoking SIP Firewall add");
    sprintf(acCommand,"/etc/rc.d/port_drill add udp %d 2> /dev/null",xVoiceSignaling.unUAPort);
		system(acCommand);
    sprintf(acCommand,"/etc/rc.d/port_drill add tcp %d 2>/dev/null",xVoiceSignaling.unUAPort);
		system(acCommand);
		if (0 ==iIntPortInitialized){
		sprintf(acCommand,"/etc/rc.d/port_drill intport udp %d",
						(IFX_SIP_INTERNAL_PORT + (vpxSrvPdrData[uiCount].uiStackHdl) ));
		system(acCommand);
		iIntPortInitialized = 1;
	}
#endif
  IFX_SIP_StackConfig(vpxSrvPdrData[uiCount].uiStackHdl,
									    &vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg);
#endif

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Registering Callbacks with the Stack");
  /* Register All Call backs here*/
  IFX_SIPAPP_RegisterCCCB(vpxSrvPdrData[uiCount].uiStackHdl);


  /*Register Options Callbacks*/
  //IFX_SIPAPP_OptionsRegCallbacks(vpxSrvPdrData[uiCount].uiStackHdl);


#ifdef MESSAGE_SUPPORT 
  /* Register Message Callbacks*/
  IFX_SIPAPP_InstMsgRegCallbacks(vpxSrvPdrData[uiCount].uiStackHdl);
#endif	

  /*Register MWI Events Callbacks*/
  IFX_SIPAPP_MWIPkgInit(vpxSrvPdrData[uiCount].uiStackHdl);

  /* Refer Event Callbacks*/
  IFX_SIPAPP_REFPkgInit(vpxSrvPdrData[uiCount].uiStackHdl);

  /*Call back Event */
  IFX_SIPAPP_CBPkgInit(vpxSrvPdrData[uiCount].uiStackHdl);

  /* Register Callbacks*/
  IFX_SIP_RegisterREGCallbacks(vpxSrvPdrData[uiCount].uiStackHdl);	 
 IFX_SIPAPP_OptionsRegCallbacks(vpxSrvPdrData[uiCount].uiStackHdl);

#ifdef STUN_SUPPORT
   /* If STUN is on get the mapped port for server port */
   if(vpxSrvPdrData[uiCount].xSipAppCfg.acStunAddr[0] != '\0') {
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
     "STUN Support Enabled - Starting NAT discovery and address resolution\n");
     xstuninfo.iNATType=IFX_SIPAPP_NAT_NOT_DETECTED;
		 if(strlen(vpxSrvPdrData[uiCount].xSipAppCfg.xParamCfg.acIPAddr)<15){
       strcpy(xstuninfo.uacLocalIPAddr,vpxSrvPdrData[uiCount].xSipAppCfg.
					    xParamCfg.acIPAddr);
		 }
     strcpy((xstuninfo.uacSTUNServerAddr),IFX_SIPAPP_GET_STUNADDR(uiCount));
	 if(IFX_SIPAPP_ValidateIPv4Addr(xstuninfo.uacSTUNServerAddr)!= IFX_SIP_SUCCESS){
	    struct hostent *pxIpv4Addr=NULL;
	    struct in_addr xSinAddr;
	    pxIpv4Addr = gethostbyname(xstuninfo.uacSTUNServerAddr);
			if(pxIpv4Addr){
		    xSinAddr = *(struct in_addr *)pxIpv4Addr->h_addr;
		    strcpy(vpxSrvPdrData[uiCount].xSipAppCfg.acStunAddr,inet_ntoa(xSinAddr));
			}
	 }else{
	     strcpy(vpxSrvPdrData[uiCount].xSipAppCfg.acStunAddr,xstuninfo.uacSTUNServerAddr);
	 }
					
	 xstuninfo.unStunServPort = IFX_SIPAPP_GET_STUNPORT(uiCount);
   xstuninfo.ucNumofPorts=1;
	 /* xstuninfo.iSTUNId=IFX_SIP_STUN_REG_QUERY;*/
	 xstuninfo.unLocalPort[0]=IFX_SIPAPP_GET_SERVERPORT(uiCount);
     eRetVal=IFX_SIPAPP_STUNCrtProcess(&xstuninfo,IFX_SIPAPP_STUNServerPortRsp,
                                      4,&uiCount,&iStunId);
     if(eRetVal != IFX_SIP_SUCCESS){
       return IFX_SIP_FAILURE;
     }
	   IFX_SIPAPP_RecvStunTimerMsgs(NULL,NULL,NULL,0);
   } 
  else 
#endif
  {
     /* Init the Stack in Async Mode */
     if( viStackMode == IFX_SIP_ASYNC_MODE )
     {					
	   if (IFX_SIP_Init(vpxSrvPdrData[uiCount].uiStackHdl,
           NULL) == IFX_SIP_FAILURE) {
   
   	      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "Stack Init Failed");
			   vpxSrvPdrData[uiCount].uiSrvPrdId =0;  
    	    return IFX_SIP_FAILURE;
  	   }
  	   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                "Stack Init success");
     }
     /* Init the Stack in Sync Mode */
     else if( viStackMode == IFX_SIP_SYNC_MODE)
     {
       memset(&xSyncCallbks,0,sizeof(x_IFX_SIP_SyncCallBks));
	   xSyncCallbks.pfnAddFDToSelect = IFX_SIPAPP_AddFDToSelect;
	   xSyncCallbks.pfnRemoveFDToSelect = IFX_SIPAPP_RemoveFDToSelect;
										
  	   if (IFX_SIP_Init_Sync(vpxSrvPdrData[uiCount].uiStackHdl,
	       NULL,&xSyncCallbks) == IFX_SIP_FAILURE) {
      	
    	 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                  "Stack Init Failed");
			   vpxSrvPdrData[uiCount].uiSrvPrdId =0;  
         return IFX_SIP_FAILURE;
  	  }
  	  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Stack Init success");
     }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_DestroySrvPdr 
*  Description      :  This is destroys Stack Instance.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_DestroySrvPdr(IN uint32 uiSrvPdrId)
{  
  uint32 uiCount1=0;
  int32 iCount=0;
  
  x_IFX_SIPAPP_UAAppData *pxTemp = vxAppDataPool.pxAppDataHead,*pxTemp1=NULL;
  

  iCount =IFX_SIPAPP_GetSrvPdrInst(uiSrvPdrId);
  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Destroying Service Provider");
#ifdef QOS_SUPPORT
if(iCount>=0){
		char acCommand[512] = "";
    x_IFX_SIPAPP_ParamCfg *pxParamCfg = &vpxSrvPdrData[iCount].xSipAppCfg;
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invoking SIP QoS Stop");
   sprintf(acCommand,"/etc/rc.d/sip.sh stop %s %d  tcp 2> /dev/null",pxParamCfg->xParamCfg.acIPAddr,
					  pxParamCfg->xParamCfg.unServerPort);
   system(acCommand);
   sprintf(acCommand,"/etc/rc.d/sip.sh stop %s %d  udp 2> /dev/null",pxParamCfg->xParamCfg.acIPAddr,
					  pxParamCfg->xParamCfg.unServerPort);
   system(acCommand);
   }
#endif
#ifdef FIREWALL_DRILL
if (iCount>=0){
		char acCommand[512] = "";
    x_IFX_SIPAPP_ParamCfg *pxParamCfg = &vpxSrvPdrData[iCount].xSipAppCfg;
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invoking SIP Firewall del");
    sprintf(acCommand,"/etc/rc.d/port_drill del tcp %d 2> /dev/null",pxParamCfg->xParamCfg.unServerPort);
    system(acCommand);

    sprintf(acCommand,"/etc/rc.d/port_drill del udp %d 2> /dev/null",pxParamCfg->xParamCfg.unServerPort);
    system(acCommand);
   }


#endif
  if(iCount >= 0){
     IFX_SIP_StackDestroy(vpxSrvPdrData[iCount].uiStackHdl,0);
	
     /* Clear Service Provider Specific App Data*/
     while(pxTemp != NULL){
	   pxTemp1 = pxTemp;
       __ifx_list_GetNext((void *)&pxTemp1);
	   if((uint32)pxTemp->iProfileId == uiSrvPdrId){
          for (uiCount1=0; uiCount1<IFX_SIPAPP_UA_MAX_HDLS; uiCount1++) {
	          if(pxTemp->auiHdl[uiCount1] != 0){
                IFX_SIPAPP_RemoveAppData(pxTemp,uiCount1); 
	          }                     
          }
       }
       pxTemp = pxTemp1;
	 }
	 /*Clear Registration*/
	 IFX_SIPAPP_RemoveRegForSrvPdr(uiSrvPdrId);

     memset(&vpxSrvPdrData[iCount],0,sizeof(x_IFX_SIPAPP_SrvPrd));

	 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Destroy Service Provider success");
	 return IFX_SIP_SUCCESS;
  }
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Destroy Service Provider Fail");
  return IFX_SIP_FAILURE;
}

/******************************************************************
*  Function Name    :  IFX_SIPAPP_CfgSrvPdr 
*  Description      :  This is to Configure Stack Instance.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return IFX_SIPAPP_CfgSrvPdr(IN uint32 uiSrvPdrId,
      			                                 IN uchar8 ucOptions,...)
{
 int32 iCount = IFX_SIPAPP_GetSrvPdrInst(uiSrvPdrId);
#ifndef IFX_CALLMGR
  va_list xVarList;
  x_IFX_SIPAPP_ParamCfg *pxParamCfg;
  va_start(xVarList,ucOptions);
  pxParamCfg = va_arg(xVarList,x_IFX_SIPAPP_ParamCfg *);
  if(iCount<0){
	  for(iCount =0; (uint32)iCount<vuiNoOfSrvPrd;iCount++){
	    if((vpxSrvPdrData[iCount].uiPort == pxParamCfg->xParamCfg.unServerPort)&&
		   (!strcmp(vpxSrvPdrData[iCount].xSipAppCfg.xParamCfg.acIPAddr,
		           pxParamCfg->xParamCfg.acIPAddr))){
	      return IFX_SIP_FAILURE;
	    }
	  }
	  for(iCount =0; (uint32)iCount<vuiNoOfSrvPrd;iCount++){
        if(vpxSrvPdrData[iCount].uiSrvPrdId ==0 ){
	      break;
	    }
	  }

	  vpxSrvPdrData[iCount].uiPort = pxParamCfg->xParamCfg.unServerPort;
    /*Create Stack Instance*/
    if((uint32)iCount >= vuiNoOfSrvPrd){
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
		            "Number of Service Provider Creation Exceded");
	     return IFX_SIP_FAILURE;
	  }

    vpxSrvPdrData[iCount].uiSrvPrdId = uiSrvPdrId;
    if(IFX_SIP_GetStackInstance(&vpxSrvPdrData[iCount].uiStackHdl)
       !=IFX_SIP_SUCCESS){
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
		        "Getting Stack Instance Failed");
       vpxSrvPdrData[iCount].uiSrvPrdId = 0;
       return IFX_SIP_FAILURE;
	  }
    
  }
  memcpy(&vpxSrvPdrData[iCount].xSipAppCfg,pxParamCfg,sizeof(x_IFX_SIPAPP_ParamCfg));
  
  IFX_SIP_StackConfig(vpxSrvPdrData[iCount].uiStackHdl,&pxParamCfg->xParamCfg);

  IFX_SIPAPP_DbgInit(pxParamCfg->xParamCfg.ucDbgLvl,
                     pxParamCfg->xParamCfg.ucDbgType);

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Service Provider Configuration Success");

#ifdef STUN_SUPPORT
	strcpy(vpxSrvPdrData[iCount].xSipAppCfg.acStunAddr,pxParamCfg->acStunAddr);
	vpxSrvPdrData[iCount].xSipAppCfg.unStunPort = pxParamCfg->unStunPort;
	vpxSrvPdrData[iCount].xSipAppCfg.unNatKeepAliveTime = pxParamCfg->unNatKeepAliveTime;
#endif
	

#else
   x_IFX_VMAPI_VoiceProfile xVoiceProfile;
   x_IFX_VMAPI_ProfileSignaling xVoiceSignaling;
   x_IFX_SIP_StackParamCfg xParamCfg;
	 x_IFX_VMAPI_SystemDebugSettings xDbgSet;
   memset(&xDbgSet,0,sizeof(x_IFX_VMAPI_SystemDebugSettings));
	 ifx_get_DbgSettings(&xDbgSet,IFX_F_DEFAULT);
	 
   IFX_SIPAPP_DbgInit(xDbgSet.xSipDbg.ucDbgLvl,
                      xDbgSet.xSipDbg.ucDbgType);
	 if((ucOptions != IFX_SIPAPP_DBGCFG)&&(ucOptions != 0)){
     xVoiceSignaling.ucProfileId = uiSrvPdrId;
     xVoiceProfile.ucProfileId = uiSrvPdrId;
     ifx_get_VoiceProfile (&xVoiceProfile,IFX_F_DEFAULT);
     ifx_get_ProfileSignaling(&xVoiceSignaling,IFX_F_DEFAULT);
	 }
   switch(ucOptions)
   {
#ifdef STUN_SUPPORT					 
	case IFX_SIPAPP_STUNCFG:
		strcpy(vpxSrvPdrData[iCount].xSipAppCfg.acStunAddr,xVoiceProfile.xStunConfig.acStunServer);
		vpxSrvPdrData[iCount].xSipAppCfg.unStunPort = xVoiceProfile.xStunConfig.unStunPort;
		vpxSrvPdrData[iCount].xSipAppCfg.unNatKeepAliveTime = xVoiceProfile.xStunConfig.unNatKeepAliveTime;
	 break;
#endif	 
	case IFX_SIPAPP_STACKCFG:
		strcpy(vpxSrvPdrData[iCount].xSipAppCfg.acOrganization,xVoiceSignaling.acOrg);
    strcpy(vpxSrvPdrData[iCount].xSipAppCfg.acUserAgentHdr,xVoiceSignaling.acUserAgentHdr);
		vpxSrvPdrData[iCount].xSipAppCfg.ucTransportType = xVoiceSignaling.ucUAProtocol;
    vpxSrvPdrData[iCount].xSipAppCfg.unRegRetryTime =xVoiceSignaling.unRegRetryTime;
		xParamCfg.unServerPort = xVoiceSignaling.unUAPort;
    IFX_OS_GetHostIp((char8 *)xParamCfg.acIPAddr);
    xParamCfg.ucDbgLvl =xDbgSet.xSipDbg.ucDbgLvl;
    xParamCfg.ucDbgType =xDbgSet.xSipDbg.ucDbgType;
    xParamCfg.ucDSCPMark = xVoiceSignaling.ucSipDscp;
    xParamCfg.ucUseCompactHdrs=xVoiceSignaling.bUseCompactHdrs ;
#ifdef RFC_4028				
    xParamCfg.uiMinSe=xVoiceSignaling.unInvExpires;
    xParamCfg.uiSRNot=5;
#endif				
    xParamCfg.unDnsQueryTimeOut=xVoiceSignaling.unDnsQueryTimeOut ;
    xParamCfg.unLocalIPCPort=IFX_SIPAPP_INTERNAL_PORT;
    xParamCfg.unServerPort=xVoiceSignaling.unUAPort;
    xParamCfg.unT1=xVoiceSignaling.unT1;
    xParamCfg.unTmax=xVoiceSignaling.unTb;
    /*StackCfg will upadte all changes*/
		xParamCfg.ucOptions = 0xFF;
#ifdef TLS_SUPPORT
    xParamCfg.unTlsPort=;
#endif
		memcpy(&vpxSrvPdrData[iCount].xSipAppCfg.xParamCfg,
			   &xParamCfg,sizeof(xParamCfg));
        IFX_SIP_StackConfig(vpxSrvPdrData[iCount].uiStackHdl,&xParamCfg);
				break;
/*				
	 case IFX_SIPAPP_DOMAIN:
	   strcpy(vpxSrvPdrData[iCount].xSipAppCfg.xParamCfg.acIPAddr,
	            xVoiceSignaling.acUADomain);
	 break;			*/
	 case IFX_SIPAPP_DBGCFG:			
	 default:
        xParamCfg.ucDbgLvl =xDbgSet.xSipDbg.ucDbgLvl;
        xParamCfg.ucDbgType =xDbgSet.xSipDbg.ucDbgType;
				xParamCfg.ucOptions = IFX_SIP_CFG_DEBUG;
				IFX_SIP_StackConfig(vpxSrvPdrData[iCount].uiStackHdl,&xParamCfg);
#ifdef MEM_DBG
				IFX_OS_MemInfo();
#endif
   }
#endif
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Config Service Provider Success");
   return IFX_SIP_SUCCESS;
	 
}

/******************************************************************
*  Function Name    :  IFX_SIPAPP_RegNotfiers 
*  Description      :  This is to notify the App about the states.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SIP_SUCCESS/IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_RegNotfiers( x_IFX_SIPAPP_Notifiers *pxNotifier)
{
	memcpy(&vpxNotifier,pxNotifier,sizeof(x_IFX_SIPAPP_Notifiers));
	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Callbacks with the Above App registered");
	return IFX_SIP_SUCCESS;
}

