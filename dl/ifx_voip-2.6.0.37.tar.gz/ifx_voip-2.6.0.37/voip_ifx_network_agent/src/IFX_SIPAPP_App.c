/****************************************************************************
**   FILE NAME     : IFX_SIPAPP_App.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains utility functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_DlgApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Config.h"
#include "ifx_list.h"


extern uchar8 vcSipAppModId;
x_IFX_SIPAPP_UAAppDataPool vxAppDataPool;

/************************************************************************
* Function Name  : IFX_SIPAPP_CreateNAddAppData
* Description    : This function will create AppData and adds it to pool
* Input Values   : App data pool
* Output Values  : address of App data node created, error if any
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_CreateNAddAppData(IN_OUT x_IFX_SIPAPP_UAAppData **ppxAppData,
                             OUT e_IFX_SIP_Ecode *peEcode)
{
    int32 uiErrorCode;
    
    if (vxAppDataPool.iAppDataCount >= vxAppDataPool.iMaxAppData){
       IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Max App data reached");               
       return IFX_SIP_FAILURE;
    }
    
    /* Add to App Data to pool*/
    __ifx_list_add_front((void *)&vxAppDataPool.pxAppDataHead,
                         (void *)ppxAppData,
                         sizeof(x_IFX_SIPAPP_UAAppData),&uiErrorCode);
    if ( uiErrorCode < 0){
       IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Create Endpoint Failure");       
       *peEcode = IFX_SIP_TU_MEMORY_ERROR;       
       return IFX_SIP_FAILURE;
    }
    
    /* Increment App data count*/
    vxAppDataPool.iAppDataCount++;
    
    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "App Data Creation Success");
    
    return IFX_SIPAPP_AppDataInit(*ppxAppData);
}

/************************************************************************
* Function Name  : IFX_SIPAPP_RemoveAppData
* Description    : This function will remove App Data from the pool.
* Input Values   : Pool ptr and App Data ptr along with the type
* Output Values  : None
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_RemoveAppData(IN x_IFX_SIPAPP_UAAppData *pxAppData, 
                         IN e_IFX_SIPAPP_UA_HdlTypes eHdlType)
{
  int32 iCount;
  pxAppData->auiHdl[eHdlType] = 0;
  for (iCount=0; iCount<IFX_SIPAPP_UA_MAX_HDLS; iCount++) {
    if(pxAppData->auiHdl[iCount] != 0){
      IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Not removed as its being used by someone else");
      return IFX_SIP_SUCCESS;
    }
  }

  if(vxAppDataPool.pxAppDataHead == NULL){
    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Remove App Data Failure");
    return IFX_SIP_FAILURE;
  }
  IFX_SIPAPP_AppDataFree(pxAppData);

  __ifx_list_del((void *)&(vxAppDataPool.pxAppDataHead),(void *)pxAppData);

  /* Decrement App data Count */
  vxAppDataPool.iAppDataCount--;

  IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Remove APP Data Success");

  return IFX_SIP_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_SIPAPP_GetAppData
* Description    : This function will get APP Data from the APPData
*                  pool given the connection Identifier.
* Input Values   : Pool ptr and App Data ptr
* Output Values  : None
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetAppData(IN uint32 uiConnId,
                      OUT x_IFX_SIPAPP_UAAppData **ppxAppData)
{
  *ppxAppData = vxAppDataPool.pxAppDataHead;
  
  if(*ppxAppData == NULL){
    IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "No AppData in the pool");
    return IFX_SIP_FAILURE;
  }
  
  /* Search and get the appdata */
  while(*ppxAppData){
    if((*ppxAppData)->iConnId == uiConnId){
	  IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "APP Data Found Success");
      return IFX_SIP_SUCCESS;
    }
    __ifx_list_GetNext((void **)ppxAppData);
  }
  return IFX_SIP_FAILURE;
}

/************************************************************************
* Function Name  : IFX_SIPAPP_GetConnId
* Description    : This function will get iConnId Data of matching dialog 
*                  from the APPData pool.
* Input Values   : Call Id, From tag, To Tag
* Output Values  : Connection IDentifier
* Return Value   : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetConnId(IN char8 *pcCallId,
                     IN char8 *pcToTag,
                     IN char8 *pcFromTag,
                     OUT uint32 *puiConnId)
{
  x_IFX_SIPAPP_UAAppData *pxAppData=NULL;

  /*Validation on the request*/
  if ( pcCallId == NULL || pcToTag == NULL || pcFromTag == NULL){
      IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Input paramters are NULL");
	  return IFX_SIP_FAILURE;
  }

  pxAppData = vxAppDataPool.pxAppDataHead;
  if(pxAppData == NULL)
  {
    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "No AppData in the pool");
    return IFX_SIP_FAILURE;
  }
  /* Search and get the endpoint */
  while(pxAppData)
  {
    if((!strcmp(pcCallId, pxAppData->szCallId)) &&
       (!strcmp(pcToTag, pxAppData->szRemoteTag)) &&
       (!strcmp(pcFromTag, pxAppData->szLocalTag)))
    {
      *puiConnId = (pxAppData)->iConnId;
      return IFX_SIP_SUCCESS;
    }
    __ifx_list_GetNext((void *)&pxAppData);
  }
  return IFX_SIP_FAILURE;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_AppDataInit
*  Description    : This function initializes the Data being maintained
*                   by the user agent application
*  Input Values   : pxAppData - Pointer to the Application Data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AppDataInit(IN x_IFX_SIPAPP_UAAppData* pxAppData)
{
  pxAppData->iFlag = 0;
  pxAppData->iConnId2 = 0;
  pxAppData->xSdpInfo.unDtmfPT = 0;
  pxAppData->xSdpInfo.uiSdpMsgHdl = 0;
  memset(&(pxAppData->xFrom), 0, sizeof(x_IFX_CalledAddr));
  memset(&(pxAppData->xTo), 0, sizeof(x_IFX_CalledAddr));
  memset(&pxAppData->xSdpInfo.xRtpInfo, 0, sizeof(x_IFX_SIPAPP_RtpInfo));
  pxAppData->xSdpInfo.ucNumRemCap = 0;
  memset(pxAppData->xSdpInfo.xRemCap, 0,
         (IFX_MAX_CODECS* sizeof(x_IFX_RemCapInfo)));
  pxAppData->xSdpInfo.nLockedCodecEntry = -1;  
#ifdef FAX_SUPPORT
  pxAppData->xSdpInfo.pxT38Capab = NULL;
#endif
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "App Data Init Success");

  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_AppDataFree
*  Description    : This function Frees the Data being maintained 
*                   by the user agent application 
*  Input Values   : pxAppData - Pointer to the Application Data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AppDataFree(IN x_IFX_SIPAPP_UAAppData* pxAppData)
{
 
  if(pxAppData->xSdpInfo.uiSdpMsgHdl != 0){
    IFX_SDP_FreeMsg(pxAppData->xSdpInfo.uiSdpMsgHdl);
    pxAppData->xSdpInfo.uiSdpMsgHdl = 0;
  }
 
#ifdef FAX_SUPPORT
  if(pxAppData->xSdpInfo.pxT38Capab != NULL){
    IFX_OS_Free(pxAppData->xSdpInfo.pxT38Capab);
  }
#ifdef STUN_SUPPORT
	IFX_SIPAPP_StopTimer(pxAppData->xSdpInfo.xRtpInfo.unNATKAFAXPortId);
#endif	
#endif
#ifdef STUN_SUPPORT
	IFX_SIPAPP_StopTimer(pxAppData->xSdpInfo.xRtpInfo.unNATKARTPPortId);
#endif	

  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_ConvRegAddrToStr
*  Description    : This function converts Called addr into String
*  Input Values   : pxCalledAddr and pcTo
*  Output Values  : Address in String format
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/

void IFX_SIPAPP_ConvRegAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                 OUT char8 *pcTo)
{
  uint16 unPort = 5060;
  if(pxCalledAddr->unPort != 0)
  {
    unPort = pxCalledAddr->unPort;
  }
  switch(pxCalledAddr->ucAddrProto){
    case IFX_TRPROTO_TLS:
      sprintf(pcTo,"sips:%s:%d;transport=TLS",pxCalledAddr->acCalledAddr,unPort);
	  break;
    case IFX_TRPROTO_UDP:
      sprintf(pcTo,"sip:%s:%d;transport=UDP",pxCalledAddr->acCalledAddr,unPort);
      break;
    case IFX_TRPROTO_TCP:
      sprintf(pcTo,"sip:%s:%d;transport=TCP",pxCalledAddr->acCalledAddr,unPort);
	  break;
	default:
	  sprintf(pcTo,"sip:%s:%d",pxCalledAddr->acCalledAddr,unPort);
  }
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_ConvCalAddrToStr
*  Description    : This function converts Called addr into nameaddr 
*                   String
*  Input Values   : pxCalledAddr and pcTo
*  Output Values  : pcTo
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/
void 
IFX_SIPAPP_ConvCalAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                            IN_OUT char8 *pcTo)
{
  uint16 unPort = 5060;
  if(pxCalledAddr->unPort != 0)
  {
    unPort = pxCalledAddr->unPort;
  }
  if(pxCalledAddr->ucAddrProto == IFX_TRPROTO_TLS){
		if(pxCalledAddr->acUserName[0]!='\0'){		
      sprintf(pcTo,"%s<sips:%s@%s:%d",pxCalledAddr->acDisplayName,
            pxCalledAddr->acUserName,pxCalledAddr->acCalledAddr,unPort);
		}
		else{
      sprintf(pcTo,"%s<sips:%s:%d",pxCalledAddr->acDisplayName,
            pxCalledAddr->acCalledAddr,unPort);
		}
	}
	else{
		if(pxCalledAddr->acUserName[0]!='\0'){		
      sprintf(pcTo,"%s<sip:%s@%s:%d",pxCalledAddr->acDisplayName,
            pxCalledAddr->acUserName,pxCalledAddr->acCalledAddr,unPort);
		}
		else{
      sprintf(pcTo,"%s<sip:%s:%d",pxCalledAddr->acDisplayName,
              pxCalledAddr->acCalledAddr,unPort);
		}
	}
	if(unPort == 5060){
		pcTo[strlen(pcTo)-5]='\0';
	}
  switch(pxCalledAddr->ucAddrProto){
    case IFX_TRPROTO_TLS:
      strcat(pcTo,";transport=TLS>");
	    break;
    case IFX_TRPROTO_UDP:
      strcat(pcTo,";transport=UDP>");
      break;
    case IFX_TRPROTO_TCP:
      strcat(pcTo,";transport=TCP>");
	    break;
	  default:
			strcat(pcTo,">");
			break;
  }
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_ConvUsrCfgToStr
*  Description    : This function converts User cfg data into String 
*  Input Values   : pxUsrCfg and pcFrom
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/
void IFX_SIPAPP_ConvUsrCfgToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                OUT char8 *pcFrom)
{
  sprintf(pcFrom,"%s<sip:%s@%s>",pxCalledAddr->acDisplayName,
          pxCalledAddr->acUserName,pxCalledAddr->acCalledAddr);
            
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_ConvReferAddrToStr
*  Description    : This function converts Called addr into String
*  Input Values   : pxCalledAddr and pcTo
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/

void IFX_SIPAPP_ConvReferAddrToStr(IN x_IFX_CalledAddr *pxCalledAddr,
                                   OUT char8 *pcTo)
{
  uint16 unPort = 5060;
  if(pxCalledAddr->unPort != 0){
    unPort = pxCalledAddr->unPort;
  }
  /* Fix for cisco to avoid nameaddr format in case of UDP */
  if((pxCalledAddr->ucAddrProto != IFX_TRPROTO_TLS) &&
     (pxCalledAddr->ucAddrProto != IFX_TRPROTO_TCP)){
    sprintf(pcTo,"%s:%s@%s:%d","sip",
            pxCalledAddr->acUserName,pxCalledAddr->acCalledAddr,unPort);
    return;
  }
  else{
   IFX_SIPAPP_ConvCalAddrToStr(pxCalledAddr,pcTo);
   return ;
  }
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_RespCode
*  Description    :  this function maps the status code with the Resp
*                    code enumerations
*  Input Values   :  nStatusCode is the status code
*  Output Values  :  None
*  Return Value   :  Response code enumeration
*  Notes      : 
*********************************************************************/
e_IFX_SIPAPP_RespCodes
IFX_SIPAPP_MapRespCode(int16 nStatusCode)
{
 
	if((nStatusCode > 99) && (nStatusCode < 200)){
	      return IFX_SIPAPP_1XX_RESP;
	}
	else if((nStatusCode > 199) && (nStatusCode < 300)){
		return IFX_SIPAPP_2XX_RESP;
	}
	else if((nStatusCode > 299) && (nStatusCode < 400)){
		return IFX_SIPAPP_3XX_RESP;
	}
	else if((nStatusCode > 399) && (nStatusCode < 500)){
		return IFX_SIPAPP_4XX_RESP;
	}
	else if((nStatusCode > 499) && (nStatusCode < 600)){
		return IFX_SIPAPP_5XX_RESP;
	}
	else if((nStatusCode > 599) && (nStatusCode < 700)){
		return IFX_SIPAPP_6XX_RESP;
	}
    return IFX_SIPAPP_6XX_RESP;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_SetContact
*  Description    :  this function sets the contact header
*  Input Values   :  pcFrom From user
*                    uiMsgHdl Message handle where contact header has to be added
*                    uiSrvPdrId is the serv ice provoider ID
*  Output Values  :  uiMsgHdl with contact header included
*  Return Value   :  IFX_SIP_SUCCESS
*           	     IFX_SIP_FAILURE
*  Notes          :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetContact(IN char8 *pcFrom,
                      OUT uint32 uiMsgHdl,
					            IN uint32 uiSrvPdrId)
{
  char8 acIp[IFX_MAX_TSP_ADDR],*pcTemp=NULL;
  uint32 uiHdrHdl=0;
  uint32 uiAddrType=0;
  uint32 uiAddrSpec=0;
  uint32 uiSipUri=0;
  uint16 unPort;
  e_IFX_SIP_Return eRetVal =IFX_SIP_SUCCESS;
  uint32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(uiSrvPdrId);
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_SIPAPP_SetContact> Entered\n");
#ifndef IFX_CALLMGR
  strcpy(acIp,vpxSrvPdrData[uiCfgInst].xSipAppCfg.xParamCfg.acIPAddr);
#else
  IFX_OS_GetHostIp(acIp);
#endif
#ifdef STUN_SUPPORT
  if (IFX_SIPAPP_IS_STUNON(uiCfgInst)) {
    strcpy(acIp,vpxSrvPdrData[uiCfgInst].acMappedAddr);
    unPort = vpxSrvPdrData[uiCfgInst].unSIPMappedPort;
  }
  else {
    unPort = IFX_SIPAPP_GET_SERVERPORT(uiCfgInst);
  }
#else
  unPort = IFX_SIPAPP_GET_SERVERPORT(uiCfgInst);
#endif

  eRetVal = IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT,&uiHdrHdl);
  if(eRetVal != IFX_SIP_SUCCESS){
    return eRetVal;
  }

  uiAddrType=IFX_SIP_Contact_GetAddressType(uiHdrHdl);
  IFX_SIP_AddrType_SetValue(uiAddrType,pcFrom);
  uiAddrSpec=IFX_SIP_AddressType_GetAddrSpec(uiAddrType);
  uiSipUri = IFX_SIP_Addrspec_GetSipUri(uiAddrSpec);
  if((pcTemp=IFX_SIP_SipUri_GetHost(uiSipUri)))
  {
    IFX_SIPAPP_Free(pcTemp);
  }
  IFX_SIP_SipUri_SetHost(uiSipUri,acIp);
  IFX_SIP_SipUri_SetPort(uiSipUri, unPort);
  if(IFX_SIPAPP_GET_SERVERTRANSPORT(uiCfgInst) == IFX_TRPROTO_UDP)
  {
      IFX_SIP_SipUri_SetTransportParam(uiSipUri,"udp");
  }else if( IFX_SIPAPP_GET_SERVERTRANSPORT(uiCfgInst) == IFX_TRPROTO_TCP){
      IFX_SIP_SipUri_SetTransportParam(uiSipUri,"tcp");
  }
  else if( IFX_SIPAPP_GET_SERVERTRANSPORT(uiCfgInst) == IFX_TRPROTO_TLS){
      IFX_SIP_SipUri_SetTransportParam(uiSipUri,"tls");
  }
	if(IFX_SIP_GetMessageType(uiMsgHdl)== IFX_SIP_REQUEST){
    eRetVal	= IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_FROM,1,&uiHdrHdl);
	  uiHdrHdl = IFX_SIP_From_GetAddressType(uiHdrHdl);
	  pcTemp = IFX_SIP_AddressType_GetDisplayName(uiHdrHdl);	
	  if((pcTemp!=NULL)&&((strcasecmp(pcTemp,"anonymous")==0)||
			 (strcasecmp(pcTemp,"\"anonymous\"")==0))){
#ifdef RFC_3325
  /*Setting Privacy Headers*/
		 	 eRetVal = IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_PRIVACY,&uiHdrHdl);
			 IFX_SIP_Privacy_SetValue(uiHdrHdl,"header");
	/*Removing the User name of Contact*/
			 IFX_SIP_SipUri_SetUser(uiSipUri,NULL);
#endif /*RFC_3325*/
	  }
	}
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_SIPAPP_SetContact> Exited");
   
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_SetAllow
*  Description    : This function sets the allow header
*  Input Values   : uiMsgHdl is the message handle
*  Output Values  : uiMsgHdl is the message handle
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAllow(IN_OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"INVITE");
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"ACK");
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"CANCEL");
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"BYE");
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"REFER");
#if 0
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"OPTIONS");
#endif
#ifdef MESSAGE_SUPPORT
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"MESSAGE");
#endif
#ifdef INFO_SUPPORT
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"INFO");
#endif
#ifdef RFC_3311
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"UPDATE");
#endif
#ifdef RFC_3262 
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"PRACK");
#endif
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"SUBSCRIBE");
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,&uiHdrHdl);
  IFX_SIP_Allow_SetMethod(uiHdrHdl,"REGISTER");
  return IFX_SIP_SUCCESS;
}
/******************************************************************
 *  Function Name  : IFX_SIPAPP_SetUserAgent
 *  Description    : This function sets the user agent header
 *  Input Values   : uiMsgHdl is the message handle, Service provider Id
 *                   to get input value from configuration
 *  Output Values  : uiMsgHdl is the message handle
 *  Return Value   : IFX_SIP_SUCCESS
 *                   IFX_SIP_FAILURE
 *  Notes          :
 *********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetUserAgent(IN_OUT uint32 uiMsgHdl,
						IN uint32 uiSrvPdrId)
{
  uint32 uiHdrHdl=0;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  int32 iCfgInst = IFX_SIPAPP_GetSrvPdrInst(uiSrvPdrId);
	if(iCfgInst == -1){
		iCfgInst = 0;
	}
  eRetVal = IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_USER_AGENT,&uiHdrHdl);
  if(eRetVal != IFX_SIP_SUCCESS){
    return eRetVal;
  }
  IFX_SIP_Server_SetProduct(uiHdrHdl,IFX_SIPAPP_GET_UAHDR(iCfgInst));
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name  :  IFX_SIPAPP_SetContentDisposition
*  Description    :  this function sets the content disposition header
*  Input Values   :  uiMsgHdl is the message handle
*  Output Values  :  uiMsgHdl is the message handle
*  Return Value   :  IFX_SIP_SUCCESS
*           		 IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetContentDisposition(IN_OUT uint32 uiMsgHdl)
{

  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_DISPOSTION,&uiHdrHdl);
  IFX_SIP_ContentDisposition_SetDispositionType(uiHdrHdl,"session");
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name  : IFX_SIPAPP_SetContentType
*  Description    : This function sets the content type header
*  Input Values   : uiMsgHdl is the message handle, pcType is subtype 
*  Output Values  : uiMsgHdl is the message handle
*  Return Value   : IFX_SIP_SUCCESS
*           		IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetContentType(IN char8 *pcMType,
						  IN char8 *pcMSubtype,
                          IN_OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,&uiHdrHdl);
  IFX_SIP_ContType_SetMType(uiHdrHdl,pcMType);
  IFX_SIP_ContType_SetMSubType(uiHdrHdl, pcMSubtype);
  return IFX_SIP_SUCCESS;

}


/******************************************************************
*  Function Name  :  IFX_SIPAPP_SetAcceptLanguage
*  Description    :  this function sets the accept Language header
*  Input Values   :  uiMsgHdl is the message handle
*  Output Values  :  uiMsgHdl is the message handle
*  Return Value   :  IFX_SIP_SUCCESS
*                    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAcceptLanguage(IN_OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ACCEPT_LANGUAGE,&uiHdrHdl);
  IFX_SIP_AcceptLang_SetLang(uiHdrHdl,"en");
  return IFX_SIP_SUCCESS;


}
/******************************************************************************
* Function Name  : IFX_SIPAPP_SetExpires
* Description    : This function will create Expire header with the information
*                  specified.
* Input Values   : Sip Message, Expires duration
* Output Values  : Sip Message with expires header
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes          :
* *****************************************************************************/

PUBLIC e_IFX_SIP_Return  
IFX_SIPAPP_SetExpires(IN uint32 uiExpires,
                      IN_OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_EXPIRES,&uiHdrHdl);
  IFX_SIP_Expires_SetValue(uiHdrHdl,uiExpires);
  return IFX_SIP_SUCCESS;

}

/******************************************************************
*  Function Name  : IFX_SIPAPP_SetMinExpiresHdr
*  Description    : Adds a Min-Expires header to the sip message
*  Input Values   : Sip Message, Min-Expires duration
*  Output Values  : Sip Message with Min-Expires header
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetMinExpiresHdr(IN uint32 uiMinExpiry,
                            IN_OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_MIN_EXPIRES,&uiHdrHdl);
  IFX_SIP_MinExpires_SetValue(uiHdrHdl,uiMinExpiry);
  return IFX_SIP_SUCCESS;

}
/******************************************************************
*  Function Name  : IFX_SIPAPP_SetAllowEventsHdr
*  Description    : Adds the Allow-Events header to the sip message
*  Input Values   : Sip Message
*                   pcAllowEvents ... String containing comma seperated 
*                                     supported events
*  Output Values  : Sip Message with allow-events header
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAllowEventsHdr(IN_OUT uint32 uiMsgHdl,
                             IN char8 *pcAllowEvents)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW_EVENTS,&uiHdrHdl);
  IFX_SIP_AllowEvents_SetPackage(uiHdrHdl,pcAllowEvents);
  return IFX_SIP_SUCCESS;

}
/************************************************************************
* Function Name  : IFX_SIPAPP_SetEventHdr
* Description    : This function will create Event header with the information
*                  specified.
* Input Values   : Event name, SIP message
* Output Values  : Sip Message with event header
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes          :
* *************************************************************************/

PUBLIC e_IFX_SIP_Return  
IFX_SIPAPP_SetEventHdr(IN_OUT uint32 uiMsgHdl,
                       IN  char8 *pcdata)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_EVENT,&uiHdrHdl);
  IFX_SIP_Event_SetPackage(uiHdrHdl,pcdata);
  return IFX_SIP_SUCCESS;

}
/******************************************************************
*  Function Name  :  IFX_SIPAPP_SetSupported
*  Description    :  this function sets the Supported header
*  Input Values   :  SIP message
*  Output Values  :  SIP message with supported header
*  Return Value   :  IFX_SIP_SUCCESS
*           		     IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetSupported(IN_OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_SUPPORTED,&uiHdrHdl);
  IFX_SIP_SetOptionTag(uiHdrHdl,"replaces");
#ifdef RFC_3262
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_SUPPORTED,&uiHdrHdl);
  IFX_SIP_SetOptionTag(uiHdrHdl,"100rel");
#endif
#ifdef RFC_4028
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_SUPPORTED,&uiHdrHdl);
  IFX_SIP_SetOptionTag(uiHdrHdl,"timer");
#endif
  return IFX_SIP_SUCCESS;

}
/************************************************************************
* Function Name  : IFX_SIPAPP_SetAcceptHdr
* Description    : This function will create Accept header  with the information
*                  specified.
* Input Values   : MSubtype of accept header, SIP message handle
* Output Values  : Sip Message updated with Accept header
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes          :
* *************************************************************************/

PUBLIC e_IFX_SIP_Return  
IFX_SIPAPP_SetAccept(IN_OUT uint32 uiMsgHdl,
					 IN char8 *pcMtype,
                     IN  char8 *pcMSubType)
{
  uint32 uiHdrHdl=0;
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ACCEPT,&uiHdrHdl);
  IFX_SIP_Accept_SetMType(uiHdrHdl,pcMtype);
  IFX_SIP_Accept_SetMSubType(uiHdrHdl,pcMSubType);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_SetReplaces
*  Description    :  This function  constructs the replaces Header
*  Input Values   :  uiDlgHdl..Dialog Identifier, SIP message
*  Output Values  :  uiMsgHdl..Message with updated replaces header
*  Return Value   :  IFX_SIP_SUCCESS
*           	     IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetReplaces(IN_OUT uint32 uiMsgHdl,
                       IN uint32 uiDlgHdl)
{
  uint32 uiHdrHdl=0;
  char8* callid , *fromtag, *totag;
  callid = IFX_SIP_DLG_GetCallId(uiDlgHdl);
  fromtag = IFX_SIP_DLG_GetFromTag(uiDlgHdl);
  totag = IFX_SIP_DLG_GetToTag(uiDlgHdl);
  /* Set Replaces Header */
  IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_REPLACES,&uiHdrHdl);
  /* Set CallId */
  IFX_SIP_Replaces_SetCallId(uiHdrHdl,callid);
  /* Set From Tag */
  IFX_SIP_Replaces_SetTagParam(uiHdrHdl,fromtag, "From-Tag");
  /*Set the TO Tag */
  IFX_SIP_Replaces_SetTagParam(uiHdrHdl,totag, "To-Tag");
  
  return IFX_SIP_SUCCESS;

}
#ifdef STUN_SUPPORT
/******************************************************************
*  Function Name  : IFX_SIP_AddViaIfSTUNOn
*  Description    : This function Adds the Via header sent-by param
*                   if STUN is ON
*  Input Values   : uiMsgHdl is SIP message handle and uiSrvPrd is 
*                   the service provider
*  Output Values  : SIP message with updated VIA header
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes      :
*********************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_AddViaIfSTUNOn(uint32 uiMsgHdl,uint32 uiSrvPrd)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl=0;
  uint32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(uiSrvPrd);
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "IFX_SIPAPP_AddViaIfSTUNOn Entered");               
  if (! IFX_SIPAPP_IS_STUNON(uiCfgInst)) {
     IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "IFX_SIPAPP_AddViaIfSTUNOn- STUN is NOT ON - Returning");           
    return IFX_SIP_SUCCESS;
  }

  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_VIA,1,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
    return IFX_SIP_FAILURE;
  }
  IFX_SIP_Via_SetHost(uiHdrHdl,IFX_SIPAPP_GET_MAPPEDADDR(uiCfgInst));
  IFX_SIP_Via_SetPort(uiHdrHdl,IFX_SIPAPP_GET_MAPPEDPORT(uiCfgInst));

  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "IFX_SIPAPP_AddViaIfSTUNOn Returning");
  return IFX_SIP_SUCCESS;
}
#endif /* STUN_SUPPORT */
/******************************************************************
*  Function Name    :  IFX_SIPAPP_ConvAddrTypeToCallAddr
*  Description      :  this function converts AddrType to Called Address
*  Input Values     :  uiHdl is the Addresstype handle.
*  Output Values    :  Called address
*  Return Value     :  None
*  Notes            :
*********************************************************************/
void IFX_SIPAPP_ConvAddrTypeToCallAddr(uint32 uiHdrHdl,
									   x_IFX_CalledAddr *pxCalledAddr)
{
  char8 *pcTmp=NULL;
  if((pcTmp =IFX_SIP_AddressType_GetDisplayName(uiHdrHdl))!= NULL){
		if(strlen(pcTmp)<IFX_MAX_DISP_NAME){
      strcpy(pxCalledAddr->acDisplayName,pcTmp);
		}
  }
  else
  {
    strcpy(pxCalledAddr->acDisplayName,"anonymous");
  }
  uiHdrHdl = IFX_SIP_AddressType_GetAddrSpec(uiHdrHdl);
  uiHdrHdl =IFX_SIP_Addrspec_GetSipUri(uiHdrHdl);

  if((pcTmp =IFX_SIP_SipUri_GetHost(uiHdrHdl))!=NULL){
		if(strlen(pcTmp)<IFX_MAX_TSP_ADDR){
      strcpy(pxCalledAddr->acCalledAddr,pcTmp);
		}
  }
  if((pcTmp =IFX_SIP_SipUri_GetUser(uiHdrHdl))!=NULL){
		if(strlen(pcTmp)<IFX_MAX_USR_NAME){
      strcpy(pxCalledAddr->acUserName,pcTmp);
		}
  }
  pxCalledAddr->unPort = IFX_SIP_SipUri_GetPort(uiHdrHdl);

  if((pcTmp =IFX_SIP_SipUri_GetTransportParam(uiHdrHdl))!=NULL){
    if(!strcasecmp(pcTmp,"udp")){
     pxCalledAddr->ucAddrProto = IFX_TRPROTO_UDP;
    }else if(!strcasecmp(pcTmp,"tcp")){
     pxCalledAddr->ucAddrProto = IFX_TRPROTO_TCP;
    }else if(!strcasecmp(pcTmp,"tls")){
     pxCalledAddr->ucAddrProto = IFX_TRPROTO_TLS;
    }
  }
  if(IFX_SIPAPP_ValidateIPv4Addr(pxCalledAddr->acCalledAddr)
       ==IFX_SIP_SUCCESS){
     pxCalledAddr->ucAddrType = IFX_IP_ADDR;
  }
  else
  {
     pxCalledAddr->ucAddrType = IFX_SIP_URL;
  }
  if((pcTmp = IFX_SIP_SipUri_GetUserParam(uiHdrHdl))!=NULL){
    if(!strcmp(pcTmp,"phone"))
    {
      pxCalledAddr->ucAddrType = IFX_TEL_NUM;
    }
  }

}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_CopyContactAddr
*  Description      :  this function Copies the Called Address
*  Input Values     :  uiMsgHdl is the SIP message handle
*  Output Values    :  pxCalledAddr address in contact header
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CopyContactAddr(IN uint32 uiMsgHdl,
                           OUT x_IFX_CalledAddr* pxCalledAddr)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT,1,
                                    &uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
   }
   uiHdrHdl = IFX_SIP_Contact_GetAddressType(uiHdrHdl);
  
 IFX_SIPAPP_ConvAddrTypeToCallAddr(uiHdrHdl,pxCalledAddr);
  return eRetVal;

}

/******************************************************************
*  Function Name    :  IFX_SIP_CopyCalledAddr
*  Description      :  this function Copies the Called Address
*  Input Values     :  uiMsgHdl is message handle
*  Output Values    :  pxCalledAddr is the address
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CopyCalledAddr(IN uint32 uiMsgHdl,
                          OUT x_IFX_CalledAddr* pxCalledAddr)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_FROM,1,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
   }
   uiHdrHdl = IFX_SIP_From_GetAddressType(uiHdrHdl);
  
  IFX_SIPAPP_ConvAddrTypeToCallAddr(uiHdrHdl,pxCalledAddr);
  return eRetVal;

}

/******************************************************************
*  Function Name    : IFX_SIPAPP_CopyToAddr 
*  Description      : This function Copies the to Address
*  Input Values     : To header
*  Output Values    : xUserCfg
*  Return Value     : IFX_SIP_SUCCESS
*                     IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CopyToAddr(IN uint32 uiMsgHdl,
                   OUT x_IFX_CalledAddr *pxUserCfg)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_TO,1,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
   }
   uiHdrHdl = IFX_SIP_To_GetAddressType(uiHdrHdl);
  
  IFX_SIPAPP_ConvAddrTypeToCallAddr(uiHdrHdl,pxUserCfg);
  return eRetVal;
}

/******************************************************************
*  Function Name    :  IFX_SIPAPP_CopyReferToAddr
*  Description      :  this function Copies the Called Address
*  Input Values     :  uiMsgHdl is the message handle with refer to addr
*  Output Values    :  Called address
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CopyReferToAddr(IN uint32 uiMsgHdl,
                           OUT x_IFX_CalledAddr* pxCalledAddr)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;

  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_REFER_TO,1,
                                    &uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
   }
   uiHdrHdl = IFX_SIP_ReferTo_GetAddressType(uiHdrHdl);

   IFX_SIPAPP_ConvAddrTypeToCallAddr(uiHdrHdl,pxCalledAddr);
  return eRetVal;
}

/******************************************************************
*  Function Name:  IFX_SIPAPP_ValidateIPv4Addr
*  Description  :  Validate Ipv4 address
*  Input Values :  character string
*  Output Values:  -
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_ValidateIPv4Addr(char8* pszBuff)
{
  uint32 iCount = 0, iDotCount = 0;
  char8 acTemp[4];
  while(*pszBuff != '\0'){
    if(*pszBuff == '.'){
      iDotCount++;
      acTemp[iCount] = '\0';
      if((iCount > 0) && (atoi(acTemp) < 256)){
        memset(acTemp,'\0',4);
        iCount = 0;
        pszBuff++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(!isdigit(*pszBuff)){
        return IFX_SIP_FAILURE;
      }
      acTemp[iCount++] = *pszBuff;
      pszBuff++;
      if(iCount > 3){
        return IFX_SIP_FAILURE;
      }
    }
  }
  if(iCount<1 || atoi(acTemp)> 256 || iDotCount > 3){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_ConstAddr
*  Description    :  This function
*  Input Values   :  iPAReadFd..Phone Appln read fifo fd
*  Output Values  :  None
*  Return Value   :  IFX_SIP_SUCCESS
*                    IFX_SIP_FAILURE
*  Notes      : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_ConstAddr(IN x_IFX_CalledAddr *pxCalledAddr,
					 IN x_IFX_SIPAPP_UAAppData* pxAppData)
{
   if ((pxCalledAddr->ucAddrType == IFX_EXTN) ||
       (pxCalledAddr->ucAddrType == IFX_TEL_NUM))
   { 
     if (IFX_SIPAPP_IS_PROXYON(pxAppData))
     {
			 if(strlen(IFX_SIPAPP_GET_PROXYADDRESS(pxAppData))<IFX_MAX_TSP_ADDR){
         strcpy(pxCalledAddr->acCalledAddr,
               IFX_SIPAPP_GET_PROXYADDRESS(pxAppData));
			 }

        pxCalledAddr->unPort = IFX_SIPAPP_GET_PROXYPORT(pxAppData);
        
        pxCalledAddr->ucAddrProto = 
                IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData);

        if (IFX_SIPAPP_ValidateIPv4Addr(pxCalledAddr->acCalledAddr)
            != IFX_SIP_SUCCESS)
        {
          pxCalledAddr->ucAddrType = IFX_SIP_URL;
        }
        else
        {
          pxCalledAddr->ucAddrType = IFX_IP_ADDR;
        }
    }
    else
    {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "<Uac>Proxy not configured");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

