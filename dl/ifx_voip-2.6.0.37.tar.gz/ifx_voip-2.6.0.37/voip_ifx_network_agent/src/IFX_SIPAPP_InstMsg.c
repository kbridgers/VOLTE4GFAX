/**************************************************************************
**   FILE NAME    : IFX_SIPAPP_InstMsg.c
**   PROJECT      : SIP 
**   MODULES      : InstMsg App
**   SRC VERSION  : V2.0
**   DATE         : 15-05-2007
**   AUTHOR       : SIP Team
**   DESCRIPTION  : SIP Instant Messaging APIs and Callbacks
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/


#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_list.h"

#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_DlgApi.h"
#include "IFX_SIP_Message.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_CCApi.h"

/*SDP Agent Files*/
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"


#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_InstMsg.h"

#include "IFX_SIP_EvtPkg.h"

extern uchar8 vcSipAppModId;

/******************************************************************
*  Function Name  : IFX_SIPAPP_SendInstMsg 
*  Description    : API to send and instant message.                
*  Input Values   : uiMsgId is a Message Idenfier from Call Manager
*                   uiSrvPdrId is Seriver provider's identifier.
*                   pxRouteParam is a refernce to Route Parameters
*                   pcMsg is refercen to message string.
*                   uiExpire is Expires value of Message to be sent.
*                   ppvPvtData holds reference to SIPNA's private data.
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS
                    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendInstMsg(IN uint32 uiMsgId,
  			 		   IN uint32 uiSrvPdrId,
					   IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
					   IN char8* pcMsg,
					   IN uint32 uiExpire,
					   IN_OUT void **ppvPvtData)
{
  e_IFX_SIP_Ecode eEcode;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiDlgHdr=0,uiDlg=0;
  x_IFX_SIPAPP_UAAppData *pxAppData =NULL;
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN],acTo[IFX_SIPAPP_MAX_TOKEN];  
  uint32 uiExpireHdl=0,uiDlgHdl=0; 

  if(*ppvPvtData!=NULL)
  {
	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Sending Msg inside the Dlg");
	pxAppData = (x_IFX_SIPAPP_UAAppData*)*ppvPvtData;    
	if(pxAppData->iConnId!=uiMsgId)
	{	
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
      "Error: MsgId Mismatch");  
	  return IFX_SIP_FAILURE;
	}
	if(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL] != 0)
	{     
     eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                             &uiDlgHdr);
     eRetVal |= IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHdr,&uiDlg,
                                                   &eEcode);
    }
    else if(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI] != 0)
	{
      eRetVal = IFX_SIP_SubscGetDlg(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI],
                                    &uiDlgHdr);
      eRetVal |= IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHdr, &uiDlg,
                                                       &eEcode);        
    }

    if(eRetVal != IFX_SIP_SUCCESS)
	{       
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
      "No confirmed dialog Found");
      goto hell;
    }	
   }
			  
   else
   {
		/*New Request - Creat AppData*/ 
	  if(IFX_SIPAPP_CreateNAddAppData(&pxAppData,&eEcode) != IFX_SIP_SUCCESS)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creation of Appdata failed");
       goto hell;       
    }
    /*Store AppData Information.*/
    *ppvPvtData=(void*)pxAppData;
    pxAppData->iConnId = uiMsgId;
    pxAppData->unLocalTcpPort=pxRouteParams->unLocalTcpPort; 
    pxAppData->iProfileId=uiSrvPdrId;	  
	  pxAppData->uiMsgExpires=uiExpire;
	  memcpy(&pxAppData->xTo,pxRouteParams->pxTo,sizeof(x_IFX_CalledAddr)); 
	  memcpy(&pxAppData->xFrom,pxRouteParams->pxFrom,sizeof(x_IFX_CalledAddr));
	  
	  /*Copy Proxy Info*/
	  if(pxRouteParams->pcProxyAddr)  
    {
      IFX_SIPAPP_Strcpy(pxAppData->acProxyAddr,pxRouteParams->pcProxyAddr);
      pxAppData->eProxyProtocol=pxRouteParams->eProxyProtocol;
      pxAppData->unProxyPort=pxRouteParams->unProxyPort;
      pxAppData->ucIsOutBoundProxy=pxRouteParams->ucIsOutBoundProxy;/*TODO*/
    }


     	
	 if(pcMsg!=NULL)
	 { 		  
      if(IFX_SIPAPP_Strlen(pcMsg)<IFX_SIPAPP_MAX_MSG_SIZE)
	  {
        pxAppData->pcInstMsg = (char8*)IFX_SIPAPP_Malloc(IFX_SIPAPP_Strlen(pcMsg)+1);
		  if(!pxAppData->pcInstMsg)
		  {
			IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
			return IFX_SIP_FAILURE;
		  }
        IFX_SIPAPP_Strcpy(pxAppData->pcInstMsg,pcMsg);      
      }
      else
	  {
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"InstMsg size too big");
       pxAppData->pcInstMsg = IFX_SIPAPP_Malloc(IFX_SIPAPP_MAX_MSG_SIZE);
		 if(!pxAppData->pcInstMsg)
		 {
			IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
			return IFX_SIP_FAILURE;
		 }

       IFX_SIPAPP_Strncpy(pxAppData->pcInstMsg,pcMsg,IFX_SIPAPP_MAX_MSG_SIZE-1);
  	   pxAppData->pcInstMsg[IFX_SIPAPP_MAX_MSG_SIZE]='\0';
	  }
	 } 
   }
   
   /*Copy CallerId suppression*/
   pxAppData->bSupressCallerId = pxRouteParams->bSupressCallerId;
   if(pxAppData->bSupressCallerId){
     strcpy(pxAppData->xFrom.acUserName,"anonymous");
	 strcpy(pxAppData->xFrom.acCalledAddr,"anonymous.invalid");
	 strcpy(pxAppData->xFrom.acDisplayName,"anonymous");
   } 
   /* construct ReqURI and TO */
   IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo,acTo);
   IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xFrom,acFrom);
   

   if(IFX_SIP_InstMsgCreate(pxAppData,&pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG])
     == IFX_SIP_SUCCESS)	
   {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
	        "Instant message create success");
    if(IFX_SIPAPP_IS_PROXYON(pxAppData)&& (pxAppData->ucIsOutBoundProxy))
	{
    IFX_SIP_InstMsgSetNextHopAddr(pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG],
                                  IFX_SIPAPP_GET_PROXYADDRESS(pxAppData),
                                  pxAppData->unLocalTcpPort,
                                  IFX_SIPAPP_GET_PROXYPORT(pxAppData),
                                  IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData));
   }   
	  
   if(IFX_SIP_SendInstMsgReq(pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG],
                             acTo,acFrom,0,
						     uiDlg,pxAppData->unLocalTcpPort)
        == IFX_SIP_SUCCESS)
	 {
       return IFX_SIP_SUCCESS;
     }
   }
hell:  
   if(pxAppData->pcInstMsg) 
   {
     IFX_SIPAPP_Free(pxAppData->pcInstMsg);
	  pxAppData->pcInstMsg=NULL;
   }
   IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_MAX_HDLS);	  
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Sending InstMsg Failed");
   return IFX_SIP_FAILURE; 
}
/*****************************************************************************
 * Fuinction Name : IFX_SIP_InstMsgAccept
 * Description   :  This API is used to accept the incoming message
 * Input Values  :  uiMsgId is a Message Identifier
                    pvPvtData is refernce to NA's private data structure.
 * Output Values :  
 * Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
 * Notes
 ******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgAccept(IN uint32 uiMsgId,
                         IN void* pvPvtData)
{
 if(pvPvtData)
 { 			 
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvPvtData;		  
  uint32 uiIMHdl;

  if(pxAppData==NULL ||pxAppData->iConnId!=uiMsgId)
  {
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR, 
			   "MsgId Mismatch");
     return IFX_SIP_FAILURE;
  }  
  uiIMHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG];
  if(IFX_SIP_InstMsgSendResp(uiIMHdl, 0,200,NULL) != IFX_SIP_SUCCESS)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               " InstMsg resp  from APP processing fail");
  }
  if(pxAppData->pcInstMsg!=NULL)	
     IFX_SIPAPP_Free(pxAppData->pcInstMsg);
  pxAppData->pcInstMsg=NULL;
  IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
  return IFX_SIP_SUCCESS;  
 }
 return IFX_SIP_FAILURE;
}
/*****************************************************************************
* Function Name : IFX_SIP_Send3xxInstMsgResp
* Description   : This function is called when a fwd for InstMsg Method is
                  received from the application.
* Input Values  : pxAppData
                  uiMsgHdl
                  pxFwdAddr 
* Output Values : Encoded 3xx response
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Send3xxInstMsgResp(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                              IN uint32 uiIMHdl,
										IN x_IFX_CalledAddr *pxFwdAddr)
{
  uint32 uiContactHdl=0,uiMsgHdl;
  char8 acCallFwdAddr[IFX_SIPAPP_MAX_TOKEN];
  e_IFX_Return eRetVal;

  if(IFX_SIP_CreateMsg(&uiMsgHdl)==IFX_SIP_FAILURE)
	  return IFX_SIP_FAILURE;
  eRetVal = IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT,&uiContactHdl);
  if(eRetVal == IFX_SIP_FAILURE)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Forwarding of InstMsg failed");
    return eRetVal;
  }
  uiContactHdl = IFX_SIP_Contact_GetAddressType(uiContactHdl);
  uiContactHdl = IFX_SIP_AddressType_GetAddrSpec(uiContactHdl);  
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo,acCallFwdAddr);
  IFX_SIP_AddrType_SetValue(uiContactHdl,acCallFwdAddr); 
 
  eRetVal = IFX_SIP_InstMsgSendResp(uiIMHdl,
                    uiMsgHdl,302,NULL);
    
  if(eRetVal != IFX_SIP_SUCCESS)
  {
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "3xx TxmSendSipResp or Const Return Fail");
  }
  return eRetVal;
}	

													  
/*****************************************************************************
 * Function Name : IFX_SIPAPP_InstMsgReject
 * Description   : To Reject the incoming messages                   
 * Input Values  : uiMsgId is a message identifier
                   eMsgReason is a reason for the rejecting
                   pxFwdAddr is reference to forwarded address if the reason code is IFX_MSG_FWD 
                   pvPvtData is reference to NA's data private data structure.
 * Output Values : None
 * Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
 * Notes
 ******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgReject(IN uint32 uiMsgId,
                         IN IN e_IFX_SIPAPP_Msg eMsgReason,
                         IN x_IFX_CalledAddr *pxFwdAddr,
                         IN void* pvPvtData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_FAILURE;

 if(pvPvtData)
 {
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvPvtData;
  uint32 uiIMHdl;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           " InstMsg resp  from APP");

  if((pxAppData) && pxAppData->iConnId==uiMsgId)
  {
   uiIMHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG];
   switch(eMsgReason)
   {
    case IFX_MSG_FWD:
         eRetVal = IFX_SIPAPP_Send3xxInstMsgResp(pxAppData,uiIMHdl,pxFwdAddr);
         break;
    case IFX_MSG_INBOX_FULL:            
          eRetVal=IFX_SIP_InstMsgSendResp(uiIMHdl, 0,406,NULL); 
          break; 
    case IFX_MSG_NOT_FOUND:
         eRetVal=IFX_SIP_InstMsgSendResp(uiIMHdl, 0,404,NULL); 
         break; 
   }            

  if ( eRetVal != IFX_SIP_SUCCESS)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               " InstMsg resp  from APP processing fail");
  }
  if(pxAppData->pcInstMsg!=NULL)	
     IFX_SIPAPP_Free(pxAppData->pcInstMsg);
  pxAppData->pcInstMsg=NULL;
  IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
  return eRetVal;
 
  }
 }
 return IFX_SIP_FAILURE;
}

/******************************************************************************
*  Function Name  : IFX_SIPAPP_SetAuthInfoMsg
*  Description    : API to authenticate the challanged MESSAGe request
*  Input Values   : uiMsgId  is message identifier for MESSAGE transaction.
                    pcUserName is reference to username string
                    pcPassword is reference to password for authentication
                    pxAppData is reference to internal structure for this dialog
*  Output Values  : 
*  Return Value   : IFX_SIP_SUCCESS / IFX_SIP_FAILURE
*  Notes          : 
******************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetAuthInfoMsg(IN uint32 uiMsgId,
			 			  IN char8* pcUserName,
                          IN char8* pcPassword,
                          IN void* pvPvtData)
{
 if(pvPvtData)
 {			
  x_IFX_SIPAPP_UAAppData* pxAppData = (x_IFX_SIPAPP_UAAppData*)pvPvtData;
 
   return IFX_SIP_InstMsgAuthenticate(pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG],
                                     pcUserName,pcPassword,0);
 }
 return IFX_SIP_FAILURE;

} 
/***********************************************************************
* Function Name : IFX_SIP_3xxInstMsgHdlr
* Description   : This function is called when 3xx for InstMsg is received
* Input Values  : pxAppData
*                 uiMsgHdl
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/

e_IFX_SIP_Return
IFX_SIPAPP_3xxInstMsgHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN uint32 uiMsgHdl)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  uint32 uiContactHdl; 

  eRetVal= IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT,1,&uiContactHdl);
  if(eRetVal == IFX_SIP_FAILURE)
  {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
              "InstMsg 3XX Response: Contact header not found\n");
     return eRetVal;
   }

  /* if invalid 3xx response and Contact is not present return a failure */
  if((iRespCode != 302)&&
     (iRespCode != 301)&&
     (iRespCode != 305)&&
     (uiContactHdl== 0))
  {  
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Option 3xx invalid request");        
       return IFX_SIP_FAILURE;
  }

   /*Update AppData "TO" with URI received in Contact*/
   IFX_SIPAPP_CopyContactAddr(uiMsgHdl,&pxAppData->xTo);
   return IFX_SIPAPP_SendInstMsg(pxAppData->iConnId, 0,NULL,
						  NULL,0,(void**)&pxAppData);
   
}
/***********************************************************************
* Function Name : IFX_SIP_4xxInstMsgHdlr
* Description   : This function is called when 4xx for InstMsg is received
* Input Values  : pxAppData- 
*                 uiMsgHdl- pointer to the Decoded Data Structure
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_4xxInstMsgHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                       IN uint32 uiMsgHdl)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR, "4xx recived\n");
  
  if( (iRespCode == 401) || (iRespCode == 407))
  {
   int32 iAuthHdl=0;
   char8 *pcRealm=NULL,acRealm[IFX_SIPAPP_MAX_TOKEN]={'\0'};                                     
   x_IFX_SIPAPP_AuthReqd xAuthReqd = {0};
   if(iRespCode == 401)
   {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_WWW_AUTHENTICATE,
                                     1,&iAuthHdl); 
   
    if(eRetVal == IFX_SIP_FAILURE)
    {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
     "Option 4xx Response recived but no www Auth header found");             
      return IFX_SIP_FAILURE;
     }
   }
   else
   {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_PROXY_AUTHENTICATE,
                                      1,&iAuthHdl); 
    if(eRetVal == IFX_SIP_FAILURE)
    {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
     "Option 4xx Response recived but no www Auth header found");
     return eRetVal; 
    }
   }
   pcRealm = IFX_SIP_Authentication_GetRealm(iAuthHdl);
   if(pcRealm)
   { 
    /* Since the Relm contain Quots, the below logic is to remove the Quots*/
    IFX_SIPAPP_Strncpy(acRealm,pcRealm+1,IFX_SIPAPP_Strlen(pcRealm)-2);
    xAuthReqd.pcRealm=acRealm;
    xAuthReqd.pvPvtData= (void*)pxAppData;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MSG_AUTH_REQ,
   	  	  							   (void*)&xAuthReqd);
	return IFX_SIP_SUCCESS;
   }
  }
  return IFX_SIP_FAILURE;
 }
/***********************************************************************
* Function Name : IFX_SIP_InstMsgMsgRespArrived
* Description   :
* Input Values  : uiSipMsgHdl
*                 uiInstMsgHdl
*                 pvUserData                                                         
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_InstMsgMsgRespArrived(IN uint32 uiSipMsgHdl,
         			             IN uint32 uiInstMsgHdl,
                  			     IN void *pvUserData)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_FAILURE;
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiSipMsgHdl);
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvUserData;
 
  if(iRespCode >99 && iRespCode < 200)
  {    
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
            "1xx Resp Arrived Just ignore it");
    return IFX_SIP_SUCCESS;
  }
  
  else if(iRespCode >199 && iRespCode < 300)
  {
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MSG_SUCCESS,NULL);	
    if(pxAppData->pcInstMsg)
    {
     IFX_SIPAPP_Free(pxAppData->pcInstMsg);
	 pxAppData->pcInstMsg=NULL;
    }
    IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
    return IFX_SIP_SUCCESS;
  }
   
  else if(iRespCode >299 && iRespCode < 400)
  {
   eRetVal =IFX_SIPAPP_3xxInstMsgHdlr(pxAppData,uiSipMsgHdl);
  } 
  else if(iRespCode >399 && iRespCode < 500)
  {
    eRetVal =IFX_SIPAPP_4xxInstMsgHdlr(pxAppData,uiSipMsgHdl);
  }
 
  else
  {
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"InstMsg 5xx Recived");   
  }
 
  if(eRetVal == IFX_SIP_FAILURE)
  {
   vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MSG_FAIL,NULL);
   if(pxAppData->pcInstMsg)
   {
    IFX_SIPAPP_Free(pxAppData->pcInstMsg);
	 pxAppData->pcInstMsg=NULL;
   }
   IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
  }
  return IFX_SIP_SUCCESS;
}
/*****************************************************************************
* Function Name : IFX_SIP_InstMsgHdlr
* Description   : This function is called when a Option Method is
                  received from the peer.
* Input Values  : uiDlg
*                 uiInstMsgHdl
*                 pxAppData
*                 uiMsgHdl
* Output Values : None
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes           
* 
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgHdlr(IN uint32 uiDlg,
                    IN uint32 uiInstMsgHdl,
                    IN x_IFX_SIPAPP_UAAppData *pxAppData,
                    IN uint32 uiMsgHdl)
{
  char8 *pcBody;
  x_IFX_Msg xMsg ={0};
  uint32 uiHdrHdl=0;
  
  if(!uiDlg)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "InstMsg Req Outside Dlg"); 
    /* Generate New MsgId*/
    pxAppData->iConnId = 0;
  }

  if(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1,&uiHdrHdl)
	  ==IFX_SIP_FAILURE)  
		return IFX_SIP_FAILURE;

  /* TODO  Debug and check return of GetMType*/
  if( (IFX_SIPAPP_Strcmp(IFX_SIP_ContType_GetMType(uiHdrHdl),"text")) )
  {
   
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
			  "Unsuported Media type in InstMsg");
   IFX_SIP_InstMsgSendResp(uiInstMsgHdl,0,415,
                           "Unsupported Media Type");
   return IFX_SIP_SUCCESS;
  }
  
  /* Copy the  "FROM" and "TO" headers */
  IFX_SIPAPP_CopyCalledAddr(uiMsgHdl,&(xMsg.xFrom));    
  IFX_SIPAPP_CopyToAddr(uiMsgHdl,&(xMsg.xTo));    
  /* Copy Message Body*/
  if((pcBody = IFX_SIP_GetMsgBody(uiMsgHdl)) != NULL)
  {
    if(IFX_SIPAPP_Strlen(pcBody)<IFX_SIPAPP_MAX_MSG_SIZE)
		IFX_SIPAPP_Strcpy(xMsg.acMessg,pcBody);
    else
	 {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Received Msg size is too big");
	  memcpy(xMsg.acMessg,pcBody,IFX_SIPAPP_MAX_MSG_SIZE-1);
     }
  } 
  
  if(IFX_SIP_GetHeaderByType(uiMsgHdl,1,IFX_SIP_EXPIRES,&uiHdrHdl)==
	  IFX_SIP_SUCCESS) {
		xMsg.uiExpires = IFX_SIP_Expires_GetValue(uiHdrHdl);
	 }
  pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG] = uiInstMsgHdl;
  xMsg.pvPrivateData = pxAppData;
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MSG,
                              (void *)&xMsg);
  return IFX_SIP_SUCCESS;
    
}
/***********************************************************************
* Function Name : IFX_SIP_InstMsgRequestArrived
* Description   : This function is called when InstMsg request is received
* Input Values  : uiSipMsgHdl - pointer to the Decoded Data Structure
                  uiInstMsgHdl
                  uiDlgHdl
                  ppvUserData
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_InstMsgRequestArrived(IN uint32 uiSipMsgHdl,
                                 IN uint32 uiInstMsgHdl,
                                 IN uint32 uiDlgHdl,
                                 IN_OUT void **ppvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData =NULL;
  e_IFX_SIP_Ecode eEcode;

  if(uiDlgHdl != 0)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
            "Request arrived on a exsisting dialog");
    /* Search the subscription list to get the application data */
    pxAppData = (x_IFX_SIPAPP_UAAppData *)IFX_SIP_SUBSC_GetAppData(uiDlgHdl);
    if(pxAppData == NULL)
    {
     pxAppData = (x_IFX_SIPAPP_UAAppData *)IFX_SIP_CC_GetAppData(uiDlgHdl);
     if(pxAppData == NULL)
        goto hell;
    }
    *ppvUserData = pxAppData;
  }
  else
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"New Request arrived ");
    if(IFX_SIPAPP_CreateNAddAppData(&pxAppData,&eEcode)!= IFX_SIP_SUCCESS)
	 {
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Creating App DataFailed");
     goto hell;
    }
    *ppvUserData = pxAppData;   
  }
  pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG] = uiInstMsgHdl;
  if(IFX_SIPAPP_InstMsgHdlr(uiDlgHdl,uiInstMsgHdl,pxAppData,
						    uiSipMsgHdl)== IFX_SIP_SUCCESS)
     return IFX_SIP_SUCCESS;
hell:
  IFX_SIP_InstMsgSendResp(pxAppData->auiHdl[IFX_SIPAPP_UA_IMSG],0,500,NULL);
  /* Free Containt of the Node  and Node itself */
  IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_IMSG);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           " Leaving IFX_SIP_InstMsgRequestArrived");

  return IFX_SIP_SUCCESS;
}
/***********************************************************************
* Function Name : IFX_SIP_InstMsgTimeOutOrError
* Description   : This function is called when 2xx for InstMsg is received
* Input Values  : pSipMessage - pointer to the Decoded Data Structure
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_InstMsgTimeOutOrError(IN e_IFX_SIP_TransErrorCode eErrorType,
                                 IN uint32 uiInstMsgHdl,
                                 IN void *pvUserData)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvUserData;

  if(eErrorType == IFX_SIP_DNS_ERR)
  {
	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Sending Request on Next Dns Addr");
    IFX_SIP_InstMsgSendReqToNxtAddr(uiInstMsgHdl,0);
     return IFX_SIP_SUCCESS;
  }
   
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "InstMsg Request TimeOut");
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MSG_FAIL,NULL);
  if(pxAppData->pcInstMsg)
  {
    IFX_SIPAPP_Free(pxAppData->pcInstMsg);
	 pxAppData->pcInstMsg=NULL;
  }  
  IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_IMSG);
  return IFX_SIP_SUCCESS;
 }

/***********************************************************************
* Function Name : IFX_SIP_InstMsgMsgToEncode
* Description   : This function is called when 2xx for InstMsg is received
* Input Values  : uiSipMsgHdl
*                 uiInstMsgHdl
*                 pvUserData
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return  
IFX_SIPAPP_InstMsgMsgToEncode(IN uint32 uiSipMsgHdl,
                              IN uint32 uiInstMsgHdl,
                              IN void *pvUserData)
{
 x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvUserData;
#ifdef STUN_SUPPORT
  IFX_SIPAPP_AddViaIfSTUNOn(uiSipMsgHdl);
#endif
if(pxAppData->pcInstMsg!=NULL)
   {
	 IFX_SIP_AddMsgBody(uiSipMsgHdl,IFX_SIPAPP_Strlen(pxAppData->pcInstMsg),
		 pxAppData->pcInstMsg);   	  	
	   }	  return IFX_SIP_SUCCESS;
}
/***********************************************************************
* Function Name : IFX_SIP_InstMsgDnsResolved
* Description   : This function is called when 2xx for InstMsg is received
* Input Values  : 
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return  
IFX_SIPAPP_InstMsgDnsResolved(IN uint32 uiInstMsgHdl,
                              IN void *pvUserData)
{
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_InstMsgRegCallbacks 
*  Description    : This function registers the callbacks for Instant
*                   messaging.
*  Input Values   : None
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
                    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InstMsgRegCallbacks(uint32 uiStackHdl)
{
  x_IFX_SIP_InstMsgCallBks xInstMsgCallBacks;
  /* Initialize the Instant messaging Call Backs */
  xInstMsgCallBacks.pfnRequestArrived = IFX_SIPAPP_InstMsgRequestArrived;
  xInstMsgCallBacks.pfnTimeOutOrError = IFX_SIPAPP_InstMsgTimeOutOrError;
  xInstMsgCallBacks.pfnMsgToEncode = IFX_SIPAPP_InstMsgMsgToEncode;
  xInstMsgCallBacks.pfnRespArrived = IFX_SIPAPP_InstMsgMsgRespArrived;
	xInstMsgCallBacks.uiStackHdl =uiStackHdl;
  /* Register Instant messaging Call backs */
  IFX_SIP_InstMsgRegisterCallBk(&xInstMsgCallBacks);
  return IFX_SIP_SUCCESS;
}
