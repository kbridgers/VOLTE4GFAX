/**************************************************************************
* FILE NAME     : IFX_SIPAPP_Refer.c
* PROJECT       : SIP
* MODULES       : Transaction User
* SRC VERSION   : V2.0
* DATE          :
* AUTHOR        : SIP Team
* DESCRIPTION   : This file uses the APIs provided by Refer subs-notify
* COMPILER      : gcc
* REFERENCE     :
* COPYRIGHT     : Copyright (c) 2004
*                 Infineon Technologies AG, st. Martin Strasse 53;
*                 81669 Munchen, Germany
* Any use of this software is subject to the conclusion of a respective
* License agreement. Without such a License agreement no rights to the
* software are granted
* Version Control Section  **
* $Author$
* $Date$
* $Revisions$
* $Log$
****************************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"

#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_RegApi.h"

#include "IFX_SIP_EvtPkg.h"
#include "IFX_SIP_DlgApi.h"
#include "IFX_SIP_CCApi.h"

#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"

#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_Refer.h"
#include "ifx_list.h"

extern uchar8 vcSipAppModId;
/************************************************************************
* Function Name    : IFX_SIP_REF_NotifyRecvTimeout
* Description      : No notification has been received for Refer
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIP_REF_NotifyRecvTimeout(x_IFX_SIPAPP_UAAppData *pxAppData)
{
  x_IFX_SIPAPP_ReferStatus xReferStatus;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Timeout - No Notification");

  xReferStatus.pvAppData = (void *) pxAppData;
  xReferStatus.eTransferStatus = IFX_OFF;
  xReferStatus.eReason = IFX_TIMEOUT;
	if(pxAppData->iConnId2 != 0){
  	xReferStatus.ucIsAtx = 1;
	}
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REFER_STATUS_RECV,
    &xReferStatus);
  IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);
  return IFX_SIP_FAILURE;
}
/******************************************************************
*  Function Name    :  IFX_SIPAPP_StoreReplaces
*  Description      :  this function processes the Refer request for replaces
*                      Header fields in ReferTo header
*  Input Values     :  pxReferTo...pointer to Refer To Header
*                      pxDialogID ... pointer to the endpt information
*  Output Values    :  peEcode....pointer to error code
*  Return Value     :  IFX_SIP_SUCCESS
*                      IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
static void
IFX_SIPAPP_StoreReplaces(IN char8 *pcReplaces,
                         IN x_IFX_SIPAPP_UAAppData *pxAppData)
{
  char8* szTag;
  if (pcReplaces != NULL)
  {
    char8* pcTemp, *pcCurr, *pcTempCap, *pcTempSmall;
    pcTemp = pcReplaces;
    /* Parse for To-tag and from-tag */
    pcTempCap = strstr(pcTemp, "%3B");
    pcTempSmall = strstr(pcTemp, "%3b");
    if ((pcTempSmall != NULL) && (pcTempCap != NULL)) {
      if (pcTempSmall < pcTempCap) {
        pcCurr = pcTempSmall;
      }
      else {
        pcCurr = pcTempCap;
      }
    }
    else if (pcTempSmall != NULL) {
      pcCurr = pcTempSmall;
    }
    else {
      pcCurr = pcTempCap;
    }
    if (pcCurr != NULL) {
      char8 acCallId[256];
      char8* pcTempPtr;
      strncpy(acCallId, pcTemp, (pcCurr - pcTemp));
      acCallId[(pcCurr - pcTemp)] = '\0';
      pcTempPtr = strstr(acCallId, "%40");
      if(pcTempPtr != NULL) {
        strncpy(pxAppData->szCallId, acCallId,(pcTempPtr - acCallId));
        pxAppData->szCallId[(pcTempPtr - acCallId)] = '@';
        strncpy(&(pxAppData->szCallId[(pcTempPtr - acCallId + 1)]),
                (pcTempPtr + 3),
                ((acCallId + strlen(acCallId)) - (pcTempPtr + 3)));
        pxAppData->szCallId[strlen(acCallId) - 2] = '\0';
      }
      else {
        strcpy(pxAppData->szCallId, acCallId);
      }
    }
    else {
      strcpy(pxAppData->szCallId,pcReplaces);
    }
    pcTemp = pcCurr + 3;
    pcTempCap = strstr(pcTemp, "%3D");
    pcTempSmall = strstr(pcTemp, "%3d");
    if ((pcTempSmall != NULL) && (pcTempCap != NULL)) {
      if (pcTempSmall < pcTempCap) {
        pcCurr = pcTempSmall;
      }
      else {
        pcCurr = pcTempCap;
      }
    }
    else if (pcTempSmall != NULL) {
      pcCurr = pcTempSmall;
    }
    else {
      pcCurr = pcTempCap;
    }
    if (pcCurr != NULL) {
      if(strncmp(pcTemp, "to-tag", (pcCurr - pcTemp)) == 0){
        szTag = pxAppData->szRemoteTag;
      }
      else if (strncmp(pcTemp, "from-tag", (pcCurr - pcTemp)) == 0) {
        szTag = pxAppData->szLocalTag;
      }
      else {
        return;
      }

      /* Find the next delimiter */
      pcTemp = pcCurr + 3;
      pcTempCap = strstr(pcTemp, "%3B");
      pcTempSmall = strstr(pcTemp, "%3b");
      if ((pcTempSmall != NULL) && (pcTempCap != NULL)) {
        if (pcTempSmall < pcTempCap) {
          pcCurr = pcTempSmall;
        }
        else {
          pcCurr = pcTempCap;
        }
      }
      else if (pcTempSmall != NULL) {
        pcCurr = pcTempSmall;
      }
      else {
        pcCurr = pcTempCap;
      }
      if (pcCurr != NULL) {
        strncpy(szTag,pcTemp, (pcCurr - pcTemp));
        szTag[(pcCurr - pcTemp)] = '\0';
        pcTemp = pcCurr + 3;
        pcTempCap = strstr(pcTemp, "%3D");
        pcTempSmall = strstr(pcTemp, "%3d");
        if ((pcTempSmall != NULL) && (pcTempCap != NULL)) {
          if (pcTempSmall < pcTempCap) {
            pcCurr = pcTempSmall;
          }
          else {
            pcCurr = pcTempCap;
          }
        }
        else if(pcTempSmall != NULL) {
          pcCurr = pcTempSmall;
        }
        else{
          pcCurr = pcTempCap;
        }
        if(pcCurr != NULL) {
          if(strncmp(pcTemp, "to-tag", (pcCurr - pcTemp)) == 0) {
            szTag = pxAppData->szRemoteTag;
          }
          else if(strncmp(pcTemp, "from-tag", (pcCurr - pcTemp)) == 0) {
            szTag = pxAppData->szLocalTag;
          }
          else {
            return;
          }
          pcTemp = pcCurr + 3;
          pcCurr = pcReplaces +
            strlen(pcReplaces);
          strncpy(szTag, pcTemp, (pcCurr - pcTemp));
          szTag[(pcCurr - pcTemp)] = '\0';
        }
        else {
          return;
        }
      }
      else {
       return;
      }
    }
    else {
      return;
    }
    return;
  }
  return;
}
/************************************************************************
* Function Name    : IFX_SIP_REF_PkgRecvSubsc
* Description      : This function handles the subscribe request specific
*                    to REF event package
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_REF_PkgRecvSubsc(IN uint32 uiDecodedMsgHdl,
                            IN uint32 uiSubscHdl,
                            IN uint32 uiDialogHdl,
                            IN_OUT void **ppvUserData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode;
  x_IFX_SIPAPP_UAAppData *pxAppData;
  uint32 uiHdrHdl = 0;
  char8 *pcReplaces = NULL;
  x_IFX_SIPAPP_ReferRecvd xReferRecvd={{'\0'}};

  if(ppvUserData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }
	else{
    pxAppData= (x_IFX_SIPAPP_UAAppData *) *ppvUserData;
	}

  /* Check whether request has arrived on an existing dialog */
  if(uiDialogHdl)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               " Request arrived on a existing dialog");
    /* Search the subscription list to get the application data */
    pxAppData = (x_IFX_SIPAPP_UAAppData *) IFX_SIP_CC_GetAppData(uiDialogHdl);
    if(pxAppData == NULL)
    {
      pxAppData =
        (x_IFX_SIPAPP_UAAppData *) IFX_SIP_SUBSC_GetAppData(uiDialogHdl);
      if(pxAppData == NULL)
      {
        eRetVal = IFX_SIP_SubscRespond(uiSubscHdl,500,NULL,0);
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 " Leaving IFX_SIPAPP_REF_PkgRecvSubsc");
        return IFX_SIP_SUCCESS;
      }
    }
	else{
	  if(!(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST)){
	    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
		        " Leaving IFX_SIPAPP_REF_PkgRecvSubsc, on hook received and than refer, so send 500");
        eRetVal = IFX_SIP_SubscRespond(uiSubscHdl,500,NULL,0);
        return IFX_SIP_SUCCESS;
				
	  }
	}
  }
  else
  {
    eRetVal = IFX_SIPAPP_CreateNAddAppData(&pxAppData, &eEcode);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      return eRetVal;
    }
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " Creating New App Data");
  }
  *ppvUserData = (void *) pxAppData;
  pxAppData->auiHdl[IFX_SIPAPP_UA_REF] = uiSubscHdl;

#ifdef IFX_INTERCOM_SUPPORT
  eRetVal = IFX_SIP_GetHeaderByType(uiDecodedMsgHdl, IFX_SIP_TO, 1, &uiHdrHdl);
  pcHdr = NULL;
  pcHdr = IFX_SIP_ToFrom_GetGenericParam(uiHdrHdl, 1, "intercom");
  if ((pcHdr) && (!strcmp(pcHdr, "true")))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " <HandleInvite> REFER - intercom call");
    pxAppData->bIsIntercomTypeCall = 1;
  }
#endif
  /* Copy addresses only if this is a new dialog */
  if(!pxAppData->iConnId)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Copying Called Addr, UserCfg and ReferTo Addr");
    IFX_SIPAPP_CopyCalledAddr(uiDecodedMsgHdl, &pxAppData->xFrom);
    IFX_SIPAPP_CopyToAddr(uiDecodedMsgHdl, &pxAppData->xTo);
  }
  xReferRecvd.uiReplacesCallId = 0;
	xReferRecvd.pvAppData = pxAppData;
  IFX_SIPAPP_CopyReferToAddr(uiDecodedMsgHdl, &xReferRecvd.xTargetAddr);

  /*Check For Replaces */
  if(IFX_SIP_GetHeaderByType(uiDecodedMsgHdl, IFX_SIP_REFER_TO, 1, &uiHdrHdl)
       == IFX_SIP_SUCCESS)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Check replaces in refer");

    uiHdrHdl = IFX_SIP_ReferTo_GetAddressType(uiHdrHdl);
    uiHdrHdl = IFX_SIP_AddressType_GetAddrSpec(uiHdrHdl);
    uiHdrHdl = IFX_SIP_Addrspec_GetSipUri(uiHdrHdl);
    pcReplaces = IFX_SIP_SipUri_GetHeader(uiHdrHdl, "Replaces");
    if(pcReplaces != NULL)
    {
      IFX_SIPAPP_StoreReplaces(pcReplaces, pxAppData);
      xReferRecvd.uiReplacesCallId = pxAppData->iConnId;
    }
  }
  else
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No replaces Found");
  }
  
  /* Send a positive response */
  eRetVal = IFX_SIP_SubscRespond(uiSubscHdl, 202, NULL, 0);
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REFER_RECV,
    &xReferRecvd);
  return eRetVal;
}

/************************************************************************
* Function Name    : IFX_SIP_REF_PkgRecvNotify
* Description      : This function handles the notify request specific
*                    to REF event package
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_REF_PkgRecvNotify(IN uint32 uiDecodedMsgHdl,
                             IN uint32 uiSubscHdl,
                             IN uint32 uiDlgHdl,
                             IN_OUT void **ppvUserData)
{
  e_IFX_SIP_Ecode eEcode;
  x_IFX_SIPAPP_UAAppData *pxAppData;
  x_IFX_SIPAPP_ReferStatus xReferStatus;
  int32 iStatusCode = 0;
  uint32 uiHdrHdl = 0;
  char8 *pcMsgBody = NULL, *pcTmp = NULL, *pcState = NULL;

  if(ppvUserData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  if(*ppvUserData == NULL)
  {
    /* Don't accept unsolicited Notify for REFER */
    IFX_SIP_NotifyRespond(uiSubscHdl, uiDlgHdl, 0, 481, NULL);
    return IFX_SIP_FAILURE;
  }

  pxAppData = (x_IFX_SIPAPP_UAAppData *) *ppvUserData;
	/*Fix: 150908 Set this flag to Indicate that Notify is received */
  pxAppData->iFlag |= IFX_SIPAPP_NOTIFY_RCVD;
	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Notify Received flag is set");
	
  IFX_SIPAPP_StopTimer(pxAppData->unNoNotifyId);
  IFX_SIPAPP_StartTimer(32000, IFX_SIP_REF_NotifyRecvTimeout, pxAppData,
      &pxAppData->unNoNotifyId, &eEcode);
  xReferStatus.pvAppData = (void *) pxAppData;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Received Notify Request");

  if((pcMsgBody = IFX_SIP_GetMsgBody(uiDecodedMsgHdl)) != NULL)
  {
    pcTmp = strchr(pcMsgBody,' ');
    if(pcTmp != NULL)
    {
      pcTmp++;
      iStatusCode = atoi(pcTmp);
      if((iStatusCode >=100) && (iStatusCode <200))
      {
        xReferStatus.eReason = IFX_100_RESP;
      }
      else if ((iStatusCode >=200) && (iStatusCode <300))
      {
        xReferStatus.eReason = IFX_200_RESP;
      }
      else if ((iStatusCode >=300) && (iStatusCode <400))
      {
        xReferStatus.eReason = IFX_300_RESP;
      }
      else if ((iStatusCode >=400) && (iStatusCode <500))
      {
        xReferStatus.eReason = IFX_400_RESP;
      }
      else if ((iStatusCode >=500) && (iStatusCode <600))
      {
        xReferStatus.eReason = IFX_500_RESP;
      }
      else if ((iStatusCode >=600) && (iStatusCode <700))
      {
        xReferStatus.eReason = IFX_600_RESP;
      }
    }
  }

  if(IFX_SIP_GetHeaderByType(uiDecodedMsgHdl, IFX_SIP_SUBSCRIPTION_STATE, 1,
       &uiHdrHdl) != IFX_SIP_FAILURE)
  {
    pcState = IFX_SIP_SubState_GetState(uiHdrHdl);
		if(pcState != NULL){
      xReferStatus.eTransferStatus =
	     (!strcmp(pcState, "terminated")) ? IFX_OFF : IFX_ON;
		}
		else{
			 xReferStatus.eTransferStatus = IFX_OFF;
		}
  }else{
		xReferStatus.eTransferStatus = IFX_OFF;
	}
#if 0
  if(pcState == NULL)
  {
    /* Since we do not accept any further notify to come*/
		IFX_SIPAPP_StopTimer(pxAppData->unNoNotifyId);
    return IFX_SIP_FAILURE;
  }
#endif
  /* An immediate response is sent as mandated by the RFC */
  IFX_SIP_NotifyRespond(uiSubscHdl, uiDlgHdl, 0, 200, NULL);

	if(pxAppData->iConnId2 != 0){
  	xReferStatus.ucIsAtx = 1;
	}
	/* If state is terminated need not wait for any notify, so stop the timer*/
	if(xReferStatus.eTransferStatus == IFX_OFF){
		IFX_SIPAPP_StopTimer(pxAppData->unNoNotifyId);
	}
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REFER_NOTIFY_RECV,
    &xReferStatus);

  if(xReferStatus.eTransferStatus == IFX_OFF)
  {
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);
  }

  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_REF_MsgToEncode
* Description      : This function will add custom headers to te message
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_REF_MsgToEncode(IN uint32 uiSipMsgHdl,
                           IN uint32 uiSubscHdl,
                           IN uint32 uiDlgHdl,
                           IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvUserData;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN];

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             " IFX_SIPAPP_REF_MsgToEncode");

  IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xFrom, acFrom);
  eRetVal = IFX_SIPAPP_SetContact(acFrom, uiSipMsgHdl, pxAppData->iProfileId);
  if(eRetVal == IFX_SIP_FAILURE)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               " Seting Contact Failed");
    return IFX_SIP_FAILURE;
  }
#ifdef STUN_SUPPORT
  IFX_SIPAPP_AddViaIfSTUNOn(uiSipMsgHdl, 1);
#endif
#ifdef IFX_INTERCOM_SUPPORT
  if(pxAppData->bIsIntercomTypeCall)
  {
    uint32 uiHdrHdl;
    e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
    eRetVal = IFX_SIP_GetHeaderByType(uiSipMsgHdl, IFX_SIP_TO, 1, &uiHdrHdl);
    if(eRetVal == IFX_SIP_SUCCESS)
    {
      IFX_SIP_ToFrom_SetGenericParam(uiHdrHdl, "intercom", "true");
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
                 " Added intercom flag to the REFER message");
    }
  }
#endif
  return IFX_SIP_SUCCESS;
}

/***********************************************************************
* Function Name : IFX_SIP_4xxSubscHdlr
* Description   : This function is called when 4xx for Subsc is received
* Input Values  :
* Return Value  : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_4xxReferHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                        IN uint32 uiMsgHdl,
                        IN uint32 uiDlgHdl)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 iAuthHdl = 0, iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  char8 *pcRealm = NULL;
  char8 acRealm[IFX_SIPAPP_MAX_TOKEN] = "";
  x_IFX_SIPAPP_ReferStatus xReferStatus;
  x_IFX_SIPAPP_AuthReqd xAuthReqd;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Subscribe 4xx Response recived");

  xReferStatus.pvAppData = (void *) pxAppData;
	xReferStatus.ucIsAtx = pxAppData->iConnId2;
  /* The assignment below handles the case where iRespCode is neither
     401 nor 407. */
  eRetVal = IFX_SIP_FAILURE;

  if(iRespCode == 401)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_WWW_AUTHENTICATE,
                1, &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 " Subscribe 4xx Response recived but no www Auth header found");
    }
  }
  else if(iRespCode == 407)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_PROXY_AUTHENTICATE,
                1, &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
        " Subscribe 4xx Response received but no www Auth header found");
    }
  }
	
	if(iAuthHdl)
	{
    pcRealm = IFX_SIP_Authentication_GetRealm(iAuthHdl);

	}
  /* Get the necessary information to search for proper credentials */
	if(pcRealm == NULL){
		IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"No Realm found");
		/* Absence of realm is considered as not having authenticate header */
    eRetVal=IFX_SIP_FAILURE;
	}

  if(eRetVal == IFX_SIP_FAILURE)
  {
    xReferStatus.eTransferStatus = IFX_OFF;
    xReferStatus.eReason = IFX_400_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_REFER_STATUS_RECV,
      &xReferStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);
    return eRetVal;
  }

  /* Since the Realm contain Quotes, the below logic is to remove the Quotes */
  strncpy(acRealm, pcRealm + 1, strlen(pcRealm) - 2);

  xAuthReqd.uiHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_REF];
  xAuthReqd.uiDlgHdl = uiDlgHdl;
  xAuthReqd.pcRealm = acRealm;
  xAuthReqd.uiSipMsgHdl = 0;

  /* This callback should ensure that Authentication with credentials happens */
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REFER_AUTH_REQD,
    &xAuthReqd);

  return IFX_SIP_SUCCESS;
}
/************************************************************************
* Function Name    : IFX_SIP_REF_PkgRecvSubscRsp
* Description      : This function handles the subscribe requests response
*                    for REF event package
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_REF_PkgRecvSubscRsp(IN uint32 uiDecodedMsgHdl,
                               IN uint32 uiSubscHdl,
                               IN uint32 uiDlgHdl,
                               IN void *pvUserData)
{
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiDecodedMsgHdl);
  e_IFX_SIP_Ecode eEcode;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *)pvUserData;
  x_IFX_SIPAPP_ReferStatus xReferStatus;

  xReferStatus.pvAppData = (void *) pxAppData;
	xReferStatus.ucIsAtx = pxAppData->iConnId2;

  if((nStatusCode >= 200) && (nStatusCode < 300))
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " subscription Refer recived 2xx response");
    IFX_SIPAPP_StopTimer(pxAppData->unNoNotifyId);

    /* Fill values*/
    xReferStatus.eTransferStatus = 
      (IFX_SIP_SubscGetState(uiSubscHdl, uiDlgHdl) ==
         IFX_SIP_SUBSC_TERMINATED) ? IFX_OFF : IFX_ON;
    xReferStatus.eReason = IFX_200_RESP;

    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REFER_STATUS_RECV,
      &xReferStatus);
    
	  /*Fix: 150908 If IFX_SIPAPP_NOTIFY_RCVD flag is set that do not start the timer.
		  This may occur when Notify request is received before REFER response */
		if(pxAppData->iFlag & IFX_SIPAPP_NOTIFY_RCVD)
		{
			IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"NOTIFY already received - No timer started");
		}
    if(xReferStatus.eTransferStatus == IFX_ON && !(pxAppData->iFlag & IFX_SIPAPP_NOTIFY_RCVD))
    {
      /* Start a no notification timer */
      IFX_SIPAPP_StartTimer(32000, IFX_SIP_REF_NotifyRecvTimeout, pxAppData,
        &pxAppData->unNoNotifyId, &eEcode);
    }
    eRetVal = IFX_SIP_SUCCESS;
  }
  else if((nStatusCode >= 400) && (nStatusCode < 500))
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " subscription Refer recived 4xx response");
    eRetVal = IFX_SIPAPP_4xxReferHdlr(pxAppData, uiDecodedMsgHdl, uiDlgHdl);
  }
  else
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      " subscription status OFF, recived 356xx Rsp clearing subsc node");
    xReferStatus.eTransferStatus = IFX_OFF;
    xReferStatus.eReason = IFX_500_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_REFER_STATUS_RECV,
      &xReferStatus);
    eRetVal = IFX_SIP_FAILURE;
  }

  return eRetVal;
}

/************************************************************************
* Function Name    : IFX_SIP_REF_PkgRecvNotifyRsp
* Description      : This function will handle the NOTIFY response
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_REF_PkgRecvNotifyRsp(IN uint32 uiDecodedMsgHdl,
                                IN uint32 uiSubscHdl,
                                IN uint32 uiDlgHdl,
                                IN void *pvUserData)
{
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiDecodedMsgHdl);
  x_IFX_SIPAPP_ReferStatus xReferStatus;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *)pvUserData;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " Notify Response Recived");

  xReferStatus.pvAppData = (void *) pxAppData;
	xReferStatus.ucIsAtx = pxAppData->iConnId2;

  if(IFX_SIP_SubscGetState(uiSubscHdl, uiDlgHdl) == IFX_SIP_SUBSC_TERMINATED)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " Notify Resp : Since terminated remove App data");
    xReferStatus.eTransferStatus = IFX_OFF;
  }
  else
  {
    xReferStatus.eTransferStatus = IFX_ON;
  }

  if((nStatusCode) >= 200 && (nStatusCode < 300))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " Notify Response 2xx Recived");
    xReferStatus.eReason = IFX_200_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_REFER_NOTIFY_STATUS_RECV, &xReferStatus);
    eRetVal = IFX_SIP_SUCCESS;
  }
  else if((nStatusCode) >= 400 && (nStatusCode < 500))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " Notify Refer recived 4xx response");
		if((nStatusCode != 401)&&(nStatusCode != 407)){
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
        IFX_REFER_NOTIFY_STATUS_RECV, &xReferStatus);
		}
		else{
			/* TODO: Check this code, it sends a refer again ?? */
      eRetVal = IFX_SIPAPP_4xxReferHdlr(pxAppData, uiDecodedMsgHdl, uiDlgHdl);
		}
    return eRetVal;
  }
  else
  {
    xReferStatus.eReason = IFX_500_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_REFER_NOTIFY_STATUS_RECV, &xReferStatus);
    eRetVal = IFX_SIP_FAILURE;
  }
  if(IFX_SIP_SubscGetState(uiSubscHdl, uiDlgHdl) == IFX_SIP_SUBSC_TERMINATED)
  {
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);
  }
/*
  if(!(pxAppData->iFlag & IFX_SIPAPP_DNP_NOTRSP))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Notify Status Posting to PA");
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
      IFX_REFER_NOTIFY_STATUS_RECV, &xReferStatus);
  }
  else
  {
    pxAppData->iFlag &= ~IFX_SIPAPP_DNP_NOTRSP;
  }
*/
  return eRetVal;
}

/************************************************************************
* Function Name    : IFX_SIP_REF_PkgRecvTimeOut
* Description      : This function will handle the transaction timeout while
*                    sending subscribe requests
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_REF_PkgRecvTimeOut(IN e_IFX_SIP_TransErrorCode eErrType,
                              IN uint32 uiSubscHdl,
                              IN uint32 uiDlgHdl,
                              IN void *pvUserData)
{
  x_IFX_SIPAPP_ReferStatus xReferStatus;
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *) pvUserData;

  xReferStatus.pvAppData = (void *) pxAppData;
  xReferStatus.eTransferStatus = IFX_OFF;
  xReferStatus.eReason = IFX_TIMEOUT;
  xReferStatus.ucIsAtx = pxAppData->iConnId2;
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_NOTIFY_STATUS,
    &xReferStatus);

  /* Remove the UserData */
  IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);

  return IFX_SIP_SUCCESS;
}
/************************************************************************
* Function Name    : IFX_SIP_REFPkgInit
* Description      : This function will initialize the REFER callbacks.
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/

PUBLIC e_IFX_SIP_Return IFX_SIPAPP_REFPkgInit(uint32 uiStackHdl)
{
  x_IFX_SIP_SubscCallBks xCallBks = {0};
  xCallBks.pfnNotifyReqArrived = IFX_SIPAPP_REF_PkgRecvNotify;
  xCallBks.pfnTimeOutOrError = IFX_SIPAPP_REF_PkgRecvTimeOut;
  xCallBks.pfnMsgToEncode = IFX_SIPAPP_REF_MsgToEncode;
  xCallBks.pfnSubscRespArrived = IFX_SIPAPP_REF_PkgRecvSubscRsp;
  xCallBks.pfnSubscReqArrived = IFX_SIPAPP_REF_PkgRecvSubsc;
  xCallBks.pfnNotifyRespArrived = IFX_SIPAPP_REF_PkgRecvNotifyRsp;
	xCallBks.uiStackHdl = uiStackHdl;
  return  IFX_SIP_SubscRegisterCallBks(IFX_SIP_SUBSC_REFER,
            120, 10, &xCallBks);
}

/******************************************************************
*  Function Name    :  IFX_SIP_SendRefer
*  Description      :  This function sends Refer message to the
*                      specified destination
*  Input Values     :
*  Output Values    :
*  Return Value     :  IFX_SIP_SUCCESS, IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendReferReq(IN uint32 uiCallId,
                        IN uint32 uiReplacesCallId,
                        IN x_IFX_CalledAddr *pxReferTo,
                        IN void *pvAppData)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvAppData,
                         *pxAppData1 = NULL;
  uint32 uiDlgListHdl=0,uiDlgHdl=0,uiRepDlgHdl=0,uiMsgHdl=0,uiHdrHdl=0;
  e_IFX_SIP_Ecode eCode;

  char8 acTo[IFX_SIPAPP_MAX_TOKEN],acFrom[IFX_SIPAPP_MAX_TOKEN];
  char8 acReferTo[IFX_SIPAPP_MAX_TOKEN];

  /* If refer has to be sent on existing dialog Identify the
   * required parameters */

  if(!pxAppData)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Cannot get App Data");
    return IFX_SIP_FAILURE;
  }

  {
    eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                       &uiDlgListHdl);
    if(eRetVal != IFX_SIP_FAILURE)
    {
      eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgListHdl,&uiDlgHdl,&eCode);
      if(eRetVal != IFX_SIP_SUCCESS)
      {
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Cannot get Dialog List");
        return eRetVal;
      }
    }
    else
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Cannot get Dialog List");
      return eRetVal;
    }
  }

  /* If refer with replaces has to be sent, ConnId2 would not be zero */
  if(uiReplacesCallId)
  {
		/*To FIX ATX status notification to application-radva*/
		pxAppData->iConnId2 =uiReplacesCallId;
		
    eRetVal = IFX_SIPAPP_GetAppData(uiReplacesCallId,&pxAppData1);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
      /* Inform the application about the same */
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Invalid Conn ID 2");
      return IFX_SIP_FAILURE;
    }
    eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData1->auiHdl[IFX_SIPAPP_UA_CALL],
                                       &uiDlgListHdl);
    if(eRetVal != IFX_SIP_FAILURE)
    {
       eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgListHdl,&uiRepDlgHdl,&eCode);
       if(eRetVal != IFX_SIP_SUCCESS)
       {
        IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Cannot get Dialog List in conn 2");
        return eRetVal;
       }
    }
    else
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Cannot get Dialog List in conn 2");
      return eRetVal;
    }
  }
  
  else
  {
   pxAppData->iConnId2 = 0;
  }
  /* Create the subscription */
  eRetVal = IFX_SIP_SubscCreate(pxAppData, IFX_SIP_SUBSC_REFER,
                    &pxAppData->auiHdl[IFX_SIPAPP_UA_REF]);
  if((eRetVal != IFX_SIP_SUCCESS))
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Could not send SUBSCRIBE to REFER");
    /* Remove App data */
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);
    return eRetVal;
  }
  else
  {
    if(IFX_SIPAPP_IS_PROXYON(pxAppData))
    {
      IFX_SIP_SubscSetNextHopAddr(pxAppData->auiHdl[IFX_SIPAPP_UA_REF],
        IFX_SIPAPP_GET_PROXYADDRESS(pxAppData),
        pxAppData->unLocalTcpPort,
        IFX_SIPAPP_GET_PROXYPORT(pxAppData),
        IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData));
    }
    /* Create Call, Fill Completely */
    IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo,acTo);
		/* If telnum or extension convert here */
   	if(IFX_SIPAPP_ConstAddr(pxReferTo,pxAppData)!= 
									IFX_SIP_SUCCESS){
      return IFX_SIP_FAILURE;
    }
    IFX_SIPAPP_ConvReferAddrToStr(pxReferTo,acReferTo);
    IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xFrom,acFrom);
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "sending SUBSCRIBE to REFER");
    /*Set the Accept Body*/
    IFX_SIP_CreateMsg(&uiMsgHdl);
    /* Adding Accept Hdr*/
    IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_ACCEPT,&uiHdrHdl);
    IFX_SIP_Accept_SetMType(uiHdrHdl,"message");
    IFX_SIP_Accept_SetMSubType(uiHdrHdl,"sipfrag");

    eRetVal = IFX_SIP_SendRefer(pxAppData->auiHdl[IFX_SIPAPP_UA_REF],
                    uiDlgHdl,acFrom,acTo,32,"refer",
                                uiMsgHdl,uiRepDlgHdl,acReferTo);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Could not send SUBSCRIBE to REFER");
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_REF);
      return eRetVal;
    }
    IFX_SIPAPP_StopTimer(pxAppData->unNoNotifyId);
  }
  return eRetVal;
}

/******************************************************************
*  Function Name    :  IFX_SIP_SendNotifyForRefer
*  Description      :  This function sends Notification message to the
*                      subscription created because of refer
*  Input Values     :  iConnId...Connection Identifier
*                      xRefer...Information requires to send a refer
*  Output Values    :  None
*  Return Value     :  success or failure
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendNotifyForRefer(IN uint32 uiCallId,
                              IN uint32 eReferStatus,
                              IN e_IFX_ReasonCode eReason,
                              IN x_IFX_CalledAddr *pxProxyAddr,
                              IN boolean bIsOutboundProxy,
                              IN void *pvAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData=pvAppData;
  uint32 uiDlgHdl=0,uiMsgHdl=0,uiHdrHdl=0;
  char8 *pcMsg;

  /*Locate the User Data */
  if(!pxAppData)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle ");
    return IFX_SIP_FAILURE;
  }

  /* IMPORTANT - This may be an updated value */
  pxAppData->iConnId = uiCallId;

  if(IFX_SIP_CreateMsg(&uiMsgHdl) != IFX_SIP_SUCCESS){
		return IFX_SIP_FAILURE;
	}
  /* Construct the message body */
  switch(eReason)
  {
    case  IFX_200_RESP:
      pcMsg = "SIP/2.0 200 OK";
      break;
    case IFX_300_RESP:
      pcMsg = "SIP/2.0 300 Multiple Choices";
      break;
    case  IFX_400_RESP:
      pcMsg = "SIP/2.0 400 Bad Request";
      break;
    case IFX_486_RESP:
      pcMsg = "SIP/2.0 486 Busy Here";
      break;
    case IFX_500_RESP:
      pcMsg = "SIP/2.0 500 Server Internal Error";
      break;
    default:
      pxAppData->iFlag |= IFX_SIPAPP_DNP_NOTRSP;
      pcMsg = "SIP/2.0 100 Trying";
      break;
  }
  IFX_SIP_AddMsgBody(uiMsgHdl,strlen(pcMsg),pcMsg);

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Setting Content Type");
  if(IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,&uiHdrHdl)
									!= IFX_SIP_SUCCESS){
		return IFX_SIP_FAILURE;
	}
  IFX_SIP_ContType_SetMType(uiHdrHdl,"message");
  IFX_SIP_ContType_SetMSubType(uiHdrHdl,"sipfrag");
  /* Send a notification */
  eRetVal = IFX_SIP_SendNotify(pxAppData->auiHdl[IFX_SIPAPP_UA_REF],
                           uiDlgHdl,eReferStatus,
                               IFX_SIP_EVNTRSN_NORESOURSE,uiMsgHdl);
  if(eRetVal != IFX_SIP_SUCCESS)
  {
    /* Assumes no Unsolicited Notifications for Refer */
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Failure in sending Notification");
  }
  return eRetVal;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_SetAuthDataForRefer
* Description      : This function will
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return 
IFX_SIPAPP_SetAuthDataForRefer(IN uint32 uiCBackId,
                               IN char8 *pcUserName,
                               IN char8 *pcPasswd,
                               IN void *pvAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_FAILURE;
  x_IFX_SIPAPP_AuthReqd *pxAuthReqd = (x_IFX_SIPAPP_AuthReqd *) pvAppData;

  if(pxAuthReqd)
  {
    eRetVal = IFX_SIP_SubscAuthorize(pxAuthReqd->uiHdl, pxAuthReqd->uiDlgHdl,
                pcUserName, pcPasswd, pxAuthReqd->uiSipMsgHdl);
  }
  else
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle ");
  }
  return eRetVal;
}
