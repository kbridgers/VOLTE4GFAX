/**************************************************************************
**   FILE NAME     : IFX_SIP_PLatform.c
**   PROJECT       : SIP
**   MODULES       : Transport
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004
**   AUTHOR        : Sip Team
**                   Jagadeesh N.G.( IMSENV part )
**   DESCRIPTION   : All portable functions used by transport module
**   COMPILER      : gcc 
**   REFERENCE     : Coding guide lines for VSS 
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"

#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"


#if defined(__LINUX__)||defined(WIN32_TIMERS)
#include <IFX_TLIB_Import.h>
#endif

#ifdef __IMSCORE__
#include "mmb_component_container_lh.h"
#include "mmb_ipstack_lh.h"
#include "mmb_error_ph.h"
#include "ifx_mmb_env.h"
#include "mmb_datetime_ph.h"
#endif



#define IFX_SIPAPP_TIMER_FIFO_NAME  "TimerFifo"
#define IFX_SIPAPP_MAX_TIMERS      100
#define IFX_SIPAPP_TIMER_PERMS    0666

extern uchar8 vcSipAppModId;
extern uint32 viAppRdFd;
extern x_IFX_SIPAPP_Notifiers vpxNotifier;

e_IFX_SIP_Return IFX_SIPAPP_DeleteTimerFromList(IN uint16);

STATIC e_IFX_SIP_Return
IFX_SIPAPP_GetTimerFromList(OUT x_IFX_SIPAPP_TimerInfo** pxTimerInfo);

x_IFX_SIPAPP_TimerInfo vxSipAppTimerInfo[IFX_SIPAPP_MAX_TIMERS];
extern void IFX_SIPAPP_RecvStunTimerMsgs( IN IFX_SIPAPP_fd_set *pxRdFdSet,
						                       IN IFX_SIPAPP_fd_set *pxWrFdSet,
                       						 IN IFX_SIPAPP_fd_set *pxExFdSet,
                      						 IN int32 *piNoFds);

void IFX_SIPAPP_TimeOutHandler(x_IFX_SIPAPP_TimerInfo*);


/* Initialization begin */
static int N = 624;
static int M = 397;
static int MATRIX_A = 0x9908b0df; /* private static final * constant vector*/
static int UPPER_MASK = 0x80000000; /* most significant w-r bits*/
static int LOWER_MASK = 0x7fffffff; /* least significant r bits*/


/* Tempering parameters*/
static int TEMPERING_MASK_B = 0x9d2c5680;
static int TEMPERING_MASK_C = 0xefc60000;

static int mt[624]; /* the array for the state vector */
static int mti; /* mti==N+1 means mt[N] is not initialized */
static int mag01[2];

/******************************************************************
*  Function Name  :  IFX_SIP_RandomNumber
*  Description    :  this function is generates the random number
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  a random number
*  Notes          : 
*********************************************************************/
uint32
IFX_SIPAPP_RandomNumber() {
  static int iFirstTime = 0;
  if (iFirstTime == 0) {
#ifdef __LINUX__
    mt[0] = ((unsigned int)(time(0))) & 0xffffffff;
#else
	mt[0] = (IFX_SIPAPP_Time(0)) & 0xffffffff;
#endif
    for (mti = 1; mti < N; mti++) {
      mt[mti] = (69069 * mt[mti - 1]) & 0xffffffff;
    }

    mag01[0] = 0x0;
    mag01[1] = MATRIX_A;
    iFirstTime = 1;
  }
  {
    int y;

    if (mti >= N) /* generate N words at one time */
    {
      int kk;

      for (kk = 0; kk < N - M; kk++) {
        y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
        mt[kk] = mt[kk + M] ^ (y >> 1) ^ mag01[y & 0x1];
      }
      for (; kk < N - 1; kk++) {
        y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
        mt[kk] = mt[kk + (M - N)] ^ (y >> 1) ^ mag01[y & 0x1];
      }
      y = (mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
      mt[N - 1] = mt[M - 1] ^ (y >> 1) ^ mag01[y & 0x1];

      mti = 0;
    }

    y = mt[mti++];
    y ^= y >> 11; /*    TEMPERING_SHIFT_U(y)*/
    y ^= (y << 7) & TEMPERING_MASK_B; /* TEMPERING_SHIFT_S(y)*/
    y ^= (y << 15) & TEMPERING_MASK_C; /* TEMPERING_SHIFT_T(y)*/
    y ^= (y >> 18); /* TEMPERING_SHIFT_L(y)*/

    return y;
  }
}
/******************************************************************
*  Function Name:  IFX_SIP_strncasecmp
*  Description  :  Compares two strings ignoring the case
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/

int32
IFX_SIPAPP_strncasecmp(const char* pszString1,
                     const char* pszString2,
                     int32 iSize)
{
#ifdef __LINUX__
  return strncasecmp(pszString1,pszString2,iSize);
#endif
#ifdef __IMSENV__
  T_Mmb_HString pszstr1 = NULLP;
  T_Mmb_HString pszstr2 = NULLP;
  T_Mmb_Int8 stat=0;
  int32 err=IFX_SIP_SUCCESS;

  if(e_Mmb_ErrOk != Mmb_StringNCreateFromAscii(pszString1,iSize, &pszstr1))
  {
	    err = IFX_SIP_FAILURE;
  }
  if(e_Mmb_ErrOk != Mmb_StringNCreateFromAscii(pszString2,iSize, &pszstr2))
  {
	    err =  IFX_SIP_FAILURE;
  }
  if(  (err ==  IFX_SIP_SUCCESS) && 
       (e_Mmb_ErrOk != Mmb_StringNCompareNoCase(pszstr1, pszstr2, 0, iSize, &stat)) )
  {
        err = IFX_SIP_FAILURE;
  }
  Mmb_StringDestroy(&pszstr1);
  Mmb_StringDestroy(&pszstr2);
  if(err == IFX_SIP_FAILURE)
	return IFX_SIP_FAILURE;
  else
    return (int32)stat;

#endif
}

/******************************************************************
*  Function Name:  IFX_SIP_strcasecmp
*  Description  :  Compares two strings ignoring the case
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/

int32
IFX_SIPAPP_strcasecmp(const char* pszString1,
                    const char* pszString2)
{
#ifdef __LINUX__
  return strcasecmp(pszString1,pszString2);
#endif
#ifdef __IMSENV__
  T_Mmb_HString pszstr1 = NULLP;
  T_Mmb_HString pszstr2 = NULLP;
  T_Mmb_Int8 stat=0;
  int32 err=IFX_SIP_SUCCESS;

  if(e_Mmb_ErrOk != Mmb_StringCreateFromAscii(pszString1, &pszstr1))
  {
	    err = IFX_SIP_FAILURE;
  }
  if(e_Mmb_ErrOk != Mmb_StringCreateFromAscii(pszString2, &pszstr2))
  {
	    err = IFX_SIP_FAILURE;
  }
  if ( (err == IFX_SIP_SUCCESS) && 
       (e_Mmb_ErrOk != Mmb_StringCompareNoCase(pszstr1, pszstr2, &stat)) )
  {
     err = IFX_SIP_FAILURE;
  }
  Mmb_StringDestroy(&pszstr1);
  Mmb_StringDestroy(&pszstr2);
  if(err == IFX_SIP_FAILURE)
	return IFX_SIP_FAILURE;
  else
    return (int32)stat;

#endif
}

/*****************************************************************************
 *  Function Name :  IFX_SIPAPP_GetHostIp
 *  Description   :  Function to get the local host IP Address
 *  Input Values  :  Interface Name
 *  Output Values :  Pointer Host IP Address
 *  Return Value  :
 *  Notes         :
 *****************************************************************************/
PUBLIC char8
IFX_SIPAPP_GetHostIp(OUT char8 * pcHostIp)
{
  int iRetVal = 0;
#ifdef __IMSENV__
{
  T_Mmb_UInt16 iConnectionId;
  T_Mmb_ApplicationType eApplication = e_Mmb_ConnectionTypeIms;
  T_Mmb_HString hIPAddress = NULLP; 
  T_Mmb_HLinkProvider hLinkProvider = NULL;
  T_Mmb_Error eType = e_Mmb_ErrOk;
       
  /* Get the IP Address from the link provider */
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hcontainer = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hcontainer))
  {
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetLinkProvider( hcontainer,&hLinkProvider))
  {
	  return IFX_SIP_FAILURE;
  }
#else
  if(eType != Mmb_LinkProviderCreate(&hLinkProvider))
  {
	  return IFX_SIP_FAILURE;
  }
#endif 
  if(eType != Mmb_LinkProviderGetPrimaryPdpContextId(hLinkProvider,eApplication,&iConnectionId))
  {
	  return IFX_SIP_FAILURE;
  }
   if(eType != Mmb_LinkProviderCreate(&hLinkProvider))
  {
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_StringCreateNullString(&hIPAddress))
  {
	  Mmb_LinkProviderDestroy(&hLinkProvider);
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_LinkProviderGetIPAddress(hLinkProvider,iConnectionId,hIPAddress))
  {
	  Mmb_LinkProviderDestroy(&hLinkProvider);
	  Mmb_StringDestroy(&hIPAddress);
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_StringConvertStringToAscii(hIPAddress, pcHostIp))
  {
	  Mmb_LinkProviderDestroy(&hLinkProvider);
	  Mmb_StringDestroy(&hIPAddress);
	  return IFX_SIP_FAILURE;
  }
  if(hIPAddress != NULL)
	Mmb_StringDestroy(&hIPAddress);
  Mmb_LinkProviderDestroy(&hLinkProvider);
 }
#else 
  strcpy(pcHostIp,"127.0.0.1");
#endif
   return iRetVal;
}

/*******************************************************************************
*  Function Name : IFX_SIP_CreateThread
*  Description   : Creates thread
*  Input Values  : None
*  Output Values : None
*  Return Value  : IFX_SIP_SUCCESS 
*                  IFX_SIP_FAILURE
*  Notes         : 
*******************************************************************************/

uint32 IFX_SIPAPP_CreateThread(void * (*start_routine)(void *),void* pvParam)
{
#ifdef __IMSENV__
  struct T_Mmb_SThread Thread;
  T_Mmb_HThread hSipThread = NULLP;
  T_Mmb_UInt32 iThreadId;
  T_Mmb_Error eType = e_Mmb_ErrOk;
  
  memset(&Thread,0,sizeof(struct T_Mmb_SThread));
  Thread.fnThread = (T_Mmb_ThreadFunction) start_routine;
  Thread.m_data = pvParam;
  if(eType != Mmb_CreateThread (&Thread,&hSipThread))
  {
    return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_RunThread(&hSipThread))
  {
    return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_GetThreadID (hSipThread, &iThreadId))
  {
    return IFX_SIP_FAILURE;
  } 
  if(iThreadId == 0){
      return 0;
  }
  return iThreadId;
#endif 
#ifdef __LINUX__
  pthread_t uiThreadId = 0;
  pthread_attr_t xAttrib;
  int32 iRetVal;
  iRetVal = pthread_attr_init(&xAttrib);
  iRetVal = pthread_attr_setdetachstate(&xAttrib, PTHREAD_CREATE_DETACHED);
  if ((iRetVal =
         pthread_create(&uiThreadId, &xAttrib,start_routine,
                        pvParam)) != 0) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "SIP stack Thread Creation Error");
    return 0;
  }
  return uiThreadId;
#endif
}

/*************************************************************************
*  Function Name:  IFX_SIPAPP_SendSockMsg
*  Description  :  This function post a IPC message to internal sip sock
*  Input Values :  
*  Output Values:  
*  Return Value :  -1 on failure and size of dns pkt in terms of bytes 
*                  on success 
***************************************************************************/
PUBLIC char8
IFX_SIPAPP_SendSockMsg(IN int32 iFd,      /* FIFO fd */
                IN uchar8 ucFrom,         /* Module Id of the addressee */
                IN uchar8 ucTo,           /* Module Id of the addressed */
                IN uint16 unMsgSize,      /* Size of message */
                IN uint32 uiReserved,
                IN char8 *pcMsg,
				IN char8 *pcHostIP)       /* Pointer to message */
{
x_IFX_IPC_Msg xMsg; 
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_HString hString = NULLP;
  T_Mmb_Int32 iLength;
  T_Mmb_Error eType = e_Mmb_ErrOk;
#endif 
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
  	return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
  	return IFX_SIP_FAILURE;
  }
#endif
  memset(&xMsg, 0, sizeof(x_IFX_IPC_Msg));

  xMsg.xHdr.ucFrom = ucFrom;
  xMsg.xHdr.ucTo = ucTo;
  xMsg.xHdr.unMsgSize = unMsgSize;
  xMsg.xHdr.uiReserved = uiReserved;
  if(unMsgSize > IFX_IPC_MAX_MSG_SIZE){

	  return IFX_SIP_FAILURE;
  }
  memcpy(xMsg.acMsg, pcMsg, unMsgSize);
#ifdef __IMSENV__
  /* Open an Internal socket for communication */
  iFd = IFX_SIPAPP_CreateSocket(IFX_SIPAPP_PROTOCOL_UDP,0,
  0,pcHostIP,0,IFX_SIPAPP_TCP_SOCKTYPE_CLIENT);
 
  if(iFd < 0)
    {
      return IFX_SIP_FAILURE;
    }

  if(eType != Mmb_StringCreateFromAscii(pcHostIP, &hString))
  {
    return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_IpStackGetSock(hThis, iFd, &hSock))
  {
    return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_IpStackSendTo(hSock, hString, IFX_SIPAPP_INTERNAL_PORT, (T_Mmb_UInt8*)&xMsg, unMsgSize + IFX_IPC_HDR_SIZE, 0, &iLength))
  {
    return IFX_SIP_FAILURE;
  }
  Mmb_StringDestroy(&hString);
  IFX_SIPAPP_Close(iFd);
  if((uint16)iLength != (unMsgSize + IFX_IPC_HDR_SIZE)){
    return IFX_SIP_FAILURE;
 }
#endif
#ifdef __LINUX__ 
  IFX_SIPAPP_Write(iFd,&xMsg,unMsgSize + IFX_IPC_HDR_SIZE);
#endif
  return IFX_SIP_SUCCESS;
}
/*******************************************************************************
*  Function Name : IFX_SIPAPP_RecvSockMsg
*  Description   : Receive Internal sock message
*  Input Values  : None
*  Output Values : None
*  Return Value  : IFX_SIP_SUCCESS 
*                  IFX_SIP_FAILURE
*  Notes         : 
*******************************************************************************/
PUBLIC char8
IFX_SIPAPP_RecvSockMsg(IN int32 iFd,
                    OUT uchar8 * pucFrom,
                    OUT uchar8 * pucTo,
                    OUT uint16 * punMsgSize,
                    OUT uint32 * puiReserved,
                    OUT char8 * pcMsg,
                    OUT char8 * pErr)
{
   x_IFX_IPC_MsgHdr *pxHdr;
   int16 nBytes = 0;
   char8 acBuff[512];
#ifdef __LINUX__
   struct sockaddr xFrom;
   socklen_t xLen;
#endif

#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULL;
  T_Mmb_UInt32 iRecvLen;
  T_Mmb_HString phPeerAddress = NULLP;
  T_Mmb_UInt16 iPort;
  T_Mmb_Error eType = e_Mmb_ErrOk;
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
    return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
    return IFX_SIP_FAILURE;
  }
#endif
  if(eType != Mmb_IpStackGetSock(hThis, iFd, &hSock))
  {
    return IFX_SIP_FAILURE;
  }
  //TODO will not work for ipv6
  /*if(eType != Mmb_StringCreateFromAscii("000.000.000.000",&phPeerAddress))
  {
    return IFX_SIP_FAILURE;
  }*/
  if(eType != Mmb_IpStackRecvFrom(hSock, 0, (T_Mmb_UInt32)(sizeof(x_IFX_SIPAPP_TimerInfo)+IFX_IPC_HDR_SIZE),(T_Mmb_UInt8*) &acBuff, &iRecvLen,	
    &phPeerAddress, &iPort))
  {
    /* Error Reading Header */
    /* Add Debugs if required */
    *pErr = IFX_IPC_FIFO_READ_ERR;
	Mmb_StringDestroy(&phPeerAddress);
    return IFX_SIP_FAILURE;
  }
  pxHdr = (x_IFX_IPC_MsgHdr *)acBuff;
  *pucFrom = pxHdr->ucFrom;
  *pucTo = pxHdr->ucTo;
  *punMsgSize = pxHdr->unMsgSize;
  *puiReserved = pxHdr->uiReserved;
  if((*pucFrom > IFX_IPC_APP_ID_SNMP) 
      || (*pucTo > IFX_IPC_APP_ID_SNMP)
      || (*punMsgSize > IFX_IPC_MAX_MSG_SIZE))
   {
	 Mmb_StringDestroy(&phPeerAddress);
     return IFX_IPC_FAIL;
   }

   memcpy(pcMsg,&acBuff[IFX_IPC_HDR_SIZE],*punMsgSize);
   Mmb_StringDestroy(&phPeerAddress);
#endif 
#ifdef __LINUX__
   if (((nBytes = recvfrom(iFd,&acBuff,sizeof(x_IFX_SIPAPP_TimerInfo)+IFX_IPC_HDR_SIZE,0,
         &xFrom,&xLen))) < 0)
   {
      /* Error Reading Header */
      /* Add Debugs if required */
      *pErr = IFX_IPC_FIFO_READ_ERR;
       perror("The error is");
      return IFX_IPC_FAIL;
   }
   pxHdr = (x_IFX_IPC_MsgHdr *)acBuff;
   *pucFrom = pxHdr->ucFrom;
   *pucTo = pxHdr->ucTo;
   *punMsgSize = pxHdr->unMsgSize;
   *puiReserved = pxHdr->uiReserved;

   if((*pucFrom > IFX_IPC_APP_ID_SNMP)
       || (*pucTo > IFX_IPC_APP_ID_SNMP)
       || (*punMsgSize > IFX_IPC_MAX_MSG_SIZE))
   {
     return IFX_IPC_FAIL;
   }
	 if(*punMsgSize<(512-IFX_IPC_HDR_SIZE)){
     memcpy(pcMsg,&acBuff[IFX_IPC_HDR_SIZE],*punMsgSize);
	 }
	 else{
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
             "Array out of bound");
	 }
#endif
   return IFX_IPC_SUCCESS;
}
/******************************************************************
 *  Function Name    : IFX_SIPAPP_CreateSocket
 *  Description      : This function Creates a TCP/UDP Socket
 *  Input Values     : Protocol Type (TCP/UDP)
 *                     Local Port
 *                     Remote Port
 *                     Remote IP Address
 *                     TCP Socket Type (Server / Client)
 *  Output Values    : None
 *  Return Value     : Socket Fd (on Success) or -1 (on Failure)
 *  Notes            :
*******************************************************************/
PUBLIC int32
IFX_SIPAPP_CreateSocket(IN uchar8 ucProtocol,
                    IN uint16 unLocalPort,
                    IN uint16 unRemotePort,
                    IN char8 * pacLocalIpAddress,
                    IN char8 * pacRemoteIpAddress,
                    IN uchar8 ucTcpSocketType)
{
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_Error eType = e_Mmb_ErrOk;
  T_Mmb_HString hLocalString = NULLP, hRemoteString = NULLP;
  T_Mmb_UInt16 iNumber;
  T_Mmb_SocketAddrFamily eIp4SockFamily = IFX_SOCK_AF_INET;
  T_Mmb_SocketType eTcpSock = IFX_SOCK_STREAM;
  T_Mmb_SocketType eUdpSock = IFX_SOCK_DGRAM;
  T_Mmb_SocketOptionsLevel eBsdsock = e_SOCK_BSD_SOL_SOCKET;
  T_Mmb_SocketOptions eSockOption = e_SOCK_BSD_SO_REUSEADDR;
  T_Mmb_Int32 iSockFd = -1, iResult = 0;
  T_Mmb_UInt32 iOn = 1;
  T_Mmb_UInt16  piConnectionId = 0;
  /* Create the Socket */
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;
  T_Mmb_HLinkProvider hlinkpvdr = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetLinkProvider(hHandle, &hlinkpvdr))
  {
	  return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_LinkProviderGetPrimaryPdpContextId(hlinkpvdr, e_Mmb_ConnectionTypeDefault, &piConnectionId))
  {
	  return IFX_SIP_FAILURE;
  }
#endif 
if(ucProtocol == IFX_SIPAPP_PROTOCOL_TCP){
  if(eType != Mmb_IpStackSocket(hThis, eIp4SockFamily, eUdpSock, 0,
     &hSock ))
  {
	  return IFX_SIP_FAILURE;
  }
  /* HACK */
  /*
  iSockFd = hSock;
  */
  iSockFd = (int32)hSock->sock;
  
 }
  else if (ucProtocol == IFX_SIPAPP_PROTOCOL_UDP)
  {
    if(eType != Mmb_IpStackSocket(hThis, eIp4SockFamily, eUdpSock, 0, &hSock ))
    {
      return IFX_SIP_FAILURE;
    }
	/* HACK */
    /*
    iSockFd = hSock;
	*/
    iSockFd = (int32)hSock->sock;
  }
  else
  {
    return iSockFd;
  }
  /* Set the connection id for the created socket.*/
  if(eType != Mmb_IpStackSetSockId(hSock, piConnectionId))
   {
      return IFX_SIP_FAILURE;
    }
  if(iSockFd < 0)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
             "Error Creating Socket : Type %d", ucProtocol);
    goto Fail;
  }
  if(ucProtocol == IFX_SIPAPP_PROTOCOL_TCP)
  {
    if(eType != Mmb_IpStackSetSockOpt(hSock, eBsdsock, 
       eSockOption, &iOn, sizeof(iOn)))
    {
     return  IFX_SIP_FAILURE;
    }
  }
  iNumber = unLocalPort;
  if(eType != Mmb_StringCreateFromAscii(pacLocalIpAddress, &hLocalString))
  {
      return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_IpStackBind(hSock, hLocalString, iNumber))
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
             "Error Binding Socket : Type %d", ucProtocol);
    goto Fail;
  }
  Mmb_StringDestroy(&hLocalString);
   /* If the protocol is TCP, we need to know the type of socket.
    * Whether its a server socket or a client socket
    */
  if(ucProtocol == IFX_SIPAPP_PROTOCOL_TCP)
  {
    if(ucTcpSocketType == IFX_SIPAPP_TCP_SOCKTYPE_CLIENT)
	{
      inet_pton(IFX_SOCK_AF_INET,pacRemoteIpAddress,hRemoteString);
      iNumber = Mmb_htons(unRemotePort);
      /* TODO: return proper error, usefule when socket is used in 
         non-blocking mode */ 
	  if(eType != Mmb_IpStackConnect(hSock, hRemoteString, iNumber))
	  {
         IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
                  "Error Connecting to Remote Socket");
         goto Fail;
      }
    }
      else if (ucTcpSocketType == IFX_SIPAPP_TCP_SOCKTYPE_SERVER)
	  {
        if(eType != Mmb_IpStackListen(hSock, 5))
	    {
	      return IFX_SIP_FAILURE;
	    }
      }
	 Mmb_StringDestroy(&hRemoteString);
  }
#endif 
#ifdef __LINUX__
   int32 iSockFd = -1, iResult = 0;
   int32 iOn = 1;
   struct sockaddr_in xLocalAddr, xRemoteAddr;

   /* Create the Socket */
   if (ucProtocol == IFX_SIPAPP_PROTOCOL_TCP)
   {
      iSockFd = socket(AF_INET, SOCK_STREAM, 0);
   }
   else if (ucProtocol == IFX_SIPAPP_PROTOCOL_UDP)
   {
      iSockFd = socket(AF_INET, SOCK_DGRAM, 0);
   }
   else
   {
      return iSockFd;
   }
   if (iSockFd < 0)
   {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Error Creating Socket : Type %d", ucProtocol);
      goto Fail;
   }
   if (ucProtocol == IFX_SIPAPP_PROTOCOL_TCP)
   {
      setsockopt(iSockFd, SOL_SOCKET, SO_REUSEADDR, &iOn, sizeof(iOn));
   }

   bzero(&xLocalAddr, sizeof(xLocalAddr));
   xLocalAddr.sin_family = AF_INET;
   xLocalAddr.sin_addr.s_addr = inet_addr(pacLocalIpAddress);
   xLocalAddr.sin_port = htonl(unLocalPort);

   /* Bind the Socket to the local port */
   iResult = bind(iSockFd, (struct sockaddr *) &xLocalAddr, sizeof(xLocalAddr));
   if (iResult < 0)
   {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Error Binding Socket : Type %d", ucProtocol);
      goto Fail;
   }

   /* If the protocol is TCP, we need to know the type of socket.
    * Whether its a server socket or a client socket
    */
   if (ucProtocol == IFX_SIPAPP_PROTOCOL_TCP)
   {
      if (ucTcpSocketType == IFX_SIPAPP_TCP_SOCKTYPE_CLIENT)
      {
         bzero(&xRemoteAddr, sizeof(xRemoteAddr));
         xRemoteAddr.sin_family = AF_INET;
         inet_pton(AF_INET, pacRemoteIpAddress,  &xRemoteAddr.sin_addr);
         xRemoteAddr.sin_port = htons(unRemotePort);

         iResult = connect(iSockFd, (struct sockaddr *) &xRemoteAddr,
                                          sizeof(xRemoteAddr));
         if (iResult < 0)
         {
            IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                     "Error Connecting to Remote Socket");
            goto Fail;
         }
      }
      else if (ucTcpSocketType == IFX_SIPAPP_TCP_SOCKTYPE_SERVER)
      {
         listen(iSockFd, 5);
      }
   }
#endif
   return iSockFd;

Fail :
   return iSockFd;

}
/************************************************************************
 * Function Name    : IFX_SIPAPP_SocketInit
 * Description      : This function will create FIFO's ,open the created
 *                    FIFO's in the read and write mode.Add the FIFO fd's
 *                    to the FD_SET
 * Input Values   : void
 * Output Values  : None
 * Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
 * Notes          :
 * *************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SocketInit()
{
  char8 acAddr[128];
  IFX_SIPAPP_GetHostIp(acAddr);
#ifdef __IMSENV__
  /* Open an Internal socket for communication */
  viAppRdFd = 
          IFX_SIPAPP_CreateSocket(IFX_SIPAPP_PROTOCOL_UDP,IFX_SIPAPP_INTERNAL_PORT,
		  0,acAddr,0,IFX_SIPAPP_TCP_SOCKTYPE_CLIENT);
  if(viAppRdFd < 0)
  {
    return IFX_SIP_FAILURE;
  }
  /* Connect the socket */
  /* Add SIP read FIFO to select list */
  vpxNotifier.pfAddFdToSelect(viAppRdFd,IFX_SIP_READ_FDSET,IFX_SIPAPP_RecvStunTimerMsgs);
#endif
#ifdef __LINUX__
 { struct sockaddr_in xDestAddr;
	 char8 acCommand[256]= "";
	 sprintf(acCommand,"/etc/rc.d/port_drill intport udp %d",IFX_SIPAPP_INTERNAL_PORT);
	 system(acCommand);
   /* Open an Internal socket for communication */
   viAppRdFd = 
           IFX_SIPAPP_CreateSocket(IFX_SIPAPP_PROTOCOL_UDP,IFX_SIPAPP_INTERNAL_PORT,0,
		                        acAddr,0,IFX_SIPAPP_TCP_SOCKTYPE_CLIENT);
   if(viAppRdFd < 0){
     return IFX_SIP_FAILURE;
   }
   /* Connect the socket */
   xDestAddr.sin_family = AF_INET;
   xDestAddr.sin_port = htons(IFX_SIPAPP_INTERNAL_PORT);
   inet_pton(AF_INET, "127.0.0.1",&xDestAddr.sin_addr);

   if((connect(viAppRdFd,(struct sockaddr*)&xDestAddr,
            sizeof(xDestAddr))) == -1){
     return IFX_SIP_FAILURE;
   }
   /* Add SIP read FIFO to select list */
  vpxNotifier.pfAddFdToSelect(viAppRdFd,IFX_SIP_READ_FDSET,IFX_SIPAPP_RecvStunTimerMsgs);
 }
#endif
 return IFX_SIP_SUCCESS;
}

/*******************************************************************************
*  Function Name:  IFX_SIPAPP_CloseSocket
*  Description  :  Function to close a socket
*  Input Values  : int32: sockfd to close 
*  Output Values : 
*  Return Value  : 
*  Notes         : 
*******************************************************************************/
void
IFX_SIPAPP_CloseSocket(int32 iSockFd) {
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_Error eType = e_Mmb_ErrOk;
#endif 
  /* remove the socket descriptor from the global FDSET */
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
    return;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
    return;
  }
#endif 
  //IFX_SIPAPP_RemoveFromFDSet(iSockFd,);
#ifdef __IMSENV__
  if(eType != Mmb_IpStackGetSock(hThis, iSockFd, &hSock))
  {
    return;
  }
  if(eType != Mmb_IpStackCloseSocket(hThis, hSock))
  {
    return;
  } 	
#endif 
#ifdef __LINUX__
  close(iSockFd);
#endif
}

/*******************************************************************************
*  Function Name:  IFX_SIPAPP_IsFDSet
*  Description  :  Function to check if socket descriptor is set in a fd set
*  Input Values  : int32: sockfd to check
fd_set* : fd set where to check
*  Output Values : 
*  Return Value  : int32: set or not (1/0)
*  Notes         : 
*******************************************************************************/
int32
IFX_SIPAPP_IsFDSet(int32 iSockFd,
                   IFX_SIPAPP_fd_set* pxFdSet)
{
#ifdef __IMSENV__
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_Error eType = e_Mmb_ErrOk;
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
    return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
    return IFX_SIP_FAILURE;
  } 
#endif 
#ifdef THREAD_SAFE
  IFX_SIP_LockAcquire(xSockDescLock);
#endif /*THREAD_SAFE*/
  if(eType != Mmb_IpStackGetSock(hThis, iSockFd, &hSock))
  {
    return IFX_SIP_FAILURE;
  }
  if(IFX_FD_ISSET(hSock,(pxFdSet))){
#ifdef THREAD_SAFE
  IFX_SIP_LockRelease(xSockDescLock);
#endif /*THREAD_SAFE*/
    return 1;
}
  else{ 
#ifdef THREAD_SAFE
  IFX_SIP_LockRelease(xSockDescLock);
#endif /*THREAD_SAFE*/
    return 0;
  }

#endif
#ifdef __LINUX__
#ifdef THREAD_SAFE
  IFX_SIP_LockAcquire(xSockDescLock);
#endif /*THREAD_SAFE*/
  if(IFX_SIPAPP_FdIsSet(iSockFd, pxFdSet)) {
#ifdef THREAD_SAFE
  IFX_SIP_LockRelease(xSockDescLock);
#endif /*THREAD_SAFE*/
    return 1;
  }
  else {
#ifdef THREAD_SAFE
  IFX_SIP_LockRelease(xSockDescLock);
#endif /*THREAD_SAFE*/
    return 0;
  }
#endif
}



#ifdef __IMSENV__

void IFX_SIPAPP_ThreadExit(int iRet)
{  
  T_Mmb_UserData * HThread = NULLP;
 
  Mmb_DestroyThread ( HThread,(int16)iRet );

}

int32 IFX_SIPAPP_ThreadSelf(void)
{
	T_Mmb_UserData pHThread = NULLP;
	T_Mmb_UInt32 iThreadID;
	T_Mmb_Error eType = e_Mmb_ErrOk;
    
	if(eType != Mmb_GetCurrentThreadID(&iThreadID))
	{
		return IFX_SIP_FAILURE;
	}
    return iThreadID;
}

IFX_SIPAPP_ThreadCleanUpPush(void *Pfn, short Id)
{
}

IFX_SIPAPP_ThreadCleanUpPop(int x)
{
}

int32 IFX_SIPAPP_FdIsSet(int32 iFd, T_Mmb_SIfxSockFdSet *pFdSet)
{
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_Error eType = e_Mmb_ErrOk;
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
	return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
	return IFX_SIP_FAILURE;
  }
#endif 

  if(eType != Mmb_IpStackGetSock(hThis, iFd, &hSock))
  {
	return IFX_SIP_FAILURE;
  }
  return IFX_FD_ISSET(hSock,pFdSet);
}

int32 IFX_SIPAPP_Close(int32 Fd)
{
  T_Mmb_HIfxSocket hSock = NULLP;
  T_Mmb_Error eType = e_Mmb_ErrOk;
#ifdef __IMSCORE__
  T_Mmb_HComponentContainer hHandle = NULLP;
  T_Mmb_HIpStack hThis = NULLP;

  if(eType != Mmb_ComponentContainerGetHandle(&hHandle))
  {
	return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_ComponentContainerGetIpStack(hHandle, &hThis))
  {
	return IFX_SIP_FAILURE;
  }
#endif 
  if(eType != Mmb_IpStackGetSock(hThis, Fd, &hSock))
  {
	return IFX_SIP_FAILURE;
  }
  if(eType != Mmb_IpStackCloseSocket(hThis, hSock))
  {
	return IFX_SIP_FAILURE;
  }
  return 1;
}




void * IFX_SIPAPP_Malloc(int32 iBytes)
{
   T_Mmb_Error ret = e_Mmb_ErrOk;
   void * ppMem = NULLP;

   ret = Mmb_Alloc(iBytes,  &ppMem);
   if(ret != e_Mmb_ErrOk)
	   return NULLP;
   else
    {
	   Mmb_MemSet(ppMem, '\0', iBytes);
	   return ppMem;
	}
}
int32 IFX_SIPAPP_Time(int32 *t)
{
	T_Mmb_HDatetime hThis;
	T_Mmb_UInt32 piSecond = 0;
	T_Mmb_Error err = e_Mmb_ErrOk;

    err = Mmb_DatetimeCreate (&hThis);
    if(err != e_Mmb_ErrOk)
		{
		Mmb_DatetimeDestroy(&hThis);
        return IFX_SIP_FAILURE;
		}
	err = Mmb_DatetimeGetCurrentTime(hThis);
	if(err != e_Mmb_ErrOk)
		{
		Mmb_DatetimeDestroy(&hThis);
        return IFX_SIP_FAILURE;
		}
    err = Mmb_DatetimeGetTimeInSecs(hThis, &piSecond);
	Mmb_DatetimeDestroy(&hThis);
    if(err != e_Mmb_ErrOk)
   	   return IFX_SIP_FAILURE;
	if(t != NULLP)
	{
		*t = piSecond;
	    return 0;
	}
	else 
        return(piSecond);
}

void* IFX_SIPAPP_Calloc(int num, int size)
{
   void *ret;
   T_Mmb_Error mmb_ret = e_Mmb_ErrOk;
 
   if (size != 0 && (num * size) / size != num) {
        return (NULLP);
    }
   mmb_ret = Mmb_Alloc((num * size), &ret);
   if (mmb_ret != e_Mmb_ErrOk)
	   return NULLP;
   else
	{
      Mmb_MemSet(ret, '\0', num * size);
 	    return (ret);
 	 }
}
#endif 


/******************************************************************
*  Function Name  :  IFX_SIPAPP_TimerInit
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_TimerInit() {
  static char8 cOneTimeFlag = 1;
  uchar8 iCount;
  if(cOneTimeFlag){
    cOneTimeFlag =0;
#ifndef IFX_CALLMGR		
#ifdef __LINUX__
 if (IFX_TLIB_TimersInit(IFX_SIPAPP_MAX_TIMERS) == IFX_TLIB_FAIL) {
    return IFX_SIP_FAILURE;
  }
#endif
#endif 
  /* initialize the timer list */
  for (iCount = 0; iCount < IFX_SIPAPP_MAX_TIMERS; iCount++) {
    vxSipAppTimerInfo[iCount].cIsFree = 'y';
#ifdef __IMSENV__
    vxSipAppTimerInfo[iCount].iFired = 0;
    vxSipAppTimerInfo[iCount].pvTimerId = NULL;
#endif
  }
  
 }
 return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  :  IFX_SIPAPP_StartTimer
*  Description    :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_StartTimer(IN uint32 uiTimeOutValue, /* milli seconds */
    IN void* pfn_IFX_SIP_CallBackFn,
    IN void* pCallBackFnParam,
    OUT uint16* punTimerId,
    OUT uint32* peEcode) {
  uint16 unTempTimerId;

  x_IFX_SIPAPP_TimerInfo* pxTimerInfo;
#if defined(__IMSENV__)&&!(defined(WIN32_TIMERS))  
  static short i = 10000;
  T_Mmb_HTimer hThis;
#endif


  if (IFX_SIPAPP_GetTimerFromList(&pxTimerInfo) == IFX_SIP_FAILURE) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
        "Timer List Exhausted");
    return IFX_SIP_FAILURE;
  }

  /* construct the timer structure */
  pxTimerInfo->pfnCallBackFn = pfn_IFX_SIP_CallBackFn;
  pxTimerInfo->pCallBackFnParam = pCallBackFnParam;
#if defined(__LINUX__)||defined(WIN32_TIMERS)
#ifdef __LINUX__
  /* convert the timeout value from milliseconds to microseconds */
  uiTimeOutValue *= 1000;
#endif
  /* start the timer for so many micro seconds */
  if (IFX_TLIB_StartTimer(&unTempTimerId, uiTimeOutValue,
      IFX_TLIB_ONE_TIME_TIMER, (void*) IFX_SIPAPP_TimeOutHandler,
      pxTimerInfo) == IFX_TLIB_FAIL) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_TIMER_START_ERR,
        "start Timer", uiTimeOutValue);
    return IFX_SIP_FAILURE;
  }
#else
  Mmb_TimerCreate(&hThis);
  Mmb_TimerStartAsync(hThis,(T_Mmb_StandardCallback)IFX_SIPAPP_TimeOutHandler,
                (T_Mmb_UserData)pxTimerInfo,uiTimeOutValue);
  pxTimerInfo->pvTimerId = hThis;
  unTempTimerId = i++;
#endif
  *punTimerId = unTempTimerId;
  /* store the timer id */
  pxTimerInfo->unTimerId = unTempTimerId;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "Started timer with ID", unTempTimerId);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIP_StopTimer
*  Description    :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          : 
*********************************************************************/

PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_StopTimer(IN uint16 unTimerId) {

  int32 iCount;
  if (unTimerId == 0) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
        "Stop Timer Timer id 0");
    return IFX_SIP_FAILURE;
  }
#if defined(__IMSENV__)&&!(defined(WIN32_TIMERS))
  /*Locate the timer Info */
   for (iCount = 0; iCount < IFX_SIPAPP_MAX_TIMERS; iCount++) {
      if (vxSipAppTimerInfo[iCount].unTimerId == unTimerId) {
        if(vxSipAppTimerInfo[iCount].pvTimerId != NULL){
          Mmb_TimerStop((T_Mmb_HTimer)((vxSipAppTimerInfo[iCount].pvTimerId)));
          Mmb_TimerDestroy((T_Mmb_HTimer*)(&(vxSipAppTimerInfo[iCount].pvTimerId)));
        }
        vxSipAppTimerInfo[iCount].unTimerId = 0;
        if(vxSipAppTimerInfo[iCount].iFired == 0){
          vxSipAppTimerInfo[iCount].cIsFree = 'y';
        }
	    return IFX_SIP_FAILURE;
	  }
   }
   if(iCount == IFX_SIPAPP_MAX_TIMERS){
     return IFX_SIP_FAILURE;
   }
#else
   if (IFX_TLIB_StopTimer(unTimerId) == IFX_TLIB_FAIL) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_TIMER_ERR,
        "Stop Timer Failed", unTimerId);
    for (iCount = 0; iCount < IFX_SIPAPP_MAX_TIMERS; iCount++) {
      if (vxSipAppTimerInfo[iCount].unTimerId == unTimerId) {
	        vxSipAppTimerInfo[iCount].unTimerId = 0;
	        return IFX_SIP_FAILURE;
      }
    }
  }
#endif
  /* delete timer info structure from the list */
  if (IFX_SIPAPP_DeleteTimerFromList(unTimerId) == IFX_SIP_FAILURE) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_SIP_ERR, unTimerId,
        "no timer with this id");
  }

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_TimeOutHandler
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/

PUBLIC void
IFX_SIPAPP_TimeOutHandler(IN x_IFX_SIPAPP_TimerInfo* pxTimerInfo)
{
  char8 acHostIp[128];
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
		"Fired Timer with ID", pxTimerInfo->unTimerId);
#if defined(__IMSENV__)&&!(defined(WIN32_TIMERS))
  pxTimerInfo->iFired = 1;
#endif
  IFX_SIPAPP_GetHostIp(acHostIp);
  if(IFX_SIPAPP_SendSockMsg(viAppRdFd, IFX_IPC_APP_ID_SIP,IFX_IPC_APP_ID_SIP,
                            sizeof(pxTimerInfo), IFX_IPC_SIPAPP_TIMER,
                            (char8 *)&pxTimerInfo,acHostIp)== IFX_IPC_FAIL){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_FIFO_WRITE_ERR,
             IFX_IPC_FAIL);
  }
  return;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_ProcessTimerMsg
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/

PUBLIC void
IFX_SIPAPP_ProcessTimerMsg(x_IFX_SIPAPP_TimerInfo* pxTimerInfo) 
{
  if (pxTimerInfo == NULL) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "<SIP-TUTimerIface> In IFX_SIPAPP_ProcessTimerMsg pxTimerInfo is NULL");
    return ;
  }
  
  if(pxTimerInfo->unTimerId == 0)
  {
    pxTimerInfo->cIsFree = 'y';
#if defined(__IMSENV__)&&!(defined(WIN32_TIMERS))
    pxTimerInfo->iFired = 0;
    if(pxTimerInfo->pvTimerId != NULL){
       Mmb_TimerDestroy((T_Mmb_HTimer*)(&(pxTimerInfo->pvTimerId)));
    }
#endif
    return;
  }
  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Process Timer with ID",pxTimerInfo->unTimerId);

  /* delete the timerinfo from the list */
  pxTimerInfo->cIsFree = 'y';
  pxTimerInfo->unTimerId = 0;
#if defined(__IMSENV__)&&!(defined(WIN32_TIMERS))
    pxTimerInfo->iFired = 0;
    if(pxTimerInfo->pvTimerId != NULL){
       Mmb_TimerDestroy((T_Mmb_HTimer*)(&(pxTimerInfo->pvTimerId)));
    }
#endif


  /* call the function along with the parameters */
  if (pxTimerInfo->pfnCallBackFn == NULL) {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "<SIP-TUTimerIface> In IFX_SIP_ProcessTimerMsg pfnCallBackFn is NULL");
    return ;
  }
  if (pxTimerInfo->pCallBackFnParam == NULL) {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "<SIP-TUTimerIface> In ProcessTimerMsg pCallBackFnParam is NULL");
  }
  pxTimerInfo->pfnCallBackFn(pxTimerInfo->pCallBackFnParam);

  return ;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_DeleteTimerFromList
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_DeleteTimerFromList(IN uint16 unTimerId) {
  uchar8 iCount;

  for (iCount = 0; iCount < IFX_SIPAPP_MAX_TIMERS; iCount++) {
    if (vxSipAppTimerInfo[iCount].unTimerId == unTimerId) {
      vxSipAppTimerInfo[iCount].cIsFree = 'y';
      vxSipAppTimerInfo[iCount].unTimerId = 0;
#if defined(__IMSENV__)&&!(defined(WIN32_TIMERS))
      vxSipAppTimerInfo[iCount].pvTimerId = NULL;
#endif

      return IFX_SIP_SUCCESS;
    }
  }

  return IFX_SIP_FAILURE;
}

/******************************************************************
*  Function Name  :  IFX_SIPAPP_StopAllTimers
*  Description    :  Stops all the timers, Used while shutting down
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
void IFX_SIPAPP_StopAllTimers(void)
{
  int32 iCount;
  for (iCount = 0; iCount < IFX_SIPAPP_MAX_TIMERS; iCount++) {
    if (vxSipAppTimerInfo[iCount].cIsFree == 'n') {
	  IFX_SIPAPP_StopTimer(vxSipAppTimerInfo[iCount].unTimerId);
	}
  }
}
/******************************************************************
*  Function Name  :  IFX_SIPAPP_GetTimerFromList
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
STATIC e_IFX_SIP_Return
IFX_SIPAPP_GetTimerFromList(OUT x_IFX_SIPAPP_TimerInfo** pxTimerInfo) {
  uchar8 iCount;

  for (iCount = 0; iCount < IFX_SIPAPP_MAX_TIMERS; iCount++) {
    if (vxSipAppTimerInfo[iCount].cIsFree == 'y') {
      vxSipAppTimerInfo[iCount].cIsFree = 'n';
      *pxTimerInfo = &vxSipAppTimerInfo[iCount];
      return IFX_SIP_SUCCESS;
    }
  }

  return IFX_SIP_FAILURE;
}

