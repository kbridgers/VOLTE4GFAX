/**************************************************************************
**   FILE NAME    : IFX_SIPAPP_Options.c
**   PROJECT      : SIP 
**   MODULES      : Options App
**   SRC VERSION  : V2.0
**   DATE         : 15-08-2005
**   AUTHOR       : SIP Team
**   DESCRIPTION  : Endpoint data base.
**   COMPILER     : gcc
**   REFERENCE    : Coding guide lines.
**   COPYRIGHT    : Copyright (c) 2004
**                  Infineon Technologies AG, st. Martin Strasse 53;
**                  81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"

#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_RegApi.h"
#include "IFX_SIP_CCApi.h"
#include "IFX_SIP_EvtPkg.h"
#include "IFX_SIP_DlgApi.h"


#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Config.h"
#include "IFX_SIP_Options.h"
#include "IFX_SIPAPP_Options.h"

extern uchar8 vcSipAppModId;
/***********************************************************************
* Function Name : IFX_SIPAPP_OptionsMsgToEncode
* Description   : Invoked from SIP toolkit to encode OPTION request
* Input Values  : pSipMessage - pointer to the Decoded Data Structure
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return  IFX_SIPAPP_OptionsMsgToEncode(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData)
{
  e_IFX_SIP_Ecode eEcode;
#ifdef STUN_SUPPORT
  x_IFX_SIPAPP_UAAppData* pxAppData = (x_IFX_SIPAPP_UAAppData*)pvUserData;
#endif
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR, "Entry");

#ifdef STUN_SUPPORT
  IFX_SIPAPP_AddViaIfSTUNOn(uiSipMsgHdl,pxAppData->iProfileId);
#endif

  if (IFX_SIP_GetMessageType(uiSipMsgHdl) == IFX_SIP_REQUEST) {
    IFX_SIPAPP_OfferSdp(uiSipMsgHdl, 
	&((x_IFX_SIPAPP_UAAppData *)pvUserData)->xSdpInfo, &eEcode);
  }
  IFX_SIPAPP_SetAllow(uiSipMsgHdl);
  IFX_SIPAPP_SetAccept(uiSipMsgHdl,"application", "sdp");
  IFX_SIPAPP_SetSupported(uiSipMsgHdl);
  IFX_SIPAPP_SetAcceptLanguage(uiSipMsgHdl);
  //IFX_SIPAPP_SetAcceptEncoding(uiSipMsgHdl);
  IFX_SIPAPP_SetContentType("application","sdp", uiSipMsgHdl);

  return IFX_SIP_SUCCESS;
}



/***********************************************************************
* Function Name : IFX_SIP_OptionsRequestArrived
* Description   : This function is invoked when Option request arrives
* Input Values  : pSipMessage - pointer to the Decoded Data Structure
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Output Values : None
************************************************************************/
e_IFX_SIP_Return IFX_SIPAPP_OptionsRequestArrived(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiOptionsHdl,
                        IN uint32 uiDialogHdl,
                        IN_OUT void **ppvUserData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData =NULL;
  e_IFX_SIP_Ecode eEcode;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Entering");

  if(uiDialogHdl != 0)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             " Request arrived on a exsisting dialog");
    /* Search the subscription list to get the application data */
    pxAppData = (x_IFX_SIPAPP_UAAppData *)IFX_SIP_CC_GetAppData(uiDialogHdl);
    if(pxAppData == NULL){
    pxAppData = (x_IFX_SIPAPP_UAAppData *)IFX_SIP_SUBSC_GetAppData(uiDialogHdl);
      if(pxAppData == NULL){
        goto FailHandler;
      }
    }
  }
  else
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
              " New Request arrived ");
    eRetVal=IFX_SIPAPP_CreateNAddAppData(&pxAppData,&eEcode);
    if(eRetVal != IFX_SIP_SUCCESS)
    {
       goto FailHandler;
    }
  }
  *ppvUserData = pxAppData;

  eRetVal = IFX_SIPAPP_OptionsHdlr(uiDialogHdl,uiOptionsHdl,pxAppData,
                   uiSipMsgHdl);
	if(eRetVal == IFX_SIP_SUCCESS){
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Success");
  /*PAIf always returns success if HANDLE_OPTIONS is enabled*/ 
		 return IFX_SIP_SUCCESS;
	}
FailHandler:
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Handling failed");
	if (pxAppData){
  	eRetVal = IFX_SIP_OptionsSendResp(uiOptionsHdl,
                    0,500,NULL, pxAppData->unLocalTcpPort);

  	/* Free Containt of the Node  and Node itself */
  	IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_OPTIONS);
	}
 
  return IFX_SIP_SUCCESS;
}

/*****************************************************************************
* Function Name : IFX_SIP_OptionsHdlr
* Description   : This function is called when a Option Method is
                  received from the peer.
* Input Values  : pSipMessage - pointer to the Decoded Data Structure
* Output Values : None
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_OptionsHdlr(IN uint32 uiDlg,
                    IN uint32 uiOptionsHdl,
                    IN x_IFX_SIPAPP_UAAppData *pxAppData,
                    IN uint32 uiMsgHdl)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode;
  char8* pcSdp;
  uint32 uiCallId = 0;
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
            "Entering");
  if(!uiMsgHdl || !pxAppData || !uiOptionsHdl)  {
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Invalid Handle");
  return IFX_FAILURE;

  }
  if (uiDlg == 0) /* OUTSIDE DLG*/
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
            "Req Outside Dlg "); 
    
    pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_SESSIONVER; 
  /* Since this is Option response - no need to get RTP port - Hard coded to 2006*/
		pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort = 2006;
  }

  /* Copy the  from/to Addr */
  IFX_SIPAPP_CopyCalledAddr(uiMsgHdl,&pxAppData->xFrom);  
  IFX_SIPAPP_CopyToAddr(uiMsgHdl,&pxAppData->xTo);
  
  /* Copy SDP and Supported headr fileds*/
   if((pcSdp = IFX_SIP_GetMsgBody(uiMsgHdl)) != NULL)
   {
     uint32 uiErrHdl;

     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                  " Options Request contains SDP ");
     if(pxAppData->xSdpInfo.uiSdpMsgHdl != 0){
        IFX_SDP_FreeMsg(pxAppData->xSdpInfo.uiSdpMsgHdl);
        pxAppData->xSdpInfo.uiSdpMsgHdl = 0;
     }
     IFX_SDP_CreateMsg(&pxAppData->xSdpInfo.uiSdpMsgHdl);
     IFX_SDP_DecodeMessage(pcSdp, pcSdp + strlen(pcSdp), 
		pxAppData->xSdpInfo.uiSdpMsgHdl, &uiErrHdl);

     eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,
                                  &pxAppData->xSdpInfo,&eEcode);

     if (eRetVal != IFX_SIP_SUCCESS)
     {
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                " Options SDP processing fail ");

       eRetVal = IFX_SIP_OptionsSendResp(uiOptionsHdl,
                       0,488,NULL, pxAppData->unLocalTcpPort); 
    
       IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_OPTIONS);
       return eRetVal;
     }
     pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT; 
  }
  else 
  {
     pxAppData->iFlag &= ~IFX_SIPAPP_SDP_PRESENT; 
  }
  /* Store the options Handle */
  pxAppData->auiHdl[IFX_SIPAPP_UA_OPTIONS] = uiOptionsHdl; 
 
/*Options will be responded directly from CMGR, so need to manage
    call id*/
  eRetVal =
     vpxNotifier.pfStateNotifier(&uiCallId,IFX_OPTIONS,
                   (void *) pxAppData);

  return eRetVal;
}



/*****************************************************************************
* Function Name : IFX_SIP_Send2xxOptionsResp
* Description   : This function is called when a success for Options Method is
                  received from the application.
* Input Values  : Context Id 
* Output Values : Encoded 2xx response
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Send2xxOptionsResp(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                           IN uint32 uiOptHdl)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiMsgHdl;
  e_IFX_SIP_Ecode eEcode;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
          "Entered");

  if (IFX_SIP_CreateMsg(&uiMsgHdl) == IFX_SIP_FAILURE) {
    return IFX_SIP_FAILURE;
  }

/*  if (IFX_SIPAPP_HandleRTPPort(0,
      &(pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort)) != IFX_SIP_SUCCESS)
  {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Options Getting RTP Port Fail");
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_OPTIONS);
      IFX_SIP_FreeMsg(uiMsgHdl);
      return IFX_SIP_FAILURE;
        
  }*/
     
  if (pxAppData->iFlag & IFX_SIPAPP_SDP_PRESENT)
  { 
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Answering");
     /* Create a Answer SDP*/
     pxAppData->xSdpInfo.iProfileId = (uint32) pxAppData;
     eRetVal = IFX_SIPAPP_AnswerSdpInactive(uiMsgHdl,&pxAppData->xSdpInfo,&eEcode);
  }
  else
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,"Offering");
     pxAppData->xSdpInfo.iProfileId = (uint32) pxAppData;
    /* Offer an SDP */
    eRetVal = IFX_SIPAPP_OfferSdp(uiMsgHdl, &pxAppData->xSdpInfo,
                               &eEcode);
  }
     
  if(eRetVal != IFX_SIP_SUCCESS)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Off/Ans SDP Failed");
    eRetVal = IFX_SIP_OptionsSendResp(pxAppData->auiHdl[IFX_SIPAPP_UA_OPTIONS],
            uiMsgHdl,500,NULL, pxAppData->unLocalTcpPort);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_OPTIONS);
    return eRetVal;
  }
  eRetVal = IFX_SIP_OptionsSendResp(pxAppData->auiHdl[IFX_SIPAPP_UA_OPTIONS],
            uiMsgHdl,200,NULL, pxAppData->unLocalTcpPort);
  if(eRetVal != IFX_SIP_SUCCESS)
  {
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Options 2xx Answer SDP Return Fail");
  }
  IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_OPTIONS);
  return eRetVal;
}

/*****************************************************************************
* Function Name : IFX_SIP_Send3xxOptionsResp
* Description   : This function is called when a fwd for Options Method is
                  received from the application.
* Input Values  : Context Id 
* Output Values : Encoded 3xx response
* Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes
******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Send3xxOptionsResp(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                              IN uint32 uiOptHdl,
			      IN x_IFX_CalledAddr *pxFwdAddr)

{
  uint32 uiContactHdl=0,uiMsgHdl;
  char8 acCallFwdAddr[IFX_SIPAPP_MAX_TOKEN];
  e_IFX_Return eRetVal;

  if(IFX_SIP_CreateMsg(&uiMsgHdl)==IFX_SIP_FAILURE){
	  return IFX_SIP_FAILURE;
  }
  eRetVal = IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_CONTACT,&uiContactHdl);
  if(eRetVal == ( e_IFX_Return ) IFX_SIP_FAILURE){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Forwarding failed");
    return eRetVal;
  }
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo,acCallFwdAddr);

  uiContactHdl = IFX_SIP_Contact_GetAddressType(uiContactHdl);
  if(uiContactHdl == 0){
	return IFX_SIP_FAILURE;
  }
  IFX_SIP_AddrType_SetValue(uiContactHdl,acCallFwdAddr);  
  eRetVal = IFX_SIP_OptionsSendResp(uiOptHdl,uiMsgHdl,
  302,NULL, pxAppData->unLocalTcpPort);

 
  if(eRetVal != (e_IFX_Return) IFX_SIP_SUCCESS)
  {
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "3xx TxmSendSipResp or Const Return Fail");
  }
  return eRetVal;
}	


/*****************************************************************************
 * Function Name : IFX_SIP_SendOptionResp
 * Description   : This function is called when a response for Options Method is
                   received from the application
 * Input Values  : Context Id,Reason
 * Output Values : None
 * Return Value  : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
 * Notes
 ******************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendOptionsResp(IN void * pvPvtData,
         IN int32 iFlag, 
			   IN int32 iReason,
			   IN x_IFX_CalledAddr *pxFwdAddr)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvPvtData;
  uint32 uiOptHdl;
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Entered");

  if(pxAppData == NULL){
    return IFX_SIP_FAILURE;
  } 
  uiOptHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_OPTIONS];
  if(iFlag == IFX_OPTIONS_ACCEPT) {
     eRetVal=IFX_SIPAPP_Send2xxOptionsResp(pxAppData,uiOptHdl);
  }

  else {
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,"Reject Reason ",
  iReason);
		switch(iReason){
			case IFX_CALL_FORWARD:
				if(pxFwdAddr != NULL){
				 memcpy(&pxAppData->xTo,pxFwdAddr,sizeof(x_IFX_CalledAddr));
				}
				eRetVal =IFX_SIPAPP_Send3xxOptionsResp(pxAppData,uiOptHdl,pxFwdAddr);
				return IFX_SUCCESS;

			case IFX_USER_NOT_FOUND:
				eRetVal = IFX_SIP_OptionsSendResp(uiOptHdl,0,404,NULL, 
				pxAppData->unLocalTcpPort);
				break;

			case IFX_ENDPOINT_BUSY:
				 eRetVal = IFX_SIP_OptionsSendResp(uiOptHdl,0,486,NULL, 
				pxAppData->unLocalTcpPort);
				break;
			
			case IFX_INTERNAL_ERR:
				 eRetVal = IFX_SIP_OptionsSendResp(uiOptHdl,0,603,NULL, 
				pxAppData->unLocalTcpPort);
				break;
			default:
				 eRetVal = IFX_SIP_OptionsSendResp(uiOptHdl,0,500,NULL, 
				pxAppData->unLocalTcpPort);
				break;
		}
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Removing App data");
     IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_OPTIONS);
  }

  if ( eRetVal != IFX_SIP_SUCCESS){
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               " Options resp  from APP processing fail");     
  }

  return eRetVal;
}
/**************************************
Dummy Function
******************************************/
e_IFX_SIP_Return IFX_SIPAPP_OptionsTimeOutOrError(
                        e_IFX_SIP_TransErrorCode eErrorType,
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData)
{

  return IFX_SIP_SUCCESS;
}

e_IFX_SIP_Return IFX_SIPAPP_OptionsMsgRespArrived(
                        IN uint32 uiSipMsgHdl,
                        IN uint32 uiOptionsHdl,
                        IN void *pvUserData)
{

  return IFX_SIP_SUCCESS;

}
/******************************************************************
*  Function Name  : IFX_SIPAPP_OptionsRegCallBacks
*  Description    : This function registers the callbacks for OPTIONS
*  	             related processing.
*  Input Values   : pxPAMsg ... Message received from phone application
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
                    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_OptionsRegCallbacks(uint32 uiStackHdl)
{
  x_IFX_SIP_OptionsCallBks xOptionsCallBacks;
	memset(&xOptionsCallBacks,0,sizeof(x_IFX_SIP_OptionsCallBks));

  xOptionsCallBacks.pfnRequestArrived = IFX_SIPAPP_OptionsRequestArrived;
  xOptionsCallBacks.pfnTimeOutOrError = IFX_SIPAPP_OptionsTimeOutOrError;
  xOptionsCallBacks.pfnMsgToEncode = IFX_SIPAPP_OptionsMsgToEncode;
  xOptionsCallBacks.pfnRespArrived = IFX_SIPAPP_OptionsMsgRespArrived;
  xOptionsCallBacks.uiStackHdl =uiStackHdl;

  IFX_SIP_OptionsRegisterCallBk(&xOptionsCallBacks);

  return IFX_SIP_SUCCESS;
}

