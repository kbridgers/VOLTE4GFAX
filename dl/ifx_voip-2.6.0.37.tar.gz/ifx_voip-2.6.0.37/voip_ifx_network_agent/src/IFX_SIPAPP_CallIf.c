/****************************************************************************
**   FILE NAME     : IFX_SIPAPP_CallIf.c
**   PROJECT       : SIP
**   MODULES       : Network agent
**   SRC VERSION   : V2.0 
**   DATE          : 
**   AUTHOR        : SIP Team
**   DESCRIPTION   : This file contains High level APIs availabe for the user.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
*****************************************************************************/
/*Common Files*/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"

/*Stack Files*/
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_CCApi.h"
#include "IFX_SIP_DlgApi.h"
#include "IFX_SDP_GetSet.h"

/*SDP Agent Files*/
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"

/*SipApp Files*/
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Transceiver.h"
#include "IFX_SIPAPP_Uac.h"
#include "IFX_SIPAPP_Uas.h"
#include "IFX_SIPAPP_PRACK.h"
#include "IFX_SIPAPP_Info.h"

/*Interface Files*/
#include "IFX_SIPAPP_CallIf.h"
#include "IFX_SIPAPP_Config.h"
#include "ifx_list.h"

/*Stun Files*/
#ifdef STUN_SUPPORT
#include "IFX_SIPAPP_Stun.h"
#include "ifx_stun_api.h"
#endif

#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

extern uchar8 vcSipAppModId;
x_IFX_SIPAPP_UAAppDataPool *vpxAppDataPool;

e_IFX_SIP_Return 
IFX_SIPAPP_RtpRespHandler(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN e_IFX_SIPAPP_RTPEvent eRtpRespType);
void
IFX_SIPAPP_GetProxyInfo(IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
                        x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling);
						

/***********************************************************************
* Function Name : IFX_SIPAPP_ModifyMedia
* Description   : This function is called to modify the media params. 
* Input Values  : pxAppData - pointer to the Endpt Information Database 
* Output Values : None
* Return Values : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes         :
************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ModifyMedia(IN x_IFX_SIPAPP_UAAppData* pxAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  int32 iCodec,iLockedCodec;

  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Entered ModifyMedia");

  iCodec=pxAppData->xSdpInfo.xRemCap[0].uiRmCodec;
  iLockedCodec=pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.
        nLockedCodecEntry].uiRmCodec;	  

  if(((iCodec >=IFX_G711_ALAW)&& (iCodec < IFX_T38_UDP)) && 
       ((iLockedCodec == IFX_T38_UDP)||
       (iLockedCodec == IFX_T38_TCP))){
    if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
	    pxAppData->iRtpParamModified = 0;
      pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
        IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
    }
#ifdef FAX_SUPPORT
    pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_FAX_SETUP;    
#endif
  }
  if( ((iCodec== IFX_T38_UDP)||(iCodec == IFX_T38_TCP))&&
	   ((iLockedCodec >= IFX_G711_ALAW)&&(iLockedCodec< IFX_T38_UDP))
	 ){
    
#ifdef FAX_SUPPORT 	    
	pxAppData->iFlag &= ~IFX_SIPAPP_FAX_ORIGINATE;
    pxAppData->iFlag &= ~IFX_SIPAPP_FAX_TERMINATE;
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_FAX_SETUP;	    
#endif
  }
  else{
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
  }	
  IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Returning from ModifyMedia");
  return eRetVal;
}

/***********************************************************************
* Function Name : IFX_SIPAPP_STUNCallResp
* Description   : This is the function called when  a STUN query response
*                 has been received   
* Input Values  : pxCallBackParam - Call back parameters
*                 eStatus - Status of Stun response
*                 pxSTUNFifo is the STUN response
* Output Values : None
* Return Values : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes         :
************************************************************************/
#ifdef STUN_SUPPORT
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_STUNCallResp(IN void* pxCallBackParam,
                        IN e_IFX_SIP_Return eStatus,
                        IN x_IFX_SIPAPP_STUN_FifoStr *pxSTUNFifo)
{
  e_IFX_SIP_Ecode eCode;
  x_IFX_SIPAPP_UAAppData *pxAppData = *((x_IFX_SIPAPP_UAAppData **)pxCallBackParam);
  int32 i=0;
  uint32 uiCfgInst=0;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;

  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Stun Response Arrived");

  uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);

  if(eStatus == IFX_SIP_SUCCESS){
    /* Copy the mapped RTP/RTCP ports */
    for(i=0;((i<pxSTUNFifo->ucNumofPorts)&&(i<12));i++){
      if(pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort ==
                                    pxSTUNFifo->unMappedPorts[i][0]){
        pxAppData->xSdpInfo.xRtpInfo.unMappedRTPPort =
                                    pxSTUNFifo->unMappedPorts[i][1];
      }
      else if((pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort+1) ==
                                    pxSTUNFifo->unMappedPorts[i][0]){
        pxAppData->xSdpInfo.xRtpInfo.unMappedRTCPPort =
                                    pxSTUNFifo->unMappedPorts[i][1];
      }
#ifdef FAX_SUPPORT
      else if(pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort ==
        pxSTUNFifo->unMappedPorts[i][0]){
        pxAppData->xSdpInfo.xRtpInfo.unMappedFAXUDPPort =
        pxSTUNFifo->unMappedPorts[i][1];
      }
#endif
    }
    /* Start Timer For Sending  NAT keep Alive packet for RTP/RTCP bindings */
    IFX_SIPAPP_StartTimer(IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiCfgInst) * 1000,
                      (void*)IFX_SIPAPP_NATRTPPortTimeout,(void*)pxAppData,
                      &pxAppData->xSdpInfo.xRtpInfo.unNATKARTPPortId, &eCode);
#ifdef FAX_SUPPORT
    /* If FAX PORT is present then only start NAT KA timer */
    if(pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort != 0){
      /* Start Timer For Sending  NAT keep Alive packet for RTP/RTCP bindings */
      IFX_SIPAPP_StartTimer(IFX_SIPAPP_GET_NATKEEPALIVETIMER(uiCfgInst) * 1000,
                     (void*)IFX_SIPAPP_NATFAXPortTimeout,(void*)pxAppData,
                     &pxAppData->xSdpInfo.xRtpInfo.unNATKAFAXPortId, &eCode);
    }
#endif
  }
  pxAppData->iFlag &= ~IFX_SIPAPP_STUN_RESP_AWAITED;
  if(pxAppData->iFlag & IFX_SIPAPP_ORIGINATING){ 
	 pxAppData->iFlag |= IFX_SIPAPP_RTP_SESS_EXIST;
     IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_OPEN_CONNRES_EVENT);
  }
  else{
    if(pxAppData->iFlag & IFX_SIPAPP_RTPREQ_ISSUED){
	  pxAppData->iFlag |= IFX_SIPAPP_RTP_SESS_EXIST;
      IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_OPEN_CONNRES_EVENT);
      
    }
  }
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "started NAT keep alive timers");
  return eRetVal;
}
#endif
/******************************************************************
*  Function Name  : IFX_SIPAPP_SetAuthData
*  Description    : Sets Authentication Data
*  Input Values   : Call ID, User name, Password for given realm, User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAuthData(IN uint32 uiCallId,
					   IN char8 *pcUserName,
					   IN char8 *pcPasswd,
					   IN void *pvPrivateData)
{
  
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "CC Auth Called");
  return IFX_SIP_CC_Authenticate(
	  ((x_IFX_SIPAPP_UAAppData *)pvPrivateData)->auiHdl[IFX_SIPAPP_UA_CALL],
      pcUserName, pcPasswd, 0);

}
/******************************************************************
*  Function Name  : IFX_SIPAPP_SetNextHopAddr 
*  Description    : Sets Next Hop Address if it is other than TO addr
*  Input Values   : User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetNextHopAddr(IN void *pvPrivateData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvPrivateData;
//  if((IFX_SIPAPP_IS_PROXYON(pxAppData)) && (IFX_SIPAPP_ISOUTBOUND(pxAppData)))
  if(IFX_SIPAPP_ISOUTBOUND(pxAppData) == IFX_TRUE)
  {
    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Proxy is outbound so set next hop address");

    return  IFX_SIP_CC_SetNextHopAddr(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                  IFX_SIPAPP_GET_PROXYADDRESS(pxAppData),
                  pxAppData->unLocalTcpPort,
                  IFX_SIPAPP_GET_PROXYPORT(pxAppData),
                  IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData));
  }
  return IFX_SIP_SUCCESS;
}
#ifdef RFC_4028
/******************************************************************
*  Function Name  : IFX_SIPAPP_GetSesTimerValue
*  Description    : This API will query rc.conf to fetch Session timer 
										Expires value
*  Input Values   : Profile Id
*  Output Values  : 
*  Return Value   : Timer Value
*                   
*  Notes          : 
*********************************************************************/
uint32 IFX_SIPAPP_GetSesTimerValue (IN uint32 iProfileId)
{
	uint32 uiSessExpires = 3600; //RFC4028 Sec4. Deafult recommended Value
	x_IFX_VMAPI_Misc xMisc = {{{{"\0"}}}};

	memset(&xMisc,0,sizeof(xMisc));
	xMisc.iid.config_owner = IFX_VOIP;
	ifx_get_Misc(&xMisc,IFX_F_DEFAULT);
	uiSessExpires = xMisc.uiSessExpires;
	return uiSessExpires;
}
#endif
/******************************************************************
*  Function Name  : IFX_SIPAPP_CreateCall 
*  Description    : Creates Application data, make's stun query 
*                   and make's call
*  Input Values   : Call ID, Service provider ID, Route params, Call 
*                   params
*  Output Values  : Privae data
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CreateCall(IN uint32 uiCallId,
					  IN uint32 uiSrvPdrId,
					  IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
					  IN x_IFX_SIPAPP_CallParams *pxCallParams,
					  OUT void **ppvPrivateData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData;
  e_IFX_SIP_Ecode eEcode;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiCfgInst=0;
#ifdef STUN_SUPPORT
   x_IFX_SIPAPP_STUNInfo xstuninfo;
#endif 

  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Entered CreateCall");

  uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(uiSrvPdrId);
  /* Create App Data */
  eRetVal=IFX_SIPAPP_CreateNAddAppData(&pxAppData,&eEcode);
  if(eRetVal != IFX_SIP_SUCCESS){
    return IFX_SIP_FAILURE;
  }
 
  /* Copy the necessary data to User Data */
  pxAppData->iConnId = uiCallId;
  memcpy(&pxAppData->xTo,pxRouteParams->pxTo,sizeof(x_IFX_CalledAddr));
  memcpy(&pxAppData->xFrom,pxRouteParams->pxFrom,sizeof(x_IFX_CalledAddr));
  if(pxRouteParams->pcProxyAddr != NULL){
    strcpy(pxAppData->acProxyAddr,pxRouteParams->pcProxyAddr);
    pxAppData->eProxyProtocol=pxRouteParams->eProxyProtocol;
	  pxAppData->unProxyPort=pxRouteParams->unProxyPort;
		pxAppData->ucIsOutBoundProxy = pxRouteParams->ucIsOutBoundProxy;
  }
 	if(IFX_SIPAPP_ConstAddr(&pxAppData->xTo,pxAppData)!= 
									IFX_SIP_SUCCESS){
    return IFX_SIP_FAILURE;
  }
 
  pxAppData->iProfileId = uiSrvPdrId;
  pxAppData->xSdpInfo.iProfileId = (int32)pxAppData;

  /* If Addr type is IP and port is zero copy default port */
  if(pxAppData->xTo.ucAddrType == IFX_IP_ADDR){
    if(pxAppData->xTo.unPort == 0) {
      pxAppData->xTo.unPort = IFX_SIPAPP_GET_SERVERPORT(uiCfgInst);
    }
  }
  /*Copy CodecList*/
  memcpy(&pxAppData->xCodecList,
	     &pxCallParams->xMediaParams.xCodecParams,
		 sizeof(x_IFX_CodecList));
  
	IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
               "The Number of Codec is",pxAppData->xCodecList.unNoOfCodecs);
  /* Configure Ports*/
  pxAppData->unLocalTcpPort = pxRouteParams->unLocalTcpPort;
  pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort =
	  pxCallParams->xMediaParams.xRtpParams.uiLocalRtpPort;
  
	/*Store Remote Party ID*/
	strcpy(pxAppData->szPhoneNumber,pxCallParams->szPhoneNumber);
	
	/*Copy CallerId suppression*/
  pxAppData->bSupressCallerId = pxRouteParams->bSupressCallerId;
	if(pxAppData->bSupressCallerId){
		strcpy(pxAppData->xFrom.acUserName,"anonymous");
		strcpy(pxAppData->xFrom.acCalledAddr,"anonymous.invalid");
		strcpy(pxAppData->xFrom.acDisplayName,"anonymous");
	}
#ifdef FAX_SUPPORT
  memcpy(&pxAppData->axFaxParams,&pxCallParams->xMediaParams.axFaxParams,
		 sizeof(x_IFX_FaxParams)*IFX_MAX_FAX_PROTO);
  
  pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort= 
	  pxAppData->axFaxParams[0].uiLocalFaxPort;
  pxAppData->xSdpInfo.xRtpInfo.iLocalFaxTcpPort= 
	  pxAppData->axFaxParams[1].uiLocalFaxPort;
#endif
  /* Store the replaces connection ID */
  if(pxCallParams->uiReplacesCallId != 0){
	  pxAppData->iConnId2 =pxCallParams->uiReplacesCallId;
  }
  pxAppData->iFlag |= IFX_SIPAPP_SEND_REQ;
  pxAppData->iFlag |= IFX_SIPAPP_ORIGINATING;
  *ppvPrivateData = pxAppData;

#ifdef STUN_SUPPORT
  /* Check if a STUN query is required */
  if(IFX_SIPAPP_IS_STUNON(uiCfgInst) && ((IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_FULL)||
     (IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_RESTRICT)||
     (IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_PORTRESTRICT))){
	  
      xstuninfo.iNATType=IFX_SIPAPP_GET_NATTYPE(uiCfgInst);
      IFX_OS_GetHostIp(xstuninfo.uacLocalIPAddr);
      strcpy((xstuninfo.uacSTUNServerAddr), IFX_SIPAPP_GET_STUNADDR(uiCfgInst));
      xstuninfo.unStunServPort = IFX_SIPAPP_GET_STUNPORT(uiCfgInst);
      xstuninfo.ucNumofPorts=2;
      xstuninfo.unLocalPort[0]= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort;
      xstuninfo.unLocalPort[1]= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort+1;
#ifdef FAX_SUPPORT
      xstuninfo.ucNumofPorts += 1;
      xstuninfo.unLocalPort[2]=pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort;
#endif
      /* Create the process and call appropriate Call back */
      eRetVal = IFX_SIPAPP_STUNCrtProcess(&xstuninfo, IFX_SIPAPP_STUNCallResp,
                                       4,&pxAppData, &pxAppData->iStunId);

      pxAppData->iFlag |= IFX_SIPAPP_STUN_RESP_AWAITED;

	  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Stun Query on Returning From CreateCall");

      return IFX_SIP_SUCCESS;
  }
#endif
#ifdef RFC_4028
	pxAppData->uiSe = IFX_SIPAPP_GetSesTimerValue(pxAppData->iProfileId);
#endif
   pxAppData->iFlag |= IFX_SIPAPP_RTP_SESS_EXIST;
   eRetVal=IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_OPEN_CONNRES_EVENT);

   IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Exited From CreateCall");
    
  return eRetVal;
}
/*********************************************************\*********
*  Function Name  : IFX_SIPAPP_MakeCall
*  Description    : creates Call Info and creates Call.
*  Input Values   : User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_MakeCall(IN x_IFX_SIPAPP_UAAppData *pxAppData)
{ 
  e_IFX_SIP_Return eRetVal= IFX_SIP_SUCCESS;
  int32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);
  char8 acTo[IFX_SIPAPP_MAX_TOKEN],acFrom[IFX_SIPAPP_MAX_TOKEN];

  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Entered MakeCall");

  /* Create Call Information */
	if(-1 == uiCfgInst){
		return IFX_SIP_FAILURE;
	}
  eRetVal = IFX_SIP_CC_CreateCallInfo(pxAppData,
		                      &pxAppData->auiHdl[IFX_SIPAPP_UA_CALL]);
  if(eRetVal != IFX_SIP_SUCCESS){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "<TUPAIF>Error in creating App data");
	vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,(void *)NULL); 
	/* Remove App data */
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL);
    return IFX_SIP_FAILURE;
  }

  IFX_SIP_CC_AssociateCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
	                       vpxSrvPdrData[uiCfgInst].uiStackHdl,0);

  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Associated Call to specfic Stack Instance");

#ifdef RFC_4028
  /*IFX_SIP_CC_SetSessionRefreshParam(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                    3600,pxAppData->uiMinSe,IFX_SIP_REFRESH_UAC);*/
  IFX_SIP_CC_SetSessionRefreshParam(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                    pxAppData->uiSe,pxAppData->uiMinSe,IFX_SIP_REFRESH_UAC);

#endif
  if( IFX_SIPAPP_IS_PROXYON(pxAppData))
  {
      IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Proxy is On");
					
      IFX_SIP_CC_SetNextHopAddr(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                  IFX_SIPAPP_GET_PROXYADDRESS(pxAppData),
                  pxAppData->unLocalTcpPort,
                  IFX_SIPAPP_GET_PROXYPORT(pxAppData),
                  IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData));
  }

  /*Create Call*/
	memset(acTo,0,IFX_SIPAPP_MAX_TOKEN);
	memset(acFrom,0,IFX_SIPAPP_MAX_TOKEN);
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo,acTo);
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);

  eRetVal = IFX_SIP_CC_CreateCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
	  0,acFrom,acTo,pxAppData->unLocalTcpPort);
  if(eRetVal != IFX_SIP_SUCCESS){
#ifdef STUN_SUPPORT
    if(IFX_SIPAPP_IS_STUNON(IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId))){
     	vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
		              IFX_RELEASE_SIGNAL,(void *)IFX_TERMINATED); 
		}
#endif
	  /* Remove APP Data */
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL); 
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "<TUPAIF>Error in creating App data");
  }
  IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Make Call Success");
  return eRetVal;
}


/******************************************************************
*  Function Name  : IFX_SIPAPP_RejectCall 
*  Description    : Releases the call with te specified Connection Identifier 
*  Input Values   : Connection Identifier of the call, Reason for rejection
*                   Forward address if rejected with IFX_CALL_FORWARD,User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_RejectCall(IN uint32 uiConnId,
					  IN e_IFX_ReasonCode eReason,
				      IN x_IFX_CalledAddr *pxFwdAddr,
					  IN void *pvPrivateData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData=(x_IFX_SIPAPP_UAAppData *)pvPrivateData;  

  switch(eReason){
      case IFX_USER_NOT_FOUND:
        eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,404,NULL);
        break;  
	  case IFX_NO_RESOURCE:
      case IFX_ENDPOINT_BUSY:
        eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,486,NULL);
        break; 
	 case IFX_MEDIA_MISMATCH:
        eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,488,NULL);
        break;
      case IFX_ENDPOINT_RINGING:
        eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,480,NULL);
        break;
      case IFX_CALL_FORWARD:
					if (pxFwdAddr->ucAddrType == IFX_EXTN){
						if(IFX_SIPAPP_ConstAddr(pxFwdAddr,pxAppData)!= IFX_SIP_SUCCESS)
    					return IFX_SIP_FAILURE;
					}
       		memcpy(&pxAppData->xTo,pxFwdAddr,sizeof(x_IFX_CalledAddr));
	     		eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                                 0,302,NULL);
        break; 
		  case IFX_INTERNAL_ERR:
        eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,500,NULL);
				break;
      default:
        eRetVal = IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,603,NULL);
  }
  if (eRetVal != IFX_SIP_SUCCESS)
  {
    /* Remove APP Data */
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL);
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Error in Rejecting Call");
		
  }
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Reject Call Success");
  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_AnswerCall 
*  Description    : Answers the call with the specified connection Identifier 
*  Input Values   : iConnId -Connection Identifier, Service provider ID
*                   Media parameters and user data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_AnswerCall(IN uint32 uiCallId,
					  IN uint32 uiSrvPdrId,
					  IN x_IFX_MediaParams *pxMediaParams,
					  IN void *pvPrivateData)
{
  //e_IFX_SIP_Return  eRetVal;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvPrivateData;
	#ifdef STUN_SUPPORT
	uint32 uiCfgInst=0;
  #endif
	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Answer Call");

  pxAppData->iProfileId = uiSrvPdrId;
  pxAppData->xSdpInfo.iProfileId = (uint32)pxAppData;	
  if(pxAppData->acProxyAddr[0]=='\0')
  {  
    x_IFX_VMAPI_ProfileSignaling xVoiceProfile={{{{"\0"}}}};
    x_IFX_SIPAPP_RouteParams xRouteParams={0};
	 /*Fix: To get outbound proxy information for Incoming call*/
    xVoiceProfile.ucProfileId = uiSrvPdrId;
    ifx_get_ProfileSignaling (&xVoiceProfile,IFX_F_DEFAULT);
    IFX_SIPAPP_GetProxyInfo(&xRouteParams,&xVoiceProfile);
	 if(xRouteParams.pcProxyAddr != NULL)
	 {
      strcpy(pxAppData->acProxyAddr,xRouteParams.pcProxyAddr);
      pxAppData->eProxyProtocol=xRouteParams.eProxyProtocol;
	  pxAppData->unProxyPort=xRouteParams.unProxyPort;
	  pxAppData->ucIsOutBoundProxy = xRouteParams.ucIsOutBoundProxy;
     }

  }
  
	#ifdef STUN_SUPPORT
  uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);
	#endif
	  if(pxMediaParams != NULL){
    /*Copy CodecList*/
    memcpy(&pxAppData->xCodecList,
	       &pxMediaParams->xCodecParams,sizeof(x_IFX_CodecList));


 #ifdef FAX_SUPPORT
      /*Copy Fax Params*/
    memcpy(pxAppData->axFaxParams,
	       pxMediaParams->axFaxParams,sizeof(pxAppData->axFaxParams));
 #endif

    /* Init RTP ports */
    pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort = 
		pxMediaParams->xRtpParams.uiLocalRtpPort;

#ifdef STUN_SUPPORT
    /* Check if a STUN query is required */
    if(IFX_SIPAPP_IS_STUNON(uiCfgInst) && ((IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_FULL)||
       (IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_RESTRICT)||
       (IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_PORTRESTRICT))){
        x_IFX_SIPAPP_STUNInfo xstuninfo;
        xstuninfo.iNATType=IFX_SIPAPP_GET_NATTYPE(uiCfgInst);
        IFX_OS_GetHostIp(xstuninfo.uacLocalIPAddr);
        strcpy((xstuninfo.uacSTUNServerAddr), IFX_SIPAPP_GET_STUNADDR(uiCfgInst));
        xstuninfo.unStunServPort = IFX_SIPAPP_GET_STUNPORT(uiCfgInst);
        xstuninfo.ucNumofPorts=2;
        xstuninfo.unLocalPort[0]= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort;
        xstuninfo.unLocalPort[1]= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort+1;
#ifdef FAX_SUPPORT
        xstuninfo.ucNumofPorts += 1;
        xstuninfo.unLocalPort[2]=pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort;
#endif
        /* Create the process and call appropriate Call back */
        /*eRetVal = */IFX_SIPAPP_STUNCrtProcess(&xstuninfo, IFX_SIPAPP_STUNCallResp,
                                       4,&pxAppData, &pxAppData->iStunId);

        pxAppData->iFlag |= IFX_SIPAPP_STUN_RESP_AWAITED;

	    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Stun Query on Returning From Answer Call");

    }
#endif
  }
#ifdef RFC_3262
  if((pxAppData->iFlag & IFX_SIPAPP_PRACK_PENDING) &&
     (pxAppData->iFlag & IFX_SIPAPP_DELAY_2XX)){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<ConnectinProceeding>200 for Invite is pending");
    pxAppData->iFlag |= IFX_SIPAPP_2XX_PENDING;
    return IFX_SIP_SUCCESS;
  }
#endif /*RFC_3262*/
  /* Open RTP session */
  if(pxAppData->xSdpInfo.ucNumRemCap != 0){
    /* Offer was made in Invite, so set mode and Locked entry */      
    IFX_SIPAPP_GetLockedCodecEntry(&pxAppData->xSdpInfo.nLockedCodecEntry,
                                &pxAppData->xSdpInfo);
    if(pxAppData->xSdpInfo.nLockedCodecEntry == -1){

	  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                 NULL);
	  /*eRetVal =*/ IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                        0,488,NULL);
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Call Rejected : Locked Codec entry is -1");
      return IFX_SIP_FAILURE;
    }
    pxAppData->xSdpInfo.eLocalMode = IFX_SIPAPP_GetLocalMode(pxAppData->
                    xSdpInfo.eLocalMode,pxAppData->xSdpInfo.
                    xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].eMode);
  }
  
  /* IF STUN Querry going on d'nt post OpenRTP Connection */
  if(!(pxAppData->iFlag & IFX_SIPAPP_STUN_RESP_AWAITED)){
#ifdef RFC_3262
    pxAppData->iFlag &= ~IFX_SIPAPP_2XX_PENDING;
    if(pxAppData->iFlag & IFX_SIPAPP_DELAY_2XX){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<ConnectinProceeding>ModifyRtp for 200->INVITE");
      IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
    }
    else
#endif
    {
	  pxAppData->iFlag |= IFX_SIPAPP_RTP_SESS_EXIST;
      IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_OPEN_CONNRES_EVENT);
    }
  }
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Answer Call Success");
  return IFX_SIP_SUCCESS;	
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_ReleaseCall 
*  Description    : Releases the call with te specified Connection Identifier 
*  Input Values   : iConnId -Connection Identifier of the call, Private data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_ReleaseCall(IN uint32 uiConnId,
					   IN void *pvPrivateData)
{
	
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *)pvPrivateData;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Release Call");
 
#ifdef STUN_SUPPORT  
  /*If stun response is awaited clear the Local Information */
  if (pxAppData->iFlag & IFX_SIPAPP_STUN_RESP_AWAITED)
  { 
	 IFX_SIPAPP_RemoveStunCallBack(pxAppData->iStunId);
	 return IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_CALL);
  }
#endif  
    
  /*If RTP session Exists close the same */
  if (pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST)
  {
    pxAppData->iRtpParamModified = 0;
    pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
  }
#ifdef FAX_SUPPORT
  if( pxAppData->xSdpInfo.iFlag & IFX_SIPAPP_FAX_SETUP )
  {
     pxAppData->iFlag &= ~IFX_SIPAPP_FAX_ORIGINATE;
     pxAppData->iFlag &= ~IFX_SIPAPP_FAX_TERMINATE;
     pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_FAX_SETUP;
     //TODOpxAppData->xSdpInfo.iFlag &= ~IFIN_FA_EndOnHook;
  }
#endif  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Call Released");

  /* If outbound proxy set next hop address*/
  IFX_SIPAPP_SetNextHopAddr(pxAppData);

   /*Call the release call stack function */
  if(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL])
  {
    return IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
  }
  else
  {
	return IFX_SIP_SUCCESS;
  }
  
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_HoldCall 
*  Description    : Holds the call with the specified User data
*  Input Values   : User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_HoldCall(IN uint32 uiConnId,IN void *pvPrivateData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvPrivateData;
  uint32 uiDlgHeadHdl=0,uiDlgHdl=0;
  uint32 uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);


  /* If the call is already on hold return success to application */
  if(pxAppData->iFlag & IFX_SIPAPP_LOCAL_HOLD){
	  vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_HOLD_SUCCESS,NULL);      
    return IFX_SIP_SUCCESS;      
  }


  eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Dialog head is null");
	vpxNotifier.pfStateNotifier(&uiConnId,IFX_HOLD_FAIL,"Dilog Head is NULL"); 	
    return eRetVal;
  } 
  
  eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl, &eEcode);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "No Confirmed dialog");
	vpxNotifier.pfStateNotifier(&uiConnId,IFX_HOLD_FAIL,
		 "No COnfirmed dialog to send Re-Invite"); 		 
    return eRetVal;
  } 

   /* Set the Local Mode */
  pxAppData->xSdpInfo.eLocalMode = IFX_SDP_INACTIVE;
  /*pxAppData->xSdpInfo.eLocalMode = IFX_SIPAPP_GetLocalMode(
                                      pxAppData->xSdpInfo.eLocalMode,
                                      pxAppData->xSdpInfo.xRemCap[pxAppData
                                      ->xSdpInfo.nLockedCodecEntry].eMode);*/

  /* If outbound proxy set next hop address*/
  IFX_SIPAPP_SetNextHopAddr(pxAppData);
  
  /* Set the connection address related flags */
  if(IFX_SIPAPP_GET_USECONNADDRFORHOLD(uiCfgInst)){
    pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_USE_CONNADDR_FORHOLD;
	
  }
  
  pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_USE_IP_HOLD;
#ifdef RFC_3311 /*Clear UPDATE offer/Answer */
  pxAppData->iUpdateFlag &=  ~IFX_SIPAPP_UPDATE; 
#endif
  eRetVal = IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                   0,uiDlgHdl, "INVITE");
  if(eRetVal != IFX_SIP_SUCCESS){  
     vpxNotifier.pfStateNotifier(&uiConnId,IFX_HOLD_FAIL,"Send REquest Failed");
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Should never reach here (IFX_CC_sendReq fail)");
     return eRetVal;
   } 
   /* Set the mode flag to indicate RTP */
   pxAppData->iRtpParamModified =1;
   /* Set Local Hold flag */
   pxAppData->iFlag |= IFX_SIPAPP_LOCAL_HOLD;
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Call Hold Success");
   return IFX_SIP_SUCCESS;   
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_ResumeCall 
*  Description    : Resume a call which is on Hold.
*  Input Values   : User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_ResumeCall(uint32 uiConnId,IN void *pvPrivateData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvPrivateData;
  uint32 uiDlgHeadHdl=0,uiDlgHdl=0;
  
  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Resume Call"); 
  
  /* If the call is not put on hold return failure to application */
  if(!(pxAppData->iFlag & IFX_SIPAPP_LOCAL_HOLD)){
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_RESUME_FAIL,NULL);      
    return IFX_SIP_SUCCESS;      
  }

  eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Dialog head is null");
    vpxNotifier.pfStateNotifier(&uiConnId,IFX_RESUME_FAIL,"Dilog Head is NULL"); 	
    return eRetVal;
  } 
  eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl,&eEcode);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "No Confirmed dialog");
    vpxNotifier.pfStateNotifier(&uiConnId,IFX_RESUME_FAIL,
		  "No COnfirmed dialog to send Re-Invite"); 		 
    return eRetVal;
  } 

  
  /* Reset the Local Hold flag */
  pxAppData->iFlag &= ~IFX_SIPAPP_LOCAL_HOLD;
  if((pxAppData->xSdpInfo.eLocalMode == IFX_SDP_INACTIVE)
			&&(pxAppData->iFlag & IFX_SIPAPP_REMOTE_HOLD_FLAG)){
    /* Set the Local Mode */
    pxAppData->xSdpInfo.eLocalMode = IFX_SDP_RECVONLY;
  }
  else{
    pxAppData->xSdpInfo.eLocalMode = IFX_SDP_SENDRECV;
  }
  /* Set the Use Ip in connection addr flag */
  pxAppData->xSdpInfo.iFlag |=IFX_SIPAPP_USE_IP_HOLD;

  /* If outbound proxy set next hop address*/
  IFX_SIPAPP_SetNextHopAddr(pxAppData);
      
  /* Send a Re-Invite */
#ifdef RFC_3311 /*Clear UPDATE offer/Answer */
  pxAppData->iUpdateFlag &=  ~IFX_SIPAPP_UPDATE; 
#endif
  eRetVal = IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                       0,uiDlgHdl, "INVITE");
   if(eRetVal != IFX_SIP_SUCCESS){  
     vpxNotifier.pfStateNotifier(&uiConnId,IFX_RESUME_FAIL,"Send Request Failed");
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Should never reach here (IFX_CC_sendReq fail)");
     return eRetVal;
   } 

  /* Set the mode flag to indicate RTP */
  pxAppData->iRtpParamModified =1;
  
  /* Set Local Resume flag */
  pxAppData->iFlag |= IFX_SIPAPP_LOCAL_RESUME;
  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Call Resume Success");
  return IFX_SIP_SUCCESS;
  
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_AcceptCall 
*  Description    : Accept Call.
*  Input Values   : Service provider ID, Media params, User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_AcceptCall(IN uint32 uiCallId,
					  IN uint32 uiSrvPdrId,
					  IN x_IFX_MediaParams *pxMediaParams,
					  IN void *pvPrivateData)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData=(x_IFX_SIPAPP_UAAppData *)pvPrivateData;
	uint16 unIsReliable = 0;
	#ifdef STUN_SUPPORT
  uint32 uiCfgInst = 0;
	#endif
  x_IFX_VMAPI_ProfileSignaling xVoiceProfile={{{{"\0"}}}};
  x_IFX_SIPAPP_RouteParams xRouteParams={0};
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Accept Call"); 

  pxAppData->iProfileId = uiSrvPdrId;
  pxAppData->xSdpInfo.iProfileId = (uint32)pxAppData;  
  /*Fix: To get outbound proxy information for Incoming call*/
  xVoiceProfile.ucProfileId = uiSrvPdrId;
  ifx_get_ProfileSignaling (&xVoiceProfile,IFX_F_DEFAULT);
  IFX_SIPAPP_GetProxyInfo(&xRouteParams,&xVoiceProfile);
	if(xRouteParams.pcProxyAddr != NULL)
	{
    strcpy(pxAppData->acProxyAddr,xRouteParams.pcProxyAddr);
    pxAppData->eProxyProtocol=xRouteParams.eProxyProtocol;
	  pxAppData->unProxyPort=xRouteParams.unProxyPort;
		pxAppData->ucIsOutBoundProxy = xRouteParams.ucIsOutBoundProxy;
  }
	
	#ifdef STUN_SUPPORT
  uiCfgInst = IFX_SIPAPP_GetSrvPdrInst(pxAppData->iProfileId);
	#endif
	/*Do not send SDP in 183 if
	 1.INVITE came with offer
	 2.PRACK is not supported by the remote end*/
  if((pxAppData->xSdpInfo.ucNumRemCap != 0) 
		#ifdef RFC_3262 
		 || !(pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT)
    #endif
		)
	{
		pxMediaParams = NULL;			
  #ifdef RFC_3262
		/*No need to delay 2xx for INVITE as 183 does not have SDP*/
		if(pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT)
		{ 								
		 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<AcceptinProceeding> Media params is null");
	   unIsReliable = 1;
		 pxAppData->iFlag	&= ~IFX_SIPAPP_DELAY_2XX;		   
     pxAppData->iFlag |= IFX_SIPAPP_PRACK_PENDING;
		}

   #endif
  }
  
	if(pxMediaParams != NULL)
	{
    /*Copy CodecList*/
    memcpy(&pxAppData->xCodecList,
	       &pxMediaParams->xCodecParams,sizeof(x_IFX_CodecList));
    
#ifdef FAX_SUPPORT
     /*Copy Fax Params*/
    memcpy(pxAppData->axFaxParams,
	       pxMediaParams->axFaxParams,sizeof(pxAppData->axFaxParams));
#endif
    /* Copy Port Information */
    pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort =
		pxMediaParams->xRtpParams.uiLocalRtpPort;
	#ifdef STUN_SUPPORT
    /* Check if a STUN query is required */
    if(IFX_SIPAPP_IS_STUNON(uiCfgInst) && ((IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_FULL)||
       (IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_RESTRICT)||
       (IFX_SIPAPP_GET_NATTYPE(uiCfgInst) == IFX_STUN_TYPE_PORTRESTRICT))){
        x_IFX_SIPAPP_STUNInfo xstuninfo;
        xstuninfo.iNATType=IFX_SIPAPP_GET_NATTYPE(uiCfgInst);
        IFX_OS_GetHostIp(xstuninfo.uacLocalIPAddr);
        strcpy((xstuninfo.uacSTUNServerAddr), IFX_SIPAPP_GET_STUNADDR(uiCfgInst));
        xstuninfo.unStunServPort = IFX_SIPAPP_GET_STUNPORT(uiCfgInst);
        xstuninfo.ucNumofPorts=2;
        xstuninfo.unLocalPort[0]= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort;
        xstuninfo.unLocalPort[1]= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort+1;
#ifdef FAX_SUPPORT
        xstuninfo.ucNumofPorts += 1;
        xstuninfo.unLocalPort[2]=pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort;
#endif
        /* Create the process and call appropriate Call back */
        eRetVal = IFX_SIPAPP_STUNCrtProcess(&xstuninfo, IFX_SIPAPP_STUNCallResp,
                                       4,&pxAppData, &pxAppData->iStunId);

        pxAppData->iFlag |= IFX_SIPAPP_STUN_RESP_AWAITED;

	    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Stun Query on Returning From Accept Call");

    }
#endif
  }

#ifdef RFC_3262
  if((pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT) && 
		 (pxMediaParams!=NULL) /*183 will make an offer*/&& 
		 !(pxAppData->iFlag & IFX_SIPAPP_STUN_RESP_AWAITED) )
     {
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<AcceptinProceeding> Invite without offer-- offer in 183");    
       pxAppData->iFlag |= IFX_SIPAPP_DELAY_2XX;
       pxAppData->iFlag |= IFX_SIPAPP_RTP_SESS_EXIST;
       eRetVal=IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_OPEN_CONNRES_EVENT);      
     }
	else		
#endif
	{
     eRetVal = IFX_SIP_CC_AcceptCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL], 
										                 0,unIsReliable);
	}
  if(eRetVal != IFX_SIP_SUCCESS)
	{
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_SIP_SEND_RSP_ERR,
             "AcceptinProceeding", eRetVal);
    eRetVal = vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_STOPTONE_SIGNAL, NULL);
	  return IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_CALL);
  }
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Accept Call Success");
  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_RemHoldResAccept 
*  Description    : Accept Remote Resume/Hold.
*  Input Values   : User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_RemHoldResAccept(IN uint32 uiConnId,
							IN void *pvPrivateData)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
	char8 acMethod[32]="INVITE";
  x_IFX_SIPAPP_UAAppData *pxAppData=(x_IFX_SIPAPP_UAAppData *)pvPrivateData;

  /* Send 200  Response for ReInvite */
#ifdef RFC_3311
	if(IFX_SIP_UPDATE == pxAppData->eMediaUpdateMethod){
		strcpy(acMethod,"UPDATE");
	}
#endif 
  eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                    0,200,"OK",0,acMethod);
  
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Accept Remote Hold/Resume Success");
  return eRetVal;
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_RemHoldResReject 
*  Description    : Reject Remote Hold/Resume.
*  Input Values   : User data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_RemHoldResReject(IN uint32 uiConnId,
							IN e_IFX_ReasonCode eReason,
							IN void *pvPrivateData)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
	char8 acMethod[32]="INVITE";
  x_IFX_SIPAPP_UAAppData *pxAppData=(x_IFX_SIPAPP_UAAppData *)pvPrivateData;
  
  if(pxAppData->iFlag & IFX_SIPAPP_REMOTE_HOLD_FLAG){
    pxAppData->iFlag &= ~IFX_SIPAPP_REMOTE_HOLD_FLAG;
  }
  if(pxAppData->iFlag & IFX_SIPAPP_REMOTE_RESUME_FLAG){
    pxAppData->iFlag &= ~IFX_SIPAPP_REMOTE_RESUME_FLAG;
    pxAppData->iFlag |= IFX_SIPAPP_REMOTE_HOLD_FLAG;
  }
  /* Send 500  Response for ReInvite */
#ifdef RFC_3311
	if(IFX_SIP_UPDATE == pxAppData->eMediaUpdateMethod){
		strcpy(acMethod,"UPDATE");
	}
#endif 

  eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
		                    0,500,"Internal Error",0,acMethod);
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Reject Remote Hold/Resume Success");
  return eRetVal;
}


/******************************************************************
*  Function Name  : IFX_SIPAPP_SetRefreshMethod 
*  Description    : Sets the refresh SIP method to be used in session refreshs
*  Input Values   : uiMsgHdl - Message received from the peer
*                   uiCCHdl - Call Control Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
void IFX_SIPAPP_SetRefreshMethod(x_IFX_SIPAPP_UAAppData* pxAppData,
								 uint32 uiMsgHdl)
{
#ifdef RFC_3311
	int32 iLocation=0;
	uint32 uiHdr=0;
	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered SetRefresh Method");
    /* Allow Header Checking*/
    iLocation = 1;
    while(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_ALLOW,iLocation, &uiHdr)
          != IFX_SIP_FAILURE) {
	  if(strcasecmp(IFX_SIP_Allow_GetMethod(
                    uiHdr),"UPDATE")==0)
	  {
         pxAppData->eRefreshMethod = IFX_SIP_GetMethodType("UPDATE");
		 return;

	  } 
      iLocation++;
    }
#endif
	pxAppData->eRefreshMethod = IFX_SIP_GetMethodType("INVITE");

}
/******************************************************************
*  Function Name  : IFX_SIPAPP_CCAppReqArrived 
*  Description    : Callback registered to be called on reception of
*                   an Incoming Message
*  Input Values   : uiMsgHdl - Message received from the peer
*                   uiCCHdl - Call Control Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return  
IFX_SIPAPP_CCAppReqArrived(IN uint32 uiMsgHdl,
                        IN uint32 uiCCHdl,
                        IN_OUT void **ppvUserData)
{
  e_IFX_SIP_Ecode eEcode;
  char8 *pcMethod;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_BasicMethod eMethod;
  char8 *pcSdpMsg=NULL;
  x_IFX_SIPAPP_UAAppData* pxAppData = (x_IFX_SIPAPP_UAAppData*)*ppvUserData;
  char8 *pcRequireTag = NULL;
  uint32 uiHdr=0;
  int32 iLocation=1;
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "entered Request Arrived");

  eRetVal = IFX_SIP_Request_GetMethod(uiMsgHdl,&pcMethod);
  if(eRetVal == IFX_SIP_FAILURE) {
		 /*ToDo*/			
     IFX_SIP_CC_SendResponse(uiCCHdl,0,400,"Bad Request",0,pcMethod);
     return eRetVal;
  }
  eMethod = IFX_SIP_GetMethodType(pcMethod);
  /* Check if there is an extension method which is not supported by us
     if yes send a 420 response */
  if(!((eMethod == IFX_SIP_CANCEL) || (eMethod == IFX_SIP_ACK))){

	/* Require Header Checking*/
    while(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_REQUIRE,iLocation, &uiHdr)
           != IFX_SIP_FAILURE) {
      pcRequireTag = IFX_SIP_GetOptionTag(uiHdr);
#if defined(RFC_3262) && defined(RFC_4028)
   if(!((strcmp("100rel",pcRequireTag)==0)||strcmp("timer",pcRequireTag)==0))
#elif defined(RFC_3262)
   if(strcmp("100rel",pcRequireTag))
#elif defined(RFC_4028)
   if(strcmp("timer",pcRequireTag))
#endif
      {
        IFX_SIP_CC_SendResponse(uiCCHdl,0,420,"Bad Extention",0,pcMethod);
        return IFX_SIP_FAILURE;
      }
      iLocation++;
    }
	/* content Type Checking*/
	if(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1, &uiHdr)
		== IFX_SIP_SUCCESS){
		char *pcTemp=NULL,*pcTemp1= NULL;
		pcTemp = IFX_SIP_ContType_GetMType(uiHdr);
		pcTemp1=IFX_SIP_ContType_GetMSubType(uiHdr);

		if(!(pcTemp && pcTemp1 && strcasecmp(pcTemp,"application")==0 &&
			 (strcasecmp(pcTemp1,"sdp")==0|| strcasecmp(pcTemp1,"dtmf")==0)) ) 
			
	  /*&if(!((((pcTemp=IFX_SIP_ContType_GetMType(uiHdr)!=NULL))&& 
						strcasecmp(pcTemp,"application")==0)&&
	      (((pcTemp=IFX_SIP_ContType_GetMSubType(uiHdr))!=NULL)&&
				 ((strcasecmp(pcTemp,"sdp")==0)||(strcasecmp(pcTemp,"dtmf")==0)))))*/
	  {
        IFX_SIP_CC_SendResponse(uiCCHdl,0,415,NULL,0,pcMethod);
        return IFX_SIP_FAILURE;

	  }   
	}

	/* Accept Header Checking*/
    iLocation = 1;
    while(IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_ACCEPT,iLocation, &uiHdr)
           != IFX_SIP_FAILURE) {
		char *pcTemp=NULL,*pcTemp1= NULL;
		pcTemp = IFX_SIP_Accept_GetMType(uiHdr);
		pcTemp1= IFX_SIP_Accept_GetMSubType(uiHdr);
		
		if( (pcTemp) && (pcTemp1) &&  
				strcasecmp(pcTemp,"application")==0 &&
		    (strcasecmp(pcTemp1,"sdp")==0|| strcasecmp(pcTemp1,"*")==0) ) 
		 {  
         iLocation=0;
		     break;
  	  } 
      iLocation++;
    }
	if(iLocation > 1){
	  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	           "Accept header type content not supported");
	  IFX_SIP_CC_SendResponse(uiCCHdl,0,406,NULL,0,pcMethod);
      return IFX_SIP_FAILURE;
	}
  }

  if(pxAppData == NULL){
    eRetVal = IFX_SIPAPP_CreateNAddAppData(&pxAppData,&eEcode);
    if(eRetVal == IFX_SIP_SUCCESS)
    {
      pxAppData->auiHdl[IFX_SIPAPP_UA_CALL]= uiCCHdl;
      *ppvUserData = pxAppData;
    }
		else{
	      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Failed to Create App data");
        return IFX_SIP_FAILURE;
		}
  }
 
  if((eMethod == IFX_SIP_INVITE) 
#ifdef RFC_3311
    || (eMethod == IFX_SIP_UPDATE)
#endif
){	
    IFX_SIPAPP_SetRefreshMethod(pxAppData,uiMsgHdl);
    pcSdpMsg = IFX_SIP_GetMsgBody(uiMsgHdl);

    if(pcSdpMsg != NULL){
      if(pxAppData->xSdpInfo.uiSdpMsgHdl){
	  		IFX_SDP_FreeMsg(pxAppData->xSdpInfo.uiSdpMsgHdl);		
		    pxAppData->xSdpInfo.uiSdpMsgHdl = 0;	
		  }
      if(IFX_SDP_FAILURE == IFX_SDP_CreateMsg(&pxAppData->xSdpInfo.uiSdpMsgHdl)) {
        IFX_SIP_CC_SendResponse(uiCCHdl,0,500,NULL,0,pcMethod);
        return IFX_SIP_FAILURE;
      }
      eRetVal = IFX_SDP_DecodeMessage(pcSdpMsg,pcSdpMsg+strlen(pcSdpMsg),
                                    (uint32)pxAppData->xSdpInfo.uiSdpMsgHdl, &eEcode);
      if(eRetVal == IFX_SIP_FAILURE) {
	      eRetVal = IFX_SIP_CC_SendResponse(uiCCHdl,0,400,
                                        "Invalid SDP",0,pcMethod);
	      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Deconding SDP Failed");
        return IFX_SIP_FAILURE;
      }
    }
	}
  pxAppData->eMediaUpdateMethod = eMethod;
  eRetVal = pfnHandleSpecMsg[eMethod -1](pxAppData,uiMsgHdl,&eEcode); 
  return eRetVal; 
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_CCAppTimeOutOrError 
*  Description    : This function Gets Called in case of Transaction
*                   timeout or an error 
*  Input Values   : eErrorType - Error Type
*                   uiCCHdl - Call Control Handle
*                   uiDlgHdl - Dialog Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_CCAppTimeOutOrError(IN e_IFX_SIP_TransErrorCode eErrorType,
                            IN uint32 uiCCHdl,
                            IN uint32 uiDlgHdl,
                            IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData *) pvUserData;
#ifdef RFC_4028
  uint32 uiDlgHeadHdl=0;
  e_IFX_SIP_Ecode eEcode;
#endif 
  uiDlgHdl=0;
  switch(eErrorType){
    case IFX_SIP_INFO_TIMEOUT:
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "INFO timed out");
    break;
    case IFX_SIP_ERR_CLEANUP:
    case IFX_SIP_TIMEOUT_ERR:
      /* Inform the application */
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                                 NULL);
      if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
        /* Close RTP session */
        pxAppData->iRtpParamModified = 0;
        pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
        IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
      }
      /* Remove the UserData */
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL);
      /* As we plan to clean up the call return a failure */  
	  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Request Timedout");
      return IFX_SIP_FAILURE; 
    case IFX_SIP_2XXACK_TIMEOUT:
	     vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_RELEASE_SIGNAL,
                         NULL);
       if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
         pxAppData->iRtpParamModified = 0;
         pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
         IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
       }
       /* If FAX Session Exist Post Close Fax */
#ifdef FAX_SUPPORT
      if(pxAppData->xSdpInfo.iFlag & IFX_SIPAPP_FAX_SETUP) {
         pxAppData->iFlag &= ~IFX_SIPAPP_FAX_ORIGINATE;
         pxAppData->iFlag &= ~IFX_SIPAPP_FAX_TERMINATE;
         pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_FAX_SETUP;
      }
#endif  	
	  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Request ACK Timedout");
    break;
#ifdef RFC_4028    
    case IFX_SIP_SESSREFRESH_TIMEOUT:
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Session timeout notification\n");
      /* No UPDATE/RE-INVITE from the other end */
      /* Send BYE */
      IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
      /* Release call to PA*/
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL, NULL);
      /* Close the RTP connection if it exists */
      if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
        pxAppData->iRtpParamModified = 0;
        pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
        IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
      }
      /* Clear the App Data */
      IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_CALL);

	  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Session RefreshTimedout");
    break;
    case IFX_SIP_SESSREFRESH_NOTIFY:
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Session refresh notification\n");
      /*Set the SDP version flag unchanged */
      pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_NOCHANGE;
      IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
      IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                         &uiDlgHdl,&eEcode);
	    IFX_SIP_CC_SessionRefresh(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                  0,uiDlgHdl,pxAppData->eRefreshMethod);
	  
      /*Reset the SDP version flag */
      pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SDP_NOCHANGE;
    break;
#endif    
    default:
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Default Case\n ");
     break;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_CCAppMsgToEncode 
*  Description    : Call Back registered to be called before the message
*                   is being sent out 
*  Input Values   : uiCCHdl - Call Control Handle
*                   uiDlgHdl - Dialog Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : Other Applications can use the message APIs, without 
*                   typecasting and directly populating the strucutes 
*********************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_CCAppMsgToEncode(IN uint32 uiMsgHdl,
                         IN uint32 uiCCHdl,
                         IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData* pxAppData = (x_IFX_SIPAPP_UAAppData*)pvUserData;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_MsgType eMsgType;
  e_IFX_SIP_BasicMethod eMethod;
  e_IFX_SIPAPP_RespCodes eRespCode;
  e_IFX_SIP_Ecode eEcode;
  char8 *pcMethod=NULL;
  uint32 uiCSeqHdl=0,uiHdrHdl=0;
  uint16 nStatusCode =0;
	char8 acBuff[100],acIp[16];

  if(pxAppData == NULL){
	  return IFX_SIP_SUCCESS;
  }
  IFX_SIPAPP_SetUserAgent(uiMsgHdl,pxAppData->iProfileId);
  eMsgType = IFX_SIP_GetMessageType(uiMsgHdl);

#ifdef FAX_SUPPORT
  pxAppData->xSdpInfo.xRtpInfo.iLocalFaxTcpPort = IFX_SIPAPP_GET_FAX_TCP_PORT(pxAppData);
  pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort = IFX_SIPAPP_GET_FAX_UDP_PORT(pxAppData);
#endif
  /* Check if the Message is request or response */
  if (eMsgType == IFX_SIP_REQUEST) {
    eRetVal = IFX_SIP_Request_GetMethod (uiMsgHdl,&pcMethod);
    if (eRetVal != IFX_SIP_SUCCESS){
      return IFX_SIP_FAILURE;
    }
		/*Set Remote Party Id*/
		if(pxAppData->szPhoneNumber[0] !='\0'){
				eRetVal=IFX_SIP_SetHeaderByName(uiMsgHdl,"Remote-Party-ID",&uiHdrHdl);
				IFX_OS_GetHostIp(acIp);
				sprintf(acBuff,"<sip:%s@%s;user=phone>",pxAppData->szPhoneNumber,acIp);
				IFX_SIP_Extension_SetHdrValue(uiHdrHdl,acBuff);
		}
    eMethod = IFX_SIP_GetMethodType(pcMethod);
    eRetVal = pfnSpecReqConst[eMethod-1](pxAppData,uiMsgHdl,&eEcode); 
#ifdef STUN_SUPPORT
    IFX_SIPAPP_AddViaIfSTUNOn(uiMsgHdl,pxAppData->iProfileId);
#endif
#ifdef IFX_INTERCOM_SUPPORT
    if (pxAppData->xCalledAddr.ucIntercomCall == IFX_SIP_TRUE) {
       uint32 uiHdrHdl;
       eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_TO,1,&uiHdrHdl);
       if (eRetVal == IFX_SIP_SUCCESS) {
         IFX_SIP_ToFrom_SetGenericParam(uiHdrHdl, "intercom", "true");
       }
    }
#endif
    if(eMethod == IFX_SIP_CANCEL){
      /*If it is a cancel remove app data as no call backs will be invoked */
      //TODO:IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL); 
    }
  }
  else if(eMsgType == IFX_SIP_RESPONSE) {
     IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CSEQ,1,&uiCSeqHdl);
     pcMethod = IFX_SIP_CSeq_GetMethod(uiCSeqHdl);
     eMethod = IFX_SIP_GetMethodType(pcMethod);
     nStatusCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
     eRespCode = IFX_SIPAPP_MapRespCode(nStatusCode);
     eRetVal = pfnSpecRespConst[eRespCode](eMethod,uiMsgHdl,
		                          pxAppData,&eEcode);
		if(eRetVal == IFX_SIP_FAILURE){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Uas Response Construction Failed ");
						
		}	
     /* Would happen in the cases where a call is rejected */
     if((eMethod == IFX_SIP_INVITE) && (nStatusCode>299)&&
        (nStatusCode != 401)&& (nStatusCode != 407)) {
       if((pxAppData == NULL) || (!(pxAppData->iFlag & 
                IFX_SIPAPP_RTP_SESS_EXIST))){
         IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL); 
       }
     }
  }

  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_CCAppRespArrived
*  Description    : Call Back registered to be called on reception of
*                   the response
*  Input Values   : uiMsgHdl - Message Handle
*                   uiCCHdl - Call Control Handle
*                   uiDlgHdl - Dialog Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CCAppRespArrived(IN uint32 uiMsgHdl,
                         IN uint32 uiCCHdl,
                         IN uint32 uiDlgHdl,
                         IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvUserData; 
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  int16 nStatCode;
  e_IFX_SIP_StatusType eStatusType = IFX_SIP_Response_GetStatusType(uiMsgHdl);
  char8 *pcSdpMsg=NULL;
  uint32 uiErrHdl=0;
  uint32 uiHdrHdl=0;
  char8 *pcMethod=NULL;
  e_IFX_SIP_BasicMethod eReqId;/* TODO: Use msg APIs */
    
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "IFX_SIP_CCAppRespArrived Arrived ");
  /* get the method */
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CSEQ,1,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
      return eRetVal;
  }

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
           "IFX_SIPAPP_Resp arrived and got Cseq hdl ");
  
  pcMethod = IFX_SIP_CSeq_GetMethod(uiHdrHdl);
  eReqId = IFX_SIP_GetMethodType(pcMethod); 
  nStatCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl); 
  
#ifdef INFO_SUPPORT
  if(eReqId == IFX_SIP_INFO_METHOD){
		if(nStatCode > 299){			
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_INFO_FAIL,
          	        	           NULL);
		}
		else{
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_INFO_SUCCESS,
          	        	           NULL);
		}
    return eRetVal;
	}
#endif	
  IFX_SIPAPP_SetRefreshMethod(pxAppData,uiMsgHdl);
  pcSdpMsg = IFX_SIP_GetMsgBody(uiMsgHdl);
  if(pcSdpMsg != NULL){

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Before IFX_SDP_DecodeMessage ");
    if(pxAppData->xSdpInfo.uiSdpMsgHdl){
			IFX_SDP_FreeMsg(pxAppData->xSdpInfo.uiSdpMsgHdl);		
		  pxAppData->xSdpInfo.uiSdpMsgHdl = 0;	
		}
    IFX_SDP_CreateMsg(&pxAppData->xSdpInfo.uiSdpMsgHdl);
    eRetVal = IFX_SDP_DecodeMessage(pcSdpMsg,pcSdpMsg+strlen(pcSdpMsg),
                                    pxAppData->xSdpInfo.uiSdpMsgHdl,&uiErrHdl);
    if (eRetVal == IFX_SIP_FAILURE) {
	    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Decode SDP Failed");
      
      /* Close RTP Connection */
      pxAppData->iRtpParamModified = 0;
      pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
      IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
      /* Send Bye in case there is an error */
      IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
      /* Give Release to Application */
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
          	        	  NULL);
      return eRetVal;
     }
  }

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           " IFX_SDP_DecodeMessage  Success");
  eRetVal =  pfnHandleResponse[eStatusType-1](pxAppData,uiMsgHdl,&eEcode);
  
  
  if((eReqId == IFX_SIP_BYE) && (nStatCode >199)) {
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL); 
  }
	/*Don't RemoveApp Data if Event is already handled. Such as Resp 401/407/422 */
  if((eReqId == IFX_SIP_INVITE) && (nStatCode >299) &&  
			(eEcode != IFX_SIP_EVENT_HANDLED)) {
		 uint32 uiDlgHeadHdl=0;
  		IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Evnet not handled");
		 eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
										                    &uiDlgHeadHdl);
    if(uiDlgHeadHdl == 0){
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL); 
    }
  } 


  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_CCAppDnsResolved 
*  Description    : Call back which will be called when the destination
*                   address is resolved
*  Input Values   : uiCCHdl - Call Control Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CCAppDnsResolved(IN uint32 uiCCHdl,
                         IN void *pvUserData)
{
  
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_CCAppDialogCreated 
*  Description    : Call back registered to be called when dialog
*                   is created
*  Input Values   : uiCCHdl - Call Control Handle
*                   uiDlgHdl - Dialog Handle
*                   pvUserData - UserData
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_CCAppDialogCreated(IN uint32 uiCCHdl,
                           IN uint32 uiDlgHdl,
                           IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*)pvUserData; 
  pxAppData->uiDlgIdHdl = uiDlgHdl;
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_RegisterCCCB 
*  Description    : This function Registers the call control call backs
*                   with the stack 
*  Input Values   : None
*  Output Values  : None
*  Return Value   : void
*  Notes          : 
*********************************************************************/
void
IFX_SIPAPP_RegisterCCCB(uint32 uiStackHdl)
{
  x_IFX_SIP_CCCallBacks xCCCB={0};
 
  /* Initialize the call backs */ 
  xCCCB.pfnReqArrived = IFX_SIPAPP_CCAppReqArrived;
  xCCCB.pfnTimeOutOrError = IFX_SIPAPP_CCAppTimeOutOrError;
  xCCCB.pfnMsgToEncode = IFX_SIPAPP_CCAppMsgToEncode;
  xCCCB.pfnRespArrived = IFX_SIPAPP_CCAppRespArrived;
  xCCCB.pfnDnsResolved = IFX_SIPAPP_CCAppDnsResolved;
  xCCCB.pfnDialogCreated = IFX_SIPAPP_CCAppDialogCreated;
	xCCCB.uiStackHdl =uiStackHdl;
  /* Register the call backs */
  IFX_SIP_CC_RegisterCB(&xCCCB); 
}

/******************************************************************
*  Function Name  : IFX_SIPAPP_RtpRespHandler 
*  Description    : Handle RTP responsed from the RTP module
*  Input Values   : uiConnId - Connection Identifier
*                         iRTPRespEvent - RTP response Event
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_RtpRespHandler(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                          IN e_IFX_SIPAPP_RTPEvent eRtpRespType)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  switch(eRtpRespType){
    case IFX_SIPAPP_OPEN_CONNRES_EVENT:
#ifdef RFC_3262
      if((pxAppData->iFlag & IFX_SIPAPP_DELAY_2XX) &&
         !(pxAppData->iFlag & IFX_SIPAPP_PRACK_PENDING)){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<OpenRspinProceeding> Sending 183rel");
        /* Copy the Locked Info in 0th Location */
        memcpy(&pxAppData->xSdpInfo.xRemCap[0],&pxAppData->xSdpInfo.
               xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry],
               sizeof(x_IFX_RemCapInfo));
        /* Send a 183 response */
        eRetVal = IFX_SIP_CC_AcceptCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL], 0,1);
        pxAppData->iFlag |= IFX_SIPAPP_PRACK_PENDING;
        if(eRetVal!=IFX_SIP_SUCCESS)
				{
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<OpenConnRspinProceeding>Error From TxmSendResp 183");
          return IFX_SIP_FAILURE;
        }
        return IFX_SIP_SUCCESS;
      }
#endif
	if(pxAppData->xSdpInfo.ucNumRemCap != 0){
	   /* Copy the Locked Info in 0th Location */
         memcpy(&pxAppData->xSdpInfo.xRemCap[0],&pxAppData->xSdpInfo.
             xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry],
             sizeof(x_IFX_RemCapInfo));
#ifdef FAX_SUPPORT
         if(pxAppData->xSdpInfo.iFlag & IFX_SIPAPP_FAX_SETUP){
           pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_FAX_SETUP;	  
         }
#endif 
	}
	if(pxAppData->iFlag & IFX_SIPAPP_SEND_REQ) {
	  if(pxAppData->xSdpInfo.ucNumRemCap==0){
	     /* Open Connection Response before sending Invite case */
	     eRetVal= IFX_SIPAPP_MakeCall(pxAppData);	 
	  }
	  else{
	     /* Open Connection Response Re-Invite case */	
	  }
	}
	else if(pxAppData->iFlag & IFX_SIPAPP_SEND_RESP){
#ifdef RFC_3262
		/* Reset the PRACK related flags */			
    pxAppData->iFlag &= ~IFX_SIPAPP_PRACK_PENDING;
#endif					
	   IFX_SIP_CC_AnswerCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
	}
        pxAppData->iFlag |= IFX_SIPAPP_RTP_SESS_EXIST;
    break;
    case IFX_SIPAPP_MODIFY_CONNRES_EVENT:
#ifdef RFC_3262
      if(pxAppData->iFlag & IFX_SIPAPP_PRACK_PENDING){
        eRetVal= IFX_SIPAPP_FinalPRACKHandling(pxAppData);
        if(eRetVal !=IFX_SIP_SUCCESS){
          IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<ModifyConnRspinProceeding>Error in FinalPRACKHandling");
          return IFX_SIP_FAILURE;
        }
        return IFX_SIP_SUCCESS;
      }
      if(pxAppData->iFlag & IFX_SIPAPP_DELAY_2XX){
        memcpy(&pxAppData->xSdpInfo.xRemCap[0],&pxAppData->xSdpInfo.
               xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry],
               sizeof(x_IFX_RemCapInfo));
        /* Send a 200 response */
        IFX_SIP_CC_AnswerCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
      }
#endif /*RFC_3262*/

	/* Copy the Locked Info in 0th Location */
	  if(pxAppData->xSdpInfo.nLockedCodecEntry > 0){
       memcpy(&pxAppData->xSdpInfo.xRemCap[0],&pxAppData->xSdpInfo.
           xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry],
           sizeof(x_IFX_RemCapInfo));
	  }
	/* Following will be done during Re-Invite cases */
	/* Send Local Hold/Resume success to the application */
       if((pxAppData->iFlag & IFX_SIPAPP_LOCAL_HOLD)&&
					!(pxAppData->iFlag &IFX_SIPAPP_ACK_RECIVED)){
          vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_HOLD_SUCCESS, 
                             NULL);
       }
       else if((pxAppData->iFlag & IFX_SIPAPP_LOCAL_RESUME)&&
							!(pxAppData->iFlag &IFX_SIPAPP_ACK_RECIVED)){
          vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_RESUME_SUCCESS,
                             NULL);
          /* Reset this hold flag */
          pxAppData->iFlag &= ~IFX_SIPAPP_LOCAL_RESUME;
          /* Reset this hold flag */
          pxAppData->iFlag &= ~IFX_SIPAPP_LOCAL_HOLD;
       }
			 else if(pxAppData->iFlag &IFX_SIPAPP_MEDIA_UPDATE_SENT){
          vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MEDIA_UPDATE_SUCCESS,
                             pxAppData);
					/* Reset this hold flag */
					pxAppData->iFlag &= ~IFX_SIPAPP_MEDIA_UPDATE_SENT;
			 }
			 pxAppData->iFlag &= ~IFX_SIPAPP_ACK_RECIVED;
       if(pxAppData->iFlag & IFX_SIPAPP_REMOTE_RESUME_FLAG){
          pxAppData->iFlag &= ~IFX_SIPAPP_REMOTE_RESUME_FLAG;      
          pxAppData->iFlag &= ~IFX_SIPAPP_REMOTE_HOLD_FLAG;      
       }
    break;		
		default:
		 break;
  }
  return eRetVal;
}
                                  

#ifdef INFO_SUPPORT
/******************************************************************
*  Function Name  : IFX_SIPAPP_SendINFO 
*  Description    : Send info method over the requeste ID
*  Input Values   : iConnId - Connection Identifier, Info params and privatedata
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SendINFO(IN uint32 uiCallId,
					IN x_IFX_InfoMethod *pxDigitInfo,
                    IN void *pvPrivateData)
{
    x_IFX_SIPAPP_UAAppData *pxAppData =(x_IFX_SIPAPP_UAAppData *)pvPrivateData;

	IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered SendInfo");
	/* copy digit info into app data*/
	memcpy(&pxAppData->xInfoMethod,pxDigitInfo,sizeof(x_IFX_InfoMethod));
    
	/* If outbound proxy set next hop address*/
    IFX_SIPAPP_SetNextHopAddr(pxAppData);
	return IFX_SIPAPP_SendInfo(pxAppData);

}
#endif
/******************************************************************
*  Function Name  : IFX_SIPAPP_UpdateMediaParams
*  Description    : Send A ReInvite to initamte the peer about the media modifications 
*  Input Values   : iConnId - Connection Identifier, media params and privatedata
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UpdateMediaParams(IN uint32 uiCallId,
					   IN x_IFX_MediaParams *pxMediaParams,
					   IN void *pvPrivateData)
{
   x_IFX_SIPAPP_UAAppData *pxAppData =(x_IFX_SIPAPP_UAAppData *)pvPrivateData;
   uint32 uiDlgHeadHdl=0,uiDlgHdl=0,uiSdpMsgHdl=0;
   e_IFX_SIP_Return eRetVal= IFX_SIP_SUCCESS;
   e_IFX_SIP_Ecode eEcode;

   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Update Media Params");
   if(pxMediaParams != NULL){
    /*Copy CodecList*/
    memcpy(&pxAppData->xCodecList,
	       &pxMediaParams->xCodecParams,sizeof(x_IFX_CodecList));
    

		if((pxAppData->xCodecList.axCodec[0].uiCodec == IFX_T38_UDP)||
			 (pxAppData->xCodecList.axCodec[0].uiCodec == IFX_T38_TCP)){
				
			 uiSdpMsgHdl = pxAppData->xSdpInfo.uiSdpMsgHdl;
			 pxAppData->xSdpInfo.uiSdpMsgHdl =0;
		}
    /*Copy Fax Params*/
    memcpy(pxAppData->axFaxParams,
	       pxMediaParams->axFaxParams, sizeof(x_IFX_FaxParams)*IFX_MAX_FAX_PROTO);
	
    pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort= 
	    pxAppData->axFaxParams[0].uiLocalFaxPort;

    /* Configure Ports*/
    pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort =
		pxMediaParams->xRtpParams.uiLocalRtpPort;
  }

  eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Dialog head is null");
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MEDIA_UPDATE_FAILURE,
		                        "Dilog Head is NULL"); 	
    return eRetVal;
  } 
  eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl, &eEcode);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "No Confirmed dialog");
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MEDIA_UPDATE_FAILURE,
		                     "No COnfirmed dialog to send Re-Invite"); 		 
    return eRetVal;
  } 
  /* If outbound proxy set next hop address*/
  IFX_SIPAPP_SetNextHopAddr(pxAppData);
#ifdef RFC_3311 /*Clear UPDATE offer/Answer */
  pxAppData->iUpdateFlag &=  ~IFX_SIPAPP_UPDATE; 
#endif
  eRetVal= IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,uiDlgHdl,
	                            "INVITE");
  pxAppData->iFlag |= IFX_SIPAPP_MEDIA_UPDATE_SENT;
	/* Not A Clean Fix-murali*/
  if(uiSdpMsgHdl !=0){
					pxAppData->xSdpInfo.uiSdpMsgHdl = uiSdpMsgHdl;	
	}
	return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_AcceptUpdateMediaParams
*  Description    : Send response to the media modifications 
*  Input Values   : iConnId - Connection Identifier, media params and privatedata
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AcceptUpdatedMediaParams(IN uint32 uiCallId,
					                IN x_IFX_MediaParams *pxMediaParams,
								    IN void *pvPrivateData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData =(x_IFX_SIPAPP_UAAppData *)pvPrivateData;
  uint32 uiDlgHeadHdl=0,uiDlgHdl=0;
  //e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Accept Update Media Params");

  if(pxMediaParams != NULL){
    /*Copy CodecList*/
    memcpy(&pxAppData->xCodecList,
	       &pxMediaParams->xCodecParams,sizeof(x_IFX_CodecList));
    
   #ifdef FAX_SUPPORT
     /*Copy Fax Params*/
    memcpy(pxAppData->axFaxParams,
	       pxMediaParams->axFaxParams,sizeof(pxAppData->axFaxParams));
    pxAppData->xSdpInfo.xRtpInfo.iLocalFaxUdpPort= 
	       pxAppData->axFaxParams[0].uiLocalFaxPort;
    pxAppData->xSdpInfo.xRtpInfo.iLocalFaxTcpPort= 
	       pxAppData->axFaxParams[1].uiLocalFaxPort;
#endif
    /* Configure Ports*/
    pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort =
		pxMediaParams->xRtpParams.uiLocalRtpPort;
  }
  /*eRetVal =*/ IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);

 /* eRetVal = */IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl, &eEcode);

  if(pxAppData->eMediaUpdateMethod == IFX_SIP_INVITE){
    return IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
	    	                         200,NULL,uiDlgHdl,"INVITE");
  }
  else{
    return IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
	    	                         200,NULL,uiDlgHdl,"UPDATE");
  }
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_RejectUpdateMediaParams
*  Description    : Send response to the  media modifications 
*  Input Values   : iConnId - Connection Identifier, media params and privatedata
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_RejectUpdatedMediaParams(IN uint32 uiCallId,
					                IN e_IFX_ReasonCode* peReason,
					                IN void *pvPrivateData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData =(x_IFX_SIPAPP_UAAppData *)pvPrivateData;
  uint32 uiDlgHeadHdl=0,uiDlgHdl=0;
  //e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered Reject Update Media Params");

  /*eRetVal = */IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);

  /*eRetVal = */IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl, &eEcode);

  if(pxAppData->eMediaUpdateMethod == IFX_SIP_INVITE){
    return IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
	    	                         500,NULL,uiDlgHdl,"INVITE");
  }
  else{
    return IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
	    	                         500,NULL,uiDlgHdl,"UPDATE");
  }

}

/******************************************************************
*  Function Name  : IFX_SIPAPP_GetMediaParams
*  Description    : Get Media Params recived from the remote end 
*  Input Values   : iConnId - Connection Identifier, media params and privatedata
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_GetMediaParams(IN uint32 uiCallId,
						  OUT x_IFX_MediaParams *pxMediaParams,
						  IN void *pvPrivateData)
{
   x_IFX_SIPAPP_UAAppData *pxAppData =(x_IFX_SIPAPP_UAAppData *)pvPrivateData;
   int32 iCount=0;

   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered GetMediaParams");
   if((pxAppData->xSdpInfo.ucNumRemCap ==0)||
			 (pxAppData->xSdpInfo.ucNumRemCap > 20)){
	   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Zero/Too many Remote Capabilites");
		 /* Dont return fail */
		 memset(pxMediaParams,0,sizeof(x_IFX_MediaParams));
	   return IFX_SIP_SUCCESS;
	   //return IFX_SIP_FAILURE;
   }
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Filling Rtp remote Params");
   /* Fill Rtp Params*/
   pxMediaParams->xRtpParams.eSdpMode = pxAppData->xSdpInfo.eLocalMode;
   if(pxAppData->xSdpInfo.xRtpInfo.cRemoteRTPAddr[0] != '\0'){
   strcpy((char8 *)pxMediaParams->xRtpParams.szRemoteRtpIpAddr,pxAppData->xSdpInfo.xRtpInfo.cRemoteRTPAddr);
   strcpy((char8 *)pxMediaParams->xRtpParams.szRemoteRtcpIpAddr,pxAppData->xSdpInfo.xRtpInfo.cRemoteRTPAddr);
   }
   else{
     if((pxAppData->xSdpInfo.nLockedCodecEntry > 0) && (pxAppData->xSdpInfo.nLockedCodecEntry <=
	      pxAppData->xSdpInfo.ucNumRemCap) && (pxAppData->xSdpInfo.nLockedCodecEntry < IFX_MAX_CODECS)){
       strcpy((char8 *)pxMediaParams->xRtpParams.szRemoteRtpIpAddr,
	          pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].cRTPAddr);
       strcpy((char8 *)pxMediaParams->xRtpParams.szRemoteRtcpIpAddr,
	          pxAppData->xSdpInfo.xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].cRTPAddr);
	 }
	 else{
       IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "LOCKED CODEC ENTRY is INVALID");
	 }
   }
   pxMediaParams->xRtpParams.uiLocalRtcpPort= pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort+1;
   pxMediaParams->xRtpParams.uiLocalRtpPort=pxAppData->xSdpInfo.xRtpInfo.iLocalRTPPort;
   pxMediaParams->xRtpParams.uiRemoteRtcpPort=pxAppData->xSdpInfo.xRtpInfo.iRemoteRTPPort+1;
   pxMediaParams->xRtpParams.uiRemoteRtpPort=pxAppData->xSdpInfo.xRtpInfo.iRemoteRTPPort;
   pxMediaParams->xCodecParams.unNoOfCodecs = pxAppData->xSdpInfo.ucNumRemCap;
#ifdef FAX_SUPPORT	 
	 if(pxAppData->xSdpInfo.pxT38Capab != NULL){
     memcpy(pxMediaParams->axFaxParams,pxAppData->xSdpInfo.pxT38Capab,
	       sizeof(pxMediaParams->axFaxParams));
   }
#endif	 

   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Filled Codec Params");
   /* fill Codec Info*/
   for(iCount=0;iCount<IFX_MAX_CODECS-1 && iCount<pxAppData->xSdpInfo.ucNumRemCap;iCount++)
   {
     pxMediaParams->xCodecParams.axCodec[iCount].uiCodec=
		   pxAppData->xSdpInfo.xRemCap[iCount+1].uiRmCodec;
	   pxMediaParams->xCodecParams.axCodec[iCount].ucDynPT =
       pxAppData->xSdpInfo.xRemCap[iCount+1].ucCodec;
#ifdef FAX_SUPPORT
     if(pxAppData->xSdpInfo.xRemCap[iCount+1].uiRmCodec == IFX_T38_UDP){
         strcpy((char8 *)pxMediaParams->axFaxParams[0].szRemoteFaxIpAddr,
							  pxAppData->xSdpInfo.xRemCap[iCount+1].cRTPAddr);
				 pxMediaParams->axFaxParams[0].uiRemoteFaxPort = 
				   pxAppData->xSdpInfo.xRemCap[iCount+1].unRTPPort;
		 }
	   if(pxAppData->xSdpInfo.xRemCap[iCount+1].uiRmCodec == IFX_T38_TCP){
         strcpy((char8 *)pxMediaParams->axFaxParams[1].szRemoteFaxIpAddr,
								pxAppData->xSdpInfo.xRemCap[iCount+1].cRTPAddr);
				 pxMediaParams->axFaxParams[1].uiRemoteFaxPort = 
				   pxAppData->xSdpInfo.xRemCap[iCount+1].unRTPPort;
		 }
	 
#endif
   }

   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Filled sdp Dtmf payload");
	 if(pxAppData->xSdpInfo.unDtmfPT != 0){
		 pxMediaParams->xCodecParams.axCodec[iCount].uiCodec = IFX_DIGIT_2833;
		 pxMediaParams->xCodecParams.axCodec[iCount].ucDynPT = 
						 pxAppData->xSdpInfo.unDtmfPT; 
		 iCount++;	
     pxMediaParams->xCodecParams.unNoOfCodecs++;			 
	 }
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "GetMediaParams SUCCESS");
   return IFX_SIP_SUCCESS;

}
