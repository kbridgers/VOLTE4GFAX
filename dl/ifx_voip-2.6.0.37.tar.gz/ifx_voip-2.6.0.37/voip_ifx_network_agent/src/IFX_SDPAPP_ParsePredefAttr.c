/**************************************************************************
 **   FILE NAME       : IFX_SIPAPP_ParsePredefAttr.c
 **   PROJECT         : SIP signaling
 **   MODULES         : SDP DECODER
 **   SRC VERSION     : V1.0
 **   DATE            : 15-12-2004 
 **   AUTHOR          : Murali
 **   DESCRIPTION     : Parse predefined attributes
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines
 **   COPYRIGHT       : Copyright (c) 2004
 **                     Infineon Technologies AG, st. Martin Strasse 53;
 **                     81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "ifx_common_defs.h"
#include <IFX_SIP_Errors.h>
#include <IFX_SIP_Stack.h>
#include "IFX_SDP_GetSet.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"


char8 vtblAttrField[][27] =
{
  "sendrecv",
  "sendonly",
  "recvonly",
  "inactive",
  "rtpmap",
  "fmtp",
  "quality",
  "cat",
  "framerate",
  "lang",
  "sdplang",
  "charset",
  "type",
  "orient",
  "ptime",
  "tool",
  "keywds",
  "T38FaxVersion",
  "T38MaxBitRate",
  "T38FaxFillBitRemoval",
  "T38FaxTranscodingMMR",
  "T38FaxTranscodingJBIG",
  "T38FaxRateManagement",
  "T38FaxMaxBuffer",
  "T38FaxMaxDatagram",
  "T38FaxUdpEC",
  "rtcp"
};

IFX_SDPAPP_DecPredefAttrVal IFX_SDPAPP_DecPredefAttr[23] =
{
  IFX_SDPAPP_DecodeRtpMap,          /*rtpmap*/
  IFX_SDPAPP_DecodeFmtp,            /*fmtp*/
  IFX_SDPAPP_DecodeQuality,         /*quality*/
  IFX_SDPAPP_DecodeCategory,        /*cat*/
  IFX_SDPAPP_DecodeFramerate,       /*framerate*/
  IFX_SDPAPP_Decodelang,            /*lang*/
  IFX_SDPAPP_DecodeSdplang,         /*sdplang*/
  IFX_SDPAPP_DecodeCharset,         /*charset*/
  IFX_SDPAPP_DecodeConfType,        /*type*/
  IFX_SDPAPP_DecodeOrient,          /*orient*/
  IFX_SDPAPP_DecodePtime,           /*ptime*/
  IFX_SDPAPP_DecodeTool,            /*tool*/
  IFX_SDPAPP_DecodeKeywds,          /*keywds*/
  IFX_SDPAPP_DecodeT38FaxVersion,   /*T38FaxVersion*/
  IFX_SDPAPP_DecodeT38MaxBitRate,   /*T38MaxBitRate*/
  IFX_SDPAPP_DecodeFillBitRemoval,  /*T38FaxFillBitRemoval*/
  IFX_SDPAPP_DecodeTranscodingMMR,  /*T38FaxTranscodingMMR*/
  IFX_SDPAPP_DecodeTranscodingJBIG, /*T38FaxTranscodingJBIG*/
  IFX_SDPAPP_DecodeT38FaxRateMgmt,  /*T38FaxRateManagement*/
  IFX_SDPAPP_DecodeT38FaxMaxBuffer, /*T38FaxMaxBuffer*/
  IFX_SDPAPP_DecodeT38FaxMaxDgram,  /*T38FaxMaxDatagram*/
  IFX_SDPAPP_DecodeT38FaxUdpEC,     /*T38FaxUdpEC*/
  IFX_SDPAPP_DecodeRtcp,            /*rtcp*/
};




/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeTranscodingMMR
*  Description  :  This function decodes category attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeTranscodingMMR(char8* pcStartIndex,
                              char8* pcEndIndex,
                              x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_TRANSMMR;
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Name:  IFX_SDPAPP_DecodeTranscodingJBIG
*  Description  :  This function decodes category attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeTranscodingJBIG(char8* pcStartIndex,
                               char8* pcEndIndex,
                               x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_TRANSJBIG;
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeFillBitRemoval
*  Description  :  This function decodes category attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeFillBitRemoval(char8* pcStartIndex,
                                char8* pcEndIndex,
                                x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_FILLBITREM;
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeCategory
*  Description  :  This function decodes category attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeCategory(char8* pcStartIndex,
                        char8* pcEndIndex,
                        x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_CAT;
  /* Store the value */
  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acCategory,pcStartIndex,\
                    (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acCategory[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeKeywds
*  Description  :  This function decodes keyword attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeKeywds(char8* pcStartIndex,
                      char8* pcEndIndex,
                      x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_KEYWDS;
  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acKeywds,pcStartIndex,\
                    (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acKeywds[(pcEndIndex - pcStartIndex)] = '\0';  
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeTool
*  Description  :  This function decodes tool attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeTool(char8* pcStartIndex,
                    char8* pcEndIndex,
                    x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_TOOL;
  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acToolInfo,pcStartIndex,\
                    (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acToolInfo[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodePtime
*  Description  :  This function decodes ptime attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodePtime(char8* pcStartIndex,
                     char8* pcEndIndex,
                     x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[11];

  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_PTIME;

  /* As int32 can hold only 10 digits */
  if((pcEndIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.iPTime = atoi(acTemp);
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeOrient
*  Description  :  This function decodes orientation attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeOrient(char8* pcStartIndex,
                      char8* pcEndIndex,
                      x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[IFX_SDPAPP_MAX_ATTR_VALUE];

  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_ORIENT;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
  }
  if(strcmp(acTemp,"portrait") == 0){
    pxSdpAttr->uxSdpAttr.eOrient = IFX_SDPAPP_PORTRAIT;
  }
  else if(strcmp(acTemp,"landscape") == 0){
    pxSdpAttr->uxSdpAttr.eOrient = IFX_SDPAPP_LANDSCAPE;
  }
  else if(strcmp(acTemp,"seascape") == 0){
    pxSdpAttr->uxSdpAttr.eOrient = IFX_SDPAPP_SEASCAPE;
  }
  else{
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeConfType
*  Description  :  This function decodes conference type attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeConfType(char8* pcStartIndex,
                        char8* pcEndIndex,
                        x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 cRet = IFX_SIP_SUCCESS;
  char8 acTemp[IFX_SDPAPP_MAX_ATTR_VALUE];

  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_TYPE;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
  }
  if(strcmp(acTemp,"broadcat") == 0){
    pxSdpAttr->uxSdpAttr.eConfType = IFX_SDPAPP_BROADCAST;
  }
  else if(strcmp(acTemp,"meeting") == 0){
    pxSdpAttr->uxSdpAttr.eConfType = IFX_SDPAPP_MEETING;
  }
  else if(strcmp(acTemp,"moderated") == 0){
    pxSdpAttr->uxSdpAttr.eConfType = IFX_SDPAPP_MODERATED;
  }
  else if(strcmp(acTemp,"test") == 0){
    pxSdpAttr->uxSdpAttr.eConfType = IFX_SDPAPP_TEST;
  }
  else if(strcmp(acTemp,"H332") == 0){
    pxSdpAttr->uxSdpAttr.eConfType = IFX_SDPAPP_H332;
  }
  else{
    cRet = IFX_SIP_FAILURE;
  }
  return cRet;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeCharset
*  Description  :  This function decodes Charset attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeCharset(char8* pcStartIndex,
                       char8* pcEndIndex,
                       x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_CHARSET;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acCharSet,pcStartIndex,\
                      (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acCharSet[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeSdplang
*  Description  :  This function decodes Sdplanf attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeSdplang(char8* pcStartIndex,
                       char8* pcEndIndex,
                       x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_SDPLANG;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acSdpLang,pcStartIndex,\
                    (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acSdpLang[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}

/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeRtpMap
*  Description  :  This function decodes rtpmap attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeRtpMap(char8* pcStartIndex,
                      char8* pcEndIndex,
                      x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[100];
  char8* pcTempIndex;

  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_RTPMAP;

  /* Decode the pay load type */
  pcTempIndex = strchr(pcStartIndex,' ');
  if(pcTempIndex == NULL){
    return IFX_SIP_FAILURE;
  }
  /* check and Fill in the value */
  if((pcTempIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcTempIndex - pcStartIndex));
    acTemp[(pcTempIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.xRtpMap.iPayloadType = atoi(acTemp);
  }
  /* Update the current position */
  pcStartIndex += (pcTempIndex - pcStartIndex + 1);

  /* Decode the Encoding Name */
  pcTempIndex = strchr(pcStartIndex,'/');
  if(pcTempIndex == NULL){
    return IFX_SIP_FAILURE;
  }
  /* Fill in the value */
  if((pcTempIndex - pcStartIndex) > IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcTempIndex - pcStartIndex));
    acTemp[(pcTempIndex - pcStartIndex)] = '\0';
    strcpy(pxSdpAttr->uxSdpAttr.xRtpMap.acEncodingName,acTemp);
  }
  /* Update the current position */
  pcStartIndex += (pcTempIndex - pcStartIndex + 1); 

  /* Decode the Clock Rate */
  pcTempIndex = strchr(pcStartIndex,'/');
  if(pcTempIndex == NULL){
    pcTempIndex = pcEndIndex;
  }
  /* Fill in the value */
  if((pcTempIndex - pcStartIndex) > IFX_SDPAPP_MAX_ATTR_FIELD){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcTempIndex - pcStartIndex));
    acTemp[(pcTempIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.xRtpMap.iClockRate = atoi(acTemp);
  }
  /* Update the current position */
  pcStartIndex += (pcTempIndex - pcStartIndex + 1);

  /* Decoding Encoding Params */
  if(pcTempIndex != pcEndIndex){
    if((pcEndIndex - pcStartIndex) > IFX_SDPAPP_MAX_ATTR_FIELD){
      return IFX_SIP_FAILURE;
    }
    else{
      strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
      acTemp[(pcEndIndex - pcStartIndex)] = '\0';
      strcpy(pxSdpAttr->uxSdpAttr.xRtpMap.acEncodingParams,acTemp);
    }
  }   
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_Decodelang
*  Description  :  This function decodes lang attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_Decodelang(char8* pcStartIndex,
                    char8* pcEndIndex,
                    x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* Set the type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_LANG;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acLang,pcStartIndex,\
                  (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acLang[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeFramerate
*  Description  :  This function decodes Frame rate attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeFramerate(char8* pcStartIndex,
                         char8* pcEndIndex,
                         x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_FRAMERATE;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.acFrameRate,pcStartIndex,\
                    (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.acFrameRate[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeQuality
*  Description  :  This function decodes Quality attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeQuality(char8* pcStartIndex,
                       char8* pcEndIndex,
                       x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[11];

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_QUALITY;

  if((pcEndIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.iQuality = atoi(acTemp);
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeFmtp
*  Description  :  This function decodes Fmtp attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeFmtp(char8* pcStartIndex,
                    char8* pcEndIndex,
                    x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[IFX_SDPAPP_MAX_ATTR_VALUE];
  char8* pcTempIndex;

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_FMTP;

  /* Decode the Format */
  pcTempIndex = strchr(pcStartIndex,' ');
  if(pcTempIndex == NULL){
    return IFX_SIP_FAILURE;
  }
  /* Fill in the value */
  if((pcTempIndex - pcStartIndex) < 10){
    strncpy(acTemp,pcStartIndex,(pcTempIndex - pcStartIndex));
    acTemp[(pcTempIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.xFmtp.iFormat = atoi(acTemp);
  }
  else{
    return IFX_SIP_FAILURE;
  }
  /* Update the current position */
  pcStartIndex = pcTempIndex + 1;

  /* Decoding Format specific params */
  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(pxSdpAttr->uxSdpAttr.xFmtp.acFmtpParams,pcStartIndex,\
                      (pcEndIndex - pcStartIndex));
    pxSdpAttr->uxSdpAttr.xFmtp.acFmtpParams[(pcEndIndex - pcStartIndex)] = '\0';
  }
  return IFX_SIP_SUCCESS;
}

/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeT38FaxVersion
*  Description  :  This function decodes T38FaxVersion attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeT38FaxVersion(char8* pcStartIndex,
                             char8* pcEndIndex,
                             x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[11];

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_FAXVER;

  if((pcEndIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.iFaxVersion = atoi(acTemp);
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeT38MaxBitRate
*  Description  :  This function decodes Max Bit Rate attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeT38MaxBitRate(char8* pcStartIndex,
                             char8* pcEndIndex,
                             x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[11];

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_MBR;

  if((pcEndIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.iMaxBitRate = atoi(acTemp);
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeT38FaxRateMgmt
*  Description  :  This function decodes Rate Management attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeT38FaxRateMgmt(char8* pcStartIndex,
                              char8* pcEndIndex,
                              x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[IFX_SDPAPP_MAX_ATTR_VALUE];

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_RATEMGMT;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    if(strcmp(acTemp,"transferredTCF") == 0){
      pxSdpAttr->uxSdpAttr.eFaxRateMgmt = IFX_SDPAPP_TRANSFERRED_TCF;
    }
    else if(strcmp(acTemp,"localTCF") == 0){
      pxSdpAttr->uxSdpAttr.eFaxRateMgmt = IFX_SDPAPP_LOCAL_TCF;
    }
    else{
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeT38FaxMaxBuffer
*  Description  :  This function decodes Max buffer attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeT38FaxMaxBuffer(char8* pcStartIndex,
                               char8* pcEndIndex,
                               x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[11];

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_MAXBUFF;

  if((pcEndIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0'; 
    pxSdpAttr->uxSdpAttr.iMaxBuffer = atoi(acTemp);
  }
  return IFX_SIP_SUCCESS;
}

/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeT38FaxMaxDgram
*  Description  :  This function decodes Max datagram attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeT38FaxMaxDgram(char8* pcStartIndex,
                              char8* pcEndIndex,
                              x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[11];

  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_MAXDGRAM;
  if((pcEndIndex - pcStartIndex) > 10){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    pxSdpAttr->uxSdpAttr.iMaxDgram = atoi(acTemp);
  }
  return IFX_SIP_SUCCESS;
}

/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeT38FaxUdpEC
*  Description  :  This function decodes Fax UDP EC attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeT38FaxUdpEC(char8* pcStartIndex,
                           char8* pcEndIndex,
                           x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8 acTemp[IFX_SDPAPP_MAX_ATTR_VALUE];

  /* set type as other type */
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_UDPEC;

  if((pcEndIndex - pcStartIndex) >= IFX_SDPAPP_MAX_ATTR_VALUE){
    return IFX_SIP_FAILURE;
  }
  else{
    strncpy(acTemp,pcStartIndex,(pcEndIndex - pcStartIndex));
    acTemp[(pcEndIndex - pcStartIndex)] = '\0';
    if(strcmp(acTemp,"t38UDPFEC") == 0){
      pxSdpAttr->uxSdpAttr.eUdpEC = IFX_SDPAPP_T38UDPFEC;
    }
    else if(strcmp(acTemp,"t38UDPRedundancy") == 0){
      pxSdpAttr->uxSdpAttr.eUdpEC = IFX_SDPAPP_T38UDPREDUNDANCY;
    }
  }
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeDummy
*  Description  :  This function decodes Fax UDP EC attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeDummy(char8* pcStartIndex,
                     char8* pcEndIndex,
                     x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  return IFX_SIP_SUCCESS;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeRtcp
*  Description  :  This function decodes RTCP attribute field
*  Input        :  start and end indices of attibute value
*  Output       :  populated pxSdpAttr
*  Return       :  Success or failure
***************************************************************************/
char8
IFX_SDPAPP_DecodeRtcp(char8* pcStartIndex,
                    char8* pcEndIndex,
                    x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  char8* pcTempIndex, cRet = IFX_SIP_SUCCESS;
  char8 acTemp[10];

  *pcEndIndex = '\0';
  pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_RTCP;
 
  do{
    /* Get the Port */
	pcTempIndex = strchr(pcStartIndex,' ');
    if(((pcTempIndex - pcStartIndex) > 5) || ((pcTempIndex -
	  pcStartIndex) == 0)){
	  cRet = IFX_SIP_FAILURE;
	  break;
    }
    else{
      strncpy(acTemp,pcStartIndex,(pcTempIndex - pcStartIndex));
      acTemp[(pcTempIndex - pcStartIndex)] = '\0';
      pxSdpAttr->uxSdpAttr.xRtcp.unRtcpPort = atoi(acTemp);
    }
#if 0	
    /*Get the nettype */
	pcStartIndex = pcTempIndex + 1;
	pcTempIndex = strchr(pcStartIndex,' ');
	if(pcTempIndex == NULL){
	  cRet = IFX_SIP_FAILURE;
	  break;
	}
	*pcTempIndex = '\0';
	if(strcmp(pcStartIndex,"IN")!= 0){
	  cRet = IFX_SIP_FAILURE;
	  break;
    }
    pxSdpAttr->uxSdpAttr.xRtcp.eNetwork = IFX_SDP_IN;
    /* Get an addrtype */
	pcStartIndex = pcTempIndex + 1;
    pcTempIndex = strchr(pcStartIndex,' ');
	if(pcTempIndex == NULL){
	  cRet = IFX_SIP_FAILURE;
	  break;
	}
	*pcTempIndex = '\0';
	if(strcmp(pcStartIndex,"IP4") == 0){
	  pxSdpAttr->uxSdpAttr.xRtcp.eAddrType = IFX_SDP_IPV4;
    }
    else if(strcmp(pcStartIndex,"IP6") == 0){
	  pxSdpAttr->uxSdpAttr.xRtcp.eAddrType = IFX_SDP_IPV6;
    }
	else{
	  cRet = IFX_SIP_FAILURE;
	  break;
	}
    pcStartIndex = pcTempIndex + 1;
	/* Get connection address */
	if((pcEndIndex - pcStartIndex) > IFX_SDPAPP_MAX_ADDR){
	  cRet = IFX_SIP_FAILURE;
	  break;
	}
    IFX_SDPAPP_CheckIpAddr(pcStartIndex,pcEndIndex,&ucAddrFlag);
	/* Conn addr type = unicast */
	if(ucAddrFlag == 1){
	  pxSdpAttr->uxSdpAttr.xRtcp.xConnAddr.ucConnAddrType = IFX_SDP_IP_ADDR;
	  cRet = IFX_SDPAPP_DecodeUniCast(pcStartIndex,pcEndIndex);
	  if(cRet == IFX_SIP_FAILURE){
		break;
	  }
	}
	/* Conn addr type = FQDN */
    else if(ucAddrFlag == 3){
	  pxSdpAttr->uxSdpAttr.xRtcp.xConnAddr.ucConnAddrType = IFX_SDPAPP_FQDN;
	  cRet = IFX_SDPAPP_DecodeFQDN(pcStartIndex,pcEndIndex);
	  if(cRet == IFX_SIP_FAILURE){
		break;
	  }
    }
    /* Conn addr type = multicast */
    else if(ucAddrFlag == 2){
	  pxSdpAttr->uxSdpAttr.xRtcp.xConnAddr.ucConnAddrType = 
	                                     IFX_SDPAPP_MULTICAST_ADDR;
      cRet = IFX_SDPAPP_DecodeMultiCast(pcStartIndex,pcEndIndex);
	  if(cRet == IFX_SIP_FAILURE){
	    break;
	  }
	}
	else{
	  cRet = IFX_SIP_FAILURE;
      break;
    }
    strcpy(pxSdpAttr->uxSdpAttr.xRtcp.xConnAddr.acConnAddr,pcStartIndex);
#endif
  }while(0);
	  
  return cRet;
}
/*************************************************************************
*  Function Name:  IFX_SDPAPP_DecodeAttr
*  Description  :  This function decodes attribute field 
*  Input    :  pcStartIndex,pcEndIndex.
*  Output   :  pxSdpAttr  
*  Return   :  Success or failure 
***************************************************************************/
char8
IFX_SDPAPP_DecodeSdpAttr(uint32 uiMediaDescHdl,
		      int32 iLoc,
		      x_IFX_SDPAPP_Attributes* pxSdpAttr)
{
  int32 i;
  uint32 uiAttrHdl;
  char8 cRet = IFX_SIP_SUCCESS;
  char8* pcAttrName=NULL,*pcAttrVal = NULL;
  
  if(IFX_SDP_Media_GetParamByType(uiMediaDescHdl,IFX_SDP_MEDIA_ATTRIBUTES,iLoc,
                                  &uiAttrHdl) == IFX_SDP_FAILURE){
    return IFX_SIP_FAILURE;	  
  }
  pcAttrName = IFX_SDP_Attribute_GetName(uiAttrHdl);
  if(pcAttrName == NULL){
    return IFX_SIP_FAILURE;	  
  }  
  pcAttrVal = IFX_SDP_Attribute_GetValue(uiAttrHdl);
  /* Check if it is a direction attribute and set the mode */
  for(i = 0; i < 4; i++){
    if(strcmp(pcAttrName,vtblAttrField[i]) == 0){
      /* Return the mode */
      return i;
    }
  }
  for(i = 4; i < IFX_SDPAPP_NUM_ATTR_FIELDS; i++){
    if(strcmp(pcAttrName,vtblAttrField[i]) == 0){
      pcAttrVal = IFX_SDP_Attribute_GetValue(uiAttrHdl);
      /* call appropriate decode function */
      cRet = IFX_SDPAPP_DecPredefAttr[i - 4](pcAttrVal,pcAttrVal+strlen(pcAttrVal),                                          pxSdpAttr);
      break;
    }
  }
  if((cRet == IFX_SIP_FAILURE) || (i == IFX_SDPAPP_NUM_ATTR_FIELDS)){
    /* set type as other type */
    pxSdpAttr->eAttrType = IFX_SDPAPP_ATTR_OTHER;
    /* Fill attribute field */
    strcpy(pxSdpAttr->uxSdpAttr.xOtherAttr.acAttrField,pcAttrName);
    /* Fill attribute value */
    if(pcAttrVal != NULL){
      strcpy(pxSdpAttr->uxSdpAttr.xOtherAttr.acAttrValue,pcAttrVal);
    }
  }
  return IFX_SIP_SUCCESS;
}
