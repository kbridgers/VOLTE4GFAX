/**************************************************************************
**   FILE NAME     : IFX_SIP_Info.c
**   PROJECT  	   : SIP
**   MODULES       : Transaction User(Call Control)
**   SRC VERSION   : V2.0 
**   DATE    	     : 
**   AUTHOR        : SIP team
**   DESCRIPTION   : This file contains the functions related to the INFO
**                   method. Though it is a part of call control it is not 
**                   included in the FSM as the state of the call remains 
**                   unchanged
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**
**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifdef INFO_SUPPORT

#include "ifx_common_defs.h"
#include "ifx_debug.h"

#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_CCApi.h"
#include "IFX_SIP_DlgApi.h"
#include "IFX_SDP_GetSet.h"


#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Transceiver.h"
#include "IFX_SIPAPP_Uac.h"
#include "IFX_SIPAPP_Uas.h"
#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_CallIf.h"
#include "ifx_list.h"

extern uchar8 vcSipAppModId;

/******************************************************************
*  Function Name  : IFX_SIP_InfoConst
*  Description    : this function adds specific information for
*             		  the Info request
*  Input Values   : pxEndptInfo ........ pointer to the endpoint info
*                   pxDlgType............Pointer to the dialog					
*  Output Values  : pxEncodedMsg...pointer to sip data structure which gets 
*                   encoded in the stack
*           		    peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           		    IFX_SIP_FAILURE
*  Notes          :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InfoConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                  OUT uint32 uiMsgHdl,
                  OUT e_IFX_SIP_Ecode* peEcode)
{
  char8 acTemp[100]={0};
  IFX_SIPAPP_SetContentType("application","dtmf",uiMsgHdl);
  if(pxAppData->xInfoMethod.eEvent == IFX_INFO_DTMF_RELAY_CONTENT)
  {
    sprintf(acTemp,"Signal=%c\r\nDuration=%d\r\n",
                pxAppData->xInfoMethod.ucDigit,
                pxAppData->xInfoMethod.unDuration);
  }
  else if(pxAppData->xInfoMethod.eEvent == IFX_INFO_DTMF_CONTENT)
  {
    sprintf(acTemp,"%c",(pxAppData->xInfoMethod.ucDigit));
  } 
  else
  {
    return IFX_SIP_FAILURE;
  }
  IFX_SIP_AddMsgBody(uiMsgHdl,strlen(acTemp),acTemp);
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Info Const Success");

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIP_HandleInfo
*  Description    : This function processes the Info request
*  Input Values   : pxDecodedMsg...pointer to sip data structure which 
*             	    contains the response information
*           	      pxEndptInfo ... pointer to the endpt information
*           	      pxDlgType..indication whether the request is inside
*                   or outside a dialog
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	      IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandleInfo(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                     IN uint32 uiMsgHdl,
                     OUT e_IFX_SIP_Ecode* peEcode)
{
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Info REsponse arrived");
  /* 415,481 would have already been sent in case of failure
   * Only send a 200 response in this case */
  return IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
		             200,"OK",0,"INFO");
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_SendInfo 
*  Description    : Send Info.
*  Input Values   : pxAppData - Application Data
*  Output Values  : None
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SendInfo(IN x_IFX_SIPAPP_UAAppData *pxAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  uint32 uiDlgHeadHdl=0,uiDlgHdl=0;
 
  eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Dialog head is null");
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_INFO_FAIL,"Dilog Head is NULL"); 	
    return eRetVal;
  } 
  eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl,&eEcode);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "No Confirmed dialog");
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_INFO_FAIL,
		  "No COnfirmed dialog to send Re-Invite"); 		 
    return eRetVal;
  }
  /* Send a Re-Invite */
  eRetVal = IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                       0,uiDlgHdl, "INFO");
   if(eRetVal != IFX_SIP_SUCCESS){  
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Should never reach here (IFX_CC_sendReq fail)");
     vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_RELEASE_SIGNAL,
                                 NULL);
     IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
     IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_CALL); 
     return eRetVal;
   }
   IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "INFO Sent Success");
  return eRetVal;
}
#endif
