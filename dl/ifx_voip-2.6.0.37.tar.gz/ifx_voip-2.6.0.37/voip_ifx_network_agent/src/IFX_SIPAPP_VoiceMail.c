/**************************************************************************
 **   FILE NAME     : IFX_SIPAPP_VoiceMail.c
 **   PROJECT       : SIP
 **   MODULES       : Transaction User
 **   SRC VERSION   : V2.0
 **   DATE          : 17-08-2005
 **   AUTHOR        : SIP Team
 **   DESCRIPTION   : This file uses the APIs provided by MWI subs-notify
 **   COMPILER      : gcc
 **   REFERENCE     :
 **   COPYRIGHT     : Copyright (c) 2004
 **                   Infineon Technologies AG, st. Martin Strasse 53;
 **                   81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted
 **
 **   Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 ***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"

#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_DlgApi.h"
#include "IFX_SIP_Message.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SIP_CCApi.h"

/*SDP Agent Files*/
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"

#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Config.h"

#include "IFX_SIP_EvtPkg.h"
#include "IFX_SIPAPP_VoiceMail.h"
#include "ifx_list.h"

extern uchar8 vcSipAppModId;

/******************************************************************
*  Function Name    : IFX_SIPAPP_ReSubcMWIHndlr
*  Description      : This function creates the subscription
*                     for message waiting.
*  Input Values     :
*  Output Values    :
*  Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ReSubcMWIHndlr(x_IFX_SIPAPP_UAAppData *pxAppData)
{
  char8 acTo[IFX_SIPAPP_MAX_TOKEN]="", acFrom[IFX_SIPAPP_MAX_TOKEN]="";
  uint32 uiMsgHdl=0, uiHdrHdl=0, uiDlgList;
  e_IFX_SIP_Ecode eEcode;

  /* Create a new default message template */
  IFX_SIP_CreateMsg(&uiMsgHdl);
  IFX_SIP_SetHeaderByType(uiMsgHdl, IFX_SIP_ACCEPT, &uiHdrHdl);
  IFX_SIP_Accept_SetMType(uiHdrHdl, "application");
  IFX_SIP_Accept_SetMSubType(uiHdrHdl, "simple-message-summary");

  /* Fill up the message details */
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xTo, acTo);
  IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xFrom, acFrom);

  /* handle the proxy ON setting */
  if(IFX_SIPAPP_IS_PROXYON(pxAppData))
  {
    IFX_SIP_SubscSetNextHopAddr(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI],
      IFX_SIPAPP_GET_PROXYADDRESS(pxAppData),
      pxAppData->unLocalTcpPort,
      IFX_SIPAPP_GET_PROXYPORT(pxAppData),
      IFX_SIPAPP_GET_PROXYTRANSPORT(pxAppData));
  }

  /* Send the request*/
  if(IFX_SIP_SubscSend(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI],
	   pxAppData->uiDlgIdHdl, acFrom, acTo,
       pxAppData->uiVMExpires, "message-summary", uiMsgHdl,
       pxAppData->unLocalTcpPort) != IFX_SIP_SUCCESS)
  {
    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Could not send SUBSCRIBE to VMS");
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_FAILURE;
  }

  /* Add this dialog's Id to the pxAppData structure */
  IFX_SIP_SubscGetDlg(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI], &uiDlgList);
  IFX_SIP_DLG_GetDialogFromList(uiDlgList, &pxAppData->uiDlgIdHdl, &eEcode);

  //IFX_SIP_FreeMsg(uiMsgHdl);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name    : IFX_SIPAPP_SubscribeForMWI
*  Description      : This function creates the subscription
*                     for Voicemail.
*  Input Values     :
*  Output Values    :
*  Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SubscribeForMWI(IN uint32 uiConnId,
                           IN uint32 uiSrvPdrId,
                           IN uint32 uiExpires,
                           IN x_IFX_SIPAPP_RouteParams *pxRouteParams,
                           OUT void **ppvAppData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData;
  e_IFX_SIP_Ecode eEcode;

  if(ppvAppData == NULL)
  {
    IFX_DBGC(vcSipAppModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  /* Check if teh subscription request is new, or part of an existing dialog */
  if(*ppvAppData == NULL)
  {
    if(!uiExpires)
	  {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " Expires cannot be 0 for subscription ");
      return IFX_SIP_FAILURE;
	  }

    /* Create App Data */
    if(IFX_SIPAPP_CreateNAddAppData(&pxAppData, &eEcode) != IFX_SIP_SUCCESS)
	  {
      return IFX_SIP_FAILURE;
	  }
    /* Copy the ncessary data to User Data */
    *ppvAppData = (void*)pxAppData;
    pxAppData->iConnId = uiConnId;
    pxAppData->iProfileId = uiSrvPdrId;
    pxAppData->unLocalTcpPort = pxRouteParams->unLocalTcpPort;
    pxAppData->uiVMExpires = uiExpires;
    memcpy(&pxAppData->xTo, pxRouteParams->pxTo, sizeof(x_IFX_CalledAddr));
    memcpy(&pxAppData->xFrom, pxRouteParams->pxFrom, sizeof(x_IFX_CalledAddr));
    /*Copy CallerId suppression*/
		pxAppData->bSupressCallerId = pxRouteParams->bSupressCallerId;
	  if(pxAppData->bSupressCallerId){
	    strcpy(pxAppData->xFrom.acUserName,"anonymous");
		  strcpy(pxAppData->xFrom.acCalledAddr,"anonymous.invalid");
		  strcpy(pxAppData->xFrom.acDisplayName,"anonymous");
	  }


    /*Copy Proxy Info*/
    if((!pxRouteParams->pcProxyAddr) && (pxRouteParams->pcProxyAddr))
	  {
      strcpy(pxAppData->acProxyAddr, pxRouteParams->pcProxyAddr);
      pxAppData->eProxyProtocol = pxRouteParams->eProxyProtocol;
      pxAppData->unProxyPort = pxRouteParams->unProxyPort;
      pxAppData->ucIsOutBoundProxy = pxRouteParams->ucIsOutBoundProxy;
	  }

    /* If Addr type is IP and port is zero copy default port */
    if((pxAppData->xTo.ucAddrType == IFX_IP_ADDR) &&
       (!pxAppData->xTo.unPort))
	  {
      pxAppData->xTo.unPort = IFX_SIP_DEFAULT_PORT;
	  }
  }
  else
  {
     pxAppData = *ppvAppData;
  }

  /* Create the subscription */
  if(IFX_SIP_SubscCreate(pxAppData, IFX_SIP_SUBSC_MSGWAIT,
       &pxAppData->auiHdl[IFX_SIPAPP_UA_MWI]) != IFX_SIP_SUCCESS)
  {
    return IFX_SIP_FAILURE;
  }

  if(IFX_SIP_SubscSetAutoRefresh(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI], 5, 1)
       == IFX_SIP_FAILURE)
  {
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_FAILURE;
  }

  return IFX_SIPAPP_ReSubcMWIHndlr(pxAppData);
}

/******************************************************************
*  Function Name    :  IFX_SIP_UnSubscribeForMWI
*  Description      :  This function send message to
*                      terminate the subscription for Voicemail.
*  Input Values     :
*  Output Values    :
*  Return Value     :  IFX_SIP_SUCCESS, IFX_SIP_FAILURE
*  Notes            :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_UnSubscribeForMWI(IN uint32 uiConnId,
                             IN void *pvAppData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData = (x_IFX_SIPAPP_UAAppData*) pvAppData;
  uint32 uiDlgList=0, uiDlgHdl=0;
  e_IFX_SIP_Ecode eEcode;

  if(pxAppData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  if(pxAppData->iConnId != uiConnId)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " ConnId mismatch!");
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_FAILURE;
  }

  pxAppData->uiVMExpires = 0;

  /* Unsubscribe to all branches of the subscription */
  IFX_SIP_SubscGetDlg(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI], &uiDlgList);
  IFX_SIP_DLG_GetDialogFromList(uiDlgList, &uiDlgHdl, &eEcode);
  while(uiDlgHdl)
  {
    if(IFX_SIP_SubscUnSubsc(pxAppData->auiHdl[IFX_SIPAPP_UA_MWI],
                              uiDlgHdl, 0) == IFX_SIP_FAILURE)
    {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                 "Could not UNSUBSCRIBE to VMS");
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    }
    IFX_SIP_DLG_GetDialogFromList(uiDlgList, &uiDlgHdl, &eEcode);
  }
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_GetTokenValue
* Description      : This function interprets the Notify body
*                  
* Input Values     :
* Output Values    :
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
char8*
IFX_SIPAPP_GetTokenValue(IN_OUT char8 **ptr,
						 IN_OUT char8 **token, 
						 IN_OUT char8 **value)
{
	static char8 buff[512];
	int i=0;
	*value=buff;
#ifdef __LINUX__
 	*token=strtok_r(*ptr,":",ptr);
#else
	*token = *ptr;
#endif
	if(*token == NULL)
	{
			return NULL;
	}
	while(**ptr != '\n' && **ptr !='\0')
	{
	 if(**ptr != ' ')
	 {
			*(*value+i)=**ptr;
			i++;
	 }	
	 *ptr=*ptr+1;
	}
	if(**ptr == '\0')
	{
		return NULL;
	}
	
	*ptr=*ptr+1;
	*(*value+i)='\0';
	return *ptr;
}
	
/************************************************************************
* Function Name    : IFX_SIPAPP_GetVMNotifyInfo
* Description      : This function interprets the Notify body
*                  
* Input Values     :
* Output Values    :
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_GetVMNotifyInfo(IN x_IFX_SIPAPP_VMNotifyRecvd* pxVMNotifyRecvd,
													 IN uint32 uiMsgHdl)
{
 char8 *pcBody=NULL;				
 
 if((uiMsgHdl) && ((pcBody = IFX_SIP_GetMsgBody(uiMsgHdl)) != NULL))
 {
	char *token,*value;
	int newmsg=0,oldmsg=0,newurg=0,oldurg=0;
	
	while(IFX_SIPAPP_GetTokenValue(&pcBody,&token,&value)!=NULL)
	{
		if(strncasecmp(token,"Messages-Waiting",16)==0)
		{
		 if(strncasecmp(value,"yes",3)==0)		
			 pxVMNotifyRecvd->bNewMsg = IFX_TRUE;
		 
		 else
			 pxVMNotifyRecvd->bNewMsg = IFX_FALSE;
		}				 
		
		if(strncasecmp(token,"Voice-Message",13)==0)
	  {
			sscanf(value,"%d/%d(%d/%d)",&newmsg,&oldmsg,&newurg,&oldurg);
			pxVMNotifyRecvd->unNumOfUnread=newmsg;
			pxVMNotifyRecvd->unTotalMsg=oldmsg+newmsg;
		}	  
	}
	return IFX_SIP_SUCCESS;
 }
 IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Failed");
 return IFX_SIP_FAILURE;
}

			
/************************************************************************
* Function Name    : IFX_SIPAPP_MWI_PkgRecvNotify
* Description      : This function handles the notify request specific
*                    to MWI event package
* Input Values     :
* Output Values    :
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_MWI_PkgRecvNotify(IN uint32 uiMsgHdl,
                             IN uint32 uiSubcsHdl,
                             IN uint32 uiDialogHdl,
                             IN_OUT void **ppvUserData)
{
  uint32 uiHdrHdl=0;
  e_IFX_SIP_Ecode eEcode;
  x_IFX_SIPAPP_UAAppData *pxAppData;
  x_IFX_SIPAPP_VMNotifyRecvd xVMNotifyRecvd={0};
	uchar8 ucUnSolicited = IFX_FALSE;
	uint16 unRespCode =200;
	e_IFX_SIP_SUBSC_STATE eSubscStatus;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Received Notify Request");
  if(ppvUserData == NULL)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " No AppData To Handle!");
    return IFX_SIP_FAILURE;
  }

  /* Check for (and handle) unsolicited NOTIFY */
  if(*ppvUserData == NULL)
  {
    if(IFX_SIPAPP_CreateNAddAppData(&pxAppData, &eEcode) != IFX_SIP_SUCCESS)
    {
      return IFX_SIP_FAILURE;
    }
    pxAppData->auiHdl[IFX_SIPAPP_UA_MWI] = uiSubcsHdl;
    *ppvUserData = (void *) pxAppData;
    IFX_SIPAPP_CopyCalledAddr(uiMsgHdl, &pxAppData->xFrom);
    IFX_SIPAPP_CopyToAddr(uiMsgHdl, &pxAppData->xTo);
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"UnSolicited Notify");
		ucUnSolicited = IFX_TRUE;								
  }
  else
  {
    pxAppData = (x_IFX_SIPAPP_UAAppData *) *ppvUserData;
  }

	IFX_SIPAPP_GetVMNotifyInfo(&xVMNotifyRecvd,uiMsgHdl);
	xVMNotifyRecvd.pxTo = &pxAppData->xTo;
	xVMNotifyRecvd.pxFrom = &pxAppData->xFrom;	
  xVMNotifyRecvd.pvAppData = (void *) pxAppData;

  if(IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_SUBSCRIPTION_STATE, 1,
       &uiHdrHdl) != IFX_SIP_FAILURE)
  {
    xVMNotifyRecvd.uiExpires = IFX_SIP_SubState_GetExpires(uiHdrHdl);
  }
	
	else
  {
	 xVMNotifyRecvd.uiExpires = 0;
	}
  
  switch(eSubscStatus = IFX_SIP_SubscGetState(uiSubcsHdl, uiDialogHdl))
  {
    case IFX_SIP_SUBSC_ACTIVE:
    case IFX_SIP_SUBSC_PENDING:
      xVMNotifyRecvd.eSubscStatus = IFX_ON;
    break;
    
		case IFX_SIP_SUBSC_TERMINATED:
      xVMNotifyRecvd.eSubscStatus = IFX_OFF;
      xVMNotifyRecvd.eReason = IFX_TERMINATED;
			xVMNotifyRecvd.uiExpires = 0;
    break;
    
		default:
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Handleing Default Subc Event = %d",
							  IFX_SIP_SubscGetState(uiSubcsHdl, uiDialogHdl));
     return IFX_SIP_FAILURE;
  }  
	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,"Subsc Status =",
           eSubscStatus);
  
  if((vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_NOTIFY_RECV,
      &xVMNotifyRecvd)==IFX_SIP_FAILURE) && ucUnSolicited==IFX_TRUE)
	{
		unRespCode = 403;
	}  
	IFX_SIP_NotifyRespond(uiSubcsHdl, uiDialogHdl, 0, unRespCode, 0);
  if(xVMNotifyRecvd.eSubscStatus == IFX_OFF)
  {
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_SUCCESS;
  }

  return IFX_SIP_SUCCESS;
}

/***********************************************************************
* Function Name : IFX_SIPAPP_3xxSubscCBHdlr
* Description   : This function is called when 3xx for Subsc is received
* Input Values  :
* Return Value  : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Output Values : None
************************************************************************/

static e_IFX_SIP_Return
IFX_SIPAPP_3xxSubscHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                        IN uint32 uiMsgHdl,
                        IN uint32 uiDlgHdl)
{
  uint32 uiContactHdl;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus={0};
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Subscribe 3xx Response received");

  if(IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_CONTACT, 1, &uiContactHdl) ==
       IFX_SIP_FAILURE)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " Getting Contact header failed");
    return IFX_SIP_FAILURE;
  }

  /* If invalid 3xx response and Contact is not present return a failure */
  if((iRespCode != 302) && (iRespCode != 301) && (iRespCode != 305))
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Subscribe 3xx invalid request");
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_300_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_SUBSC_STATUS_RECV,
      &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_FAILURE;
  }

  /* handle the redirection */
  IFX_SIPAPP_CopyContactAddr(uiMsgHdl, &pxAppData->xTo);
  if(IFX_SIPAPP_ReSubcMWIHndlr(pxAppData) != IFX_SIP_SUCCESS)
  {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Subscribe 3xx Request construction Fail");
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_300_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_SUBSC_STATUS_RECV,
      &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/***********************************************************************
* Function Name : IFX_SIPAPP_4xxSubscHdlr
* Description   : This function is called when 4xx for Subsc is received
* Input Values  :
* Return Value  : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Output Values : None
************************************************************************/

static e_IFX_SIP_Return
IFX_SIPAPP_4xxSubscHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                        IN uint32 uiMsgHdl,
                        IN uint32 uiDlgHdl)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  int32 iRespCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
	uint32 iAuthHdl = 0;
  char8 *pcRealm = NULL;
  char8 acRealm[IFX_SIPAPP_MAX_TOKEN] = "";
  x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus={0};
  x_IFX_SIPAPP_AuthReqd xAuthReqd;

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Subscribe 4xx Response received");

  /* The assignment below handles the case where iRespCode is neither
     401 nor 407. */
  eRetVal = IFX_SIP_FAILURE;
  if(iRespCode == 401)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_WWW_AUTHENTICATE,
                1, &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "Subscribe 4xx Response has no www Auth header");
      xSubscStatus.eSubscStatus = IFX_OFF;
      xSubscStatus.eReason = IFX_400_RESP;
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
        IFX_MWI_SUBSC_STATUS_RECV, &xSubscStatus);
      return eRetVal;
    }
  }
  else if(iRespCode == 407)
  {
    eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_PROXY_AUTHENTICATE,
                1, &iAuthHdl);
    if(eRetVal == IFX_SIP_FAILURE)
    {
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "Subscribe 4xx Response has no www Auth header");
      xSubscStatus.eSubscStatus = IFX_OFF;
      xSubscStatus.eReason = IFX_400_RESP;
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
        IFX_MWI_SUBSC_STATUS_RECV, &xSubscStatus);
      return eRetVal;
    }
  }
  else if(iRespCode == 423)
  {
    uint32 uiMinExpHdl;
    if(IFX_SIP_GetHeaderByType(uiMsgHdl, IFX_SIP_MIN_EXPIRES, 1, &uiMinExpHdl)
         == IFX_SIP_SUCCESS)
    {
      pxAppData->uiVMExpires = IFX_SIP_MinExpires_GetValue(uiMinExpHdl);
      /* The call below is only to handle a 423 response, hence it reuses all
      * information, already known for this subscription (in pxAppData),
      * however, as mandated, it creates a new transaction for the
      * subscription */
      eRetVal = IFX_SIPAPP_SubscribeForMWI(0, 0, 0, NULL, (void*)&pxAppData);
      if(eRetVal == IFX_SIP_SUCCESS)
      {
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
          " ReSubsc sent with (MinExpire)");
        return eRetVal;
      }
    }
  }

  if(eRetVal == IFX_SIP_FAILURE)
  {
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_400_RESP;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,
    IFX_MWI_SUBSC_STATUS_RECV, &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    return IFX_SIP_FAILURE;
  }

  /* Get the necessary information to search for proper credentials */
  pcRealm = IFX_SIP_Authentication_GetRealm(iAuthHdl);
	if(pcRealm==NULL){
		/* No realm in the Proxy/WWW-Authenticate header */
    return IFX_SIP_FAILURE;
	}
  /* Since the Realm will contain Quotes, this logic is to remove the Quotes*/
  strncpy(acRealm, pcRealm + 1, strlen(pcRealm) - 2);

  xAuthReqd.uiHdl = pxAppData->auiHdl[IFX_SIPAPP_UA_MWI];
  xAuthReqd.uiDlgHdl = uiDlgHdl;
  xAuthReqd.pcRealm = acRealm;
  xAuthReqd.uiSipMsgHdl = 0;
  xAuthReqd.pvPvtData = &xAuthReqd;

  /* This callback should ensure that Authentication with credentials happens */
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_AUTH_REQD,
    &xAuthReqd);

  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIP_MWI_PkgRecvSubscRsp
* Description      : This function handles the subscribe requests response
*                    for MWI event package
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS,IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_MWI_PkgRecvSubscRsp(IN uint32 uiMsgHdl,
                               IN uint32 uiSubcsInfo,
                               IN uint32 uiDlgHdl,
                               IN void *pvUserData)
{
  int16 nStatusCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *)pvUserData;

  if((nStatusCode >= 200) && (nStatusCode < 300))
  {
    /*2xx Handler*/
    x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus={0};

    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               " SUB status 2xx rcvd");

    /* Default values */
    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_200_RESP;
    IFX_SIPAPP_GetExpires(uiMsgHdl, &pxAppData->uiVMExpires);
    if(pxAppData->uiVMExpires)
    {
      xSubscStatus.eSubscStatus = IFX_ON;
      xSubscStatus.uiExpires = pxAppData->uiVMExpires;
    }

    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_SUBSC_STATUS_RECV,
      &xSubscStatus);
#if 0 
    /* Should  be removed after getting Notify with state terminated */		
    if(xSubscStatus.eSubscStatus == IFX_OFF)
    {
      IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    }
#endif		
    eRetVal = IFX_SIP_SUCCESS;
  }
  else if((nStatusCode >= 300) && (nStatusCode < 400))
  {
    eRetVal = IFX_SIPAPP_3xxSubscHdlr(pxAppData, uiMsgHdl, uiDlgHdl);
  }
  else if((nStatusCode >= 400) && (nStatusCode < 500))
  {
    eRetVal = IFX_SIPAPP_4xxSubscHdlr(pxAppData, uiMsgHdl, uiDlgHdl);
  }
  else
  {
    x_IFX_SIPAPP_SubscNotifyStatus xSubscStatus={0};

    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "subscription status OFF recived 56xx");

    xSubscStatus.eSubscStatus = IFX_OFF;
    xSubscStatus.eReason = IFX_TERMINATED;
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_SUBSC_STATUS_RECV,
      &xSubscStatus);
    IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
    eRetVal = IFX_SIP_FAILURE;
  }

  return eRetVal;
}

/************************************************************************
* Function Name    : IFX_SIP_MWI_PkgRecvTimeOut
* Description      : This function will handle the transaction timeout while
*                    sending subscribe requests
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_MWI_PkgRecvTimeOut(IN e_IFX_SIP_TransErrorCode eErrorType,
                              IN uint32 uiSubscHdl,
                              IN uint32 uiDialogHdl,
                              IN void *pvUserData)
{
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *)pvUserData;
  x_IFX_SIPAPP_SubscNotifyStatus xSubscNotifyStatus={0};

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Received Timeout");

  /* If subscription has failed try again unless user has previously 
     requested an unsubscribe */

  if((eErrorType == IFX_SIP_SUBSCRIBER_TIMEOUT) && (pxAppData->uiVMExpires) &&
			(pxAppData->unVMSubscAttempts < 2))
  {
	  pxAppData->unVMSubscAttempts++;
    return IFX_SIPAPP_ReSubcMWIHndlr(pxAppData);
  }
  
  /* Inform user that the subscription has expired due to a timeout */
  xSubscNotifyStatus.eSubscStatus = IFX_OFF;
  xSubscNotifyStatus.eReason = IFX_TIMEOUT;
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_MWI_SUBSC_STATUS_RECV,
    &xSubscNotifyStatus);
  IFX_SIPAPP_RemoveAppData(pxAppData, IFX_SIPAPP_UA_MWI);
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIP_MWI_PkgEncode
* Description      : This function will add any headers/parameters to the
*                    outgoing message.
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
**************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_MWI_PkgEncode(IN uint32 uiSipMsgHdl,
                         IN uint32 uiSubscHdl,
                         IN uint32 uiDlgHdl,
                         IN void *pvUserData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIPAPP_UAAppData *pxAppData= (x_IFX_SIPAPP_UAAppData *)pvUserData;
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN];

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Entering IFX_SIPAPP_MWI_PkgEncode");

  IFX_SIPAPP_ConvUsrCfgToStr(&pxAppData->xTo, acFrom);
  eRetVal = IFX_SIPAPP_SetContact(acFrom, uiSipMsgHdl,
                                  pxAppData->iProfileId); 
	if(eRetVal== IFX_SIP_FAILURE)
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
               "Seting Contact Failed");
    return IFX_SIP_FAILURE;
  }
#ifdef STUN_SUPPORT
  IFX_SIPAPP_AddViaIfSTUNOn(uiSipMsgHdl, 1);
#endif

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
           "Leaving IFX_SIPAPP_MWI_PkgEncode");
  return IFX_SIP_SUCCESS;
}

/************************************************************************
* Function Name    : IFX_SIPAPP_SetAuthInfoMWI
* Description      : This function will set authentication data for MWI
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetAuthInfoMWI(IN uint32 uiConnId,
                          IN char8 *pcUserName,
                          IN char8 *pcPasswd,
                          IN void *pvAppData)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_FAILURE;
  x_IFX_SIPAPP_AuthReqd *pxAuthReqd = (x_IFX_SIPAPP_AuthReqd *) pvAppData;

  if(pxAuthReqd)
  {
    eRetVal = IFX_SIP_SubscAuthorize(pxAuthReqd->uiHdl, pxAuthReqd->uiDlgHdl,
                pcUserName, pcPasswd, pxAuthReqd->uiSipMsgHdl);
  }
  else
  {
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             " No AppData To Handle ");
  }
  return eRetVal;
}
/************************************************************************
* Function Name    : IFX_SIP_MWIPkgInit
* Description      : This function will initialize the callbacks for MWI
* Input Values     :
* Output Values    : NONE
* Return Value     : IFX_SIP_SUCCESS, IFX_SIP_FAILURE
* Notes            :
* *************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_MWIPkgInit(uint32 uiStackHdl)
{
  x_IFX_SIP_SubscCallBks xCallBks = {0};
  xCallBks.pfnNotifyReqArrived = IFX_SIPAPP_MWI_PkgRecvNotify;
  xCallBks.pfnTimeOutOrError = IFX_SIPAPP_MWI_PkgRecvTimeOut;
  xCallBks.pfnMsgToEncode = IFX_SIPAPP_MWI_PkgEncode;
  xCallBks.pfnSubscRespArrived = IFX_SIPAPP_MWI_PkgRecvSubscRsp;
	xCallBks.uiStackHdl =uiStackHdl;
  return  IFX_SIP_SubscRegisterCallBks(IFX_SIP_SUBSC_MSGWAIT, 120,
            10, &xCallBks);
}
# if 0

	//Function Entry info
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,__FILE__);

	//String Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "The string goes here");
	//Integer Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Info goes here",integer goes here);
	//String Normal
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "Info Goes here",String goes here);

	//String Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "The string goes here");
	//Integer Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_INT_INFO,
             "Info goes here",integer goes here);

	//String Error
	IFX_DBGA(vxCmgrInfo.ucDebugId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
                 "Info Goes here",String goes here);

# endif
