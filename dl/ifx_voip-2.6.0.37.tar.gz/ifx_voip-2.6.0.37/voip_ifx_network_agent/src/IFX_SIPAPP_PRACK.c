/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_PRACK.c
**   PROJECT       : SIP
**   MODULES       : User Agent
**   SRC VERSION   : V2.0
**   DATE          : 15-03-2006
**   AUTHOR        : 
**   DESCRIPTION   : This file contains functions required for PRACK method.
**   COMPILER      : gcc
**   REFERENCE     :
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifdef RFC_3262

#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"

#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SDP_GetSet.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_CCApi.h"

#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_PRACK.h"
#include "ifx_list.h"



extern uchar8 vcSipAppModId;

/****************************************************************************
   Function Name  : IFX_SIP_1xxRelConst
*  Description    : This function applies rules specific to construction
                    of 1xx responses.*                  
*  Input Values   : uiMsgHdl, pxAppData, peEcode.
*  Output Values  : peEcode...pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*                     IFX_SIP_FAILURE
*  Notes          :
***************************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_1xxRelConst(IN uint32 uiMsgHdl,
                    IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;

  /*IF OpenSdp() is called in 183relConst then only call send SDP*/
  if(pxAppData->iFlag & IFX_SIPAPP_DELAY_2XX){  
    pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_SESSIONVER;  
    if((pxAppData->iFlag& IFX_SIPAPP_SDP_PRESENT) &&
       (pxAppData->xSdpInfo.eDir == IFX_SIPAPP_SENDRECV)){
      /* Application will be able to decide -- whether 1xxRel 
        should carry answer */
      if(IFX_SIPAPP_AnswerSdp(uiMsgHdl,&pxAppData->xSdpInfo,peEcode) == 
            IFX_SIP_FAILURE){
        //IFX_SIP_FreeMsg(uiMsgHdl);		  
        return IFX_SIP_FAILURE;
      }          
    }
  }

  /*Invite doe not contain offer --- Send offer in 183 */
				
  if(pxAppData->iFlag& IFX_SIPAPP_SDP_PRESENT){
	#if 0
    /* offer has to be made in the 1xx response */
    if(IFX_SIPAPP_AnswerSdpInactive(uiMsgHdl,&pxAppData->xSdpInfo,
                   peEcode) == IFX_SIP_FAILURE){
        //IFX_SIP_FreeMsg(uiMsgHdl);		  
        return IFX_SIP_FAILURE;
    }  
#endif		
  }
  else{
    /* construct SDP info */
    eRetVal = IFX_SIPAPP_OfferSdp(uiMsgHdl,&(pxAppData->xSdpInfo),peEcode);
    if(eRetVal == IFX_SIP_FAILURE){
	  //IFX_SIP_FreeMsg(uiMsgHdl);		  
      return eRetVal;
    }     
  }

  IFX_DBGA(vcSipAppModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<1xxrelConst>Calling SetRequire Header"); 
  eRetVal = IFX_SIPAPP_SetRequire(uiMsgHdl);     
  if(eRetVal != IFX_SIP_SUCCESS){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<1xxRelConst>Error in SetRequire fucntion");
    return eRetVal;
  } 
  return IFX_SIP_SUCCESS;
}

/******************************************************************************
*  Fucntion Name  : IFX_SIP_101t0199Handler -- Invoked by 1xxinProceeding
*  Input Values   : pxAppData,uiMsgHdl
*  Output Values  :
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_101to199Handler(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                        IN uint32 uiMsgHdl)
{  
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  int16 nStatCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);

  /* 1. Check if Require:100rel and Rseq header field is present */
  eRetVal = IFX_SIP_Response_IsReliable(uiMsgHdl);
  if(eRetVal == IFX_SIP_SUCCESS){
		pxAppData->iFlag |= IFX_SIPAPP_PRACK_SUPPORT;
	}	
  if(pxAppData->iFlag & IFX_SIPAPP_PRACK_SUPPORT){
    eRetVal = IFX_SIP_CC_SendRequest(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     0,0, "PRACK");
    if(eRetVal!= IFX_SIP_SUCCESS){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<101to199Handler>Sending PRACK Failed");
      return eRetVal;
    }
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<101to199Handler>PRACK Sent Successfully");
  }

  /* 2. Copy SDP Info if present in 1xx messgae */       
  if(IFX_SIP_GetMsgBody(uiMsgHdl) != NULL){
#ifdef RFC_3311
    /* ReSet  The OFFER Send Flag */
    pxAppData->iUpdateFlag &= ~IFX_SIPAPP_OFFER_SENT;
#endif
    /* Store SDP */
    eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,&pxAppData->xSdpInfo,&eEcode);
    if(eRetVal == IFX_SIP_FAILURE){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_SIP_SEND_ERR,
               "Handle183Invite : Store SDP error", eRetVal);
      return IFX_SIP_FAILURE;
    }
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
  }
  /* 3. Check the response type and post message to PA */ 
  if(nStatCode == 182){
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_CALL_QUEUE,NULL);
  }
  else if(nStatCode == 183){     
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_CALLPROG_SIGNAL,NULL);
  }
  else{ 
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_ALERT_SIGNAL, NULL);
    pxAppData->iFlag |= IFX_SIPAPP_ISSUE_RINGCMD_FLAG; 
  }
  return IFX_SIP_SUCCESS;     
}
/******************************************************************************
*  Fucntion Name  : IFX_SIPAPP_PRACKConst
*  Description    : This function constructs PRACK message
*  Input Values   : pxAppData, uiMsgHdl
*  Output Values  : peEcode
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :  
********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_PRACKConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                   OUT uint32 uiMsgHdl,
                   OUT e_IFX_SIP_Ecode* peEcode)
{
  /*Calling Set Contact */
  char8 acFrom[256];
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
  if(IFX_SIPAPP_SetContact(acFrom,uiMsgHdl,pxAppData->iProfileId) ==
      IFX_SIP_FAILURE) {
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    //IFX_SIP_FreeMsg(uiMsgHdl);
    return IFX_SIP_FAILURE;
  }   
  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<PRACKConst>Retruning from PRACK");   
  return IFX_SIP_SUCCESS; 
} 
/******************************************************************************
   Fucntion Name  : IFX_SIPAPP_FinalPRACKHandling
   Description    : This function applies rules once matching for matching PRACK
*  Input Values   : pxAppData,uimsgHdl
*  Output Values  :
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_FinalPRACKHandling(IN x_IFX_SIPAPP_UAAppData *pxAppData)
{
  e_IFX_SIP_Return eRetVal= IFX_SIP_SUCCESS;

  IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<FinalPRACKHandling>Inside this funciton");
  pxAppData->iFlag &= ~IFX_SIPAPP_PRACK_PENDING;
	

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<FinalPRACKHandling>PRACK Pending flag is cleared");
  eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                    0,200,"OK",0,"PRACK");
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<FinalPRACKHandling>200 for PRACK sent");
  if(pxAppData->iFlag & IFX_SIPAPP_2XX_PENDING){
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<FinalPRACKHandling>Calling Connect in proceeding");
    IFX_SIP_CC_AnswerCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);   
  }
  return eRetVal;
}

/************************************************************************
*  Function Name  : SetRequrie 
*  Description    : This function applies rules once matching PRACK is found.
                    in Setup state
*  Input Values   : uiMsgHdl
*  Output Values  :
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          :
**************************************************************************/
e_IFX_SIP_Return
IFX_SIPAPP_SetRequire(OUT uint32 uiMsgHdl)
{
  uint32 uiHdrHdl;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;

  eRetVal = IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_REQUIRE,&uiHdrHdl);
  if(eRetVal != IFX_SIP_SUCCESS){
    return eRetVal;
  }
  eRetVal = IFX_SIP_SetOptionTag(uiHdrHdl,"100rel");
  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIPAPP_HandlePrack
*  Description    : This function processes the PRACK request
*  Input Values   : pxAppData - Application Data 
*           	    uiMsgHdl - Incoming SIP message Handle
*  Output Values  : peEcode....pointer to error code
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_HandlePrack(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                       IN uint32 uiMsgHdl,
                       OUT e_IFX_SIP_Ecode* peEcode)
{
  char8 *pcBody;
  uint32 uiMediaDescHdl=0;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  pcBody = IFX_SIP_GetMsgBody(uiMsgHdl);
	if(pcBody != NULL){
    if(pxAppData->xSdpInfo.uiSdpMsgHdl){
	    IFX_SDP_FreeMsg(pxAppData->xSdpInfo.uiSdpMsgHdl);		
		  pxAppData->xSdpInfo.uiSdpMsgHdl = 0;	
		}
    if(IFX_SDP_FAILURE == IFX_SDP_CreateMsg(&pxAppData->xSdpInfo.uiSdpMsgHdl)) {
      return IFX_SIP_FAILURE;
    }
    eRetVal = IFX_SDP_DecodeMessage(pcBody,pcBody+strlen(pcBody),
                                    pxAppData->xSdpInfo.uiSdpMsgHdl,peEcode);
    if(eRetVal == IFX_SIP_FAILURE) {
	    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Deconding SDP Failed");
      eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                       0,400,"Invalid SDP",0,"PRACK");
      IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
                            488,"Not Acceptable"); 
      return IFX_SIP_FAILURE;
    }
	}

  /* Get Media Desc Handle */
  IFX_SDP_GetHeaderByType(pxAppData->xSdpInfo.uiSdpMsgHdl,IFX_SDP_MEDIA_DESC,1,
                          &uiMediaDescHdl); 
  /*If PRACK does not have SDP info */
  if(pxAppData->xSdpInfo.ucNumRemCap == 0){
   if((pcBody == NULL) || (uiMediaDescHdl == 0)){
     /*Invite did not contain offer*/
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<PRACKinProceeding>PRACK does not have answer--Sending 488->PRACK and 500->INVITE");
     eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                       0,488,"Not Acceptable",0,"PRACK");
     IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
                                500,"Internal Error"); 
     vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL, NULL);
     pxAppData->iRtpParamModified = 0;
     pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
     IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
   }
   else{
	 #ifdef RFC_3311
       /* set The Offer Recv Flag */
       pxAppData->iUpdateFlag |= IFX_SIPAPP_OFFER_RECV;
     #endif
     /*PRACK contains answer*/
     IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<PRACKinProceeding>PRACK contains answer");
     eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,&pxAppData->xSdpInfo,peEcode);
     if(eRetVal == IFX_SIP_FAILURE){
       IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_SIP_SEND_ERR,
               "PRACKinProceeding: Store SDP error", eRetVal);
       return IFX_SIP_FAILURE;
     }
     /* Offer was made in 183, so set mode and Locked entry */
     IFX_SIPAPP_GetLockedCodecEntry(&pxAppData->xSdpInfo.nLockedCodecEntry,
                                 &pxAppData->xSdpInfo);
     if(pxAppData->xSdpInfo.nLockedCodecEntry == -1){

	   eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                         0,488,"Not Acceptable",0,"PRACK");
       IFX_SIP_CC_RejectCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0,
                             488,"Not Acceptable"); 
       vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                     NULL);
       return eRetVal;
     }
     pxAppData->xSdpInfo.eLocalMode = IFX_SIPAPP_GetLocalMode(pxAppData->
                     xSdpInfo.eLocalMode,pxAppData->xSdpInfo.
                     xRemCap[pxAppData->xSdpInfo.nLockedCodecEntry].eMode);
		 
     IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
		 
		 vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_SDP_ANSWER,pxAppData);
   }

   return IFX_SIP_SUCCESS;
  }
  /*COPY OFFER-- CALL ModifyRTP()  */
  if(pxAppData->xSdpInfo.ucNumRemCap != 0){
    if(!(pcBody == NULL) && !(pxAppData->iFlag & IFX_SIPAPP_DELAY_2XX)){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<PRACKinProceeding>PRACK contain SDP as we have not answerd INVITE in 1XX-- sending 488 for PRACK");
      eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                       0,488,"Not Acceptable",0,"PRACK");
			return IFX_SIP_SUCCESS;
    }
    if((pcBody == NULL) || (uiMediaDescHdl == 0)){
      pxAppData->iFlag &= ~IFX_SIPAPP_2XX_ANSWER;
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<PRACKinProceeding> PRACK does not contain new offer");
      eRetVal = IFX_SIPAPP_FinalPRACKHandling(pxAppData);
      return eRetVal;
    }
    else if(pxAppData->xSdpInfo.uiSdpMsgHdl != 0){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<PRACKinProceeding> PRACK contains new offer");
      /*Set 2XX_ANSWER flag to send answer in 200 of PRACK */
      pxAppData->iFlag |= IFX_SIPAPP_2XX_ANSWER;
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<HandleInvite>Before Store SDP");
      /* check whether the offer is acceptable or not */
      eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,&pxAppData->xSdpInfo,peEcode);
      if(eRetVal == IFX_SIP_SUCCESS) {

        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<PRACKinProceeding>Store Copy SDP Success");
        /* SDP answer needs to sent in the 2xx response */
        pxAppData->iFlag |= IFX_SIPAPP_SDP_PRESENT;
      }
      else{
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<PRACKinProceeding> Store SDP Failed");
        eRetVal = IFX_SIP_CC_SendResponse(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                       0,488,"Not Acceptable",0,"PRACK");
        *peEcode = IFX_SIP_RESPONSE_SENT;
        return IFX_SIP_FAILURE; /* SDP not acceptable */
      }
    }
  }
  IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);  
  return IFX_SIP_SUCCESS;
}

#endif /*RFC_3262*/
