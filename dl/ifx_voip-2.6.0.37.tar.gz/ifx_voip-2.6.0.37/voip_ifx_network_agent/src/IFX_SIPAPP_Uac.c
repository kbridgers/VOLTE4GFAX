/**************************************************************************
**   FILE NAME     : IFX_SIPAPP_Uac.c
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE     	   : 11-02-2003
**   AUTHOR        : Narendra VP
**   DESCRIPTION   : This file contains transaction user client functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS ,  DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/


#include "ifx_common_defs.h"
#include "IFX_SIP_Errors.h"
#include "IFX_SIP_Stack.h"
#include "IFX_SIP_DlgApi.h"

#include "IFX_SDP_GetSet.h"
#include "IFX_SDPAPP_ParsePredefAttr.h"
#include "IFX_SIPAPP_Negotiate.h"
#include "ifx_debug.h"
#include "IFX_SIPAPP_Platform.h"
#include "IFX_SIPAPP_Init.h"
#include "IFX_SIPAPP_App.h"
#include "IFX_SIPAPP_Transceiver.h"
#include "IFX_SIPAPP_Uac.h"
#include "IFX_SIP_MsgApi.h"
#include "IFX_SIP_CCApi.h"
#include "ifx_list.h"
#include "IFX_SIPAPP_CallIf.h"
#include "IFX_SIPAPP_Config.h"
#include "IFX_SIPAPP_CallBk.h"

#ifdef STUN_SUPPORT
#include "IFX_SIPAPP_Stun.h"
#endif
#ifdef INFO_SUPPORT
#include "IFX_SIPAPP_Info.h"
#endif
#ifdef RFC_3262 
#include "IFX_SIPAPP_PRACK.h"
#endif


#ifdef DMALLOC
#include <dmalloc.h>
#endif
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_SetNextHopAddr(IN void *pvPrivateData);
extern e_IFX_SIP_Return IFX_SIPAPP_MakeCall(IN x_IFX_SIPAPP_UAAppData *pxAppData);

/* global variables */
IFX_SIPAPP_HandleResponse pfnHandleResponse[] =
  {
    IFX_SIPAPP_Handle1XXResp, 
    IFX_SIPAPP_Handle2XXResp, 
    IFX_SIPAPP_Handle3XXResp,
    IFX_SIPAPP_Handle4XXResp, 
    IFX_SIPAPP_Handle5XXResp,
    IFX_SIPAPP_Handle6XXResp
  };

IFX_SIPAPP_SpecReqConst pfnSpecReqConst[] = 
{
  IFX_SIPAPP_InviteConst,	
  IFX_SIPAPP_ByeConst,	
  IFX_SIPAPP_AckConst,	
  IFX_SIPAPP_CancelConst,	
#ifdef RFC_3262  
  IFX_SIPAPP_PRACKConst,
#endif 
#ifdef RFC_3311
  IFX_SIPAPP_UpdateConst,
#endif 
#ifdef INFO_SUPPORT  
  IFX_SIPAPP_InfoConst,
#endif  
};

uint16 v_IFX_SIP_CodecType;
extern uchar8 vcSipAppModId;



/******************************************************************
*  Function Name  : IFX_SIP_InviteConst
*  Description    : this function adds specific information for
*             	    the invite request
*  Input Values   : pxAppData ........ pointer to the Application data
*  Output Values  : pxEncodedMsg...pointer to sip data structure which gets 
*                   encoded in the stack
*       	    peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_InviteConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    OUT uint32 uiMsgHdl,
                    OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiDlgHeadHdl=0;
  uint32 uiDialogHdl=0;
  uint32 uiHdrHdl;
  char8 acFrom[IFX_SIPAPP_MAX_TOKEN];
  /* add the allow header field depicting the methods supported */
  if (IFX_SIPAPP_SetAllow(uiMsgHdl) == IFX_SIP_FAILURE) {
    *peEcode = IFX_SIP_TU_MEMORY_ERROR;
    //IFX_SIP_FreeMsg(uiMsgHdl);
    return IFX_SIP_FAILURE;
  }

  if(pxAppData->iConnId2 != 0){
    x_IFX_SIPAPP_UAAppData *pxRepAppData=NULL;
    /*Locate the User Data */
    eRetVal = IFX_SIPAPP_GetAppData(pxAppData->iConnId2,&pxRepAppData);
    if(eRetVal != IFX_SIP_FAILURE){
      if(pxRepAppData->szCallId[0] != '\0'){
        /* Set the replaces header */
        IFX_SIP_SetHeaderByType(uiMsgHdl,IFX_SIP_REPLACES,&uiHdrHdl);
        IFX_SIP_Replaces_SetCallId(uiHdrHdl,pxRepAppData->szCallId);
        IFX_SIP_Replaces_SetTagParam(uiHdrHdl,pxRepAppData->szRemoteTag,"to-tag");
        IFX_SIP_Replaces_SetTagParam(uiHdrHdl,pxRepAppData->szLocalTag,"from-tag");
      }
      else{
        /* This replaces information has not come from Refer */
        IFX_SIPAPP_SetReplaces(uiMsgHdl,pxRepAppData->uiDlgIdHdl); 
      }  
    }
  }

  eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
  if(eRetVal != IFX_SIP_SUCCESS){  
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Dialog head is null");
    return eRetVal;
  } 
  eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDialogHdl, peEcode);
  if(eRetVal != IFX_SIP_SUCCESS){  
    pxAppData->xSdpInfo.iFlag |= IFX_SIPAPP_SDP_SESSIONVER;
  }
  else{
    pxAppData->xSdpInfo.iFlag &= ~IFX_SIPAPP_SDP_SESSIONVER;
  } 
  /* construct SDP info */
  eRetVal = IFX_SIPAPP_OfferSdp(uiMsgHdl, &pxAppData->xSdpInfo, peEcode);
  if (eRetVal == IFX_SIP_FAILURE) {
    //IFX_SIP_FreeMsg(uiMsgHdl);		  
    return eRetVal;
  }
  IFX_SIPAPP_ConvCalAddrToStr(&pxAppData->xFrom,acFrom);
  if(IFX_SIPAPP_SetContact(acFrom,uiMsgHdl,pxAppData->iProfileId) ==
      IFX_SIP_FAILURE) {
   // IFX_SIP_FreeMsg(uiMsgHdl);
    return IFX_SIP_FAILURE;
  }
  /* set content disposition */
  IFX_SIPAPP_SetContentDisposition(uiMsgHdl);

  /* set content type */
  IFX_SIPAPP_SetContentType("application","sdp",uiMsgHdl);

  /* Set the supported header */
  eRetVal =IFX_SIPAPP_SetSupported(uiMsgHdl);
#ifdef RFC_3311
  /* Set  The OFFER Send Flag */
   pxAppData->iUpdateFlag |= IFX_SIPAPP_OFFER_SENT;
#endif
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Invite Const Success");
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name  : IFX_SIP_AckConst
*  Description    : this function adds specific information for
*                   the ack request
*  Input Values   : pxAppData ........ pointer to the Application data 
*  Output Values  : pxEncodedMsg...pointer to sip data structure which gets 
*                   encoded in the stack       
*           	    peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_AckConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT uint32 uiMsgHdl,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIP_ByeConst
*  Description    : This function adds specific information for
*           	    the Bye request
*  Input Values   : pxAppData ........ pointer to the Application data
*  Output Values  : pxEncodedMsg...pointer to sip data structure which gets 
*                   encoded in the stack
*           	    peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes          :
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_ByeConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                 OUT uint32 uiMsgHdl,
                 OUT e_IFX_SIP_Ecode* peEcode)
{
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name  : IFX_SIP_CancelConst
*  Description    : This function adds specific information for
*             	    the Cancel request
*  Input Values   : pxAppData ........ pointer to the Application data
*  Output Values  : pxEncodedMsg...pointer to sip data structure which gets 
*                   encoded in the stack
*           	    peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes      	  : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_CancelConst(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                    OUT uint32 uiMsgHdl,
                    OUT e_IFX_SIP_Ecode* peEcode)
{
  return IFX_SIP_SUCCESS;
}

/***********************************************************************
* Function Name : IFX_SIP_183RespHdlr
* Description   : This is the function called to process the 183 response
* Input Values  : pxAppData ........ pointer to the Application data
*                 pSipMessage - pointer to the Decoded Data Structure
* Output Values : None
* Return Values : IFX_SIP_SUCCESS/IFX_SIP_FAILURE
* Notes         : 
* ************************************************************************/
e_IFX_SIP_Return 
IFX_SIPAPP_183RespHdlr(IN x_IFX_SIPAPP_UAAppData *pxAppData,
                    IN uint32 uiMsgHdl)
{
  e_IFX_SIP_Ecode eEcode = IFX_SIP_NO_ERROR;
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl =0;
  char8 *pcHdr=NULL;
  
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CONTENT_TYPE,1,&uiHdrHdl);
  if(eRetVal == IFX_SIP_FAILURE) {
    return eRetVal;
  }
  pcHdr =IFX_SIP_ContType_GetMSubType(uiHdrHdl);
  if(pcHdr == NULL) {
    return eRetVal;
  }
 
  if(!strcasecmp(pcHdr,"sdp")){
#ifdef RFC_3311
    /* ReSet  The OFFER Send Flag */
   pxAppData->iUpdateFlag &= ~IFX_SIPAPP_OFFER_SENT;
#endif
    /* Store SDP */   
    eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl, &pxAppData->xSdpInfo, &eEcode);
    if(eRetVal == IFX_SIP_FAILURE){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_SIP_SEND_ERR,
               "Handle183Invite : Store SDP error", eRetVal);
      return IFX_SIP_FAILURE;
    }
    pxAppData->xSdpInfo.nLockedCodecEntry=1;
    /* Based on the RTP received post a Modify connection */
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
  }
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "183 Const Success");
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIP_Handle1XXResp
*  Description    : this function handles 1xx responses
*  Input Values   : pxAppData ... pointer to the AppData
*                   uiMsgHdl -  Message Handle
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*            	    IFX_SIP_FAILURE
*  Notes      	  : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle1XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  int16 nStatCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  if(!(pxAppData->iFlag & IFX_SIPAPP_ISSUE_RINGCMD_FLAG)) {
    if (nStatCode == 100) {
      return eRetVal;
    }
#ifdef RFC_3262
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<1xxinProceeding> Calling 101to199Handler");
    eRetVal=IFX_SIPAPP_101to199Handler(pxAppData,uiMsgHdl);
    pxAppData->iFlag |= IFX_SIPAPP_ISSUE_RINGCMD_FLAG;
    return eRetVal;
#else
    if(nStatCode == 182) {
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_CALL_QUEUE,NULL);
    }
    else if(nStatCode == 183){
      /* Handle if 183 has SDP */
      eRetVal= IFX_SIPAPP_183RespHdlr(pxAppData,uiMsgHdl);
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_CALLPROG_SIGNAL,NULL);
    }
    else{      
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_ALERT_SIGNAL, NULL);
    }
    IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
             "Issued Ringback to Phone application");
    pxAppData->iFlag |= IFX_SIPAPP_ISSUE_RINGCMD_FLAG;
#endif
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  : IFX_SIP_Handle2XXResp
*  Description    : This function handles 2xx responses..for all
*             	    the request it had sent out.
*  Input Values   : pxAppData ... pointer to the AppData
*                   uiMsgHdl -  Message Handle
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*       	    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle2XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_BasicMethod eReqId;/* TODO: Use msg APIs */
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  uint32 uiHdrHdl=0;
  char8 *pcMethod=NULL;
  /* get the method */
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CSEQ,1,&uiHdrHdl);
  if (eRetVal == IFX_SIP_FAILURE) {
       //IFX_SIP_FreeMsg(uiMsgHdl);
       return eRetVal;
  }

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
           "IFX_SIPAPP_Handle2XXResp arrived and got Cseq hdl ");
  pcMethod = IFX_SIP_CSeq_GetMethod(uiHdrHdl);
  eReqId = IFX_SIP_GetMethodType(pcMethod); 
  if(eReqId == IFX_SIP_INVITE) {
#ifdef RFC_3311
  /* Clear The Offer  Send Flag */
  pxAppData->iUpdateFlag  &= ~IFX_SIPAPP_OFFER_SENT;
  if(!(pxAppData->iUpdateFlag & IFX_SIPAPP_UPDATE))
#endif
    eRetVal = IFX_SIPAPP_Handle2XXInvite(pxAppData, uiMsgHdl, peEcode);
    return eRetVal;
  }
#ifdef RFC_3311
 if(eReqId == IFX_SIP_UPDATE){
 IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "<SIPAPP UAC> 200 Resp Handling of Update ");
 
 /* Clear The Offer  Send Flag */
 pxAppData->iUpdateFlag  &= ~IFX_SIPAPP_OFFER_SENT;
 

 eRetVal = IFX_SIPAPP_Handle2XXInvite(pxAppData,uiMsgHdl,peEcode);

 /*Update with SDP transaction successfull */
 pxAppData->iUpdateFlag  |= IFX_SIPAPP_UPDATE;

 /*Clearing  SDP Flag for UPDATE */
 pxAppData->iUpdateFlag  &= ~IFX_SIPAPP_UPDATE_SDP_PRESENT;

 return eRetVal;
 }
#endif
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "2xx handling Success");
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIP_Handle2XXInvite
*  Description    : This function handles final response for the invite
*             	    request
*  Input Values   : pxAppData ... pointer to the AppData
*                   uiMsgHdl -  Message Handle
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*           	    IFX_SIP_FAILURE
*  Notes      	  : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle2XXInvite(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                        IN uint32 uiMsgHdl,
                        OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;


  eRetVal = IFX_SIPAPP_StoreSdp(uiMsgHdl,&pxAppData->xSdpInfo, peEcode);
  if(pxAppData->xSdpInfo.ucNumRemCap == 0){
	IFX_SIP_CC_ReleaseCall(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],0);
	return IFX_SIP_SUCCESS;
  }
  /* If outbound proxy set next hop address. This is done for ack
     to be sent to the proxy */
  IFX_SIPAPP_SetNextHopAddr(pxAppData);

  if(!(pxAppData->iFlag & (IFX_SIPAPP_LOCAL_HOLD|IFX_SIPAPP_LOCAL_RESUME|
       IFX_SIPAPP_REMOTE_RESUME_FLAG|IFX_SIPAPP_REMOTE_HOLD_FLAG |IFX_SIPAPP_MEDIA_UPDATE_SENT
#ifdef FAX_SUPPORT       
       |IFX_SIPAPP_FAX_TERMINATE
#endif       
       ))){
    pxAppData->xSdpInfo.nLockedCodecEntry=1;
    /* Inform the application that 200 has been received */
    vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_CONNECTED_SIGNAL, NULL);
    /* Based on the RTP received post a Modify connection */
    pxAppData->iRtpParamModified = 1;
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_MODIFY_CONNRES_EVENT);
  }
  else{

    /* If the Modify is already posted, it's re-transmitted 200 */
    if(pxAppData->iRtpParamModified != 0){
      /*Check this */
      pxAppData->xSdpInfo.nLockedCodecEntry=1;
      /*Post Modify Conn to RTP */
      IFX_SIPAPP_ModifyMedia(pxAppData);
    }

  }
  return eRetVal;
}
/******************************************************************
*  Function Name  : IFX_SIP_Handle3XXResp
*  Description    : this function handles 3xx responses..specifically
*      		    301 and 302 response
*  Input Values   : pxAppData ... pointer to the App Data
*           	    uiMsgHdl... Message Handle having 4xx information
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*      		    IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle3XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  int16 nStatCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "<Uac> Clear Trans Info - Before ");

  if((nStatCode != 302)&&(nStatCode != 301)&&(nStatCode != 305)){
    return IFX_SIP_FAILURE;		  
  }		  

  /* Close the RTP session */
  pxAppData->iRtpParamModified = 0;
  pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
  IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);

  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "<Uac> Copying called addr");
   /* Copy contact to called Addr */
  eRetVal = IFX_SIPAPP_CopyContactAddr(uiMsgHdl, &(pxAppData->xTo)); 
  if (eRetVal == IFX_SIP_FAILURE) {
      return eRetVal;
  }

  /* If User is waiting, Inform Application about the forwarded address*/
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_CALL_FWD_ADDR,
                  &(pxAppData->xTo));

  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIP_Handle4XXResp
*  Description    : this function handles 4xx responses..
*  Input Values   : pxAppData ... pointer to the App Data
*           	    uiMsgHdl... Message Handle having 4xx information
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*  	            IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle4XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode)
{
  e_IFX_SIP_Return eRetVal=IFX_SIP_SUCCESS;
  int16 nStatCode = IFX_SIP_Response_GetStatusCode(uiMsgHdl);
  e_IFX_SIP_BasicMethod eReqId;
  char8 *pcMethod=NULL;
	uint32 uiHdrHdl=0;
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CSEQ,1,&uiHdrHdl);
  if(eRetVal == IFX_SIP_FAILURE){
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
  }
  IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<SIPAPP_Handle4XX>");
  pcMethod = IFX_SIP_CSeq_GetMethod(uiHdrHdl);

  eReqId = IFX_SIP_GetMethodType(pcMethod);

 
  if((nStatCode == 401) || (nStatCode == 407)){
    /* Call Authenticate function */
    char8  *pcRealm=NULL,acRealm[128]={'\0'};
    uint32  uiAuthHdl;
	  x_IFX_SIPAPP_AuthReqd xAuthReqd={0};

    if(nStatCode == 401) {
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "401 response received");
      eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_WWW_AUTHENTICATE,
                                         1, &uiAuthHdl);
      if(eRetVal == IFX_SIP_FAILURE){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 "No www Auth header found");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
	       "407 response received");
      eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_PROXY_AUTHENTICATE,
                                        1, &uiAuthHdl);
      if(eRetVal == IFX_SIP_FAILURE){
        IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 "No Proxy-Authenticate  header found");
        return IFX_SIP_FAILURE;
      }
    }
    pcRealm = IFX_SIP_Authentication_GetRealm(uiAuthHdl);
		if(pcRealm == NULL){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "No Realm in Proxy/www-Authenticate  header");
        return IFX_SIP_FAILURE;
		}
    /* Since the Relm contain Quots, the below logic is to remove the Quots*/
    strncpy(acRealm,pcRealm+1,strlen(pcRealm)-2);
	  xAuthReqd.pcRealm=acRealm;
  	xAuthReqd.pvPvtData = pxAppData;
	  eRetVal = vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_CALL_AUTH_REQD, 
                                          &xAuthReqd);
    if(eRetVal == IFX_SIP_FAILURE){
      IFX_DBGC(vcSipAppModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "No matching AuthInfo found - releasing the Call");
			vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                                 (void *)IFX_400_RESP);
			return IFX_SIP_SUCCESS;
		}
   *peEcode = IFX_SIP_EVENT_HANDLED;
  }
#ifdef RFC_3311
 if(eReqId == IFX_SIP_UPDATE){
 	if(nStatCode == 491){
   STATIC int32 iCount =0;
   int32  iMaxUpdate =2;
   
   /* clear Offer Send Flag */
   pxAppData->iFlag &=~ IFX_SIPAPP_OFFER_SENT;

   if(iCount < iMaxUpdate){
   if(pxAppData->iUpdateTimer != 0 ){
      IFX_SIPAPP_StopTimer((uint16)pxAppData->uiUpdateTimerId);
     }
   // Reset the timer value as this is not a retransmission
   if(pxAppData->iFlag & IFX_SIPAPP_ORIGINATING ){
      pxAppData->iUpdateTimer = 500 ;
      }
   else{
      pxAppData->iUpdateTimer = 600 ;
      }

   iCount = iCount +1;
   IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "Timer Start For 491 for Update");  

   eRetVal = IFX_SIPAPP_StartTimer(pxAppData->iUpdateTimer,
                               (void *)IFX_SIPAPP_Handle491Update,
                               (void *)pxAppData,
                               (uint16 *)&pxAppData->uiUpdateTimerId,
                                peEcode);

   if(eRetVal == IFX_SIP_FAILURE){
     IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<Update> Timer Failed");
     eRetVal =  IFX_SIPAPP_CCAppTimeOutOrError(IFX_SIP_TU_TIMER_ERROR,
                                               0,0,(void *)pxAppData);
     return eRetVal;
     }
   return eRetVal;
    }
   else {
    IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<Update> 491 handled Twice already");
    eRetVal =  IFX_SIPAPP_CCAppTimeOutOrError(IFX_SIP_SERVER_ERR,
                                              0,0,(void *)pxAppData);

    return eRetVal;
     }
    }// end for 491 Handling

		else {
			/* Find Confimed Dialog	and Send BYE - as refresh failed */
			uint32 uiDlgHeadHdl = 0;
			eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],&uiDlgHeadHdl);
			if(IFX_SIP_SUCCESS == eRetVal) {
					uint32 uiDlgHdl=0;
					eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl,peEcode);
					if(IFX_SIP_SUCCESS == eRetVal) {
  						IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"UPDATE/SE timeout -Sending BYE\n");
						eRetVal= IFX_SIPAPP_ReleaseCall(pxAppData->iConnId, (void*)pxAppData);
						*peEcode = IFX_SIP_EVENT_HANDLED;
				}
			}
		}

   } // end for UPDATE handling
#endif
#ifdef RFC_4028
  if(nStatCode == 422){
    IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_MIN_SE,1,&uiHdrHdl);
    pxAppData->uiMinSe = IFX_SIP_MIN_SE_GetTime(uiHdrHdl);
		pxAppData->uiSe = pxAppData->uiMinSe;
  	IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Hanlding Min-SE");
    eRetVal = IFX_SIPAPP_MakeCall(pxAppData);
    if (eRetVal == IFX_SIP_FAILURE) {
      IFX_SIP_FreeMsg(uiMsgHdl);
			/*Send Release to App*/
    }
		else {
   		*peEcode = IFX_SIP_EVENT_HANDLED;
			return IFX_SIP_SUCCESS;
		}
  }
#endif
  if((nStatCode != 407) && (nStatCode != 401) && (eReqId != IFX_SIP_BYE)) {
    /* To handle 481/other 4xx response for cancel. Eg: DSL link goes down 
       after receiving 18x response */
    if(eReqId == IFX_SIP_CANCEL){
      IFX_SIPAPP_RemoveAppData(pxAppData,IFX_SIPAPP_UA_CALL);
    }
    if(pxAppData->iFlag & IFX_SIPAPP_LOCAL_HOLD){
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_HOLD_FAIL, 
                              "Negotiation Error");
      /* Reset this hold flag */
      pxAppData->iFlag &= ~IFX_SIPAPP_LOCAL_HOLD;
    }
    else if(pxAppData->iFlag & IFX_SIPAPP_LOCAL_RESUME){
      vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_RESUME_FAIL,
                              "Negotiation Error");
      pxAppData->iFlag &= ~IFX_SIPAPP_LOCAL_RESUME;
      pxAppData->iFlag |= IFX_SIPAPP_LOCAL_HOLD;
    }
		else if(pxAppData->iFlag & IFX_SIPAPP_MEDIA_UPDATE_SENT){
	    vpxNotifier.pfStateNotifier(&pxAppData->iConnId,IFX_MEDIA_UPDATE_FAILURE,
                              pxAppData);
      pxAppData->iFlag &= ~IFX_SIPAPP_MEDIA_UPDATE_SENT;
 					
		}
    else{
      
      if(nStatCode == 404) {
        vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL, 
                                 (void *)IFX_404_RESP);
      }
      else if(nStatCode == 486){
        vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                                    (void *)IFX_486_RESP);
      }
      else if(nStatCode == 488){
        vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                                 (void *)IFX_488_RESP);
      }
      else if(nStatCode == 415) {
         vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL, 
                                  (void *)IFX_415_RESP);
      }
			else if(nStatCode == 487){
					/* No action */		
			}
      else{
        vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
		         	(void *)IFX_400_RESP);
      }
    }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIP_Handle5XXResp
*  Description    : this function handles 5xx responses..
*  Input Values   : pxAppData ... pointer to the App Data
*           	    uiMsgHdl... Message Handle having 5xx information
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*  	            IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle5XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode)
{
#ifdef RFC_3311
	e_IFX_SIP_BasicMethod eReqId;
	e_IFX_SIP_Return eRetVal;
  char8 *pcMethod=NULL;
	uint32 uiHdrHdl=0;
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CSEQ,1,&uiHdrHdl);
  if(eRetVal == IFX_SIP_FAILURE){
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
  }

	pcMethod = IFX_SIP_CSeq_GetMethod(uiHdrHdl);
  eReqId = IFX_SIP_GetMethodType(pcMethod);
#endif

  /* If 183 Response has been recvd before the receipt of 5xx response */
  if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
    pxAppData->iRtpParamModified = 0;
    pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
  }
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,(void *)IFX_500_RESP);

#ifdef RFC_4028
#ifdef RFC_3311
/*If Refresh Has failed inside the confirmed dialog - Send Bye and Relase the Call*/
	if(eReqId == IFX_SIP_UPDATE){
		uint32 uiDlgHeadHdl = 0;
		eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
		if(IFX_SIP_SUCCESS == eRetVal) {
			uint32 uiDlgHdl=0;
			eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl, peEcode);
			if(IFX_SIP_SUCCESS == eRetVal) {
  			IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Refresh Failed - Send BYE");
				eRetVal= IFX_SIPAPP_ReleaseCall(pxAppData->iConnId, (void*)pxAppData);
				*peEcode = IFX_SIP_EVENT_HANDLED;
			}
		}
	}
#endif
#endif

  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name  : IFX_SIP_Handle6XXResp
*  Description    : this function handles 6xx responses..
*  Input Values   : pxAppData - Pointer to application data
*          	    uiMsgHdl - Message handle for Inbound message
*  Output Values  : peEcode .......pointer to error code if any
*  Return Value   : IFX_SIP_SUCCESS
*                   IFX_SIP_FAILURE
*  Notes          : 
*********************************************************************/
PUBLIC e_IFX_SIP_Return
IFX_SIPAPP_Handle6XXResp(IN x_IFX_SIPAPP_UAAppData* pxAppData,
                      IN uint32 uiMsgHdl,
                      OUT e_IFX_SIP_Ecode* peEcode)
{
#ifdef RFC_3311
	e_IFX_SIP_BasicMethod eReqId;
	e_IFX_SIP_Return eRetVal;
  char8 *pcMethod=NULL;
	uint32 uiHdrHdl=0;
  eRetVal = IFX_SIP_GetHeaderByType(uiMsgHdl,IFX_SIP_CSEQ,1,&uiHdrHdl);
  if(eRetVal == IFX_SIP_FAILURE){
      //IFX_SIP_FreeMsg(uiMsgHdl);
      return eRetVal;
  }

	pcMethod = IFX_SIP_CSeq_GetMethod(uiHdrHdl);
  eReqId = IFX_SIP_GetMethodType(pcMethod);
#endif


  /* If 183 Response has been recvd before the receipt of 6xx response */
  if(pxAppData->iFlag & IFX_SIPAPP_RTP_SESS_EXIST){
    pxAppData->iRtpParamModified = 0;
    pxAppData->iFlag &= ~IFX_SIPAPP_RTP_SESS_EXIST;
    IFX_SIPAPP_RtpRespHandler(pxAppData,IFX_SIPAPP_CLOSE_CONNRES_EVENT);
  }
  vpxNotifier.pfStateNotifier(&pxAppData->iConnId, IFX_RELEASE_SIGNAL,
                         (void *)IFX_600_RESP);
#ifdef RFC_4028
#ifdef RFC_3311
	if(eReqId == IFX_SIP_UPDATE){
		uint32 uiDlgHeadHdl = 0;
		eRetVal = IFX_SIP_CC_GetDialogHead(pxAppData->auiHdl[IFX_SIPAPP_UA_CALL],
                                     &uiDlgHeadHdl);
		if(IFX_SIP_SUCCESS == eRetVal) {
			uint32 uiDlgHdl=0;
			eRetVal = IFX_SIP_DLG_GetConfDialoginDlgList(uiDlgHeadHdl,
                                               &uiDlgHdl, peEcode);
			if(IFX_SIP_SUCCESS == eRetVal) {
  			IFX_DBGA(vcSipAppModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Refresh Failed - Send BYE");
				eRetVal= IFX_SIPAPP_ReleaseCall(pxAppData->iConnId, (void*)pxAppData);
				*peEcode = IFX_SIP_EVENT_HANDLED;
			}
		}
	}
#endif
#endif
  return IFX_SIP_SUCCESS;
}



