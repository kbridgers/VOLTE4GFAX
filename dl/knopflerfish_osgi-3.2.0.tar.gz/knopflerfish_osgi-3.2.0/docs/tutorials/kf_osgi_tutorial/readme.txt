
This directory contains the OSGi Tutorial (in OpenOffice Writer format) 
originally by Sven Haiges and updated by Erik wistrand.

The example_source directory contains the source code used in the 
tutorial. These examples depend on ${kf.dir/framework.jar}
