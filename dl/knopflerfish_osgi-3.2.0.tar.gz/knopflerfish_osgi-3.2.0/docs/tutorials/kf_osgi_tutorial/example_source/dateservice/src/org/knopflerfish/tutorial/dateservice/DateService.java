package org.knopflerfish.tutorial.dateservice; 

import java.util.Date; 

public interface DateService {
  public String getFormattedDate(Date date);
} 
