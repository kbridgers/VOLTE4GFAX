#include <stdio.h>
#include <sys/types.h>
#include<string.h>
#include <ifx_common.h>
#define FILE_SYSTEM_STATUS	"/tmp/system_status"
#define FILE_OPER	oper_file

#ifdef IFX_MULTILIB_UTIL
#define	main	status_oper_main
#endif

#define MAX_CFG_STR_LEN		10000
#define MAX_FIELD_LEN		1000
#define MAX_FILENAME		256

#if 1
#define PRINTF(fmt, args...)
#else
#define PRINTF(fmt, args...)	printf(fmt, ##args)
#endif

void usage(char *apps_name)
{
	printf("usage: %s [-u modify] [-a add] [-d delete] [-f <file>]\n"
	       "\t SET <tag_name> <cfg_name> <cfg_value>\n"
	       "\t GET <tag_name> <cfg_value>\n", apps_name);
}

int main(int argc, char *argv[])
{
	char sValue[MAX_FIELD_LEN], buf[MAX_CFG_STR_LEN],conf_buf[MAX_FIELD_LEN];
	int i = 0;
	char oper_file[MAX_FILENAME];
	char operation[256]={0};
	char **org_argv;
	int f_upd = 0, ret = 0;

	org_argv = argv;
	if (argc < 4) {
		goto lbl_usage;
	}

	strcpy(oper_file, FILE_SYSTEM_STATUS);	/* default file to operate on */
	while (argv[1][0] == '-') {
		switch (argv[1][1]) {
			case 'u':
				f_upd = 1;
				strcpy(operation,"update");
				argc--;
				argv++;
				break;
			case 'a':
				f_upd = 1;
				strcpy(operation,"add");
				argc--;
				argv++;
				break;
			case 'd':
				f_upd = 1;
				strcpy(operation,"delete");
				argc--;
				argv++;
				break;
			case 'f':
				strcpy(oper_file, argv[2]);
				argc -= 2;
				argv += 2;
				break;
		}
		PRINTF("argc[%d], f_upd[%d], oper_file[%s]\n", argc, f_upd,
				oper_file);
		if (argc < 4) {
			goto lbl_usage;
		}
	}

	if (!strcasecmp("SET", argv[1])) {

		memset(buf, 0x00, sizeof(buf));
		ret = sizeof(buf) - 1;
		for (i = 0; i < (argc - 2) / 2; i++) {
			ret -=
				sprintf(conf_buf, "%s=\"%s\"\n", argv[i * 2 + 3],
						argv[i * 2 + 4]);
			if (ret < 0) {
				printf("(%s) SET string too large !\n",
						org_argv[0]);
				goto lbl_ret;
			}
			LTQ_STRNCAT(buf, conf_buf, sizeof(buf));
			PRINTF("[%d] buf[%s]\n", i, buf);
		}
#if 0				/* [ Support conditional update as well */
		ifx_SetCfgData(FILE_OPER, argv[2], 1, buf);
#else				/* ][ */
		PRINTF("argc[%d], f_upd[%d], oper_file[%s]\n", argc, f_upd,oper_file);
		if(!strcmp(operation,"update"))
			ret = ifx_SetObjData(FILE_OPER, argv[2],f_upd ? /*IFX_F_INT_MOD_ADD */ IFX_F_MODIFY :0,1, buf);
		else if(!strcmp(operation,"add"))
			ret = ifx_SetObjData(FILE_OPER, argv[2],f_upd ? IFX_F_INT_ADD :0,1, buf);
		else if(!strcmp(operation,"delete"))
			ret = ifx_SetObjData(FILE_OPER, argv[2],f_upd ? IFX_F_DELETE :0,1, buf);
		else
			ret = ifx_SetObjData(FILE_OPER, argv[2],f_upd ? /*IFX_F_INT_MOD_ADD */ IFX_F_MODIFY :0,1, buf);

		if (ret != 0) {
			PRINTF("ifx_SetObjData() returned [%d] \n", ret);
		} else {
			if (strcmp(oper_file, FILE_SYSTEM_STATUS) != 0) {
				/* Updating Persistent Storage */
				ret =
					ifx_config_write(FILE_RC_CONF,
							IFX_F_MODIFY);
				if (ret != 0) {
					PRINTF
						("[%s:%d] Update persistent storage fail",
						 __FUNCTION__, __LINE__);
				}
			}
		}

#endif
	} else if (!strcasecmp("GET", argv[1])) {
		if (ifx_GetCfgData(FILE_OPER, argv[2], argv[3], sValue) == 1) {
			printf("%s", sValue);
		} else {
			ret = 1;
		}
	} else {
		goto lbl_usage;
	}
lbl_ret:
	return ret;
lbl_usage:
	usage(org_argv[0]);
	return 1;
}
