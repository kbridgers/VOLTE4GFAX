
#define UPSTREAM_Q_DEV "imq0"
#define DOWNSTREAM_Q_DEV "imq1"
#define TAG_QOS_CLASS_QUEUE_MAP "qos_bk"
#define RATE_SHAPING_MASK "0x1C00"

#define QQ_AVPKT 500
#define CALCULATE_THRESOLD_RED(qmin_th,qmax_th,qburst) \
{ \
	qmin_th = qos_queue->uiRedTh; \
	qmax_th = (qmin_th * 3); \
	qburst  = (qmin_th << 2); \
	qburst  = (qburst + qmax_th); \
	qburst  = (qburst / (QQ_AVPKT * 3)); \
}

#define GET_INSTANCE_FROM_CPEID(file,id,section,inst) { \
	CPE_ID cpe_id; \
	strcpy(cpe_id.secName, section); \
	cpe_id.Id = id; \
	if(ifx_get_index_from_cpe_id(file, &cpe_id, \
		&inst) != IFX_SUCCESS ) { \
		fprintf(stderr,"Error: %s %s", __FILE__,__func__); \
	} \
}

#define INIT_QOS_CLASS_QUEUE_MAP(qos_queues,numQueueInst) { \
	int loop_count = 0; \
	for(loop_count = 0; loop_count < numQueueInst; loop_count++) { \
		init_qspec_class_queue_map_file(&qos_queues[loop_count],IFX_F_INT_ADD); \
	} \
}

typedef struct qos_q_map_class_info {
	int class_cpeid;
	int cur_stream_rate;
	int old_stream_rate;
	int mapped_idx;
} QoS_Q_Map_Class_info;

typedef struct qos_class_queue_map {
	int queue_cpeid;
	int num_stream_attached;
	QoS_Q_Map_Class_info class_info[8];
} QoS_Class_Queue_Map;
