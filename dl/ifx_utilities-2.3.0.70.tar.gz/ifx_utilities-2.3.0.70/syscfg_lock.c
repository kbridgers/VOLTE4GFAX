/*
 * syscfg_lock <file to lock> '<operations>'
 * Use this utility to execute critical operations by locking a file.
 * lock will be released once the operations are terminated.
 * Created to lock /flash/rc.conf and execute critical operations like backup.
 *
 * Copyright (C) 2012, Lantiq Inc., All rights reserved.
 * alexander.abraham@lantiq.com
 *
 */

#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/time.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <ifx_common.h>
#include<signal.h>

#ifdef IFX_MULTILIB_UTIL
  #define main syscfg_lock_main
#endif

#define SEMAPHORE_KEY 1234

/* From MAPI */
extern int init_sem(key_t key);
extern int enter_critical_section(int semid);
extern int exit_critical_section(int semid);
/* ********* */

void sig_handler(int signo)
{
    if (signo == SIGTERM)
        printf("SYS_LOCK util:received SIGTERM\n");
}

int main (int argc, char *argv[])
{
	FILE *fp = NULL;
	int ret = 0, semid;

	if (signal(SIGTERM, sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGTERM\n");

	if (argc != 3) {
		fprintf(stderr, "Usage: %s <file to lock> '<commands to scripts>'\n", argv[0]);
		return (1);
	}

	//Initialize semaphore 
	semid = init_sem(SEMAPHORE_KEY);

	if ((fp = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "%s: Unable to open file: %s\n", argv[0], argv[1]);
		return (2);
	}

	/* Get an Exclusive Write Lock */
	if (enter_critical_section(semid) == 0) {
		if (flock(fileno(fp), LOCK_EX) < 0) {
			fprintf(stderr, "%s: Unable to perform Exclusive Lock!\n", argv[0]);
			fclose(fp);
			exit_critical_section(semid);
			return (1);
		}

		ret = ifx_run_command (argv[2]);

		exit_critical_section(semid);
	}

	flock(fileno(fp), LOCK_UN);

	if (fp) fclose(fp);

	return (ret);
}

