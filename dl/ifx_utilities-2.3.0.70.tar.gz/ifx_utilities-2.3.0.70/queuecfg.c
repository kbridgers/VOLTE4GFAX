
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>

#include <ifx_config.h>
#include <ifx_common.h>
#include "ifx_amazon_cfg.h"
#include "queuecfg.h"

#ifdef IFX_MULTILIB_UTIL
#define main	queuecfg_main
#endif

#define SEMAPHORE_KEY 4321

/* From MAPI */
extern int init_sem(key_t key);
extern int enter_critical_section(int semid);
extern int exit_critical_section(int semid);


#define OPT_ADD 1
#define OPT_DEL 2
#define OPT_MOD 3
#define OPT_ADD_ALL 4
#define OPT_DEL_ALL 5
#define OPT_PRIO 6
#define OPT_FLAG_INIT 7
#define OPT_QUEUE_CONFIG 8
#define OPT_RATE_UPDATE 9
#define OPT_FLAG_UPDATE 10
#define OPT_CLASS_INIT 11
#define OPT_CLASS_DISABLE 12
  /* Macros for QOS_RATE_SHAPING */
#define OPT_CQMAP_ADD 13
#define OPT_CQMAP_DEL 14
#define OPT_CQMAP_STREAM_ADD 15
#define OPT_CQMAP_STREAM_DEL 16
#define OPT_CQMAP_QUEUE_ADD 17
#define OPT_CQMAP_QUEUE_DEL 18

#define ADSL_PTM  1  
#define VDSL_PTM  2  
#define VRX288_MODEL       1 
#define ARX188_MODEL       2
#define DEFAULT_MODEL      3
#define AR9_PLATFORM       4
#define DEFAULT_PLATFORM   5

static void help_fn(char *prg)
{
	printf("Usage: %s [options]\n", prg);
	printf(" --Add {vpi/vci}\t\t\t Add Queue \n");
	printf(" --Delete {vpi/vci}\t\t\t Delete Queue\n");
	printf(" --Modify {vpi/vci}\t\t\t Modify Queue\n");
	printf(" --InsertAll {vpi/vci}\t\t\t Add all the queues of a PVC\n");
	printf
	    (" --FlushAll {vpi/vci}\t\t\t Delete all queues attached to a PVC\n");
	printf(" --PreInitialize QoS\n");
	printf(" --Configure Queues\n");
	printf(" --Update Rates\n");
	printf(" --Initialize HW Classifiers\n");
	printf(" --Disable HW Classifiers\n");
	printf(" --Help\t\t\t\t\t display help\n");

}

/* Debug function for QOS Rate Shaping */
static int qos_debug(char *str)
{
	FILE *fp = NULL;
	if ((fp = fopen("/tmp/qos_debug", "a")) == NULL) {
		fprintf(stderr, "Unable to open the qos debug file");
/* Manamohan: 14,June 2011,Added return as per Klocwork report  */
		return -1;
	}

	fprintf(fp, str);
	fprintf(fp, "\n");
	fclose(fp);
	return 0;
}

/* Function to get the Queue Method for QOS Rate Shaping */
static int get_queue_method()
{
	char sLine[64];
	char tLine[64];

	// Initialize Memories
	memset(sLine, 0, 64);
	memset(tLine, 0, 64);

	int queue_method = -1;

	sprintf(tLine, "queue_method");
	ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_QOS_CLASS_QUEUE_MAP, tLine,
		       IFX_F_GET_ENA, 0, sLine);
	queue_method = atoi(sLine);

	IFX_DBG("%s:Selected Queue Method: %d", __func__, queue_method);

	return queue_method;
}

static int
update_class_queue_map(char *cl_q_map, int idx, int queue_cpeid,
		       int class_cpeid, int stream_rate)
{
	char sLine[512];
	//char pLine[256];
/*Manamohan: Klockwork updates on 7,March 7 */
	char pLine[538];
	int ret=0;
	char *sPtr, *ePtr;

	int sidx, tidx;
	int stlen = 0, start_len = 0, end_len = 0;
	int len = 0;

	// Initialize the memory
	memset(sLine, 0, 512);
	memset(pLine, 0, 538);

	// Check input parameters
	if (cl_q_map == NULL || idx < 0 || idx > 8) {

		IFX_ERR(" Invalid Argument %s %s", __FILE__, __func__);
		return -2;
	}
	// total len of the buf 
	stlen = strlen(cl_q_map);
	sPtr = ePtr = cl_q_map;
	// skip upto idx spaces
	sidx = (idx << 1);

	tidx = 0;
	while (tidx < sidx) {
		if (*ePtr == ' ') {
			tidx++;
		}
		ePtr++;
		if (*ePtr == 0) {
			// TBD: error handling
		}
	}

	// calculate start len of the string 
	start_len = ePtr - sPtr;

	// copy sart string into buffer.
	if (start_len > 0) {
		strncpy(sLine, sPtr, start_len);
	}
	// Add class_id an rate
	ret=sprintf(sLine + start_len, "%d %d ", class_cpeid, stream_rate);
        sLine[ret+start_len]='\0';
	// sPtr = ePtr;
	// Skip two spaces
	tidx = 0;
	while (*ePtr && tidx < 2) {
		if (*ePtr == ' ') {
			tidx++;
		}
		ePtr++;
	}

	end_len = stlen - (ePtr - sPtr);

	// consider the end string case
	if (end_len > 1) {
		len = strlen(sLine);
		strncpy(sLine + strlen(sLine), ePtr, end_len);
/* Manamohan: 16,June 2011, NULL termination as per Klocwork */
		sLine[end_len + len] = '\0';
	}

	IFX_DBG("%s: Modified Queue Map: %s for: queue cpe: %d class_cpe: %d",
		__func__, sLine, queue_cpeid, class_cpeid);

	sprintf(pLine, "qq_%d_map_list=\"%s\"\n", queue_cpeid, sLine);
	ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_QOS_CLASS_QUEUE_MAP,
		       IFX_F_MODIFY, 1, pLine);
	return 0;
}

static int
get_class_queue_mapped_idx(int queue_cpeid, int class_cpeid, int *avail_idx,
			   char *map_list, int *stream_rate,
			   int *num_stream_attached)
{
	char sLine[256];
	char tLine[256];
	char *tStr = NULL, *mlist = NULL;
	int list_count, tcount = 0;
	int retIdx = -1, stream_count = 0;
	int class_id = -1, old_stream_rate = -1;

	// Initialize the memories
	memset(sLine, 0, 256);
	memset(tLine, 0, 256);

	// Check input parameters
	if (queue_cpeid < 0 || class_cpeid < 0) {
		fprintf(stderr, " Invalid Argument %s %s", __FILE__, __func__);
		return -2;
	}
	// set the map list pointer
	if (map_list) {
		mlist = map_list;
	} else {
		mlist = sLine;
	}

	// Read Class Queue Map List
	sprintf(tLine, "qq_%d_map_list", queue_cpeid);
	if (ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_QOS_CLASS_QUEUE_MAP, tLine,
			   IFX_F_GET_ENA, 0, mlist) != IFX_SUCCESS) {
		IFX_ERR("Invalid Get Object Operation");
		// either tmp file sys of section does not exist.
		return -2;
	}

	IFX_DBG("mList: %s", mlist);

	tStr = mlist;

	if (avail_idx != NULL) {
		*avail_idx = -1;
	}
	// Parse Class Queue Map List and Check if classif is present
	for (list_count = 0, tcount = 0; list_count < 15; list_count += 2) {
		// Scan Class CPEID
		sscanf(tStr, "%d", &class_id);
		while (*tStr && *tStr != ' ')
			tStr++;

		// Skip space
		if (*tStr == ' ')
			tStr++;

		// Scan Class Rate
		sscanf(tStr, "%d", &old_stream_rate);
		while (*tStr && *tStr != ' ')
			tStr++;

		// Skip space
		if (*tStr == ' ')
			tStr++;

		if (class_id >= 0) {

			if (class_id == class_cpeid) {
				retIdx = tcount;
				// If existing then returns it's stream rate
				if (stream_rate)
					*stream_rate = old_stream_rate;
			}
			stream_count++;

		} else if (avail_idx != NULL && *avail_idx == -1) {

			// Set Available classifier idx
			*avail_idx = tcount;
		}
		tcount++;
	}

	// Set number of stream attached to this stream
	if (num_stream_attached != NULL)
		*num_stream_attached = stream_count;

	// return -1 if stream does not exist, >=0 if stream exist
	return retIdx;
}

static int init_class_queue_map(QoS_Class_Queue_Map * cl_q_map)
{
	int loop_count = 0;
	cl_q_map->queue_cpeid = -1;
	cl_q_map->num_stream_attached = 0;

	for (loop_count = 0; loop_count < 8; loop_count++) {
		cl_q_map->class_info[loop_count].class_cpeid = -1;
		cl_q_map->class_info[loop_count].cur_stream_rate = -1;
		cl_q_map->class_info[loop_count].old_stream_rate = -1;
		cl_q_map->class_info[loop_count].mapped_idx = -1;
	}
	return 0;
}

static int get_class_queue_map(int queue_cpeid, QoS_Class_Queue_Map * cl_q_map)
{
	char sLine[256];
	char tLine[256];
	char *tStr;
	int list_count = 0, tcount = 0;
	int stream_count = 0;
	int class_id = 0, old_stream_rate = 0;

	// Initialize the memories
	memset(sLine, 0, 256);
	memset(tLine, 0, 256);

	sprintf(tLine, "qq_%d_map_list", queue_cpeid);

	// Get Class Queue Map List
	if (ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_QOS_CLASS_QUEUE_MAP, tLine,
			   IFX_F_GET_ENA, 0, sLine) != IFX_SUCCESS) {

		// either tmp file sys of section does not exist.
		return -2;
	}

	tStr = sLine;
	// Parse Class Queue Map List and Check if classif is present
	for (list_count = 0; list_count < 15; list_count += 2) {
		// Scan Class CPEID
		sscanf(tStr, "%d", &class_id);
		while (*tStr && *tStr != ' ')
			tStr++;

		// Skip space
		if (*tStr == ' ')
			tStr++;

		// Scan Class Rate
		sscanf(tStr, "%d", &old_stream_rate);
		while (*tStr && *tStr != ' ')
			tStr++;

		// Skip space
		if (*tStr == ' ')
			tStr++;

		if (class_id >= 0) {
			cl_q_map->class_info[tcount].class_cpeid = class_id;
			cl_q_map->class_info[tcount].old_stream_rate =
			    old_stream_rate;
			cl_q_map->class_info[tcount].cur_stream_rate =
			    old_stream_rate;
			cl_q_map->class_info[tcount].mapped_idx = (tcount + 1);
			stream_count++;
		}
		tcount++;
	}
	cl_q_map->num_stream_attached = stream_count;
	IFX_DBG("%s: Number of st attached: %d", __func__,
		cl_q_map->num_stream_attached);

	// return -1 if stream does not exist, >=0 if stream exist
	return 0;
}

#if 0
#endif
// TBD: Put it as define 
static int
get_tc_queue_class_id(char *queue_id, char *class_id, int queue_prio,
		      char *lower_class_id, char *lower_b_queue_id,
		      int mapped_idx)
{
	sprintf(queue_id, "4%d", queue_prio);
	sprintf(class_id, "1:%s", queue_id);
	sprintf(lower_class_id, "%s:%d", queue_id, mapped_idx);
	sprintf(lower_b_queue_id, "%s%d", queue_id, mapped_idx);
	return 0;
}

/* Manamohan, WFQ + SP  */
get_tc_queue_class_id_wfq(char *queue_id, char *class_id, int queue_prio,
			  char *lower_class_id, char *lower_b_queue_id,
			  int mapped_idx)
{
	sprintf(queue_id, "99%d", queue_prio);
	sprintf(class_id, "99:%d", queue_prio);
	sprintf(lower_class_id, "%s:%d", queue_id, mapped_idx);
	sprintf(lower_b_queue_id, "%s%d", queue_id, mapped_idx);
	return 0;
}

static int
update_qdisc(IFX_MAPI_QoS_Queue * qos_queue, int mapped_idx, int cl_stream_rate,
	     int num_stream_attached, int flag)
{
	int queue_prio = -1;
/*Manamohan: Update for Klocwork,7March2012  */
	char class_id[16], lower_class_id[23];
	char queue_id[16], lower_b_queue_id[22];
	char cmd[2048], opt[16], red_bfifo[256];
	char *tptr;
	int nfmark = 0;
	int queue_peakrate = 0, stream_rate = 0;
	unsigned int qmin_th = 0, qmax_th = 0, qburst = 0;

	// check queue method and return from here.
	if ((get_queue_method() != 1) || qos_queue == NULL) {
		return -1;
	}
	// Initialise buffers
	memset(class_id, 0, 16);
	memset(lower_class_id, 0, 23);
	memset(queue_id, 0, 16);
	memset(lower_b_queue_id, 0, 22);
	memset(cmd, 0, 2048);
	memset(opt, 0, 16);
	memset(red_bfifo, 0, 256);

	queue_prio = qos_queue->qPrio;
	queue_peakrate = qos_queue->peakRate;

	if (queue_peakrate < 0 || queue_prio < 0) {
		IFX_DBG("%s: Invalid queue Peak Rate or queue prio", __func__);
		return -1;
	}
	// Limit stream rate upto max rate
	stream_rate =
	    (queue_peakrate > cl_stream_rate) ? cl_stream_rate : queue_peakrate;

	IFX_DBG("%s: Queue Prio : %d PeakRate: %d stream: %d", __func__,
		queue_prio, queue_peakrate, stream_rate);

	// make tc class id i.e 1:41 and queue_id i.e 41

/* Manamohan: SP + WFQ */
	if (qos_queue->schedType == IFX_MAPI_QoS_Sched_SP)
		get_tc_queue_class_id(queue_id, class_id, queue_prio,
				      lower_class_id, lower_b_queue_id,
				      mapped_idx);
	else {
		get_tc_queue_class_id_wfq(queue_id, class_id, queue_prio,
					  lower_class_id, lower_b_queue_id,
					  mapped_idx);

	}

	IFX_DBG("%s: Queue_ID : %s class_id: %s ", __func__, queue_id,
		class_id);
	IFX_DBG("%s: lower_class_id : %s lower_b_queue_id: %s ", __func__,
		lower_class_id, lower_b_queue_id);

	// Create ClassLess Qdisc Buffer Depending on Red or Bfifo
	if (qos_queue->dropType == 0) {
		if (qos_queue->qLen > 0) {
			sprintf(red_bfifo, "bfifo limit %u", qos_queue->qLen);
		} else {
			sprintf(red_bfifo, "bfifo");
		}
	} else if (qos_queue->dropType == 1) {
		if (qos_queue->qLen > 0) {
			sprintf(red_bfifo, "red limit %u ", qos_queue->qLen);
		} else {
			sprintf(red_bfifo, "red");
		}

		// Calculate min max & burst & max dropping probability
		CALCULATE_THRESOLD_RED(qmin_th, qmax_th, qburst);

		// Set min max & burst & max dropping probability
		sprintf(red_bfifo + strlen(red_bfifo),
			"min %u max %u avpkt %u burst %u probability %f",
			qmin_th, qmax_th, QQ_AVPKT, qburst,
			qos_queue->flRedProb);
	} else {
		IFX_DBG("%s: UnKnown Queue Dropping Mechanism", __func__);
		return -1;
	}

	// Add the following rule
	// if num_stream_attached = 1 replace bfifo qdisc with htb
	tptr = cmd;
	if (flag == OPT_CQMAP_STREAM_ADD && num_stream_attached == 0) {

		// tc qdisc add dev $UPSTREAM_Q_DEV parent 1:11 handle 11 htb
		// Delete the bfifo queue first
		sprintf(tptr, "tc qdisc del dev %s parent %s handle %s; ",
			UPSTREAM_Q_DEV, class_id, queue_id);
		tptr = cmd + strlen(cmd);
		sprintf(tptr,
			"tc qdisc add dev %s parent %s handle %s htb default 9; ",
			UPSTREAM_Q_DEV, class_id, queue_id);
		// Add default class under this 
		tptr = cmd + strlen(cmd);
		sprintf(tptr,
			"tc class add dev %s parent %s:0 classid %s:9 htb rate %dkbit ceil %dkbit; ",
			UPSTREAM_Q_DEV, queue_id, queue_id, queue_peakrate,
			queue_peakrate);
		tptr = cmd + strlen(cmd);
		sprintf(tptr, "tc qdisc add dev %s parent %s:9 handle %s9 %s; ",
			UPSTREAM_Q_DEV, queue_id, queue_id, red_bfifo);

	} else if (flag == OPT_CQMAP_STREAM_DEL && num_stream_attached == 1) {
		sprintf(tptr, "tc qdisc del dev %s parent %s handle %s htb; ",
			UPSTREAM_Q_DEV, class_id, queue_id);
		tptr = cmd + strlen(cmd);
		sprintf(tptr, "tc qdisc add dev %s parent %s handle %s %s; ",
			UPSTREAM_Q_DEV, class_id, queue_id, red_bfifo);
		IFX_DBG("Deleting: %s", cmd);
		system(cmd);
		return 0;
	}
	// move the tptr to add the rules recursively
	tptr = cmd + strlen(cmd);

	nfmark = (mapped_idx << 10) & 0x1C00;
	if (flag == OPT_CQMAP_STREAM_ADD) {
		// add the class for that stream
		// tc class add dev $UPSTREAM_Q_DEV parent 11:0 classid 11:1 htb rate
		// $STREAM_FST_PEAKRATE ceil $STREAM_FST_PEAKRATE
		sprintf(tptr,
			"tc class add dev %s parent %s:0 classid %s htb rate %dkbit ceil %dkbit; ",
			UPSTREAM_Q_DEV, queue_id, lower_class_id, stream_rate,
			stream_rate);

		// Attach bfifo disc to this class
		// tc qdisc add dev $UPSTREAM_Q_DEV parent 11:1 handle 111 bfifo limit
		// 30000
		tptr = cmd + strlen(cmd);
		sprintf(tptr, "tc qdisc add dev %s parent %s handle %s %s; ",
			UPSTREAM_Q_DEV, lower_class_id, lower_b_queue_id,
			red_bfifo);

		// move the cmd ptr
		tptr = cmd + strlen(cmd);

		// Attach tc filter to this
		// tc filter add dev imq0 protocol all parent 11:0 prio 1 handle 10 fw
		// classid 11:1
		// tc filter add dev $UPSTREAM_Q_DEV protocol all parent 1:0 prio 1 u32 
		// 
		// match mark 13 0xffff flowid 1:13
		// TBD: u32 classifier
		sprintf(tptr,
			"tc filter add dev %s protocol all parent %s:0 prio %d u32 match mark %d %s flowid %s;",
			UPSTREAM_Q_DEV, queue_id, mapped_idx, nfmark,
			RATE_SHAPING_MASK, lower_class_id);
	} else if (flag == OPT_CQMAP_STREAM_DEL) {
		// One second sleep is introduced as after deleting filter if we
		// immediately try to delete the class the class id crassing
		// sprintf(tptr,"tc filter del dev %s protocol all parent %s:0 prio %d
		// u32 match mark %d %s flowid %s; ", \
		// UPSTREAM_Q_DEV, queue_id, mapped_idx, nfmark,
		// RATE_SHAPING_MASK,lower_class_id);

		// tptr = cmd + strlen(cmd);
		// sprintf(tptr,"tc class del dev %s parent %s:0 classid %s htb rate %d 
		// 
		// 
		// ceil %d; ", \
		// UPSTREAM_Q_DEV,queue_id,lower_class_id,stream_rate,stream_rate);

	}
	IFX_DBG("Command : %s", cmd);

	// Run the system command
	system(cmd);

	/* if (flag == OPT_CQMAP_STREAM_DEL) { //sleep(5); tptr = cmd +
	   strlen(cmd); sprintf(tptr,"tc class del dev %s parent %s:0 classid %s
	   htb rate %d ceil %d; ", \
	   UPSTREAM_Q_DEV,queue_id,lower_class_id,stream_rate,stream_rate);

	   IFX_DBG("Stream Del Command : %s",tptr); system(tptr); } */

	return 0;
}

static int update_qdisc_scaning_classinfo(IFX_MAPI_QoS_Queue * qos_queue)
{
	int loop_count, str_cnt;
	int queue_cpeid = qos_queue->iid.cpeId.Id;
	QoS_Class_Queue_Map cl_q_map;

	init_class_queue_map(&cl_q_map);
	cl_q_map.queue_cpeid = queue_cpeid;

	if (get_class_queue_map(queue_cpeid, &cl_q_map) < 0) {
		return 0;
	}

	IFX_DBG("%s: QueueId: %d Num stream attached %d", __func__, queue_cpeid,
		cl_q_map.num_stream_attached);

	for (loop_count = 0, str_cnt = 0; loop_count < 8; loop_count++) {
		if (cl_q_map.class_info[loop_count].class_cpeid >= 0) {
			update_qdisc(qos_queue,
				     cl_q_map.class_info[loop_count].mapped_idx,
				     cl_q_map.class_info[loop_count].
				     cur_stream_rate, str_cnt,
				     OPT_CQMAP_STREAM_ADD);

			IFX_DBG("%s:class_cpeid: %d rate: %d", __func__,
				cl_q_map.class_info[loop_count].class_cpeid,
				cl_q_map.class_info[loop_count].
				cur_stream_rate);

			str_cnt++;
			if (str_cnt == cl_q_map.num_stream_attached) {
				// exit from the loop
				loop_count = 8;
				IFX_DBG("%s: strcnt: %d attach: %d", __func__,
					str_cnt, cl_q_map.num_stream_attached);
			}
		}
	}
	return 0;
}

static int
update_stream_in_queue(IFX_MAPI_QoS_Queue * qos_queue, int class_cpeid,
		       int flag)
{
	char map_list[512];
	char sLine[256], tLine[256];

	int retidx;
	int avail_idx = 0, class_inst = 0;
	int num_stream_attached = 0;
	int stream_rate = 0;
	int queue_cpeid = 0;

	// Initialize the bufers
	memset(map_list, 0, 512);
	memset(sLine, 0, 256);
	memset(tLine, 0, 256);

	queue_cpeid = qos_queue->iid.cpeId.Id;
	// Get index for the stream
	retidx =
	    get_class_queue_mapped_idx(queue_cpeid, class_cpeid, &avail_idx,
				       map_list, &stream_rate,
				       &num_stream_attached);
	IFX_DBG("retidx: %d avail_idx: %d", retidx, avail_idx);
	IFX_DBG("stream_rate: %d num_stream_attached: %d", stream_rate,
		num_stream_attached);
	if (retidx >= 0) {
		// Stream already exist
		if (flag == OPT_CQMAP_STREAM_DEL) {
			update_class_queue_map(map_list, retidx, queue_cpeid,
					       -1, -1);
			// TBD: Kernel panic occur if we delete only one stream
			// So, restart the queueing mechanism after updating class queue
			// map
			if (num_stream_attached == 1) {
				update_qdisc(qos_queue, retidx + 1, stream_rate,
					     num_stream_attached,
					     OPT_CQMAP_STREAM_DEL);

			} else {
				update_qdisc_scaning_classinfo(qos_queue);
			}
		}
	} else if (retidx == -1) {
		if (flag == OPT_CQMAP_STREAM_ADD && avail_idx >= 0) {
			// Add the new stream.
			GET_INSTANCE_FROM_CPEID(FILE_RC_CONF, class_cpeid,
						TAG_IPQOS_CLASSIFY, class_inst);
			IFX_DBG("Func: %s : Class Instance Obtained: %d",
				__func__, class_inst);

			// obtain the rate of the classifier
			sprintf(tLine, "qcl_%d_rateLmt", class_inst);
			ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY, tLine,
				       IFX_F_GET_ENA, 0, sLine);
			stream_rate = atoi(sLine);

			IFX_DBG("Func: %s :Class Rate Obtained: %d", __func__,
				stream_rate);

			// if rate > 0 update tmp_status
			if (stream_rate > 0) {
				update_class_queue_map(map_list, avail_idx,
						       queue_cpeid, class_cpeid,
						       stream_rate);
				// add level 2 queue.
				update_qdisc(qos_queue, avail_idx + 1,
					     stream_rate, num_stream_attached,
					     OPT_CQMAP_STREAM_ADD);
			}
		}
	}
	return (retidx >= 0) ? (retidx + 1) : (avail_idx + 1);
}

static int add_stream_to_queue(IFX_MAPI_QoS_Queue * qos_queue, int class_cpeid)
{
	return update_stream_in_queue(qos_queue, class_cpeid,
				      OPT_CQMAP_STREAM_ADD);
}

static int
del_stream_from_queue(IFX_MAPI_QoS_Queue * qos_queue, int class_cpeid)
{
	return update_stream_in_queue(qos_queue, class_cpeid,
				      OPT_CQMAP_STREAM_DEL);
}

/* Function for QOS Rate Shaping */
static int queuesm(char *ids, int opt)
{
	int queue_cpeid = -1, class_cpeid = -1;
	char *tstr1 = NULL;
	char *tstr2 = NULL;
	int ret = 0;
	IFX_MAPI_QoS_Queue qos_queue;

	// Check the arguments
	if (ids == NULL) {
		IFX_ERR("NULL Queue And Class Ids\n");
		return -1;
	}
	// Retrieve queue id and class id
	tstr1 = ids;
	tstr2 = strchr(ids, '/');
	if (tstr2 == NULL) {
		IFX_ERR("Invalid Parameter value\n");
		return -1;
	}

	*tstr2 = '\0';
	tstr2++;
	if (*tstr1 == '\0' || *tstr1 == '\0') {
		IFX_ERR("Invalid Parameter value\n");
		return -1;
	}

	queue_cpeid = atoi(tstr1);
	class_cpeid = atoi(tstr2);

	if (queue_cpeid < 0) {
		return 0;
	}
	if (opt == OPT_CQMAP_ADD) {
		opt =
		    (class_cpeid >=
		     0) ? OPT_CQMAP_STREAM_ADD : OPT_CQMAP_QUEUE_ADD;
	} else if (opt == OPT_CQMAP_DEL) {
		opt =
		    (class_cpeid >=
		     0) ? OPT_CQMAP_STREAM_DEL : OPT_CQMAP_QUEUE_DEL;
	}

	IFX_DBG("queue_cpeid: %d class_cpeid: %d Action: %d", queue_cpeid,
		class_cpeid, opt);

	// retrieve queue related info
	qos_queue.iid.cpeId.Id = queue_cpeid;
	ifx_mapi_get_qos_queue(&qos_queue, IFX_F_DEFAULT);

	// Call stream add 
	if (opt == OPT_CQMAP_STREAM_ADD) {

		ret = add_stream_to_queue(&qos_queue, class_cpeid);
	}

	else if (opt == OPT_CQMAP_STREAM_DEL) {
		ret = del_stream_from_queue(&qos_queue, class_cpeid);
	} else if (opt == OPT_CQMAP_QUEUE_ADD) {
		ret =
		    init_qspec_class_queue_map_file(&qos_queue, IFX_F_INT_ADD);
	} else if (opt == OPT_CQMAP_QUEUE_DEL) {
		ret = init_qspec_class_queue_map_file(&qos_queue, IFX_F_DELETE);
	}
	return ret;
}

static void queuepvc(char *pvc, int opt)
{
	// Invoked from MAPI during Queue ADD operation after compaction is
	// performed.
	// Invoked from MAPI during enabling of QoS
	// (1)Add/DELETE one queue to pvc using ioctl based on the option
	// (2)call MAPI to get all the queue configurations from the rc.conf
	// (3)sort all the available priorities
	// (4)Make ioctl calls to perform skbuff priority mappings to queues

	IFX_MAPI_QoS_Queue *qos_queues = NULL;
	IFX_MAPI_QoS_Queue *Lqos_queues = NULL;
	IFX_MAPI_QoS_Classifier *qos_classes = NULL;
	IFX_MAPI_QoS_Classifier *Wqos_classes = NULL;
	IFX_MAPI_QoS_Interface_Type qIfType;
	IFX_MAPI_QoS_Interface_Type LqIfType;
	char *vpi = NULL, *vci = NULL, cmdbuf[1024];
	int numQueueInst = 0, LnumQueueInst = 0, numClassInst =
	    0, WnumClassInst = 0, i, j, *prio = NULL, *dsprio = NULL;
	int iDisableCount = 0;
	int iLDisableCount = 0;
	int def_queue_prio = 0;
	int def_queue_cpeid = 0;
	int ds_def_queue_prio = 0;
	int ds_def_queue_cpeid = 0;
	int stream_direction = -1;
	const char *model_grx288;
	const char *model_vrx288;
	const char *model_arx300;
	char sLine[256];
	int total_ClassInst = 0;
   int wanModeType = 0;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	// step1; 
	vpi = pvc;
	vci = strchr(pvc, '/');
	if (vci == NULL) {
		printf("Invalid Parameter value\n");
		return;
	}
	*vci = '\0';
	vci++;

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
		if (pstWanPhy.wan_tc == WAN_TC_ATM) {
			qIfType = IFX_MAPI_QoS_WAN_ATM;
			def_queue_cpeid = 9;
			LqIfType = IFX_MAPI_QoS_LAN_ATM;
			ds_def_queue_cpeid = 13;
		}
		if (pstWanPhy.wan_tc == WAN_TC_PTM) {
			qIfType = IFX_MAPI_QoS_WAN_PTM;
			LqIfType = IFX_MAPI_QoS_LAN_PTM;
			def_queue_cpeid = 12;
			ds_def_queue_cpeid = 14;
         wanModeType = ADSL_PTM; 
		}
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) {
		qIfType = IFX_MAPI_QoS_WAN_ETH_0;
		LqIfType = IFX_MAPI_QoS_LAN_ETH_0;
		def_queue_cpeid = 10;
		ds_def_queue_cpeid = 15;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {
		qIfType = IFX_MAPI_QoS_WAN_ETH_1;
		LqIfType = IFX_MAPI_QoS_LAN_ETH_1;
		def_queue_cpeid = 11;
		ds_def_queue_cpeid = 16;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) {
		qIfType = IFX_MAPI_QoS_WAN_PTM;
		LqIfType = IFX_MAPI_QoS_LAN_PTM;
		def_queue_cpeid = 12;
		ds_def_queue_cpeid = 14;
      wanModeType = VDSL_PTM; 
	} else {
		/* This will never be hit : Default is taken as ATM*/
		qIfType = IFX_MAPI_QoS_WAN_ATM;
		def_queue_cpeid = 9;
		LqIfType = IFX_MAPI_QoS_LAN_ATM;
		ds_def_queue_cpeid = 13;
	}

	IFX_DBG("[%s:%d] qIfType: %d", __func__, __LINE__, qIfType);
	if (ifx_mapi_get_all_qos_queue_if_specific
	    (qIfType, (uint32 *) & numQueueInst, &qos_queues,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
		printf
		    ("[%s:%d] Failed to display configured queues for interface ",
		     __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}

	if (ifx_mapi_get_all_qos_classifier_if_specific
	    (qIfType, (uint32 *) & numClassInst, &qos_classes,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
		printf
		    ("[%s:%d] Failed to display configured classes for interface ",
		     __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}
	if (ifx_mapi_get_all_qos_queue_if_specific
	    (LqIfType, (uint32 *) & LnumQueueInst, &Lqos_queues,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
		printf
		    ("[%s:%d] Failed to display configured queues for interface ",
		     __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}

	if (ifx_mapi_get_all_qos_ds_classifier_if_specific
	    (LqIfType, (uint32 *) & WnumClassInst, &Wqos_classes,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
		printf
		    ("[%s:%d] Failed to display configured classes for interface ",
		     __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}
	total_ClassInst = numClassInst + WnumClassInst;

	if ((numQueueInst > 1) || (LnumQueueInst > 1)) {
		switch (opt) {
		case OPT_ADD:
			sprintf(cmdbuf, "echo pvc %s.%s add > /proc/eth/prio",
				vpi, vci);
			system(cmdbuf);
			break;
		case OPT_ADD_ALL:
			for (i = 1; i < numQueueInst; i++) {
				sprintf(cmdbuf,
					"echo pvc %s.%s add > /proc/eth/prio",
					vpi, vci);
				system(cmdbuf);
			}
			break;
		case OPT_DEL:
			sprintf(cmdbuf, "echo pvc %s.%s del > /proc/eth/prio",
				vpi, vci);
			system(cmdbuf);
			break;
		case OPT_DEL_ALL:
			for (i = 1; i < numQueueInst; i++) {
				sprintf(cmdbuf,
					"echo pvc %s.%s del > /proc/eth/prio",
					vpi, vci);
				system(cmdbuf);
			}
			break;
		case OPT_PRIO:
			break;
		case OPT_FLAG_INIT:
			break;
		case OPT_FLAG_UPDATE:
			break;
		case OPT_QUEUE_CONFIG:
			break;
		case OPT_RATE_UPDATE:
			break;
		case OPT_CLASS_INIT:
			break;
		case OPT_CLASS_DISABLE:
			break;
		default:
			break;
		}
	}
	// step2 
	// also assign the priority of default queue in a variable.
	// allocate and copy the cpeid and priority
	prio = (int *)malloc(sizeof(int) * numQueueInst);
	dsprio = (int *)malloc(sizeof(int) * LnumQueueInst);

/* Manamohan : 14,June 2011, NULL check and initialization as per Klocwork report */
	if (prio == NULL) {
		goto IFX_Handler;
	}
	if (dsprio == NULL) {
		goto IFX_Handler;
	}
	memset(prio, 0, (sizeof(int) * numQueueInst));
	memset(dsprio, 0, (sizeof(int) * LnumQueueInst));

	for (i = 0, j = 0; i < numQueueInst; i++) {
		if (qos_queues[i].enable) {
			prio[j] = qos_queues[i].qPrio;
			j++;
		} else {
			iDisableCount++;
		}
		if (qos_queues[i].iid.cpeId.Id == def_queue_cpeid)
			def_queue_prio = qos_queues[i].qPrio;
	}
	for (i = 0, j = 0; i < LnumQueueInst; i++) {
		if (Lqos_queues[i].enable) {
			dsprio[j] = Lqos_queues[i].qPrio;
			j++;
		} else {
			iLDisableCount++;
		}
		if (Lqos_queues[i].iid.cpeId.Id == ds_def_queue_cpeid)
			ds_def_queue_prio = Lqos_queues[i].qPrio;
	}

	// step3
	// sort the cpeid based on priority
	for (i = 0; i < (numQueueInst - iDisableCount); i++) {
		for (j = i + 1; j < (numQueueInst - iDisableCount); j++) {
			if (prio[i] > prio[j]) {
				prio[i] ^= prio[j] ^= prio[i] ^= prio[j];
			}
		}
	}
	for (i = 0; i < (LnumQueueInst - iLDisableCount); i++) {
		for (j = i + 1; j < (LnumQueueInst - iLDisableCount); j++) {
			if (dsprio[i] > dsprio[j]) {
				dsprio[i] ^= dsprio[j] ^= dsprio[i] ^= dsprio[j];
			}
		}
	}

	for (i = 0; i < (numQueueInst - iDisableCount); i++) {
		if ((opt != OPT_PRIO) && (opt != OPT_FLAG_INIT)
		    && (opt != OPT_FLAG_UPDATE) && (opt != OPT_QUEUE_CONFIG)
		    && (opt != OPT_RATE_UPDATE) && (opt != OPT_CLASS_INIT)
		    && (opt != OPT_CLASS_DISABLE)) {
			sprintf(cmdbuf,
				"echo pvc %s.%s queue %d prio %d > /proc/eth/prio",
				vpi, vci, i, prio[i] - 1);
			system(cmdbuf);
		}
	}

	for (i = 0; i < (LnumQueueInst - iLDisableCount); i++) {
		if ((opt != OPT_PRIO) && (opt != OPT_FLAG_INIT)
		    && (opt != OPT_FLAG_UPDATE) && (opt != OPT_QUEUE_CONFIG)
		    && (opt != OPT_RATE_UPDATE) && (opt != OPT_CLASS_INIT)
		    && (opt != OPT_CLASS_DISABLE)) {
			sprintf(cmdbuf,
				"echo pvc %s.%s queue %d prio %d > /proc/eth/prio",
				vpi, vci, i, prio[i] - 1);
			system(cmdbuf);
		}
	}

	if (opt == OPT_PRIO) {
		int queuecnt = 0;
		int prio_mod1 = 0;
		int prio_mod2 = 0;

		sprintf(cmdbuf,
			"/usr/sbin/iptables -t mangle -F IPQOS_OUTPUT_MAP");
		system(cmdbuf);

/*Manamohan: D5 FW MII0 QoS Support  */
#if 0
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) {
			queuecnt = 4;
		} else {
			queuecnt = 8;
		}
#endif
		queuecnt = 8;
		if ((numQueueInst - iDisableCount) == 1) {
			prio_mod1 = ((-prio[0] + queuecnt + 1) << 6);

			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark 0xffffff1 -j MARK --set-mark %d",
				prio_mod1);
			system(cmdbuf);
			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark 0xffffff2 -j MARK --set-mark %d",
				prio_mod1);
			system(cmdbuf);
			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark %d -j ACCEPT",
				prio_mod1);
			system(cmdbuf);
		} else {
			prio_mod1 = ((-prio[0] + queuecnt + 1) << 6);
			prio_mod2 = ((-prio[1] + queuecnt + 1) << 6);

			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark 0xffffff1 -j MARK --set-mark %d",
				prio_mod1);
			system(cmdbuf);
			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark %d -j ACCEPT",
				prio_mod1);
			system(cmdbuf);
			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark 0xffffff2 -j MARK --set-mark %d",
				prio_mod2);
			system(cmdbuf);
			sprintf(cmdbuf,
				"/usr/sbin/iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark %d -j ACCEPT",
				prio_mod2);
			system(cmdbuf);
		}
	}

	if (opt == OPT_FLAG_INIT) {
		int red_enable = 0, red_count = 0;
		int mfc_enable = 0, mfc_count = 0;
		int queue_type = 0 /* 0->SP and 2->WFQ */ , queue_type_check =
		    0;
		int Lqueue_type = 0 /* 0->SP and 2->WFQ */ , Lqueue_type_check =
		    0;
		int queue_enable_count = 0, Lqueue_enable_count = 0;
		int dscp_count = 0, dscp_enable = 0;
		// class_rate_limit_enb initialize rate_limit to zero. If Any class
		// rate
		// limit is enabled this vlaue is incremented. class_rate_limit_enb
		// store
		// Number of class associated with rate limit.
		int class_rate_limit_enb = 0;
		int onep_count = 0, onep_enable = 0;
		int sum_cr = 0, lanq_sum_cr = 0;
		int sum_pr = 0, lanq_sum_pr = 0;
		int sum_wt = 0, lanq_sum_wt = 0;
		char sLine[256];
		for (i = 0; i < numQueueInst; i++) {
			if (qos_queues[i].enable) {
				queue_enable_count++;

				// if (qos_queues[i].weightEnable)
				// {
				sum_wt += qos_queues[i].qWt;
				// }
				if (qos_queues[i].shaperEnable) {
					sum_pr += qos_queues[i].peakRate;
					if (!qos_queues[i].weightEnable &&
					    (qos_queues[i].schedType ==
					     IFX_MAPI_QoS_Sched_WFQ)) {
						sum_cr +=
						    qos_queues[i].commitRate;
					}
				}
				if (!queue_type_check) {
					if (qos_queues[i].schedType ==
					    IFX_MAPI_QoS_Sched_WFQ) {
						queue_type = 2;
					} else {
						queue_type = 0;
					}
					queue_type_check = 1;
				}
				if (qos_queues[i].dropType ==
				    IFX_MAPI_QoS_Drop_RED)
					red_count++;
			}
		}
		for (i = 0; i < LnumQueueInst; i++) {
			if (Lqos_queues[i].enable) {
				Lqueue_enable_count++;

				// if (qos_queues[i].weightEnable)
				// {
				lanq_sum_wt += Lqos_queues[i].qWt;
				// }
				if (Lqos_queues[i].shaperEnable) {
					lanq_sum_pr += Lqos_queues[i].peakRate;
					if (!Lqos_queues[i].weightEnable &&
					    (Lqos_queues[i].schedType ==
					     IFX_MAPI_QoS_Sched_WFQ)) {
						lanq_sum_cr +=
						    qos_queues[i].commitRate;
					}
				}
				if (!Lqueue_type_check) {
					if (Lqos_queues[i].schedType ==
					    IFX_MAPI_QoS_Sched_WFQ) {
						Lqueue_type = 2;
					} else {
						Lqueue_type = 0;
					}
					Lqueue_type_check = 1;
				}
				if (Lqos_queues[i].dropType ==
				    IFX_MAPI_QoS_Drop_RED)
					red_count++;
			}
		}
		if (red_count)
			red_enable = 1;
	   //total_ClassInst = numClassInst + WnumClassInst;
		for (i = 0; i < numClassInst; i++) {
			if (qos_classes[i].enable) {
				if (qos_classes[i].mfClass ==
				    IFX_MAPI_QoS_Multi_Field)
					mfc_count++;
				if (qos_classes[i].mfClass == IFX_MAPI_QoS_DSCP)
					dscp_count++;
				if (qos_classes[i].mfClass ==
				    IFX_MAPI_QoS_P_Bits)
					onep_count++;
				// check if Any Class is associated with rate limit.
				if (qos_classes[i].rateCtrlEnbl == 1)
					class_rate_limit_enb++;
			}
		}
      for (i = 0; i < WnumClassInst; i++) {
			if (Wqos_classes[i].enable) {
				if (Wqos_classes[i].mfClass ==
				    IFX_MAPI_QoS_Multi_Field)
					mfc_count++;
				if (Wqos_classes[i].mfClass == IFX_MAPI_QoS_DSCP)
					dscp_count++;
				if (Wqos_classes[i].mfClass ==
				    IFX_MAPI_QoS_P_Bits)
					onep_count++;
				// check if Any Class is associated with rate limit.
				if (Wqos_classes[i].rateCtrlEnbl == 1)
					class_rate_limit_enb++;
			}
		}

		if (mfc_count)
			mfc_enable = 1;
		if (dscp_count)
			dscp_enable = 1;
		if (onep_count)
			onep_enable = 1;
		sprintf(sLine, "red_count=\"%d\"\n", red_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "red_enable=\"%d\"\n", red_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "mfc_count=\"%d\"\n", mfc_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "mfc_enable=\"%d\"\n", mfc_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "dscp_count=\"%d\"\n", dscp_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "dscp_enable=\"%d\"\n", dscp_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "onep_count=\"%d\"\n", onep_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "onep_enable=\"%d\"\n", onep_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "queue_enable_count=\"%d\"\n",
			queue_enable_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "queue_type=\"%d\"\n", queue_type);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		
		sprintf(sLine, "sum_cr=\"%d\"\n", sum_cr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "lanq_sum_cr=\"%d\"\n", lanq_sum_cr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		
		sprintf(sLine, "sum_pr=\"%d\"\n", sum_pr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "lanq_sum_pr=\"%d\"\n", lanq_sum_pr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		
		sprintf(sLine, "sum_wt=\"%d\"\n", sum_wt);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		sprintf(sLine, "lanq_sum_wt=\"%d\"\n", lanq_sum_wt);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);
		// Write Class Rate Enable In /tmp/system_status
		sprintf(sLine, "class_rate_limit_enb=\"%d\"\n",
			class_rate_limit_enb);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);

/*Manamohan: SP + WFQ support   */
		sprintf(sLine, "queue_wfq_prio=\"99\"\n");
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);

		sprintf(sLine, "link_rate_status=\"1\"\n");
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_INT_ADD, 1,
			       sLine);

		INIT_QOS_CLASS_QUEUE_MAP(qos_queues, numQueueInst);
		INIT_QOS_CLASS_QUEUE_MAP(Lqos_queues, LnumQueueInst);
	}

	if (opt == OPT_FLAG_UPDATE) {
		int red_enable = 0, red_count = 0, Lred_count = 0;
		    
		int mfc_enable = 0, mfc_count = 0;
		    
		int dscp_count = 0, dscp_enable = 0;
		    
		// class_rate_limit_enb initialize rate_limit to zero. If Any class
		// rate
		// limit is enabled this vlaue is incremented. class_rate_limit_enb
		// store
		// Number of class associated with rate limit.
		int class_rate_limit_enb = 0;
		int onep_count = 0, onep_enable = 0;
		int queue_type = 0 /* 0->SP and 2->WFQ */ , queue_type_check =
		    0;
		int Lqueue_type = 0 /* 0->SP and 2->WFQ */ , Lqueue_type_check =
		    0;
		int queue_enable_count = 0;
		int Lqueue_enable_count = 0;
		int sum_cr = 0, lanq_sum_cr = 0;
		int sum_pr = 0, lanq_sum_pr = 0;
		int sum_wt = 0, lanq_sum_wt = 0;
		char sLine[256];
		for (i = 0; i < numQueueInst; i++) {
			if (qos_queues[i].enable) {
				queue_enable_count++;

				// if (qos_queues[i].weightEnable)
				// {
				sum_wt += qos_queues[i].qWt;
				// }
				if (qos_queues[i].shaperEnable) {
					sum_pr += qos_queues[i].peakRate;
					if (!qos_queues[i].weightEnable &&
					    (qos_queues[i].schedType ==
					     IFX_MAPI_QoS_Sched_WFQ)) {
						sum_cr +=
						    qos_queues[i].commitRate;
					}
				}
				if (!queue_type_check) {
					if (qos_queues[i].schedType ==
					    IFX_MAPI_QoS_Sched_WFQ) {
						queue_type = 2;
					} else {
						queue_type = 0;
					}
					queue_type_check = 1;
				}
				if (qos_queues[i].dropType ==
				    IFX_MAPI_QoS_Drop_RED)
					red_count++;
			}
		}
		for (i = 0; i < LnumQueueInst; i++) {
			if (Lqos_queues[i].enable) {
				Lqueue_enable_count++;

				// if (qos_queues[i].weightEnable)
				// {
				lanq_sum_wt += Lqos_queues[i].qWt;
				// }
				if (Lqos_queues[i].shaperEnable) {
					lanq_sum_pr += Lqos_queues[i].peakRate;
					if (!Lqos_queues[i].weightEnable &&
					    (Lqos_queues[i].schedType ==
					     IFX_MAPI_QoS_Sched_WFQ)) {
						lanq_sum_cr +=
						    Lqos_queues[i].commitRate;
					}
				}
				if (!Lqueue_type_check) {
					if (Lqos_queues[i].schedType ==
					    IFX_MAPI_QoS_Sched_WFQ) {
						Lqueue_type = 2;
					} else {
						Lqueue_type = 0;
					}
					Lqueue_type_check = 1;
				}
				if (Lqos_queues[i].dropType ==
				    IFX_MAPI_QoS_Drop_RED)
					Lred_count++;
			}
		}
		red_count += Lred_count;
		if (red_count)
			red_enable = 1;
	   //total_ClassInst = numClassInst + WnumClassInst;
		for (i = 0; i < numClassInst; i++) {
			if (qos_classes[i].enable) {
				if (qos_classes[i].mfClass ==
				    IFX_MAPI_QoS_Multi_Field)
					mfc_count++;
				if (qos_classes[i].mfClass == IFX_MAPI_QoS_DSCP)
					dscp_count++;
				if (qos_classes[i].mfClass ==
				    IFX_MAPI_QoS_P_Bits)
					onep_count++;
				// check if Any Class is associated with rate limit.
				if (qos_classes[i].rateCtrlEnbl == 1)
					class_rate_limit_enb++;
			}
		}
      for (i = 0; i < WnumClassInst; i++) {
			if (Wqos_classes[i].enable) {
				if (Wqos_classes[i].mfClass ==
				    IFX_MAPI_QoS_Multi_Field)
					mfc_count++;
				if (Wqos_classes[i].mfClass == IFX_MAPI_QoS_DSCP)
					dscp_count++;
				if (Wqos_classes[i].mfClass ==
				    IFX_MAPI_QoS_P_Bits)
					onep_count++;
				// check if Any Class is associated with rate limit.
				if (Wqos_classes[i].rateCtrlEnbl == 1)
					class_rate_limit_enb++;
			}
		}

		if (mfc_count)
			mfc_enable = 1;
		if (dscp_count)
			dscp_enable = 1;
		if (onep_count)
			onep_enable = 1;
		sprintf(sLine, "red_count=\"%d\"\n", red_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "red_enable=\"%d\"\n", red_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "mfc_count=\"%d\"\n", mfc_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "mfc_enable=\"%d\"\n", mfc_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "dscp_count=\"%d\"\n", dscp_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "dscp_enable=\"%d\"\n", dscp_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "onep_count=\"%d\"\n", onep_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "onep_enable=\"%d\"\n", onep_enable);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "queue_enable_count=\"%d\"\n",
			queue_enable_count);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "queue_type=\"%d\"\n", queue_type);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		
		sprintf(sLine, "sum_cr=\"%d\"\n", sum_cr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "lanq_sum_cr=\"%d\"\n", lanq_sum_cr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		
		sprintf(sLine, "sum_pr=\"%d\"\n", sum_pr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "lanq_sum_pr=\"%d\"\n", lanq_sum_pr);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);

		sprintf(sLine, "sum_wt=\"%d\"\n", sum_wt);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
		sprintf(sLine, "lanq_sum_wt=\"%d\"\n", lanq_sum_wt);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);

		// Write Class Rate Enable In /tmp/system_status
		sprintf(sLine, "class_rate_limit_enb=\"%d\"\n",
			class_rate_limit_enb);
		ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1,
			       sLine);
	}

	if (opt == OPT_QUEUE_CONFIG) {
		char sLine[256];
		char sLine1[256];

		char cmd[2048];
		char *tptr;
		int queue_method = -1;

		int US_enable = -1;
		int DS_enable = -1;
		char8 command[256];
		
		// /* Update the /tmp/system_status counters */
		// system("queuecfg -c 0/0");

		/* Get The Current Platform */
		char platform[10];
		stream_direction = atoi(vpi);
		ifx_GetObjData("/tmp/system_status", "ppe_config_status",
			       "ppe_platform", IFX_F_GET_ENA, 0, sLine);

/*Manamohan: 16 June 2011,Buffer overflow fix */
		if (strlen(sLine) < 10)
			strcpy(platform, sLine);

		/* Get the Current Mode */
		IFX_MAPI_QoS_Interface_Type iIfType;
		IFX_MAPI_QoS_Interface_Type LiIfType;
		iIfType = ifx_mapi_get_active_qos_iface();
		
		if(stream_direction == 1)
		{
			iIfType = ifx_mapi_get_active_qos_iface();
		}
		if(stream_direction == 2)
		{
			switch(iIfType)
			{
				case IFX_MAPI_QoS_WAN_ATM:
					LiIfType = IFX_MAPI_QoS_LAN_ATM;
					break;
				case IFX_MAPI_QoS_WAN_PTM:
					LiIfType = IFX_MAPI_QoS_LAN_PTM;
					break;
				case IFX_MAPI_QoS_WAN_ETH_0:
					LiIfType = IFX_MAPI_QoS_LAN_ETH_0;
					break;
				case IFX_MAPI_QoS_WAN_ETH_1:
					LiIfType = IFX_MAPI_QoS_LAN_ETH_1;
					break;
				default:
					break;
			}
			iIfType = LiIfType;	
		}
		/* Get Red Enable Status */
		int red_enable = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk", "red_enable",
			       IFX_F_GET_ENA, 0, sLine);
		red_enable = atoi(sLine);

		/* Get MFC Enable Status */
		int mfc_enable = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk", "mfc_enable",
			       IFX_F_GET_ENA, 0, sLine);
		mfc_enable = atoi(sLine);

		/* Get MFC Enable Status */
		int class_rate_limit_enb = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk",
			       "class_rate_limit_enb", IFX_F_GET_ENA, 0, sLine);
		class_rate_limit_enb = atoi(sLine);

		IFX_DBG
		    ("\n%s: $$$ class_rate_limit_enb Param read from /tmp/ : %d\n",
		     __func__, class_rate_limit_enb);
		/* Get Current Queuing method */
		// 0->none 1->sw 2->ppefw 3->hwgig 4->hwtantos

		/* Get the current PPE FW */
		char ppefw[10];
		ifx_GetObjData("/tmp/system_status", "ppe_config_status",
			       "ppe_firmware", IFX_F_GET_ENA, 0, sLine);

/*Manamohan: 16 June 2011,Buffer overflow fix */
		if (strlen(sLine) < 10)
			strcpy(ppefw, sLine);

		/* Get Queuing mode */
		int queuing_mode = 0;	// 0->pvc 1->port
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt", "qm_atmQmode",
			       IFX_F_GET_ENA, 0, sLine);
		queuing_mode = atoi(sLine);

		/* Get Queuing mode */
		int port_shaping_enable = 0;	// 0->pvc 1->port
		int DS_port_shaping_enable = 0;	// 0->pvc 1->port
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt",
			       "qm_portRateLimEnab", IFX_F_GET_ENA, 0, sLine);
		port_shaping_enable = atoi(sLine);
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt",
			       "qm_DSportRateLimEnab", IFX_F_GET_ENA, 0, sLine);
		DS_port_shaping_enable = atoi(sLine);

		/* Manamohan: WFQ + SP support */
		int port_rate = 0, down_port_rate = 0;
		int up_link_rate = 0, down_link_rate = 0;
		int stream_rate = 0;
		//ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt", "qm_upportRateLim", IFX_F_GET_ENA, 0, sLine);

		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim",
			       IFX_F_GET_ENA, 0, sLine);
		port_rate = atoi(sLine);
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim",
			       IFX_F_GET_ENA, 0, sLine);
		down_port_rate = atoi(sLine);

		memset(cmd, 0, 2048);
		tptr = cmd;

		memset(sLine, 0, sizeof(sLine));
		ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk", "queue_method",
			       IFX_F_GET_ENA, 0, sLine);
		queue_method = atoi(sLine);

		if ((queue_method == 1) || (queue_method == 5)) 
		{
			if( stream_direction == 1)
			{
				for (i = 0; i < numQueueInst; i++) 
				{
					if (qos_queues[i].enable) 
					{
						if (qos_queues[i].schedType == 
					    	IFX_MAPI_QoS_Sched_WFQ) 
						{
							ifx_GetObjData
						    	("/tmp/system_status",
						     	"qos_bk", "up_link_rate",
						     	IFX_F_GET_ENA, 0, sLine);
							up_link_rate = atoi(sLine);

							if (qos_queues[i].shaperEnable == 1)	/* !< enable rateshaping */
								stream_rate =
							    qos_queues[i].
							    peakRate;
							if (port_shaping_enable == 1)
								stream_rate = port_rate;
							else
								stream_rate = up_link_rate;	/* How to get this info ??? */

							sprintf(tptr,
								"tc class delete dev %s parent 1:1 classid 1:99 htb rate 1kbit ceil %dkbit prio %d; ",
								UPSTREAM_Q_DEV,
								stream_rate,
								qos_queues[i].qPrio -
								1);

							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							sprintf(tptr,
								"tc qdisc delete dev %s parent 1:99 handle 99: htb; ",
								UPSTREAM_Q_DEV);

							// move the cmd ptr
							tptr = cmd + strlen(cmd);

							system(cmd);

                  					/* Manamohan,WFQ capped to stream rate */
							memset(cmd, 0, 2048);
							tptr = cmd;
							sprintf(tptr,
								"tc class delete dev %s parent 99: classid 99:99 htb rate %dkbit; ",
								UPSTREAM_Q_DEV,
								stream_rate);

							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							system(cmd);

							break;
						}
					}
				}		/*End of for loop */
			} /* End of stream direction = 1 loop */
			if( (stream_direction == 2) && ((strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR10") != 0)))
			{
				for (i = 0; i < LnumQueueInst; i++) 
				{
					if (qos_queues[i].enable) 
					{
						if (qos_queues[i].schedType == IFX_MAPI_QoS_Sched_WFQ) 
						{
							ifx_GetObjData
							    ("/tmp/system_status",
							     "qos_bk", "down_link_rate",
							     IFX_F_GET_ENA, 0, sLine);
							down_link_rate = atoi(sLine);

							if (qos_queues[i].shaperEnable == 1)	/* !< enable rateshaping */
								stream_rate =
								    qos_queues[i].
								    peakRate;
							if (DS_port_shaping_enable == 1)
								stream_rate = down_port_rate;
							else
								stream_rate = down_link_rate;	/* How to get this info ??? */

							sprintf(tptr,
								"tc class delete dev %s parent 1:1 classid 1:99 htb rate 1kbit ceil %dkbit prio %d; ",
								DOWNSTREAM_Q_DEV,
								stream_rate,
								qos_queues[i].qPrio -
								1);
	
							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
								sprintf(tptr,
								"tc qdisc delete dev %s parent 1:99 handle 99: htb; ",
								DOWNSTREAM_Q_DEV);
	
							// move the cmd ptr
							tptr = cmd + strlen(cmd);
	
							system(cmd);
	
							/* Manamohan,WFQ capped to stream rate */
							memset(cmd, 0, 2048);
							tptr = cmd;
							sprintf(tptr,
								"tc class delete dev %s parent 99: classid 99:99 htb rate %dkbit; ",
								DOWNSTREAM_Q_DEV,
								stream_rate);
		
							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							system(cmd);
	
							break;
						} /* End of WFQ loop*/
					}
				}
			} /*End of stream direction = 2 */
		} /* End of Queue Method = 1 */

		/*End of queue method check */
		/* Disable the current queuing method */
		//char8 command[256];
		int16 Queue_direction = 0;	
		int16 upstream_queues = 1;
		int16 downstream_queues = 2;
		if(stream_direction == 1)
		{
			for (i = 0; i < numQueueInst; i++) {
				int32 index;
				int32 ret;
				if (qos_queues[i].enable) {
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queues[i].iid.cpeId, index)
				    	sprintf(command,"/etc/rc.d/ipqos_q_mgmt %d 0 %d",index,upstream_queues);
					system(command);
				}
			}
		} /* End of stream direction = 1 */
		if(stream_direction == 2)
		{
			for (i = 0; i < LnumQueueInst; i++) {
				int32 index;
				int32 ret;
				if (Lqos_queues[i].enable) {
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, Lqos_queues[i].iid.cpeId, index)
					sprintf(command,"/etc/rc.d/ipqos_q_mgmt %d 0 %d", index, downstream_queues);
					system(command);
				}
			}
		} /* End of stream direction = 2 */
		
		memset(sLine, 0, sizeof(sLine));
		memset(sLine1, 0, sizeof(sLine1));

		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_USenable",
			       IFX_F_GET_ENA, 0, sLine);
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_DSenable",
			       IFX_F_GET_ENA, 0, sLine1);
		US_enable = atoi(sLine);
		DS_enable = atoi(sLine1);
		
		if ((US_enable == 1) && (stream_direction == 1))
		{
			Queue_direction=1;	
			sprintf(command, "/etc/rc.d/ipqos_q_disable %d", Queue_direction);
			system(command);
		}
		if ((DS_enable == 1) && (stream_direction == 2))
		{
			Queue_direction=2;	
			sprintf(command, "/etc/rc.d/ipqos_q_disable %d", Queue_direction);
			system(command);
		}
		
		//sprintf(command, "/etc/rc.d/ipqos_q_disable");
		//system(command);
      int num_model =0;
      int num_platform=0;
	   model_grx288 = strstr(CONFIG_IFX_MODEL_NAME, "ARX188");
      if(model_grx288 != NULL)
              num_model = ARX188_MODEL;
      else
      {
	      model_grx288 = strstr(CONFIG_IFX_MODEL_NAME, "VRX288");
         if(model_grx288 != NULL)
              num_model = VRX288_MODEL;
         else
              num_model = DEFAULT_MODEL;
      }
      
      if(strcmp(platform, "AR9") == 0)
              num_platform = AR9_PLATFORM;
      else
              num_platform = DEFAULT_PLATFORM;

      switch(iIfType)
      {
              case IFX_MAPI_QoS_WAN_ATM:
              case IFX_MAPI_QoS_LAN_ATM:
                      switch(num_platform)
                      {
                              case AR9_PLATFORM:
                                 queue_method = 1;
                                 break;
                              default:
                                 queue_method = 5;
                      }
                      break;

              case IFX_MAPI_QoS_WAN_PTM:
              case IFX_MAPI_QoS_LAN_PTM:
                      switch(wanModeType)
                      {
                              case ADSL_PTM:
                                 switch(num_platform)
                                 {
                                    case AR9_PLATFORM:
                                       queue_method = 1;
                                       break;
                                    default:
                                       queue_method = 5;
                                 }
                                 break;
                              default:
                                 queue_method = 2;
                      }
                      break;

              case IFX_MAPI_QoS_WAN_ETH_1:
              case IFX_MAPI_QoS_LAN_ETH_1:
                      switch(num_model)
                      {
                              case ARX188_MODEL:
                              case VRX288_MODEL:
                                 queue_method = 2;
                                 break;
                              default:
                                 queue_method = 3;
                      }
                      break;
       }
       
       if ( ((red_enable) || (class_rate_limit_enb) || (port_shaping_enable)) &&  (strcmp(platform, "AR9") == 0) ) 
               queue_method = 1;
       else 
            if(  (port_shaping_enable) && (iIfType == IFX_MAPI_QoS_WAN_ETH_1) )
                  queue_method = 2; /* Not supported */
            else
               if ( (red_enable) || (class_rate_limit_enb) || (port_shaping_enable)) 
                     queue_method = 5;

/* Set the ppa acceleration part */
       if( (queue_method == 1) || (queue_method == 5) )
            system("ppacmd control --disable-lan --enable-wan");
       else
            system("ppacmd control --enable-lan --enable-wan");
	    
/* Set the queue method in the tmp system status */
       sprintf(sLine, "queue_method=\"%d\"\n",queue_method);
		 ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1, sLine);


/************************************************************************************************************************************************************/
#if 0

		if (iIfType == IFX_MAPI_QoS_WAN_PTM) 
		{
			/* If red is enabled and platform is not VR9 then SW. Also since
			   port shaping is not supported in VRX-PTM FW, we will move to
			   software. */
			if ((red_enable) || (class_rate_limit_enb) || ((strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR9") != 0)) 
					|| (port_shaping_enable) || (DS_port_shaping_enable)) 
			{
				/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
				system("ppacmd control --disable-lan --disable-wan");
				printf("Disabling Routed & Disabling Bridged Acceleration\n");
				/* Set sw queuing method for all queues */
				printf("Setting Queuing Method to Software\n");
				sprintf(sLine, "queue_method=\"1\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
			} else {
				/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
				system
				    ("ppacmd control --enable-lan --enable-wan");
				/* Set PPE FW queuing method for all queues */
				printf
				    ("Enabling Routed & Enabling Bridged Acceleration\n");
				/* Set sw queuing method for mgmt traffic */
				printf("Setting Queuing Method to PPE FW\n");
				sprintf(sLine, "queue_method=\"2\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
			}
		} /* End of IFTYPE WAN PTM LOOP */
		if ((iIfType == IFX_MAPI_QoS_WAN_ETH_1) || (iIfType == IFX_MAPI_QoS_LAN_ETH_1))
		{
			if ((class_rate_limit_enb == 0) && !strcmp(platform, "VR9")) 
			{
				model_grx288 =
				    strstr(CONFIG_IFX_MODEL_NAME, "GRX288");
				if ((model_grx288 != NULL) && ((!(strcmp(ppefw, "A5"))) || (!(strcmp(ppefw, "D5")))) && (port_shaping_enable == 0)) 
				{
					/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
					system
					    ("ppacmd control --enable-lan --enable-wan");
					printf
					    ("Enabling Routed & Enabling Bridged Acceleration\n");
					/* Set HW GigFlow queuing method for all queues */
					/* Set sw queuing method for mgmt traffic */
					printf
					    ("Setting Queuing Method to HW GigFlow\n");
					sprintf(sLine, "queue_method=\"3\"\n");
					ifx_SetObjData("/tmp/system_status",
						       "qos_bk", IFX_F_MODIFY,
						       1, sLine);
				} 
				else {
					if ((model_grx288 != NULL) && ((!(strcmp(ppefw, "A5"))) || (!(strcmp(ppefw, "D5")))) && (port_shaping_enable)) 
					{
						//      __LINE__);
						/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
						system
						    ("ppacmd control --enable-lan --enable-wan");
						printf
						    ("Enabling Routed & Enabling Bridged Acceleration\n");
						/* Set PPE FW queuing method for all queues */
						/* Set sw queuing method for mgmt traffic */
						printf
						    ("Setting Queuing Method to PPE FW\n");
						sprintf(sLine,
							"queue_method=\"2\"\n");
						ifx_SetObjData
						    ("/tmp/system_status",
						     "qos_bk", IFX_F_MODIFY, 1,
						     sLine);

					}
					if (red_enable) 
					{
						/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
						system
						    ("ppacmd control --disable-lan --enable-wan");
						printf
						    ("Disabling Routed & Disabling Bridged Acceleration\n");
						/* Enable sw queuing method for all queues */
						printf
						    ("Setting Queuing Method to Software\n");
						sprintf(sLine,
							"queue_method=\"1\"\n");
						ifx_SetObjData
						    ("/tmp/system_status",
						     "qos_bk", IFX_F_MODIFY, 1,
						     sLine);
					} 
					else 
					{
						/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
						system
						    ("ppacmd control --enable-lan --enable-wan");
						printf
						    ("Enabling Routed & Enabling Bridged Acceleration\n");
						/* Set PPE FW queuing method for all queues */
						/* Set sw queuing method for mgmt traffic */
						printf
						    ("Setting Queuing Method to PPE FW\n");
						sprintf(sLine,
							"queue_method=\"2\"\n");
						ifx_SetObjData
						    ("/tmp/system_status",
						     "qos_bk", IFX_F_MODIFY, 1,
						     sLine);
					}
				} /* End of Model = grx loop*/
			}
         else if ((class_rate_limit_enb == 0)
			    && !strcmp(platform, "AR10")) {
				model_grx288 =
				    strstr(CONFIG_IFX_MODEL_NAME, "ARX3");
				if ((model_grx288 != NULL)
				    && ((!(strcmp(ppefw, "A5")))
					|| (!(strcmp(ppefw, "D5"))))
				    && (port_shaping_enable == 0)) {
					// printf("[%s:%d]\n",__FILE__,__LINE__);
					/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
					system
					    ("ppacmd control --enable-lan --enable-wan");
					//printf("Enabling Routed & Enabling Bridged Acceleration\n");
					/* Set HW GigFlow queuing method for all queues */
					/* Set sw queuing method for mgmt traffic */
					//printf ("Setting Queuing Method to HW GigFlow\n");
					sprintf(sLine, "queue_method=\"3\"\n");
					ifx_SetObjData("/tmp/system_status",
						       "qos_bk", IFX_F_MODIFY,
						       1, sLine);
				} else {
					if ((model_grx288 != NULL)
					    && ((!(strcmp(ppefw, "A5")))
						|| (!(strcmp(ppefw, "D5"))))
					    && (port_shaping_enable)) {
						//printf("[%s:%d]\n", __FILE__,
						//      __LINE__);
						/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
						system
						    ("ppacmd control --enable-lan --enable-wan");
						//printf ("Enabling Routed & Enabling Bridged Acceleration\n");
						/* Set PPE FW queuing method for all queues */
						/* Set sw queuing method for mgmt traffic */
						printf
						    ("Setting Queuing Method to PPE FW\n");
						sprintf(sLine,
							"queue_method=\"2\"\n");
						ifx_SetObjData
						    ("/tmp/system_status",
						     "qos_bk", IFX_F_MODIFY, 1,
						     sLine);

					}
					if (red_enable) {
						//printf("[%s:%d]\n", __FILE__, __LINE__);
						/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
						system
						    ("ppacmd control --disable-lan --enable-wan");
						printf
						    ("Disabling Routed & Disabling Bridged Acceleration\n");
						/* Enable sw queuing method for all queues */
						printf
						    ("Setting Queuing Method to Software\n");
						sprintf(sLine,
							"queue_method=\"1\"\n");
						ifx_SetObjData
						    ("/tmp/system_status",
						     "qos_bk", IFX_F_MODIFY, 1,
						     sLine);
					} 
            }
         }
			else 
			{
				if ((red_enable) || (class_rate_limit_enb) || ((strcmp(ppefw, "A5")) && (strcmp(ppefw, "D5")))) 
				{
					/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
					system
					    ("ppacmd control --disable-lan --enable-wan");
					printf
					    ("Disabling Routed & Disabling Bridged Acceleration\n");
					/* Set sw queuing method for all queues */
					printf
					    ("Setting Queuing Method to Software\n");
					sprintf(sLine, "queue_method=\"1\"\n");
					ifx_SetObjData("/tmp/system_status",
						       "qos_bk", IFX_F_MODIFY,
						       1, sLine);
				} 
				else 
				{
					/* Enable Routed Acceleration */
					system
					    ("ppacmd control --enable-lan --enable-wan");
					if (mfc_enable) 
					{
						/* Disable Bridged Acceleration */
						printf
						    ("Enabling Routed & Disabling Bridged Acceleration - Not Proper\n");
						/* TBD: Remove wan bridge interface from ppa */
					} 
					else 
					{
						/* Enable Bridged Acceleration */
						printf
						    ("Enabling Routed & Enabling Bridged Acceleration\n");
						/* TBD: Add wan bridge interface from ppa */
					}
					/* Set PPE FW queuing method for all queues */
					/* Set sw queuing method for mgmt traffic */
					printf
					    ("Setting Queuing Method to PPE FW\n");
					sprintf(sLine, "queue_method=\"2\"\n");
					ifx_SetObjData("/tmp/system_status",
						       "qos_bk", IFX_F_MODIFY,
						       1, sLine);
				} /* End of class rate enable & ppefw loop*/ 
			} /* End of vr9 & class enable loop & ar10 loop*/
		} /*  End of IFTYPE ETH_1 LOOP*/
		if (iIfType == IFX_MAPI_QoS_WAN_ETH_0) 
		{
			if ((red_enable) || (class_rate_limit_enb) || (port_shaping_enable)) 
			{
				/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
				system
				    ("ppacmd control --disable-lan --enable-wan");
				printf
				    ("Disabling Routed & Disabling Bridged Acceleration\n");
				/* Set sw queuing method for all queues */
				printf("Setting Queuing Method to Software\n");
				sprintf(sLine, "queue_method=\"1\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
			} 
			else 
			{
				/* Enable Routed Acceleration */
				system
				    ("ppacmd control --enable-lan --enable-wan");
				/* Disable Bridged Acceleration */
				/* TBD: Remove wan bridge interface from ppa */
				printf
				    ("Enabling Routed & Disabling Bridged Acceleration - not proper\n");
#if 0
				/* Set HW Tantos queuing method for all queues */
				/* Set sw queuing method for mgmt traffic */
				printf("Setting Queuing Method to HW Tantos\n");
				sprintf(sLine, "queue_method=\"4\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
#endif
				/*Manamohan: D5 FW QoS support for MII0  */
            			printf("Setting Queuing Method to PPE FW\n");
            			sprintf(sLine, "queue_method=\"2\"\n");
            			ifx_SetObjData("/tmp/system_status", "qos_bk", IFX_F_MODIFY, 1, sLine);

			} /* End of red & class rate & port shaping LOOP */
		} /* End of IFTYPE ETH_0 LOOP */
		if (iIfType == IFX_MAPI_QoS_WAN_ATM) 
		{
			if ( (strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR10") != 0))
			{
				if(queuing_mode == 1 || (class_rate_limit_enb))
				{
					/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
					system
					    ("ppacmd control --disable-lan --enable-wan");
					printf
					    ("Disabling Routed & Disabling Bridged Acceleration\n");
					/* Set sw queuing method for all queues */
					printf("Setting Queuing Method to Software\n");
					sprintf(sLine, "queue_method=\"1\"\n");
					ifx_SetObjData("/tmp/system_status", "qos_bk",
						       IFX_F_MODIFY, 1, sLine);
				}
				else 
				{
					// TBD: Will be done later
					printf("Not handled yet\n");
				}
			}
			else
			{
				if(queuing_mode == 1)
				{
					/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
					system
					    ("ppacmd control --disable-lan --enable-wan");
					printf
					    ("Disabling Routed & Disabling Bridged Acceleration\n");
					/* Set sw queuing method for all queues */
					printf("Setting Queuing Method to US-Software & DS-Switch\n");
					sprintf(sLine, "queue_method=\"5\"\n");
					ifx_SetObjData("/tmp/system_status", "qos_bk",
						       IFX_F_MODIFY, 1, sLine);
					if(class_rate_limit_enb)
					{
						/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
						system
						    ("ppacmd control --disable-lan --enable-wan");
						printf
						    ("Disabling Routed & Disabling Bridged Acceleration\n");
						/* Set sw queuing method for all queues */
						printf("Setting Queuing Method to US-Software & DS-Switch\n");
						sprintf(sLine, "queue_method=\"1\"\n");
						ifx_SetObjData("/tmp/system_status", "qos_bk",
							       IFX_F_MODIFY, 1, sLine);
					}
				}
				else 
				{
					// TBD: Will be done later
					printf("Not handled yet\n");
				}
			}	
		} /* End of IFTYPE ATM LOOP*/
//		if (iIfType == IFX_MAPI_QoS_LAN_ETH_1) 
//		{
//			if ( /*(red_enable) || */ (class_rate_limit_enb)
//			    /*|| (port_shaping_enable) */
//			    ) {
//				/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
//				system
//				    ("ppacmd control --disable-lan --disable-wan");
//				printf("DownStream QoS\n");
//				printf
//				    ("Cannot support Classifier rate limiting in hardware-switching to software\n");
//				printf
//				    ("Disabling Routed & Bridged Acceleration\n");
//				/* Set sw queuing method for all queues */
//				printf("Setting Queuing Method to Software\n");
//				sprintf(sLine, "queue_method=\"1\"\n");
//				ifx_SetObjData("/tmp/system_status", "qos_bk",
//					       IFX_F_MODIFY, 1, sLine);
//			} else {
//				/* Enable Routed Acceleration */
//				system
//				    ("ppacmd control --enable-lan --enable-wan");
//				printf("DownStream QoS\n");
//				printf
//				    ("Enabling Routed & Bridged Acceleration\n");
//				/* Set HW Tantos queuing method for all queues */
//				/* Set sw queuing method for mgmt traffic */
//				printf("Setting Queuing Method to HW Flow15\n");
//				sprintf(sLine, "queue_method=\"3\"\n");
//				ifx_SetObjData("/tmp/system_status", "qos_bk",
//					       IFX_F_MODIFY, 1, sLine);
//			}
//		} /* End of IFTYP LAN_ETH LOOP */
		if (iIfType == IFX_MAPI_QoS_LAN_PTM) 
		{
			/* If red is enabled and platform is not VR9 then SW. Also since
			   port shaping is not supported in VRX-PTM FW, we will move to
			   software. */
			if ((red_enable) || (class_rate_limit_enb) || ((strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR9") != 0)) 
					|| (port_shaping_enable) || (DS_port_shaping_enable)) 
			{
				/* Disable Routed Acceleration *//* Disable Bridged Acceleration */
				system("ppacmd control --disable-lan --disable-wan");
				printf("Disabling Routed & Disabling Bridged Acceleration\n");
				/* Set sw queuing method for all queues */
				printf("Setting Queuing Method to Software\n");
				sprintf(sLine, "queue_method=\"1\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
			} else {
				/* Enable Routed Acceleration *//* Enable Bridged Acceleration */
				system
				    ("ppacmd control --enable-lan --enable-wan");
				/* Set PPE FW queuing method for all queues */
				printf
				    ("Enabling Routed & Enabling Bridged Acceleration\n");
				/* Set sw queuing method for mgmt traffic */
				printf("Setting Queuing Method to PPE FW\n");
				sprintf(sLine, "queue_method=\"2\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
			}
		} /* End of IFTYPE LAN PTM LOOP */
		if (iIfType == IFX_MAPI_QoS_LAN_ATM) 
		{
			if ( (strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR10") != 0))
			{
				system
				    ("ppacmd control --disable-lan --enable-wan");
				printf("DownStream QoS in ATM Mode \n");
				printf
				    ("Disabling Routed & Bridged Acceleration\n");
				/* Set sw queuing method for all queues */
				printf("Setting Queuing Method to Software\n");
				sprintf(sLine, "queue_method=\"1\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
				       IFX_F_MODIFY, 1, sLine);
			}
			else
			{
				system
				    ("ppacmd control --disable-lan --enable-wan");
				printf("DownStream QoS in ATM Mode \n");
				printf
				    ("Disabling Routed & Bridged Acceleration\n");
				/* Set sw queuing method for all queues */
				printf("Setting Queuing Method to US-Software & DS-Switch\n");
				sprintf(sLine, "queue_method=\"5\"\n");
				ifx_SetObjData("/tmp/system_status", "qos_bk",
					       IFX_F_MODIFY, 1, sLine);
				if(class_rate_limit_enb)
				{
					system
					    ("ppacmd control --disable-lan --enable-wan");
					printf("DownStream QoS in ATM Mode \n");
					printf
					    ("Disabling Routed & Bridged Acceleration\n");
					/* Set sw queuing method for all queues */
					printf("Setting Queuing Method to US-Software & DS-Switch\n");
					sprintf(sLine, "queue_method=\"1\"\n");
					ifx_SetObjData("/tmp/system_status", "qos_bk",
						       IFX_F_MODIFY, 1, sLine);
				}
			}
		}
#endif
/********************************************************************************************************************************************************/
		/* Enable the Required queuing method */
		// printf("Initializing Queues\n");
		//sprintf(command, "/etc/rc.d/ipqos_q_init");
		//system(command);
		
		if(stream_direction == 1)
		{
			sprintf(command, "/etc/rc.d/ipqos_q_init 1");
			system(command);
		}
		if(stream_direction == 2)
		{
			sprintf(command, "/etc/rc.d/ipqos_q_init 2");
			system(command);
		}

		/* Manamohan: WFQ + SP */
		/* Check whether WFQ Scheduling present, if yes create the base class 1:99 and attach the qdisch */
		/* Get Queuing mode */

		//int port_shaping_enable = 0;    
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt",
			       "qm_portRateLimEnab", IFX_F_GET_ENA, 0, sLine);
		port_shaping_enable = atoi(sLine);

		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt",
			       "qm_DSportRateLimEnab", IFX_F_GET_ENA, 0, sLine);
		DS_port_shaping_enable = atoi(sLine);
		
		//int port_rate = 0;    
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim",
			       IFX_F_GET_ENA, 0, sLine);

		port_rate = atoi(sLine);
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim",
			       IFX_F_GET_ENA, 0, sLine);

		down_port_rate = atoi(sLine);

		memset(cmd, 0, 2048);
		tptr = cmd;

		memset(sLine, 0, sizeof(sLine));
		ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk", "queue_method",
			       IFX_F_GET_ENA, 0, sLine);
		queue_method = atoi(sLine);

		if ((queue_method == 1) || (queue_method == 5)) 
		{
			if ((US_enable == 1) && (stream_direction == 1))
			{
				for (i = 0; i < numQueueInst; i++) 
				{
					if (qos_queues[i].enable) 
					{
						if (qos_queues[i].schedType == IFX_MAPI_QoS_Sched_WFQ) 
						{
							ifx_GetObjData
						    	("/tmp/system_status",
						     	"qos_bk", "up_link_rate",
						     	IFX_F_GET_ENA, 0, sLine);
							up_link_rate = atoi(sLine);

							if (qos_queues[i].shaperEnable == 1) 
							{	/* !< enable rateshaping */
								stream_rate =
							    	qos_queues[i].
							    	peakRate;
							}
							if (port_shaping_enable == 1) 
							{
								stream_rate = port_rate;
							} 
							else 
							{
								stream_rate = up_link_rate;	/* How to get this info ??? */
							}

							sprintf(tptr,
								"tc class add dev %s parent 1:1 classid 1:99 htb rate 1kbit ceil %dkbit prio %d; ",
								UPSTREAM_Q_DEV,
								stream_rate,
								qos_queues[i].qPrio -
								1);

							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							sprintf(tptr,
							"tc qdisc add dev %s parent 1:99 handle 99: htb; ",
							UPSTREAM_Q_DEV);

							// move the cmd ptr
							tptr = cmd + strlen(cmd);

							system(cmd);

/* Manamohan,WFQ capped to stream rate */
							memset(cmd, 0, 2048);
							tptr = cmd;
							sprintf(tptr,
								"tc class add dev %s parent 99: classid 99:99 htb rate %dkbit; ",
								UPSTREAM_Q_DEV,
								stream_rate);

							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							system(cmd);
							break;
						}	/* End of WFQ LOOP  */
					}	/* End of Queue enable */
				}	/* End of for loop */
			} /* End of UPSTREAM LOOP */
			
			if ((DS_enable == 1) && (stream_direction == 2 ) && ((strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR10") != 0)))
			{
				for (i = 0; i < LnumQueueInst; i++) 
				{
					if ((Lqos_queues[i].enable) && (Lqos_queues[i].qIfType == IFX_MAPI_QoS_LAN_ETH_1) && (Lqos_queues[i].qIfType == IFX_MAPI_QoS_LAN_PTM)) 
					{
						if (Lqos_queues[i].schedType == IFX_MAPI_QoS_Sched_WFQ) 
						{
							ifx_GetObjData
						    	("/tmp/system_status",
						    	 "qos_bk", "down_link_rate",
						     	IFX_F_GET_ENA, 0, sLine);
							down_link_rate = atoi(sLine);

							if (Lqos_queues[i].shaperEnable == 1) 
							{	/* !< enable rateshaping */
								stream_rate =
							    	Lqos_queues[i].
							    	peakRate;
							}
							if (DS_port_shaping_enable == 1) 
							{
								stream_rate = down_port_rate;
							} 
							else 
							{
								stream_rate = down_link_rate;	/* How to get this info ??? */
							}
						  
                     					sprintf(tptr,
							"tc class add dev %s parent 1:1 classid 1:99 htb rate 1kbit ceil %dkbit prio %d; ",
							DOWNSTREAM_Q_DEV,
							stream_rate,
							Lqos_queues[i].qPrio -
							1);

							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							sprintf(tptr,
							"tc qdisc add dev %s parent 1:99 handle 99: htb; ",
							DOWNSTREAM_Q_DEV);

							// move the cmd ptr
							tptr = cmd + strlen(cmd);


							system(cmd);

                					  /* Manamohan,WFQ capped to stream rate */
							memset(cmd, 0, 2048);
							tptr = cmd;
							sprintf(tptr,
							"tc class add dev %s parent 99: classid 99:99 htb rate %dkbit; ",
							DOWNSTREAM_Q_DEV,
							stream_rate);

							// Attach bfifo disc to this class
							tptr = cmd + strlen(cmd);
							system(cmd);


							break;
						}	/* End of Sched Type  */
					}	/* End of Queue enable */
				}	/* End of for loop */
			}      /* End Downstream*/
		} /* End of Queue Method = 1 LOOP*/
		if ((US_enable == 1) && (stream_direction == 1))
		{
			for (i = 0; i < numQueueInst; i++) 
			{
				int32 index;
				int32 ret;
	/*			if ((qos_queues[i].enable) &&
			   		((qos_queues[i].qIfType == IFX_MAPI_QoS_WAN_ATM) || (qos_queues[i].qIfType == IFX_MAPI_QoS_WAN_PTM))) */ 
				if (qos_queues[i].enable) 
				{
				
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
							 qos_queues[i].iid.
							 cpeId, index)
				    	if (queue_method == 2) 
					{
						if (qos_queues[i].schedType == IFX_MAPI_QoS_Sched_WFQ) 
						{
							sprintf(sLine,
							"queue_wfq_prio=\"%d\"\n",
							qos_queues[i].qPrio);
							ifx_SetObjData
						 	   ("/tmp/system_status",
						 	    "qos_bk", IFX_F_MODIFY, 1,
						 	    sLine);
						}
					}
					//printf("IN QUEUE CFG: stream_direction = 1: calling q_mgmt with 1 : POST !!!!!!!!!!!!!!!!!!!!!!!! \n ");
					sprintf(command, "/etc/rc.d/ipqos_q_mgmt %d 1 %d", index, upstream_queues);
					system(command);

					/* Updating classinfo into the qdisc for QOS Rate Limiting */
					update_qdisc_scaning_classinfo(&qos_queues[i]);

				}
			}
		} /* End of UPSTREAM LOOP */
		//if ((DS_enable == 1) && (stream_direction == 2) && ((strcmp(platform, "VR9") != 0) && (strcmp(platform, "AR10") != 0)))
		if ((DS_enable == 1) && (stream_direction == 2))
		{
			for (i = 0; i < LnumQueueInst; i++) 
			{
				int32 Lindex;
				int32 ret;
				if ((Lqos_queues[i].enable) && ((Lqos_queues[i].qIfType == IFX_MAPI_QoS_LAN_ETH_1) || (Lqos_queues[i].qIfType == IFX_MAPI_QoS_LAN_PTM) || (Lqos_queues[i].qIfType == IFX_MAPI_QoS_LAN_ATM))) 
				{
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
							 Lqos_queues[i].iid.
							 cpeId, Lindex)
				    	sprintf(command, "/etc/rc.d/ipqos_q_mgmt %d 1 %d", Lindex, downstream_queues);
				    	system(command);

					/* Updating classinfo into the qdisc for QOS Rate Limiting */
					update_qdisc_scaning_classinfo(&Lqos_queues[i]);

				}
			}
		} /* End of DOWNSTREAM LOOP */
	} /* End of OPT_QUEUE_CONFIG */

	if (opt == OPT_RATE_UPDATE) {
		ipqos_rate_update();
		ipqos_rate_update_DS();
	}

	if (opt == OPT_CLASS_INIT || opt == OPT_CLASS_DISABLE) {
		char sLine[256]; 
		char sCommand[256];

		/* Get The Current Platform */
		char platform[10];
		
		stream_direction = atoi(vpi);
		
		ifx_GetObjData("/tmp/system_status", "ppe_config_status",
			       "ppe_platform", IFX_F_GET_ENA, 0, sLine);

/*Manamohan: 16 June 2011,Buffer overflow fix */
		if (strlen(sLine) < 10)
			strcpy(platform, sLine);

		/* Get the Current Mode */
		IFX_MAPI_QoS_Interface_Type iIfType;
		iIfType = ifx_mapi_get_active_qos_iface();

		/* Get Red Enable Status */
		int red_enable = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk", "red_enable",
			       IFX_F_GET_ENA, 0, sLine);
		red_enable = atoi(sLine);

		/* Get MFC Enable Status */
		int mfc_enable = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk", "mfc_enable",
			       IFX_F_GET_ENA, 0, sLine);
		mfc_enable = atoi(sLine);

		/* Get DSCP Enable Status */
		int dscp_enable = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk", "dscp_enable",
			       IFX_F_GET_ENA, 0, sLine);
		dscp_enable = atoi(sLine);

		/* Get ONEP Enable Status */
		int onep_enable = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk", "onep_enable",
			       IFX_F_GET_ENA, 0, sLine);
		onep_enable = atoi(sLine);

		/* Get Queue Enable Count */
		int queue_enable_count = 0;
		ifx_GetObjData("/tmp/system_status", "qos_bk",
			       "queue_enable_count", IFX_F_GET_ENA, 0, sLine);
		queue_enable_count = atoi(sLine);

		/* Get the current PPE FW */
		char ppefw[10];
		ifx_GetObjData("/tmp/system_status", "ppe_config_status",
			       "ppe_firmware", IFX_F_GET_ENA, 0, sLine);
		strcpy(ppefw, sLine);

		/* Get Queuing mode */
		int queuing_mode = 0;	// 0->pvc 1->port
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt", "qm_atmQmode",
			       IFX_F_GET_ENA, 0, sLine);
		queuing_mode = atoi(sLine);

		/* Get Queuing mode */
		int port_shaping_enable = 0;	// 0->pvc 1->port
		int DS_port_shaping_enable = 0;	// 0->pvc 1->port
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt",
			       "qm_portRateLimEnab", IFX_F_GET_ENA, 0, sLine);
		port_shaping_enable = atoi(sLine);
		ifx_GetObjData("/flash/rc.conf", "qos_queuemgmt",
			       "qm_DSportRateLimEnab", IFX_F_GET_ENA, 0, sLine);
		DS_port_shaping_enable = atoi(sLine);

		if (iIfType == IFX_MAPI_QoS_WAN_PTM) {
		}
		if ((iIfType == IFX_MAPI_QoS_WAN_ETH_1) || (iIfType == IFX_MAPI_QoS_WAN_PTM) || (iIfType == IFX_MAPI_QoS_WAN_ATM)) 
		{
			if (!strcmp(platform, "AR9")) 
			{
				int def_traffic_class = 0;
				int traffic_class = 0;
#if 0
				if ((def_queue_prio == 1)
				    || (def_queue_prio == 2))
					def_traffic_class = 3;
				if ((def_queue_prio == 3)
				    || (def_queue_prio == 4))
					def_traffic_class = 2;
				if ((def_queue_prio == 5)
				    || (def_queue_prio == 6))
					def_traffic_class = 1;
				if ((def_queue_prio == 7)
				    || (def_queue_prio == 8))
					def_traffic_class = 0;
#else
				if (def_queue_prio == 1)
					def_traffic_class = 3;
				else if (def_queue_prio == 2)
					def_traffic_class = 2;
				else if (def_queue_prio == 3)
					def_traffic_class = 1;
				else
					def_traffic_class = 0;
#endif
				if (opt == OPT_CLASS_INIT) 
				{
					if (!mfc_enable) 
					{
						sprintf(sCommand,
							//"switch_utility_int PortRedirectSet 1 1 0");
							"switch_cli dev=0 IFX_ETHSW_PORT_REDIRECT_SET nPortId=1 bRedirectEgress=1 bRedirectIngress=0");  
						// printf("%s\n",sCommand);
						system(sCommand);

						if (dscp_enable) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_PortCfgSet 0 1 %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_PORT_CFG_SET nPortId=0 eClassMode=1 nTrafficClass=%d", 
								def_traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
						}
						if (onep_enable) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_PortCfgSet 0 2 %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_PORT_CFG_SET nPortId=0 eClassMode=2 nTrafficClass=%d",
								def_traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
						}
						if ((onep_enable)
						    && (dscp_enable)) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_PortCfgSet 0 4 %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_PORT_CFG_SET nPortId=0 eClassMode=4 nTrafficClass=%d",
								def_traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
						}
						if ((!onep_enable)
						    && (!dscp_enable)) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_PortCfgSet 0 0 %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_PORT_CFG_SET nPortId=0 eClassMode=0 nTrafficClass=%d",
								def_traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
							goto IFX_Handler;
						}
						for (i = 0; i < 64; i++) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_DscpClassSet %d %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_DSCP_CLASS_SET nDSCP=%d nTrafficClass=%d",
								i,
								def_traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
						}
						for (i = 0; i < 8; i++) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_PcpClassSet %d %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_PCP_CLASS_SET nPCP=%d nTrafficClass=%d",
								i,
								def_traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
						}
					} 
					else 
					{
						sprintf(sCommand,
							//"switch_utility_int PortRedirectSet 1 1 0");
							"switch_cli dev=0 IFX_ETHSW_PORT_REDIRECT_SET nPortId=1 bRedirectEgress=1 bRedirectIngress=0");
						// printf("%s\n",sCommand);
						system(sCommand);
						sprintf(sCommand,
							//"switch_utility_int QOS_PortCfgSet 0 0 %d",
							"switch_cli dev=0 IFX_ETHSW_QOS_PORT_CFG_SET nPortId=0 eClassMode=0 nTrafficClass=%d",
							def_traffic_class);
						// printf("%s\n",sCommand);
						system(sCommand);
						goto IFX_Handler;
					}
				}

				if (opt == OPT_CLASS_DISABLE) 
				{
					sprintf(sCommand,
						//"switch_utility_int PortRedirectSet 1 0 0");
						"switch_cli dev=0 IFX_ETHSW_PORT_REDIRECT_SET nPortId=1 bRedirectEgress=0 bRedirectIngress=0");
					// printf("%s\n",sCommand);
					system(sCommand);
					sprintf(sCommand,
						//"switch_utility_int QOS_PortCfgSet 0 0 %d",
						"switch_cli dev=0 IFX_ETHSW_QOS_PORT_CFG_SET nPortId=0 eClassMode=0 nTrafficClass=%d",
						def_traffic_class);
					// printf("%s\n",sCommand);
					system(sCommand);
					goto IFX_Handler;
				}

				for (i = 0; i < numClassInst; i++) 
				{
					if (qos_classes[i].enable) 
					{

						for (j = 0; j < numQueueInst;
						     j++) {
							if (qos_queues[j].iid.
							    cpeId.Id ==
							    qos_classes[i].
							    qId) {
#if 0
								if ((qos_queues
								     [j].
								     qPrio == 1)
								    ||
								    (qos_queues
								     [j].
								     qPrio ==
								     2))
									traffic_class
									    = 3;
								if ((qos_queues
								     [j].
								     qPrio == 3)
								    ||
								    (qos_queues
								     [j].
								     qPrio ==
								     4))
									traffic_class
									    = 2;
								if ((qos_queues
								     [j].
								     qPrio == 5)
								    ||
								    (qos_queues
								     [j].
								     qPrio ==
								     6))
									traffic_class
									    = 1;
								if ((qos_queues
								     [j].
								     qPrio == 7)
								    ||
								    (qos_queues
								     [j].
								     qPrio ==
								     8))
									traffic_class
									    = 0;
#else
								if (qos_queues
								    [j].qPrio ==
								    1)
									traffic_class
									    = 3;
								else if
								    (qos_queues
								     [j].
								     qPrio == 2)
									traffic_class
									    = 2;
								else if
								    (qos_queues
								     [j].
								     qPrio == 3)
									traffic_class
									    = 1;
								else
									traffic_class
									    = 0;
#endif
								break;
							}
							continue;
						}

						if (qos_classes[i].mfClass ==
						    IFX_MAPI_QoS_DSCP) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_DscpClassSet %d %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_DSCP_CLASS_SET nDSCP=%d nTrafficClass=%d",
								qos_classes[i].
								dscpCheck,
								traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);

						}
						if (qos_classes[i].mfClass ==
						    IFX_MAPI_QoS_P_Bits) 
						{
							sprintf(sCommand,
								//"switch_utility_int QOS_PcpClassSet %d %d",
								"switch_cli dev=0 IFX_ETHSW_QOS_PCP_CLASS_SET nPCP=%d nTrafficClass=%d",
								qos_classes[i].
								pBitsCheck,
								traffic_class);
							// printf("%s\n",sCommand);
							system(sCommand);
						}
					}
				}

			}
			// else if ((!strcmp(platform,"VR9")) && (!strcmp(ppefw,"D5")))
			model_grx288 = strstr(CONFIG_IFX_MODEL_NAME, "GRX288");
			model_vrx288 = strstr(CONFIG_IFX_MODEL_NAME, "VRX288");
			model_arx300 = strstr(CONFIG_IFX_MODEL_NAME, "ARX3");

			if ((model_grx288 != NULL) || (model_vrx288 != NULL) || (model_arx300 != NULL)) {
				if (opt == OPT_CLASS_INIT) {

					/* enable the current classifier */
					char8 command[256];
							int from_init = 0;
					for (i = 0; i < numClassInst; i++) {
						//if(qos_classes[i].enable) {
							sprintf(command,
								"/etc/rc.d/ipqos_hw_class %d %d 1",
								i, from_init);
						IFX_DBG
						    ("[%s:%d] US Class Add Inst: %d",
						     __func__, __LINE__, i);
							system(command);
						//}
					}
					for (i = 0; i < WnumClassInst; i++) {
						//if(qos_classes[i].enable) {
							sprintf(command,
								"/etc/rc.d/ipqos_hw_class %d %d 2",
								i, from_init);
						IFX_DBG
						    ("[%s:%d] DS Class Add Inst: %d",
						     __func__, __LINE__, i);
							system(command);
						//}
					}

				}

				if (opt == OPT_CLASS_DISABLE) {
					/* Disable the current classifier */
					char8 command[256];
					//for(i = 0; i < numClassInst; i++)
					if(stream_direction == 1)
					{ 
						for (i = 0; i < numClassInst; i++) {
							if (qos_classes[i].enable) {
								sprintf(command,
									"/etc/rc.d/ipqos_US_class_delete %d",
									i);
								IFX_DBG
								    ("[%s:%d] Class Del Inst: %d",
								     __func__, __LINE__,
								     i);
								system(command);
							}
						}
					}
					if(stream_direction == 2)
					{
               					for (i = 0; i < WnumClassInst; i++) {
							if (Wqos_classes[i].enable) {
								sprintf(command,
									"/etc/rc.d/ipqos_DS_class_delete %d",
									i);
								IFX_DBG
								    ("[%s:%d] Class Del Inst: %d",
								     __func__, __LINE__,
								     i);
								system(command);
							}
						}
					}

					goto IFX_Handler;
				}

			}
		}
		if (iIfType == IFX_MAPI_QoS_WAN_ETH_0) {
		}
		if (iIfType == IFX_MAPI_QoS_WAN_ATM) {
		}

	}

      IFX_Handler:

	if (prio != NULL)
		free(prio);

	// freeing the queue list
	if (qos_queues != NULL)
		free(qos_queues);
	if (Lqos_queues != NULL)
		free(Lqos_queues);
	if (qos_classes != NULL) {
/* Manamohan,14 June 2011, corrected the parameter to free as per Klocwork report  */
		/* free(qos_queues); */
		free(qos_classes);
	}
	if (Wqos_classes != NULL) {
		free(Wqos_classes);
	}
   if (dsprio != NULL) {
      free(dsprio);
   }

}

int main(int argc, char *argv[])
{
	int c;
	int ret = 0;
   int semid =0;
	semid = init_sem(SEMAPHORE_KEY);
	if (enter_critical_section(semid) == 0) {

	while (1) {
		static struct option long_options[] = {
			{"Add", required_argument, 0, 'a'},
			{"Delete", required_argument, 0, 'd'},
			{"Modify", required_argument, 0, 'm'},
			{"InsertAll", required_argument, 0, 'i'},
			{"FlushAll", required_argument, 0, 'f'},
			{"Prio", required_argument, 0, 'p'},
			{"FlagInit", required_argument, 0, 'c'},
			{"FlagUpdate", required_argument, 0, 'u'},
			{"QueueConfig", required_argument, 0, 'q'},
			{"RateUpdate", required_argument, 0, 'r'},
			{"ClassInit", required_argument, 0, 's'},
			{"ClassDisable", required_argument, 0, 't'},
			{"StreamAdd", required_argument, 0, 'w'},	/* Option for Adding a
									   Stream for QOS Rate
									   Limiting */
			{"StreamDelete", required_argument, 0, 'x'},	/* Option for
									   Deleting a
									   Stream for
									   QOS Rate
									   Limiting */
			{"Help", no_argument, 0, 'h'},
			{0, 0, 0, 0}
		};

		int option_index = 0;

		c = getopt_long(argc, argv, "a:d:m:i:f:p:c:u:q:r:s:t:w:x:h",
				long_options, &option_index);
		if (c == -1)
			break;

		switch (c) {
		case 'a':
//          printf ("option -a with value `%s'\n", optarg);
			queuepvc(optarg, OPT_ADD);
			break;

		case 'd':
//          printf ("option -d with value `%s'\n", optarg);
			queuepvc(optarg, OPT_DEL);
			break;

		case 'm':
//          printf ("option -m with value `%s'\n", optarg);
			queuepvc(optarg, OPT_MOD);
			break;

		case 'i':
//          printf ("option -i with value `%s'\n", optarg);
			queuepvc(optarg, OPT_ADD_ALL);
			break;

		case 'f':
//          printf ("option -f with value `%s'\n", optarg);
			queuepvc(optarg, OPT_DEL_ALL);
			break;

		case 'p':
//          printf ("option -p with value `%s'\n", optarg);
			queuepvc(optarg, OPT_PRIO);
			break;

		case 'c':
//          printf ("option -c with value `%s'\n", optarg);
			queuepvc(optarg, OPT_FLAG_INIT);
			break;

		case 'u':
//          printf ("option -u with value `%s'\n", optarg);
			queuepvc(optarg, OPT_FLAG_UPDATE);
			break;

		case 'q':
//          printf ("option -q with value `%s'\n", optarg);
			queuepvc(optarg, OPT_QUEUE_CONFIG);
			break;

		case 'r':
//          printf ("option -r with value `%s'\n", optarg);
			queuepvc(optarg, OPT_RATE_UPDATE);
			break;

		case 's':
//          printf ("option -s with value `%s'\n", optarg);
			queuepvc(optarg, OPT_CLASS_INIT);
			break;

		case 't':
//          printf ("option -t with value `%s'\n", optarg);
			queuepvc(optarg, OPT_CLASS_DISABLE);
			break;

		case 'w':
//          printf ("option -w with value `%s'\n", optarg);
			ret = queuesm(optarg, OPT_CQMAP_ADD);
			IFX_DBG("%s: Class Addd Inst: %d", __func__, ret);
			break;

		case 'x':
//          printf ("option -x with value `%s'\n", optarg);
			ret = queuesm(optarg, OPT_CQMAP_DEL);
			break;

		case 'h':
//          printf ("option -h\n");
			help_fn(argv[0]);
			break;

		default:
			break;
		}
	}

	/* Print any remaining command line arguments (not options). */
	if (optind < argc) {
		printf("non-option ARGV-elements: ");
		while (optind < argc)
			printf("%s ", argv[optind++]);
		putchar('\n');
	}
	exit_critical_section(semid);
	}

	return ret;
}
