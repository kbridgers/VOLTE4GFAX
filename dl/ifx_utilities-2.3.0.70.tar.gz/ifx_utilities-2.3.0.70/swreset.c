#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <ifx_config.h>
#include <string.h>
#include <common.h>

#ifdef IFX_MULTILIB_UTIL
#define	main	swreset_main
#endif

int main(int argc, char *argv[])
{
	fd_set rfds;
	struct timeval tv;
	int retval;
	int fd;
	char buf[10];

	fd = open("/dev/sw_reset", O_RDONLY | O_NONBLOCK);

	while (1) {
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);

		retval = select(fd + 1, &rfds, NULL, NULL, NULL);

		if (FD_ISSET(fd, &rfds)) {
			read(fd, buf, 10);
			retval = atoi(buf);
			printf("%s: Reset button pressed.. %d.%d seconds\n", argv[0], retval / 10, retval % 10);

			if ((retval / 10) < 10) {
				/* Normal Reset */
				printf("%s: Initiating soft-reset..\n", argv[0]);
				system("/etc/rc.d/rebootcpe.sh 3");
			} else {
				/* Factory Default */

				printf("%s: Initiating factory defaults reset..\n", argv[0]);
				system("/usr/sbin/factorycfg.sh");
			}
		}
	}
	close(fd);
	return 0;
}

