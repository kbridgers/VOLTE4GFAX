
#ifndef BATCH_UPGRADING_H
#define BATCH_UPGRADING_H

#include <sys/socket.h>
#include <sys/select.h>
// #include <linux/in.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdint.h>
#include <signal.h>

#undef x86

#define APP_FALSE -1
#define APP_TRUE   1
#define APP_REBOOT 0

#define PACKAGE_ID_LEN 			22
#define SW_PROD_ID_LEN 			20
#define PARTITION_NAME_LEN 		20
#define WAIT_TIME_MIN			15	/*   With in 15 min it should get complete firmware 
						   other wise it will start from beginning   */

#define CON_TIME_OUT			5
#define MAX_WAIT_CNT(_min)		((_min)*(60 / CON_TIME_OUT))

#define BATCH_UPGRADING_CHUNK_SIZE 	2048
#define chain_buf_firmware_upgrade(_buf,_filelen,_socket_fd)
//#define free_chain_buf(x) 

#define get_bat_up_status() 		(1)

#define LISTEN_PORT			13456
#define MCASTGRP			"224.0.0.119"

#define  u32 unsigned int
#define u16 unsigned short
#define u8 unsigned char

#define PARTITION_DESC_PKT_ID 		0x80
#define IMAGE_DATA_PKT_ID		0x20
#define BATC_UPGD_STACK_SIZE 		6144
#define MAX_PARTITION_INFO		32
#define MAX_IMAGE_DATA			2048

#ifndef offsetof
#define offsetof(_struct, _member) 	(int )&(((struct _struct *)0)->_member)
#endif

#define cpu_to_le32(_x)								\
({										\
	typeof(_x) tmp = (_x), out;						\
        out = ((unsigned int)( 							\
                (((unsigned int)(tmp) & (unsigned int)0x000000ffUL) << 24) | 	\
                (((unsigned int)(tmp) & (unsigned int)0x0000ff00UL) <<  8) | 	\
                (((unsigned int)(tmp) & (unsigned int)0x00ff0000UL) >>  8) | 	\
                (((unsigned int)(tmp) & (unsigned int)0xff000000UL) >> 24) ));	\
})

#undef DEBUG

#ifdef DEBUG
#define	MUPG_DBG(fmt, args...)		printf("[%s:%d]"fmt"\n",__FUNCTION__,__LINE__,##args)
#else
#define MUPG_DBG(fmt, args...)
#endif

#ifndef x86
#define SHOW_PKT(_pkt) MUPG_DBG("received pkt:\n"				\
       				"id 	 	= 0x%x\n"			\
       				"pkt_len 	= %u\n"				\
           			"pkt_seq 	= %u\n"				\
            			"crc	 	= 0x%x\n"			\
            			"img_file_len 	= %u\n"				\
            			"img_crc	= 0x%x\n"			\
            			"package_id	= %s\n"				\
            			"sw_prod_id	= %s\n",			\
				(_pkt)->id,					\
				(_pkt)->pkt_len,				\
		                cpu_to_le32((_pkt)->pkt_seq),			\
				cpu_to_le32((_pkt)->crc),			\
				cpu_to_le32((_pkt)->img_file_len),		\
				cpu_to_le32((_pkt)->img_crc),			\
				(_pkt)->package_id,				\
				(_pkt)->sw_prod_id)

#else
#define SHOW_PKT(_pkt) MUPG_DBG("received pkt:\n"				\
       				"id 	 	= 0x%x\n"			\
       				"pkt_len 	= %u\n"				\
           			"pkt_seq 	= %u\n"				\
            			"crc	 	= 0x%x\n"			\
            			"img_file_len 	= %u\n"				\
            			"img_crc	= 0x%x\n"			\
            			"package_id	= %s\n"				\
            			"sw_prod_id	= %s\n",			\
				(_pkt)->id,					\
				(_pkt)->pkt_len,				\
		                (_pkt)->pkt_seq,			\
				(_pkt)->crc,			\
				(_pkt)->img_file_len,		\
				(_pkt)->img_crc,			\
				(_pkt)->package_id,				\
				(_pkt)->sw_prod_id)

#endif

#ifndef TFTP_CHUNK_SIZE

typedef struct chain_buf {	/*which hold the total image in a linked list */
	struct chain_buf *next;
	int len;
	char buffer[BATCH_UPGRADING_CHUNK_SIZE];
} chain_buf;
#else
typedef struct tftp_buf chain_buf;

#endif

#define dont_align

typedef struct partition_info_table {	/*      BATCH upgrading PKT format      */
	u8 part_name[PARTITION_NAME_LEN];
	u32 start_addr;
	u32 end_addr;
	u32 addr_opt:8;
	u32 reserved:24;
} partition_info_table dont_align;

typedef union pkt_data {	/*partition info / image data           */
	partition_info_table part_info[MAX_PARTITION_INFO];
	u8 img_data[MAX_IMAGE_DATA];
} pkt_data_t dont_align;

typedef struct pkt_format {	/*packet structure                      */

	u32 pkt_len:24;		/*packet len            */
	u32 id:8;		/*ID                    */
	u32 pkt_seq;		/*packet seq. no.       */
	u32 crc;		/*packet CRC            */

	u32 img_file_len;	/*image file len        */

	u32 img_crc;		/*image CRC             */

	u8 package_id[PACKAGE_ID_LEN];
	u8 sw_prod_id[SW_PROD_ID_LEN];
	pkt_data_t pkt_data;	/*payload               */
} pkt_format dont_align;

/**********************************************************************
				upgrade
**********************************************************************/
#define TEMP_BUF	4096
#define	RESTART_PROCESS_FILE	"/tmp/restart_porcess.sh"
#define	UPGRADE_IMG	"/ramdisk/upgrade_image"

#endif
