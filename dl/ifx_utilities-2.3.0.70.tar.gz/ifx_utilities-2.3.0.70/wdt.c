#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#define _GNU_SOURCE
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include <asm/amazon_s/amazon_s_wdt.h>

#define WDT_DEVICE	"/dev/wdt"
#define TIMEOUT		60

#ifdef IFX_MULTILIB_UTIL
#define	main	wdt_main
#endif

static int wdt_fd = -1;
static int timeout = TIMEOUT;
static int pwl = 3;
static int clkdiv = 3;

static int help()
{
	int i = 0;
	printf("Usage:\n");

	printf("wdt <-t seconds>\n");
	printf("  Option:\n");
	printf("    t: Specific watchdog timeout duration in seconds.\n");
	printf("       Default is 60 seconds if not specified.\n");
	return i;
}

static void watchdog_shutdown(int sig)
{
	if (wdt_fd >= 0) {
		ioctl(wdt_fd, AMAZON_S_WDT_IOC_STOP);
		close(wdt_fd);
	}
	exit(0);
}

int main(int argc, char *argv[])
{
	int opt = -1;
	int incr = -10;
	int ret = -1;
	struct option longopts[] = {
		{"help", 0, NULL, 'h'},
		{"timeout", 1, NULL, 't'},
		{0, 0, 0, 0}
	};

	while ((opt = getopt_long(argc, argv, "ht:", longopts, NULL)) != -1) {
		switch (opt) {
		case 'h':
			help();
			return 0;
		case 't':
			if (optarg != NULL)
				timeout = atoi(optarg);
			break;
		case ':':
			printf("option needs a value\n");
			break;
		default:
		case '?':
			printf("unknow option: %c\n", optopt);
			goto err_out;
		}
	}

	signal(SIGHUP, watchdog_shutdown);
	signal(SIGINT, watchdog_shutdown);
	signal(SIGKILL, watchdog_shutdown);
	signal(SIGTERM, watchdog_shutdown);

	wdt_fd = open(WDT_DEVICE, O_RDWR, 0);
	if (wdt_fd < 0) {
		printf("[%s]:[%d] - ERROR opening %s\n", __FUNCTION__, __LINE__,
		       WDT_DEVICE);
		return -1;
	}

	ret = ioctl(wdt_fd, AMAZON_S_WDT_IOC_SET_PWL, &pwl);
	ret = ioctl(wdt_fd, AMAZON_S_WDT_IOC_SET_CLKDIV, &clkdiv);
	ret = ioctl(wdt_fd, AMAZON_S_WDT_IOC_START, &timeout);
	if (ret != 0) {
		printf("[%s]:[%d] - Can not start watchdog!\n", __FUNCTION__,
		       __LINE__);
		return -1;
	}
	ret = nice(incr);
	if (ret == -1) {
		printf("[%s]:[%d] - Can not set watchdog to higher priority!\n",
		       __FUNCTION__, __LINE__);
	}
	while (1) {
		sleep(timeout / 2);
		ioctl(wdt_fd, AMAZON_S_WDT_IOC_PING);
	}
	close(wdt_fd);
	return 0;
      err_out:
	if (wdt_fd >= 0)
		close(wdt_fd);
	help();
	return -1;
}
