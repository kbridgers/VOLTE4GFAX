/*
 **************************************************************************
 *       file       : rcCnf_crypt.c                                       *
 *       Description: Module to encrypt the selected strings in conf file *
 *       Author     : UDAYA SHANKARA KS, RTSS Team                        *
 *       Date       : Wed Aug 22 12:15:19 IST 2012                        *
 **************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "rcCnf_crypt.h"


#ifdef CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION
// Encrypting/Decryption key for OTP algorithm
extern int key[];     

// Section sub items for system_password items in rc.conf 
struct st_subSec st_system_passwd[]=
{
   { "Password", CRYPT_BASE64_ENCODING, key}
};

// Section sub items for user_obj section in rc.conf 
struct st_subSec st_user_obj[]=
{
  { "_password",CRYPT_BASE64_ENCODING,key}
};

// Section sub items for auto_wan_detect_cfg in rc.conf 
struct st_subSec st_auto_detect_cfg[] = 
{
   { "auto_detect_ppp_pass", CRYPT_BASE64_ENCODING, key}
};

// Setion sub items for wan_ppp section in rc.conf 
struct st_subSec st_wan_ppp[] = 
{
   { "_passwd", CRYPT_BASE64_ENCODING, key}
};

// Handler for Section info in rc.conf  
t_crypt_st ltq_crypt_st[] =
{
 // { "system_password", st_system_passwd, 1 },
//  { "user_obj",st_user_obj,1},
  { "auto_detect_cfg", st_auto_detect_cfg,1},
  { "wan_ppp", st_wan_ppp, 1 }
};

//
// ltq_cryptString
//  function to encrypt the string with perticular enc type
//
int ltq_cryptString( char *out_buf, char * in_buf, t_crypt_type_en type, void *key)
{
   char *p,*q,*ptr;
   char buf[512];
   ltq_crypt    cb_cryptfun = NULL;
   int *key_buf = (int*)key;
   

   for (p = in_buf,q=out_buf; *p != '=' && *p != '\n' ; ){
     *q++ = *p++;
   }

   if(*p != '\n' && *p != '\0')
      *q++ = *p++;

   p++;

   /* Handling for empty string */
   if (*p == '"'){
     // *q++ = *p++;
      strcpy(q,"\"\"");
      return 0;
   } else {
      for ( ptr = p ; *ptr != '"' && *ptr != '\0' && *ptr != '\n'; ptr++);
      *ptr = '\0';
   }
   

   switch( type )
   {
    case  CRYPT_ONE_PADDING:
          cb_cryptfun = encrypt_OTP;
          break;

    case  CRYPT_BASE64_ENCODING:
          cb_cryptfun = encode_base64;
          break;

    default:
          break;
   }


   if (cb_cryptfun)
      cb_cryptfun( buf,p,strlen(p),key_buf);

   sprintf(q,"\"%s\"",buf);
   return 0; 
}

// 
//  ltq_updateSection
//    function to update the encrypted section 
//
int ltq_updateSection( FILE *fp,struct st_subSec * subSec, char *secBuf, int buf_len )
{

  char *p = secBuf,*q;
  char line_buf[512];
  char out_buf[512];
  int idx,found = 0;


  while((q = strchr(p,'\n'))){
    strncpy(line_buf,p,q-p); 
    line_buf[q-p] = '\0';
    p = (q+1);

    if (strstr(line_buf,"#>> ")){
      fprintf(fp,"%s\n\n",line_buf);
      break;
    }
    else if (strstr(line_buf,"#<< ")){
      fprintf( fp,"%s\n",line_buf);
      continue;
    }

    for ( idx = 0,found = 0 ; idx < buf_len ; idx++){
      if (strstr(line_buf,subSec[idx].subSecName)){
          found = 1; 
          break;
      }
    }

    if ( found ){
       ltq_cryptString( out_buf,line_buf, subSec[idx].crypt_type,subSec[idx].key);
       fprintf( fp,"%s\n",out_buf);
    }else{
       fprintf( fp ,"%s\n",line_buf);
    }
  }

  return 0;
}

// 
//  get_Section 
//   function to get the section 
//
char* get_Section( FILE *fp,char *buf, char *secName )
{
   char *p = buf,*q;
   char *ptr_buf, *secBuf;
   char line_buf[BUF_LENGTH];
   int buf_cnt = 0;

   p = strstr( buf,"#<< ");
   for ( q = secName; !isspace(*p); )
       *q++ = *p++;
  
   *q = '\0';

   secBuf = (char*)malloc( 512);
   if(!secBuf){
     dbg_error("ERROR: malloc");
     return NULL;
   }

   ptr_buf = secBuf;
   sprintf(secBuf,"%s",buf);
   buf_cnt += strlen(buf);

   while( fgets( line_buf, BUF_LENGTH, fp)){
     buf_cnt += strlen(line_buf);
     if (buf_cnt > BUF_LENGTH){
       secBuf = realloc( secBuf,buf_cnt ); 
     }

     strcat( secBuf ,line_buf);
     if ( strstr( line_buf,"#>> ")){
        if (buf_cnt >= BUF_LENGTH)
          secBuf = realloc( secBuf,buf_cnt+2 ); 
        strcat(secBuf ,"\n");
        break;
     }
   }

   return secBuf;
}
    

//
// get_crpptFileEnc
//   function to encrypt the rc.conf file 
//        parameters
//
int get_cryptFileEnc( char *in_fname )
{
//   char *in_fname;
   char out_fname[50];
   FILE *ifp,*ofp;
   char line_buf[BUF_LENGTH];
   char secName[50];
   char *secBuf;
   int sec_idx;

/*
   if (argc < 2){
     in_fname = FILE_RC_CONF;
   } else {
     in_fname = argv[1];
   }
   if (argc < 3){
     sprintf(out_fname,"%s_crypt",in_fname);
   } else {
     strcpy( out_fname, argv[2]);
   }
*/

   if ( in_fname == NULL ){
     in_fname = FILE_RC_CONF;
   }
   sprintf(out_fname,"%s_crypt",in_fname);
   ifp = fopen( in_fname,"r");
   if (!ifp ){
     dbg_error("Unable to open file %s \n", in_fname );
     return -1;
   }  

   ofp = fopen( out_fname,"w+");
   if(!ofp){
     dbg_error("Unable to open file %s \n", out_fname);
     fclose( ifp );
     return -2;
   }


  while( fgets( line_buf, BUF_LENGTH, ifp ) ){
    if (!strstr( line_buf,"#<< ") )
       continue; 

    secBuf = get_Section( ifp,line_buf,secName );

    for ( sec_idx = 0; sec_idx < SEC_LENGTH ; sec_idx++){
      if ( strstr( line_buf,ltq_crypt_st[sec_idx].secName ))
         break;
    }

    if( sec_idx < SEC_LENGTH)
         ltq_updateSection( ofp,ltq_crypt_st[sec_idx].sub_Sec,secBuf,ltq_crypt_st[sec_idx].sub_len );
    else 
       fprintf(ofp,"%s",secBuf );
        
    fflush(ofp);
    free(secBuf);
  }

  fclose(ifp);
  fclose(ofp);
  rename( out_fname,in_fname);
  return 0;
}
#endif //parameter encryption macro
