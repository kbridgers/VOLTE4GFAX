/*
 * rc.conf sanity checker
 *
 * Copyright (C) 2012, Lantiq Inc., All rights reserved.
 * alexander.abraham@lantiq.com
 *
 */

#include <stdio.h>
#include <string.h>

#define BUFSIZE 8192
#define VARSIZE 1024
#define DATSIZE 7168

#ifdef IFX_MULTILIB_UTIL
  #define main rcconf_chk_main
#endif

typedef unsigned char bool;

#define DENYSYMBOLS_MEM "\\/?\'\"# \t"
#define DENYSYMBOLS_VAL "\'\"# \t"

/* True if string is empty */
static bool is_empty (char *s)
{
	while ((*s != '\n') && (*s != '\0')) {
		if ((*s != '\t') && (*s != ' ')) return (0);
		s++;
	}
        return (1);
}

/* True if variable is clean without special symbols */
static bool clean_var (char *s, char *err_c)
{
	//char *err_c = "\\/?\'\"#- \t";
	char *p = err_c;
	while ((*s != '\n') && (*s != '\0')) {
		while (*p != '\0') {
			if (*p++ == *s) return (0);
		} s++; p = err_c;
	}
	return (1);
}

/* True if string terminated with proper quotes '' or ""
   and also true if quotes not used, but data is proper without spaces*/
static bool have_quotes (char *s)
{
	char q = *s;
	bool cnt = 0;
	unsigned int esc = 0; /* to find if escape char '/' used before quotes */
	if ((q != '\'') && (q != '\"')) { /* Check if string donot start with single or double quotes */
		if (clean_var(s, DENYSYMBOLS_VAL)) return (1); /* if not, then data must be clean without
								spaces or special symbols */
		else return (0);
	}
	/* If string starts with single or double quotes, then verify proper termination quotes */
	while ((*s != '\n') && (*s != '\0')) {
		s++;
		if(cnt) { /* proper termination quote found. Now there should not be any
				other characters after this. */
			/* if((*s != ' ') && (*s != '\t') &&  Use this also if you need to ignore white spaces
					after termination */
			if((*s != '\n') && (*s != '\0')) return (0);
		}
		if (*s == q) { /* A termination qoute found, now check if it is used with escape char '/' */
			if ((esc % 2) == 0) cnt = 1; /* total used escape char '/' in sequence is an even number,
							then termination qoute is valid */
			esc = 0;
		} else if (*s == '\\') esc++; else esc = 0; /* Count used escape chars '/' if comes in sequence */
	}
	return (cnt);
}

int main (int argc, char *argv[])
{
	FILE *fp = NULL;

	char buf[BUFSIZE];
	char var[VARSIZE];
	char data[DATSIZE];

	bool chk_flg = 0, ret = 0;
	size_t count = 0;

	if (argc == 2) {
		fp = fopen (argv[1], "r");
	} else {
		printf ("%s: Usage: %s <rc.conf file>\n", argv[0], argv[0]);
		return (1);
	}

	if (fp != NULL) {
		while (!feof(fp)) {
			if (fgets (buf, BUFSIZE, fp) != NULL) {
				count++;
				if (strncmp (buf, "#<< ", 4) == 0) {
					if ((chk_flg == 0) || (chk_flg == 2)) chk_flg = 1;
					else { ret = 1; break; }
				} else if (strncmp (buf, "#>> ", 4) == 0) {
					if (chk_flg == 1) chk_flg = 2;
					else { ret = 1; break; }
				} else if ((buf[0] == '\n') || (buf[0] == '#') || (is_empty(buf))) {
					//continue
				} else if (sscanf (buf, "%[^=]=%[^\n]", var, data) == 2) {
					if (!have_quotes(data)) { ret = 1; break; }
					if (!clean_var(var, DENYSYMBOLS_MEM)) { ret = 1; break; }
				} else {
					ret = 1; break;
				}
			}
		}
	} else {
		printf ("%s: Unable to open the file %s !\n", argv[0], argv[1]);
		return (2);
	}

	fclose (fp);
	if (ret == 0) {
		if (chk_flg == 2) ret=0; else ret=1;
	}

	if (ret) {
		printf ("%s: Error line: %zu\n", argv[0], count);
	}
	
	return (ret);
}
