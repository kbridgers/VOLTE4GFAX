/*
 **************************************************************************
 *       file       : rcCnf_crypt.h                                       *
 *       Description: header to encrypt the selected strings in conf file *
 *       Author     : UDAYA SHANKARA KS, RTSS Team                        *
 *       Date       : Wed Aug 22 12:15:19 IST 2012                        *
 **************************************************************************
 */

#ifndef __RCCONF_CRYPT_H_
#define __RCCONF_CRYPT_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "ifx_config.h"


#ifdef CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION

#define FILE_RC_CONF   "/flash/rc.conf"

#define SEC_LENGTH   (sizeof(ltq_crypt_st)/sizeof(ltq_crypt_st[0]))
#define BUF_LENGTH    (512 )

#define dbg_error printf

// Call back function for encryption and decryption
typedef int(*ltq_crypt)(char *dst, const char *src, int len,void *key );

// enum types for encrypting the strings
typedef enum 
{
   CRYPT_ONE_PADDING,                       // One time padding 
   CRYPT_BASE64_ENCODING,                   // customised base64 encoding
   CRYPT_AES,                               // AES crypt
   CRYPT_MD5                                // MD5 crypt
}t_crypt_type_en;

// Subsection structure 
struct st_subSec
{
   char                   *subSecName ;     // Sub section Name
   t_crypt_type_en         crypt_type;      // encryption type
   void                   *key;             // Encryption key
};

// Handler for crypt
typedef struct __crypt
{
   char                   *secName ;        // Section name
   struct  st_subSec      *sub_Sec;         // struct for sub section 
   int                     sub_len;         // sub section len 
}t_crypt_st;

// function to encrypt the data using  One time padding algorithm
extern int encrypt_OTP( char *out_buf, const char * in_buf, int len ,void *key );

// function to encryp the dat using customised base64 encoding.
extern int encode_base64( char *out_buf, const char *in_buf, int len , void *key);

// function to encrypt the string 
int ltq_cryptString( char *out_buf, char * in_buf, t_crypt_type_en type, void *key);

// function to update the matched section 
int ltq_updateSection( FILE *fp,struct st_subSec * subSec, char *secBuf, int buf_len );

// function to get the section 
char* get_Section( FILE *fp,char *buf, char *secName );

// function to udpate the rc.conf parameters.
int get_cryptFileEnc( char *in_fname );
#endif
#endif //PARAMETER_ENCRYPTION MACRO
