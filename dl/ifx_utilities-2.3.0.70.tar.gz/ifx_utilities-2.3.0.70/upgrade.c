//303002:JackLee 2005/06/16 Fix_webUI_firmware_upgrading_causes_webpage_error_issue 

/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   upgrade.c
 * Author :     Nirav Salot
 * Date: 		14th January, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This implements the image upgrade facility for Amazon devices
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */

#include "ifx_common.h"
#include "common.h"
#include <sys/ioctl.h>
#include<ctype.h>
#include<unistd.h>

#define SEMAPHORE_KEY 1238
#include <errno.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#define MAX_RETRIES 3
#define MICRO_SEC_INTERVAL 100
//#define DBG_ENABLED

#ifdef IFX_MULTILIB_UTIL
#define main	upgrade_main
#endif

//#include <toolchain/version.h>
#define TOOL_CHAIN_VERSION "4.3.3+cs/0.9.30.1"
#define VERSION             "1.0.5"

#include "cmd_upgrade.h"
#include "command.h"
#include <sys/stat.h>
#include <signal.h>
#include <sys/reboot.h>
#define FILE_U_LOCK      "/tmp/u_lock"

int do_upgrade(int file_fd, int srcLen);
extern int upgrade_img(ulong, ulong, char *, enum ExpandDir dir, int);
extern int32 image_file_preprocessing_hook_fn(char8 * imgName, uint32 imgLen,
					      uint32 * offset, uint32 * newLen);

env_t env;

#ifdef CONFIG_FEATURE_IFX_WIRELESS
#ifndef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
/* Possible interfaces: eth0(br0), usb0 (device, host), wlan0..4 (1- AP, 4 - VAPs) */
#define IFX_MAX_LAN_MAC_ADDR	7
#else
#define IFX_MAX_LAN_MAC_ADDR    2
#endif
#else
/* Possible interfaces: eth0(br0), usb0 (device, host) */
#define IFX_MAX_LAN_MAC_ADDR	2
#endif

/* Possible interfaces corresponding to WAN1 - WAN15 */
#define IFX_MAX_WAN_MAC_ADDR	15

void mac_usage()
{
	printf("\nEnter MAC Address in xx:xx:xx:xx:xx:xx format Only!\n \
		where xx should be in the range [0-9][A-F]\n");
}

int ValidateMACAddress(unsigned char *mac)
{
	int i, j;
	unsigned char str[12], value[15];
	unsigned int mac_val = 0;

	memset(str, 0x00, sizeof(str));
	memset(value, 0x00, sizeof(value));

	if (mac == NULL) {
		printf("Null MAC Address\n");
		mac_usage();
		return -1;
	}
	/* Total MAC Address Len should be <=17 */
	else if (strlen((const char *)mac) > 17) {
		printf("Invalid MAC Address length\n");
		mac_usage();
		return -1;
	} else {
		/* Tokenize each field in MAC Address seperator 
		 * Seperator ':' is only handled */
		for (i = 2, j = 0; i <= 17; i += 3) {
			str[j] = mac[i - 2];
			j++;
			str[j] = mac[i - 1];
			j++;
			if (mac[i] != ':' && i < 17) {
				printf("Wrong MAC Address Format\n");
				mac_usage();
				return -1;
			}
		}
	}

	/* Validate each filed in MAC Address 
	 * The fileds should be in the range [0-9][A-F] */
	for (i = 0; i < 12; i++) {
		if (isalpha(str[i]))
			str[i] = toupper(str[i]);
		if ((str[i] < '0') || (str[i] > '9')) {
			if ((str[i] < 'A') || (str[i] > 'F')) {
				printf("Wrong MAC Address Fields\n");
				mac_usage();
				return -1;
			} else {
				if ((str[i] >= 'A') && (str[i] <= 'F'))
					str[i] -= ('A' - 10);
			}
		} else {
			if ((str[i] >= '0') && (str[i] <= '9'))
				str[i] -= '0';
		}
	}

	/* Sum up each Byte in MAC Address */
	for (i = 0; i < 12 / 2; i++) {
		value[i] = (str[i << 1] << 4) + str[(i << 1) + 1];
		mac_val += value[i];
	}

	if (mac_val) {
		/* Check if any address is a MAC broadcast address FF:FF:FF:FF:FF:FF 
		 * mac_val + IFX_MAX_LAN_MAC_ADDR + IFX_MAX_WAN_MAC_ADDR >= FF:FF:FF:FF:FF:FF
		 * MAC Address is a broadcast */
		if ((mac_val + IFX_MAX_LAN_MAC_ADDR + IFX_MAX_WAN_MAC_ADDR) >=
		    1530) {
			printf("MAC Address results in Broadcast Address!\n");
			mac_usage();
			return -1;
		} else
			return 0;
	} else {
		printf("ZERO - MAC Address Invalid!");
		mac_usage();
		return -1;
	}
}

union semun {
	int val;
	struct semid_ds *buf;
	ushort *array;
};

int ifx_set_lock()
{
	char sValue[MAX_NAME_SIZE];
	if (ifx_GetCfgData(FILE_U_LOCK, "upgrade_sysconfig", "LOCK", sValue) ==
	    1) {
		if (atoi(sValue) != 0) {	// lock not available
			sleep(6);
			if (ifx_GetCfgData
			    (FILE_U_LOCK, "upgrade_sysconfig", "LOCK",
			     sValue) == 1) {
				if (atoi(sValue) != 0) {
					printf
					    ("upgrade_sysconfig LOCK is set!\n");
					return -1;
				} else
					goto IFX_Handler;
			} else {
				printf
				    ("upgrade_sysconfig LOCK fetch failed!\n");
				return -1;
			}
		} else
			goto IFX_Handler;
	} else {
		printf("upgrade_sysconfig LOCK fetch failed!\n");
		return -1;
	}
      IFX_Handler:
	sprintf(sValue, "LOCK=\"1\"\n");
	if (ifx_SetObjData
	    (FILE_U_LOCK, "upgrade_sysconfig", IFX_F_MODIFY, 1,
	     sValue) != IFX_SUCCESS)
		return -1;
	else {
		return 0;
	}
}

int ifx_release_lock()
{
	char sValue[MAX_NAME_SIZE];
	sprintf(sValue, "LOCK=\"0\"\n");
	if (ifx_SetObjData
	    (FILE_U_LOCK, "upgrade_sysconfig", IFX_F_MODIFY, 1,
	     sValue) != IFX_SUCCESS)
		return -1;
	else {
		return 0;
	}
}

void sig_handler(int signo)
{
    if (signo == SIGTERM)
        printf("UPGRADE util:received SIGTERM\n");
   
    if (signo == SIGINT)
        printf("UPGRADE util:received SIGINT\n");

    if (signo == SIGQUIT)
        printf("UPGRADE util:received SIGQUIT\n");
    
    if (signo == SIGPIPE)
        printf("UPGRADE util:received SIGPIPE\n");

    if (signo == SIGUSR1)
        printf("UPGRADE util:received SIGUSR1\n");

    if (signo == SIGUSR2)
        printf("UPGRADE util:received SIGUSR2\n");

    if (signo == SIGABRT)
        printf("UPGRADE util:received SIGABRT\n");

}

int main(int argc, char *argv[])
{
	int file_fd = 0;
	char *fileData = NULL;
	struct stat filestat;
	int bRead = 0;
	// char sCommand[32];
	int bSaveEnvCopy = 0;
	int ret = 0;
	int32 semid = 0;
	unsigned long flen = 0;
#ifdef CONFIG_FEATURE_IFX_UPGRADE_VENDOR_EXT
	unsigned int offset = 0, newLen = 0;
#endif				// CONFIG_FEATURE_IFX_UPGRADE_VENDOR_EXT

	semid = init_sem(SEMAPHORE_KEY);
	 
	if (signal(SIGTERM, sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGTERM\n");

	if (signal(SIGQUIT,sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGQUIT\n");

	if (signal(SIGINT,sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGINT\n");

	if (signal(SIGPIPE,sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGPIPE\n");
	
	if (signal(SIGUSR1,sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGUSR1\n");

	if (signal(SIGUSR2,sig_handler) == SIG_ERR)
        	printf("\ncan't catch SIGUSR2\n");

	if ( access( "/tmp/upgrade_chk.txt", F_OK ) == 0 )
        {
		printf("\nReboot in progress....! upgrade operation is not possible\n");
		return 0;
        }else{
//      if( ifx_set_lock() == 0 ){
	if (enter_critical_section(semid) == 0) {
/* Sumedh: Support MAC address updation */
		if (argc == 3
		    && ((strcmp(argv[1], "mac_set") == 0)
			|| strcmp(argv[1], "mac_get") == 0)) {
			if (strcmp(argv[1], "mac_set") == 0) {
				if (ValidateMACAddress((unsigned char *)argv[2])
				    < 0) {
					ret = 0;
					goto IFX_Handler;
				} else {
					read_env();
					set_env("ethaddr", argv[2]);
					saveenv();
					printf
					    ("System is going down for reboot!\n");
					system("/etc/rc.d/rebootcpe.sh 5");
				}
			} else {
				read_env();
				printf(get_env("ethaddr"));
				ret = 0;
				goto IFX_Handler;
			}
		}
/* Sumedh: Support ChipID & BoardID get/set */
		else if (argc == 3
			 && ((strcmp(argv[1], "chipid_set") == 0)
			     || (strcmp(argv[1], "chipid_get") == 0)
			     || (strcmp(argv[1], "boardid_set") == 0)
			     || (strcmp(argv[1], "boardid_get") == 0))) {
			if (strcmp(argv[1], "chipid_set") == 0) {
				read_env();
				set_env("chipid", argv[2]);
				saveenv();
				ret = 0;
				goto IFX_Handler;
			} else if (strcmp(argv[1], "chipid_get") == 0) {
				read_env();
				printf(get_env("chipid"));
				ret = 0;
				goto IFX_Handler;
			} else if (strcmp(argv[1], "boardid_set") == 0) {
				read_env();
				set_env("boardid", argv[2]);
				saveenv();
				ret = 0;
				goto IFX_Handler;
			} else if (strcmp(argv[1], "boardid_get") == 0) {
				read_env();
				printf(get_env("boardid"));
				ret = 0;
				goto IFX_Handler;
			}
		} else if ((argc >= 2)
			   && (strcmp(argv[1], "ethwan_set") == 0
			       || strcmp(argv[1], "ethwan_get") == 0)) {
			if (strcmp(argv[1], "ethwan_set") == 0) {
				read_env();
				set_env("ethwan", argv[2]);
				saveenv();
				printf("System is going down for reboot!\n");
				system("/etc/rc.d/rebootcpe.sh 5");
			} else if (strcmp(argv[1], "ethwan_get") == 0) {
				read_env();
				printf(get_env("ethwan"));
				ret = 0;
				goto IFX_Handler;
			}
		}

		else if (argc < 5 || argc > 6) {
			printf
			    ("Usage : upgrade file_name image_type expand_direction saveenv_copy [reboot]\n");
			printf("ToolChain:" CONFIG_GCC_VERSION "/"
			       CONFIG_LIBC_VERSION "\n");
			printf("Version:" VERSION "\n");
			ret = 1;
			goto IFX_Handler;
		}

		if (argc == 6 && (strcmp(argv[5], "reboot") == 0)) {
			printf
			    ("upgrade : reboot option is found and so killing all the processes\n");

			//303002:JackLee
			sleep(2);

			signal(SIGTERM, SIG_IGN);
			signal(SIGHUP, SIG_IGN);
			setpgrp();
			//kill all the processes except you
			kill(-1, SIGTERM);
			sleep(5);
		}

#ifndef CONFIG_TARGET_UBI_MTD_SUPPORT
		if (read_env()) {
			printf("read_env fail\n");
			ret = 1;
			goto abort;
		}
#endif
		if (strtol(argv[4], NULL, 10) == 1)
			bSaveEnvCopy = 1;

		file_fd = open(argv[1], O_RDONLY);
		if (file_fd < 0) {
			printf("The file %s could not be opened\n", argv[1]);
			ret = 1;
			goto abort;
		}

		fstat(file_fd, &filestat);
		flen = filestat.st_size;
		//806121:<IFTW-leon> IOP bit: add fwdiag
		if (!strcmp(argv[2], "ubootconfig")
		    || !strcmp(argv[2], "sysconfig")
		    || !strcmp(argv[2], "factoryconfig")
		    || !strcmp(argv[2], "wlanconfig")
		    || !strcmp(argv[2], "voip")
		    || !strcmp(argv[2], "dectconfig")) {

#ifdef CONFIG_BOOT_FROM_NAND
			char temp_buf[256];
			if (!strcmp(argv[2], "sysconfig")) {
  #ifdef CONFIG_TARGET_UBI_MTD_SUPPORT
				sprintf(temp_buf, "/usr/sbin/vol_mgmt write_vol sysconfig %s",
					argv[1]);
  #else
				sprintf(temp_buf,
					"cp -f %s /etc/sysconfig/rc.conf.current.gz; sync",
					argv[1]);
  #endif
				system(temp_buf);
				ret = 0;
				goto abort;
  #ifdef CONFIG_TARGET_UBI_MTD_SUPPORT
			} else if (!strcmp(argv[2], "wlanconfig") || !strcmp(argv[2], "dectconfig")) {
				sprintf(temp_buf, "/usr/sbin/vol_mgmt write_vol %s %s",
					argv[2], argv[1]);
				system(temp_buf);
				ret = 0;
				goto abort;
  #endif
			} else {
				ifx_debug_printf
				    ("upgrade is invoked for data block in NAND\n",
				     argv[2]);
				ret = 1;
				goto abort;
			}
#endif

			fileData = (char *)malloc(flen * sizeof(char));
			if (fileData == NULL) {
				printf
				    ("Can not allocate %ld bytes for the buffer\n",
				     flen);
				ret = 1;
				goto abort;
			}
			bRead = read(file_fd, fileData, flen);
			if (bRead < flen) {
				printf
				    ("Could read only read %d bytes out of %ld bytes of the file\n",
				     bRead, flen);
				free(fileData);
				ret = 1;
				goto abort;
			}

			close(file_fd);
//              printf("Erasing the input file %s\n",argv[1]);
			if (strcmp(argv[1], "/etc/rc.conf.gz") != 0)
				unlink(argv[1]);

			ifx_debug_printf
			    ("upgrade : calling upgrade_img with srcAddr = 0x%08lx and size %d\n",
			     fileData, flen);
			if (upgrade_img
			    ((unsigned long)fileData, flen, argv[2],
			     strtol(argv[3], NULL, 10), bSaveEnvCopy)) {
				printf
				    ("Image %s could not be updated in dir=%s\n",
				     argv[2], argv[3]);
				ret = 1;
			} else {
				//printf("Upgrade : successfully upgraded %s\n", argv[2]);
			}

			free(fileData);
			ret = 0;
		} else {

#ifdef CONFIG_FEATURE_IFX_UPGRADE_VENDOR_EXT
			if (image_file_preprocessing_hook_fn
			    (argv[1], flen, &offset, &newLen)) {
				printf
				    ("Preprocessing checks failed !!\nUpgrade process aborted.\n");
				goto abort;
			} else {
				printf
				    ("Preprocessing checks passed!!\nUpgrade process will continue.\n");
				if (offset) {
					lseek(file_fd, offset, SEEK_SET);
					flen = newLen;
				}
			}
#endif				// CONFIG_FEATURE_IFX_UPGRADE_VENDOR_EXT

			ifx_debug_printf
			    ("upgrade : calling do_upgrade with filename = %s and size %d\n",
			     argv[1], flen);
			if (do_upgrade(file_fd, flen)) {
				printf
				    ("Image %s could not be updated in dir=%s\n",
				     argv[2], argv[3]);
				ret = 1;
			} else {
				printf("Upgrade : successfully upgraded %s\n",
				       argv[2]);
			}

			close(file_fd);
			//         printf("Erasing the input file %s\n",argv[1]);
			if (strcmp(argv[1], "/etc/rc.conf.gz") != 0)
				unlink(argv[1]);

		}
	} else {
		printf("ifx_set_lock() function failed\n");
		return 1;
	}
      abort:
	if (argc == 6 && (strcmp(argv[5], "reboot") == 0)) {
		close(file_fd);
		printf("upgrade : Rebooting the system\n");
		//system("sync; sleep 5");
		sync();
		sleep(25);
		reboot(RB_AUTOBOOT);
	}
      IFX_Handler:

	if (exit_critical_section(semid) != 0)
		printf("exit_critical_section @ update.c function failed\n");
	//      if(ifx_release_lock() != 0)
	//                    printf("ifx_release_lock() function failed\n");
	return ret;
   // }
    }   // file check
}
