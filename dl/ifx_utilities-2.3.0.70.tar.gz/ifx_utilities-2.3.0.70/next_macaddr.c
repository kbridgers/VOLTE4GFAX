/* ========================================================================== */
/*                                                                            */
/*   version.c                                                                */
/*   (c) 2004 Wes Lu                                                          */
/*                                                                            */
/*   Description                                                              */
/*                                                                            */
/* ========================================================================== */
/*
 * 2005/04/19, MarsLin
 * 	Change increamental mechanism
 * 2007/09/07, Subbi
 *  Change MAC address assignment to Globally admininstered format 
 */

//000014:fchang 2005/6/2 Modified by Henry to fix the wireless MAC setting problem

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <ifx_config.h>

#ifdef IFX_MULTILIB_UTIL
#define	main	next_macaddr_main
#endif

#ifdef CONFIG_FEATURE_IFX_WIRELESS
#ifndef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
/* Possible interfaces: eth0, br0, usb0 (device, host), wlan0..4 (1- AP, 4 - VAPs) */
#define IFX_NUM_LAN_MAC_ADDR	9
#else
/* mac address of wlan0 will be base mac + 16 */
#define IFX_NUM_LAN_MAC_ADDR    4
#endif
#else
/* Possible interfaces: eth0, br0, usb0 (device, host) */
#define IFX_NUM_LAN_MAC_ADDR	4
#endif

int MACString2Bytes(unsigned char *mac, unsigned char *value)
{
	int i, j;
	unsigned char str[14] = { 0 };

	if (mac == NULL)
		return 1;
	for (j = 0, i = 0; i < 17; i++) {
		if (mac[i] != ':' && mac[i] != '-' && mac[i] != '_') {
			if (mac[i] == '.') {
				/* Here the MAC Address is grouped as - 0010.2030.4050 */
				/* Check on the value of i, where i <14 */
				if (i >= 14)
					break;
			} else {
				str[j] = mac[i];
				j++;
			}
		}
	}

	for (i = 0; i < 12; i++) {
		if ((str[i] >= '0') && (str[i] <= '9'))
			str[i] -= '0';
		else {
			str[i] = toupper(str[i]);
			if ((str[i] >= 'A') && (str[i] <= 'F'))
				str[i] -= ('A' - 10);
			else
				return 1;
		}
	}
	for (i = 0; i < 12 / 2; i++)
		value[i] = (str[i << 1] << 4) + str[(i << 1) + 1];
	return 0;
}

#if 0
void IncreaseMacAddr(unsigned char *mac_addr, int value)
{
//000014:fchang Start
	if (value == 0) {
		mac_addr[5]++;
	} else {		//000014:fchang End
		mac_addr[0] += (value / 2) * 16;
		switch (value % 2)	//000014:fchang 
		{		//000014:fchang
		case 0:
			mac_addr[0] += 2;
			break;
		case 1:
			mac_addr[0] += 10;
			break;
		}
	}			//000014:fchang
	return;
}

#else
void IncreaseMacAddr(unsigned char *mac_addr, int value)
{
	int old_mac_addr5 = mac_addr[5];
	value += IFX_NUM_LAN_MAC_ADDR;

	mac_addr[5] += value;
	if (old_mac_addr5 > mac_addr[5]) {
		mac_addr[4]++;
		if (mac_addr[4] == 0)
			mac_addr[3]++;
	}
	return;
}

#endif

int main(int argc, char **argv)
{
	unsigned char mac_addr[32], str[64], format_id;	//000014:fchang
	int i;

	scanf("%64s", str);
	MACString2Bytes(str, mac_addr);
	if (str[4] != '.')
		format_id = str[2];
	else
		format_id = str[4];
	IncreaseMacAddr(mac_addr, atoi(argv[1]));
	for (i = 0; i < 6; i++) {
		printf("%02X", mac_addr[i]);
		if (i == 5)
			printf("\n");
		else if ((format_id == '.')) {
			if ((i == 1) || (i == 3)) {
				printf("%c", format_id);
			}
		} else {
			printf("%c", format_id);
		}

	}
	return 0;
}
