#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#ifdef IFX_MULTILIB_UTIL
#define main	mknod_util_main
#endif

int main(int argc, char *argv[])
{
	FILE *fp = NULL;
	char str[255];
	char devType = 'c';
//      char *strTok = NULL;
	unsigned int devNo = 0;
	char *tok_val = NULL;

	if (argc < 3) {
		printf
		    ("Usage : mknode_util device_name node_name [minor_no]\n");
		return 1;
	}

	fp = fopen("/proc/devices", "r");
	if (fp == NULL) {
		printf("Can not open /proc/devices for reading\n");
		return 1;
	}

	memset(str, 0x00, sizeof(str));
	while (fgets(str, sizeof(str) - 1, fp)) {
		if (strstr(str, "Character devices")) {
			devType = 'c';
		} else if (strstr(str, "Block devices")) {
			devType = 'b';
		} else if (strstr(str, argv[1])) {
			tok_val = strtok(str, " ");
			if (tok_val != NULL) {
				devNo = strtol(tok_val, NULL, 10);
				if (devNo) {
					devNo = devNo << 8;
					if (argc == 4)
						devNo |=
						    strtol(argv[3], NULL, 10);
					if (devType == 'c') {
						if (mknod
						    (argv[2], S_IFCHR | 0666,
						     devNo))
							perror
							    ("mknod failed. Error");
						else
							printf
							    ("Created character device %s with major[%d] and minor[%d]\n",
							     argv[2],
							     devNo >> 8,
							     devNo & 0xf);
					} else {
						if (mknod
						    (argv[2], S_IFBLK | 0666,
						     devNo))
							perror
							    ("mknod failed. Error");
						else
							printf
							    ("Created block device %s with major[%d] and minor[%d]\n",
							     argv[2],
							     devNo >> 8,
							     devNo & 0xf);
					}
				}
				break;
			}
		}
		memset(str, 0x00, sizeof(str));
	}

	fclose(fp);
	return 0;
}
