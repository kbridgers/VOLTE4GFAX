//
// file name : rcCnf_gen.c
// Author    : Udaya Shankara KS
// Module    : Module to generate the rc.conf seek points
// Date      : Mon Mar 19 20:11:23 IST 2012
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>

// Length of the buffer
#define LENGTH (2048<<4)

#define dbg_error   printf

// Macro to skip the data 
#define skip_data( line,p)  for ((p) = line; *(p) != ' ' && *(p) != '\t'; (p)++)

// Macro to skip the space
#define skip_space(line, p)      for( (p) = line; *(p) == ' ' || *(p) == '\t'; (p)++)


//
// getStringlenght
//    fucntion to get the string len 
//
int getStringlength( char *line, char **tag, int *len )
{
   char *p = line, *q;
   char *tag1;
   char tmp_buf[512];

   skip_space(line,p); 
   skip_data( p,p);
   skip_space(p,p); 
   for (q=tmp_buf  ; *p != ' ' && *p != '\t' && *p != '\n' && *p != '\0'; ){
       *q++ = *p++;
   }
   *q = '\0';
   tag1 = strdup( tmp_buf);

   skip_space(p,p);
   p += 2;
   *len = atoi(p);
   *tag =  tag1;

   return 0;
}

// 
//  main
//    main test suite module
//
int main(int argc,char ** argv )
{
  char *if_name, *of_name;
  FILE *ifp, *ofp;
  char *Tag;
  char begTag[100];
  char line[LENGTH];
  char buffer[LENGTH],*buf_ptr;
  int ret = 0;
  int len = 0;


  if ( argc < 3 ) {
    dbg_error("Format <%s>< input_rc.conf file ><out_put file>\n",
                                 basename(*argv) );
    return -1;
  }

  if_name = argv[1];
  of_name  = argv[2];
 
  ifp = fopen( if_name ,"r");
  if (!ifp ) {
    dbg_error("Unable to open file %s \n", if_name );
    return -2;
  }

  ofp = fopen( of_name ,"w+");
  if (!ofp) {
    dbg_error("Unable to open file %s \n", of_name );
    fclose( ifp );
    return -2;
  }

  while( fgets(line,LENGTH,ifp) != NULL){
    if (strstr( line,"#<<")){
        ret = getStringlength(line,&Tag,&len);
    } else continue;

    buf_ptr = buffer; 
    while (fgets(line, LENGTH, ifp ) != NULL ){
        if( strstr(line,"#>>")){
           fseek( ifp, 0 - (strlen(line)+1), SEEK_CUR);
           break;
        }else{
         strcpy( buf_ptr,line );
         buf_ptr += strlen(line);
        }
    }
    *buf_ptr = '\0';
    len = strlen(buffer) + strlen(Tag)+6;

    if( ret != 0) continue;
    sprintf(begTag,"#<< %s ##%d\n",Tag,len);
    fprintf(ofp,"%s",begTag);
    fprintf(ofp,"%s",buffer);
    fprintf(ofp,"#>> %s\n\n",Tag);
    free( Tag );
    fflush( ofp);
  }


  fclose( ifp );
  fclose( ofp );
  return 0;
}

