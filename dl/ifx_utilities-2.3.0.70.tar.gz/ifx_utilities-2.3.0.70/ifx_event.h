// #705176:Pramod start

/* 
** =============================================================================
**   FILE NAME        : ifx_event.h
**   PROJECT          : Event Handler MAPI
**   DATE             : 05-May-2007
**   AUTHOR           : M-API Team
**   DESCRIPTION      : This file is header file for Event handling. 

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
#ifndef __IFX_EVENT_H
#define __IFX_EVENT_H

#include "ifx_common.h"

extern int32 ifx_event_handler(IFX_IN int32 evtType,
			       IFX_IN int32 evtState,
			       IFX_IN const char8 * secName,
			       IFX_IN int32 nCount,
			       IFX_IN const char8 nvp[][50]);
#endif

// #705176:Pramod end
