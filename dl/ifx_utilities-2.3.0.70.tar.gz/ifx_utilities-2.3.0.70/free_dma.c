#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include<unistd.h>
#include<fcntl.h>
#include <sys/ioctl.h>

#define MAJOR_NUM 235
#define DEVNAME "/dev/free_dma_dev"
#define DSL_NAME "/dev/ifx_mei"

#define TEST _IOWR(MAJOR_NUM, 5, int *)

#define DSL_IOC_MEI_BSP_MAGIC           's'
#define DSL_FIO_BSP_FREE_RESOURCE_NEW       _IO  (DSL_IOC_MEI_BSP_MAGIC, 21)
#define DSL_FIO_BSP_FREE_ALL_RESOURCES     _IO  (DSL_IOC_MEI_BSP_MAGIC, 20)

int main(int argc, char *argv[])
{
	int dev_file = 0, val = 0, dev_file2 = 0;
	//int ret= -1;

	if (argc != 2) {
		printf
		    ("Usage: free_dma 1|2|3 ...where 1- free LAN DMA 2-Free WAN DMA 3-Free MEI buffers\n");
		exit(0);
	}
	val = atoi(argv[1]);

	if (val == 3) {
		printf("Opening %s\n", DSL_NAME);
		dev_file = open(DSL_NAME, 0);
		if (dev_file < 0) {
			printf("Error:... Cannot be opened\n");
			exit(0);
		}
		ioctl(dev_file, DSL_FIO_BSP_FREE_RESOURCE_NEW, NULL);
		close(dev_file);
	} else {
		printf("Opening %s\n", DEVNAME);
		dev_file = open(DEVNAME, 0);
		if (dev_file < 0) {
			printf("Error: ... Dev cannot be opened\n");
			exit(0);
		}

		if (val == 1)	//free lan
		{
			printf("Freeing LAN DMA channels\n");
			ioctl(dev_file, TEST, &val);
			/*TEMP.. always free MEI */
			printf("Opening %s\n", DSL_NAME);
			dev_file2 = open(DSL_NAME, 0);
			if (dev_file2 < 0) {
				printf("Error:... Cannot be opened\n");
				exit(0);
			}
			ioctl(dev_file2, DSL_FIO_BSP_FREE_RESOURCE_NEW, NULL);
			close(dev_file2);
		} else if (val == 2)	//free wan
		{
			printf("Freeing WAN DMA channels\n");
			ioctl(dev_file, TEST, &val);
			/*TEMP.. always free MEI */
			printf("Opening %s\n", DSL_NAME);
			dev_file2 = open(DSL_NAME, 0);
			if (dev_file2 < 0) {
				printf("Error:... Cannot be opened\n");
				exit(0);
			}
			ioctl(dev_file2, DSL_FIO_BSP_FREE_ALL_RESOURCES, NULL);
			close(dev_file2);
		}
		close(dev_file);

	}

	return 0;
}
