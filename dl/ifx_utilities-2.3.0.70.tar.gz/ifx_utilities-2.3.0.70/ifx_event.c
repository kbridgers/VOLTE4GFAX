// #705174:Pramod start

#include <stdarg.h>
#include "ifx_event.h"
#include "ifx_common.h"
#include "ifx_amazon_cfg.h"
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include <signal.h>

/* This macro will read the fieldname and value pair from nvp, check if fieldname is not equal to key string passed
   if so it will copy fieldname and value to array_fvp otherwise copies value only to key parameter */
#define IFX_FILL_ARRAY_FVP_FROM_NVP(_nCount, _nvp, _count, _array_fvp, _key_str, _key_param) { \
		int32	i = 0; \
		for(i=0; i<_nCount; i+=2) { \
				if(strcmp(_nvp[i], _key_str)) { \
						sprintf(_array_fvp[_count].fieldname, "%s", _nvp[i]); \
						sprintf(_array_fvp[_count++].value, "%s", _nvp[i+1]); \
				} \
				else \
						sprintf(_key_param, "%s", _nvp[i+1]); \
		} \
}

/* This macro reads cpeid for the instance no. passed in the specified section */
#define IFX_GET_CPEID_FROM_INDEX(_sPrefix, _sSecName, _nIndex, _sValue, _Handler) { \
		char8	buf[MAX_FILELINE_LEN]; \
		sprintf(buf, "%s_%d_cpeId", _sPrefix, _nIndex); \
		if(ifx_GetObjData(FILE_RC_CONF, _sSecName, buf, IFX_F_DEFAULT, NULL, _sValue) != IFX_SUCCESS) { \
				ret = IFX_FAILURE; \
				goto _Handler; \
		} \
}

#define IFX_FILL_IID(_iid, _cpeId, _sSecName) { \
		_iid.config_owner = IFX_ROOT; \
		_iid.cpeId.Id = _cpeId; \
		sprintf(_iid.cpeId.secName, "%s", _sSecName); \
		_iid.config_owner = IFX_ROOT; \
}

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
extern char oldconnName[MAX_CONN_NAME_LEN];
extern char newconnName[MAX_CONN_NAME_LEN];
#endif

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	extern pwb_cfg_t *autodetect_pwb;
#endif

/* This function takes event type and state as input. based on the event type it will use the input name value pair
	to get necessary information such as cpeid, fully qualified name value pair.... And then it calls the different
	mgmt. interface event handlers */
int32 ifx_event_handler(IFX_IN int32 evtType,
			IFX_IN int32 evtState,
			IFX_IN const char8 * secName,
			IFX_IN int32 nCount, IFX_IN const char8 nvp[][50])
{
	IFX_ID iid;
	FILE	*fp = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[20];
	uint32 flags = IFX_F_DEFAULT;	//, outFlag = IFX_F_DEFAULT;
	int32 count = 0, nWanIDX = 0, ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN],
	    nKeyParam[MAX_FILELINE_LEN];
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
				char8 *vpivci = NULL;
				char8 *vlan = NULL;
				int32 *wan_type = NULL;
				int32 wan_mode = 0;
#endif
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	char sVal[MAX_DATA_LEN]="";
	char igmpnewconnName[MAX_CONN_NAME_LEN]="";
	char igmpoldconnName[MAX_CONN_NAME_LEN]="";
	int32 mcast_wan_flag;
#endif
#ifdef IFX_LOG_DEBUG
	IFX_DBG("Event:%d, State:%d, Section Name : %s\n",
		evtType, evtState, secName);
#endif

	memset(&iid, 0x00, sizeof(iid));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*   if (nvp != NULL)
	   printf("NVP Info : %s\n", nvp);
	 */

#if 0
	if (logInfo != NULL)
		printf("Logging Info : %s\n", logInfo);
#endif

	//PSEUDO CODE
	// Invoke local function validate - switches based on evtType and evtState
	// Check against given valid section name or UNKNOWN string name
	// nvp shoudl contain more info like "ifName=eth0\n" or "ipAddress=10.10.10.10\n". It can take multiple NVPs separated by NL.
	// If Section Name is figured out then invoke GetCfgObject and look for key 
	// atributes to know the cpeId.
	// In case of ipAddress, the old ipAddress has to be read from /tmp/dyn_info.txt file. The API  should read and look based on old IP address value in rc.conf
	// Invoke the ME specific event handler.nside it as per compile time flags. TR-069 should write ifx_Tr69_Event_Handler() function. CPE-Id shoudl be mandatorily passed to these ME-Event Handlers to handle them as they want. 
	// set flags based on evtState

	switch (evtState) {
	case EVT_STATE_ADD:
		flags = IFX_F_INT_ADD;
		break;
	case EVT_STATE_DEL:
		flags = IFX_F_DELETE;
		break;
	case EVT_STATE_MOD:
		flags = IFX_F_MODIFY;
		break;
	}

	switch (evtType) {
	case EVT_TYPE_LAN_IPADDRESS:
	case EVT_TYPE_LAN_INTERFACE:
		/*
		   get interface=\"%s\" from nvp - ifName
		   call ifx_ret_substr_from_distfield with interface=\"ifName\" - lan_main_%d_
		   get cpeid from lan_main_%d_cpeId
		   secname is lan_main
		 */
		break;
	case EVT_TYPE_WAN_INTERFACE:
		/* copy all name value pairs from nvp to array_fvp except nvp with name "wan_index"
		   (as this is not stored in rc.conf explicitly) */
		IFX_FILL_ARRAY_FVP_FROM_NVP(nCount, nvp, count, array_fvp,
					    "wan_index", nKeyParam)
		    nWanIDX = atoi(nKeyParam);

		/* wan connection cpeid is not given by caller, get cpeid from index */
			if(!strcmp(secName,"wan_ppp"))
				IFX_GET_CPEID_FROM_INDEX(PREFIX_WAN_PPP, TAG_WAN_PPP, nWanIDX,sValue, IFX_Handler)

			if(!strcmp(secName,"wan_ip"))
				IFX_GET_CPEID_FROM_INDEX(PREFIX_WAN_IP, TAG_WAN_IP, nWanIDX,sValue, IFX_Handler)

		    /* copy the connection status value pair to array_fvp */
		    sprintf(array_fvp[count].fieldname, "%s", "Conn_Status");
		switch (evtState) {
		case EVT_STATE_UP:
			sprintf(array_fvp[count++].value, "%s", "Up");
			break;
		case EVT_STATE_DOWN:
			sprintf(array_fvp[count++].value, "%s", "Down");
			break;
		}

		/* Form the fully qualified Name Value Pairs */
			if(!strcmp(secName,"wan_ppp"))
				IFX_FILL_IID(iid, atoi(sValue), TAG_WAN_PPP)

			if(!strcmp(secName,"wan_ip"))
				IFX_FILL_IID(iid, atoi(sValue), TAG_WAN_IP)

		    /* call tr69_event_handler and/or snmp_event_handler here */
		    IFX_TR69_EVENT_HANDLER(evtType, evtState, iid, array_fvp,
					   count, IFX_Handler)

		    break;
	case EVT_TYPE_WAN_IPADDRESS:
		/*
		   get interface=\"%s\" from nvp - ifName
		   call ifx_get_wan_connName_from_ifname with ifName - connname
		   call ifx_ret_substr_from_distfield with connName=\"connname\" - wan_%d_
		   get cpeid from wan_%d_cpeId
		   secname is wan_main
		 */

		/* copy all name value pairs from nvp to array_fvp except nvp with name "wan_index"
		   (as this is not stored in rc.conf explicitly) */
		IFX_FILL_ARRAY_FVP_FROM_NVP(nCount, nvp, count, array_fvp,
					    "wan_index", nKeyParam)
		    nWanIDX = atoi(nKeyParam);

#if 0				//- not required
		    /* copy the cpeid name value pair to array_fvp */
		    sprintf(array_fvp[count].fieldname, "%s", "cpeId");
		sprintf(array_fvp[count++].value, "%s", sValue);
#endif

		/* Form the fully qualified Name Value Pairs */
			if(!strcmp(secName,"wan_ppp")){
				/* wan connection cpeid is not given by caller, get cpeid from index */
				IFX_GET_CPEID_FROM_INDEX(PREFIX_WAN_PPP, TAG_WAN_PPP, nWanIDX,sValue, IFX_Handler)

				IFX_FILL_IID(iid, atoi(sValue), TAG_WAN_PPP)

				if (ifx_get_conf_index_and_nv_pairs(&iid, nWanIDX, PREFIX_WAN_PPP, count, array_fvp,flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}

			if(!strcmp(secName,"wan_ip")){
				/* wan connection cpeid is not given by caller, get cpeid from index */
				IFX_GET_CPEID_FROM_INDEX(PREFIX_WAN_IP, TAG_WAN_IP, nWanIDX,sValue, IFX_Handler)

				IFX_FILL_IID(iid, atoi(sValue), TAG_WAN_IP)

				if (ifx_get_conf_index_and_nv_pairs(&iid, nWanIDX, PREFIX_WAN_IP, count, array_fvp,flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}

		/* call tr69_event_handler and/or snmp_event_handler here */
		IFX_TR69_EVENT_HANDLER(evtType, evtState, iid, array_fvp, count,
				       IFX_Handler)

		    break;
/*Manohar : Added new event for if default wan is changed*/
	case EVT_TYPE_DEFAULT_WAN_CHANGE:
		/* copy all name value pairs from nvp to array_fvp except nvp with name "wan_index"
		   (as this is not stored in rc.conf explicitly) */


		IFX_FILL_ARRAY_FVP_FROM_NVP(nCount, nvp, count, array_fvp,"wan_index", nKeyParam)
		    nWanIDX = atoi(nKeyParam);
		int i = 0;	
		for(i=0; i<nCount; i+=2) { 
				if(strcmp(nvp[i],"wan_index")) { 
						printf("array_fvp[count].fieldname = [%s]", nvp[i]); 
						printf("array_fvp[count++].value =  [%s]", nvp[i+1]);
				} 
				else 
						printf("nKeyParam = [%s]", nvp[i+1]);
		} 


		/* Form the fully qualified Name Value Pairs */
			if(!strcmp(secName,"wan_ppp")){
				/* wan connection cpeid is not given by caller, get cpeid from index */
				IFX_GET_CPEID_FROM_INDEX(PREFIX_WAN_PPP, TAG_WAN_PPP, nWanIDX,sValue, IFX_Handler)

				IFX_FILL_IID(iid, atoi(sValue), TAG_WAN_PPP)

				if (ifx_get_conf_index_and_nv_pairs(&iid, nWanIDX, PREFIX_WAN_PPP, count, array_fvp,flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] wan_ppp failed\n", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}

			if(!strcmp(secName,"wan_ip")){
				/* wan connection cpeid is not given by caller, get cpeid from index */
				IFX_GET_CPEID_FROM_INDEX(PREFIX_WAN_IP, TAG_WAN_IP, nWanIDX,sValue, IFX_Handler)

				IFX_FILL_IID(iid, atoi(sValue), TAG_WAN_IP)

				if (ifx_get_conf_index_and_nv_pairs(&iid, nWanIDX, PREFIX_WAN_IP, count, array_fvp,flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] wan_ip failed\n", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}

			/* call tr69_event_handler and/or snmp_event_handler here */
			IFX_TR69_EVENT_HANDLER(evtType, evtState, iid, array_fvp, count,IFX_Handler)
		        break;
	case EVT_TYPE_NTP_SYNC_STATUS_CHANGE:
			sprintf(array_fvp[count].fieldname, "%s", "ntp_status");
			strcpy(array_fvp[count++].value,nvp[0]);
	                /* Fill cpeId as 1 and secName as WANCommonInterfaceConfig */
        	
		        IFX_FILL_IID(iid, 1,TAG_TIME_SECTION);
	                    /* call tr69_event_handler and/or snmp_event_handler here */
			
			memset(buf,0x00,sizeof(buf));
		        IFX_TR69_EVENT_HANDLER(evtType, evtState, iid, array_fvp,
                                           count, IFX_Handler)
                    break;
	
/*Manohar end*/
	case EVT_TYPE_ADSL_LINK_STATUS:
		/* fill fieldname as PhyLinkStatus and value as Up or Down */
		sprintf(array_fvp[count].fieldname, "%s", "PhyLinkStatus");

		switch (evtState) {
		case EVT_STATE_UP:
#ifdef IFX_LOG_DEBUG
			IFX_DBG("adsl link status event called for link up");
#endif
			sprintf(array_fvp[count++].value, "%s", "Up");
			break;
		case EVT_STATE_DOWN:
#ifdef IFX_LOG_DEBUG
			IFX_DBG("adsl link status event called for link down");
#endif
			sprintf(array_fvp[count++].value, "%s", "Down");
			break;
		}

		/* Fill cpeId as 1 and secName as WANCommonInterfaceConfig */
		IFX_FILL_IID(iid, 1, "wancommon_intfconf")

		/* call tr69_event_handler and/or snmp_event_handler here */
		IFX_TR69_EVENT_HANDLER(evtType, evtState, iid, array_fvp,
					count, IFX_Handler)
		break;
//706124 end
	case EVT_TYPE_ETH_LINK_STATUS:
		switch (evtState) {
		case EVT_STATE_UP:
			break;
		case EVT_STATE_DOWN:
			break;
		}
		break;
	case EVT_TYPE_WAN:
		switch (evtState) {
		case EVT_STATE_START:
			/* if PID file for this case is present, then call stop and then proceed with start
			 * start case : create PID file, start WAN, remove PID file
			 */
			fp = fopen(FILE_WAN_CONFIG_PID, "r+");
			if(fp != NULL) {
				fread(buf, 1, sizeof(buf), fp);
				fclose(fp);
				kill(atoi(buf), SIGTERM);
				remove(FILE_WAN_CONFIG_PID);
			}
			fp = fopen(FILE_WAN_CONFIG_PID, "w");
			if(fp != NULL) {
				sprintf(buf, "%d", getpid());
				fwrite(buf, strlen(buf), 1, fp);
				fclose(fp);
			}
			/* no background process further .. */
			do_wan_config("start", ((nCount > 0)?(nvp[0]):(NULL)));
			if(access(FILE_WAN_CONFIG_PID, F_OK) == 0) {
				remove(FILE_WAN_CONFIG_PID);
			}
			else { /* Can't be .. */
			}
			break;
		case EVT_STATE_START_ALL:
			/* if PID file for this case is present, then call stop and then proceed with start
			 * start case : create PID file, start WAN, remove PID file
			 */
			fp = fopen(FILE_WAN_CONFIG_PID, "r+");
			if(fp != NULL) {
				fread(buf, 1, sizeof(buf), fp);
				fclose(fp);
				kill(atoi(buf), SIGTERM);
				remove(FILE_WAN_CONFIG_PID);
			}
			fp = fopen(FILE_WAN_CONFIG_PID, "w");
			if(fp != NULL) {
				sprintf(buf, "%d", getpid());
				fwrite(buf, strlen(buf), 1, fp);
				fclose(fp);
			}
			/* no background process further .. */
			do_wan_config("start_all",NULL);
			if(access(FILE_WAN_CONFIG_PID, F_OK) == 0) {
				remove(FILE_WAN_CONFIG_PID);
			}
			else { /* Can't be .. */
			}
			break;
		case EVT_STATE_STOP:
			/* if PID file is present, kill the PID and remove the PID file */
			fp = fopen(FILE_WAN_CONFIG_PID, "r+");
			if(fp != NULL) {
				fread(buf, 1, sizeof(buf), fp);
				fclose(fp);
				kill(atoi(buf), SIGTERM);
				remove(FILE_WAN_CONFIG_PID);
			}
			fp = fopen(FILE_WAN_CONFIG_PID, "w");
			if(fp != NULL) {
				sprintf(buf, "%d", getpid());
				fwrite(buf, strlen(buf), 1, fp);
				fclose(fp);
			}
			/* no background process further .. */
			do_wan_config("stop",NULL);
			if(access(FILE_WAN_CONFIG_PID, F_OK) == 0) {
				remove(FILE_WAN_CONFIG_PID);
			}
			else { /* Can't be .. */
			}
			break;
		case EVT_STATE_STOP_ALL:
			/* if PID file is present, kill the PID and remove the PID file */
			fp = fopen(FILE_WAN_CONFIG_PID, "r+");
			if(fp != NULL) {
				fread(buf, 1, sizeof(buf), fp);
				fclose(fp);
				kill(atoi(buf), SIGTERM);
				remove(FILE_WAN_CONFIG_PID);
			}
			fp = fopen(FILE_WAN_CONFIG_PID, "w");
			if(fp != NULL) {
				sprintf(buf, "%d", getpid());
				fwrite(buf, strlen(buf), 1, fp);
				fclose(fp);
			}
			/* no background process further .. */
			do_wan_config("stop_all",NULL);
			if(access(FILE_WAN_CONFIG_PID, F_OK) == 0) {
				remove(FILE_WAN_CONFIG_PID);
			}
			else { /* Can't be .. */
			}
			break;
		}
		break;
	case EVT_TYPE_WLAN_STATUS:
		/* update the status in system_status file */
		switch (evtState) {
		case EVT_STATE_START:
			sprintf(buf, "/usr/sbin/status_oper SET %s %s 'start'",
				TAG_WLAN_CONFIG, "status");
			break;
		case EVT_STATE_STOP:
			sprintf(buf, "/usr/sbin/status_oper SET %s %s 'stop'",
				TAG_WLAN_CONFIG, "status");
			break;
		case EVT_STATE_COMPLETE:
			sprintf(buf,
				"/usr/sbin/status_oper SET %s %s 'complete'",
				TAG_WLAN_CONFIG, "status");
			break;
		}
		system(buf);
		break;
	case EVT_TYPE_DEFAULT_WAN:
		ret = ifx_modify_default_wan_interface();
		if (ret != 0)
			IFX_DBG("[%s:%d]def wan set failure", __FUNCTION__,
				__LINE__);
		break;
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT	
#ifdef CONFIG_FEATURE_NAPT
								case EVT_TYPE_AUTODETECT:

												switch (evtState) {
																/*	case EVT_STATE_START:

																		sprintf(buf,"/usr/sbin/wan_autodetect");
																		system(buf);*/

																case EVT_STATE_COMPLETE:

#ifdef IFX_LOG_DEBUG
																				IFX_DBG("[%s:%d:%s:%s:%s:%d] parameters passed and ncount ", __FUNCTION__,__LINE__, nvp[0], nvp[1], nvp[2],nCount);
#else
																				{}
#endif
																				WAN_PHY_CFG	wanPhy;
																				if(ifx_get_wan_phy_cfg(&wanPhy) != IFX_SUCCESS) {
																								ret = IFX_FAILURE;
																								goto IFX_Handler;
																				}
																				WAN_MODE	wanMode;
																				/*manohar : check if already there is a function for getting wan mode*/
																				wanMode = compute_wan_mode(wanPhy.phy_mode, wanPhy.wan_tc);

																				if (wanMode == WAN_MODE_ATM)
																								wan_mode = WAN_MODE_ATM ;       /* !< ADSL ATM WAN mode. */
																				else if(wanMode == WAN_MODE_PTM)
																								wan_mode = WAN_MODE_PTM;        /* !< ADSL PTM WAN mode. */
																				else if(wanMode == WAN_MODE_VDSL_PTM)
																								wan_mode = WAN_MODE_VDSL_PTM;        /* !< VDSL PTM WAN mode. */
																				else if(wanMode == WAN_MODE_ETH1)
																								wan_mode = WAN_MODE_ETH1;        /* !< ETH1 WAN mode. */
																				else if(wanMode == WAN_MODE_ETH0)
																								wan_mode = WAN_MODE_ETH0;        /* !< ETH0 WAN mode. */


																				if(nCount == 4 || nCount  == 3 )
																				{
																								vpivci = nvp[1];
																								vlan = nvp[2];
																								if(wan_mode == WAN_MODE_ATM)
																								{
																												ret = Update_vcchannel_config(wan_mode,vpivci);
																												if (ret != 0)
																												{
																																IFX_DBG("[%s:%d]Update_vcchannel_config failed ", __FUNCTION__,__LINE__);
																												}

																								}
																								if(wan_mode == WAN_MODE_PTM || wan_mode == WAN_MODE_VDSL_PTM || wan_mode == WAN_MODE_ETH1 || wan_mode == WAN_MODE_ETH0)
																								{
																												ret = Update_vlan_config(wan_mode,vlan);
																												if (ret != 0)
																												{
																																IFX_DBG("[%s:%d]Update_vlan_config failed ", __FUNCTION__,__LINE__);
																												}
																								}
																								if(nCount == 4)
																								{
																												wan_type =nvp[3];
																												ret = Update_wan_config(wan_mode,wan_type);					

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
																												strcpy(igmpnewconnName,newconnName);
#endif


#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
		if(mapi_pwb_modentry_on_wanchange(newconnName, autodetect_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
	      		IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
		}		
#endif
																											ret = Update_virtual_server_config(newconnName,"autodetect");
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
																												ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal);
																												if (sVal[0] != '\0')
																												{
																																strcpy(igmpoldconnName,oldconnName);
																																if ( strstr(sVal,igmpoldconnName) != NULL )
																																{
																																				mcast_wan_flag =3;
																																				Update_mcast_wan_flag(1,mcast_wan_flag);
																																				Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
																																				mcast_wan_flag=0;
																																}
																												}
																												Update_mcast_wan_flag(1,mcast_wan_flag);
#ifdef IFX_LOG_DEBUG
																												IFX_DBG("%s is new conn name %s is old conn name and %d is mcast flag\n",igmpnewconnName,igmpoldconnName,mcast_wan_flag);
#endif
#endif
#ifdef IFX_LOG_DEBUG
						IFX_DBG("   In func [%s] line [%d] old : %s new : %s  !!", __FUNCTION__, __LINE__,oldconnName , newconnName);
#endif
																												if (ret != 0)
																												{
																																IFX_DBG("   Update_wan_config failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
																												}
																								}
																				}
																				else if(nCount == 2)
																				{
																								wan_type = nvp[1];

																								ret = Update_wan_config(wan_mode,wan_type);
																								if (ret != 0)
																								{
																												IFX_DBG("   Update_wan_config failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
																								}
																								ret = Update_virtual_server_config(newconnName,"autodetect");
																								if (ret != 0)
																								{
																												IFX_DBG("   Update_wan_config failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
																								}
																				}

																				break;
												}
												break;
#endif
#endif
	case EVT_TYPE_TR69_SYS_INIT:
		
		/* iid,array_fvp,count is not required for this event */
		sprintf(array_fvp[count].fieldname, "%s", "PhyLinkStatus");
		sprintf(array_fvp[count++].value, "%s", "Up");
		IFX_FILL_IID(iid, 1, "wlan_main")
	      	/* calling event handler to post msg to devm when system initialization over */  
	      	IFX_TR69_EVENT_HANDLER(evtType, evtState, iid, array_fvp,
					   count, IFX_Handler)
	break;
	
	default:
		goto IFX_Handler;
	}

      IFX_Handler:
	return IFX_SUCCESS;
}

// #705174:Pramod end
