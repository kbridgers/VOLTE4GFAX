/******************************************************************************
**
** FILE NAME    : sw_reset.c
** PROJECT      : UGW
** MODULES      : GPIO for sw reset
**
** DATE         : 23 Dec 2011
** AUTHOR       : 
** DESCRIPTION  : Sw Reset Push Button Driver
** COPYRIGHT    :       Copyright (c) 2011
**                      Lantiq Communications 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
** HISTORY
** $Date        $Author         $Comment
** 23 Dec 2011 
*******************************************************************************/


#ifndef EXPORT_SYMTAB
#define EXPORT_SYMTAB
#endif
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/major.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/fcntl.h>
#include <linux/ptrace.h>
#include <linux/mm.h>
#include <linux/ioport.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/spinlock.h>
#include <linux/slab.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/bitops.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>

#include <linux/version.h>
#ifdef CONFIG_VR9
#include <asm-mips/ifx/vr9/vr9.h>
#include <asm-mips/ifx/vr9/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#elif defined(CONFIG_AMAZON_S)
#include <asm/amazon_s/amazon_s.h>
#include <asm/amazon_s/irq.h>
#include <asm/amazon_s/amazon_s_gptu.h>
#elif defined CONFIG_DANUBE
#include <asm-mips/ifx/danube/danube.h>
#include <asm-mips/ifx/danube/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#elif defined CONFIG_AR9
#include <asm-mips/ifx/ar9/ar9.h>
#include <asm-mips/ifx/ar9/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#elif defined CONFIG_AR10
#include <asm-mips/ifx/ar10/ar10.h>
#include <asm-mips/ifx/ar10/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#endif
#if (defined(CONFIG_MODVERSIONS)&&(CONFIG_MODVERSIONS==1))
# include <linux/modversions.h>
#endif

#define GPIO_SWRESET_VERSION "1.0.0.0"

#if 0
#define DEBUG(args...) do {;} while(0)
#else
#define DEBUG   printk
#endif


#define BIT5   (1<<5)

#if defined (CONFIG_VR9)
	//#define SWRESET_PIN 54
	#define SWRESET_PIN 7
#elif defined(CONFIG_AMAZON_S)
	#define SWRESETBIT BIT5
#elif defined(CONFIG_DANUBE)
	#define SWRESET_PIN 22
#elif defined CONFIG_AR9_REF_BOARD
	#define SWRESET_PIN 54
#elif defined CONFIG_AR9_CUSTOM_BOARD
	#define SWRESET_PIN 53
#elif defined CONFIG_AR10
  #if defined (CONFIG_AR10_FAMILY_BOARD_2)
	#define SWRESET_PIN 25
  #else
	#define SWRESET_PIN 17
  #endif
#endif

#define SWRESETBIT 1
static const int swreset_gpio_module_id = IFX_GPIO_MODULE_SWRESET;

#define POLLING_PERIOD HZ/10
#define FIFO_LEN 5

#if CONFIG_PROC_FS
static struct proc_dir_entry *swreset_proc_dir;
int swreset_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data);

int swreset_drv_get_version_proc(char *buf);

#define PROC_SWRESETBUTTON "swreset"
static struct proc_dir_entry *Proc_File;
static unsigned long procfs_buffer_size = 0;
static unsigned char procfs_buffer[37]={0};


#endif /* CONFIG_PROC_FS */

struct timer_list gpio_timer;

wait_queue_head_t swreset_readq;

int maj = 151;
int g_time = 0;
int ready_output = 0;
int user_output = 0;
unsigned int global_index = 0;
unsigned int output_index = 0;
int output_time[FIFO_LEN] = {0};


void ltq_sw_reset_GPIO_init(void)
{
    ifx_gpio_register(swreset_gpio_module_id);
}

static void gpio_swreset(unsigned long data)
{
    uint32_t gpio_p0_in=0;
    ifx_gpio_input_get(SWRESET_PIN,swreset_gpio_module_id,&gpio_p0_in);

//    printk("gpio_swreset %d\n",gpio_p0_in);
#if CONFIG_PROC_FS
      if(user_output){
	    ready_output = 1;
      	if(user_output == 1){
        	output_time[global_index] = 100;
	}
      	else if(user_output == 3){ /* Added for initiaing Date and time notification */
        	output_time[global_index] = 500;
	}	
        else{
        	output_time[global_index] = 10;
      	}
	++global_index;
      	global_index = (global_index) % FIFO_LEN;
      	wake_up_interruptible(&swreset_readq);
	user_output=0;
     }
     else
#endif
    if (gpio_p0_in & SWRESETBIT)
    {
        if (g_time > 0)
        {
	    ready_output = 1;
            output_time[global_index] = g_time;
            DEBUG("output_time is %i and global_index is % i\n",output_time[global_index],global_index);
	    ++global_index;
            global_index = (global_index) % FIFO_LEN;
            wake_up_interruptible(&swreset_readq);
            DEBUG("The output time is %i\n",output_time);
        }
        g_time = 0;
    }
    else
    {
        ready_output = 0;
	g_time ++;
    }

    mod_timer(&gpio_timer,jiffies + POLLING_PERIOD);
}

#if CONFIG_PROC_FS
int procfile_write(struct file *file, const char *buffer, unsigned long count,void *data)
{
	 procfs_buffer_size = count;
	 if(copy_from_user(procfs_buffer,buffer,procfs_buffer_size)<0){
		 return -1;
	 }
	 if(procfs_buffer[0] == '1'){
		 user_output = 1; 
	 }
	 else if(procfs_buffer[0] == '3'){/* Added for initiaing Date and time notification */
		 user_output = 3;
	 }
   else{
		 user_output = 2;
   }
	 return procfs_buffer_size;
}
#endif                                                                                

int sw_reset_open(struct inode *inode, struct file * filp)
{
  filp->f_pos=0;
  ltq_sw_reset_GPIO_init();
  g_time=0;  
  DEBUG("sw_reset_open is invoked\n");

#if CONFIG_PROC_FS
  swreset_proc_dir = proc_mkdir("driver/swreset", NULL);

  if (swreset_proc_dir != NULL)
  {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
    swreset_proc_dir->owner = THIS_MODULE;
#endif
    create_proc_read_entry("version", S_IFREG|S_IRUGO, swreset_proc_dir,
                    swreset_drv_read_proc, swreset_drv_get_version_proc);
		/* create the /proc file */
		Proc_File = create_proc_entry(PROC_SWRESETBUTTON, 0644, NULL);
		Proc_File->read_proc  = NULL;
		Proc_File->write_proc = procfile_write;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
		Proc_File->owner = THIS_MODULE;
#endif
		Proc_File->mode = S_IFREG | S_IRUGO;
		Proc_File->parent = swreset_proc_dir;
		Proc_File->uid = 0;
		Proc_File->gid = 0;


  }
#endif /* CONFIG_PROC_FS */
        return 0;
}
                                                                                
int sw_reset_close(struct inode *inode, struct file *filp)
{
  ifx_gpio_deregister(swreset_gpio_module_id);
#if CONFIG_PROC_FS
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
		remove_proc_entry(PROC_SWRESETBUTTON, &proc_root);
#else
		remove_proc_entry(PROC_SWRESETBUTTON, NULL);
#endif
		remove_proc_entry("version", swreset_proc_dir);
		remove_proc_entry("driver/swreset", NULL);
#endif /* CONFIG_PROC_FS */
    return 0;
}
int sw_reset_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long data)
{
	return 0;
}
                                                                                
static ssize_t sw_reset_read(struct file *filp, char *ubuf, size_t len, loff_t *off)
{
    char buf[20];
    int ret;
    int i;
 
    DEBUG("sw_reset_read is invoked\n");
    if (ready_output)
    {
           if (global_index > output_index)
           {
		if (global_index - output_index == 1)
                {
                   sprintf(buf,"%i",output_time[output_index]);
    					 DEBUG("sw_reset_read  - 1\n");
                }else{
                   for (i=0; i<(global_index-output_index); i++)
                   {
                      sprintf(buf+2*i,"%i ",output_time[output_index+i]);
    					 	DEBUG("sw_reset_read  - 2\n");
                   }
                }
           }else{
		if (global_index + FIFO_LEN - output_index == 1)
                {
                   sprintf(buf,"%i",output_time[output_index]);
    					 DEBUG("sw_reset_read  - 3\n");
                }else{
                   for (i=0; i<(global_index+FIFO_LEN-output_index); i++)
                   {
                      sprintf(buf+2*i,"%i ",output_time[(output_index+i)%FIFO_LEN]);
    					 	 DEBUG("sw_reset_read  - 4\n");
                   }
                }
           }
          output_index = global_index;        
               
	   ready_output = 0;
    }

    if (copy_to_user((void*)ubuf, buf, 20 ) != 0)
            ret = -EFAULT;
    return 1;//the length

}
static ssize_t sw_reset_write(struct file *filp, const char *ubuf, size_t len, loff_t *off)
{
	char buf[256];
	
        memset(buf,0,256);	
	copy_from_user(buf, ubuf, len);
        DEBUG("sw_reset_write is invoked and the buf is %s\n",buf);
	return 0;
}
unsigned int sw_reset_poll(struct file *filp, poll_table *wait)
{
    unsigned int mask = 0;

    poll_wait(filp, &swreset_readq, wait);

     if (ready_output)
        mask |= POLLIN | POLLRDNORM;                                                            
    return mask;
}

static struct file_operations sw_reset_fops = {
        owner:          THIS_MODULE,
        read:           sw_reset_read,    /* read */
        write:          sw_reset_write,   /* write */
        ioctl:          sw_reset_ioctl,   /* ioctl */
        open:           sw_reset_open,    /* open */
        poll:           sw_reset_poll,    /* poll */
        release:        sw_reset_close,   /* release */
};



int __init ltq_swreset_init(void)
{
    int ret;

    init_timer(&gpio_timer);
    gpio_timer.data = (long)NULL;
    gpio_timer.function = gpio_swreset;
    gpio_timer.expires =  jiffies + POLLING_PERIOD;
    add_timer(&gpio_timer);

    init_waitqueue_head(&swreset_readq);
    if ((ret = register_chrdev(maj, "sw_reset", &sw_reset_fops)) < 0){
                printk("Unable to register major %d for the Infineon Danube DECT\n", maj);
    }
  
    return 0;
}

void __exit ltq_swreset_cleanup_module(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
    int ret;
		if((ret = unregister_chrdev(maj,"sw_reset"))<0)
		{
     	printk("Unable to un-register major %d for the Infineon Danube DECT\n", maj);
		}
#else
		unregister_chrdev(maj,"sw_reset");
#endif
    del_timer(&gpio_timer);
}

#if CONFIG_PROC_FS
int swreset_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data)
{
  int len;
  int (*fn)(char *buf);

  if (data != NULL)
  {
    fn = data;
    len = fn(page);
  }
  else
    return 0;

  if (len <= off+count)
    *eof = 1;

  *start = page + off;

  len -= off;

  if (len > count)
    len = count;

  if (len < 0)
    len = 0;

  return len;

}
int swreset_drv_get_version_proc(char *buf)
{
  int len;
  unsigned char ucVersion[]=GPIO_SWRESET_VERSION;
  len = sprintf(buf, "Page Driver Version:%s\n Built Time stamp: Date-%sTime-%s\n",ucVersion,__DATE__,__TIME__);
  return len;
}
#endif/*CONFIG_PROC_FS*/

module_exit(ltq_swreset_cleanup_module);
module_init(ltq_swreset_init);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Kamal Eradath");
MODULE_DESCRIPTION("LTQ SWRESET button driver");
