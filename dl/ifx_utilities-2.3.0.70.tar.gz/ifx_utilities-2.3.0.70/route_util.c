#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <ifx_common.h>

#ifdef IFX_MULTILIB_UTIL
#define	main	route_util_main
#endif

void usage(char *apps_name)
{
	printf("usage: %s ADD/DEL TARGET NETMASK GW INTF", apps_name);
}

int main(int argc, char *argv[])
{
	char *ptr = NULL, *tptr = NULL;
	char route_cmd[80], t_tgt[20], t_net[20];
	int i = 0, tgt_oct[4];

	/* argument INTF is optional here */
	if (argc < 5 || argc > 6) {
		usage(argv[0]);
		return 1;
	}

	sprintf(t_tgt, "%s", argv[2]);
	sprintf(t_net, "%s", argv[3]);

	/* convert TARGET as per NETMASK specified */
	ptr = strtok_r(t_tgt, ".", &tptr);
	while (ptr != NULL) {
		tgt_oct[i++] = atoi(ptr);
		ptr = strtok_r(NULL, ".", &tptr);
	}

	i = 0;
	ptr = strtok_r(t_net, ".", &tptr);
	while (ptr != NULL) {
		tgt_oct[i++] &= atoi(ptr);
		ptr = strtok_r(NULL, ".", &tptr);
	}

	if (!strcmp(argv[1], "ADD")) {
		if (argv[5] != NULL) {
			sprintf(route_cmd,
				"route add -net %d.%d.%d.%d netmask %s gw %s dev %s",
				tgt_oct[0], tgt_oct[1], tgt_oct[2], tgt_oct[3],
				argv[3], argv[4], argv[5]);
		} else {
			sprintf(route_cmd,
				"route add -net %d.%d.%d.%d netmask %s gw %s",
				tgt_oct[0], tgt_oct[1], tgt_oct[2], tgt_oct[3],
				argv[3], argv[4]);
		}
	} else if (!strcmp(argv[1], "DEL")) {
		if (argv[5] != NULL) {
			sprintf(route_cmd,
				"route del -net %d.%d.%d.%d netmask %s gw %s dev %s",
				tgt_oct[0], tgt_oct[1], tgt_oct[2], tgt_oct[3],
				argv[3], argv[4], argv[5]);
		} else {
			sprintf(route_cmd,
				"route del -net %d.%d.%d.%d netmask %s gw %s",
				tgt_oct[0], tgt_oct[1], tgt_oct[2], tgt_oct[3],
				argv[3], argv[4]);
		}
	}

	system(route_cmd);

	return 0;
}
