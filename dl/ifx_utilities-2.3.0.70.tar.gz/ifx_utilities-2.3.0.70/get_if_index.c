/*
 * 508302:linmars support get_if_index_by_name
 */
#include <stdio.h>
#include <sys/types.h>
#include<string.h>
#include<unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>

#ifdef IFX_MULTILIB_UTIL
#define main	get_if_index_main
#endif

int main(int argc, char *argv[])
{
	struct ifreq ifr;
	//int alen;
	int s;

	if (argc < 1) {
		goto err_exit;
	}

	s = socket(PF_PACKET, SOCK_DGRAM, 0);
	if (s < 0) {
		goto err_exit;
	}

	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, argv[1]);
	if (ioctl(s, SIOCGIFINDEX, &ifr) < 0) {
		close(s);
		goto err_exit;
	}
	printf("%d", ifr.ifr_ifindex);
	close(s);
	return 0;
      err_exit:
	printf("0");
	return -1;
}
