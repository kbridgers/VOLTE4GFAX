/*
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */
//-----------------------------------------------------------------------
//Description:  
// generic register access tools under Linux for Amazon
//-----------------------------------------------------------------------
//Author:       Qi-Ming.Wu@infineon.com
//Created:      28-July-2004
//-----------------------------------------------------------------------
/* History
 * Last changed on:
 * Last changed by: 
 */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/mman.h>
#include <errno.h>

#define LINE 0
#define TABLE 1
#define BYTE 0
#define WORD 1
#define SWITCH_BASE 0xB0106000
#define SWITCH_RANGE 0x3FF
#define DMA_BASE    0xB0103000
#define DMA_RANGE   0x7FF
#define TPE_BASE    0x0
#define TPE_RANGE   0x0
#define WDT_BASE    0xB0100900
#define WDT_RANGE   0xFF

#ifdef IFX_MULTILIB_UTIL
#define	main	mem_main
#endif

static int c;
static int start_address = 0;
static int end_address = 0;
static int end_input = 0;
static int range = 1;
//static int range_input=0;
static int input_flag = 0;
//static int digit_optind=0;
static int format_flag = LINE;
static int length_flag = BYTE;
static int write_value = 0;
static void (*func) () = NULL;
static void *g_address;

void display_version()
{
	printf
	    ("amazon memory test version1.0\nby Wu Qi Ming\nQi-Ming.Wu@infineon.com\n");

	return;
}

void mem_help()
{
	printf("Usage:mem [options] [parameter] ...\n");
	printf("options:\n");
	printf("-h --help            Display help information\n");
	printf("-d --dump            Display memory content \n");
	printf("-s --start=ADDRESS   Set starting address\n");
	//printf("-e --end=ADDRESS     Set end address\n");
	printf("-r --range=RANGE     Set address range\n");
	printf("-w --write           Write to memory\n");
	printf("-l --line            Display in consecutive lines format\n");
	printf("-t --table           Display in table format\n");
	printf("-b --byte            Display in byte form\n");
	printf("-u --word            Display in word form\n");
	//printf("--switch             range=switch register\n");
	//printf("--dma                range=dma register\n");
	//printf("--tpe                range=TPE register\n");
	//printf("--wdt                range=watch dog timer register\n");
	printf("-v --version         Display version information\n");
	return;
}

int map(char *fname, unsigned int offset, unsigned int len)
{
	FILE *f;

	if (!(f = fopen(fname, "r+w"))) {
		perror("fopen");
		return -EIO;
	}
	//g_address=mmap(0, len, PROT_READ, MAP_FILE | MAP_PRIVATE, fileno(f), offset);
	g_address =
	    mmap(0, len, PROT_READ | PROT_WRITE, MAP_SHARED, fileno(f), offset);
	if (g_address == (void *)-1) {
		perror("mmap: ");
		fclose(f);
		return -EFAULT;
	}
	fclose(f);
	return 0;
}

void mem_write()
{
	//  int i=0;
	int offset = (start_address) & 0xffff0000;
	map("/dev/mem", offset, 0x1000000);

	switch (length_flag) {
	case BYTE:
		*((unsigned char *)g_address + (start_address - offset)) =
		    (unsigned char)write_value;
		break;
	case WORD:
		printf("writing 0x%08x into address 0x%08x\n", write_value,
		       (start_address & (~3)));
		*((int *)g_address + (((start_address - offset) & (~3)) >> 2)) =
		    (int)write_value;
		break;
	}

}

void mem_dump()
{

	int i = 0;
	int j = 0;
	int pos = 0;
	int value = 0;
	int finish = 0;
	int offset = (start_address) & 0xfffff000;
	map("/dev/mem", offset, 0x1000000);
	if (length_flag == BYTE) {
		switch (format_flag) {
		case LINE:
			for (i = 0; i < range; i++)
				printf("0x%08x:0x%02x\n", (start_address) + i,
				       *((unsigned char *)g_address +
					 (start_address - offset) + i));
			break;

		case TABLE:
			printf("           ");
			for (i = 0; i < 16; i++)
				printf("%02x ", i);
			printf("\n");
			//for(i=0;i<=((range-1)>>4);i++)
			i = 0;
			while (1) {
				if (finish == 1)
					break;
				printf("0x%08x:",
				       ((start_address) & (~15)) + i * 16);

				for (j = 0; j < 16; j++) {
					pos =
					    ((start_address - offset) & (~15)) +
					    i * 16 + j;
					if ((pos - (start_address - offset)) >=
					    range) {
						//printf("%d,%d,%d\n",pos,start_address,(pos-start_address));
						finish = 1;
						break;
					}
					value =
					    *((unsigned char *)g_address + pos);
					if ((pos < (start_address - offset))) {
						printf("   ");

					} else {
						printf("%02x ", value);
					}
				}
				printf("\n");
				i++;
			}
			break;
		}
	}

	if (length_flag == WORD) {
		switch (format_flag) {
		case LINE:

			for (i = 0; i < range; i++) {
				pos =
				    (((start_address - offset) & (~3)) +
				     i * 4) >> 2;
				printf("0x%08x:0x%08x\n",
				       ((start_address) & (~3)) + i * 4,
				       *((int *)g_address + pos));
			}
			break;

		case TABLE:
			printf("           ");
			for (i = 0; i < 4; i++)
				printf("0x%08x ", i * 4);
			printf("\n");
			i = 0;
			finish = 0;
			while (1) {
				if (finish == 1)
					break;
				printf("0x%08x:",
				       ((start_address) & (~15)) + i * 16);

				for (j = 0; j < 4; j++) {
					pos =
					    (((start_address - offset) & (~3)) +
					     i * 16 + j * 4) >> 2;
					if (((pos << 2) -
					     (start_address - offset)) >=
					    range * 4) {
						//printf("%d,%d,%d\n",pos,start_address,(pos-start_address));
						finish = 1;
						break;
					}
					value = *((int *)g_address + pos);
					if ((pos <
					     ((start_address - offset) >> 2))) {
						printf("           ");

					} else {
						printf("0x%08x ", value);
					}
				}
				printf("\n");
				i++;
			}
			break;
		}
	}

	return;

}

int main(int argc, char **argv)
{
	while (1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"dump", 0, 0, 0},
			{"start", 1, 0, 0},
			{"end", 1, 0, 0},
			{"range", 1, 0, 0},
			{"line", 0, 0, 0},
			{"table", 0, 0, 0},
			{"write", 1, 0, 0},
			{"switch", 0, 0, 0},
			{"dma", 0, 0, 0},
			{"tpe", 0, 0, 0},
			{"wdt", 0, 0, 0},
			{"byte", 0, 0, 0},
			{"word", 0, 0, 0},
			{"version", 0, 0, 0}

		};
		c = getopt_long(argc, argv, "bs:e:r:dtlhw:uv",
				long_options, &option_index);

		//printf("c=%d option_index=%d\n",c,option_index);       
		if (c == -1) {
			if (input_flag == 0) {
				printf("mem:please specify parameters\n");
				func = &mem_help;
			}
			if (func)
				(*func) ();
			else {
			      ERROR:mem_help();
			}
			break;
		}
		input_flag = 1;
		switch (c) {
		case 0:
			if (option_index == 0) {
				func = &mem_help;
				break;
			}
			if (option_index == 1) {
				func = &mem_dump;
				break;
			}
			if (option_index == 2) {
				if (!optarg)
					goto ERROR;
				start_address = strtoul(optarg, NULL, 0);
				break;
			}
			if (option_index == 3) {
				if (!optarg)
					goto ERROR;
				end_address = strtoul(optarg, NULL, 0);
				break;
			}
			if (option_index == 4) {
				if (!optarg)
					goto ERROR;
				range = strtoul(optarg, NULL, 0);
				break;
			}
			if (option_index == 5) {
				format_flag = LINE;
				break;
			}
			if (option_index == 6) {
				format_flag = TABLE;
				break;
			}
			if (option_index == 7) {
				if (!optarg)
					goto ERROR;
				write_value = strtoul(optarg, NULL, 0);
				func = &mem_write;
				break;
			}
			if (option_index == 8) {
				start_address = SWITCH_BASE;
				range = SWITCH_RANGE;
				break;
			}
			if (option_index == 9) {
				start_address = DMA_BASE;
				range = DMA_RANGE;
				break;
			}
			if (option_index == 10) {
				start_address = TPE_BASE;
				range = TPE_RANGE;
				break;
			}
			if (option_index == 11) {
				start_address = WDT_BASE;
				range = WDT_RANGE;
				break;
			}
			if (option_index == 12) {
				length_flag = BYTE;
				break;
			}
			if (option_index == 13) {
				length_flag = WORD;
				break;
			}
			if (option_index == 14) {
				func = &display_version;
				break;

			}
		case 'h':
			func = &mem_help;
			break;
		case 's':
			if (!optarg)
				goto ERROR;
			start_address = strtoul(optarg, NULL, 0);
			break;
		case 'e':
			if (!optarg)
				goto ERROR;
			end_input = 1;
			end_address = strtoul(optarg, NULL, 0);
			break;
		case 'r':
			if (!optarg)
				goto ERROR;
			range = strtoul(optarg, NULL, 0);
			break;
		case 'd':
			func = &mem_dump;
			break;
		case 'b':
			length_flag = BYTE;
			break;
		case 'u':
			length_flag = WORD;
			break;
		case 'l':
			format_flag = LINE;
			break;
		case 't':
			format_flag = TABLE;
			break;
		case 'w':
			if (!optarg)
				goto ERROR;
			write_value = strtoul(optarg, NULL, 0);
			func = &mem_write;
			break;
		case 'v':
			func = &display_version;
			break;
		}
	}
	return 0;
}
