/*
 **************************************************************************
 *       file       : ltq_crypt.c                                         *
 *       Description: Command for enc/dec string to stdout                * 
 *       Author     : UDAYA SHANKARA KS, RTSS Team,                       *
 *       Date       : Tue Sep  4 12:31:18 IST 2012                        *
 **************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <libgen.h>
#include "ifx_config.h"


#ifdef CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION

#ifdef IFX_MULTILIB_UTIL
#define main	ltq_crypt
#endif

#define CRYPT_KEY_LEN    40

extern int key[CRYPT_KEY_LEN];

// function decrypt using OTP algorithm
extern int decrypt_OTP( char *out_buf, const char *in_buf, int len, void *key);

// function encrypt using OTP algorithm
extern int encrypt_OTP( char *out_buf, const char *in_buf, int len, void *key);

// function to encode the string using customised base64 algorithm
extern int encode_base64( char *out_buf, const char *in_buf, int len , void *key);

// function to decode the string using customised base64 algorithm
extern int decode_base64( char *out_buf, const char *in_buf, int len , void *key);

// function get encrypt the rc.conf paramters
extern int get_cryptFileEnc( char *in_file );  

// Enumerator for crypt mode 
typedef enum
{
  CRYPT_MODE_ENCRYPT,                // mode encryption
  CRYPT_MODE_DECRYPT                 // mode decryption

}t_crypt_mode_en;

// Enumeration type for crypto algorithms
typedef enum 
{
  CRYPT_BASE64_ENCODING,              // crypt customised base64 encoding
  CRYPT_ONE_TIME_PADDING,             // crypt one time padding 
//CRYPT_AES,                          // crypt aes 

  MAX_CRYPT_ALG                       // maximum number of crypts avalilable
}t_crypt_alg_en ;

//
// crypt_otp 
//    function for one time padding algorigth
//
int crypt_otp( t_crypt_mode_en cmode, const char * in_buf )
{
  char out_buf[256];


  if (cmode == CRYPT_MODE_DECRYPT )
    decrypt_OTP( out_buf, in_buf, CRYPT_KEY_LEN , key);
  else 
    encrypt_OTP( out_buf, in_buf, CRYPT_KEY_LEN, key);

  /* 
   * writing to file desceptor :1 required for redirection of STDOUT,
   * Called from the script 
   */
  fprintf( stdout,"password %s\n", out_buf);
  return 0;
}

//
// ltq_crypt_base64
//  function for modified base64 algorithm
//
int ltq_crypt_base64( t_crypt_mode_en cmode, const char *in_buf )
{
  char out_buf[256];

  if (cmode == CRYPT_MODE_DECRYPT)
    decode_base64( out_buf, in_buf, strlen(in_buf), NULL);
  else 
    encode_base64( out_buf, in_buf, strlen(in_buf), NULL);

  // Writing to filedecreptor <1>, Required for redirection of stdout
  // Called from the script
  fprintf( stdout,"password %s\n", out_buf);
  return 0;

}

// call back function for encryption methods
typedef int(*crypt_alg_cb)( t_crypt_mode_en en_crypt_mode, const char * input_string);

// Handler for encryption algorithms
struct __crypt_alg
{
  t_crypt_alg_en           en_crypt_alg;       // Encryption method 
  crypt_alg_cb             cb_crypt;           // Call back function for encryption algorithm
}st_crypt_alg[MAX_CRYPT_ALG] = 
{
  { CRYPT_BASE64_ENCODING, ltq_crypt_base64 }, // Handler for CUSTOMIDED BASE64 ENCODING
  { CRYPT_ONE_TIME_PADDING, crypt_otp}         // Handler for ONE TIME PADDING crypto
};
   

// 
// get_cryptResult 
//    function to get the crypt result to STDOUT 
// 
int get_cryptResult( int crypt_method, int crypt_alg, char *input_string )
{

  int idx;

  for ( idx = 0; idx < MAX_CRYPT_ALG ; idx++){
    if ( crypt_alg == st_crypt_alg[idx].en_crypt_alg){
        if (st_crypt_alg[idx].cb_crypt && input_string )
           st_crypt_alg[idx].cb_crypt( crypt_method, input_string);
        break;
    }
  }

  return 0;
}


//
// ltq_crypt_help
//   function to print the help 
// 
void ltq_crypt_help(char *base_name)
{

  printf("Usage:\n");
  printf("======\n");
  printf("%s [OPTIONS] [INPUT_STRING]\n",basename(base_name));
  printf("OPTIONS: \n");
  printf(" -e: Encryption \n -d: Decryption \n");
  printf("\nCrypto Algorithms\n");
  printf(" -o: One Time Padding\n -a: AES \n");
  printf(" -b: Customised base64 encoding\n");
  printf(" -t: full file encryption \n");
  return ;
  
} 


/*
 *  input format :
 *  a.out -{option1} -{option2} ..  {input_value}
 * (OR)
 *  a.out -{option1,option2,....}   {input_value}
 *
 */

//
// main
//   main module 
// 
int main( int argc, char ** argv )
{
  t_crypt_mode_en  crypt_method = 0 ;
  t_crypt_alg_en   crypt_alg = 0 ;
  char *input_string = NULL;
  char *base_name = argv[0];
  int type = 0;

  if ( argc < 3 ){
     ltq_crypt_help(base_name);
     exit(0);
  }
  
  while (*++argv){
     if (**argv == '-' ){
        while (*++*argv){
          switch( **argv )
          {
              case 'd':
              case 'D':
                     crypt_method = CRYPT_MODE_DECRYPT;
                     break;

              case 'e':
              case 'E': 
                    crypt_method = CRYPT_MODE_ENCRYPT;
                    break;

              case 'o':
              case 'O':
                     crypt_alg = CRYPT_ONE_TIME_PADDING;
                     break;

              case 'b':
              case 'B':
                     crypt_alg = CRYPT_BASE64_ENCODING;
                     break;

              case 'h':
              case 'H':
                     ltq_crypt_help(base_name);
                     break;

              case 't':
              case 'T':
                     type = 1;      // file encryption option 
                     break;

              default:
                    printf("Unknow option <%c> exiting now\n", **argv);
                    ltq_crypt_help(base_name);
                    exit(0);
                    //break;
          } 
        } 
     } else {
       input_string = *argv;
     }

  }

  if ( type )
    get_cryptFileEnc( input_string );
  else 
    get_cryptResult( crypt_method, crypt_alg, input_string);

  return 0;
}
#endif //PARAMETER_ENCRYPTION_FEATURE macro 
