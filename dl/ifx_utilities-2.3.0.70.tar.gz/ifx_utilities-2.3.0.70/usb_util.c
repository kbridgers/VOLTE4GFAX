#include <stdio.h>
#include <stdlib.h>
#include <linux/types.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <string.h>
#include <syslog.h>
#include <sys/socket.h>

#ifdef IFX_MULTILIB_UTIL
#define	main	usb_util_main
#endif

int usb_daemon(void);
int create_nl_socket(void);

static int usb_sd;

int main(int argc, char *argv[])
{
	FILE *foam;
	int pid = 0;

	create_nl_socket();
	pid = getpid();
	printf("usb: PID:%d \n", pid);
	foam = fopen("/var/run/usb.pid", "w");
	if (!foam) {
		printf("/n Error opening file: /var/run/usb.pid !\n");
		return -1;
	}

	fprintf(foam, "%d", pid);
	fclose(foam);
	usb_daemon();

	return 0;
}

int create_nl_socket(void)
{

	struct sockaddr_nl src_addr, dest_addr;
	int addr_len;

	//usb_sd = socket(AF_NETLINK, SOCK_RAW, NETLINK_USBMSG);
	usb_sd = socket(AF_NETLINK, SOCK_RAW, 15);
	if (usb_sd < 0) {
		printf("Error opening USB socket");
	}

	memset(&src_addr, 0, sizeof(src_addr));
	/* bind socket */
	src_addr.nl_family = AF_NETLINK;
	src_addr.nl_pad = 0;
	src_addr.nl_pid = getpid();
	src_addr.nl_groups = 0;

	if (bind(usb_sd, (struct sockaddr *)&src_addr, sizeof(src_addr)) < 0) {
		printf(" Error binding USB socket");
	}

	addr_len = sizeof(src_addr);

	if (getsockname(usb_sd, (struct sockaddr *)&src_addr, &addr_len) < 0) {
		printf("cannot getsockname");
		return -1;
	}

	if (addr_len != sizeof(src_addr)) {
		printf("wrong address lenght %d\n", addr_len);
		return -1;
	}

	if (src_addr.nl_family != AF_NETLINK) {
		printf("wrong address family %d\n", src_addr.nl_family);
		return -1;
	}

	return 0;
}

int usb_daemon(void)
{
	//OAM_CELL *pCell;
	struct nlmsghdr *nlh = NULL;
	int size;
	struct sockaddr_nl dest_addr;
	struct msghdr rxmsg, txmsg;
	struct iovec rxiov, txiov;
	//struct sockaddr_nl oamRxSockAdd;
	struct amazon_atm_cell_header *amz_cell_hdr;
	char sCommand[128];
	/*Sumedh: new vars */
	FILE *fp = NULL;
	int free_mem = 0;
	char str_free_mem[10];
	/*end */

	memset(&dest_addr, 0, sizeof(dest_addr));

	dest_addr.nl_family = AF_NETLINK;
	dest_addr.nl_pid = 0;
	dest_addr.nl_groups = 0;

	nlh = (struct nlmsghdr *)malloc(64);
	nlh->nlmsg_len = 64;
	nlh->nlmsg_pid = getpid();
	nlh->nlmsg_flags = 0;

	txiov.iov_base = (void *)nlh;
	txiov.iov_len = nlh->nlmsg_len;

	txmsg.msg_name = (void *)&dest_addr;
	txmsg.msg_namelen = sizeof(dest_addr);
	txmsg.msg_iov = &txiov;
	txmsg.msg_iovlen = 1;
	txmsg.msg_control = NULL;
	txmsg.msg_controllen = 0;
	txmsg.msg_flags = 0;

	if (sendmsg(usb_sd, &txmsg, 0) < 0) {
		printf("\n tx_msg usb error!  ");
		return -1;
	}

	rxiov.iov_base = (void *)nlh;
	rxiov.iov_len = nlh->nlmsg_len;

	rxmsg.msg_name = (void *)&dest_addr;
	rxmsg.msg_namelen = sizeof(dest_addr);
	rxmsg.msg_iov = &rxiov;
	rxmsg.msg_iovlen = 1;
	rxmsg.msg_control = NULL;
	rxmsg.msg_controllen = 0;
	rxmsg.msg_flags = 0;

	while (1) {

		/* read whole structure */

		size = recvmsg(usb_sd, &rxmsg, 0);

		printf("\n Rcv usb kernel msg !");
		sprintf(sCommand, "ifconfig usb0 down");
		system(sCommand);
		sprintf(sCommand, "brctl delif br0 usb0");
		system(sCommand);
		sprintf(sCommand, "rmmod g_ether");
		system(sCommand);
		sprintf(sCommand, "rmmod dwc_otg");
		system(sCommand);
		/* */
		//         system("/etc/rc.d/rc.bringup_services stop");
		//system("killall -SIGTERM oamd dnrd atmarpd devm");
		/* Sumedh: Can only kill oamd, dnrd and wan services momentarily. */
		system
		    ("cat /proc/meminfo | grep Mem: | sed -n 's,Mem:[ ]*[0-9]*[ ]*[0-9]*[ ]*,,;1p' > /tmp/free__");
		system("cat /tmp/free__ | sed -e 's/ 0.*$//' > /tmp/free__");
		fp = fopen("/tmp/free__", "r+");
		if (fp) {
			fread(str_free_mem, sizeof(str_free_mem), 1, fp);
			free_mem = atoi(str_free_mem);
			fclose(fp);
		} else
			free_mem = 0;
		if (free_mem < 280000) {

			system("killall -SIGTERM oamd dnrd devm");
			//system("/etc/rc.d/rc.bringup_wan stop");
			sleep(3);
		}

		sprintf(sCommand, "insmod dwc_otg");
		system(sCommand);
		sprintf(sCommand, "insmod g_ether");
		system(sCommand);
		sprintf(sCommand, "brctl addif br0 usb0");
		system(sCommand);
		sprintf(sCommand, "ifconfig usb0 up");
		system(sCommand);

		sleep(3);
		//              system("/etc/rc.d/rc.bringup_services start");
		if (free_mem < 280000) {
			//system("/etc/rc.d/rc.bringup_wan start");
			system("devm");
			system("/etc/rc.d/init.d/dns_relay restart");
			system("/etc/rc.d/init.d/oam restart");
		}
		//system("/usr/sbin/devm");
		//system("/usr/sbin/atmarpd -b -l /dev/null");          
		//fflush(stdout);
	}
}
